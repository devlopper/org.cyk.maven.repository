package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.ColorPalette;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartDataSet;
import org.primefaces.model.charts.ChartOptions;
import org.primefaces.model.charts.axes.cartesian.CartesianScales;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearAxes;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearTicks;
import org.primefaces.model.charts.optionconfig.legend.Legend;
import org.primefaces.model.charts.optionconfig.title.Title;

/**
 * Cette classe représente la base de graphique.
 *
 * @author Christian
 *
 * @param <T> Type de modèle
 */
public abstract class AbstractChart<T> extends AbstractWidget {

  @Setter
  @Getter
  protected T model;

  /**
   * Cette classe représentente la base de constructeur de modèle.
   *
   * @author Christian
   *
   * @param <P> Type de modèle
   * @param <O> Type d'options
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  protected abstract static class AbstractModelBuilder<M, O extends ChartOptions, P> {

    ChartDto chart;
    ColorPalette colorPalette;
    Consumer<O> optionsConsumer;

    /**
     * Affichage du titre dans le graphique ; vrai si nul.
     */
    Boolean titleDisplayed;

    /**
     * Affichage de la légende ; comportement du composant graphique si nul.
     */
    Boolean legendDisplayed;

    /**
     * Graduations entières sur l'axe des valeurs, pour des effectifs (jamais 3,5 événements) ; faux
     * si nul.
     */
    Boolean integerValues;

    /**
     * Couleur (hexadécimale, ex. "#dc2626") imposée à une clé du graphique ; les clés absentes
     * gardent la couleur de la palette.
     */
    Map<String, String> keyColors;

    /**
     * Ajoute à l'échelle donnée un axe des valeurs gradué en entiers, à partir de zéro.
     *
     * @param scales échelle existante, ou nulle
     * @return l'échelle donnée, ou une nouvelle si elle était nulle
     */
    static CartesianScales withIntegerValues(CartesianScales scales) {
      CartesianLinearTicks ticks = new CartesianLinearTicks();
      ticks.setPrecision(0);
      CartesianLinearAxes axes = new CartesianLinearAxes();
      axes.setBeginAtZero(true);
      axes.setTicks(ticks);
      CartesianScales result = scales == null ? new CartesianScales() : scales;
      result.addYAxesData(axes);
      return result;
    }

    public M build() {
      Core.doThrowIfNull(IllegalArgumentException.class, "graphique requis", chart);
      ChartData chartData = new ChartData();
      chartData.setLabels(new ArrayList<>(chart.getKeys()));

      Collection<ChartDataSet> charDataSets = getChartDataSets(chart.filterDataSets());

      charDataSets.forEach(chartData::addChartDataSet);

      return consume(chartData);
    }

    Collection<ChartDataSet> getChartDataSets(Set<ChartDataSetDto> dtos) {
      AtomicInteger dtoIndex = new AtomicInteger();
      int dtosCount = dtos.size();
      return dtos.stream().map(dto -> {
        ChartDataSet chartDataSet = instantiateCharDataSet(dto, dtosCount, dtoIndex);
        dtoIndex.incrementAndGet();
        return chartDataSet;
      }).toList();
    }

    abstract ChartDataSet instantiateCharDataSet(ChartDataSetDto dto, int dtosCount,
        AtomicInteger dtoIndex);

    public M consume(ChartData chartData) {
      M model = instantateModel();
      processModel(model, chartData);

      O options = instantateOptions();
      configureOptions(options, chart.getName());
      processOptions(model, chartData, options);
      return model;
    }

    abstract M instantateModel();

    abstract void processModel(M model, ChartData chartData);

    abstract O instantateOptions();

    abstract void processOptions(M model, ChartData chartData, O options);

    void configureOptions(ChartOptions options, String titleText) {
      options.setResponsive(true);
      options.setMaintainAspectRatio(false);
      Title title = new Title();
      title.setDisplay(!Boolean.FALSE.equals(titleDisplayed));
      title.setText(titleText);
      options.setTitle(title);
      if (legendDisplayed != null) {
        Legend legend = new Legend();
        legend.setDisplay(legendDisplayed);
        options.setLegend(legend);
      }
    }

    /**
     * Cette méthode permet d'obtenir une couleur par clé : celle imposée par {@link #keyColors} ou,
     * à défaut, celle de la palette.
     *
     * @param border vrai pour la bordure (opaque), faux pour le fond (transparence réduite)
     * @return couleurs dans l'ordre des clés, ou la palette si aucune couleur n'est imposée
     */
    List<String> getKeyColors(boolean border) {
      List<String> palette = border ? colorPalette.getRgbList() : colorPalette.getRgbaList();
      if (!hasKeyColors()) {
        return palette;
      }
      List<String> colors = new ArrayList<>();
      int index = 0;
      for (String key : chart.getKeys()) {
        String hex = keyColors.get(key);
        colors.add(hex != null ? toCssColor(hex, border)
            : palette.isEmpty() ? null : palette.get(index % palette.size()));
        index++;
      }
      return colors;
    }

    boolean hasKeyColors() {
      return keyColors != null && !keyColors.isEmpty();
    }

    static String toCssColor(String hex, boolean border) {
      int rgb = Integer.parseInt(hex.substring(1), 16);
      String components = ((rgb >> 16) & 0xFF) + ", " + ((rgb >> 8) & 0xFF) + ", " + (rgb & 0xFF);
      return border ? "rgb(" + components + ")" : "rgba(" + components + ", 0.35)";
    }
  }

  /**
   * Cette classe représentente la base de constructeur.
   *
   * @author Christian
   *
   * @param <M> Type de modèle
   * @param <O> Type d'options
   * @param <B> type de constructeur de modèle
   * @param <T> Type de graphique
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public abstract static class AbstractBuilder<M, O extends ChartOptions,
      B extends AbstractModelBuilder<M, O, T>, T extends AbstractChart<M>>
      extends AbstractWidgetBuilder<T> {

    B modelBuilder;

    @Override
    protected void validate() {
      super.validate();
      Core.doThrowIfNull(IllegalArgumentException.class, "constructeur de modèle requis",
          modelBuilder);
    }
        
    @Override
    protected void processWidget(T chart) {
      super.processWidget(chart);
      chart.model = modelBuilder.build();
    }
  }
}
