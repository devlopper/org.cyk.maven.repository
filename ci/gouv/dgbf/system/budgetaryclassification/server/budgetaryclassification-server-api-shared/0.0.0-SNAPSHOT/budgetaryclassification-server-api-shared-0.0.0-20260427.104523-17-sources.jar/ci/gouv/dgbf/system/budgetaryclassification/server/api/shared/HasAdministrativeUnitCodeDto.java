package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un code d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitCodeDto extends HasAdministrativeUnitCode {

  /**
   * Identifiant json du code de l'unité administrative.
   */
  String JSON_ADMINISTRATIVE_UNIT_CODE = "codeUniteAdministrative";
}
