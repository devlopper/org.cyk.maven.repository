package ci.gouv.dgbf.extension.primefaces.template;

import java.util.Locale;

/**
 * Cette classe calcule l'avatar d'un utilisateur : ses initiales et une teinte stable.
 *
 * <p>Les initiales sont la première lettre des deux premiers mots du nom (« KOUASSI Yao Jean »
 * donne « KY ») ; un nom d'un seul mot donne sa première lettre. La teinte ne dépend que du nom :
 * une même personne garde la même couleur d'une page et d'une session à l'autre.
 *
 * @author Christian
 */
public final class UserAvatar {
  /**
   * Nombre de teintes disponibles (classes {@code user-avatar--tone-0} à {@code -3} de
   * layout-private.css).
   */
  public static final int TONE_COUNT = 4;

  private static final int MAX_INITIALS = 2;

  private UserAvatar() {}

  /**
   * Cette méthode calcule les initiales d'un nom.
   *
   * @param names le nom et les prénoms
   * @return les initiales en majuscules, ou une chaîne vide si le nom ne contient aucune lettre
   */
  public static String initials(String names) {
    if (names == null) {
      return "";
    }
    StringBuilder initials = new StringBuilder();
    boolean wordStart = true;
    for (int i = 0; i < names.length() && initials.length() < MAX_INITIALS; ) {
      int codePoint = names.codePointAt(i);
      i += Character.charCount(codePoint);
      if (!Character.isLetter(codePoint)) {
        wordStart = true;
      } else if (wordStart) {
        initials.appendCodePoint(codePoint);
        wordStart = false;
      }
    }
    return initials.toString().toUpperCase(Locale.ROOT);
  }

  /**
   * Cette méthode calcule la teinte d'un nom.
   *
   * @param names le nom et les prénoms
   * @return un entier entre 0 et {@value #TONE_COUNT} exclu ; 0 si le nom est vide
   */
  public static int tone(String names) {
    if (names == null || names.isBlank()) {
      return 0;
    }
    return Math.floorMod(names.strip().toLowerCase(Locale.ROOT).hashCode(), TONE_COUNT);
  }
}
