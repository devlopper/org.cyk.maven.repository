package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sous localité.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SubLocalityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant {@link Locality}.
   */
  @JsonbProperty(JSON_LOCALITY_IDENTIFIER)
  private String localityIdentifier;
  
  /*
   * Réprésentation en chaine de caractère {@link LocalityDto}.
   */
  @JsonbProperty(JSON_LOCALITY_AS_STRING)
  private String localityAsString;

  /**
   * Identifiant json de identifiant de {@link SubLocalityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSousLocalite";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link SubLocalityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "sousLocaliteChaine";

  /**
   * Identifiant json {@link #localityIdentifier}.
   */
  public static final String JSON_LOCALITY_IDENTIFIER =
      "idLocalite";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link LocalityDto}.
   */
  public static final String JSON_LOCALITY_AS_STRING = "localiteChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "sous localité";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
