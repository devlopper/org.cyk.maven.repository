package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/** Page d'administration de la confidentialite par type. */
@Named
@ViewScoped
public class ResourceTypeConfidentialityListPage extends AbstractPage {
  @Inject @Getter ResourceTypeConfidentialityController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ResourceTypeConfidentialityDto.PLURAL_NAME;
    controller.initialize();
  }

  public static final String OUTCOME = "resourceTypeConfidentialityListPage";
}
