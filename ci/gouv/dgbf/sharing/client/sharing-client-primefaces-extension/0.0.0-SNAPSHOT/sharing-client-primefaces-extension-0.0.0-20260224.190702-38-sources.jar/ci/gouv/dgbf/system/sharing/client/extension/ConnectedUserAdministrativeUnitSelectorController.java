package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection d'unité administrative.
 *
 * @author Christian
 *
 */
@SessionScoped
@Named
public class ConnectedUserAdministrativeUnitSelectorController extends AbstractController {

  @Inject
  ResourceClient client;

  /**
   * {@link ConnectedUserSharedResourceSelectorController}.
   */
  @Inject
  @Getter
  ConnectedUserSharedResourceSelectorController selectorController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    selectorController.prepareAdministrativeUnit();
    selectorController.initialize();
  }

  /**
   * {@link ConnectedUserSharedResourceSelectorController#getResourceIdentifier()}.
   *
   * @return Identifiant de {@link ResourceDto}
   */
  public String getResourceIdentifier() {
    return selectorController.getResourceIdentifier();
  }

  /**
   * {@link ConnectedUserSharedResourceSelectorController#getResourceReference()}.
   *
   * @return Référence de {@link ResourceDto}
   */
  public String getResourceReference() {
    return selectorController.getResourceReference();
  }

  /**
   * {@link ConnectedUserSharedResourceSelectorController#getResourceName()}.
   *
   * @return Nom de {@link ResourceDto}
   */
  public String getResourceName() {
    return selectorController.getResourceName();
  }
}
