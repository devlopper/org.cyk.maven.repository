package ci.gouv.dgbf.extension.primefaces.component.input;

import java.math.BigDecimal;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un décimal.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputBigDecimal extends AbstractInputNumber<BigDecimal> {

  public InputBigDecimal() {
    decimalPlaces = "2";
  }
  
}
