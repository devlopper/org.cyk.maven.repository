package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserGroupDto}.
 *
 * @author kimou
 */
@Named
@ViewScoped
public class UserGroupListPage extends AbstractPage {

  @Inject
  @Getter
  UserGroupController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + UserGroupDto.NAME;
    controller.initialize();
  }

  /** Identifiant de navigation. */
  public static final String OUTCOME = "userGroupPage";
}
