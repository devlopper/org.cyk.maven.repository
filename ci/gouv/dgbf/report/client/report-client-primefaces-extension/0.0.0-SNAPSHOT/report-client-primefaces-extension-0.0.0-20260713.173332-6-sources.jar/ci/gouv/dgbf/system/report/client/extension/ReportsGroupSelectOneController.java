package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.report.server.api.ReportsGroupClient;
import ci.gouv.dgbf.system.report.server.api.ReportsGroupDto;
import ci.gouv.dgbf.system.report.server.api.ReportsGroupService.ReportsGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ReportsGroupDto}.
 *
 * @author Desysoft
 *
 */
@Dependent
public class ReportsGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    ReportsGroupDto, ReportsGroupGetManyResponseDto, ReportsGroupClient> {

  @Getter
  @Inject
  ReportsGroupClient client;

  protected ReportsGroupSelectOneController() {
    super(ReportsGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}

