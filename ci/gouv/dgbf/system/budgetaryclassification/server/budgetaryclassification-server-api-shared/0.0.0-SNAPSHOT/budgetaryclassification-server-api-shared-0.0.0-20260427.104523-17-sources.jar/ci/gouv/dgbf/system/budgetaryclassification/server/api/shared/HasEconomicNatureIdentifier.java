package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de la nature economique.
 *
 * @author arnaud
 */
public interface HasEconomicNatureIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la nature economique.
   *
   * @return identifiant de la nature economique
   */
  String getEconomicNatureIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la nature economique.
   *
   * @param identifier identifiant de la nature economique
   */

  void setEconomicNatureIdentifier(String identifier);
  /**
   * Identifiant java de l'identifiant de la nature economique.
   */

  String FIELD_ECONOMIC_NATURE_IDENTIFIER = "economicNatureIdentifier";
}