package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptRelationDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ScriptRelationFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ScriptDto} parent.
   */
  String parentIdentifier;

  /**
   * Identifiant {@link ScriptDto} enfant.
   */
  String childIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptRelationFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ScriptRelationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param filter filtre
   */
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    parentIdentifier = getParentIdentifier(filter);
    childIdentifier = getChildIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setParentIdentifier(filter, parentIdentifier);
    setChildIdentifier(filter, childIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ScriptDto} parent.
   *
   * @param filter filtre
   * @return identifiant {@link ScriptDto} parent
   */
  public static String getParentIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PARENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ScriptDto} parent.
   *
   * @param filter filtre
   * @param identifier identifiant {@link ScriptDto} parent
   */
  public static void setParentIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PARENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ScriptDto} enfant.
   *
   * @param filter filtre
   * @return identifiant {@link ScriptDto} enfant
   */
  public static String getChildIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHILD_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ScriptDto} enfant.
   *
   * @param filter filtre
   * @param identifier identifiant {@link ScriptDto} enfant
   */
  public static void setChildIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_CHILD_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #parentIdentifier}.
   */
  public static final String JSON_PARENT_IDENTIFIER = ScriptRelationDto.JSON_PARENT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #childIdentifier}.
   */
  public static final String JSON_CHILD_IDENTIFIER = ScriptRelationDto.JSON_CHILD_IDENTIFIER;
}
