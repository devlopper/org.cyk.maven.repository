package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.sharing.server.api.VisibilityLevel;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link VisibilityLevel}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class VisibilityLevelManager extends AbstractStatusManager<VisibilityLevel> {

  /**
   * Cette méthode permet d'instancier.
   */
  public VisibilityLevelManager() {
    super(VisibilityLevel.class, VisibilityLevel::getName);
  }

  /**
   * Cette méthode permet d'obtenir le niveau de visibilité ou {@link VisibilityLevel#FULL} s'il est
   * nul.
   *
   * @param visibilityLevel niveau de visibilité
   * @return niveau de visibilité, public si nul
   */
  public VisibilityLevel getOrFull(VisibilityLevel visibilityLevel) {
    return visibilityLevel == null ? VisibilityLevel.FULL : visibilityLevel;
  }
}
