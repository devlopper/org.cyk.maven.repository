package ci.gouv.dgbf.extension.primefaces;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de publication de notification.
 *
 * @author Christian
 *
 */
@Dependent
public class NotificationPublishController {

  @Getter
  @Setter
  boolean enabled = true;

  @Getter
  @Setter
  String channel;

  @Inject
  NotificationPublisher publisher;

  /**
   * Cette méthode permet de publier une notification.
   *
   * @param message message
   */
  public void publish(String message) {
    if (enabled) {
      validateChannel();
      publisher.publish(channel, message);
    }
  }

  protected void validateChannel() {
    if (channel == null) {
      throw new IllegalStateException("La chaine de notification ne doit pas être nulle");
    }
  }
}
