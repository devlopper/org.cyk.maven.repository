package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et
* {@link RemunerableDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T09:54:21+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RemunerableRequestMapperImpl implements RemunerableRequestMapper {

    @Override
    public RemunerableService.RemunerableCreateRequestDto mapCreate(RemunerableDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RemunerableService.RemunerableCreateRequestDto remunerableCreateRequestDto = new RemunerableService.RemunerableCreateRequestDto();

        remunerableCreateRequestDto.setFunctionaryIdentifier( arg0.getFunctionaryIdentifier() );
        remunerableCreateRequestDto.setPayslipTypeIdentifier( arg0.getPayslipTypeIdentifier() );
        remunerableCreateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );
        remunerableCreateRequestDto.setIsEnabled( arg0.getIsEnabled() );

        return remunerableCreateRequestDto;
    }

    @Override
    public RemunerableService.RemunerableUpdateRequestDto mapUpdate(RemunerableDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RemunerableService.RemunerableUpdateRequestDto remunerableUpdateRequestDto = new RemunerableService.RemunerableUpdateRequestDto();

        remunerableUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        remunerableUpdateRequestDto.setFunctionaryIdentifier( arg0.getFunctionaryIdentifier() );
        remunerableUpdateRequestDto.setPayslipTypeIdentifier( arg0.getPayslipTypeIdentifier() );
        remunerableUpdateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );
        remunerableUpdateRequestDto.setIsEnabled( arg0.getIsEnabled() );

        return remunerableUpdateRequestDto;
    }
}
