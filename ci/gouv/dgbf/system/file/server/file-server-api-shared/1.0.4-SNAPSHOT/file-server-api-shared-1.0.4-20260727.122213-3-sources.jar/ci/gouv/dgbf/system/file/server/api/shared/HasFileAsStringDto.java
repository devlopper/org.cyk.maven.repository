package ci.gouv.dgbf.system.file.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de fichier.
 *
 * @author Christian
 */
public interface HasFileAsStringDto extends HasFileAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du fichier.
   */
  String JSON_FILE_AS_STRING = "fichierChaine";
}
