package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class FileIconManager {

  String filesGroupStatusCreated;

  String filesGroupConfirm;
  String filesGroupStatusConfirmed;

  String fileStatusCreated;

  String fileConfirm;
  String fileStatusConfirmed;

  /**
   * Cette méthode permet d'instancier.
   */
  public FileIconManager() {
    filesGroupStatusCreated = "pi pi-pencil";

    filesGroupConfirm = "pi pi-thumbs-up";
    filesGroupStatusConfirmed = filesGroupConfirm;

    fileStatusCreated = "pi pi-pencil";

    fileConfirm = "pi pi-thumbs-up";
    fileStatusConfirmed = fileConfirm;
  }

  /**
   * Cette méthode permet de déterminer l'icône représentant un type de contenu (type MIME), pour
   * l'affichage dans la liste des fichiers.
   *
   * @param contentType type de contenu (ex. {@code image/png})
   * @return icône PrimeIcons correspondante
   */
  public String buildContentTypeIcon(String contentType) {
    if (contentType == null) {
      return "pi pi-file";
    }
    if (contentType.startsWith("image/")) {
      return "pi pi-image";
    }
    if (contentType.startsWith("video/")) {
      return "pi pi-video";
    }
    if (contentType.startsWith("audio/")) {
      return "pi pi-volume-up";
    }
    if ("application/pdf".equals(contentType)) {
      return "pi pi-file-pdf";
    }
    if (contentType.contains("excel") || contentType.contains("spreadsheet")) {
      return "pi pi-file-excel";
    }
    return "pi pi-file";
  }
}
