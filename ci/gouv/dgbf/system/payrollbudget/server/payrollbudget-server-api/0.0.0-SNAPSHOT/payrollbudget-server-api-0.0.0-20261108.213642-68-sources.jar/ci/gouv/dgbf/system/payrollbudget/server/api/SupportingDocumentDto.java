package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Pièce justificative réellement transmise par l'EPN, rattachée à une ligne de son dossier.
 *
 * <p>La pièce ne porte toujours pas le binaire, et c'est délibéré : elle porte l'identifiant du
 * <strong>groupe de fichiers</strong> que le module de gestion de fichiers lui a attribué
 * (TCH_PRB_ARB_22). Les octets vivent là-bas, dédoublonnés par empreinte ; ici ne vit que la
 * référence qui permet de les consulter et de les télécharger.</p>
 *
 * <p>Un groupe, et non un fichier : une même exigence peut être satisfaite par plusieurs pages
 * ou plusieurs scans, et le module raisonne en ensembles. C'est {@code libelle} qui porte le
 * nom que l'EPN a donné à sa pièce — ce qu'il a écrit sur le bordereau, qui n'est pas
 * forcément le nom du fichier déposé ; {@code fichier}, lui, désigne le fichier lui-même.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportingDocumentDto extends AbstractIdentifiableDto {

  /**
   * Dossier auquel la pièce est jointe.
   */
  @JsonbProperty(JSON_DOSSIER_IDENTIFIER)
  private String dossierIdentifier;

  /**
   * Nature exigée que cette pièce vient satisfaire.
   */
  @JsonbProperty(JSON_NATURE_IDENTIFIER)
  private String natureIdentifier;

  /**
   * Libellé de la nature, servi par jointure.
   */
  @JsonbProperty(JSON_NATURE_AS_STRING)
  private String natureAsString;

  /**
   * Ligne d'arbitrage à laquelle la pièce est rattachée. Nulle pour une pièce du dossier entier.
   */
  @JsonbProperty(JSON_MOVEMENT_IDENTIFIER)
  private String movementIdentifier;

  /**
   * Libellé donné à la pièce au moment du dépôt.
   */
  @JsonbProperty(JSON_LABEL)
  private String label;

  /**
   * Référence du document tel que remis — nom de fichier aujourd'hui, référence GED demain.
   */
  @JsonbProperty(JSON_FILE)
  private String file;

  /**
   * Identifiant du groupe de fichiers, chez le module de gestion de fichiers.
   *
   * <p>Nul pour une pièce déclarée sans dépôt : l'écran l'annonce alors comme non consultable
   * plutôt que d'offrir un bouton qui ne montrerait rien.</p>
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPieceJustificative";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "pieceJustificativeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "pièce justificative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "pièces justificatives";

  /**
   * Identifiant json pour {@link #dossierIdentifier}.
   */
  public static final String JSON_DOSSIER_IDENTIFIER =
      BudgetAdministrativeUnitDossierDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #natureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER =
      SupportingDocumentNatureDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #natureAsString}.
   */
  public static final String JSON_NATURE_AS_STRING =
      SupportingDocumentNatureDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #movementIdentifier}.
   */
  public static final String JSON_MOVEMENT_IDENTIFIER =
      ArbitrationMovementDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #label}.
   */
  public static final String JSON_LABEL = "libelle";

  /**
   * Identifiant json pour {@link #file}.
   */
  public static final String JSON_FILE = "fichier";

  /**
   * Identifiant json pour {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "idGroupeFichier";
}
