package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author desysoft
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  /**
   * Administrateur.
   */
  ADMINISTRATOR("ADMINISTRATEUR")

  ;

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;
}
