package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SharingDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = SharingService.PATH)
@Tag(name = "Gestion des partages")
public interface SharingService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "partage";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PARTAGE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface SharingSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ResourceDto}.
     *
     * @return identifiant de {@link ResourceDto}
     */
    String getResourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ResourceDto}.
     *
     * @param resourceIdentifier identifiant de {@link ResourceDto}
     */
    void setResourceIdentifier(String resourceIdentifier);

    /**
     * Cette méthode permet d'obtenir {@link ResourceType}.
     *
     * @return {@link ResourceType}
     */
    ResourceType getResourceType();

    /**
     * Cette méthode permet d'assigner {@link ResourceType}.
     *
     * @param resourceType {@link ResourceType}
     */
    void setResourceType(ResourceType resourceType);

    /**
     * Cette méthode permet d'obtenir {@link Location} de {@link ResourceDto}.
     *
     * @return {@link Location}
     */
    Location getResourceLocation();

    /**
     * Cette méthode permet d'assigner {@link Location} de {@link ResourceDto}.
     *
     * @param resourceLocation {@link Location} de {@link ResourceDto}
     */
    void setResourceLocation(Location resourceLocation);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ReceiverDto}.
     *
     * @return identifiant de {@link ReceiverDto}
     */
    String getReceiverIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ReceiverDto}.
     *
     * @param resourceIdentifier identifiant de {@link ReceiverDto}
     */
    void setReceiverIdentifier(String resourceIdentifier);

    /**
     * Cette méthode permet d'obtenir {@link ReceiverType}.
     *
     * @return {@link ReceiverType}
     */
    ReceiverType getReceiverType();

    /**
     * Cette méthode permet d'assigner {@link ReceiverType}.
     *
     * @param resourceType {@link ReceiverType}
     */
    void setReceiverType(ReceiverType resourceType);

    /**
     * Cette méthode permet d'obtenir {@link Location} de {@link ReceiverDto}.
     *
     * @return {@link Location}
     */
    Location getReceiverLocation();

    /**
     * Cette méthode permet d'assigner {@link Location} de {@link ReceiverDto}.
     *
     * @param receiverLocation {@link Location} de {@link ReceiverDto}
     */
    void setReceiverLocation(Location receiverLocation);

    /**
     * Cette méthode permet d'obtenir vrai ou faux si le partage de la ressource est refusée.
     *
     * @return vrai ou faux si le partage de la ressource est refusée
     */
    Boolean getRefused();

    /**
     * Cette méthode permet d'assigner vrai ou faux si le partage de la ressource est refusée.
     *
     * @param refused vrai ou faux si le partage de la ressource est refusée
     */
    void setRefused(Boolean refused);

    /**
     * Cette méthode permet d'obtenir la date de début.
     *
     * @return date de début
     */
    LocalDateTime getFromDate();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param fromDate date de début
     */
    void setFromDate(LocalDateTime fromDate);

    /**
     * Cette méthode permet d'obtenir la date de fin.
     *
     * @return date de fin
     */
    LocalDateTime getToDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param fromDate date de fin
     */
    void setToDate(LocalDateTime fromDate);

    /**
     * Identifiant json champ identifiant de {@link ResourceDto}.
     */
    String JSON_RESOURCE_IDENTIFIER = SharingDto.JSON_RESOURCE_IDENTIFIER;

    /**
     * Identifiant json champ {@link ResourceType}.
     */
    String JSON_RESOURCE_TYPE = SharingDto.JSON_RESOURCE_TYPE;

    /**
     * Identifiant json champ {@link Location} de {@link ResourceDto}.
     */
    String JSON_RESOURCE_LOCATION = SharingDto.JSON_RESOURCE_LOCATION;

    /**
     * Identifiant json champ identifiant de {@link ReceiverDto}.
     */
    String JSON_RECEIVER_IDENTIFIER = SharingDto.JSON_RECEIVER_IDENTIFIER;

    /**
     * Identifiant json champ {@link ReceiverType}.
     */
    String JSON_RECEIVER_TYPE = SharingDto.JSON_RECEIVER_TYPE;

    /**
     * Identifiant json champ {@link Location} de {@link ReceiverDto}.
     */
    String JSON_RECEIVER_LOCATION = SharingDto.JSON_RECEIVER_LOCATION;

    /**
     * Identifiant json champ vrai ou faux si le partage de la ressource est refusée.
     */
    String JSON_REFUSED = SharingDto.JSON_REFUSED;

    /**
     * Identifiant json champ date de début.
     */
    String JSON_FROM_DATE = SharingDto.JSON_FROM_DATE;

    /**
     * Identifiant json champ date de fin.
     */
    String JSON_TO_DATE = SharingDto.JSON_TO_DATE;
  }

  /**
   * Cette méthode permet de créer {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un partage",
      description = "Ce service permet de créer un partage")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SharingCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class SharingCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SharingSaveRequestDto {

    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;

    @JsonbProperty(JSON_RESOURCE_TYPE)
    private ResourceType resourceType;

    @JsonbProperty(JSON_RESOURCE_LOCATION)
    private Location resourceLocation;

    @JsonbProperty(JSON_RECEIVER_IDENTIFIER)
    private String receiverIdentifier;

    @JsonbProperty(JSON_RECEIVER_TYPE)
    private ReceiverType receiverType;

    @JsonbProperty(JSON_RECEIVER_LOCATION)
    private Location receiverLocation;

    @JsonbProperty(JSON_REFUSED)
    private Boolean refused;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PARTAGE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des partages")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SharingGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class SharingGetManyResponseDto extends AbstractGetByPageResponseDto<SharingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SharingDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PARTAGE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un partage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SharingDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PARTAGE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un partage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SharingDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PARTAGE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un partage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SharingUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class SharingUpdateRequestDto extends ByIdentifierRequestDto implements SharingSaveRequestDto {
    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;

    @JsonbProperty(JSON_RESOURCE_TYPE)
    private ResourceType resourceType;

    @JsonbProperty(JSON_RESOURCE_LOCATION)
    private Location resourceLocation;

    @JsonbProperty(JSON_RECEIVER_IDENTIFIER)
    private String receiverIdentifier;

    @JsonbProperty(JSON_RECEIVER_TYPE)
    private ReceiverType receiverType;

    @JsonbProperty(JSON_RECEIVER_LOCATION)
    private Location receiverLocation;

    @JsonbProperty(JSON_REFUSED)
    private Boolean refused;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PARTAGE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SharingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un partage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
