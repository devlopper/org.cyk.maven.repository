package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'exercice.
   *
   * @return représentation en chaine de caractères de l'exercice
   */
  String getExerciseAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'exercice.
   *
   * @param asString représentation en chaine de caractères de l'exercice
   */
  void setExerciseAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'exercice.
   */
  String FIELD_EXERCISE_AS_STRING = "exerciseAsString";
}
