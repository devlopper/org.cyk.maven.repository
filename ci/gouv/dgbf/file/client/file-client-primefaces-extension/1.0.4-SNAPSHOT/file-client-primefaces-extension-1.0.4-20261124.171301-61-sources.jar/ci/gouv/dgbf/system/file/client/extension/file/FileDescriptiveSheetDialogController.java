package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.ClientRuntimeException;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.PhysicalItemDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le contrôleur du dialogue d'affichage, à l'écran et en HTML, de la fiche
 * descriptive d'un Fichier physique (RG_FILE_FIC_18, spec-api § 9.6).
 *
 * @author Christian
 *
 */
@Dependent
public class FileDescriptiveSheetDialogController extends AbstractController {

  @Inject
  FileClient client;

  @Getter
  @Setter
  String widgetVar;

  @Getter
  @Setter
  String title;

  @Getter
  @Setter
  FileDto file;

  @Getter
  @Setter
  PhysicalItemDto physicalItem;

  /**
   * Mention obligatoire affichée sur la fiche descriptive (RG_FILE_FIC_18).
   */
  public static final String MANDATORY_NOTICE =
      ci.gouv.dgbf.system.file.server.api.FileService.DESCRIPTIVE_SHEET_MANDATORY_NOTICE;

  /**
   * Cette méthode permet de construire une instance.
   */
  public FileDescriptiveSheetDialogController() {
    widgetVar = "fileDescriptiveSheetDialog";
    title = "Fiche descriptive";
  }

  /**
   * Cette méthode permet d'ouvrir la fiche descriptive d'un fichier.
   *
   * @param identifier identifiant du fichier
   */
  public void open(String identifier) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L'identifiant du fichier est obligatoire");
    }
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME, FileDto.JSON_MODULE_IDENTIFIER,
        FileDto.JSON_MEDIUM_NATURE, FileDto.JSON_MEDIUM_NATURE_AS_STRING,
        FileDto.JSON_ORIGINAL_MEDIUM, FileDto.JSON_ORIGINAL_MEDIUM_AS_STRING,
        FileDto.JSON_CONTENT_FORM, FileDto.JSON_CONTENT_FORM_AS_STRING,
        FileDto.JSON_DESCRIPTION, FileDto.JSON_PRODUCTION_DATE_AS_STRING,
        HasStatusDto.JSON_STATUS, HasStatusAsStringDto.JSON_STATUS_AS_STRING);

    file = client.getByIdentifier(identifier, projection, userIdentifier, null);
    physicalItem = readPhysicalItem(identifier);
    showDialog();
  }

  /**
   * Cette méthode lit l'Exemplaire physique. Seule une absence (404) signifie « pas
   * d'Exemplaire » ; toute autre erreur remonte, pour ne jamais afficher la fiche d'un Fichier
   * physique privée de son Exemplaire à cause d'une panne.
   *
   * @param identifier identifiant du fichier
   * @return Exemplaire physique, {@code null} si le fichier n'en a pas
   */
  PhysicalItemDto readPhysicalItem(String identifier) {
    try {
      return client.getPhysicalItem(identifier, userIdentifier, null);
    } catch (ClientRuntimeException exception) {
      if (exception.getResponseCode() == NOT_FOUND) {
        return null;
      }
      throw exception;
    }
  }

  static final int NOT_FOUND = 404;

  /**
   * Affiche le dialogue PrimeFaces si l'instance PrimeFaces est disponible.
   */
  void showDialog() {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      // Par le widgetVar : l'identifiant client du dialogue dépend du formulaire englobant.
      primeFaces.ajax().update("@widgetVar(" + widgetVar + ")");
      primeFaces.executeScript("PF('" + widgetVar + "').show();");
    }
  }

  /**
   * Obtient l'instance courante de PrimeFaces.
   *
   * @return instance {@link PrimeFaces}
   */
  PrimeFaces getPrimeFaces() {
    return PrimeFaces.current();
  }

  /**
   * Indique si un exemplaire physique est présent pour le fichier courant.
   *
   * @return {@code true} si l'exemplaire physique est présent
   */
  public boolean isPhysicalItemPresent() {
    return physicalItem != null;
  }

  /**
   * Indique si la localisation est renseignée et non masquée (RG_FILE_FIC_14).
   *
   * @return {@code true} si la localisation est visible
   */
  public boolean hasLocation() {
    return physicalItem != null && !Core.isStringBlank(physicalItem.getLocation());
  }

  /**
   * Mention obligatoire pour l'affichage dans les vues XHTML.
   *
   * @return texte de la mention
   */
  public String getMandatoryNotice() {
    return MANDATORY_NOTICE;
  }
}
