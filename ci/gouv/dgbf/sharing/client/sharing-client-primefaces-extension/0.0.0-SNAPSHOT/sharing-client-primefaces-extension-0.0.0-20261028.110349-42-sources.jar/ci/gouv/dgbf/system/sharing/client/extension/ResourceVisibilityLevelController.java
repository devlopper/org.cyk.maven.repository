package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelRequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.VisibilityLevel;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceVisibilityLevelController extends AbstractController {

  @Inject
  ResourceVisibilityLevelClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ResourceVisibilityLevelFilterController filterController;

  @Inject
  @Getter
  ResourceSelectOneController resourceSelectOneController;

  @Inject
  @Getter
  VisibilityLevelSelectOneController visibilityLevelSelectOneController;

  @Inject
  ResourceVisibilityLevelRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ResourceVisibilityLevelDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ResourceVisibilityLevelDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ResourceVisibilityLevelService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ResourceVisibilityLevelDto.JSON_RESOURCE_AS_STRING,
        ResourceVisibilityLevelDto.JSON_VISIBILITY_LEVEL,
        ResourceVisibilityLevelDto.JSON_VISIBILITY_LEVEL_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      ResourceVisibilityLevelCreateRequestDto request =
          requestMapper.mapCreate((ResourceVisibilityLevelDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            ResourceVisibilityLevelDto.JSON_VISIBILITY_LEVEL));

    listController.getUpdateController().setFunction(entity -> {
      ResourceVisibilityLevelUpdateRequestDto request =
          requestMapper.mapUpdate((ResourceVisibilityLevelDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    resourceSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(ResourceVisibilityLevelDto.class)
            .setResourceIdentifier(identifier));

    visibilityLevelSelectOneController.getSelectOneMenu()
        .addValueConsumer(levelName -> listController
            .getCreateControllerOrUpdateControllerEntityAs(ResourceVisibilityLevelDto.class)
            .setVisibilityLevel(
                levelName == null ? null : Core.getEnumerationValueByName(
                    VisibilityLevel.class, levelName)));
  }
}
