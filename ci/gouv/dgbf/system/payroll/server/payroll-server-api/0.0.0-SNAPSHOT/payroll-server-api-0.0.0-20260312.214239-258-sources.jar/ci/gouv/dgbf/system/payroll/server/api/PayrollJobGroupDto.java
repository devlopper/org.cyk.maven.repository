package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe d'emplois de paie.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollJobGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant {@link PayrollComponentCategory}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant de la grille indiciaire.
   */
  @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
  private String payScaleIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #payScaleIdentifier}.
   */
  @JsonbProperty(JSON_PAY_SCALE_AS_STRING)
  private String payScaleAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeEmploiPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeEmploiPaieChaine";

  /**
   * Identifiant json de {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = "idTypeEmploiPaie";

  /**
   * Identifiant json de {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = "typeEmploiPaieChaine";

  /**
   * Identifiant json de {@link #payScaleIdentifier}.
   */
  public static final String JSON_PAY_SCALE_IDENTIFIER = "idGrilleIndiciaire";

  /**
   * Identifiant json de {@link #payScaleAsString}.
   */
  public static final String JSON_PAY_SCALE_AS_STRING = "grilleIndiciaireChaine";



  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe d'emplois de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes d'emplois de paie";
}
