package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.

    @author Christian
               """)
public interface SubAdministrativeUnitRequestMapper extends RequestMapper<SubAdministrativeUnitDto,
    SubAdministrativeUnitCreateRequestDto, SubAdministrativeUnitUpdateRequestDto> {

}
