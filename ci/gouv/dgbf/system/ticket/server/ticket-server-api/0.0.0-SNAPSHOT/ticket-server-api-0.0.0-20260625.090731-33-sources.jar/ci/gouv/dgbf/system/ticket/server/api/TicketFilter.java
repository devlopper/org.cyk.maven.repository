package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDomainIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TicketFilter extends AbstractIdentifiableFilter
    implements FilterHasStatusCode, FilterHasStatusCodes, FilterHasDomainIdentifier {

  private String statusCode;
  private Set<String> statusCodes;
  private String domainIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TicketFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TicketFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
    updateDomainIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
    updateFilterDomainIdentifier(filter);
  }
}
