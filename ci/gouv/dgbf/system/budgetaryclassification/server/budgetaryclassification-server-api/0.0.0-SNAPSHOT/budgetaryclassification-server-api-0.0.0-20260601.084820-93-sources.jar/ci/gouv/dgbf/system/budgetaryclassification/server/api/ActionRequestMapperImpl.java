package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ActionDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-01T08:48:44+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ActionRequestMapperImpl implements ActionRequestMapper {

    @Override
    public ActionService.ActionCreateRequestDto mapCreate(ActionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActionService.ActionCreateRequestDto actionCreateRequestDto = new ActionService.ActionCreateRequestDto();

        actionCreateRequestDto.setCode( arg0.getCode() );
        actionCreateRequestDto.setName( arg0.getName() );
        actionCreateRequestDto.setBudgetSpecializationUnitIdentifier( arg0.getBudgetSpecializationUnitIdentifier() );

        return actionCreateRequestDto;
    }

    @Override
    public ActionService.ActionUpdateRequestDto mapUpdate(ActionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActionService.ActionUpdateRequestDto actionUpdateRequestDto = new ActionService.ActionUpdateRequestDto();

        actionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        actionUpdateRequestDto.setCode( arg0.getCode() );
        actionUpdateRequestDto.setName( arg0.getName() );
        actionUpdateRequestDto.setBudgetSpecializationUnitIdentifier( arg0.getBudgetSpecializationUnitIdentifier() );

        return actionUpdateRequestDto;
    }
}
