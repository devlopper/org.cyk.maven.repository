package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileGroupFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link FilesGroupDtos}.
   */
  String groupIdentifier;

  /**
   * Identifiants {@link FilesGroupDtos}.
   */
  Set<String> groupsIdentifiers;

  @Override
  protected void doInitialize(FilterDto filter) {
    groupIdentifier = getGroupIdentifier(filter);
    groupsIdentifiers = getGroupsIdentifiers(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setGroupsIdentifiers(filter, groupsIdentifiers);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link FilesGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @param groupsIdentifiers identifiants {@link FilesGroupDto}
   */
  public static void setGroupsIdentifiers(FilterDto filter, Set<String> groupsIdentifiers) {
    set(filter, JSON_GROUPS_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet((LinkedHashSet<String>) Core
            .getOrNullifyIfCollectionEmpty(Core.getLinkedHashSet(groupsIdentifiers))));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @return identifiants {@link FilesGroupDto}
   */
  public static Set<String> getGroupsIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_GROUPS_IDENTIFIERS));
  }

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = FileDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant JSON {@link #groupsIdentifiers}.
   */
  public static final String JSON_GROUPS_IDENTIFIERS = "idsGroupes";
}
