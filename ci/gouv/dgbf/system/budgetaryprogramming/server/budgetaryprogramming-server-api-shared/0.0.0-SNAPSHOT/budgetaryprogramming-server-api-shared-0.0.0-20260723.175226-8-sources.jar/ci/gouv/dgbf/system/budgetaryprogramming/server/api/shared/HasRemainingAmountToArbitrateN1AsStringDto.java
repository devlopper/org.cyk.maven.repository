package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateN1AsStringDto
    extends HasRemainingAmountToArbitrateN1AsString {

  /**
   * Identifiant json du montant restant à arbitrer pour l'année N+1,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_ARBITRATE_N1_AS_STRING =
      "montantResteAArbitrerN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName