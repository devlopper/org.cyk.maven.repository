package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link UserGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UserGroupFilterController extends AbstractFilterController<UserGroupFilter> {

  @Inject
  @Getter
  UsersGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  UserCapacitySelectOneController capacitySelectOneController;

  @Inject
  @Getter
  SelectBooleanController isResponsibleSelectBooleanController;

  /**
   * Cette méthode permet de construire.
   */
  public UserGroupFilterController() {
    super(UserGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    groupSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> filter.setGroupIdentifier(identifier));
    capacitySelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> filter.setCapacityIdentifier(identifier));

    isResponsibleSelectBooleanController.setOutputLableValue("Responsable");
    isResponsibleSelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices(true)
        .addValueConsumer(value -> filter.setIsResponsible(value));
  }
}
