package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une ligne d'un fichier FUR conservée dans un Lot d'Import, en lecture
 * seule : ses colonnes d'identification, sans donnée personnelle (nom, naissance, adresse), la
 * réclamation qu'elle a produite ou le motif pour lequel elle n'en a produit aucune.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimImportBatchLineDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant du Lot d'Import.
   */
  @JsonbProperty(JSON_IMPORT_BATCH_IDENTIFIER)
  private String importBatchIdentifier;

  /**
   * Version de la ligne : {@link #VERSION_ORIGIN} ou {@link #VERSION_FINAL}.
   */
  @JsonbProperty(JSON_VERSION)
  private String version;

  /**
   * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
   */
  @JsonbProperty(JSON_LINE_NUMBER)
  private Integer lineNumber;

  /**
   * Code pièce.
   */
  @JsonbProperty(JSON_PIECE)
  private String piece;

  /**
   * Code document.
   */
  @JsonbProperty(JSON_DOCUMENT)
  private String document;

  /**
   * Matricule de l'agent.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Code organisme.
   */
  @JsonbProperty(JSON_ORGANISM)
  private String organism;

  /**
   * Code échelle-corps.
   */
  @JsonbProperty(JSON_SCALE_CORPS)
  private String scaleCorps;

  /**
   * Code grade.
   */
  @JsonbProperty(JSON_GRADE)
  private String grade;

  /**
   * Code indice.
   */
  @JsonbProperty(JSON_INDEX)
  private String index;

  /**
   * Date d'effet de la situation administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_EFFECTIVE_DATE)
  private String administrativeEffectiveDate;

  /**
   * Code emploi.
   */
  @JsonbProperty(JSON_JOB)
  private String job;

  /**
   * Code du lieu d'affectation.
   */
  @JsonbProperty(JSON_LOCALITY)
  private String locality;

  /**
   * Code position solde.
   */
  @JsonbProperty(JSON_SALARY_POSITION)
  private String salaryPosition;

  /**
   * Identifiant de la réclamation générée à partir de la ligne, {@code null} si aucune.
   */
  @JsonbProperty(JSON_CLAIM_IDENTIFIER)
  private String claimIdentifier;

  /**
   * Motif pour lequel la ligne n'a produit aucune réclamation.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Motif de la dérogation qui a forcé la génération de la réclamation.
   */
  @JsonbProperty(JSON_DEROGATION_MOTIVE)
  private String derogationMotive;

  /**
   * Identifiant json {@link #importBatchIdentifier}.
   */
  public static final String JSON_IMPORT_BATCH_IDENTIFIER = "idLotImport";

  /**
   * Identifiant json {@link #version}.
   */
  public static final String JSON_VERSION = "version";

  /**
   * Identifiant json {@link #lineNumber}.
   */
  public static final String JSON_LINE_NUMBER = "numeroLigne";

  /**
   * Identifiant json {@link #piece}.
   */
  public static final String JSON_PIECE = "codePiece";

  /**
   * Identifiant json {@link #document}.
   */
  public static final String JSON_DOCUMENT = "codeDocument";

  /**
   * Identifiant json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";

  /**
   * Identifiant json {@link #organism}.
   */
  public static final String JSON_ORGANISM = "codeOrganisme";

  /**
   * Identifiant json {@link #scaleCorps}.
   */
  public static final String JSON_SCALE_CORPS = "codeEchelleCorps";

  /**
   * Identifiant json {@link #grade}.
   */
  public static final String JSON_GRADE = "codeGrade";

  /**
   * Identifiant json {@link #index}.
   */
  public static final String JSON_INDEX = "codeIndice";

  /**
   * Identifiant json {@link #administrativeEffectiveDate}.
   */
  public static final String JSON_ADMINISTRATIVE_EFFECTIVE_DATE = "dateEffetSituationAdm";

  /**
   * Identifiant json {@link #job}.
   */
  public static final String JSON_JOB = "codeEmploi";

  /**
   * Identifiant json {@link #locality}.
   */
  public static final String JSON_LOCALITY = "codeLieuAffectation";

  /**
   * Identifiant json {@link #salaryPosition}.
   */
  public static final String JSON_SALARY_POSITION = "codePositionSolde";

  /**
   * Identifiant json {@link #claimIdentifier}.
   */
  public static final String JSON_CLAIM_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json {@link #derogationMotive}.
   */
  public static final String JSON_DEROGATION_MOTIVE = "motifDerogation";

  /**
   * Version d'origine : la ligne telle que reçue.
   */
  public static final String VERSION_ORIGIN = "ORIGINE";

  /**
   * Version finale : la ligne exploitable, pièces 1090 et 1091 fusionnées.
   */
  public static final String VERSION_FINAL = "FINALE";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ligne de lot d'import";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "lignes de lot d'import";
}
