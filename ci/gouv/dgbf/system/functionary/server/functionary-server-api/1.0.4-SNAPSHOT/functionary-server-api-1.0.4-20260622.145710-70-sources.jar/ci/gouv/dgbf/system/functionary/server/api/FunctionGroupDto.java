package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de fonctions.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;
  
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeFonction";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeFonctionChaine";

  /**
   * Identifiant json de {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = 
      FunctionGroupTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = 
      FunctionGroupTypeDto.JSON_THIS_AS_STRING;

  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe fonction";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes fonction";
}
