package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ActivityNatureService.ActivityNatureCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ActivityNatureService.ActivityNatureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ActivityDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ActivityNatureDto}.

    @author Christian
               """)
public interface ActivityNatureRequestMapper extends RequestMapper<ActivityNatureDto,
    ActivityNatureCreateRequestDto, ActivityNatureUpdateRequestDto> {

}
