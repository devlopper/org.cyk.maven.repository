package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une page.
 *
 * @author Christian
 *
 */
@Getter
public abstract class AbstractPage extends AbstractController {

  protected String title;
  
  protected String contentTitle;
  
  @Setter
  protected boolean isRenderedAsDialog;
  
  protected ContentLoader contentLoader;
  
  /**
   * Cette méthode permet de préparer la page.
   */
  public void prepare() {
    prepareContent();
  }
  
  protected void prepareContent() {
    
  }
}
