package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupTypeService.JobGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupTypeService.JobGroupTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link JobGroupTypeDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link JobGroupTypeDto}.

    @author Arnaud
               """)
public interface JobGroupTypeRequestMapper extends
    RequestMapper<JobGroupTypeDto, JobGroupTypeCreateRequestDto, JobGroupTypeUpdateRequestDto> {

}
