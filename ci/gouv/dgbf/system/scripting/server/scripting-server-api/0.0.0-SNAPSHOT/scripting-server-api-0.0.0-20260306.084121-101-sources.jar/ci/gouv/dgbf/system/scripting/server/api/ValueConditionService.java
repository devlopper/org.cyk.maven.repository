package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ComparisonOperator;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasBooleanValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasComparisonOperatorDto;
import ci.gouv.dgbf.extension.core.segregation.HasConditionalValueIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueMapKeyDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesSeparatorDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueConditionDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ValueConditionService.PATH)
@Tag(name = "Gestion des conditions de valeur")
public interface ValueConditionService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "conditions-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueConditionSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant de {@link ConditionalValueDto}.
     *
     * @return identifiant de {@link ConditionalValueDto}
     */
    String getConditionalValueIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant de {@link ConditionalValueDto}.
     *
     * @param conditionalValueIdentifier identifiant de {@link ConditionalValueDto}
     */
    void setConditionalValueIdentifier(String conditionalValueIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant de sélecteur de valeur.
     *
     * @return identifiant de sélecteur de valeur
     */
    String getValueSelectorIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant de sélecteur de valeur.
     *
     * @param valueSelectorIdentifier identifiant de sélecteur de valeur
     */
    void setValueSelectorIdentifier(String valueSelectorIdentifier);

    /**
     * Cette méthode permet d'obtenir la clé de map pour récupération de valeur.
     *
     * @return clé de map
     */
    String getValueMapKey();

    /**
     * Cette méthode permet d'assigner la clé de map pour récupération de valeur.
     *
     * @param valueMapKey clé de map pour récupération de valeur
     */
    void setValueMapKey(String valueMapKey);

    /**
     * Cette méthode permet d'obtenir {@link ComparisonOperator}.
     *
     * @return {@link ComparisonOperator}
     */
    ComparisonOperator getComparisonOperator();

    /**
     * Cette méthode permet d'assigner {@link ComparisonOperator}.
     *
     * @param comparisonOperator {@link ComparisonOperator}
     */
    void setComparisonOperator(ComparisonOperator comparisonOperator);

    /**
     * Cette méthode permet d'obtenir le séparateur de valeurs.
     *
     * @return le séparateur de valeurs
     */
    String getValuesSeparator();

    /**
     * Cette méthode permet d'assigner le séparateur de valeurs.
     *
     * @param valuesSeparator le séparateur de valeurs
     */
    void setValuesSeparator(String valuesSeparator);

    /**
     * Cette méthode permet d'obtenir valeur.
     *
     * @return valeur
     */
    String getValue();

    /**
     * Cette méthode permet d'assigner valeur.
     *
     * @param value valeur
     */
    void setValue(String value);

    /**
     * Cette méthode permet d'obtenir {@link ValueType}.
     *
     * @return {@link ValueType}
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner {@link ValueType}.
     *
     * @param valueType {@link ValueType}
     */
    void setValueType(ValueType valueType);

    /**
     * {@link HasValueSelectorIdentifierDto#JSON_VALUE_SELECTOR_IDENTIFIER}.
     */
    String JSON_VALUE_SELECTOR_IDENTIFIER =
        HasValueSelectorIdentifierDto.JSON_VALUE_SELECTOR_IDENTIFIER;

    /**
     * {@link HasValueMapKeyDto#JSON_VALUE_MAP_KEY}.
     */
    String JSON_VALUE_MAP_KEY = HasValueMapKeyDto.JSON_VALUE_MAP_KEY;

    /**
     * {@link HasConditionalValueIdentifierDto#JSON_CONDITIONAL_VALUE_IDENTIFIER}.
     */
    String JSON_CONDITIONAL_VALUE_IDENTIFIER =
        HasConditionalValueIdentifierDto.JSON_CONDITIONAL_VALUE_IDENTIFIER;

    /**
     * {@link HasComparisonOperatorDto#JSON_COMPARISON_OPERATOR}.
     */
    String JSON_COMPARISON_OPERATOR = HasComparisonOperatorDto.JSON_COMPARISON_OPERATOR;

    /**
     * {@link HasValueDto#JSON_VALUE}.
     */
    String JSON_VALUE = HasValueDto.JSON_VALUE;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;

    /**
     * {@link HasValuesSeparatorDto#JSON_VALUES_SEPARATOR}.
     */
    String JSON_VALUES_SEPARATOR = HasValuesSeparatorDto.JSON_VALUES_SEPARATOR;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CONDITION_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueConditionCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueConditionCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ValueConditionSaveRequestDto {

    @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
    private String valueSelectorIdentifier;

    @JsonbProperty(JSON_VALUE_MAP_KEY)
    private String valueMapKey;

    @JsonbProperty(JSON_CONDITIONAL_VALUE_IDENTIFIER)
    private String conditionalValueIdentifier;

    @JsonbProperty(JSON_COMPARISON_OPERATOR)
    private ComparisonOperator comparisonOperator;

    @JsonbProperty(JSON_VALUES_SEPARATOR)
    private String valuesSeparator;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONDITION_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueConditionGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueConditionGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueConditionDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueConditionDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CONDITION_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueConditionDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONDITION_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueConditionDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CONDITION_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueConditionUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueConditionUpdateRequestDto extends ByIdentifierRequestDto
      implements ValueConditionSaveRequestDto {

    @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
    private String valueSelectorIdentifier;

    @JsonbProperty(JSON_VALUE_MAP_KEY)
    private String valueMapKey;

    @JsonbProperty(JSON_CONDITIONAL_VALUE_IDENTIFIER)
    private String conditionalValueIdentifier;

    @JsonbProperty(JSON_COMPARISON_OPERATOR)
    private ComparisonOperator comparisonOperator;

    @JsonbProperty(JSON_VALUES_SEPARATOR)
    private String valuesSeparator;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de vérification.
   */
  String VERIFY_IDENTIFIER = "VERIFICATION_CONDITION_VALEUR";

  /**
   * Chemin du service de vérification.
   */
  String VERIFY_PATH = "verification";

  /**
   * Cette méthode permet de vérifier.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VERIFY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = VERIFY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueConditionVerifyResponseDto.class))})
  Response verify(ValueConditionVerifyRequestDto request);

  /**
   * Cette classe représente la requête de vérification.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueConditionVerifyRequestDto extends ByIdentifierRequestDto
      implements HasValuesMapDto<String, Object> {

    /**
     * Valeur de l'attribut de filtre du sélecteur.
     */
    @JsonbProperty(JSON_VALUE_SELECTOR_FILTER_ATTRIBUTE_VALUE)
    private String valueSelectorFilterAttributeValue;

    /**
     * Dictionnaire de valeurs pour la récupération par clé. Ce dictionnaire contient les paires
     * clé-valeur utilisées pour récupérer la valeur à comparer selon la clé configurée dans la
     * condition.
     */
    @JsonbProperty(JSON_VALUES_MAP)
    private Map<String, Object> valuesMap;

    /**
     * Identifiant json {@link #valueSelectorFilterAttributeValue}.
     */
    public static final String JSON_VALUE_SELECTOR_FILTER_ATTRIBUTE_VALUE =
        "valeurAttributFiltreSelecteur";
  }

  /**
   * Cette classe représente la réponse de vérification.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueConditionVerifyResponseDto extends IdentifiableResponseDto
      implements HasBooleanValueDto {

    @JsonbProperty(JSON_VALUE)
    private Boolean value;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONDITION_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueConditionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
