package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollJobGroupTypeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollJobGroupTypeDto}.

    @author Christian
               """)
public interface PayrollJobGroupTypeRequestMapper extends RequestMapper<PayrollJobGroupTypeDto,
    PayrollJobGroupTypeCreateRequestDto, PayrollJobGroupTypeUpdateRequestDto> {

}
