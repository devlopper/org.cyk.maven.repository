package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.AbstractLazyDataModel;
import ci.gouv.dgbf.extension.primefaces.FilterDtoGetter;
import ci.gouv.dgbf.extension.primefaces.ProjectionDtoGetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente de contrôleur de lecture.
 *
 * @author Christian
 *
 */
@Dependent
public class ReadController extends AbstractController {

  @Getter
  @Setter
  Object client;

  @Getter
  @Setter
  AbstractLazyDataModel<?, ?> model;

  @Getter
  @Setter
  boolean selectable;
  
  @Getter
  @Setter
  Object filter;

  @Getter
  @Setter
  Supplier<Object> filterSupplier;

  @Inject
  FilterDtoGetter filterDtoGetter;

  @Getter
  @Setter
  Object projection;

  @Getter
  @Setter
  Supplier<Object> projectionSupplier;

  @Inject
  ProjectionDtoGetter projectionDtoGetter;

  Map<String, Object> identifiersMap;

  Map<String, Object> identifiersMap() {
    if (identifiersMap == null) {
      identifiersMap = new HashMap<>();
    }
    return identifiersMap;
  }

  /**
   * Cette méthode permet d'initialiser le modèle.
   *
   * @param <T> type du dto
   * @param <R> type de la réponse
   * @param dtoClass classe du dto
   * @param responseClass classe de la réponse
   */
  public <T, R> void initializeModel(Class<T> dtoClass, Class<R> responseClass) {
    model = new AbstractLazyDataModel<T, R>(name) {
      @Override
      protected R serve(PageDto page) {
        return ReadController.this.serve(dtoClass, responseClass, page);
      }
    };
    initializeModelSelectable();
  }

  void initializeModelSelectable() {
    if (selectable) {
      model.setSelectable(selectable);
      model.setGetRowKeyFunction(getIdentifierByObjectFunction());
      model.setGetRowDataFunction(getObjectByIdentifierFunction());
    }
  }
  
  Function<Object, String> getIdentifierByObjectFunction() {
    return object -> {
      String identifier = Core.getIdentifier(object);
      identifiersMap().put(identifier, object);
      return identifier;
    };
  }

  Function<String, Object> getObjectByIdentifierFunction() {
    return identifier -> identifiersMap().remove(identifier);
  }

  @SuppressWarnings("unchecked")
  <T, R> R serve(Class<T> dtoClass, Class<R> responseClass, PageDto page) {
    ProjectionDto projectionDto = getProjectionDto();
    FilterDto filterDto = filterDtoGetter.get(filter, filterSupplier);
    if (client instanceof GetMany<?> c) {
      return (R) c.getMany(projectionDto, filterDto, page, userIdentifier, null);
    }
    Logger.getLogger(getClass().getName()).log(Level.SEVERE,
        "Obtention de {0} en {1} n''a pas été implémentée.",
        new Object[] {dtoClass, responseClass});
    throw new IllegalStateException("L'obtention de données n'a pas été implémentée.");
  }

  ProjectionDto getProjectionDto() {
    return projectionDtoGetter.get(projection, projectionSupplier);
  }

  public boolean hasProjectionName(String name) {
    ProjectionDto projectionDto = getProjectionDto();
    return ProjectionDto.hasName(projectionDto, name);
  }
}
