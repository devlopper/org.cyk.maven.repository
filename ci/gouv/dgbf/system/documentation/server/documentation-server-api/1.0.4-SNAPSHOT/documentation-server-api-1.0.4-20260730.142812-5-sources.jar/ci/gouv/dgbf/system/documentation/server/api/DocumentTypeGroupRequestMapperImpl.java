package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentTypeGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T14:28:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentTypeGroupRequestMapperImpl implements DocumentTypeGroupRequestMapper {

    @Override
    public DocumentTypeGroupService.DocumentTypeGroupCreateRequestDto mapCreate(DocumentTypeGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeGroupService.DocumentTypeGroupCreateRequestDto documentTypeGroupCreateRequestDto = new DocumentTypeGroupService.DocumentTypeGroupCreateRequestDto();

        documentTypeGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentTypeGroupCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        documentTypeGroupCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );

        return documentTypeGroupCreateRequestDto;
    }

    @Override
    public DocumentTypeGroupService.DocumentTypeGroupUpdateRequestDto mapUpdate(DocumentTypeGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeGroupService.DocumentTypeGroupUpdateRequestDto documentTypeGroupUpdateRequestDto = new DocumentTypeGroupService.DocumentTypeGroupUpdateRequestDto();

        documentTypeGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentTypeGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentTypeGroupUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        documentTypeGroupUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );

        return documentTypeGroupUpdateRequestDto;
    }
}
