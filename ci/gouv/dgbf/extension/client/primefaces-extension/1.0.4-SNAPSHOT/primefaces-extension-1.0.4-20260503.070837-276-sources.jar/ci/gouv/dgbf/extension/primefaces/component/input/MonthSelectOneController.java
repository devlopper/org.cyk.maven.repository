package ci.gouv.dgbf.extension.primefaces.component.input;

import jakarta.enterprise.context.Dependent;
import java.time.Month;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * Cette classe représente le contrôleur de sélection de {@link BloodGroup}.
 *
 * @author Christian
 *
 */
@Dependent
public class MonthSelectOneController extends AbstractSelectOneEnumerationController<Month> {

  protected MonthSelectOneController() {
    super(Month.values());
    outputLableValue = "Mois";
  }

  @Override
  protected String computeSelectItemLabel(Month value) {
    return value.getDisplayName(TextStyle.FULL, Locale.FRENCH);
  }
}
