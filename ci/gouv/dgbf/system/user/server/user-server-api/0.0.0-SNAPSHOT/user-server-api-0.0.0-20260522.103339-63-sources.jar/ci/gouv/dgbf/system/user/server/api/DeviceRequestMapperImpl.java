package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DeviceDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-22T10:33:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DeviceRequestMapperImpl implements DeviceRequestMapper {

    @Override
    public DeviceService.DeviceCreateRequestDto mapCreate(DeviceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeviceService.DeviceCreateRequestDto deviceCreateRequestDto = new DeviceService.DeviceCreateRequestDto();

        deviceCreateRequestDto.setCode( arg0.getCode() );
        deviceCreateRequestDto.setName( arg0.getName() );
        deviceCreateRequestDto.setBrand( arg0.getBrand() );
        deviceCreateRequestDto.setModel( arg0.getModel() );
        deviceCreateRequestDto.setOperatingSystem( arg0.getOperatingSystem() );
        deviceCreateRequestDto.setImei( arg0.getImei() );

        return deviceCreateRequestDto;
    }

    @Override
    public DeviceService.DeviceUpdateRequestDto mapUpdate(DeviceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeviceService.DeviceUpdateRequestDto deviceUpdateRequestDto = new DeviceService.DeviceUpdateRequestDto();

        deviceUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        deviceUpdateRequestDto.setCode( arg0.getCode() );
        deviceUpdateRequestDto.setName( arg0.getName() );
        deviceUpdateRequestDto.setBrand( arg0.getBrand() );
        deviceUpdateRequestDto.setModel( arg0.getModel() );
        deviceUpdateRequestDto.setOperatingSystem( arg0.getOperatingSystem() );
        deviceUpdateRequestDto.setImei( arg0.getImei() );

        return deviceUpdateRequestDto;
    }
}
