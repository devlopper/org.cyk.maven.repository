package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.ArrayContainer;
import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasFullNameDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente la base d'identité.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractIdentityDto extends AbstractIdentifiableAuditableDto
    implements HasFullNameDto {

  // Identification

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Groupe de matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
  private String registrationNumberGroupIdentifier;

  /**
   * Le matricule appartient au groupe de la fonction publique.
   */
  @JsonbProperty(value = JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
  private Boolean isRegistrationNumberGroupPublicFunction;

  // Data

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  private String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  private String lastNames;

  /**
   * Nom et prénoms.
   */
  @JsonbProperty(value = JSON_FIRST_NAME_AND_LAST_NAMES)
  private String firstNameAndLastNames;

  @JsonbProperty(value = JSON_FULL_NAME)
  private String fullName;

  /**
   * Identifiant du genre.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  private String genderIdentifier;

  /**
   * Représentation en chaine de caractères de {@link GenderDto}.
   */
  @JsonbProperty(value = JSON_GENDER_AS_STRING)
  private String genderAsString;

  /**
   * Le genre est masculin.
   */
  @JsonbProperty(value = JSON_IS_MASCULINE)
  private Boolean isGenderMasculine;

  /**
   * Date de naissance.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE)
  private LocalDate birthDate;

  /**
   * Identifiant de l'unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de l'unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Cette méthode permet de construire la représentation en chaine de caractères de
   * {@link AbstractIdentityDto}.
   *
   * @param arrayContainer {@link ArrayContainer}
   * @return représentation en chaine de caractères de {@link AbstractIdentityDto}
   */
  public static String buildAsString(ArrayContainer arrayContainer) {
    return asStringBuilder().arrayContainer(arrayContainer).build();
  }

  /**
   * Cette méthode permet de construire la représentation en chaine de caractères de
   * {@link AbstractIdentityDto}.
   *
   * @param arrayContainer {@link ArrayContainer}
   * @return représentation en chaine de caractères de {@link AbstractIdentityDto}
   */
  public static String buildFunctionaryAsString(ArrayContainer arrayContainer) {
    AsStringBuilder asStringBuilder = asStringBuilder().arrayContainer(arrayContainer);
    asStringBuilder.arrayContainerConsumer(container -> {
      asStringBuilder.registrationNumber = container.getNextAsString();
      asStringBuilder.firstName = container.getNextAsString();
      asStringBuilder.lastNames = container.getNextAsString();
    });
    return asStringBuilder.build();
  }

  /**
   * Cette méthode permet d'obtenir une instance de {@link AsStringBuilder}.
   *
   * @return instance de {@link AsStringBuilder}
   */
  public static AsStringBuilder asStringBuilder() {
    return new AsStringBuilder();
  }

  /**
   * Identifiant json champ {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = "adresseEmail";
  /**
   * Identifiant json champ {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";
  /**
   * Identifiant json champ {@link #registrationNumberGroupIdentifier}.
   */
  public static final String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER = "idGroupeMatricule";
  /**
   * Identifiant json champ {@link #isRegistrationNumberGroupPublicFunction}.
   */
  public static final String JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION =
      "estMatriculeFonctionPublique";
  /**
   * Identifiant json champ {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "nom";

  /**
   * Identifiant json champ {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = "prenoms";

  /**
   * Identifiant json champ {@link #firstNameAndLastNames}.
   */
  public static final String JSON_FIRST_NAME_AND_LAST_NAMES = "nomEtPrenoms";

  /**
   * Identifiant json champ {@link #genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = "idGenre";

  /**
   * Identifiant json champ {@link #birthDate}.
   */
  public static final String JSON_IS_MASCULINE = "estMasculin";

  /**
   * Identifiant json champ {@link #isGenderMasculine}.
   */
  public static final String JSON_BIRTH_DATE = "dateNaissance";

  /**
   * Identifiant json champ {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";

  /**
   * Identifiant json champ {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Identifiant json champ {@link #genderAsString}.
   */
  public static final String JSON_GENDER_AS_STRING = "genreChaine";

  /**
   * Cette classe représente un constructeur de représentation en chaine de caractères de
   * {@link AbstractIdentityDto}.
   *
   * @author Christian
   *
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class AsStringBuilder {

    ArrayContainer arrayContainer;
    Consumer<ArrayContainer> arrayContainerConsumer;

    Map<String, Boolean> fieldsNames;
    String registrationNumber;
    String emailAddress;
    String firstName;
    String lastNames;
    String firstNameAndLastNames;

    /**
     * Cette méthode permet de construire.
     */
    public AsStringBuilder() {
      fieldsNames().putAll(Map.of(FIELD_REGISTRATION_NUMBER, true, FIELD_EMAIL_ADDRESS, true,
          FIELD_FIRST_NAME, true, FIELD_LAST_NAMES, true));
      arrayContainerConsumer = container -> {
        Core.runIfTrue(isFieldNameGettable(FIELD_REGISTRATION_NUMBER),
            () -> registrationNumber = container.getNextAsString());

        Core.runIfTrue(isFieldNameGettable(FIELD_EMAIL_ADDRESS),
            () -> emailAddress = container.getNextAsString());

        Core.runIfTrue(isFieldNameGettable(FIELD_FIRST_NAME),
            () -> firstName = container.getNextAsString());

        Core.runIfTrue(isFieldNameGettable(FIELD_LAST_NAMES),
            () -> lastNames = container.getNextAsString());

        Core.runIfTrue(isFieldNameGettable(FIELD_FIRST_NAME_AND_LAST_NAMES),
            () -> firstNameAndLastNames = container.getNextAsString());
      };
    }

    Map<String, Boolean> fieldsNames() {
      if (fieldsNames == null) {
        fieldsNames = new HashMap<>();
      }
      return fieldsNames;
    }

    /**
     * Cette méthode permet d'ajouter un nom de champ.
     *
     * @param fieldName nom de champ
     * @return this
     */
    public AsStringBuilder addFieldName(String fieldName) {
      fieldsNames().put(fieldName, true);
      return this;
    }

    /**
     * Cette méthode permet de supprimer un nom de champ.
     *
     * @param fieldName nom de champ
     * @return this
     */
    public AsStringBuilder removeFieldName(String fieldName) {
      if (fieldsNames != null) {
        fieldsNames.remove(fieldName);
      }
      return this;
    }

    boolean isFieldNameGettable(String fieldName) {
      if (fieldsNames == null) {
        return true;
      }
      return Boolean.TRUE.equals(fieldsNames.get(fieldName));
    }

    /**
     * Cette méthode permet de construire la représentation en chaine de caractères.
     *
     * @return représentation en chaine de caractères
     */
    public String build() {
      consumeArrayContainer();
      registrationNumber = Core.getOrDefaultIfBlank(registrationNumber, null);
      emailAddress = Core.getOrDefaultIfBlank(emailAddress, null);
      firstName = Core.getOrDefaultIfBlank(firstName, null);
      lastNames = Core.getOrDefaultIfBlank(lastNames, null);
      firstNameAndLastNames = Core.getOrDefaultIfBlank(firstNameAndLastNames, null);
      String identifier = buildIdentifier(registrationNumber, emailAddress);
      String names = buildNames(firstNameAndLastNames, firstName, lastNames);
      if (Core.isAllNull(identifier, names)) {
        return Constant.EMPTY_STRING;
      }
      return concatIdentifierAndNames(identifier, names);
    }

    String concatIdentifierAndNames(String identifier, String names) {
      if (identifier == null) {
        return names;
      }
      return String.format("%s - %s", identifier, names);
    }

    void consumeArrayContainer() {
      if (arrayContainer != null && arrayContainerConsumer != null) {
        arrayContainerConsumer.accept(arrayContainer);
      }
    }

    String buildIdentifier(String registrationNumber, String emailAddress) {
      return Core.getOrDefaultIfNull(registrationNumber, emailAddress);
    }

    String buildNames(String firstNameAndLastNames, String firstName, String lastNames) {
      if (Core.isStringBlank(firstNameAndLastNames)) {
        firstNameAndLastNames = Core.concatenateWithSpaceSeparator(firstName, lastNames);
      }
      return Core.getOrDefaultIfBlank(firstNameAndLastNames, null);
    }

    /**
     * Identitifiant java {@link #registrationNumber}.
     */
    public static final String FIELD_REGISTRATION_NUMBER = "registrationNumber";

    /**
     * Identitifiant java {@link #emailAddress}.
     */
    public static final String FIELD_EMAIL_ADDRESS = "emailAddress";

    /**
     * Identitifiant java {@link #firstName}.
     */
    public static final String FIELD_FIRST_NAME = "firstName";

    /**
     * Identitifiant java {@link #lastNames}.
     */
    public static final String FIELD_LAST_NAMES = "lastNames";

    /**
     * Identitifiant java {@link #firstNameAndLastNames}.
     */
    public static final String FIELD_FIRST_NAME_AND_LAST_NAMES = "firstNameAndLastNames";
  }
}
