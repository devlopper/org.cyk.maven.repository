package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant arbitré pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountN2AsStringDto extends HasArbitratedAmountN2AsString {

  /**
   * Identifiant json du montant arbitré pour l'année N+2.
   */
  String JSON_ARBITRATED_AMOUNT_N2_AS_STRING = "montantArbitreN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName