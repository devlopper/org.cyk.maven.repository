package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une liaison entre un rapport et un groupe de rapports.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReportGroupDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link ReportDto}.
   */
  @JsonbProperty(JSON_REPORT_IDENTIFIER)
  private String reportIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ReportDto}.
   */
  @JsonbProperty(JSON_REPORT_AS_STRING)
  private String reportAsString;

  /**
   * Identifiant de {@link ReportDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String reportsGroupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ReportsGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String reportsGroupAsString;

  /**
   * Identitiant json {@link ReportGroupDto#reportIdentifier}.
   */
  public static final String JSON_REPORT_IDENTIFIER = "idRapport";

  /**
   * Identitiant json {@link ReportGroupDto#reportAsString}.
   */
  public static final String JSON_REPORT_AS_STRING = "rapportChaine";

  /**
   * Identitiant json {@link ReportGroupDto#reportsGroupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";

  /**
   * Identitiant json {@link ReportGroupDto#reportAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "GroupeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rapport groupe";
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "rapports groupes";
}
