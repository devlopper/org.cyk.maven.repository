package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a filtre par identifiant d'imputation.
 *
 * @author Christian
 */
public interface FilterHasImputationIdentifier extends HasImputationIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'imputation.
   *
   * @param filter {@link FilterDto}
   */
  default void updateImputationIdentifier(FilterDto filter) {
    setImputationIdentifier(ImputationIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'imputation de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterImputationIdentifier(FilterDto filter) {
    ImputationIdentifierFilter.set(filter, getImputationIdentifier());
  }

}
