package ci.gouv.dgbf.system.token.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TokenDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-14T18:33:31+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TokenRequestMapperImpl implements TokenRequestMapper {

    @Override
    public TokenService.TokenCreateRequestDto mapCreate(TokenDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TokenService.TokenCreateRequestDto tokenCreateRequestDto = new TokenService.TokenCreateRequestDto();

        tokenCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        tokenCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        tokenCreateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );
        tokenCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        tokenCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        tokenCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        tokenCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );

        return tokenCreateRequestDto;
    }

    @Override
    public TokenService.TokenCreateRequestDto mapUpdate(TokenDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TokenService.TokenCreateRequestDto tokenCreateRequestDto = new TokenService.TokenCreateRequestDto();

        tokenCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        tokenCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        tokenCreateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );
        tokenCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        tokenCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        tokenCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        tokenCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );

        return tokenCreateRequestDto;
    }
}
