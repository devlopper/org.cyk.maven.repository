package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeClient;
import ci.gouv.dgbf.system.functionary.server.api.GradeDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.GradeService;
import ci.gouv.dgbf.system.functionary.server.api.GradeService.GradeCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeService.GradeUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link GradeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class GradeController extends AbstractController {

  @Inject
  GradeClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  GradeRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  CategorySelectOneController categorySelectOneController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = GradeDto.NAME;

    listController.setEntityClass(GradeDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(GradeService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME, GradeDto.JSON_CATEGORY_AS_STRING));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      GradeCreateRequestDto request = requestMapper.mapCreate((GradeDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME, GradeDto.JSON_CATEGORY_IDENTIFIER));
    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());
    categorySelectOneController.getSelectOneRadio()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(GradeDto.class)
            .setCategoryIdentifier(identifier));
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((GradeDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((GradeDto) entity).getName());
      categorySelectOneController.getSelectOneRadio()
          .writeValue(((GradeDto) entity).getCategoryIdentifier());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(GradeDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(GradeDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      GradeUpdateRequestDto request = requestMapper.mapUpdate((GradeDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
