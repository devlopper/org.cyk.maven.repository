package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de bailleur.
 *
 * @author Christian
 */
public interface FilterHasLessorIdentifier extends HasLessorIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant exercice.
   *
   * @param filter {@link FilterDto}
   */
  default void updateLessorIdentifier(FilterDto filter) {
    setLessorIdentifier(LessorIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant exercice de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterLessorIdentifier(FilterDto filter) {
    LessorIdentifierFilter.set(filter, getLessorIdentifier());
  }

}
