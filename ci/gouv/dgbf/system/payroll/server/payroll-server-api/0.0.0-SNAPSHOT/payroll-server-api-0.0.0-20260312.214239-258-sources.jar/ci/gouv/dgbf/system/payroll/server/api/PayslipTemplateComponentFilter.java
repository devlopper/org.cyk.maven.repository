package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRemunerableIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayslipTemplateIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipTemplateComponentDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayslipTemplateComponentFilter extends AbstractIdentifiableFilter
    implements FilterHasPayslipTemplateIdentifier, FilterHasRemunerableIdentifier {

  private String payslipTemplateIdentifier;

  private String remunerableIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipTemplateComponentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipTemplateComponentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayslipTemplateIdentifier(filter);
    updateRemunerableIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayslipTemplateIdentifier(filter);
    updateFilterRemunerableIdentifier(filter);
  }
}
