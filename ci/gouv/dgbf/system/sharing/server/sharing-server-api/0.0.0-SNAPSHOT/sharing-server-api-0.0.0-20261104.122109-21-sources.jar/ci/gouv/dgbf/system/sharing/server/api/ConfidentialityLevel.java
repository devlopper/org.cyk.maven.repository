package ci.gouv.dgbf.system.sharing.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/** Niveau de confidentialité d'une ressource. */
@Getter
public enum ConfidentialityLevel {

  /** Niveau privé, appliqué par défaut en l'absence de classification. */
  PRIVATE(ConfidentialityLevelCode.PRIVATE, "Privé", 0),

  /** Niveau public, explicitement autorisé. */
  PUBLIC(ConfidentialityLevelCode.PUBLIC, "Public", 1);

  private final String code;
  private final String name;
  private final int order;

  ConfidentialityLevel(String code, String name, int order) {
    this.code = code;
    this.name = name;
    this.order = order;
  }

  @Override
  public String toString() {
    return name;
  }

  /** Obtient un niveau à partir de son code persistant. */
  public static ConfidentialityLevel getByCode(String code) {
    return Stream.of(values()).filter(level -> level.code.equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException(
            "Code de niveau de confidentialité inconnu : " + code));
  }
}
