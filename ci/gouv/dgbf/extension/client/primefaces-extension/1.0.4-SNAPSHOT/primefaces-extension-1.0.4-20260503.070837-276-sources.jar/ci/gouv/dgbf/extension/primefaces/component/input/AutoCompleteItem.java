package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.segregation.HasName;
import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection de {@link Item} par suggestion.
 *
 * @author Christian
 *
 * @param <T> type
 */
public class AutoCompleteItem
    extends AbstractAutoComplete<Object, AutoCompleteItem.Item, Object, AutoCompleteItem.Item> {

  /**
   * Cette méthode permet d'instantier.
   */
  public AutoCompleteItem(ScriptManager scriptManager) {
    super(scriptManager);
    valueGetFunction = t -> {
      if (t instanceof Item item) {
        return item;
      }
      Item item = new Item(null, null);
      if (t instanceof IdentifiableByString identifiable) {
        item.identifier = identifiable.getIdentifier();
      }
      if (t instanceof HasName namable) {
        item.name = namable.getName();
      }
      return item;
    };

    itemValueGetFunction = t -> {
      if (t instanceof Item item) {
        return item;
      }
      Item item = new Item(null, null);
      if (t instanceof IdentifiableByString identifiable) {
        item.identifier = identifiable.getIdentifier();
      }
      if (t instanceof HasName namable) {
        item.name = namable.getName();
      }
      return item;
    };
  }

  /**
   * Cette classe représente un élément.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @AllArgsConstructor
  public static class Item implements IdentifiableByString, HasName {
    String identifier;
    String name;
  }
}
