package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SubAdministrativeUnitRequestMapperImpl implements SubAdministrativeUnitRequestMapper {

    @Override
    public SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto mapCreate(SubAdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto subAdministrativeUnitCreateRequestDto = new SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto();

        subAdministrativeUnitCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        subAdministrativeUnitCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        subAdministrativeUnitCreateRequestDto.setName( arg0.getName() );

        return subAdministrativeUnitCreateRequestDto;
    }

    @Override
    public SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto mapUpdate(SubAdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto subAdministrativeUnitUpdateRequestDto = new SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto();

        subAdministrativeUnitUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        subAdministrativeUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        subAdministrativeUnitUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        subAdministrativeUnitUpdateRequestDto.setName( arg0.getName() );

        return subAdministrativeUnitUpdateRequestDto;
    }
}
