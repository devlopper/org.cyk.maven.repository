package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N1.
 *
 * @author Christian
 */
public interface HasInputtedAmountN1 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant saisi à l'horizon N1.
   *
   * @return le montant saisi à l'horizon N1
   */
  Long getInputtedAmountN1();

  /**
   * Cette méthode permet d'assigner le montant saisi à l'horizon N1.
   *
   * @param amount le montant saisi à l'horizon N1
   */
  void setInputtedAmountN1(Long amount);

  /**
   * Identifiant java du montant saisi à l'horizon N1.
   */
  String FIELD_INPUTTED_AMOUNT_N1 = "inputtedAmountN1";
}
