package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.DeviceClient;
import ci.gouv.dgbf.system.user.server.api.DeviceDto;
import ci.gouv.dgbf.system.user.server.api.DeviceService.DeviceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DeviceDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class DeviceSelectOneController extends AbstractSelectOneIdentifiableController<
    DeviceDto, DeviceGetManyResponseDto, DeviceClient> {

  @Getter
  @Inject
  DeviceClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected DeviceSelectOneController() {
    super(DeviceDto.class, SelectItemLabelStrategy.NAME);
  }
}
