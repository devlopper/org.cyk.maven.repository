package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de processus sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasProcessCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de processus sous forme de chaîne.
   *
   * @return le nombre de processus sous forme de chaîne
   */
  String getProcessCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre de processus sous forme de chaîne.
   *
   * @param processCountAsString le nombre de processus sous forme de chaîne
   */
  void setProcessCountAsString(String processCountAsString);

  /**
   * Identifiant java du nombre de processus sous forme de chaîne.
   */
  String FIELD_PROCESS_COUNT_AS_STRING = "processCountAsString";
}
