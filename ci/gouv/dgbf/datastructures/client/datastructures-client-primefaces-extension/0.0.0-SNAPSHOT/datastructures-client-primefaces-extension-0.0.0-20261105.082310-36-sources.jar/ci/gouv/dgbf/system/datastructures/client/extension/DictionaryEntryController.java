package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.Ajax;
import ci.gouv.dgbf.extension.primefaces.component.input.ValueTypeSelectOneController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryClient;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryService;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.event.AjaxBehaviorEvent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Dependent
public class DictionaryEntryController extends AbstractController {

  /**
   * Classe css du panneau des contraintes, rafraîchi quand le type de valeur change.
   */
  public static final String CONSTRAINTS_CSS_CLASS = "dictionary-entry-constraints";

  @Inject
  DictionaryEntryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  DictionaryEntryRequestMapper requestMapper;

  @Inject
  @Getter
  DictionaryEntryFilterController filterController;

  @Inject
  @Getter
  ValueTypeSelectOneController valueTypeSelectOneController;

  @Inject
  @Getter
  DictionarySelectOneController dictionarySelectOneController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DictionaryEntryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser le contrôleur.
   */
  public void initialize() {
    listController.setEntityClass(DictionaryEntryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DictionaryEntryService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE,
        DictionaryEntryDto.JSON_VALUE_TYPE,
        DictionaryEntryDto.JSON_DEFAULT_VALUE,
        DictionaryEntryDto.JSON_ORDER,
        DictionaryEntryDto.JSON_MIN_OCCURRENCES,
        DictionaryEntryDto.JSON_MAX_OCCURRENCES,
        DictionaryEntryDto.JSON_MIN_LENGTH,
        DictionaryEntryDto.JSON_MAX_LENGTH,
        DictionaryEntryDto.JSON_MIN_VALUE,
        DictionaryEntryDto.JSON_MAX_VALUE,
        DictionaryEntryDto.JSON_PATTERN,
        DictionaryEntryDto.JSON_ALLOWED_VALUES,
        DictionaryEntryDto.JSON_PRECISION,
        DictionaryEntryDto.JSON_SCALE,
        AbstractIdentifiableCodableNamableDto.JSON_NAME,
        DictionaryEntryDto.JSON_DICTIONARY_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    dictionarySelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, DictionaryEntryDto.JSON_DICTIONARY_AS_STRING);

    dictionarySelectOneController.setRenderable(
        Core.isStringBlank(filterController.getFilter().getDictionaryIdentifier()));

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    AbstractIdentifiableCodableDto.JSON_CODE,
                    AbstractIdentifiableCodableNamableDto.JSON_NAME,
                    DictionaryEntryDto.JSON_VALUE_TYPE,
                    DictionaryEntryDto.JSON_DEFAULT_VALUE,
                    DictionaryEntryDto.JSON_ORDER,
                    DictionaryEntryDto.JSON_MIN_OCCURRENCES,
                    DictionaryEntryDto.JSON_MAX_OCCURRENCES,
                    DictionaryEntryDto.JSON_MIN_LENGTH,
                    DictionaryEntryDto.JSON_MAX_LENGTH,
                    DictionaryEntryDto.JSON_MIN_VALUE,
                    DictionaryEntryDto.JSON_MAX_VALUE,
                    DictionaryEntryDto.JSON_PATTERN,
                    DictionaryEntryDto.JSON_ALLOWED_VALUES,
                    DictionaryEntryDto.JSON_PRECISION,
                    DictionaryEntryDto.JSON_SCALE,
                    DictionaryEntryDto.JSON_DICTIONARY_IDENTIFIER
                )
        );

    listController.getCreateController().addEntityConsumer(
        entity -> ((DictionaryEntryDto) entity).setDictionaryIdentifier(
            filterController.getFilter().getDictionaryIdentifier()));

    listController.getCreateController().setFunction(entity -> {
      applyDictionaryFromFilter((DictionaryEntryDto) entity);
      DictionaryEntryService.DictionaryEntryCreateRequestDto request =
          requestMapper.mapCreate((DictionaryEntryDto) entity);
      request.setValueType(
          ValueType.valueOf(valueTypeSelectOneController.getSelectOneMenu().getValue()));
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setFunction(entity -> {
          DictionaryEntryService.DictionaryEntryUpdateRequestDto request = requestMapper.mapUpdate(
              (DictionaryEntryDto) entity);
          request.setValueType(
              ValueType.valueOf(valueTypeSelectOneController.getSelectOneMenu().getValue()));
          request.setAuditWho(userIdentifier);
          return client.update(request);
        });

    listController.getUpdateController().addEntityConsumer(entity -> {
      dictionarySelectOneController.getSelectOneMenu()
          .writeValue(((DictionaryEntryDto) entity).getDictionaryIdentifier());

      valueTypeSelectOneController.getSelectOneMenu()
          .writeValue(((DictionaryEntryDto) entity).getValueType().name());
    });

    dictionarySelectOneController
        .getSelectOneMenu()
        .addValueConsumer(dictionaryIdentifierConsumer());

    Ajax ajax = valueTypeSelectOneController.getSelectOneMenu().valueChangeAjax();
    ajax.setEvent("valueChange");
    ajax.setUpdate("@(." + CONSTRAINTS_CSS_CLASS + ")");
    ajax.setConsumer(this::clearInapplicableConstraints);
    ajax.setDisabled(false);
  }

  /**
   * Cette méthode permet de vider les contraintes de l'entrée en cours de saisie qui ne
   * s'appliquent pas au type de valeur choisi.
   *
   * @param event événement du changement de type de valeur
   */
  void clearInapplicableConstraints(AjaxBehaviorEvent event) {
    DictionaryEntryDto entry =
        listController.getCreateControllerOrUpdateControllerEntityAs(DictionaryEntryDto.class);
    if (entry != null) {
      DictionaryEntryConstraints.clearInapplicable(entry, selectedValueType());
    }
  }

  ValueType selectedValueType() {
    String value = valueTypeSelectOneController.getSelectOneMenu().getValue();
    return Core.isStringBlank(value) ? null : ValueType.valueOf(value);
  }

  /**
   * Cette méthode permet de savoir s'il faut proposer les longueurs.
   *
   * @return vrai si le type de valeur choisi les admet
   */
  public boolean isLengthsApplicable() {
    return DictionaryEntryConstraints.hasLengths(selectedValueType());
  }

  /**
   * Cette méthode permet de savoir s'il faut proposer l'expression régulière.
   *
   * @return vrai si le type de valeur choisi l'admet
   */
  public boolean isPatternApplicable() {
    return DictionaryEntryConstraints.hasPattern(selectedValueType());
  }

  /**
   * Cette méthode permet de savoir s'il faut proposer les bornes.
   *
   * @return vrai si le type de valeur choisi les admet
   */
  public boolean isBoundsApplicable() {
    return DictionaryEntryConstraints.hasBounds(selectedValueType());
  }

  /**
   * Cette méthode permet de savoir s'il faut proposer les valeurs autorisées.
   *
   * @return vrai si le type de valeur choisi les admet
   */
  public boolean isAllowedValuesApplicable() {
    return DictionaryEntryConstraints.hasAllowedValues(selectedValueType());
  }

  /**
   * Cette méthode permet de savoir s'il faut proposer la précision et l'échelle.
   *
   * @return vrai si le type de valeur choisi les admet
   */
  public boolean isPrecisionAndScaleApplicable() {
    return DictionaryEntryConstraints.hasPrecisionAndScale(selectedValueType());
  }

  /**
   * Cette méthode permet de savoir s'il faut afficher le dictionnaire de chaque entrée : inutile
   * quand la liste est déjà restreinte à un dictionnaire.
   *
   * @return vrai si la liste n'est pas restreinte à un dictionnaire
   */
  public boolean isDictionaryColumnRendered() {
    return Core.isStringBlank(filterController.getFilter().getDictionaryIdentifier());
  }

  /**
   * Cette méthode permet de résumer les contraintes d'une entrée pour la liste.
   *
   * @param entry entrée
   * @return le résumé, vide si aucune contrainte
   */
  public String constraintsSummary(DictionaryEntryDto entry) {
    return DictionaryEntryConstraints.summarize(entry);
  }

  /**
   * Cette méthode retourne le consommateur de la valeur du menu des dictionnaires. Une valeur
   * blanche est ignorée : quand la liste est restreinte à un dictionnaire, le menu n'est pas
   * affiché et sa valeur nulle effaçait l'identifiant posé à l'ouverture du dialogue.
   *
   * @return le consommateur
   */
  Consumer<String> dictionaryIdentifierConsumer() {
    return identifier -> {
      if (!Core.isStringBlank(identifier)) {
        listController.getCreateControllerOrUpdateControllerEntityAs(DictionaryEntryDto.class)
            .setDictionaryIdentifier(identifier);
      }
    };
  }

  /**
   * Cette méthode reprend le dictionnaire du filtre quand l'entrée à créer n'en porte pas. Une
   * valeur déjà renseignée est conservée.
   *
   * @param entry entrée à créer
   */
  void applyDictionaryFromFilter(DictionaryEntryDto entry) {
    String identifier = filterController.getFilter().getDictionaryIdentifier();
    if (Core.isStringBlank(entry.getDictionaryIdentifier())
        && !Core.isStringBlank(identifier)) {
      entry.setDictionaryIdentifier(identifier);
    }
  }

}

