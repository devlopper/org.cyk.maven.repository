package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'unité
 * administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitAsStringDto extends HasAdministrativeUnitAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'unité administrative.
   */
  String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";
}
