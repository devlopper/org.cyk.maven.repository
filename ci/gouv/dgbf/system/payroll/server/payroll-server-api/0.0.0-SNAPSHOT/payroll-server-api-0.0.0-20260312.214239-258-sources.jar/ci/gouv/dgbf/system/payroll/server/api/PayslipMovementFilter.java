package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayslipIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipMovementDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class PayslipMovementFilter extends AbstractIdentifiableFilter
    implements FilterHasPayslipIdentifier {

  private String payslipIdentifier;

  /**
   * Identifiant du mouvement actuel.
   */
  String actualMovementIdentifier;

  /**
   * Identifiant du mouvement precedent.
   */
  String previousMovementIdentifier;

  /**
   * Identifiant instance de l'élément de paie.
   */
  String payrollElementInstanceIdentifier;

  /**
   * Identifiant du remunerable.
   */
  String remunerableIdentifier;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipMovementFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipMovementFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayslipIdentifier(filter);
    actualMovementIdentifier = getActualMovementIdentifier(filter);
    previousMovementIdentifier = getPreviousMovementIdentifier(filter);
    payrollElementInstanceIdentifier = getPayrollElementInstanceIdentifier(filter);
    remunerableIdentifier = getRemunerableIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayslipIdentifier(filter);
    setActualMovementIdentifier(filter, actualMovementIdentifier);
    setPreviousMovementIdentifier(filter, previousMovementIdentifier);
    setPayrollElementInstanceIdentifier(filter, payrollElementInstanceIdentifier);
    setRemunerableIdentifier(filter, remunerableIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du mouvement actuel.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setActualMovementIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ACTUAL_MOVEMENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du mouvement actuel.
   *
   * @param filter filtre
   * @return identifiant du mouvement actuel
   */
  public static String getActualMovementIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTUAL_MOVEMENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du mouvement précédent.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPreviousMovementIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PREVIOUS_MOVEMENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du mouvement précédent.
   *
   * @param filter filtre
   * @return identifiant du mouvement précédent
   */
  public static String getPreviousMovementIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PREVIOUS_MOVEMENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant instance de l'élément de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPayrollElementInstanceIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant instance de l'élément de paie.
   *
   * @param filter filtre
   * @return identifiant instance de l'élément de paie
   */
  public static String getPayrollElementInstanceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(
            JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le remunerable.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setRemunerableIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_REMUNERABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du remunerable.
   *
   * @param filter filtre
   * @return identifiant du remunerable
   */
  public static String getRemunerableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(
            JSON_REMUNERABLE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link PayslipMovementFilter#actualMovementIdentifier}.
   */
  public static final String JSON_ACTUAL_MOVEMENT_IDENTIFIER = MovementDto.JSON_IDENTIFIER;

  /**
   * Identifiant json champ {@link PayslipMovementFilter#previousMovementIdentifier}.
   */
  public static final String JSON_PREVIOUS_MOVEMENT_IDENTIFIER = MovementDto.JSON_IDENTIFIER;

  /**
   * Identifiant json champ {@link PayslipMovementFilter#payrollElementInstanceIdentifier}.
   */
  public static final String JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER = 
      MovementDto.JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER;

  /**
   * Identifiant json champ {@link PayslipMovementFilter#remunerableIdentifier}.
   */
  public static final String JSON_REMUNERABLE_IDENTIFIER = 
      MovementDto.JSON_REMUNERABLE_IDENTIFIER;



}
