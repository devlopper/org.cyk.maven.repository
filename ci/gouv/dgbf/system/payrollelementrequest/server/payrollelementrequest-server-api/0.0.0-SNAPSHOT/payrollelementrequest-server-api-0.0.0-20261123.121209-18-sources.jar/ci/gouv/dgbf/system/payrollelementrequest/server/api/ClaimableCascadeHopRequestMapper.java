package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeHopService.ClaimableCascadeHopCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeHopService.ClaimableCascadeHopUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimableCascadeHopDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimableCascadeHopDto}.

    @author akm
               """)
public interface ClaimableCascadeHopRequestMapper extends
    RequestMapper<ClaimableCascadeHopDto, ClaimableCascadeHopCreateRequestDto,
        ClaimableCascadeHopUpdateRequestDto> {

}
