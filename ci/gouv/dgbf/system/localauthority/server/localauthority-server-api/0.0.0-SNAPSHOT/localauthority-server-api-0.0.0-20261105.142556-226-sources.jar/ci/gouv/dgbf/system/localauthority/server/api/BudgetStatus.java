package ci.gouv.dgbf.system.localauthority.server.api;


import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link BudgetDto}.
 *
 * @author Donsylla
 *
 */
@Getter
public enum BudgetStatus {

  /**
   * Créé.
   */
  CREATED(BudgetStatusCode.CREATED, "Créé", "Créer", "Création"),

  /**
   * Validé.
   */
  VALIDATED(BudgetStatusCode.VALIDATED, "Validé", "Valider", "Validation"),

  /**
   * Transmis.
   */
  TRANSMITTED(BudgetStatusCode.TRANSMITTED, "Transmis", "Transmettre", "Transmission"),

  /**
   * Différé.
   */
  DEFERRED(BudgetStatusCode.DEFERRED, "Différé", "Différer", "Différé"),

  /**
   * Approuvé.
   */
  APPROVED(BudgetStatusCode.APPROVED, "Approuvé", "Approuver", "Approbation"),

  /**
   * Clôturé.
   */
  CLOSED(BudgetStatusCode.CLOSED, "Clôturé", "Clôturer", "Clôture");

  private BudgetStatus(String code, String name, String action, String actionName) {
    this.code = code;
    this.name = name;
    this.action = action;
    this.actionName = actionName;
  }

  private String code;
  private String name;
  private String action;
  private String actionName;
  private Set<BudgetStatus> previous;

  /**
   * Cette méthode permet de savoir si le budget est modifiable.
   *
   * @return vrai si le budget est modifiable sinon faux
   */
  public boolean isUpdatable() {
    return CREATED.equals(this) || DEFERRED.equals(this);
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le statut par code.
   *
   * @param code code
   * @return statut
   */
  public static BudgetStatus getByCode(String code) {
    return Stream.of(BudgetStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }

  static {
    CREATED.previous = Collections.emptySet();
    VALIDATED.previous = Core.getSet(List.of(CREATED, DEFERRED));
    TRANSMITTED.previous = Core.getSet(List.of(VALIDATED));
    DEFERRED.previous = Core.getSet(List.of(TRANSMITTED));
    APPROVED.previous = Core.getSet(List.of(TRANSMITTED));
    CLOSED.previous = Core.getSet(List.of(CREATED, VALIDATED, TRANSMITTED, DEFERRED, APPROVED));
  }
}
