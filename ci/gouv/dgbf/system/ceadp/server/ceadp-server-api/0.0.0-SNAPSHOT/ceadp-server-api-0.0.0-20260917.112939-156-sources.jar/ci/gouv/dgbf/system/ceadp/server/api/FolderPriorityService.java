package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link FolderPriorityDto}.
 *
 * @author Dahoud Yao Komenan
 */
@Path(value = FolderPriorityService.PATH)
@Tag(name = "Gestion des priorites de dossiers")
public interface FolderPriorityService extends SpecificService {

  /** Chemin de base des services. */
  String PATH = "priorites-dossiers";

  /** Identifiant du service de création. */
  String CREATE_IDENTIFIER = "CREATION_PRIORITE_DOSSIER";

  /** Chemin du service de création. */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(
      operationId = CREATE_IDENTIFIER,
      summary = "Création d'une priorité de dossier",
      description = "Ce service permet de créer une priorité de dossier")
  @APIResponse(
      responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FolderPriorityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Dahoud
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(
      value = {
        AbstractCodableCreateRequestJsonDto.FIELD_CODE,
        AbstractCodableNamableCreateRequestJsonDto.FIELD_NAME,
        AbstractRequestDto.FIELD_AUDIT_WHO,
        AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION
      })
  class FolderPriorityCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto {}

  /** Identifiant du service d'obtention de plusieurs. */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PRIORITE_DOSSIER";

  /** Chemin du service d'obtention de plusieurs. */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(
      operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des priorites de dossiers")
  @APIResponse(
      responseCode = "200",
      content = {
        @Content(schema = @Schema(implementation = FolderPriorityGetManyResponseDto.class))
      })
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Dahoud
   */
  @Getter
  @Setter
  public static class FolderPriorityGetManyResponseDto
      extends AbstractGetByPageResponseDto<FolderPriorityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FolderPriorityDto> datas;
  }

  /** Identifiant du service d'obtention de un. */
  String GET_ONE_IDENTIFIER = "OBTENTION_UNE_PRIORITE_DOSSIER";

  /** Chemin du service d'obtention de un. */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(
      operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une priorité de dossier")
  @APIResponse(
      responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FolderPriorityDto.class))})
  Response getOne(GetOneRequestDto request);

  /** Identifiant du service d'obtention par identifiant de un. */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PRIORITE_DOSSIER";

  /** Chemin du service d'obtention par identifiant de un. */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(
      operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une priorité dossier")
  @APIResponse(
      responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FolderPriorityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /** Identifiant du service de mise à jour. */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PRIORITE_DOSSIER";

  /** Chemin du service de mise à jour. */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(
      operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une priorité dossier")
  @APIResponse(
      responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FolderPriorityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Dahoud
   */
  @Getter
  @Setter
  class FolderPriorityUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto {}

  /** Identifiant du service de suppression. */
  String DELETE_IDENTIFIER = "SUPPRESSION_PRIORITE_DOSSIER";

  /** Chemin du service de suppression. */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FolderPriorityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(
      operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une priorité dossier")
  @APIResponse(
      responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
