package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.io.Serializable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/** DTO de lecture d’un événement de traçabilité. */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TraceabilityEventDto extends AbstractIdentifiableAuditableDto
    implements Serializable {

  @JsonbProperty("category")
  private TraceabilityEventCategory category;

  @JsonbProperty("sourceIdentifier")
  private String sourceIdentifier;

  @JsonbProperty("processIdentifier")
  private String processIdentifier;

  @JsonbProperty("level")
  private LogLevel level;

  @JsonbProperty("source")
  private String source;

  @JsonbProperty("record")
  private String record;

  @JsonbProperty("operation")
  private String operation;

  @JsonbProperty("actionType")
  private TraceabilityActionType actionType;

  @JsonbProperty("containsMaskedData")
  private boolean containsMaskedData;

  @JsonbProperty("messageSummary")
  private String messageSummary;

  @JsonbProperty("classificationVersion")
  private String classificationVersion;
}
