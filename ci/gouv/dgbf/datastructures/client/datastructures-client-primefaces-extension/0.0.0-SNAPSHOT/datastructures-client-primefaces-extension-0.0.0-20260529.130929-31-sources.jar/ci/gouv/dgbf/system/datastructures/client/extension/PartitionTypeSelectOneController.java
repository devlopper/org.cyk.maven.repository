package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeService.PartitionTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PartitionTypeDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionTypeSelectOneController extends
    AbstractSelectOneIdentifiableController<PartitionTypeDto, 
    PartitionTypeGetManyResponseDto, PartitionTypeClient> {

  @Getter
  @Inject
  PartitionTypeClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected PartitionTypeSelectOneController() {
    super(PartitionTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
