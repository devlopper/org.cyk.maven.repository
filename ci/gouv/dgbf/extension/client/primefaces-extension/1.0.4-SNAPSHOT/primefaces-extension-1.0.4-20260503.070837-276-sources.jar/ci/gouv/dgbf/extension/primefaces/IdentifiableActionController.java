package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.enterprise.context.Dependent;
import java.util.function.Function;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur d'action sur un identifiable.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentifiableActionController
    extends AbstractActionController<IdentifiableResponseDto> {

  @Setter
  Function<String, IdentifiableResponseDto> function;

  public IdentifiableActionController() {
    name = "action sur identifiable";
  }
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    notificationPublishController.setEnabled(false);
  }
  
  /**
   * Cette méthode permet d'exécuter.
   *
   * @return navigation
   */
  public String execute(String identifier) {
    validate(identifier);
    return new ActionExecutor<String>(this, name, () -> {
      IdentifiableResponseDto response = function.apply(identifier);
      processResponse(response);
      publishNotification(response);
      return navigate(response);
    }).execute();
  }
  
  void validate(String identifier) {
    validateIdentifier(identifier);
    validateFunction();
  }
  
  void validateIdentifier(String identifier) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L''identifiant est obligatoire");
    }
  }
  
  void validateFunction() {
    if (function == null) {
      throw new IllegalStateException("La fonction à exécuter est obligatoire");
    }
  }
}
