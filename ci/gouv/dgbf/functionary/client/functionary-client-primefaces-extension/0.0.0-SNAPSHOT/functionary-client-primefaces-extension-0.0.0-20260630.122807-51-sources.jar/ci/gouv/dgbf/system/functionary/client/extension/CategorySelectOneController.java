package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.CategoryClient;
import ci.gouv.dgbf.system.functionary.server.api.CategoryDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService.CategoryGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link CategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class CategorySelectOneController extends AbstractSelectOneIdentifiableController<
    CategoryDto, CategoryGetManyResponseDto, CategoryClient> {

  @Getter
  @Inject
  CategoryClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected CategorySelectOneController() {
    super(CategoryDto.class, SelectItemLabelStrategy.NAME);
  }
}
