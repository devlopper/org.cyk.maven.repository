package ci.gouv.dgbf.system.file.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de groupe de fichiers.
 *
 * @author Christian
 */
public interface HasFilesGroupIdentifierDto extends HasFilesGroupIdentifier {

  /**
   * Identifiant json de l'identifiant du groupe de fichiers.
   */
  String JSON_FILES_GROUP_IDENTIFIER = "idGroupFichiers";
}