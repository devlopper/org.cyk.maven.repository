package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamService.SupportTeamCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamService.SupportTeamUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SupportTeamDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SupportTeamDto}.

    @author Arnaud
               """)
public interface SupportTeamRequestMapper
    extends RequestMapper<SupportTeamDto, SupportTeamCreateRequestDto,
     SupportTeamUpdateRequestDto> {

}
