package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RoleDto}.
 *
 * @author Arnaud
 */
@Getter
@Setter
public class RoleFilter extends AbstractIdentifiableFilter {


  /**
   * Identifiant de l'application pour filtrer les rôles. Si renseigné, retourne uniquement les
   * rôles de cette application.
   */
  private String applicationIdentifier;

  /**
   * Identifiant de l'utilisateur pour filtrer les rôles NON assignés. Si renseigné, retourne
   * uniquement les rôles que cet utilisateur n'a PAS.
   */
  private String unassignedUserIdentifier;

  /**
   * Identifiant de l'utilisateur pour filtrer les rôles assignés. Si renseigné, retourne uniquement
   * les rôles que cet utilisateur possède.
   */
  private String assignedUserIdentifier;

  /**
   * Nom.
   */
  private String name;

  /**
   * Nom contenant.
   */
  private String nameContains;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RoleFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RoleFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    applicationIdentifier = getApplicationIdentifier(filter);
    unassignedUserIdentifier = getUnassignedUserIdentifier(filter);
    assignedUserIdentifier = getAssignedUserIdentifier(filter);
    name = getName(filter);
    nameContains = getNameContains(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setApplicationIdentifier(filter, applicationIdentifier);
    setUnassignedUserIdentifier(filter, unassignedUserIdentifier);
    setAssignedUserIdentifier(filter, assignedUserIdentifier);
    setName(filter, name);
    setNameContains(filter, nameContains);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur pour les rôles NON assignés.
   *
   * @param filter                   filtre
   * @param unassignedUserIdentifier identifiant de l'utilisateur
   */
  public static void setUnassignedUserIdentifier(FilterDto filter,
                                                 String unassignedUserIdentifier) {
    set(filter, JSON_UNASSIGNED_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(unassignedUserIdentifier));
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur pour les rôles NON assignés.
   *
   * @param filter filtre
   * @return identifiant de l'utilisateur
   */
  public static String getUnassignedUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_UNASSIGNED_USER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur pour les rôles assignés.
   *
   * @param filter                 filtre
   * @param assignedUserIdentifier identifiant de l'utilisateur
   */

  public static void setAssignedUserIdentifier(FilterDto filter, String assignedUserIdentifier) {
    set(filter, JSON_ASSIGNED_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(assignedUserIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur pour les rôles assignés.
   *
   * @param filter filtre
   * @return identifiant de l'utilisateur
   */
  public static String getAssignedUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ASSIGNED_USER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param name   nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * assigner l'id app.
   *
   * @param filter                filtre
   * @param applicationIdentifier id app.
   */
  public static void setApplicationIdentifier(FilterDto filter, String applicationIdentifier) {
    set(filter, JSON_APPLICATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(applicationIdentifier));
  }

  /**
   * obtenir id app.
   *
   * @param filter filtre
   * @return id app.
   */
  public static String getApplicationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_APPLICATION_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter       filtre
   * @param nameContains nom
   */
  public static void setNameContains(FilterDto filter, String nameContains) {
    set(filter, JSON_NAME_CONTAINS, f -> f.getValueAsString(),
        f -> f.setValueAsString(nameContains));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getNameContains(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME_CONTAINS));
  }

  /**
   * Identifiant json champ {@link #unassignedUserIdentifier}.
   */
  public static final String JSON_UNASSIGNED_USER_IDENTIFIER =
      RoleDto.JSON_UNASSIGNED_USER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #assignedUserIdentifier}.
   */
  public static final String JSON_ASSIGNED_USER_IDENTIFIER = RoleDto.JSON_ASSIGNED_USER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = RoleDto.JSON_APPLICATION_IDENTIFIER;

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #nameContains}.
   */
  public static final String JSON_NAME_CONTAINS = "nameContains";

}
