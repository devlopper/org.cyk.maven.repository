package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationClient;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationRequestMapper;
import ci.gouv.dgbf.system.user.server.api.ApplicationService;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserRoleClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleService;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class ApplicationController extends AbstractController {

  @Inject
  ApplicationClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ApplicationFilterController filterController;

  @Inject
  ApplicationRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  DomainSelectOneController domainSelectOneController;

  @Inject
  @Getter
  IdentifiableProcessingController assignUsersRolesProcessingController;

  @Inject
  UserClient userClient;

  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;
  @Inject
  @Getter
  UserSelectManyController userSelectManyController;

  @Getter
  @Inject
  UserRoleClient userRoleClient;

  @Inject
  RoleClient roleClient;

  @Inject
  @Getter
  IdentifiableProcessingController assignAdministratorProcessingController;

  @Inject
  @Getter
  UserSelectManyController assignAdministratorUserSelectManyController;

  @Inject
  @Getter
  UserRoleCreateManyController createManyController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ApplicationDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(ApplicationDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ApplicationService.PATH);

    ProjectionDto projection =
        new ProjectionDto()
            .addNames(
                AbstractIdentifiableDto.JSON_IDENTIFIER,
                AbstractIdentifiableCodableDto.JSON_CODE,
                AbstractIdentifiableCodableNamableDto.JSON_NAME,
                ApplicationDto.JSON_DOMAIN_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(ApplicationReadUsersPage.OUTCOME);

    listController.initialize();

    listController
        .getCreateController()
        .setFunction(
            entity -> {
              ApplicationCreateRequestDto request =
                  requestMapper.mapCreate((ApplicationDto) entity);
              request.setAuditWho(userIdentifier);
              return client.create(request);
            });

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    AbstractIdentifiableCodableDto.JSON_CODE,
                    AbstractIdentifiableCodableNamableDto.JSON_NAME,
                    ApplicationDto.JSON_DOMAIN_IDENTIFIER,
                    ApplicationDto.JSON_DOMAIN_AS_STRING));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    domainSelectOneController.getSelectOneMenu().setRequired(true);
    domainSelectOneController.getSelectOneMenu().addValueConsumer(domainIdentifierConsumer());

    assignUsersRolesProcessingController.setViewer(IdentifiableProcessingController.Viewer.DIALOG);
    assignUsersRolesProcessingController.prepareDialog(
        ApplicationDto.class,
        "Assigner un rôle",
        "pi pi-users",
        assignUsersRolesFunction(),
        "assignUsersRolesForm",
        client);
    assignUsersRolesProcessingController.addShowDialogConsumer(loadRoleByApplicationIdentifier());
    assignUsersRolesProcessingController.initialize();

    roleSelectManyController.setOutputLableValue("Rôles à assigner");
    roleSelectManyController.getSelectManyCheckbox().setRequired(true);
    roleSelectManyController.setChoicable(true);
    roleSelectManyController.getSelectManyCheckbox().setLayout("responsive");
    roleSelectManyController.getSelectManyCheckbox().setColumns(3);

    userSelectManyController.setOutputLableValue("Utilisateurs");
    userSelectManyController.getAutoComplete().setMultiple(true);
    userSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeUser(query)));

    assignAdministratorUserSelectManyController.setOutputLableValue("Utilisateurs");
    assignAdministratorUserSelectManyController.getAutoComplete().setMultiple(true);
    assignAdministratorUserSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeUser(query)));

    assignAdministratorProcessingController.setViewer(
        IdentifiableProcessingController.Viewer.DIALOG);
    assignAdministratorProcessingController.prepareDialog(
        ApplicationDto.class,
        "Assigner administrateur",
        "pi pi-user-plus",
        assignAdministratorFunction(),
        "assignAdministratorForm",
        client);
    assignAdministratorProcessingController.addShowDialogConsumer(
        identifier -> userSelectManyController.getAutoComplete()
            .writeValue(new ArrayList<>()));
    assignAdministratorProcessingController.initialize();
  }

  /**
   * Méthode de complétion pour l'autocomplete des utilisateurs.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants
   */
  public List<UserDto> completeUser(String query) {
    if (query == null || query.trim().isEmpty()) {
      return List.of();
    }
    UserFilter filter = new UserFilter();
    filter.setNameContains("%" + query + "%");
    PageDto pageDto = new PageDto();
    pageDto.setIndex(0);
    pageDto.setSize(20);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING);
    UserGetManyResponseDto response =
        userClient.getMany(projection, filter.toDto(), pageDto, userIdentifier, null);
    return response != null && response.getDatas() != null
        ? response.getDatas()
        : List.of();
  }

  /**
   * Méthode pour obtenir le label d'affichage d'un utilisateur.
   *
   * @param user l'utilisateur
   * @return le label formaté
   */
  public String getUserLabel(UserDto user) {
    return user.getName() + " (" + user.getIdentityAsString() + ")";
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((ApplicationDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((ApplicationDto) entity).getName());
      domainSelectOneController
          .getSelectOneMenu()
          .writeValue(((ApplicationDto) entity).getDomainIdentifier());
    };
  }

  Consumer<String> domainIdentifierConsumer() {
    return identifier ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setDomainIdentifier(identifier);
  }

  Consumer<String> codeConsumer() {
    return code ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ApplicationUpdateRequestDto request = requestMapper.mapUpdate((ApplicationDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream()
        .map(input -> input.getMessage().getIdentifier())
        .collect(Collectors.joining(","));
  }

  /**
   * Cette méthode permet de charger les rôles par identifiant de l'application.
   */
  Consumer<String> loadRoleByApplicationIdentifier() {
    return applicationIdentifier -> {
      RoleFilter roleFilter = new RoleFilter();
      roleFilter.setApplicationIdentifier(applicationIdentifier);
      roleSelectManyController.setFilter(roleFilter.toDto());
      roleSelectManyController.computeSelectManyCheckboxChoices();
    };
  }


  /**
   * Cette méthode permet de créer plusieurs rôles pour plusieurs utilisateurs.
   *
   * @return la fonction de création de plusieurs rôles
   */
  UnaryOperator<Object> assignUsersRolesFunction() {
    return input -> {
      Set<String> selectedRoleIds =
          new HashSet<>(roleSelectManyController.getSelectManyCheckbox().getValue());
      UserRoleService.UserRoleCreateManyRequestDto request =
          new UserRoleService.UserRoleCreateManyRequestDto();
      request.setUserIdentifiers(
          new HashSet<>(userSelectManyController.getAutoComplete().getValue()));
      request.setRoleIdentifiers(selectedRoleIds);
      request.setAuditWho(userIdentifier);
      return userRoleClient.createMany(request);
    };
  }

  /**
   * Fonction d'assignation du rôle administrateur applicatif.
   *
   * @return l'opérateur appliqué à l'entité {@link ApplicationDto} de la ligne courante
   */
  UnaryOperator<Object> assignAdministratorFunction() {
    return input -> {
      ApplicationDto application = (ApplicationDto) input;
      ApplicationService.ApplicationAssignAdministratorRequestDto request =
          new ApplicationService.ApplicationAssignAdministratorRequestDto();
      request.setIdentifier(application.getIdentifier());
      request.setUserIdentifiers(
          new HashSet<>(assignAdministratorUserSelectManyController.getAutoComplete().getValue()));
      request.setAuditWho(userIdentifier);
      return client.assignAdministrator(request);
    };
  }
}
