package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitEmployeeAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitEmployeeIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetAdministrativeUnitIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseIdentifierDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployeeAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un poste de paie d'employé.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EmployeePayrollComponentDto extends AbstractIdentifiableDto
    implements HasExerciseIdentifierDto, HasExerciseAsStringDto, HasBudgetIdentifierDto,
    HasBudgetAsStringDto, HasBudgetAdministrativeUnitIdentifierDto,
    HasAdministrativeUnitEmployeeIdentifierDto, HasAdministrativeUnitEmployeeAsStringDto,
    HasAdministrativeUnitIdentifierDto, HasAdministrativeUnitAsStringDto, HasEmployeeAsStringDto,
    HasPayrollComponentIdentifierDto, HasPayrollComponentAsStringDto,
    PayrollComponentProjectionContainerDto {

  /**
   * Identifiant de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  String exerciseAsString;

  /**
   * Identifiant de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de unité administrative de budget.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Identifiant d'employé d'unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
  String administrativeUnitEmployeeIdentifier;

  /**
   * Représentation en chaine de caractères d'employé d'unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING)
  String administrativeUnitEmployeeAsString;

  /**
   * Identifiant de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  String administrativeUnitAsString;

  /**
   * Représentation en chaine de caractères de l'employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_AS_STRING)
  String employeeAsString;

  /**
   * Identifiant de poste de paie.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  String payrollComponentIdentifier;

  /**
   * Représentation en chaine de caractères de poste de paie.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  String payrollComponentAsString;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @Transient
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Représentation en chaine de caractères de la variance du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVarianceAsString;
  
  /**
   * Identifiant json de identifiant de {@link EmployeePayrollComponentDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPostePaieEmploye";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link EmployeePayrollComponentDto}.
   */
  public static final String JSON_THIS_AS_STRING = "postePaieEmployeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de paie d'employé";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de paie d'employé";
}
