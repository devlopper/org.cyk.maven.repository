package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewDelegateToTreasuryRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewDelegateToTreasuryResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewGrantVisaRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewGrantVisaResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewRejectRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewRejectResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewResumeRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewResumeResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewSuspendRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewSuspendResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToControlRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToControlResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToValidationRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToValidationResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToVisaRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToVisaResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTreasuryValidateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTreasuryValidateResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateControlRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateControlResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateManyRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewValidateResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ClaimedValueReviewService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ClaimedValueReviewClient extends AbstractClient<ClaimedValueReviewService>
    implements GetByIdentifier<ClaimedValueReviewDto>,
    GetMany<ClaimedValueReviewGetManyResponseDto> {

  @Override
  public ClaimedValueReviewClient service(ClaimedValueReviewService service) {
    return (ClaimedValueReviewClient) super.service(service);
  }

  /**
   * {@link ClaimedValueReviewService#transmitToVisa}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewTransmitToVisaResponseDto transmitToVisa(
      ClaimedValueReviewTransmitToVisaRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewTransmitToVisaResponseDto>(
        ClaimedValueReviewTransmitToVisaResponseDto.class,
        ClaimedValueReviewService.TRANSMIT_TO_VISA_IDENTIFIER)
            .execute(() -> service().transmitToVisa(request));
  }

  /**
   * {@link ClaimedValueReviewService#grantVisa}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewGrantVisaResponseDto grantVisa(
      ClaimedValueReviewGrantVisaRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewGrantVisaResponseDto>(
        ClaimedValueReviewGrantVisaResponseDto.class,
        ClaimedValueReviewService.GRANT_VISA_IDENTIFIER)
            .execute(() -> service().grantVisa(request));
  }

  /**
   * {@link ClaimedValueReviewService#transmitToControl}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewTransmitToControlResponseDto transmitToControl(
      ClaimedValueReviewTransmitToControlRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewTransmitToControlResponseDto>(
        ClaimedValueReviewTransmitToControlResponseDto.class,
        ClaimedValueReviewService.TRANSMIT_TO_CONTROL_IDENTIFIER)
            .execute(() -> service().transmitToControl(request));
  }

  /**
   * {@link ClaimedValueReviewService#transmitToValidation}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewTransmitToValidationResponseDto transmitToValidation(
      ClaimedValueReviewTransmitToValidationRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewTransmitToValidationResponseDto>(
        ClaimedValueReviewTransmitToValidationResponseDto.class,
        ClaimedValueReviewService.TRANSMIT_TO_VALIDATION_IDENTIFIER)
            .execute(() -> service().transmitToValidation(request));
  }

  /**
   * {@link ClaimedValueReviewService#delegateToTreasury}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewDelegateToTreasuryResponseDto delegateToTreasury(
      ClaimedValueReviewDelegateToTreasuryRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewDelegateToTreasuryResponseDto>(
        ClaimedValueReviewDelegateToTreasuryResponseDto.class,
        ClaimedValueReviewService.DELEGATE_TO_TREASURY_IDENTIFIER)
            .execute(() -> service().delegateToTreasury(request));
  }

  /**
   * {@link ClaimedValueReviewService#validateControl}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewValidateControlResponseDto validateControl(
      ClaimedValueReviewValidateControlRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewValidateControlResponseDto>(
        ClaimedValueReviewValidateControlResponseDto.class,
        ClaimedValueReviewService.VALIDATE_CONTROL_IDENTIFIER)
            .execute(() -> service().validateControl(request));
  }

  /**
   * {@link ClaimedValueReviewService#reject}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewRejectResponseDto reject(ClaimedValueReviewRejectRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewRejectResponseDto>(
        ClaimedValueReviewRejectResponseDto.class, ClaimedValueReviewService.REJECT_IDENTIFIER)
            .execute(() -> service().reject(request));
  }

  /**
   * {@link ClaimedValueReviewService#validate}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewValidateResponseDto validate(
      ClaimedValueReviewValidateRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewValidateResponseDto>(
        ClaimedValueReviewValidateResponseDto.class, ClaimedValueReviewService.VALIDATE_IDENTIFIER)
            .execute(() -> service().validate(request));
  }

  /**
   * {@link ClaimedValueReviewService#treasuryValidate}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewTreasuryValidateResponseDto treasuryValidate(
      ClaimedValueReviewTreasuryValidateRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewTreasuryValidateResponseDto>(
        ClaimedValueReviewTreasuryValidateResponseDto.class,
        ClaimedValueReviewService.TREASURY_VALIDATE_IDENTIFIER)
            .execute(() -> service().treasuryValidate(request));
  }

  /**
   * {@link ClaimedValueReviewService#getCount}.
   *
   * @param request requête
   * @return nombre
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(ClaimedValueReviewService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link ClaimedValueReviewService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewGetManyResponseDto>(
        ClaimedValueReviewGetManyResponseDto.class, ClaimedValueReviewService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimedValueReviewService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimedValueReviewGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimedValueReviewService#getByIdentifier}.
   *
   * @param request requête
   * @return revue de valeur réclamée
   */
  public ClaimedValueReviewDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewDto>(ClaimedValueReviewDto.class,
        ClaimedValueReviewService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimedValueReviewService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimedValueReviewDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimedValueReviewService#suspend}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewSuspendResponseDto suspend(
      ClaimedValueReviewSuspendRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewSuspendResponseDto>(
        ClaimedValueReviewSuspendResponseDto.class, ClaimedValueReviewService.SUSPEND_IDENTIFIER)
            .execute(() -> service().suspend(request));
  }

  /**
   * {@link ClaimedValueReviewService#resume}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewResumeResponseDto resume(
      ClaimedValueReviewResumeRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewResumeResponseDto>(
        ClaimedValueReviewResumeResponseDto.class, ClaimedValueReviewService.RESUME_IDENTIFIER)
            .execute(() -> service().resume(request));
  }

  /**
   * {@link ClaimedValueReviewService#validateMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewValidateManyResponseDto validateMany(
      ClaimedValueReviewValidateManyRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewValidateManyResponseDto>(
        ClaimedValueReviewValidateManyResponseDto.class,
        ClaimedValueReviewService.VALIDATE_MANY_IDENTIFIER)
            .execute(() -> service().validateMany(request));
  }

  /**
   * {@link ClaimedValueReviewService#treasuryValidateMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewValidateManyResponseDto treasuryValidateMany(
      ClaimedValueReviewValidateManyRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewValidateManyResponseDto>(
        ClaimedValueReviewValidateManyResponseDto.class,
        ClaimedValueReviewService.TREASURY_VALIDATE_MANY_IDENTIFIER)
            .execute(() -> service().treasuryValidateMany(request));
  }
}
