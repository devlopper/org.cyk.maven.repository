package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PolicyDto}.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
public class PolicyClient extends AbstractClient<PolicyService>
    implements GetByIdentifier<PolicyDto>, GetMany<PolicyGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link PolicyService}
   * @return client {@link PolicyClient}
   */
  @Override
  public PolicyClient service(PolicyService service) {
    return (PolicyClient) super.service(service);
  }

  /**
   * {@link PolicyService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PolicyCreateRequestDto request) {
    return new CreateExecutor(PolicyService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PolicyService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PolicyGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PolicyGetManyResponseDto>(PolicyGetManyResponseDto.class,
        PolicyService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PolicyService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PolicyGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PolicyService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PolicyDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<PolicyDto>(PolicyDto.class,
        PolicyService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PolicyService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PolicyDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<PolicyDto>(PolicyDto.class,
        PolicyService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PolicyService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PolicyUpdateRequestDto request) {
    return new IdentifiableExecutor(PolicyService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PolicyService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PolicyService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PolicyService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
