package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.component.input.InputText;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative.AdministrativeUnitSelectOneController;
import ci.gouv.dgbf.system.identity.server.api.AbstractIdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityService;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityImportAllRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityController extends AbstractController {

  @Inject
  IdentityClient client;

  @Inject
  IdentityRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Getter
  InputText firstName;

  @Getter
  InputText lastNames;

  @Inject
  @Getter
  AdministrativeUnitSelectOneController administrativeUnitSelectOneController;

  @Inject
  @Getter
  GenderSelectOneController genderSelectOneController;

  @Inject
  @Getter
  RegistrationNumberGroupSelectOneController registrationNumberGroupSelectOneController;

  /* Filter */

  @Inject
  @Getter
  IdentityFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentityDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialise() {
    listController.setEntityClass(IdentityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentityService.PATH);
    listController.setFilterController(filterController);

    administrativeUnitSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityDto.class)
            .setAdministrativeUnitIdentifier(identifier));

    registrationNumberGroupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityDto.class)
            .setRegistrationNumberGroupIdentifier(identifier));

    genderSelectOneController.getSelectOneRadio()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityDto.class)
            .setGenderIdentifier(identifier));

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getAdministrativeUnitIdentifier(),
        AbstractIdentityDto.JSON_ADMINISTRATIVE_UNIT_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentityDto.JSON_EMAIL_ADDRESS, AbstractIdentityDto.JSON_REGISTRATION_NUMBER,
        AbstractIdentityDto.JSON_FIRST_NAME_AND_LAST_NAMES,
        AbstractIdentityDto.JSON_GENDER_AS_STRING, AbstractIdentityDto.JSON_EMAIL_ADDRESS);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getDataTable().setHeaderRendered(false);
    listController.getDataTable().getOrderNumberColumn().setWidth("50");
    
    listController.getCreateController().setFunction(entity -> {
      IdentityCreateRequestDto request = requestMapper.mapCreate((IdentityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
    listController.getCreateController()
        .addEntityConsumer(entity -> ((IdentityDto) entity).setAdministrativeUnitIdentifier(
            filterController.getFilter().getAdministrativeUnitIdentifier()));

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentityDto.JSON_EMAIL_ADDRESS, AbstractIdentityDto.JSON_REGISTRATION_NUMBER,
            AbstractIdentityDto.JSON_FIRST_NAME, AbstractIdentityDto.JSON_LAST_NAMES,
            AbstractIdentityDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER,
            AbstractIdentityDto.JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER,
            AbstractIdentityDto.JSON_GENDER_IDENTIFIER));
    listController.getUpdateController().addEntityConsumer(entity -> {
      firstName.writeValue(((IdentityDto) entity).getFirstName());
      lastNames.writeValue(((IdentityDto) entity).getLastNames());

      administrativeUnitSelectOneController.getAutoComplete()
          .writeValue(((IdentityDto) entity).getAdministrativeUnitIdentifier());

      registrationNumberGroupSelectOneController.getSelectOneMenu()
          .writeValue(((IdentityDto) entity).getRegistrationNumberGroupIdentifier());

      genderSelectOneController.getSelectOneRadio()
          .writeValue(((IdentityDto) entity).getGenderIdentifier());
    });
    listController.getUpdateController().setFunction(entity -> {
      IdentityUpdateRequestDto request = requestMapper.mapUpdate((IdentityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    firstName = new InputText();
    firstName.outputLabel().setValue("Nom");
    firstName.computePlaceholderFromOutputLabelValue();
    firstName.addValueConsumer(value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(IdentityDto.class).setFirstName(value));

    lastNames = new InputText();
    lastNames.outputLabel().setValue("Prénoms");
    lastNames.computePlaceholderFromOutputLabelValue();
    lastNames.addValueConsumer(value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(IdentityDto.class).setLastNames(value));
  }

  /**
   * Cette méthode permet d'importer.
   */
  public void importAll() {
    IdentityImportAllRequestDto request = new IdentityImportAllRequestDto();
    request.setAuditWho(userIdentifier);
    new ActionExecutor<>(this, "Importation", () -> client.importAll(request)).execute();
  }
}
