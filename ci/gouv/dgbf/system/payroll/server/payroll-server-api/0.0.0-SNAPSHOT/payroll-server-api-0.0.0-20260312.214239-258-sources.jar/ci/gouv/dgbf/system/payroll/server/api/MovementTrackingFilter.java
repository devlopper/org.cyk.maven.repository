package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link MovementTrackingDto}.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
public class MovementTrackingFilter extends AbstractIdentifiableFilter {
  
}
