package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasValueIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ContextualConstantEvaluationGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ContextualConstantEvaluationGroupFilter extends AbstractIdentifiableFilter
    implements FilterHasValueIdentifier {

  /**
   * Identifiant {@link ConditionalValueDto}.
   */
  private String valueIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ContextualConstantEvaluationGroupFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ContextualConstantEvaluationGroupFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateValueIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterValueIdentifier(filter);
  }

}
