package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasArbitratedAmountN2}.
 *
 * @author Christian
 */
public interface HasArbitratedAmountN2Dto extends HasArbitratedAmountN2 {

  /**
   * Identifiant json du montant arbitré à l'horizon N2.
   */
  String JSON_ARBITRATED_AMOUNT_N2 = "montantArbitreN2";
}
