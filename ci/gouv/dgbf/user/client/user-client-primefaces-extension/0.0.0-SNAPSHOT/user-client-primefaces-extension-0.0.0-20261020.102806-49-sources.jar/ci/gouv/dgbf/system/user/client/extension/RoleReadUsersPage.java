package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserRoleDto} d'un {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Named
@ViewScoped
public class RoleReadUsersPage extends AbstractRoleReadDatasPage {

  @Override
  protected String getListPageOutcome() {
    return "roleListPage";
  }

  @Inject
  @Getter
  protected UserRoleController userRoleController;

  @Override
  public void initializeWhenIdentifiableNotNull(RoleDto instance) {
    super.initializeWhenIdentifiableNotNull(instance);
    userRoleController.getFilterController().getFilter()
        .setRoleIdentifier(role.getIdentifier());
    userRoleController.initialize();
  }

  /**
   * Cas de navigation.
   */
  public static final String OUTCOME = "roleReadUsersPage";
}
