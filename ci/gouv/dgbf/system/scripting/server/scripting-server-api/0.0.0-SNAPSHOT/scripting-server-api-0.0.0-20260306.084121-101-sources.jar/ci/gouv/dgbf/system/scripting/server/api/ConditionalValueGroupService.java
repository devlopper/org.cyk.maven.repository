package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueRetrievalStrategy;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueRetrievalStrategyDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ConditionalValueGroupDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ConditionalValueGroupService.PATH)
@Tag(name = "Gestion des groupes de valeur conditionnées")
public interface ConditionalValueGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-valeurs-conditionnees";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ConditionalValueGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description description
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir {@link ValueType}.
     *
     * @return {@link ValueType}
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner {@link ValueType}.
     *
     * @param valueType {@link ValueType}
     */
    void setValueType(ValueType valueType);

    /**
     * Cette méthode permet d'obtenir la valeur par défaut.
     *
     * @return valeur par défaut
     */
    String getDefaultValue();

    /**
     * Cette méthode permet d'assigner la valeur par défaut.
     *
     * @param value valeur par défaut
     */
    void setDefaultValue(String value);

    /**
     * Cette méthode permet d'obtenir la stratégie de récupération de valeur.
     *
     * @return stratégie de récupération de valeur
     */
    ValueRetrievalStrategy getValueRetrievalStrategy();

    /**
     * Cette méthode permet d'assigner la stratégie de récupération de valeur.
     *
     * @param valueRetrievalStrategy stratégie de récupération de valeur
     */
    void setValueRetrievalStrategy(ValueRetrievalStrategy valueRetrievalStrategy);

    /**
     * {@link HasDescriptionDto#JSON_DESCRIPTION}.
     */
    String JSON_DESCRIPTION = HasDescriptionDto.JSON_DESCRIPTION;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;

    /**
     * {@link HasDefaultValueDto#JSON_DEFAULT_VALUE}.
     */
    String JSON_DEFAULT_VALUE = HasDefaultValueDto.JSON_DEFAULT_VALUE;

    /**
     * {@link HasValueRetrievalStrategyDto#JSON_VALUE_RETRIEVAL_STRATEGY}.
     */
    String JSON_VALUE_RETRIEVAL_STRATEGY =
        HasValueRetrievalStrategyDto.JSON_VALUE_RETRIEVAL_STRATEGY;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ConditionalValueGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ConditionalValueGroupSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_DEFAULT_VALUE)
    private String defaultValue;

    @JsonbProperty(JSON_VALUE_RETRIEVAL_STRATEGY)
    private ValueRetrievalStrategy valueRetrievalStrategy;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ConditionalValueGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ConditionalValueGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ConditionalValueGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ConditionalValueGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConditionalValueGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConditionalValueGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ConditionalValueGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ConditionalValueGroupSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_DEFAULT_VALUE)
    private String defaultValue;

    @JsonbProperty(JSON_VALUE_RETRIEVAL_STRATEGY)
    private ValueRetrievalStrategy valueRetrievalStrategy;
  }

  /**
   * Identifiant du service d'obtention de la valeur applicable.
   */
  String GET_APPLICABLE_VALUE_IDENTIFIER = "OBTENIR_VALEUR_APPLICABLE_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention de la valeur applicable.
   */
  String GET_APPLICABLE_VALUE_PATH = "obtention/valeur-applicable";

  /**
   * Cette méthode permet de d'obtenir la valeur applicable.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_APPLICABLE_VALUE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_APPLICABLE_VALUE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = ConditionalValueGroupGetApplicableValueResponseDto.class))})
  Response getApplicableValue(ConditionalValueGroupGetApplicableValueRequestDto request);

  /**
   * Cette classe représente la requête de vérification d'applicabilité.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueGroupGetApplicableValueRequestDto extends ByIdentifierRequestDto
      implements HasValuesMapDto<String, Object> {

    /**
     * Valeur de filtre.
     */
    @JsonbProperty(JSON_FILTER_VALUE)
    private String filterValue;

    @JsonbProperty(JSON_VALUES_MAP)
    private Map<String, Object> valuesMap;
    
    /**
     * Identifiant json {@link #filterValue}.
     */
    public static final String JSON_FILTER_VALUE = "filterValue";
  }

  /**
   * Cette classe représente la réponse de vérification d'applicabilité.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueGroupGetApplicableValueResponseDto extends IdentifiableResponseDto
      implements HasStringValueDto, HasValueTypeDto {

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConditionalValueGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
