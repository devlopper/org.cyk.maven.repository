package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ResourceType}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceTypeSelectOneController
    extends AbstractSelectOneEnumerationController<ResourceType> {

  /**
   * Cette méthode permet de construire.
   */
  protected ResourceTypeSelectOneController() {
    super(ResourceType.values());
    outputLableValue = "Type de ressource";
  }
}

