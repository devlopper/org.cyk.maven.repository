package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant arbitré à l'horizon N2.
 *
 * @author Christian
 */
public interface HasArbitratedAmountN2 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant arbitré à l'horizon N2.
   *
   * @return le montant arbitré à l'horizon N2
   */
  Long getArbitratedAmountN2();

  /**
   * Cette méthode permet d'assigner le montant arbitré à l'horizon N2.
   *
   * @param amount le montant arbitré à l'horizon N2
   */
  void setArbitratedAmountN2(Long amount);

  /**
   * Identifiant java du montant arbitré à l'horizon N2.
   */
  String FIELD_ARBITRATED_AMOUNT_N2 = "arbitratedAmountN2";
}
