package ci.gouv.dgbf.system.budgetaryclassification.client.extension.act;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExerciseClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExerciseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExerciseService.ExerciseGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ExerciseDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ExerciseSelectOneController extends AbstractSelectOneIdentifiableController<
    ExerciseDto, ExerciseGetManyResponseDto, ExerciseClient> {

  @Inject
  @Getter
  ExerciseClient client;

  protected ExerciseSelectOneController() {
    super(ExerciseDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
