package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.primefaces.AbstractActionController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur de création ou de modification.
 *
 * @author Christian
 *
 */
public abstract class AbstractCreateOrUpdateController<T, R> extends AbstractActionController<R> {

  @Getter
  @Setter
  protected T entity;

  @Getter
  Consumer<T> entityConsumer;

  /**
   * Cette méthode permet d'ajouter un consommateur d'entité.
   *
   * @param consumer consommateur
   */
  public void addEntityConsumer(Consumer<T> consumer) {
    if (consumer != null) {
      if (entityConsumer == null) {
        entityConsumer = consumer;
      } else {
        entityConsumer = entityConsumer.andThen(consumer);
      }
    }
  }

  /**
   * Cette méthode permet de consommer l'entité.
   */
  public void consumeEntity() {
    validateEntity();
    if (entityConsumer != null) {
      entityConsumer.accept(entity);
    }
  }

  /**
   * Cette méthode permet d'exécuter.
   *
   * @return navigation
   */
  public String execute() {
    return new ActionExecutor<String>(this, name, () -> {
      validateEntity();
      R response = doExecute();
      processResponse(response);
      updateComponents();
      publishNotification(response);
      return navigate(response);
    }).execute();
  }

  protected void validateEntity() {
    if (entity == null) {
      throw new IllegalStateException("L'entité ne doit pas être nulle");
    }
  }

  public abstract boolean isCreate();

  protected abstract R doExecute();
}
