package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringArgumentsDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatArgumentsFormatAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatArgumentsFormatDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatResultFormatAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatResultFormatDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringResultDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un log d'opération d'enregistrement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RecordOperationDto extends AbstractIdentifiableAuditableDto
    implements HasProcessIdentifierDto, HasProcessAsStringDto, HasSourceIdentifierDto,
    HasSourceAsStringDto, HasRecordIdentifierDto, HasRecordAsStringDto, HasOperationIdentifierDto,
    HasOperationAsStringDto, HasStringArgumentsDto, HasStringFormatArgumentsFormatDto,
    HasStringFormatArgumentsFormatAsStringDto, HasStringResultDto, HasStringFormatResultFormatDto,
    HasStringFormatResultFormatAsStringDto, HasMessageDto {

  // Process
  
  @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  @JsonbProperty(value = JSON_PROCESS_AS_STRING)
  private String processAsString;

  // Source
  
  @JsonbProperty(value = JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(value = JSON_SOURCE_AS_STRING)
  private String sourceAsString;

  // Record
  
  @JsonbProperty(value = JSON_RECORD_IDENTIFIER)
  private String recordIdentifier;

  @JsonbProperty(value = JSON_RECORD_AS_STRING)
  private String recordAsString;

  // Operation
  
  @JsonbProperty(value = JSON_OPERATION_IDENTIFIER)
  private String operationIdentifier;

  @JsonbProperty(value = JSON_OPERATION_AS_STRING)
  private String operationAsString;

  // Arguments

  @JsonbProperty(value = JSON_ARGUMENTS)
  private String arguments;

  @JsonbProperty(value = JSON_ARGUMENTS_FORMAT)
  private StringFormat argumentsFormat;

  @JsonbProperty(value = JSON_ARGUMENTS_FORMAT_AS_STRING)
  private String argumentsFormatAsString;

  // Result

  @JsonbProperty(value = JSON_RESULT)
  private String result;

  @JsonbProperty(value = JSON_RESULT_FORMAT)
  private StringFormat resultFormat;

  @JsonbProperty(value = JSON_RESULT_FORMAT_AS_STRING)
  private String resultFormatAsString;

  @JsonbProperty(value = JSON_MESSAGE)
  private String message;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idOperationEnregistrement";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "operationEnregistrementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "opération d'enregistrement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "opérations d'enregistrement";
}
