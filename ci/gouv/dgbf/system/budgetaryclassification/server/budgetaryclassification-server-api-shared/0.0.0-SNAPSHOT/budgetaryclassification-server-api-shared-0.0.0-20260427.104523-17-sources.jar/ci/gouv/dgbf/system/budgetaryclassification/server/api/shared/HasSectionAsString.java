package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * section.
 *
 * @author Christian
 */
public interface HasSectionAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de section.
   *
   * @return représentation en chaine de caractères de section
   */
  String getSectionAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de section.
   *
   * @param asString représentation en chaine de caractères de section
   */
  void setSectionAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de section.
   */
  String FIELD_SECTION_AS_STRING = "sectionAsString";
}
