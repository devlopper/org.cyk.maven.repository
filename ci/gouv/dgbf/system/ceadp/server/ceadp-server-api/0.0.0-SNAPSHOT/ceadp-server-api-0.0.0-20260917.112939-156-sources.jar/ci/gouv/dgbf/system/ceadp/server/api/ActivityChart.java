package ci.gouv.dgbf.system.ceadp.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques de {@link ActivityDto}.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum ActivityChart {

  /**
   * Compte des statuts des {@link ActivityDto}.
   */
  ACTIVITY_STATUS_COUNTS(ActivityChartCode.ACTIVITY_STATUS_COUNTS,
      "Situation %s".formatted(ActivityDto.PLURAL_NAME)),

  /**
   * Compte des statuts des {@link TaskDto}.
   */
  TASK_STATUS_COUNTS(ActivityChartCode.TASK_STATUS_COUNTS,
      "Nombre %s par %s".formatted(TaskDto.PLURAL_NAME, ActivityDto.NAME));

  /**
   * Code.
   */
  String code;

  String name;

  /**
   * Cette méthode permet d'obtenir {@link ActivityChart} par code.
   *
   * @param code code
   * @return statut
   */
  public static ActivityChart getByCode(String code) {
    return Stream.of(ActivityChart.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElse(null);
  }
}
