package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryClient;
import ci.gouv.dgbf.system.functionary.server.api.CategoryDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService.CategoryCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService.CategoryUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link CategoryDto}.
 *
 * @author akm
 *
 */
@Dependent
public class CategoryController extends AbstractController {

  @Inject
  CategoryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  CategoryFilterController filterController;

  @Inject
  CategoryRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;



  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = CategoryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(CategoryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(CategoryService.PATH);

    listController.getDataTable().getFilterButton().setRendered(true);

    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME);

    projection.addNamesIfStringBlank(filterController.getFilter()
        .getCivilServiceStatusIdentifier(),
        CategoryDto.JSON_CIVIL_SERVICE_STATUS_AS_STRING);

    listController.getReadController().setProjection(projection);

    civilServiceStatusSelectOneController.setRenderable(StringCore.isBlank(filterController
        .getFilter().getCivilServiceStatusIdentifier()));

    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());

    listController.getCreateController().setFunction(entity -> {
      CategoryCreateRequestDto request = requestMapper.mapCreate((CategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            CategoryDto.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    civilServiceStatusSelectOneController.getSelectOneMenu().setRequired(true);
    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(civilServiceStatusIdentifierConsumer());

  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {

      ((CategoryDto) entity).setCivilServiceStatusIdentifier(filterController.getFilter()
          .getCivilServiceStatusIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {

      codeInputTextController.getInputText().writeValue(((CategoryDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((CategoryDto) entity).getName());
      civilServiceStatusSelectOneController.getSelectOneMenu()
          .writeValue(((CategoryDto) entity).getCivilServiceStatusIdentifier());
    };
  }

  Consumer<String> civilServiceStatusIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(CategoryDto.class)
        .setCivilServiceStatusIdentifier(identifier);
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(
        CategoryDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(
        CategoryDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      CategoryUpdateRequestDto request = requestMapper.mapUpdate((CategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des
   * messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
