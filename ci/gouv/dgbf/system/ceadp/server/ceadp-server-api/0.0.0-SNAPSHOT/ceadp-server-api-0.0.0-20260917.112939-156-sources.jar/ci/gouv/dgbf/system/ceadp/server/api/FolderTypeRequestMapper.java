package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.FolderTypeService.FolderTypeCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderTypeService.FolderTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FolderTypeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FolderTypeDto}.

    @author Christian
               """)
public interface FolderTypeRequestMapper
    extends RequestMapper<FolderTypeDto, FolderTypeCreateRequestDto, FolderTypeUpdateRequestDto> {

}
