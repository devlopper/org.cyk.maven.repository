package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentGroupDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentGroupDto}.

    @author Christian
               """)
public interface DocumentGroupRequestMapper
    extends RequestMapper<DocumentGroupDto, DocumentGroupCreateRequestDto,
        DocumentGroupUpdateRequestDto> {

}
