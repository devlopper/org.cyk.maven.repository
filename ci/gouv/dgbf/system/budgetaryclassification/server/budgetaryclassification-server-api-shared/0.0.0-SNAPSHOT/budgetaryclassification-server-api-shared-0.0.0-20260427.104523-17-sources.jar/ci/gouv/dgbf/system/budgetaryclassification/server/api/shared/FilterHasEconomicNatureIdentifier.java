package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de la nature economique.
 *
 * @author Arnaud
 */
public interface FilterHasEconomicNatureIdentifier extends HasEconomicNatureIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant nature economique.
   *
   * @param filter {@link FilterDto}
   */
  default void updateEconomicNatureIdentifier(FilterDto filter) {
    setEconomicNatureIdentifier(EconomicNatureIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant nature economique de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterEconomicNatureIdentifier(FilterDto filter) {
    EconomicNatureIdentifierFilter.set(filter, getEconomicNatureIdentifier());
  }

}
