package ci.gouv.dgbf.system.servicecatalog.client.extension.representation;

import ci.gouv.dgbf.extension.primefaces.component.output.BooleanTagRepresentation;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la pastille de l'accès public d'un processus (RG_SVC_VIS_04) : « Sans
 * connexion » (Portail public) ou « Connexion requise ». Libellés et icônes repris de la section
 * « Repères visuels » du lexique de la conception ; indicateur à deux valeurs, donc aucun ton
 * (constitution-ui.md §3.3.1) : gravité « secondary », rendue en neutral par la charte. Utilisée
 * par le fragment {@code /servicecatalog/component/output/publicAccess.xhtml} en liste comme en
 * fiche.
 *
 * @author Christian
 */
@ApplicationScoped
@Named("publicAccessRepresentation")
public class PublicAccessRepresentation extends BooleanTagRepresentation {

  public static final String TRUE_LABEL = "Sans connexion";
  public static final String FALSE_LABEL = "Connexion requise";

  /**
   * Constructeur.
   */
  public PublicAccessRepresentation() {
    super(TRUE_LABEL, FALSE_LABEL, "pi pi-globe", "pi pi-lock", "secondary", "secondary");
  }
}
