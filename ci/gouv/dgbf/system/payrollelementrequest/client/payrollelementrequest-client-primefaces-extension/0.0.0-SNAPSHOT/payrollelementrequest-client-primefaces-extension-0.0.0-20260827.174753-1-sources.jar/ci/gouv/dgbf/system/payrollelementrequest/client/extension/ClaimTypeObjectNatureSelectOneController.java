package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente le contrôleur de sélection de la nature de l'objet ciblé par un
 * Rattachement. Restreint à Élément de Paie/Constante de Paie (contrainte
 * {@code TA_TYPE_RECLAMATION_OBJET_NATURE_CK}) -- un Poste ne peut être que la cible d'un Effet
 * Attendu, voir {@link ObjectNatureSelectOneController}.
 *
 * @author akm
 *
 */
@Dependent
public class ClaimTypeObjectNatureSelectOneController extends AbstractSelectOneController {

  protected ClaimTypeObjectNatureSelectOneController() {
    outputLableValue = "Nature de l'objet";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem("ELEMENT_PAIE", "Element de Paie"),
        new SelectItem("CONSTANTE_PAIE", "Constante de Paie"));
  }
}
