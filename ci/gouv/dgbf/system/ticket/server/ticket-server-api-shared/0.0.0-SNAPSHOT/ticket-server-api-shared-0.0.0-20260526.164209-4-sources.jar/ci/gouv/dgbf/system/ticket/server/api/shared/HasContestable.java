package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être contesté.
 *
 * @author Christian
 */
public interface HasContestable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être contesté.
   *
   * @return peut être contesté
   */
  Boolean getContestable();

  /**
   * Cette méthode permet d'assigner peut être contesté.
   *
   * @param contestable peut être contesté
   */
  void setContestable(Boolean contestable);

  /**
   * Identifiant java de peut être contesté.
   */
  String FIELD_CONTESTABLE = "contestable";
}