package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente un contrôleur de d'entrée de nombre.
 *
 * @author Christian
 *
 */
@Dependent
public class InputNumberController extends AbstractInputController {

  /* Controls */

  protected InputInteger inputInteger;
  protected InputLong inputLong;
  protected InputFloat inputFloat;
  protected InputBigDecimal inputBigDecimal;

  /*------------------------------ Input Integer ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputInteger}.
   *
   * @return {@link InputInteger}
   */
  public InputInteger getInputInteger() {
    if (!initialized) {
      Core.runIfNull(inputInteger, () -> inputInteger = instantiateInputInteger());
      initialized = true;
    }
    return inputInteger;
  }

  protected InputInteger instantiateInputInteger() {
    InputInteger selector = new InputInteger();
    processInputInteger(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processInputInteger(InputInteger inputInteger) {
    processInput(inputInteger);
  }

  /*------------------------------ Input Long ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputLong}.
   *
   * @return {@link InputLong}
   */
  public InputLong getInputLong() {
    if (!initialized) {
      Core.runIfNull(inputLong, () -> inputLong = instantiateInputLong());
      initialized = true;
    }
    return inputLong;
  }

  protected InputLong instantiateInputLong() {
    InputLong selector = new InputLong();
    processInputLong(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processInputLong(InputLong inputLong) {
    processInput(inputLong);
  }

  /*------------------------------ Input Float ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputFloat}.
   *
   * @return {@link InputFloat}
   */
  public InputFloat getInputFloat() {
    if (!initialized) {
      Core.runIfNull(inputFloat, () -> inputFloat = instantiateInputFloat());
      initialized = true;
    }
    return inputFloat;
  }

  protected InputFloat instantiateInputFloat() {
    InputFloat selector = new InputFloat();
    processInputFloat(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processInputFloat(InputFloat inputFloat) {
    processInput(inputFloat);
  }

  /*------------------------------ Input BigDecimal ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputBigDecimal}.
   *
   * @return {@link InputBigDecimal}
   */
  public InputBigDecimal getInputBigDecimal() {
    if (!initialized) {
      Core.runIfNull(inputBigDecimal, () -> inputBigDecimal = instantiateInputBigDecimal());
      initialized = true;
    }
    return inputBigDecimal;
  }

  protected InputBigDecimal instantiateInputBigDecimal() {
    InputBigDecimal selector = new InputBigDecimal();
    processInputBigDecimal(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processInputBigDecimal(InputBigDecimal inputBigDecimal) {
    processInput(inputBigDecimal);
  }
}
