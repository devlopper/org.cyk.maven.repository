package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion de diagnostique.
 *
 * @author Christian
 */
public interface HasDiagnosticDto extends HasDiagnostic {
  
  /**
   * Identifiant json du diagnostique.
   */
  String JSON_DIAGNOSTIC = "diagnostique";
}
