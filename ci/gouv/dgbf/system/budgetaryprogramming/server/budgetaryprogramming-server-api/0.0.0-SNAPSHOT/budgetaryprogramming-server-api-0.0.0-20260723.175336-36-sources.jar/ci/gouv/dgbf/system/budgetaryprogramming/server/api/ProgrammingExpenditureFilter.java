package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasActivityIdentifier;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasExpenditureIdentifier;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasProgrammingIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProgrammingExpenditureDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ProgrammingExpenditureFilter extends AbstractIdentifiableFilter implements
    FilterHasProgrammingIdentifier, FilterHasExpenditureIdentifier, FilterHasActivityIdentifier {

  String programmingIdentifier;

  String expenditureIdentifier;

  String activityIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateProgrammingIdentifier(filter);
    updateExpenditureIdentifier(filter);
    updateActivityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterProgrammingIdentifier(filter);
    updateFilterExpenditureIdentifier(filter);
    updateFilterActivityIdentifier(filter);
  }

}
