package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobService.PayrollJobGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollJobDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PayrollJobSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollJobDto, PayrollJobGetManyResponseDto, PayrollJobClient> {

  @Inject
  @Getter
  PayrollJobClient client;

  protected PayrollJobSelectOneController() {
    super(PayrollJobDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
