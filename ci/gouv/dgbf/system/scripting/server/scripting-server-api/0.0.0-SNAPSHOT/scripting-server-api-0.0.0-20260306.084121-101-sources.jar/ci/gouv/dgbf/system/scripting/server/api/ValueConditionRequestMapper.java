package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionUpdateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionVerifyRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueConditionDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueConditionDto}.

    @author Christian
               """)
public interface ValueConditionRequestMapper extends RequestMapper<ValueConditionDto,
    ValueConditionCreateRequestDto, ValueConditionUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper.
   *
   * @param valueCondition {@link ValueConditionDto}
   * @return {@link ValueConditionVerifyRequestDto}
   */
  ValueConditionVerifyRequestDto mapVerify(ValueConditionDto valueCondition);
}
