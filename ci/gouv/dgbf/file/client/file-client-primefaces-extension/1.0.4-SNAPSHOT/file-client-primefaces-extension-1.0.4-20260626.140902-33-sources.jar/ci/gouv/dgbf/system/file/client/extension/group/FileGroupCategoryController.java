package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.client.extension.file.FileCategorySelectOneController;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FileGroupCategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupCategoryController extends AbstractController {

  @Inject
  FileGroupCategoryClient client;

  @Inject
  FileGroupCategoryRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  FileGroupSelectOneController fileGroupSelectOneController;

  @Inject
  @Getter
  FileCategorySelectOneController categorySelectOneController;

  @Inject
  @Getter
  FileGroupCategoryFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FileGroupCategoryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FileGroupCategoryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileGroupCategoryService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getFileGroupIdentifier(),
        FileGroupCategoryDto.JSON_FILE_GROUP_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getCategoryIdentifier(),
        FileGroupCategoryDto.JSON_CATEGORY_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    /* Creation */

    listController.getCreateController().addEntityConsumer(entity -> {
      ((FileGroupCategoryDto) entity)
          .setFileGroupIdentifier(filterController.getFilter().getFileGroupIdentifier());
      ((FileGroupCategoryDto) entity)
          .setCategoryIdentifier(filterController.getFilter().getCategoryIdentifier());
    });
    listController.getCreateController().setFunction(entity -> {
      FileGroupCategoryCreateRequestDto request =
          requestMapper.mapCreate((FileGroupCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });


    /* Update */

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            FileGroupCategoryDto.JSON_FILE_GROUP_IDENTIFIER,
            FileGroupCategoryDto.JSON_CATEGORY_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(entity -> {
      fileGroupSelectOneController.getSelectOneMenu()
          .writeValue(((FileGroupCategoryDto) entity).getFileGroupIdentifier());

      categorySelectOneController.getSelectOneMenu()
          .writeValue(((FileGroupCategoryDto) entity).getCategoryIdentifier());
    });

    listController.getUpdateController().setFunction(entity -> {
      FileGroupCategoryUpdateRequestDto request =
          requestMapper.mapUpdate((FileGroupCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */

    fileGroupSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, FileGroupCategoryDto.JSON_FILE_GROUP_AS_STRING);


    fileGroupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(FileGroupCategoryDto.class)
            .setFileGroupIdentifier(identifier));

    categorySelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, FileGroupCategoryDto.JSON_CATEGORY_AS_STRING);

    categorySelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(FileGroupCategoryDto.class)
            .setCategoryIdentifier(identifier));
  }
}
