package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ExpenditureService.ExpenditureCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ExpenditureService.ExpenditureGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ExpenditureService.ExpenditureUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ExpenditureDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class ExpenditureClient extends AbstractClient<ExpenditureService>
    implements GetByIdentifier<ExpenditureDto>,
           GetMany<ExpenditureGetManyResponseDto>,
           DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ExpenditureService}
   * @return client {@link ExpenditureClient}
   */
  @Override
  public ExpenditureClient service(ExpenditureService service) {
    return (ExpenditureClient) super.service(service);
  }

  /**
   * {@link ExpenditureService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ExpenditureCreateRequestDto request) {
    return new CreateExecutor(ExpenditureService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ExpenditureService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpenditureGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ExpenditureGetManyResponseDto>(
        ExpenditureGetManyResponseDto.class,
        ExpenditureService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ExpenditureService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpenditureGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ExpenditureService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpenditureDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ExpenditureDto>(ExpenditureDto.class,
        ExpenditureService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ExpenditureService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpenditureDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ExpenditureDto>(ExpenditureDto.class,
        ExpenditureService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ExpenditureService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ExpenditureUpdateRequestDto request) {
    return new IdentifiableExecutor(ExpenditureService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ExpenditureService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ExpenditureService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
