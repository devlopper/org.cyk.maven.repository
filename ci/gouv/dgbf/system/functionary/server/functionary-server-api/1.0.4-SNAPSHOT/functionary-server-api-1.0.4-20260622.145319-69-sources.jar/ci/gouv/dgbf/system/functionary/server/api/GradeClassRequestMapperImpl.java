package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link GradeClassDto}.
*
* @author Stéphane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class GradeClassRequestMapperImpl implements GradeClassRequestMapper {

    @Override
    public GradeClassService.GradeClassCreateRequestDto mapCreate(GradeClassDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GradeClassService.GradeClassCreateRequestDto gradeClassCreateRequestDto = new GradeClassService.GradeClassCreateRequestDto();

        gradeClassCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        gradeClassCreateRequestDto.setCode( arg0.getCode() );
        gradeClassCreateRequestDto.setName( arg0.getName() );
        gradeClassCreateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return gradeClassCreateRequestDto;
    }

    @Override
    public GradeClassService.GradeClassUpdateRequestDto mapUpdate(GradeClassDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GradeClassService.GradeClassUpdateRequestDto gradeClassUpdateRequestDto = new GradeClassService.GradeClassUpdateRequestDto();

        gradeClassUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        gradeClassUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        gradeClassUpdateRequestDto.setCode( arg0.getCode() );
        gradeClassUpdateRequestDto.setName( arg0.getName() );
        gradeClassUpdateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return gradeClassUpdateRequestDto;
    }
}
