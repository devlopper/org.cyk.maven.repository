package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a filtre par identifiant de verrou d'imputation.
 *
 * @author Christian
 */
public interface FilterHasImputationLockIdentifier extends HasImputationLockIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du verrou d'imputation.
   *
   * @param filter {@link FilterDto}
   */
  default void updateImputationLockIdentifier(FilterDto filter) {
    setImputationLockIdentifier(ImputationLockIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du verrou d'imputation de {@link FilterDto}
   * .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterImputationLockIdentifier(FilterDto filter) {
    ImputationLockIdentifierFilter.set(filter, getImputationLockIdentifier());
  }

}
