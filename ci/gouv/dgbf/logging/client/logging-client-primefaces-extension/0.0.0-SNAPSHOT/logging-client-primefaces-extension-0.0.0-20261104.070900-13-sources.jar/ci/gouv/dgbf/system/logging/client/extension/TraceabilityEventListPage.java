package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/** Page de consultation du journal transverse. */
@Named
@ViewScoped
public class TraceabilityEventListPage extends AbstractPage {

  @Inject @Getter TraceabilityEventController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Événements de traçabilité";
    controller.initialize();
  }

  /** Identifiant de navigation. */
  public static final String OUTCOME = "traceabilityEventListPage";
}
