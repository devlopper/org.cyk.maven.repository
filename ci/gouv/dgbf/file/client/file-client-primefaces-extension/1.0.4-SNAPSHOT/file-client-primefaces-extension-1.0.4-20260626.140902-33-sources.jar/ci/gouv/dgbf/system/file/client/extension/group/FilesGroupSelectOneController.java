package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FilesGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<FilesGroupDto,
        FilesGroupGetManyResponseDto, FilesGroupClient> {

  @Inject
  @Getter
  FilesGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FilesGroupSelectOneController() {
    super(FilesGroupDto.class);
  }
}
