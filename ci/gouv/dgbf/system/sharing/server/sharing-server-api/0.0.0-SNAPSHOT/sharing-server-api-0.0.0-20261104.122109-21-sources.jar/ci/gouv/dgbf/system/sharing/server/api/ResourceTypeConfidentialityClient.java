package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityGetManyResponseDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/** Client REST de la confidentialite par type. */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ResourceTypeConfidentialityClient
    extends AbstractClient<ResourceTypeConfidentialityService>
    implements GetByIdentifier<ResourceTypeConfidentialityDto>,
    GetMany<ResourceTypeConfidentialityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {
  @Override
  public ResourceTypeConfidentialityClient service(ResourceTypeConfidentialityService service) {
    return (ResourceTypeConfidentialityClient) super.service(service);
  }

  /** Cree une classification. */
  public CreateResponseDto create(ResourceTypeConfidentialityCreateRequestDto request) {
    return new CreateExecutor(ResourceTypeConfidentialityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /** Obtient une page de classifications. */
  public ResourceTypeConfidentialityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ResourceTypeConfidentialityGetManyResponseDto>(
        ResourceTypeConfidentialityGetManyResponseDto.class,
        ResourceTypeConfidentialityService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /** Obtient une page de classifications avec des parametres simples. */
  @Override
  public ResourceTypeConfidentialityGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /** Obtient une classification selon un filtre. */
  public ResourceTypeConfidentialityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ResourceTypeConfidentialityDto>(ResourceTypeConfidentialityDto.class,
        ResourceTypeConfidentialityService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /** Obtient une classification par identifiant. */
  public ResourceTypeConfidentialityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ResourceTypeConfidentialityDto>(ResourceTypeConfidentialityDto.class,
        ResourceTypeConfidentialityService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /** Obtient une classification par identifiant avec ses parametres. */
  @Override
  public ResourceTypeConfidentialityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /** Met a jour une classification. */
  public IdentifiableResponseDto update(ResourceTypeConfidentialityUpdateRequestDto request) {
    return new IdentifiableExecutor(ResourceTypeConfidentialityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /** Supprime une classification. */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ResourceTypeConfidentialityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /** Supprime une classification par identifiant. */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
