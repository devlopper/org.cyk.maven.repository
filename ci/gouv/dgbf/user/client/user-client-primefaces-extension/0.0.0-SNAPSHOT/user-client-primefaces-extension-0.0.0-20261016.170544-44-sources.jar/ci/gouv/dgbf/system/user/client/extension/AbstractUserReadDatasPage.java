package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages de consultation de {@link UserDto}.
 *
 * @author BoobaCool
 */
public abstract class AbstractUserReadDatasPage extends AbstractPage {

  @Inject
  protected UserClient client;

  @Getter
  protected UserDto user;

  @Getter
  protected LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  protected IconManager iconManager;

  @Inject
  @Getter
  protected UserTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + UserDto.NAME;
    String identifier = getRequestParameterIdentifier();

    user = client.getByIdentifier(identifier, instantiateProjection(), userIdentifier, null);

    buildLabelValueGroupsInformationCard();

    tabMenuController.setInstance(user);
    tabMenuController.initialize();
  }

  protected void buildLabelValueGroupsInformationCard() {
    UserLabelValueGroupsInformationCardBuilder builder =
        new UserLabelValueGroupsInformationCardBuilder(iconManager);
    builder.name(user.getName()).identity(user.getIdentityAsString())
        .domain(user.getDomainAsString()).roleCount(user.getRoleCountAsString())
        .pendingRoleSolicitationCount(user.getPendingRoleSolicitationCountAsString());
    labelValueGroupsInformationCard = builder.build();
  }

  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME, UserDto.JSON_IDENTITY_AS_STRING,
        UserDto.JSON_DOMAIN_AS_STRING,
        // Nombres de la fiche (RU_UTI_027)
        UserDto.JSON_ROLE_COUNT_AS_STRING, UserDto.JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING);
  }
}
