package ci.gouv.dgbf.system.user.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class IconManager {

  String user;


  /**
   * Cette méthode permet d'instancier.
   */
  public IconManager() {

    user = "pi pi-user";
  }
}
