package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimTypeObjectDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimTypeObjectFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Nature de l'objet ciblé.
   */
  String objectNature;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimTypeObjectFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimTypeObjectFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    objectNature = getObjectNature(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setObjectNature(filter, objectNature);
  }

  /**
   * Cette méthode permet d'assigner la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @param objectNature nature de l'objet ciblé
   */
  public static void setObjectNature(FilterDto filter, String objectNature) {
    set(filter, JSON_OBJECT_NATURE, f -> f.getValueAsString(),
        f -> f.setValueAsString(objectNature));
  }

  /**
   * Cette méthode permet d'obtenir la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @return nature de l'objet ciblé
   */
  public static String getObjectNature(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_OBJECT_NATURE));
  }

  /**
   * Identifiant json champ {@link #objectNature}.
   */
  public static final String JSON_OBJECT_NATURE = ClaimTypeObjectDto.JSON_OBJECT_NATURE;
}
