package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une nature dépense.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureNatureDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link ExpenditureNatureDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idNatureDepense";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExpenditureNatureDto}.
   */
  public static final String JSON_THIS_AS_STRING = "natureDepenseChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "nature depense";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "natures dépense";
}
