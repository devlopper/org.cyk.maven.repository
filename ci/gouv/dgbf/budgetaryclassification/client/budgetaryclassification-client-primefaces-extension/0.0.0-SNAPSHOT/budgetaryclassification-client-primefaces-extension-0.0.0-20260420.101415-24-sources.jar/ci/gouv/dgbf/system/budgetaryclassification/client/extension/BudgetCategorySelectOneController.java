package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetCategoryClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetCategoryDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetCategoryService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link BudgetCategoryDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class BudgetCategorySelectOneController extends AbstractSelectOneIdentifiableController<
    BudgetCategoryDto, GetManyResponseDto, BudgetCategoryClient> {

  @Inject
  @Getter
  BudgetCategoryClient client;

  protected BudgetCategorySelectOneController() {
    super(BudgetCategoryDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
