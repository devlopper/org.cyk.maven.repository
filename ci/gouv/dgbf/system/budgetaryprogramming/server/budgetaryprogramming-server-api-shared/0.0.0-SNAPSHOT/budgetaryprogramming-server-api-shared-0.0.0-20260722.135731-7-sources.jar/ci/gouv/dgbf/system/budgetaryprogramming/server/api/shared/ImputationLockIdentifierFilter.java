package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Interface représentant un filtre basé sur la notion d'identifiant de verrou d'imputation.
 *
 * @author Christian
 */
public interface ImputationLockIdentifierFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir l'identifiant du verrou d'imputation.
   *
   * @param filter {@link FilterDto}
   * @return identifiant de l'intervalle
   */
  public static String get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du verrou d'imputation.
   *
   * @param filter {@link FilterDto}
   * @param identifier identifiant de l'intervalle
   */
  public static void set(FilterDto filter, String identifier) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = HasImputationLockIdentifierDto.JSON_IMPUTATION_LOCK_IDENTIFIER;


}

