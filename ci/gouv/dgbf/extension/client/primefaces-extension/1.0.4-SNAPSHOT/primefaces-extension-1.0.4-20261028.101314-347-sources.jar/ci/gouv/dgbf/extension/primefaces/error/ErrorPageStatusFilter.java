package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cette classe donne à une page d'erreur du socle le code HTTP qu'elle porte.
 *
 * <p>Un refus de {@code quarkus.http.auth.permission.*} est décidé avant le conteneur servlet : la
 * requête est réacheminée vers la page 403 sans passer par {@code sendError}, et le conteneur
 * répondait alors 200. Le code est donc fixé à l'entrée de la page elle-même.
 *
 * @author Christian
 */
public class ErrorPageStatusFilter extends HttpFilter {
  private static final long serialVersionUID = 1L;

  private static final Pattern PAGE =
      Pattern.compile("/extension/public/error/(403|404|500)\\.xhtml$");

  @Override
  protected void doFilter(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws IOException, ServletException {
    Matcher matcher = PAGE.matcher(request.getRequestURI());
    if (matcher.find()) {
      response.setStatus(Integer.parseInt(matcher.group(1)));
    }
    chain.doFilter(request, response);
  }
}
