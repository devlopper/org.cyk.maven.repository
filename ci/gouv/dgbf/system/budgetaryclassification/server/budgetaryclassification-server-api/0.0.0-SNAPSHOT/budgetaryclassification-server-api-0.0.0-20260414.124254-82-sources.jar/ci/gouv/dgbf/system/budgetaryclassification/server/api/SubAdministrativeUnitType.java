package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types de sous-unité administrative.
 *
 * @author stephane
 *
 */
@Getter
public enum SubAdministrativeUnitType {

  /**
   * Organisationnel.
   */
  ORGANIZATIONAL(SubAdministrativeUnitTypeCode.ORGANIZATIONAL, "ORGANISATIONNEL"),
  
  /**
   * Fonctionnel.
   */
  FUNCTIONAL(SubAdministrativeUnitTypeCode.FUNCTIONAL, "FONCTIONNEL")
  
  ;
  
  private SubAdministrativeUnitType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le type de sous unité administrative par code.
   *
   * @param code code
   * @return type sous unité administrative
   */
  public static SubAdministrativeUnitType getByCode(String code) {
    return Stream.of(SubAdministrativeUnitType.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
