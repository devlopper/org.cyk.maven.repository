package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DictionaryDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T08:22:18+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DictionaryRequestMapperImpl implements DictionaryRequestMapper {

    @Override
    public DictionaryService.DictionaryCreateRequestDto mapCreate(DictionaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryService.DictionaryCreateRequestDto dictionaryCreateRequestDto = new DictionaryService.DictionaryCreateRequestDto();

        dictionaryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        dictionaryCreateRequestDto.setCode( arg0.getCode() );
        dictionaryCreateRequestDto.setName( arg0.getName() );
        dictionaryCreateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );

        return dictionaryCreateRequestDto;
    }

    @Override
    public DictionaryService.DictionaryUpdateRequestDto mapUpdate(DictionaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryService.DictionaryUpdateRequestDto dictionaryUpdateRequestDto = new DictionaryService.DictionaryUpdateRequestDto();

        dictionaryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        dictionaryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        dictionaryUpdateRequestDto.setCode( arg0.getCode() );
        dictionaryUpdateRequestDto.setName( arg0.getName() );
        dictionaryUpdateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );

        return dictionaryUpdateRequestDto;
    }
}
