package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link LocalityDto}.
*
* @author arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class LocalityGroupRequestMapperImpl implements LocalityGroupRequestMapper {

    @Override
    public LocalityGroupService.LocalityGroupCreateRequestDto mapCreate(LocalityGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LocalityGroupService.LocalityGroupCreateRequestDto localityGroupCreateRequestDto = new LocalityGroupService.LocalityGroupCreateRequestDto();

        localityGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        localityGroupCreateRequestDto.setCode( arg0.getCode() );
        localityGroupCreateRequestDto.setName( arg0.getName() );

        return localityGroupCreateRequestDto;
    }

    @Override
    public LocalityGroupService.LocalityGroupUpdateRequestDto mapUpdate(LocalityGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LocalityGroupService.LocalityGroupUpdateRequestDto localityGroupUpdateRequestDto = new LocalityGroupService.LocalityGroupUpdateRequestDto();

        localityGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        localityGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        localityGroupUpdateRequestDto.setCode( arg0.getCode() );
        localityGroupUpdateRequestDto.setName( arg0.getName() );

        return localityGroupUpdateRequestDto;
    }
}
