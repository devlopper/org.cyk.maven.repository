package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.core.enumeration.BusinessValueType;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Column;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupClient;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupRequestMapper;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService.UsersGroupCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService.UsersGroupUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsString;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link UsersGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class UsersGroupController extends AbstractController {

  @Inject
  UsersGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  UsersGroupRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController moduleInputTextController;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  /* Colonnes */
  
  @Getter
  Column codeColumn;
  
  @Getter
  Column nameColumn;
  
  @Getter
  Column countColumn;

  /**
   * Cette méthode permet de construire.
   */
  public UsersGroupController() {
    codeColumn = new Column();
    
    nameColumn = new Column();
    
    countColumn = new Column();
    countColumn.setHeaderText("Éffectif");
    countColumn.setBusinessValueType(BusinessValueType.QUANTITY);
    countColumn.setFieldName(HasUserCountAsString.FIELD_USER_COUNT_AS_STRING);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = UsersGroupDto.NAME;

    listController.setEntityClass(UsersGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(UsersGroupService.PATH);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(UsersGroupReadUsersPage.OUTCOME);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(HasIdentifierDto.JSON_IDENTIFIER,
        HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER, HasCodeDto.JSON_CODE, HasNameDto.JSON_NAME,
        HasUserCountAsStringDto.JSON_USER_COUNT_AS_STRING);

    listController.getReadController().setProjection(projection);

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER, AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      UsersGroupCreateRequestDto request = requestMapper.mapCreate((UsersGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(entity -> {
      UsersGroupUpdateRequestDto request = requestMapper.mapUpdate((UsersGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    moduleInputTextController.setOutputLableValue("Module");
    moduleInputTextController.getInputText().setRequired(true);
    moduleInputTextController.getInputText().addValueConsumer(moduleIdentifierConsumer());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    codeColumn.setRendered(
        projection.getNames().contains(HasCodeDto.JSON_CODE));
    codeColumn.initializeAsCode();
    
    nameColumn.setRendered(
        projection.getNames().contains(HasNameDto.JSON_NAME));
    nameColumn.initializeAsName();
    
    countColumn.setRendered(
        projection.getNames().contains(HasUserCountAsStringDto.JSON_USER_COUNT_AS_STRING));
    countColumn.initializeAsBusinessValueType();
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      moduleInputTextController.getInputText()
          .writeValue(((UsersGroupDto) entity).getModuleIdentifier());
      codeInputTextController.getInputText().writeValue(((UsersGroupDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((UsersGroupDto) entity).getName());
    };
  }

  Consumer<String> moduleIdentifierConsumer() {
    return moduleIdentifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UsersGroupDto.class)
        .setModuleIdentifier(moduleIdentifier);
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(UsersGroupDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(UsersGroupDto.class)
        .setName(name);
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(moduleInputTextController.getInputText(), codeInputTextController.getInputText(),
            nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
