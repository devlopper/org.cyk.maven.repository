package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.Namable;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceFilter;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.application.FacesMessage;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de sélecteur de resource partagée a l'utilisateur connecté.
 *
 * @author Christian
 *
 */
@Dependent
public class ConnectedUserSharedResourceSelectorController extends AbstractController {

  @Inject
  ResourceClient client;

  @Getter
  @Setter
  ResourceType type;

  @Getter
  @Setter
  Location location;

  @Inject
  @Getter
  ResourceSelectOneController selectOneController;

  @Getter
  @Setter
  Button showDialogButton;

  @Getter
  @Setter
  Dialog dialog;

  @Inject
  MessageManager messageManager;

  @Inject
  ComponentManager componentManager;

  @Inject
  ScriptManager scriptManager;

  @Getter
  @Setter
  ResourceDto resource;

  @Getter
  @Setter
  Consumer<ResourceDto> resourceConsumer;

  @Getter
  String resourceOutputPanelIdentifier;

  /**
   * Cette méthode permet d'instantier.
   */
  public ConnectedUserSharedResourceSelectorController() {
    showDialogButton = new Button();
    showDialogButton.setValue("Changer");
    showDialogButton.setActionFunction(p -> {
      scriptManager.show(dialog);
      return null;
    });

    dialog = new Dialog();
    dialog.setHeader("Sélection");
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    ResourceFilter filter = new ResourceFilter();
    filter.setType(type);
    filter.setLocation(location);
    filter.setUserName(userIdentifier);
    FilterDto filterDto = filter.toDto();
    
    selectOneController.setFilter(filterDto);
    initializeDefaultResource(filterDto);
    resourceOutputPanelIdentifier = type.name() + location.name();
  }
  
  void initializeDefaultResource(FilterDto filterDto) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractResourceOrReceiverDto.JSON_REFERENCE, AbstractIdentifiableNamableDto.JSON_NAME);
    request.setFilter(filterDto);
    request.setUseFirstResultIfManyGot(true);
    request.setAuditWho(userIdentifier);
    resource = client.getOne(request);
  }
  

  /**
   * Cette méthode permet de préparer le sélection des unités administratives.
   */
  public void prepareAdministrativeUnit() {
    type = ResourceType.ADMINISTRATIVE_UNIT;
    location = Location.BUDGETARY_CLASSIFICATION;
  }

  /**
   * Cette méthode permet d'exécuter.
   */
  public void execute() {
    /*
     * On stocke la ressource sélectionnée en session
     */
    String identifier = selectOneController.getAutoComplete().getValue();
    resource = client.getByIdentifier(identifier,
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractResourceOrReceiverDto.JSON_REFERENCE, AbstractIdentifiableNamableDto.JSON_NAME),
        userIdentifier, null);
    Core.acceptConsumer(resourceConsumer, resource);
    messageManager.addGrowlMessage(
        new FacesMessage(String.format("%s a été sélectionné", resource.getName())));
    componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier(),
        resourceOutputPanelIdentifier);
    scriptManager.hide(dialog);
    scriptManager.reloadPage();
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ResourceDto}.
   *
   * @return Identifiant de {@link ResourceDto}
   */
  public String getResourceIdentifier() {
    return Optional.ofNullable(resource).map(r -> r.getIdentifier()).orElse(Constant.EMPTY_STRING);
  }

  /**
   * Cette méthode permet d'obtenir la référence de {@link ResourceDto}.
   *
   * @return Référence de {@link ResourceDto}
   */
  public String getResourceReference() {
    return Optional.ofNullable(resource).map(r -> r.getReference()).orElse(Constant.EMPTY_STRING);
  }

  /**
   * Cette méthode permet d'obtenir le nom de {@link ResourceDto}.
   *
   * @return Nom de {@link ResourceDto}
   */
  public String getResourceName() {
    return Optional.ofNullable(resource).map(Namable::getName).orElse(Constant.EMPTY_STRING);
  }
}
