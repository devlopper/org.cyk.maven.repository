package ci.gouv.dgbf.extension.primefaces.component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Cette classe représente une carte statistique.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class StatisticCard extends AbstractWidget {

  private String title;
  private String titleTextColorClass;
  
  private String value;
  private String valueTextColorClass;
  
  private String columnClass;
  
  private String bottomTextClass;
  private String bottomTextValue;
  private String bottomTextDescription;
  
  private String iconClass;
  
  private String backgroundColorClass;
  
  /**
   * Cette méthode permet d'instantier.
   */
  public StatisticCard() {
    templateFilePath = "/extension/component/statistic/card/default.xhtml";
    
    title = "Titre à définir";
    titleTextColorClass = "";
    
    value = "Valeur à définir";
    valueTextColorClass = "";
    
    columnClass = "col-md-4";
    
    bottomTextDescription = "Description à définir";
    
    iconClass = "ri-information-line";
    
    backgroundColorClass = "bg-danger-subtle";
  }
  
  /**
   * Cette classe représente une donnée.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @AllArgsConstructor
  @NoArgsConstructor
  public static class Data {

    private String name;
    
    private String value;
    
  }
}
