package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+2 est complétée,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN2AsStringDto extends HasCompletedN2AsString {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N+2 est complétée,
   * sous forme de chaîne de caractères.
   */
  String JSON_COMPLETED_N2_AS_STRING = "completeN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName