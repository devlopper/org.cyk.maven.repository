package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.faces.application.ResourceHandler;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Cette classe rend les pages Faces en mémoire avant de les envoyer.
 *
 * <p>Une erreur survenue pendant le rendu peut ainsi encore être remplacée par la page d'erreur,
 * au lieu d'envoyer une page tronquée : le tampon du conteneur (16 Ko par défaut sous Quarkus)
 * est dépassé par la plupart des pages et la taille demandée par Faces n'y est pas appliquée. Les
 * ressources Faces ne sont pas concernées ; au-delà de {@link #LIMIT}, la réponse est transmise
 * au fil de l'eau (téléchargements).
 *
 * @author Christian
 */
public class ResponseBufferingFilter extends HttpFilter {
  private static final long serialVersionUID = 1L;

  /** Taille au-delà de laquelle la réponse n'est plus retenue en mémoire. */
  public static final int LIMIT = 2 * 1024 * 1024;

  @Override
  protected void doFilter(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws IOException, ServletException {
    if (request.getRequestURI().contains(ResourceHandler.RESOURCE_IDENTIFIER)) {
      chain.doFilter(request, response);
      return;
    }
    BufferedResponse buffered = new BufferedResponse(response, LIMIT);
    chain.doFilter(request, buffered);
    buffered.finish();
  }
}
