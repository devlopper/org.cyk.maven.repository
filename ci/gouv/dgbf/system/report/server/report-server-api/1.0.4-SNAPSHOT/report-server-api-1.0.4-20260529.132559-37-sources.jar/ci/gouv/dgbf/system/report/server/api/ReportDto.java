package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasTemplateIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un <b>rapport (ou état)</b> au sein du module d'édition d'états du SI de
 * la DGBF [1].<br/>
 * Ce module est un outil stratégique utilisé pour le suivi administratif, le pilotage budgétaire ou
 * la production de documents officiels [1]. Il agit comme une interface entre le système
 * d'information et un moteur de reporting externe [2].<br/>
 * L'objectif principal est de séparer la logique métier du SI de la logique de génération des
 * rapports afin de rendre le système plus modulaire et évolutif [3].
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReportDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasTemplateIdentifierDto {


  /**
   * <b>Type de fichier de sortie</b> du rapport [4].<br/>
   * Indique le format dans lequel le document doit être généré par le moteur de reporting [4]. Les
   * formats supportés sont :
   * <ul>
   * <li>PDF</li>
   * <li>Excel</li>
   * <li>CSV</li>
   * <li>HTML</li>
   * </ul>
   */
  @JsonbProperty(JSON_OUTPUT_FILE_TYPE)
  private String outputFileType;

  /**
   * <b>Description</b> du rapport [5].<br/>
   * Texte permettant de préciser l'<b>objectif</b> ou le <b>contenu</b> du rapport afin de
   * faciliter son utilisation par les agents métiers [5].
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * <b>Identifiant du modèle</b> de rapport (template) [6].<br/>
   * Cette référence, connue du moteur de reporting, peut correspondre à :
   * <ul>
   * <li>L'identifiant interne du rapport dans le moteur [6].</li>
   * <li>L'emplacement du modèle (ex : fichier .jasper ou .jrxml) [6].</li>
   * <li>Toute autre référence permettant de localiser le modèle à exécuter [6].</li>
   * </ul>
   */
  @JsonbProperty(JSON_TEMPLATE_IDENTIFIER)
  private String templateIdentifier;

  /**
   * Identifiant du dictionnaire de paramètres.
   */
  @JsonbProperty(JSON_PARAMETERS_DICTIONARY_IDENTIFIER)
  private String parametersDictionaryIdentifier;

  /**
   * Representation en chaine du dictionnaire de paramètres.
   */
  @JsonbProperty(JSON_PARAMETERS_DICTIONARY_AS_STRING)
  private String parametersDictionaryAsString;


  /**
   * Entrées du dictionnaire de paramètres.
   */
  @JsonbProperty(JSON_PARAMETERS_DICTIONARY_ENTRIES_NAMES)
  private List<String> parametersDictionaryEntriesNames;

  /**
   * Identifiant json {@link #outputFileType}.
   */
  public static final String JSON_OUTPUT_FILE_TYPE = "typeFichierSortie";


  /**
   * Identifiant json {@link #description}.
   */
  public static final String JSON_PARAMETERS_DICTIONARY_IDENTIFIER =
      "identifiantDictionnaireParametre";


  /**
   * Identifiant json {@link #parametersDictionaryAsString}.
   */
  public static final String JSON_PARAMETERS_DICTIONARY_AS_STRING = "dictionnaireParametreChaine";


  /**
   * Identifiant json {@link #parametersDictionaryEntriesNames}.
   */
  public static final String JSON_PARAMETERS_DICTIONARY_ENTRIES_NAMES = "nomsEntreesDictionnaire";

  /**
   * Nom de l'entité en français.
   */
  public static final String NAME = "rapport";

  /**
   * Nom pluriel de l'entité.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
