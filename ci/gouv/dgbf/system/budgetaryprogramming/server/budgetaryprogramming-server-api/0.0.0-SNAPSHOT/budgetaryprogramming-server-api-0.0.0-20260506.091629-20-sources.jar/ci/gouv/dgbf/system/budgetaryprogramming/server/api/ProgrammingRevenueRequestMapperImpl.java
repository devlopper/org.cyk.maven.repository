package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingRevenueDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-06T09:16:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingRevenueRequestMapperImpl implements ProgrammingRevenueRequestMapper {

    @Override
    public ProgrammingRevenueService.ProgrammingRevenueCreateRequestDto mapCreate(ProgrammingRevenueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingRevenueService.ProgrammingRevenueCreateRequestDto programmingRevenueCreateRequestDto = new ProgrammingRevenueService.ProgrammingRevenueCreateRequestDto();

        programmingRevenueCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingRevenueCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingRevenueCreateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingRevenueCreateRequestDto.setRevenueIdentifier( arg0.getRevenueIdentifier() );

        return programmingRevenueCreateRequestDto;
    }

    @Override
    public ProgrammingRevenueService.ProgrammingRevenueUpdateRequestDto mapUpdate(ProgrammingRevenueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingRevenueService.ProgrammingRevenueUpdateRequestDto programmingRevenueUpdateRequestDto = new ProgrammingRevenueService.ProgrammingRevenueUpdateRequestDto();

        programmingRevenueUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingRevenueUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingRevenueUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingRevenueUpdateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingRevenueUpdateRequestDto.setRevenueIdentifier( arg0.getRevenueIdentifier() );

        return programmingRevenueUpdateRequestDto;
    }
}
