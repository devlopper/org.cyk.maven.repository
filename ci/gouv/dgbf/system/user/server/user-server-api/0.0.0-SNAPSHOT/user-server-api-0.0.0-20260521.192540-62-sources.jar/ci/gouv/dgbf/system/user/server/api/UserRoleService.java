package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link UserRoleDto}.
 *
 * @author BoobaCool
 */
@Path(value = UserRoleService.PATH)
@Tag(name = "Gestion des roles des utilisateurs")
public interface UserRoleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "utilisateurs-roles";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author BoobaCool
   */
  interface UserRoleSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link UserDto}.
     *
     * @return identifiant de {@link UserDto}
     */
    String getUserIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link UserDto}.
     *
     * @param userIdentifier identifiant de {@link UserDto}
     */
    void setUserIdentifier(String userIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité.
     *
     * @return identifiant de l'identité
     */
    String getRoleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité.
     *
     * @param roleIdentifier identifiant de l'identité
     */
    void setRoleIdentifier(String roleIdentifier);

    /**
     * Identifiant json identifiant de {@link UserDto}.
     */
    String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link RoleDto}.
     */
    String JSON_ROLE_IDENTIFIER = RoleDto.JSON_THIS_IDENTIFIER;
  }


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ROLE_UTILISATEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(UserRoleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserRoleCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements UserRoleSaveRequestDto {
    @JsonbProperty(JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

  }


  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ROLE_UTILISATEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserRoleGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class UserRoleGetManyResponseDto extends AbstractGetByPageResponseDto<UserRoleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<UserRoleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ROLE_UTILISATEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserRoleDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ROLE_UTILISATEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserRoleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ROLE_UTILISATEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(UserRoleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserRoleUpdateRequestDto extends ByIdentifierRequestDto implements UserRoleSaveRequestDto {

    @JsonbProperty(JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ROLE_UTILISATEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link UserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de création multiple.
   */
  String CREATE_MANY_IDENTIFIER = "CREATION_PLUSIEURS_ROLE_UTILISATEUR";

  /**
   * Chemin du service de création multiple.
   */
  String CREATE_MANY_PATH = "creation/plusieurs";

  /**
   * Cette méthode permet de créer plusieurs associations entre utilisateurs et roles.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = UserRoleCreateManyResponseDto.class))})
  Response createMany(UserRoleCreateManyRequestDto request);

  /**
   * Cette classe représente la requête de création multiple.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserRoleCreateManyRequestDto extends AbstractAuditedRequestJsonDto {

    @JsonbProperty(JSON_USER_IDENTIFIERS)
    private Set<String> userIdentifiers;

    @JsonbProperty(JSON_ROLE_IDENTIFIERS)
    private Set<String> roleIdentifiers;

    /**
     * Identifiant json {@link #userIdentifiers}.
     */
    public static final String JSON_USER_IDENTIFIERS = "utilisateursIdentifiants";

    /**
     * Identifiant json {@link #roleIdentifiers}.
     */
    public static final String JSON_ROLE_IDENTIFIERS = "rolesIdentifiants";

  }

  /**
   * Cette classe représente la réponse de création multiple.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserRoleCreateManyResponseDto {

    @JsonbProperty(JSON_USER_ROLE_IDENTIFIERS)
    private List<String> identifiers;
    @JsonbProperty(JSON_MESSAGE)
    private String message;
    @JsonbProperty(JSON_ORDERED_IDENTIFIERS)
    private List<OrderedIdentifier> orderedIdentifiers;

    /**
     * Classe interne pour identifiantsOrdonnes.
     */
    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    public static class OrderedIdentifier {


      @JsonbProperty(JSON_ORDER_NUMBER)
      private Integer orderNumber;

      @JsonbProperty(JSON_IDENTIFIER)
      private String identifier;

      /**
       * Id java.
       */
      public static final String JSON_ORDER_NUMBER = "numeroOrdre";
      
      /**
       * Id java.
       */
      public static final String JSON_IDENTIFIER = "identifiant";
    }

    /**
     * Identifiant json {@link #identifiers}.
     */
    public static final String JSON_USER_ROLE_IDENTIFIERS = "utilisateursRolesIdentifiants";

    /**
     * Identifiant json {@link #message}.
     */
    public static final String JSON_MESSAGE = "message";

    /**
     * Identifiant json {@link #orderedIdentifiers}.
     */
    public static final String JSON_ORDERED_IDENTIFIERS = "identifiantsOrdonnes";

  }
}
