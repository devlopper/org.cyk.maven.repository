package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette interface représente une classe avec une notion de nombre de processus.
 *
 * @author Christian
 */
public interface HasProcessCountDto extends HasProcessCount {

  /**
   * Identifiant json du nombre de processus.
   */
  String JSON_PROCESS_COUNT = "nombreProcessus";
}
