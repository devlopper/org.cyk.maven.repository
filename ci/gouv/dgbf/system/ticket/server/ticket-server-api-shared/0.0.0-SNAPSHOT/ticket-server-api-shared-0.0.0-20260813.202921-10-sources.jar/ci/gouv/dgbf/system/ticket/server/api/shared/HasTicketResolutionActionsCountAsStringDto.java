package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de résolution
 * de ticket sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketResolutionActionsCountAsStringDto
    extends HasTicketResolutionActionsCountAsString {

  /**
   * Identifiant json du nombre cumulé d'actions de résolution de ticket sous forme de chaîne.
   */
  String JSON_TICKET_RESOLUTION_ACTIONS_COUNT_AS_STRING = "nombreActionsResolutionTicketChaine";
}
