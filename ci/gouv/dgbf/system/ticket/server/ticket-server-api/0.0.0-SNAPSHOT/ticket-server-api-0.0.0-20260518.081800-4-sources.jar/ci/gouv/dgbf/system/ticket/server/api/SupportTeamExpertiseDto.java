package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une expertise équipe support.
 *
 * @author kimou
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamExpertiseDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant de {@link SupportLevelDto}.
   */
  @JsonbProperty(JSON_SUPPORT_LEVEL_IDENTIFIER)
  private String supportLevelIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportLevelDto}.
   */
  @JsonbProperty(JSON_SUPPORT_LEVEL_AS_STRING)
  private String supportLevelAsString;

  /**
   * Identifiant de {@link FunctionalDomainDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_DOMAIN_IDENTIFIER)
  private String functionalDomainIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link FunctionalDomainDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_DOMAIN_AS_STRING)
  private String functionalDomainAsString;

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
  private String supportTeamIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_AS_STRING)
  private String supportTeamAsString;



  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idExpertiseEquipeSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "expertiseEquipeSupportChaine";

  /**
   * Identifiant champ java {@link #supportLevelIdentifier}.
   */
  public static final String JSON_SUPPORT_LEVEL_IDENTIFIER =
          SupportLevelDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportLevelAsString}.
   */
  public static final String JSON_SUPPORT_LEVEL_AS_STRING =
          SupportLevelDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #functionalDomainIdentifier}.
   */
  public static final String JSON_FUNCTIONAL_DOMAIN_IDENTIFIER =
          FunctionalDomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #functionalDomainAsString}.
   */
  public static final String JSON_FUNCTIONAL_DOMAIN_AS_STRING =
          FunctionalDomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #supportTeamIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_IDENTIFIER =
          SupportTeamDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_AS_STRING =
          SupportTeamDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "expertise equipe support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "expertises equipe support";

}

