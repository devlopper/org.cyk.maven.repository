package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionaryUnitSectionDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FunctionaryUnitSectionFilter extends AbstractIdentifiableFilter {
  /**
   * Identifiant de {@link FunctionaryDto}.
   */
  String functionaryIdentifier;

  /**
   * Identifiant de l'unité de section.
   */
  String unitSectionIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FunctionaryUnitSectionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FunctionaryUnitSectionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    functionaryIdentifier = getFunctionaryIdentifier(filter);
    unitSectionIdentifier = getUnitSectionIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFunctionaryIdentifier(filter, functionaryIdentifier);
    setUnitSectionIdentifier(filter, unitSectionIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FunctionaryDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFunctionaryIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FUNCTIONARY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FunctionaryDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FunctionaryDto}
   */
  public static String getFunctionaryIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUNCTIONARY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'unié de Section.
   *
   * @param filter filtre
   * @param identifier identifiant de l'unié de Section
   */
  public static void setUnitSectionIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_UNIT_SECTION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unié de Section.
   *
   * @param filter filtre
   * @return identifiant de l'unié de Section
   */
  public static String getUnitSectionIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_UNIT_SECTION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link FunctionaryUnitSectionFilter#functionaryIdentifier}.
   */
  public static final String JSON_FUNCTIONARY_IDENTIFIER = 
      FunctionaryUnitSectionDto.JSON_FUNCTIONARY_IDENTIFIER;

  /**
   * Identifiant json champ {@link FunctionaryUnitSectionFilter#unitSectionIdentifier}.
   */
  public static final String JSON_UNIT_SECTION_IDENTIFIER =
      FunctionaryUnitSectionDto.JSON_UNIT_SECTION_IDENTIFIER;

}
