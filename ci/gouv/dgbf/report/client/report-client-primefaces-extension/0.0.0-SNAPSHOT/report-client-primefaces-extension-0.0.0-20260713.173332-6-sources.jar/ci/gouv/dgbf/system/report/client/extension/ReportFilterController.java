package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.report.server.api.ReportFilter;
import ci.gouv.dgbf.system.report.server.api.ReportGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ReportGroupDto}.
 *
 * @author Desysoft
 */
@Dependent
public class ReportFilterController
    extends AbstractFilterController<ReportFilter> {

  @Inject
  @Getter
  ReportsGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  InputTextController groupCodeController;

  public ReportFilterController() {
    super(ReportFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setGroupIdentifier(
        getRequestParameter(ReportFilter.JSON_GROUP_IDENTIFIER));

    filter.setGroupCode(
        getRequestParameter(ReportFilter.JSON_GROUP_CODE));

    groupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setGroupIdentifier(identifier));

    groupCodeController.getInputText()
        .addValueConsumer(code -> filter.setGroupCode(code));
  }
}

