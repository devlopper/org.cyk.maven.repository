package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RepresentationFunctionTypeDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class RepresentationFunctionTypeFilter extends AbstractIdentifiableFilter {

  private String functionTypeIdentifier;

  private String representationIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RepresentationFunctionTypeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RepresentationFunctionTypeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    functionTypeIdentifier = getFunctionTypeIdentifier(filter);
    representationIdentifier = getRepresentationIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFunctionTypeIdentifier(filter, functionTypeIdentifier);
    setRepresentationIdentifier(filter, representationIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type de fonction.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFunctionTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FUNCTION_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de fonction.
   *
   * @param filter filtre
   * @return identifiant du type de fonction
   */
  public static String getFunctionTypeIdentifier(FilterDto filter) {
    return get(filter, d ->
            d.getFieldValueAsStringByName(JSON_FUNCTION_TYPE_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant de la representation.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setRepresentationIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_REPRESENTATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la representation.
   *
   * @param filter filtre
   * @return identifiant de la representation
   */
  public static String getRepresentationIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_REPRESENTATION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #functionTypeIdentifier}.
   */
  public static final String JSON_FUNCTION_TYPE_IDENTIFIER = 
      RepresentationFunctionTypeDto.JSON_FUNCTION_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #representationIdentifier}.
   */
  public static final String JSON_REPRESENTATION_IDENTIFIER = 
      RepresentationFunctionTypeDto.JSON_REPRESENTATION_IDENTIFIER;
}
