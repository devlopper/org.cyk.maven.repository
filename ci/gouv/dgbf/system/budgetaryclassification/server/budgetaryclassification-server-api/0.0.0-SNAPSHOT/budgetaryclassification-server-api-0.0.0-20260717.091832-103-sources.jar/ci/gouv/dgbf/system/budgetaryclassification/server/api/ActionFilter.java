package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ActionDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ActionFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link BudgetSpecializationUnitDto}.
   */
  String budgetSpecializationUnitIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ActionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ActionFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    budgetSpecializationUnitIdentifier = getBudgetSpecializationUnitIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setBudgetSpecializationUnitIdentifier(filter, budgetSpecializationUnitIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link BudgetSpecializationUnitDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link BudgetSpecializationUnitDto}
   */
  public static void setBudgetSpecializationUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link BudgetSpecializationUnitDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link BudgetSpecializationUnitDto}
   */
  public static String getBudgetSpecializationUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #budgetSpecializationUnitIdentifier}.
   */
  public static final String JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER =
      ActionDto.JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER;
}
