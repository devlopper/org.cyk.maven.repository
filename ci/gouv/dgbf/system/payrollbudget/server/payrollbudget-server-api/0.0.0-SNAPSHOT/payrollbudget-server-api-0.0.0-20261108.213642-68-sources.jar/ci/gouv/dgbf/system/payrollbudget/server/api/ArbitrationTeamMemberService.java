package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat de la composition des équipes : qui en fait partie.
 *
 * <p>Pas de modification : un membre s'ajoute ou se retire. Changer le rôle d'un agent revient
 * à le retirer puis à le réinscrire, et l'audit garde trace des deux gestes plutôt que d'une
 * mutation silencieuse.</p>
 *
 * @author Christian
 *
 */
@Path(value = ArbitrationTeamMemberService.PATH)
@Tag(name = "Gestion des membres d'équipe")
public interface ArbitrationTeamMemberService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "membres-equipe";

  /**
   * Ce que porte la requête, au-delà de ce que la classe parente apporte.
   *
   * <p>Le concept n'expose pas de mise à jour : l'interface ne factorise donc
   * rien, mais elle tient le contrat des champs et dispense la requête de
   * nommer le {@link ArbitrationTeamMemberDto} à chaque clé.</p>
   *
   * <p>Il n'y a pas de {@code ArbitrationTeamMemberRequestMapper} pour autant : R50 ne le prévoit
   * que là où la création <em>et</em> la mise à jour existent toutes deux, un mapper
   * à un seul type de requête supposant une nouvelle classe générique dans
   * l'extension.</p>
   */
  interface ArbitrationTeamMemberSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'équipe.
     *
     * @return l'équipe
     */
    String getTeamIdentifier();

    /**
     * Cette méthode permet d'assigner l'équipe.
     *
     * @param teamIdentifier l'équipe
     */
    void setTeamIdentifier(String teamIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de connexion du membre.
     *
     * @return l'identifiant de connexion du membre
     */
    String getUser();

    /**
     * Cette méthode permet d'assigner l'identifiant de connexion du membre.
     *
     * @param user l'identifiant de connexion du membre
     */
    void setUser(String user);

    /**
     * Cette méthode permet d'obtenir le rôle tenu dans l'équipe.
     *
     * @return le rôle tenu dans l'équipe
     */
    String getRole();

    /**
     * Cette méthode permet d'assigner le rôle tenu dans l'équipe.
     *
     * @param role le rôle tenu dans l'équipe
     */
    void setRole(String role);

    /**
     * {@link ArbitrationTeamMemberDto#JSON_TEAM_IDENTIFIER}.
     */
    String JSON_TEAM_IDENTIFIER = ArbitrationTeamMemberDto.JSON_TEAM_IDENTIFIER;

    /**
     * {@link ArbitrationTeamMemberDto#JSON_USER}.
     */
    String JSON_USER = ArbitrationTeamMemberDto.JSON_USER;

    /**
     * {@link ArbitrationTeamMemberDto#JSON_ROLE}.
     */
    String JSON_ROLE = ArbitrationTeamMemberDto.JSON_ROLE;
  }

  /**
   * Identifiant du service de création unitaire de {@link ArbitrationTeamMemberDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_MEMBRE_EQUIPE";

  /**
   * Chemin du service de création unitaire de {@link ArbitrationTeamMemberDto}.
   */
  String CREATE_PATH = "";

  /**
   * Inscription d'un agent dans une équipe.
   *
   * @param request l'agent et son rôle
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Inscription d'un membre d'équipe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ArbitrationTeamMemberCreateRequestDto request);

  /**
   * Requête d'inscription d'un membre.
   */
  @Getter
  @Setter
  class ArbitrationTeamMemberCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ArbitrationTeamMemberSaveRequestDto {

    @JsonbProperty(JSON_TEAM_IDENTIFIER)
    private String teamIdentifier;

    @JsonbProperty(JSON_USER)
    private String user;

    @JsonbProperty(JSON_ROLE)
    private String role;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ArbitrationTeamMemberDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MEMBRE_EQUIPE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ArbitrationTeamMemberDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des membres.
   *
   * @param request critères, projection et pagination
   * @return les membres correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER, summary = "Consultation des membres d'équipe")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ArbitrationTeamMemberGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de membres.
   */
  @Getter
  @Setter
  public static class ArbitrationTeamMemberGetManyResponseDto
      extends AbstractGetByPageResponseDto<ArbitrationTeamMemberDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ArbitrationTeamMemberDto> datas;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ArbitrationTeamMemberDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MEMBRE_EQUIPE";

  /**
   * Chemin du service de suppression unitaire de {@link ArbitrationTeamMemberDto}.
   */
  String DELETE_PATH = "";

  /**
   * Retrait d'un membre.
   *
   * <p>Il ne défait rien de ce qu'il a instruit : ses décisions restent à son nom.</p>
   *
   * @param request l'identifiant à retirer
   * @return l'identifiant retiré
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER, summary = "Retrait d'un membre d'équipe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
