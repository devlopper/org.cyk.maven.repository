package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link IdentitiesGroupRoleDto}.
 *
 * @author Arnaud
 *
 */
@Path(IdentitiesGroupRoleService.PATH)
@Tag(name = "Gestion role groupe d'identités")
public interface IdentitiesGroupRoleService extends Service {

  /**
   * Chemin du service de gestion des roles de groupes d'identités.
   */
  String PATH = "roles-groupes-identites";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author arnaud
   *
   */
  interface IdentitiesGroupRoleSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentitiesGroupDto}.
     *
     * @return identifiant de {@link IdentitiesGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link IdentitiesGroupDto}.
     *
     * @param groupIdentifier identifiant de {@link IdentitiesGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RoleDto}.
     *
     * @return identifiant de {@link RoleDto}
     */
    String getRoleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link RoleDto}.
     *
     * @param roleIdentifier identifiant de {@link RoleDto}
     */
    void setRoleIdentifier(String roleIdentifier);

    /**
     * {@link IdentitiesGroupRoleDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = 
            IdentitiesGroupRoleDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link IdentitiesGroupRoleDto#JSON_ROLE_IDENTIFIER}.
     */
    String JSON_ROLE_IDENTIFIER = IdentitiesGroupRoleDto.JSON_ROLE_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UN_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link IdentitiesGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un rôle groupe d'identité",
      description = "Ce service permet de créer un rôle groupe d'identité")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IdentitiesGroupRoleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author arnaud
   *
   */
  @Getter
  @Setter
  class IdentitiesGroupRoleCreateRequestDto extends AbstractAuditedRequestJsonDto 
       implements IdentitiesGroupRoleSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

  }


  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link IdentitiesGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs rôles groupes d'identités")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class IdentitiesGroupRoleGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentitiesGroupRoleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentitiesGroupRoleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un groupe de matricule.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un rôle groupe d'identité")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link IdentitiesGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un rôle groupe d'identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentitiesGroupRoleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentitiesGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un groupe de matricule")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IdentitiesGroupRoleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author arnaud
   *
   */

  @Getter
  @Setter
  class IdentitiesGroupRoleUpdateRequestDto extends ByIdentifierRequestDto 
        implements IdentitiesGroupRoleSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ROLE_GROUPE_IDENTITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link IdentitiesGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un rôle groupe d'identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

