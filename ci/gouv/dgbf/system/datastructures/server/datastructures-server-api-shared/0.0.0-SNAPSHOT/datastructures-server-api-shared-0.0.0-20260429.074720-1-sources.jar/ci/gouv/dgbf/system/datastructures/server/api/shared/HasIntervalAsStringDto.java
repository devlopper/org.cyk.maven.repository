package ci.gouv.dgbf.system.datastructures.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'intervalle.
 *
 * @author Christian
 */
public interface HasIntervalAsStringDto extends HasIntervalAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'intervalle.
   */
  String JSON_INTERVAL_AS_STRING = "intervalleChaine";
}
