package ci.gouv.dgbf.extension.primefaces.segregation;

/**
 * Cette interface représente un widget.
 *
 * @author Christian
 *
 */
public interface Widgetable {

  String getWidgetVar();
  
  void setWidgetVar(String widgetVar);
  
}
