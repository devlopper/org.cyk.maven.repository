package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import java.util.Arrays;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import lombok.Getter;

/**
 * Les profils de l'arbitrage, et les droits que chacun porte.
 *
 * <p>C'est la matrice rôles × fonctionnalités, tirée des deux diagrammes de cas d'utilisation.
 * Elle vit ici plutôt que dans Keycloak pour une raison simple : écrite en composites Keycloak,
 * elle serait invisible à la relecture et personne ne saurait dire, devant un écran, pourquoi
 * tel agent y accède. Écrite ici, elle se lit, elle se teste, et elle se corrige en un endroit.</p>
 *
 * <p><strong>Keycloak n'accorde que huit profils, pas vingt et un droits.</strong> C'est ce qui
 * rend l'administration tenable : on donne à un agent « chargé des mouvements », pas la liste de ce
 * qu'un chargé des mouvements a le droit de faire. Le droit accordé directement reste accepté —
 * {@link UserProfile} n'interdit rien, il dispense de tout énumérer.</p>
 *
 * <p><strong>La spécialisation du diagramme est reproduite telle quelle.</strong> Les trois
 * chargés et le chef d'équipe sont des membres de l'équipe DCB, et consultent à ce titre le
 * tableau de bord budgétaire. Le chargé de contrôle, lui, n'en est pas : le diagramme ne lui
 * donne aucun cas de consultation, et rien n'a été ajouté de notre initiative.</p>
 *
 * <p><strong>Un écart assumé au diagramme, décidé le 06/10/2026 :</strong> le chef d'équipe
 * cumule désormais la réception, le contrôle, le traitement et la validation. Les diagrammes
 * les répartissaient sur trois acteurs. Le métier l'a demandé, et la raison est pratique : le
 * chef menait un dossier jusqu'à la réception puis se trouvait sans geste, à attendre qu'un
 * chargé prenne la main. Le contrôle à quatre yeux n'est donc plus garanti par l'application
 * pour ce profil ; il repose sur l'organisation du service.</p>
 *
 * @author Christian
 *
 */
@Getter
public enum UserProfile implements CodableByStringWithGetterOnly {

  /**
   * Chargé de contrôle. Réceptionne les projets et vérifie les pièces jointes.
   *
   * <p>Il garde {@link UserRole#DECLARE_DOSSIER_ADMISSIBLE} alors que l'admission n'est
   * plus une étape du circuit : ce qui a disparu, c'est la transition que ce droit
   * déclenchait, non le droit lui-même. Il désigne toujours le chargé de contrôle, et
   * commande l'ouverture du menu de réception, l'écran de contrôle et la vérification des
   * pièces jointes.</p>
   */
  CONTROL_OFFICER("CHARGE_DE_CONTROLE",
      UserRole.RECEIVE_DOSSIER, UserRole.DECLARE_DOSSIER_ADMISSIBLE),

  /**
   * Chargé des mouvements à venir : primes, retraites, glissements, indemnités, avancements.
   */
  MOVEMENT_OFFICER("CHARGE_MOUVEMENTS",
      UserRole.PROCESS_FORTHCOMING_MOVEMENT, UserRole.CONSULT_BUDGET_DASHBOARD),

  /**
   * Chargé des régularisations : rappels et régularisations.
   *
   * <p><strong>Son code Keycloak dit encore les mesures ponctuelles</strong>, et c'est voulu : le
   * 12/10/2026 a redessiné les <em>droits</em>, pas les groupes. Renommer le groupe obligerait à
   * réaffecter tous les comptes qui le portent, ce qui est une décision d'administration et non
   * de code. Le droit qu'il ouvre, lui, est bien celui des régularisations.</p>
   */
  PUNCTUAL_MEASURE_OFFICER("CHARGE_MESURES_PONCTUELLES",
      UserRole.PROCESS_REGULARIZATION, UserRole.CONSULT_BUDGET_DASHBOARD),

  /**
   * Chargé des transferts de solde.
   */
  BALANCE_TRANSFER_OFFICER("CHARGE_TRANSFERTS_SOLDE",
      UserRole.PROCESS_BALANCE_TRANSFER, UserRole.CONSULT_BUDGET_DASHBOARD),

  /**
   * Chef d'équipe. Mène un dossier d'un bout à l'autre, et valide le travail des trois chargés.
   *
   * <p>Le 06/10/2026, le métier lui a donné la réception, le contrôle d'admissibilité et le
   * traitement des trois familles, qu'il n'avait pas. Il pouvait faire changer un dossier
   * d'étape mais ne pouvait rien faire <em>dans</em> le dossier : il le réceptionnait, puis
   * restait devant un écran sans aucun geste, à attendre qu'un chargé prenne la main.</p>
   *
   * <p><strong>Cela lève le contrôle à quatre yeux, et il faut le dire.</strong> Jusqu'ici
   * instruire et homologuer étaient deux gestes confiés à deux personnes : un chargé
   * instruisait sa famille, le chef validait. Le chef peut désormais instruire puis valider
   * son propre travail. La séparation n'est pas supprimée — les trois chargés restent
   * cantonnés à leur famille, et eux ne valident rien — mais elle n'est plus garantie par
   * l'application : elle repose sur l'organisation du service.</p>
   */
  TEAM_LEADER("CHEF_EQUIPE",
      UserRole.RECEIVE_DOSSIER, UserRole.DECLARE_DOSSIER_ADMISSIBLE,
      UserRole.PROCESS_FORTHCOMING_MOVEMENT, UserRole.PROCESS_REGULARIZATION,
      UserRole.PROCESS_BALANCE_TRANSFER, UserRole.MANAGE_ARBITRATION_TEAM,
      UserRole.VALIDATE_MAINTAINED_DATA, UserRole.VALIDATE_PROJECTED_MOVEMENTS,
      UserRole.VALIDATE_PUNCTUAL_MEASURES, UserRole.VALIDATE_BALANCE_TRANSFERS,
      UserRole.TRANSMIT_TO_ARBITRATION_MANAGER, UserRole.TAKE_OBSERVATION_INTO_ACCOUNT,
      UserRole.CONSULT_PROCESSING_RESULTS, UserRole.CONSULT_BUDGET_DASHBOARD),

  /**
   * Responsable d'arbitrage de sous-direction. Consulte les travaux, et édite les trois états.
   *
   * <p>Il pré-validait le projet au diagramme de cas d'utilisation ; les écrans ne portent plus
   * ce geste, et le droit a été retiré plutôt que laissé à ouvrir une entrée de menu qu'aucun
   * bouton n'honore.</p>
   */
  SD_ARBITRATION_MANAGER("RESPONSABLE_ARBITRAGE_SD",
      UserRole.CONSULT_PROCESSING_RESULTS, UserRole.CONSULT_BUDGET_DASHBOARD,
      UserRole.EDIT_CONSOLIDATED_DOSSIER, UserRole.EDIT_PROCESSING_RESULTS,
      UserRole.EDIT_PAYROLL_PROJECT),

  /**
   * Responsable d'arbitrage de la DCB. Valide définitivement le projet.
   */
  DCB_ARBITRATION_MANAGER("RESPONSABLE_ARBITRAGE_DCB",
      UserRole.VALIDATE_PAYROLL_PROJECT, UserRole.EDIT_PAYROLL_PROJECT,
      UserRole.MANAGE_ARBITRATION_TEAM),

  /**
   * Agent de l'établissement. Consulte son dossier et le retransmet après correction.
   *
   * <p>Ce profil ne figure pas aux diagrammes, qui décrivent le travail de la DCB. Il est déduit
   * des écrans que le module sert déjà à l'EPN, et reste à confirmer avec le métier.</p>
   */
  NATIONAL_PUBLIC_INSTITUTION_AGENT("AGENT_EPN",
      UserRole.CONSULT_OWN_DOSSIER, UserRole.CORRECT_AND_RETRANSMIT);

  private UserProfile(String code, UserRole... roles) {
    this.code = code;
    this.roles = Set.copyOf(Arrays.asList(roles));
  }

  /**
   * Code.
   */
  private String code;

  /**
   * Droits que ce profil porte.
   */
  private Set<UserRole> roles;

  /**
   * Les profils qui portent un droit donné.
   *
   * @param role droit recherché
   * @return les profils qui le portent, éventuellement aucun
   */
  public static Set<UserProfile> ofRole(UserRole role) {
    Set<UserProfile> profiles = new LinkedHashSet<>();
    for (UserProfile profile : values()) {
      if (profile.getRoles().contains(role)) {
        profiles.add(profile);
      }
    }
    return profiles;
  }

  /**
   * Tout ce qu'il suffit de détenir pour exercer un droit.
   *
   * <p>Le droit lui-même, s'il a été accordé directement ; l'un des profils qui le portent ; ou
   * le super administrateur, qui passe partout. La liste est faite pour être donnée telle quelle
   * à la vérification de rôles du socle, qui reconnaît tout objet portant un code.</p>
   *
   * <p>Le type est {@code Enum<?>} et non {@code Object} : le mélange de {@link UserRole} et de
   * {@link UserProfile} est voulu, mais il n'y a aucune raison d'y admettre autre chose. Le
   * socle attend un {@code Object[]}, auquel un {@code Enum<?>[]} se donne tel quel.</p>
   *
   * @param role droit à exercer
   * @return les rôles et profils qui l'ouvrent
   */
  public static Collection<Enum<?>> grantorsOf(UserRole role) {
    Collection<Enum<?>> grantors = new LinkedHashSet<>();
    grantors.add(UserRole.SUPER_ADMINISTRATOR);
    grantors.add(role);
    grantors.addAll(ofRole(role));
    return grantors;
  }

  /**
   * Tout ce qu'il suffit de détenir pour exercer au moins un droit parmi plusieurs.
   *
   * @param roles droits examinés
   * @return les rôles et profils qui en ouvrent au moins un
   */
  public static Enum<?>[] grantorsOfAny(UserRole... roles) {
    Collection<Enum<?>> grantors = new LinkedHashSet<>();
    for (UserRole role : List.of(roles)) {
      grantors.addAll(grantorsOf(role));
    }
    return grantors.toArray(new Enum<?>[0]);
  }
}
