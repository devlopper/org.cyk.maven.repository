package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ActionService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ActionClient extends AbstractClient<ActionService>
    implements GetByIdentifier<ActionDto>,
               GetMany<ActionGetManyResponseDto>,
               DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ActionClient service(ActionService service) {
    return (ActionClient) super.service(service);
  }

  /**
   * {@link ActionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ActionCreateRequestDto request) {
    return new CreateExecutor(ActionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ActionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ActionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ActionGetManyResponseDto>(
      ActionGetManyResponseDto.class,
        ActionService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }

  /**
   * {@link ActionService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ActionGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ActionService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ActionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ActionDto>(ActionDto.class,
        ActionService.GET_ONE_IDENTIFIER)
           .execute(() -> service().getOne(request));
  }

  /**
   * {@link ActionService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ActionDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ActionService#getByIdentifier}.
   *
   * @param request requête
   * @return declaration
   */
  public ActionDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ActionDto>(ActionDto.class,
        ActionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ActionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ActionDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ActionService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ActionUpdateRequestDto request) {
    return new IdentifiableExecutor(ActionService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ActionService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ActionService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ActionService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
