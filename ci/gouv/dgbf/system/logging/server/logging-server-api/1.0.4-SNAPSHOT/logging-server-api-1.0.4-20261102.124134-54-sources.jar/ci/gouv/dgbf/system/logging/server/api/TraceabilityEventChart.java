package ci.gouv.dgbf.system.logging.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques de {@link TraceabilityEventDto}.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum TraceabilityEventChart {

  /**
   * Répartition par catégorie.
   */
  CATEGORY(TraceabilityEventChartCode.CATEGORY, "Répartition par catégorie"),

  /**
   * Répartition par type d'action.
   */
  ACTION_TYPE(TraceabilityEventChartCode.ACTION_TYPE, "Répartition par type d'action"),

  /**
   * Répartition par niveau.
   */
  LEVEL(TraceabilityEventChartCode.LEVEL, "Répartition par niveau"),

  /**
   * Volume par jour.
   */
  VOLUME_BY_DAY(TraceabilityEventChartCode.VOLUME_BY_DAY, "Volume par jour"),

  /**
   * Top processus émetteurs.
   */
  PROCESS(TraceabilityEventChartCode.PROCESS, "Top processus émetteurs"),

  /**
   * Répartition par utilisateur.
   */
  USER(TraceabilityEventChartCode.USER, "Répartition par utilisateur"),

  /**
   * Indicateurs clés (KPIs).
   */
  KPIS(TraceabilityEventChartCode.KPIS, "Indicateurs clés"),

  /**
   * Tableau de bord global.
   */
  DASHBOARD(TraceabilityEventChartCode.DASHBOARD, "Tableau de bord"),

  /**
   * Tableau de bord d'activité d'un utilisateur.
   */
  USER_ACTIVITY(TraceabilityEventChartCode.USER_ACTIVITY, "Activité utilisateur"),

  /**
   * Date de dernière activité de l'utilisateur.
   */
  LAST_ACTIVITY(TraceabilityEventChartCode.LAST_ACTIVITY, "Dernière activité"),

  /**
   * Objets les plus consultés ou traités.
   */
  TOP_RECORDS(TraceabilityEventChartCode.TOP_RECORDS, "Objets les plus consultés"),

  /**
   * Activité par session.
   */
  SESSIONS(TraceabilityEventChartCode.SESSIONS, "Activité par session"),

  /**
   * Erreurs récentes de l'utilisateur.
   */
  RECENT_ERRORS(TraceabilityEventChartCode.RECENT_ERRORS, "Erreurs récentes"),

  /**
   * Recherche d'utilisateurs.
   */
  USER_SEARCH(TraceabilityEventChartCode.USER_SEARCH, "Recherche d'utilisateurs");

  private final String code;
  private final String name;

  /**
   * Cette méthode permet d'obtenir {@link TraceabilityEventChart} par code.
   *
   * @param code code
   * @return graphique
   */
  public static TraceabilityEventChart getByCode(String code) {
    return Stream.of(values()).filter(c -> c.getCode().equals(code)).findFirst().orElse(null);
  }
}

