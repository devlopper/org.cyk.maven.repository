package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.CreateManyRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateAmountRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollComponentStaffProjectionService}.
 *
 * @author parfait
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollComponentStaffProjectionClient
    extends AbstractClient<PayrollComponentStaffProjectionService>
    implements GetByIdentifier<PayrollComponentStaffProjectionDto>,
    GetMany<PayrollComponentStaffProjectionGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollComponentStaffProjectionClient service(
          PayrollComponentStaffProjectionService service) {
    return (PayrollComponentStaffProjectionClient) super.service(service);
  }

  /**
   * {@link PayrollComponentStaffProjectionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollComponentStaffProjectionCreateRequestDto request) {
    return new CreateExecutor(PayrollComponentStaffProjectionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentStaffProjectionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollComponentStaffProjectionGetManyResponseDto>(
        PayrollComponentStaffProjectionGetManyResponseDto.class,
        PayrollComponentStaffProjectionService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentStaffProjectionGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollComponentStaffProjectionService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentStaffProjectionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollComponentStaffProjectionDto>(
            PayrollComponentStaffProjectionDto.class,
        PayrollComponentStaffProjectionService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollComponentProjectionService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollComponentStaffProjectionDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollComponentStaffProjectionService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollComponentStaffProjectionDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollComponentStaffProjectionDto>(
            PayrollComponentStaffProjectionDto.class,
        PayrollComponentStaffProjectionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentStaffProjectionDto getByIdentifier(String identifier, 
          ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollComponentStaffProjectionService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollComponentStaffProjectionUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentStaffProjectionService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#updateAmount}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateAmount(
      PayrollComponentStaffProjectionUpdateAmountRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentStaffProjectionService.UPDATE_AMOUNT_IDENTIFIER)
        .execute(() -> service().updateAmount(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentStaffProjectionService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollComponentStaffProjectionService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
  
  /**
   * {@link PayrollComponentStaffProjectionService#createMany}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createMany(CreateManyRequestDto request) {
    return new CreateExecutor(
            PayrollComponentStaffProjectionService.CREATE_MANY_IDENTIFIER)
        .execute(() -> service().createMany(request));
  }
}
