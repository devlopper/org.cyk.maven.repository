package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ActivityDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;

  /**
   * Identifiant {@link TriennialProgramDto} exclu.
   */
  String excludedTriennialProgramIdentifier;

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * Identifiant de {@link ActivityCategoryDto}.
   */
  String categoryIdentifier;

  /**
   * Identifiant de {@link FunctionalAccountDto}.
   */
  String functionalAccountIdentifier;

  /**
   * Identifiant de {@link EconomicNatureDto}.
   */
  String economicNatureIdentifier;


  /**
   * {@link ActivityCategory}.
   */
  ActivityCategory category;


  /**
   * Identifiant {@link ActivityDto} pour identifier l'opération parente.
   */
  String referencedActivityIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ActivityFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
    excludedTriennialProgramIdentifier = getExcludedTriennialProgramIdentifier(filter);
    categoryIdentifier = getCategoryIdentifier(filter);
    category = getCategory(filter);
    referencedActivityIdentifier = getReferencedActivityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
    setExcludedTriennialProgramIdentifier(filter, excludedTriennialProgramIdentifier);
    setCategoryIdentifier(filter, categoryIdentifier);
    setCategory(filter, category);
    setReferencedActivityIdentifier(filter, referencedActivityIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramDto} exclu.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link TriennialProgramDto} exclu
   */
  public static void setExcludedTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXCLUDED_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramDto} exclu.
   *
   * @param filter filtre
   * @return identifiant de {@link TriennialProgramDto} exclu
   */
  public static String getExcludedTriennialProgramIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_EXCLUDED_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ActivityCategoryDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link ActivityCategoryDto}
   */
  public static void setCategoryIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_CATEGORY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityCategoryDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ActivityCategoryDto}
   */
  public static String getCategoryIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CATEGORY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner la {@link ActivityCategory}.
   *
   * @param filter   filtre
   * @param category {@link ActivityCategory}
   */
  public static void setCategory(FilterDto filter, ActivityCategory category) {
    set(filter, JSON_CATEGORY, f -> f.getValueAsString(), f -> f.setValueAsEnum(category));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityCategory}.
   *
   * @param filter filtre
   * @return {@link ActivityCategory}
   */
  public static ActivityCategory getCategory(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_CATEGORY, ActivityCategory.class));
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de l'activité de référence de
   * {@link ActivityDto}.
   *
   * @param filter                       filtre
   * @param referencedActivityIdentifier identifiant de {@link ActivityDto} pour l'opération de
   *                                     référence.
   */
  public static void setReferencedActivityIdentifier(FilterDto filter,
                                                     String referencedActivityIdentifier) {
    set(filter, JSON_REFERENCED_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(referencedActivityIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'activité de référence de {@link ActivityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ActivityDto} pour l'opération de référence.
   */
  public static String getReferencedActivityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REFERENCED_ACTIVITY_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #excludedTriennialProgramIdentifier}.
   */
  public static final String JSON_EXCLUDED_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER + "Exclu";

  /**
   * Identifiant json champ {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = ActivityDto.JSON_CATEGORY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #functionalAccountIdentifier}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER =
      ActivityDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #category}.
   */
  public static final String JSON_CATEGORY = ActivityDto.JSON_CATEGORY;


  /**
   * Identifiant json champ {@link #categoryIdentifier}.
   */
  public static final String JSON_REFERENCED_ACTIVITY_IDENTIFIER =
      ActivityDto.JSON_REFERENCED_ACTIVITY_IDENTIFIER;
}
