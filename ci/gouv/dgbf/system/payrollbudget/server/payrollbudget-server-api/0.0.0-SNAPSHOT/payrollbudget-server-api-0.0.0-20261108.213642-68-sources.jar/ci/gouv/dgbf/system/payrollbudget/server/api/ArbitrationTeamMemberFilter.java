package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des membres d'équipe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ArbitrationTeamMemberFilter extends AbstractIdentifiableFilter {

  /**
   * Équipe dont on veut les membres.
   */
  String teamIdentifier;

  /**
   * Identifiant de connexion du membre.
   */
  String user;

  public ArbitrationTeamMemberFilter() {
    super();
  }

  public ArbitrationTeamMemberFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setTeamIdentifier(ArbitrationMovementFilter.read(filter,
        ArbitrationTeamMemberDto.JSON_TEAM_IDENTIFIER));
    setUser(ArbitrationMovementFilter.read(filter, ArbitrationTeamMemberDto.JSON_USER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    ArbitrationMovementFilter.write(filter, ArbitrationTeamMemberDto.JSON_TEAM_IDENTIFIER,
        getTeamIdentifier());
    ArbitrationMovementFilter.write(filter, ArbitrationTeamMemberDto.JSON_USER, getUser());
  }
}
