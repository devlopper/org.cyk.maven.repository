package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MailDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link MailDto}.

    @author Christian
               """)
public interface MailRequestMapper
    extends RequestMapper<MailDto, MailCreateRequestDto,
        MailUpdateRequestDto> {

}
