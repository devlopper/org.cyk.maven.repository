package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementService.PayrollElementCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementService.PayrollElementUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollElementDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollElementDto}.

    @author stephane
               """)
public interface PayrollElementRequestMapper
    extends RequestMapper<PayrollElementDto, 
            PayrollElementCreateRequestDto, PayrollElementUpdateRequestDto> {

}
