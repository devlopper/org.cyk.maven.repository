package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de libellé du groupe d'utilisateurs à
 * créer (module Utilisateur).
 *
 * @author Arnaud
 */
public interface HasUsersGroupName extends HasField {

  /**
   * Cette méthode permet d'obtenir le libellé du groupe d'utilisateurs.
   *
   * @return le libellé du groupe d'utilisateurs
   */
  String getUsersGroupName();

  /**
   * Cette méthode permet d'assigner le libellé du groupe d'utilisateurs.
   *
   * @param usersGroupName le libellé du groupe d'utilisateurs
   */
  void setUsersGroupName(String usersGroupName);

  /**
   * Identifiant java du libellé du groupe d'utilisateurs.
   */
  String FIELD_USERS_GROUP_NAME = "usersGroupName";
}
