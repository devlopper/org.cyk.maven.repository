package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente un ouvreur de visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerOpener {
  private static final Logger LOGGER = Logger.getLogger(ViewerOpener.class.getName());

  @Inject
  @Getter
  ViewerOpenerScriptBuilder scriptBuilder;

  /**
   * Cette méthode permet permet d'ouvrir un visualisateur.
   *
   */
  public void open() {
    validate();
    String script = scriptBuilder.build();
    validate(script);
    PrimeFaces.current().executeScript(script);
    LOGGER.log(Level.FINER, "Visualisateur ouvert. {0}", script);
  }
  
  void validate() {
    if (scriptBuilder == null) {
      throw new IllegalArgumentException(
          "Le constructeur du script d'ouverture du visualisateur est obligatoire");
    }
  }
  
  void validate(String script) {
    if (Core.isStringBlank(script)) {
      throw new IllegalStateException(
          "Le script d'ouverture du visualisateur est obligatoire");
    }
  }
}
