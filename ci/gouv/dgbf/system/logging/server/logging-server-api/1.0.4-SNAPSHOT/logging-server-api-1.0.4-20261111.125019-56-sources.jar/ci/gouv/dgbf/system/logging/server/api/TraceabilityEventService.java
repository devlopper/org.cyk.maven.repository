package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;

/** Service de lecture transverse des événements de traçabilité. */
@Path(TraceabilityEventService.PATH)
public interface TraceabilityEventService extends SpecificService {

  String PATH = "evenements-tracabilite";

  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EVENEMENTS_TRACABILITE";
  String GET_MANY_PATH = "obtention/plusieurs";

  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_EVENEMENT_TRACABILITE";
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_EVENEMENTS_TRACABILITE";
  String GET_CHART_PATH = "obtention/graphique";

  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getMany(GetManyRequestDto request);

  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getChart(GetChartRequestDto request);

  /** Réponse paginée des événements de traçabilité. */
  class TraceabilityEventGetManyResponseDto
      extends AbstractGetByPageResponseDto<TraceabilityEventDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TraceabilityEventDto> datas;

    @Override
    public List<TraceabilityEventDto> getDatas() {
      return datas;
    }

    @Override
    public void setDatas(List<TraceabilityEventDto> datas) {
      this.datas = datas;
    }
  }
}
