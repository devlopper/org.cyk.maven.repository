package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimableCascadeDependencyDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-23T12:07:56+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimableCascadeDependencyRequestMapperImpl implements ClaimableCascadeDependencyRequestMapper {

    @Override
    public ClaimableCascadeDependencyService.ClaimableCascadeDependencyCreateRequestDto mapCreate(ClaimableCascadeDependencyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableCascadeDependencyService.ClaimableCascadeDependencyCreateRequestDto claimableCascadeDependencyCreateRequestDto = new ClaimableCascadeDependencyService.ClaimableCascadeDependencyCreateRequestDto();

        claimableCascadeDependencyCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableCascadeDependencyCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableCascadeDependencyCreateRequestDto.setParentClaimableIdentifier( arg0.getParentClaimableIdentifier() );
        claimableCascadeDependencyCreateRequestDto.setChildClaimableIdentifier( arg0.getChildClaimableIdentifier() );

        return claimableCascadeDependencyCreateRequestDto;
    }

    @Override
    public ClaimableCascadeDependencyService.ClaimableCascadeDependencyUpdateRequestDto mapUpdate(ClaimableCascadeDependencyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableCascadeDependencyService.ClaimableCascadeDependencyUpdateRequestDto claimableCascadeDependencyUpdateRequestDto = new ClaimableCascadeDependencyService.ClaimableCascadeDependencyUpdateRequestDto();

        claimableCascadeDependencyUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableCascadeDependencyUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableCascadeDependencyUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimableCascadeDependencyUpdateRequestDto.setParentClaimableIdentifier( arg0.getParentClaimableIdentifier() );
        claimableCascadeDependencyUpdateRequestDto.setChildClaimableIdentifier( arg0.getChildClaimableIdentifier() );

        return claimableCascadeDependencyUpdateRequestDto;
    }
}
