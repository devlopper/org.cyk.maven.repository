package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un format d'exemple de valeurs de paramètres.
 *
 * @author Christian
 */
public interface HasParameterValuesExampleFormat extends HasField {

  /**
   * Cette méthode permet d'obtenir le format de l'exemple de valeurs de paramètres.
   *
   * @return le format de l'exemple de valeurs de paramètres
   */
  StringFormat getParameterValuesExampleFormat();

  /**
   * Cette méthode permet d'assigner le format de l'exemple de valeurs de paramètres.
   *
   * @param parameterValuesExampleFormat le format de l'exemple de valeurs de paramètres
   */
  void setParameterValuesExampleFormat(StringFormat parameterValuesExampleFormat);

  /**
   * Identifiant java du format de l'exemple de valeurs de paramètres.
   */
  String FIELD_PARAMETER_VALUES_EXAMPLE_FORMAT = "parameterValuesExampleFormat";
}
