package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileGroupArchivalJournalFieldKind}.
 *
 * @author Christian
 *
 */
public class FileGroupArchivalJournalFieldKindCode {

  private FileGroupArchivalJournalFieldKindCode() {

  }

  /**
   * Motif de la demande.
   */
  public static final String SOLICITATION = "DEMANDE";

  /**
   * Motif de refus.
   */
  public static final String REFUSAL = "REFUS";

  /**
   * Motif d'annulation.
   */
  public static final String CANCELLATION = "ANNULATION";

  /**
   * Motif de début (voie directe).
   */
  public static final String DIRECT_ARCHIVING = "ARCHIVAGE_DIRECT";

  /**
   * Motif de fin (voie directe).
   */
  public static final String DIRECT_UNARCHIVING = "DESARCHIVAGE_DIRECT";
}
