package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de diagnostique.
 *
 * @author Christian
 */
public interface HasDiagnostic extends HasField {

  /**
   * Cette méthode permet d'obtenir le diagnostique.
   *
   * @return le diagnostique
   */
  String getDiagnostic();
  
  /**
   * Cette méthode permet d'assigner le diagnostique.
   *
   * @param diagnostic le diagnostique
   */
  void setDiagnostic(String diagnostic);
  
  /**
   * Identifiant java du diagnostique.
   */
  String FIELD_DIAGNOSTIC = "diagnostic";
}
