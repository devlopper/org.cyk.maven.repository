package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetAdministrativeUnitStaffDto}.
*
* @author parfait
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-17T13:47:55+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetAdministrativeUnitStaffRequestMapperImpl implements BudgetAdministrativeUnitStaffRequestMapper {

    @Override
    public BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffCreateRequestDto mapCreate(BudgetAdministrativeUnitStaffDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffCreateRequestDto budgetAdministrativeUnitStaffCreateRequestDto = new BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffCreateRequestDto();

        budgetAdministrativeUnitStaffCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetAdministrativeUnitStaffCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetAdministrativeUnitStaffCreateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        budgetAdministrativeUnitStaffCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        budgetAdministrativeUnitStaffCreateRequestDto.setJobIdentifier( arg0.getJobIdentifier() );
        budgetAdministrativeUnitStaffCreateRequestDto.setCompetence( arg0.getCompetence() );
        budgetAdministrativeUnitStaffCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        budgetAdministrativeUnitStaffCreateRequestDto.setIsFunctionary( arg0.getIsFunctionary() );
        budgetAdministrativeUnitStaffCreateRequestDto.setStaff( arg0.getStaff() );
        budgetAdministrativeUnitStaffCreateRequestDto.setAmount( arg0.getAmount() );

        return budgetAdministrativeUnitStaffCreateRequestDto;
    }

    @Override
    public BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffUpdateRequestDto mapUpdate(BudgetAdministrativeUnitStaffDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffUpdateRequestDto budgetAdministrativeUnitStaffUpdateRequestDto = new BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffUpdateRequestDto();

        budgetAdministrativeUnitStaffUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setJobIdentifier( arg0.getJobIdentifier() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setCompetence( arg0.getCompetence() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setIsFunctionary( arg0.getIsFunctionary() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setStaff( arg0.getStaff() );
        budgetAdministrativeUnitStaffUpdateRequestDto.setAmount( arg0.getAmount() );

        return budgetAdministrativeUnitStaffUpdateRequestDto;
    }
}
