package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SupplierDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SupplierDto}.
    
    @author Christian
    """)
public interface SupplierRequestMapper
    extends
    RequestMapper<SupplierDto,
        SupplierService.SupplierCreateRequestDto,
        SupplierService.SupplierUpdateRequestDto> {

}
