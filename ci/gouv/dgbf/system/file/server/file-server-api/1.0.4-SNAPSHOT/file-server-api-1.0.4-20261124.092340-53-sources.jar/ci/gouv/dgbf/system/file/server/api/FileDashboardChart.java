package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques du tableau de bord du module Fichier
 * (RG_FILE_UI_05).
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum FileDashboardChart {

  /**
   * Indicateurs clés.
   */
  KPIS(FileDashboardChartCode.KPIS, "Indicateurs"),

  /**
   * Évolution des archivages et désarchivages.
   */
  EVOLUTION(FileDashboardChartCode.EVOLUTION, "Évolution des archivages"),

  /**
   * Répartition des Demandes d'archivage.
   */
  DISTRIBUTION(FileDashboardChartCode.DISTRIBUTION, "Répartition des demandes");

  private final String code;
  private final String name;

  /**
   * Cette méthode permet d'obtenir {@link FileDashboardChart} par code.
   *
   * @param code code
   * @return graphique
   */
  public static FileDashboardChart getByCode(String code) {
    return Stream.of(values()).filter(c -> c.getCode().equals(code)).findFirst().orElse(null);
  }
}
