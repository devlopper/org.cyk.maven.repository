package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController.FormLayout;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryClient;
import ci.gouv.dgbf.system.file.server.api.FileCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FileCategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileCategoryController extends AbstractController {

  @Inject
  FileCategoryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileCategoryRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FileCategoryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FileCategoryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileCategoryService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.setFormLayout(FormLayout.STACKED);
    listController.initialize();

    /* Creation */

    // Les champs sont partagés avec la modification : la création repart de champs vides.
    listController.getCreateController().addEntityConsumer(entity -> {
      codeInputTextController.getInputText().writeValue(null);
      nameInputTextController.getInputText().writeValue(null);
    });
    listController.getCreateController().setFunction(entity -> {
      FileCategoryCreateRequestDto request = requestMapper.mapCreate((FileCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    /* Update */

    listController.getUpdateController().addEntityConsumer(entity -> {
      codeInputTextController.getInputText().writeValue(((FileCategoryDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((FileCategoryDto) entity).getName());
    });
    listController.getUpdateController().setFunction(entity -> {
      FileCategoryUpdateRequestDto request = requestMapper.mapUpdate((FileCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */

    codeInputTextController.initializeCode(
        v -> listController.getCreateControllerOrUpdateControllerEntityAs(FileCategoryDto.class)
            .setCode(v));
    nameInputTextController.initializeName(
        v -> listController.getCreateControllerOrUpdateControllerEntityAs(FileCategoryDto.class)
            .setName(v));
  }
}
