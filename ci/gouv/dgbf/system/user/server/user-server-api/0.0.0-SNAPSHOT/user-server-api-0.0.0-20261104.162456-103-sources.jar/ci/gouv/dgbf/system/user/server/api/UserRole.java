package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import java.util.Objects;
import lombok.Getter;

/**
 * Cette énumération représente les Droits (rôles applicatifs) du module : chacun est accordé par
 * un Rôle réservé, pour une portée donnée (RG_UTI_ROL_16). C'est le seul endroit qui traduit les
 * Rôles réservés en Droits ; le frontal (jeton) et le serveur (base) appliquent la même règle,
 * {@link #isGrantedTo(ReservedRolesHolder, String, String)}.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // Role utilisateur
  /**
   * Assigner.
   */
  ASSIGN_USER_ROLE("ASSIGNER_ROLE_UTILISATEUR", ReservedRole.FUNCTIONAL_ADMINISTRATOR,
      Scope.APPLICATION),

  /**
   * Revoquer.
   */
  REVOKE_USER_ROLE("REVOQUER_ROLE_UTILISATEUR", ReservedRole.FUNCTIONAL_ADMINISTRATOR,
      Scope.APPLICATION),

  /**
   * Traiter (accepter, refuser) une demande de rôle (RG_UTI_ROL_12).
   */
  PROCESS_ROLE_SOLICITATION("TRAITER_DEMANDE_ROLE", ReservedRole.FUNCTIONAL_ADMINISTRATOR,
      Scope.APPLICATION),

  // UserRole
  /**
   * Assigner rôle administrateur applicatif.
   */
  ASSIGN_APPLICATION_ADMINISTRATOR_USER_ROLE("ASSIGNER_ADMINISTRATEUR_APPLICATIF",
      ReservedRole.DOMAIN_ADMINISTRATOR, Scope.DOMAIN),

  /**
   * Assigner rôle administrateur technique.
   */
  ASSIGN_TECHNICAL_ADMINISTRATOR_USER_ROLE("ASSIGNER_ADMINISTRATEUR_TECHNIQUE",
      ReservedRole.APPLICATION_ADMINISTRATOR, Scope.APPLICATION),

  /**
   * Assigner rôle administrateur fonctionnel.
   */
  ASSIGN_FUNCTIONAL_ADMINISTRATOR_USER_ROLE("ASSIGNER_ADMINISTRATEUR_FONCTIONNEL",
      ReservedRole.APPLICATION_ADMINISTRATOR, Scope.APPLICATION),

  // Domain

  /**
   * Gérer (créer, modifier, supprimer) les domaines : l'Administrateur de {@code master}.
   */
  MANAGE_DOMAIN("GERER_DOMAINE", ReservedRole.DOMAIN_ADMINISTRATOR, Scope.MASTER),

  /**
   * Désigner un administrateur de domaine : celui de {@code master} pour tout Domaine, celui d'un
   * Domaine pour ce Domaine (RG_UTI_ROL_08).
   */
  ASSIGN_DOMAIN_ADMINISTRATOR_USER_ROLE("DESIGNER_ADMINISTRATEUR_DOMAINE",
      ReservedRole.DOMAIN_ADMINISTRATOR, Scope.MASTER_OR_DOMAIN),

  // User

  /**
   * Créer un utilisateur.
   */
  CREATE_USER("CREER_UTILISATEUR", ReservedRole.DOMAIN_ADMINISTRATOR, Scope.DOMAIN),

  /**
   * Créer un compte.
   */
  CREATE_ACCOUNT("CREER_COMPTE", ReservedRole.DOMAIN_ADMINISTRATOR, Scope.DOMAIN),

  /**
   * Synchroniser vers Keycloak les noms des utilisateurs d'un domaine.
   */
  SYNCHRONIZE_USER_NAMES("SYNCHRONISER_NOMS_UTILISATEURS", ReservedRole.DOMAIN_ADMINISTRATOR,
      Scope.DOMAIN),

  // Role

  /**
   * Gérer (créer, modifier, supprimer) les Rôles applicatifs, et changer la Nature d'un Rôle
   * (RG_UTI_ROL_18, RG_UTI_ROL_21).
   */
  MANAGE_APPLICATION_ROLE("GERER_ROLE_APPLICATIF", ReservedRole.APPLICATION_ADMINISTRATOR,
      Scope.APPLICATION),

  /**
   * Gérer les Rôles métier et leur composition (RG_UTI_ROL_18, RG_UTI_ROL_19).
   */
  MANAGE_BUSINESS_ROLE("GERER_ROLE_METIER", ReservedRole.TECHNICAL_ADMINISTRATOR,
      Scope.APPLICATION),

  /**
   * Définir le caractère Demandable d'un Rôle ordinaire (RG_UTI_ROL_20).
   */
  DEFINE_ROLE_REQUEST_POLICY("DEFINIR_POLITIQUE_DEMANDE_ROLE",
      ReservedRole.APPLICATION_ADMINISTRATOR, Scope.APPLICATION),

  // Application

  /**
   * Gérer.
   */
  MANAGE_APPLICATION("GERER_APPLICATION", ReservedRole.DOMAIN_ADMINISTRATOR, Scope.DOMAIN);

  private UserRole(String code, String reservedRole, Scope scope) {
    this.code = code;
    this.reservedRole = reservedRole;
    this.scope = scope;
  }

  /**
   * Code.
   */
  String code;

  /**
   * Code du Rôle réservé qui accorde ce Droit ({@link ReservedRole}).
   */
  String reservedRole;

  /**
   * Portée du Droit.
   */
  Scope scope;

  /**
   * Cette méthode indique si le Droit est accordé, pour un objet, par les Rôles réservés détenus.
   *
   * @param holder            Rôles réservés de l'Utilisateur
   * @param domainCode        Code du Domaine de l'objet (le Domaine lui-même, ou celui de
   *                          l'Application)
   * @param applicationCode   Code de l'Application de l'objet, null pour un Domaine
   * @return vrai si le Droit est accordé
   */
  public boolean isGrantedTo(ReservedRolesHolder holder, String domainCode,
      String applicationCode) {
    if (holder == null) {
      return false;
    }
    boolean sameDomain = Objects.equals(holder.getDomainCode(), domainCode);
    boolean master = DomainDto.CODE_MASTER.equals(holder.getDomainCode());
    if (scope == Scope.APPLICATION) {
      return sameDomain && applicationCode != null && holder.holds(reservedRole, applicationCode);
    }
    if (!holder.isDomainAdministrator()) {
      return false;
    }
    if (scope == Scope.MASTER) {
      return master;
    }
    return scope == Scope.DOMAIN ? sameDomain : master || sameDomain;
  }

  /**
   * Cette énumération représente la portée d'un Droit.
   */
  public enum Scope {
    /**
     * Le Domaine {@code master} : l'Administrateur de {@code master}.
     */
    MASTER,
    /**
     * Tout Domaine pour l'Administrateur de {@code master}, sinon le Domaine de l'Utilisateur.
     */
    MASTER_OR_DOMAIN,
    /**
     * Le Domaine de l'Utilisateur : son Administrateur.
     */
    DOMAIN,
    /**
     * Une Application du Domaine de l'Utilisateur : le détenteur du Rôle réservé sur elle.
     */
    APPLICATION
  }
}
