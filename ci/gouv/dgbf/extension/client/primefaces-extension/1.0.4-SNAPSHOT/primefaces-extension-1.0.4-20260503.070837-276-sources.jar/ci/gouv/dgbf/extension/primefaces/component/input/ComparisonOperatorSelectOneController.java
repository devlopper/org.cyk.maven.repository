package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.enumeration.ComparisonOperator;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ComparisonOperator}.
 *
 * @author Christian
 *
 */
@Dependent
public class ComparisonOperatorSelectOneController
    extends AbstractSelectOneEnumerationController<ComparisonOperator> {

  protected ComparisonOperatorSelectOneController() {
    super(ComparisonOperator.values());
    outputLableValue = "Opérateur de comparaison";
  }

  @Override
  protected String computeSelectItemLabel(ComparisonOperator operator) {
    return operator.getName();
  }
}
