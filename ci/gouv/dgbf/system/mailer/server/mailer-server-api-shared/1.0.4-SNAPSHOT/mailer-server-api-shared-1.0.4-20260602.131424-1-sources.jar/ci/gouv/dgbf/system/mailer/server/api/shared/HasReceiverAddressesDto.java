package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a des adresses de destinataire.
 *
 * @author Christian
 */
public interface HasReceiverAddressesDto extends HasReceiverAddresses {

  /**
   * Identifiant json des adresses des destinataires.
   */
  String JSON_RECEIVER_ADDRESSES = "adressesDestinataires";
}
