package ci.gouv.dgbf.system.datastructures.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.server.service.api.filter.DataEntityIdentifierFilter;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ValueSourceGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class ValueSourceGroupFilterController
    extends AbstractFilterController<ValueSourceGroupFilter> {

  @Inject
  @Getter
  DataEntitySelectOneController dataEntitySelectOneController;

  /**
   * Cette méthode permet d'instantier.
   */
  public ValueSourceGroupFilterController() {
    super(ValueSourceGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setDataEntityIdentifier(getRequestParameter(DataEntityIdentifierFilter.JSON_KEY));

    dataEntitySelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setDataEntityIdentifier(identifier));

  }



}
