package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueSourceGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueSourceGroupDto}.

    @author Christian
               """)
public interface ValueSourceGroupRequestMapper extends RequestMapper<ValueSourceGroupDto,
    ValueSourceGroupCreateRequestDto, ValueSourceGroupUpdateRequestDto> {

}
