package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeCategoryService.AdministrativeUnitEmployeeCategoryGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link AdministrativeUnitEmployeeCategoryService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class AdministrativeUnitEmployeeCategoryClient
    extends AbstractClient<AdministrativeUnitEmployeeCategoryService>
    implements GetByIdentifier<AdministrativeUnitEmployeeCategoryDto>,
    GetMany<AdministrativeUnitEmployeeCategoryGetManyResponseDto>, GetChart<GetChartResponseDto> {

  @Override
  public AdministrativeUnitEmployeeCategoryClient service(
      AdministrativeUnitEmployeeCategoryService service) {
    return (AdministrativeUnitEmployeeCategoryClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitEmployeeCategoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeCategoryGetManyResponseDto>(
        AdministrativeUnitEmployeeCategoryGetManyResponseDto.class,
        AdministrativeUnitEmployeeCategoryService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitEmployeeCategoryGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitEmployeeCategoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeCategoryDto>(
        AdministrativeUnitEmployeeCategoryDto.class,
        AdministrativeUnitEmployeeCategoryService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitEmployeeCategoryDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AdministrativeUnitEmployeeCategoryDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeCategoryDto>(
        AdministrativeUnitEmployeeCategoryDto.class,
        AdministrativeUnitEmployeeCategoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AdministrativeUnitEmployeeCategoryDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
  
  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        AdministrativeUnitEmployeeCategoryService.GET_CHART_IDENTIFIER)
            .execute(() -> service().getChart(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeCategoryService#getChart}.
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditWho, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getChart(request);
  }
}
