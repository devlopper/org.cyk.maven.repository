package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PartitionUnitDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:53+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PartitionUnitRequestMapperImpl implements PartitionUnitRequestMapper {

    @Override
    public PartitionUnitService.PartitionUnitCreateRequestDto mapCreate(PartitionUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionUnitService.PartitionUnitCreateRequestDto partitionUnitCreateRequestDto = new PartitionUnitService.PartitionUnitCreateRequestDto();

        partitionUnitCreateRequestDto.setName( arg0.getName() );
        partitionUnitCreateRequestDto.setPartitionIdentifier( arg0.getPartitionIdentifier() );

        return partitionUnitCreateRequestDto;
    }

    @Override
    public PartitionUnitService.PartitionUnitUpdateRequestDto mapUpdate(PartitionUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionUnitService.PartitionUnitUpdateRequestDto partitionUnitUpdateRequestDto = new PartitionUnitService.PartitionUnitUpdateRequestDto();

        partitionUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        partitionUnitUpdateRequestDto.setName( arg0.getName() );
        partitionUnitUpdateRequestDto.setPartitionIdentifier( arg0.getPartitionIdentifier() );

        return partitionUnitUpdateRequestDto;
    }
}
