package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantService.ContextualConstantCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantService.ContextualConstantUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ContextualConstantDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ContextualConstantDto}.

    @author Christian
               """)
public interface ContextualConstantRequestMapper extends RequestMapper<ContextualConstantDto,
    ContextualConstantCreateRequestDto, ContextualConstantUpdateRequestDto> {

}
