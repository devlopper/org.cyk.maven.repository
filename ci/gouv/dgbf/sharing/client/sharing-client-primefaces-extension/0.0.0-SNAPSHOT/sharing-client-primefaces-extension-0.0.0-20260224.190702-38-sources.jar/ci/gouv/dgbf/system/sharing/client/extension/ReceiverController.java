package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverClient;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ReceiverController extends AbstractController {

  @Inject
  ReceiverClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ReceiverFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ReceiverDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ReceiverDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ReceiverService.PATH);
    listController.setFilterController(filterController);
    
    listController.getShowCreateDialogButton().setRendered(false);
    listController.getDataTable().getActionColumn().setRendered(false);
    
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        AbstractResourceOrReceiverDto.JSON_TYPE_AS_STRING,
        AbstractResourceOrReceiverDto.JSON_LOCATION_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();
  }
}
