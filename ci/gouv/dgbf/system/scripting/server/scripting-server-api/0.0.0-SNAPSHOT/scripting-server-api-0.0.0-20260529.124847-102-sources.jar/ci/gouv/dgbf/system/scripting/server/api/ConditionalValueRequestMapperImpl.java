package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ConditionalValueDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ConditionalValueRequestMapperImpl implements ConditionalValueRequestMapper {

    @Override
    public ConditionalValueService.ConditionalValueCreateRequestDto mapCreate(ConditionalValueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConditionalValueService.ConditionalValueCreateRequestDto conditionalValueCreateRequestDto = new ConditionalValueService.ConditionalValueCreateRequestDto();

        conditionalValueCreateRequestDto.setCode( arg0.getCode() );
        conditionalValueCreateRequestDto.setName( arg0.getName() );
        conditionalValueCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        conditionalValueCreateRequestDto.setValue( arg0.getValue() );
        conditionalValueCreateRequestDto.setValueType( arg0.getValueType() );

        return conditionalValueCreateRequestDto;
    }

    @Override
    public ConditionalValueService.ConditionalValueUpdateRequestDto mapUpdate(ConditionalValueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConditionalValueService.ConditionalValueUpdateRequestDto conditionalValueUpdateRequestDto = new ConditionalValueService.ConditionalValueUpdateRequestDto();

        conditionalValueUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        conditionalValueUpdateRequestDto.setCode( arg0.getCode() );
        conditionalValueUpdateRequestDto.setName( arg0.getName() );
        conditionalValueUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        conditionalValueUpdateRequestDto.setValue( arg0.getValue() );
        conditionalValueUpdateRequestDto.setValueType( arg0.getValueType() );

        return conditionalValueUpdateRequestDto;
    }

    @Override
    public ConditionalValueService.ConditionalValueCheckApplicabilityRequestDto mapCheckApplicability(ConditionalValueDto conditionalValue) {
        if ( conditionalValue == null ) {
            return null;
        }

        ConditionalValueService.ConditionalValueCheckApplicabilityRequestDto conditionalValueCheckApplicabilityRequestDto = new ConditionalValueService.ConditionalValueCheckApplicabilityRequestDto();

        conditionalValueCheckApplicabilityRequestDto.setIdentifier( conditionalValue.getIdentifier() );
        conditionalValueCheckApplicabilityRequestDto.setFilterValue( conditionalValue.getFilterValue() );
        Map<String, Object> map = conditionalValue.getValuesMap();
        if ( map != null ) {
            conditionalValueCheckApplicabilityRequestDto.setValuesMap( new LinkedHashMap<String, Object>( map ) );
        }

        return conditionalValueCheckApplicabilityRequestDto;
    }
}
