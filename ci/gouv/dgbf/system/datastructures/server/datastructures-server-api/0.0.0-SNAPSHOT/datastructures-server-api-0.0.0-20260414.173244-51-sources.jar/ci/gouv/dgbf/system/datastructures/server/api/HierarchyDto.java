package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une hiérarchie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class HierarchyDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasValueSourceIdentifierDto, HasValueSourceAsStringDto {

  @JsonbProperty(JSON_VALUE_SOURCE_IDENTIFIER)
  private String valueSourceIdentifier;

  @JsonbProperty(JSON_VALUE_SOURCE_AS_STRING)
  private String valueSourceAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idHierarchie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "hierarchieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "hiérarchie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
