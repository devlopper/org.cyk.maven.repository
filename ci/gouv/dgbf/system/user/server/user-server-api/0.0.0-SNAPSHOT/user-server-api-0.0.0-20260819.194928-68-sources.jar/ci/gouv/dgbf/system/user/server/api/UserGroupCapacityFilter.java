package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCapacityIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUserGroupIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserGroupCapacityDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class UserGroupCapacityFilter extends AbstractIdentifiableFilter
    implements FilterHasUserGroupIdentifier, FilterHasCapacityIdentifier {

  /**
   * Identifiant de {@link UserGroupDto}.
   */
  private String userGroupIdentifier;

  /**
   * Identifiant de {@link UserCapacityDto}.
   */
  private String capacityIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateUserGroupIdentifier(filter);
    updateCapacityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterUserGroupIdentifier(filter);
    updateFilterCapacityIdentifier(filter);
  }
}
