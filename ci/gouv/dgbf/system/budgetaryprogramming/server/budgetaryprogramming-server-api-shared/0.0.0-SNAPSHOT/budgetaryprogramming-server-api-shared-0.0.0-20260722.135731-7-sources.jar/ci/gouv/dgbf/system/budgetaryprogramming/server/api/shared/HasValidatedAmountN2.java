package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant validé à l'horizon N2.
 *
 * @author Christian
 */
public interface HasValidatedAmountN2 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant validé à l'horizon N2.
   *
   * @return le montant validé à l'horizon N2
   */
  Long getValidatedAmountN2();

  /**
   * Cette méthode permet d'assigner le montant validé à l'horizon N2.
   *
   * @param amount le montant validé à l'horizon N2
   */
  void setValidatedAmountN2(Long amount);

  /**
   * Identifiant java du montant validé à l'horizon N2.
   */
  String FIELD_VALIDATED_AMOUNT_N2 = "validatedAmountN2";
}
