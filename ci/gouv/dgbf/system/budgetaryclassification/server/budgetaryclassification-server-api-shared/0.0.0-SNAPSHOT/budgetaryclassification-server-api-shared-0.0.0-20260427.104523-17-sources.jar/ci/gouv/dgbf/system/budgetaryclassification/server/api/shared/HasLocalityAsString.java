package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * localité.
 *
 * @author Christian
 */
public interface HasLocalityAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de localité.
   *
   * @return représentation en chaine de caractères de localité
   */
  String getLocalityAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de localité.
   *
   * @param localityAsString représentation en chaine de caractères de localité
   */
  void setLocalityAsString(String localityAsString);

  /**
   * Identifiant java de la représentation en chaine de caractères de localité.
   */
  String FIELD_LOCALITY_AS_STRING = "localityAsString";
}
