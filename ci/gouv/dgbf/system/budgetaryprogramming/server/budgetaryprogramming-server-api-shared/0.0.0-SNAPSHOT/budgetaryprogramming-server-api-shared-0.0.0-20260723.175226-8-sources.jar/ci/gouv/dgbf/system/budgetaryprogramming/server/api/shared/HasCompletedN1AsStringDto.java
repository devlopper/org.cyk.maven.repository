package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+1 est complétée,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN1AsStringDto extends HasCompletedN1AsString {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N+1 est complétée,
   * sous forme de chaîne de caractères.
   */
  String JSON_COMPLETED_N1_AS_STRING = "completeN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName