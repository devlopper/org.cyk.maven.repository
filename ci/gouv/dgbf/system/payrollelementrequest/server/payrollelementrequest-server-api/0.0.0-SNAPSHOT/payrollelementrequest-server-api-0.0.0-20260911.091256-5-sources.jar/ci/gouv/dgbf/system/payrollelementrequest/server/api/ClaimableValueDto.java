package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une option concrète d'un {@link ClaimableDto}, selon {@link #nature} :
 * une instance d'Élément de Paie synchronisée depuis le module {@code payroll} (RG_REP_CIB_07), ou
 * une valeur autorisée pour une Constante de Paie, saisie par le métier (RG_REP_CIB_09).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableValueDto extends AbstractIdentifiableDto {

  /**
   * Identifiant du {@link ClaimableDto} dont cette ligne dépend.
   */
  @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
  private String claimableIdentifier;

  /**
   * Nature ({@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE}).
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * {@code ELEMENT_PAIE} : identifiant, module payroll, de l'instance d'Élément de Paie
   * synchronisée. {@code CONSTANTE_PAIE} : la valeur autorisée elle-même, interprétée selon
   * {@link #valueType}. Toujours renseignée.
   */
  @JsonbProperty(JSON_VALUE)
  private String value;

  /**
   * {@code ELEMENT_PAIE} uniquement : date de la dernière synchronisation ; {@code null} pour
   * {@code CONSTANTE_PAIE}.
   */
  @JsonbProperty(JSON_SYNCHRONIZATION_DATE)
  private String synchronizationDate;

  /**
   * {@code ELEMENT_PAIE} uniquement : code et libellé de l'instance, formatés "code - libellé"
   * par la synchronisation ; {@code null} pour {@code CONSTANTE_PAIE} (une valeur autorisée est
   * sa propre étiquette).
   */
  @JsonbProperty(JSON_LABEL)
  private String label;

  /**
   * {@code CONSTANTE_PAIE} uniquement : type de {@link #value} ; {@code null} pour
   * {@code ELEMENT_PAIE}.
   */
  @JsonbProperty(JSON_VALUE_TYPE)
  private String valueType;

  /**
   * Identifiant json {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #value}.
   */
  public static final String JSON_VALUE = "valeur";

  /**
   * Identifiant json {@link #synchronizationDate}.
   */
  public static final String JSON_SYNCHRONIZATION_DATE = "dateSynchronisation";

  /**
   * Identifiant json {@link #label}.
   */
  public static final String JSON_LABEL = "libelle";

  /**
   * Identifiant json {@link #valueType}.
   */
  public static final String JSON_VALUE_TYPE = "typeValeur";

  /**
   * Identifiant json de identifiant de {@link ClaimableValueDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idValeurReclamable";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimableValueDto}.
   */
  public static final String JSON_THIS_AS_STRING = "valeurReclamableChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "valeur réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "valeurs réclamables";

  /**
   * Nature Élément de Paie.
   */
  public static final String NATURE_ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Nature Constante de Paie.
   */
  public static final String NATURE_CONSTANTE_PAIE = "CONSTANTE_PAIE";
}
