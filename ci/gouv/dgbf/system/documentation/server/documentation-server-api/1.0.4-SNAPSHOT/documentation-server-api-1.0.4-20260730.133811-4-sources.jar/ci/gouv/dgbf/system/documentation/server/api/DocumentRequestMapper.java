package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentDto}.

    @author Christian
               """)
public interface DocumentRequestMapper
    extends RequestMapper<DocumentDto, DocumentCreateRequestDto, DocumentUpdateRequestDto> {

}
