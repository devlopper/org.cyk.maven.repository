package ci.gouv.dgbf.extension.server.service.impl;

/**
 * Cette classe représente une exception.
 *
 * @author Christian
 *
 */
public class ServerRuntimeException extends RuntimeException {

  /**
   * {@inheritDoc}
   *
   * @param message message
   */
  public ServerRuntimeException(String message) {
    super(message);
  }

}
