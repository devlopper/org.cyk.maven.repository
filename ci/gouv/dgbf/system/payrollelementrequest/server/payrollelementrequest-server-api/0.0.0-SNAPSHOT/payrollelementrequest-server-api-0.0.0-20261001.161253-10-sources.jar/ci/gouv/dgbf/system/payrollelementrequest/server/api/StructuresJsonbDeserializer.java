package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.json.JsonArray;
import jakarta.json.JsonValue;
import jakarta.json.bind.serializer.DeserializationContext;
import jakarta.json.bind.serializer.JsonbDeserializer;
import jakarta.json.stream.JsonParser;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Cette classe désérialise {@link FunctionaryDto#structures} en préservant l'ordre des clés
 * du document JSON source (cf. {@link OrderedJsonValues}) -- sans elle, la désérialisation JSON-B
 * générique d'un {@code Map} ne garantit aucun ordre, ce qui produit un affichage mélangé de la
 * Situation administrative côté client malgré l'ordre correct de {@code STRUCTURES_JSON} tel que
 * transmis par le serveur.
 *
 * @author akm
 *
 */
public class StructuresJsonbDeserializer implements JsonbDeserializer<List<Map<String, Object>>> {

  @SuppressWarnings("unchecked")
  @Override
  public List<Map<String, Object>> deserialize(JsonParser parser, DeserializationContext context,
      Type runtimeType) {
    JsonArray array = context.deserialize(JsonArray.class, parser);
    List<Map<String, Object>> structures = new ArrayList<>();
    for (JsonValue value : array) {
      structures.add((Map<String, Object>) OrderedJsonValues.toJavaValue(value));
    }
    return structures;
  }
}
