package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchicalRelationService.HierarchicalRelationCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchicalRelationService.HierarchicalRelationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link HierarchicalRelationDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link HierarchicalRelationDto}.

    @author Christian
               """)
public interface HierarchicalRelationRequestMapper extends RequestMapper<HierarchicalRelationDto,
    HierarchicalRelationCreateRequestDto, HierarchicalRelationUpdateRequestDto> {

}
