package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Nature de pièce justificative : ce que la réglementation exige pour un type de mouvement donné.
 *
 * <p>C'est le référentiel du contrôle d'admissibilité (CU02, RG6) : pour chaque ligne, l'écran
 * confronte les natures exigées — servies par ce contrat — aux pièces réellement jointes par
 * l'EPN. Une nature ne dit pas qu'un document existe ; elle dit qu'il <em>devrait</em>
 * exister.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportingDocumentNatureDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Famille de lignes concernée : mouvement ou mesure ponctuelle.
   */
  @JsonbProperty(JSON_ELEMENT_TYPE)
  private String elementType;

  /**
   * Type de mouvement pour lequel la pièce est exigée. Nul pour une exigence commune.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_CODE)
  private String movementTypeCode;

  /**
   * Vrai si la pièce conditionne l'admissibilité, faux pour une pièce d'appoint.
   */
  @JsonbProperty(JSON_MANDATORY)
  private Boolean mandatory;

  /**
   * Vrai tant que la nature peut être exigée d'un nouveau dépôt.
   */
  @JsonbProperty(JSON_ACTIVE)
  private Boolean active;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idNaturePieceJustificative";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "naturePieceJustificativeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "nature de pièce justificative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "natures de pièces justificatives";

  /**
   * Identifiant json pour {@link #elementType}.
   */
  public static final String JSON_ELEMENT_TYPE = ArbitrationMovementDto.JSON_ELEMENT_TYPE;

  /**
   * Identifiant json pour {@link #movementTypeCode}.
   */
  public static final String JSON_MOVEMENT_TYPE_CODE =
      ArbitrationMovementDto.JSON_MOVEMENT_TYPE_CODE;

  /**
   * Identifiant json pour {@link #mandatory}.
   */
  public static final String JSON_MANDATORY = "estObligatoire";

  /**
   * Identifiant json pour {@link #active}.
   */
  public static final String JSON_ACTIVE = "estActif";
}
