package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingExerciseDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-05T20:53:21+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingExerciseRequestMapperImpl implements ProgrammingExerciseRequestMapper {

    @Override
    public ProgrammingExerciseService.ProgrammingExerciseCreateRequestDto mapCreate(ProgrammingExerciseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingExerciseService.ProgrammingExerciseCreateRequestDto programmingExerciseCreateRequestDto = new ProgrammingExerciseService.ProgrammingExerciseCreateRequestDto();

        programmingExerciseCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingExerciseCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingExerciseCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        programmingExerciseCreateRequestDto.setPeriodIntervalIdentifier( arg0.getPeriodIntervalIdentifier() );

        return programmingExerciseCreateRequestDto;
    }

    @Override
    public ProgrammingExerciseService.ProgrammingExerciseUpdateRequestDto mapUpdate(ProgrammingExerciseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingExerciseService.ProgrammingExerciseUpdateRequestDto programmingExerciseUpdateRequestDto = new ProgrammingExerciseService.ProgrammingExerciseUpdateRequestDto();

        programmingExerciseUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingExerciseUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingExerciseUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingExerciseUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        programmingExerciseUpdateRequestDto.setPeriodIntervalIdentifier( arg0.getPeriodIntervalIdentifier() );

        return programmingExerciseUpdateRequestDto;
    }
}
