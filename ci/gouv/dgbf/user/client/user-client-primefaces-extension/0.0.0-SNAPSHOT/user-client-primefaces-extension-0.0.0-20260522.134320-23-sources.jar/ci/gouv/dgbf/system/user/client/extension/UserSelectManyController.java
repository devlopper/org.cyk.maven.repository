package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur d'autocomplete de {@link UserDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class UserSelectManyController extends
    AbstractSelectManyIdentifiableController<UserDto, UserGetManyResponseDto, UserClient> {

  @Inject
  @Getter
  UserClient client;

  /**
   * Cette méthode permet de construire.
   */
  public UserSelectManyController() {
    super(UserDto.class);
  }


}
