package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserRoleDto}.
 *
 * @author Arnaud
 */
@Named
@ViewScoped
public class UserRoleListPage extends AbstractPage {

  @Inject
  @Getter
  UserRoleController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + UserRoleDto.NAME;
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "userRoleListPage";
}
