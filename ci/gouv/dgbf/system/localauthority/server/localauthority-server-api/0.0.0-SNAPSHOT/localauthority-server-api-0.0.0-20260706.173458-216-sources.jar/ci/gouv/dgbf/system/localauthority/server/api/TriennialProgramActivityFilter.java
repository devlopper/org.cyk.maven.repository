package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TriennialProgramActivityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TriennialProgramActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * {@link ActivityCategory}.
   */
  ActivityCategory activityCategory;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TriennialProgramActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TriennialProgramActivityFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
    activityCategory = getActivityCategory(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
    setActivityCategory(filter, activityCategory);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner la {@link ActivityCategory}.
   *
   * @param filter filtre
   * @param category {@link ActivityCategory}
   */
  public static void setActivityCategory(FilterDto filter, ActivityCategory category) {
    set(filter, JSON_ACTIVITY_CATEGORY, f -> f.getValueAsString(), f -> f.setValueAsEnum(category));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityCategory}.
   *
   * @param filter filtre
   * @return {@link ActivityCategory}
   */
  public static ActivityCategory getActivityCategory(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_ACTIVITY_CATEGORY, ActivityCategory.class));
  }

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      TriennialProgramActivityDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramActivityDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

  /**
   * Identifiant json champ {@link #activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY =
      TriennialProgramActivityDto.JSON_ACTIVITY_CATEGORY;
}
