package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitService.BudgetSpecializationUnitGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link BudgetSpecializationUnitService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BudgetSpecializationUnitClient extends AbstractClient<BudgetSpecializationUnitService>
    implements GetByIdentifier<BudgetSpecializationUnitDto>,
               GetMany<BudgetSpecializationUnitGetManyResponseDto> {

  @Override
  public BudgetSpecializationUnitClient service(BudgetSpecializationUnitService service) {
    return (BudgetSpecializationUnitClient) super.service(service);
  }

  /**
   * {@link BudgetSpecializationUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetSpecializationUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<BudgetSpecializationUnitGetManyResponseDto>(
      BudgetSpecializationUnitGetManyResponseDto.class,
        BudgetSpecializationUnitService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }

  /**
   * {@link BudgetSpecializationUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetSpecializationUnitGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BudgetSpecializationUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetSpecializationUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetSpecializationUnitDto>(BudgetSpecializationUnitDto.class,
        BudgetSpecializationUnitService.GET_ONE_IDENTIFIER)
           .execute(() -> service().getOne(request));
  }

  /**
   * {@link BudgetSpecializationUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetSpecializationUnitDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BudgetSpecializationUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return declaration
   */
  public BudgetSpecializationUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetSpecializationUnitDto>(BudgetSpecializationUnitDto.class,
        BudgetSpecializationUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BudgetSpecializationUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetSpecializationUnitDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

}
