package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.math.BigDecimal;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la saisie d'une mesure ponctuelle pour une unité administrative.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AdministrativeUnitPunctualMeasureDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de l'exercice.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de l'exercice.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  String exerciseAsString;

  /**
   * Identifiant du budget.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères du budget.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de l'unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de l'unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  String administrativeUnitAsString;

  /**
   * Identifiant de l'entité budget-unité administrative.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de l'entité budget-unité administrative.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING)
  String budgetAdministrativeUnitAsString;

  /**
   * Identifiant de la mesure ponctuelle.
   */
  @JsonbProperty(JSON_PUNCTUAL_MEASURE_IDENTIFIER)
  String punctualMeasureIdentifier;

  /**
   * Représentation en chaine de caractères de la mesure ponctuelle.
   */
  @JsonbProperty(JSON_PUNCTUAL_MEASURE_AS_STRING)
  String punctualMeasureAsString;

  /**
   * Montant saisi.
   */
  @JsonbProperty(JSON_AMOUNT)
  Integer amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Identifiant json de l'identifiant de {@link AdministrativeUnitPunctualMeasureDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUniteAdministrativeMesurePonctuelle";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link AdministrativeUnitPunctualMeasureDto}.
   */
  public static final String JSON_THIS_AS_STRING = "uniteAdministrativeMesurePonctuelleChaine";

  /**
   * Identifiant json de {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";

  /**
   * Identifiant json de {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Identifiant json de {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #budgetAdministrativeUnitAsString}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #punctualMeasureIdentifier}.
   */
  public static final String JSON_PUNCTUAL_MEASURE_IDENTIFIER =
      PunctualMeasureDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #punctualMeasureAsString}.
   */
  public static final String JSON_PUNCTUAL_MEASURE_AS_STRING =
      PunctualMeasureDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json de {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mesure ponctuelle d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "mesures ponctuelles d'unités administratives";
}
