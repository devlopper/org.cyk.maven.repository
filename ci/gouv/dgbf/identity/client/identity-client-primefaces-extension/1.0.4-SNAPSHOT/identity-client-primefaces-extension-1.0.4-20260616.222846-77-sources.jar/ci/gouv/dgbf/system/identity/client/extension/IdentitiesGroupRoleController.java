package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleClient;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentitiesGroupRoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class IdentitiesGroupRoleController extends AbstractController {

  @Inject
  IdentitiesGroupRoleClient client;

  @Inject
  IdentitiesGroupRoleRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentitiesGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  RoleSelectOneController roleSelectOneController;

  @Inject
  @Getter
  IdentitiesGroupRoleFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentitiesGroupRoleDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(IdentitiesGroupRoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentitiesGroupRoleService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getGroupIdentifier(),
        IdentitiesGroupRoleDto.JSON_GROUP_IDENTIFIER);
    projection.addNamesIfStringBlank(filterController.getFilter().getRoleIdentifier(),
        IdentitiesGroupRoleDto.JSON_ROLE_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    /* Creation */

    listController.getCreateController().addEntityConsumer(entity -> {
      ((IdentitiesGroupRoleDto) entity)
          .setGroupIdentifier(filterController.getFilter().getGroupIdentifier());
      ((IdentitiesGroupRoleDto) entity)
          .setRoleIdentifier(filterController.getFilter().getRoleIdentifier());
    });
    listController.getCreateController().setFunction(entity -> {
      IdentitiesGroupRoleCreateRequestDto request =
          requestMapper.mapCreate((IdentitiesGroupRoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });


    /* Update */

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            IdentitiesGroupRoleDto.JSON_GROUP_IDENTIFIER,
            IdentitiesGroupRoleDto.JSON_ROLE_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(entity -> {
      groupSelectOneController.getSelectOneMenu()
          .writeValue(((IdentitiesGroupRoleDto) entity).getGroupIdentifier());

      roleSelectOneController.getSelectOneMenu()
          .writeValue(((IdentitiesGroupRoleDto) entity).getRoleIdentifier());
    });

    listController.getUpdateController().setFunction(entity -> {
      IdentitiesGroupRoleUpdateRequestDto request =
          requestMapper.mapUpdate((IdentitiesGroupRoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */

    groupSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, IdentitiesGroupRoleDto.JSON_GROUP_AS_STRING);


    groupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentitiesGroupRoleDto.class)
            .setGroupIdentifier(identifier));

    roleSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(listController,
        IdentitiesGroupRoleDto.JSON_ROLE_AS_STRING);

    roleSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentitiesGroupRoleDto.class)
            .setRoleIdentifier(identifier));
  }
}
