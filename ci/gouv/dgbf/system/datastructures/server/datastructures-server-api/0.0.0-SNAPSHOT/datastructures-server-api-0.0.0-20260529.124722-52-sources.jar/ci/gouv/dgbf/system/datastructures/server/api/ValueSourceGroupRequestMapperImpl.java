package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueSourceGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueSourceGroupRequestMapperImpl implements ValueSourceGroupRequestMapper {

    @Override
    public ValueSourceGroupService.ValueSourceGroupCreateRequestDto mapCreate(ValueSourceGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSourceGroupService.ValueSourceGroupCreateRequestDto valueSourceGroupCreateRequestDto = new ValueSourceGroupService.ValueSourceGroupCreateRequestDto();

        valueSourceGroupCreateRequestDto.setCode( arg0.getCode() );
        valueSourceGroupCreateRequestDto.setName( arg0.getName() );
        valueSourceGroupCreateRequestDto.setDataEntityIdentifier( arg0.getDataEntityIdentifier() );

        return valueSourceGroupCreateRequestDto;
    }

    @Override
    public ValueSourceGroupService.ValueSourceGroupUpdateRequestDto mapUpdate(ValueSourceGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSourceGroupService.ValueSourceGroupUpdateRequestDto valueSourceGroupUpdateRequestDto = new ValueSourceGroupService.ValueSourceGroupUpdateRequestDto();

        valueSourceGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueSourceGroupUpdateRequestDto.setCode( arg0.getCode() );
        valueSourceGroupUpdateRequestDto.setName( arg0.getName() );
        valueSourceGroupUpdateRequestDto.setDataEntityIdentifier( arg0.getDataEntityIdentifier() );

        return valueSourceGroupUpdateRequestDto;
    }
}
