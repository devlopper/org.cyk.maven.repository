package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentTypeGroupFieldDto}.
*
* @author si.kimou
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-05T12:14:42+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentTypeGroupFieldRequestMapperImpl implements DocumentTypeGroupFieldRequestMapper {

    @Override
    public DocumentTypeGroupFieldService.DocumentTypeGroupFieldCreateRequestDto mapCreate(DocumentTypeGroupFieldDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeGroupFieldService.DocumentTypeGroupFieldCreateRequestDto documentTypeGroupFieldCreateRequestDto = new DocumentTypeGroupFieldService.DocumentTypeGroupFieldCreateRequestDto();

        documentTypeGroupFieldCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeGroupFieldCreateRequestDto.setCode( arg0.getCode() );
        documentTypeGroupFieldCreateRequestDto.setName( arg0.getName() );
        documentTypeGroupFieldCreateRequestDto.setTypeGroupIdentifier( arg0.getTypeGroupIdentifier() );
        documentTypeGroupFieldCreateRequestDto.setValueType( arg0.getValueType() );
        documentTypeGroupFieldCreateRequestDto.setRequired( arg0.getRequired() );

        return documentTypeGroupFieldCreateRequestDto;
    }

    @Override
    public DocumentTypeGroupFieldService.DocumentTypeGroupFieldUpdateRequestDto mapUpdate(DocumentTypeGroupFieldDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeGroupFieldService.DocumentTypeGroupFieldUpdateRequestDto documentTypeGroupFieldUpdateRequestDto = new DocumentTypeGroupFieldService.DocumentTypeGroupFieldUpdateRequestDto();

        documentTypeGroupFieldUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeGroupFieldUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentTypeGroupFieldUpdateRequestDto.setCode( arg0.getCode() );
        documentTypeGroupFieldUpdateRequestDto.setName( arg0.getName() );
        documentTypeGroupFieldUpdateRequestDto.setTypeGroupIdentifier( arg0.getTypeGroupIdentifier() );
        documentTypeGroupFieldUpdateRequestDto.setValueType( arg0.getValueType() );
        documentTypeGroupFieldUpdateRequestDto.setRequired( arg0.getRequired() );

        return documentTypeGroupFieldUpdateRequestDto;
    }
}
