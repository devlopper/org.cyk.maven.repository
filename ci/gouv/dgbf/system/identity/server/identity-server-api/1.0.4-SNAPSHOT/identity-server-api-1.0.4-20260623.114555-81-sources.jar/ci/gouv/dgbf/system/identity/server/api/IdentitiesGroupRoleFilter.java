package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentitiesGroupRoleDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class IdentitiesGroupRoleFilter extends AbstractIdentifiableFilter {


  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  String groupIdentifier;

  /**
   * Identifiant {@link RoleDto}.
   */
  String roleIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    groupIdentifier = getGroupIdentifier(filter);
    roleIdentifier = getRoleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setRoleIdentifier(filter, roleIdentifier);
  }

  /**
   * Cette méthode permet d'assigner identifiant {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link IdentitiesGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link IdentitiesGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner identifiant {@link RoleDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link RoleDto}
   */
  public static void setRoleIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ROLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link RoleDto}.
   *
   * @param filter filtre
   * @return identifiant {@link RoleDto}
   */
  public static String getRoleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ROLE_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = IdentitiesGroupRoleDto.JSON_GROUP_IDENTIFIER;
  
  /**
   * Identifiant JSON {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = IdentitiesGroupRoleDto.JSON_ROLE_IDENTIFIER;
}
