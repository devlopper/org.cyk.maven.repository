package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimTypeClaimableDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimTypeClaimableFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Nature de l'objet ciblé.
   */
  String nature;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimTypeClaimableFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimTypeClaimableFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    nature = getNature(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setNature(filter, nature);
  }

  /**
   * Cette méthode permet d'assigner la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @param nature nature de l'objet ciblé
   */
  public static void setNature(FilterDto filter, String nature) {
    set(filter, JSON_NATURE, f -> f.getValueAsString(),
        f -> f.setValueAsString(nature));
  }

  /**
   * Cette méthode permet d'obtenir la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @return nature de l'objet ciblé
   */
  public static String getNature(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NATURE));
  }

  /**
   * Identifiant json champ {@link #nature}.
   */
  public static final String JSON_NATURE = ClaimTypeClaimableDto.JSON_NATURE;
}
