package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentCategoryDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentCategoryDto}.

    @author akm
               """)
public interface PayrollComponentCategoryRequestMapper
    extends RequestMapper<PayrollComponentCategoryDto, 
            PayrollComponentCategoryCreateRequestDto, PayrollComponentCategoryUpdateRequestDto> {

}
