package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets traités sous forme
 * de chaîne.
 *
 * @author Christian
 */
public interface HasProcessedTicketCountAsStringDto extends HasProcessedTicketCountAsString {

  /**
   * Identifiant json du nombre de tickets traités sous forme de chaîne.
   */
  String JSON_PROCESSED_TICKET_COUNT_AS_STRING = "nombreTicketsTraitesChaine";
}
