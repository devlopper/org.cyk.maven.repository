package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ActivityDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ActivityRequestMapperImpl implements ActivityRequestMapper {

    @Override
    public ActivityService.ActivityCreateRequestDto mapCreate(ActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityService.ActivityCreateRequestDto activityCreateRequestDto = new ActivityService.ActivityCreateRequestDto();

        activityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityCreateRequestDto.setName( arg0.getName() );
        activityCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        activityCreateRequestDto.setFolderIdentifier( arg0.getFolderIdentifier() );
        activityCreateRequestDto.setResponsibleIdentityIdentifier( arg0.getResponsibleIdentityIdentifier() );
        activityCreateRequestDto.setDescription( arg0.getDescription() );
        activityCreateRequestDto.setSubAdministrativeUnitIdentifier( arg0.getSubAdministrativeUnitIdentifier() );

        return activityCreateRequestDto;
    }

    @Override
    public ActivityService.ActivityUpdateRequestDto mapUpdate(ActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityService.ActivityUpdateRequestDto activityUpdateRequestDto = new ActivityService.ActivityUpdateRequestDto();

        activityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        activityUpdateRequestDto.setName( arg0.getName() );
        activityUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        activityUpdateRequestDto.setFolderIdentifier( arg0.getFolderIdentifier() );
        activityUpdateRequestDto.setResponsibleIdentityIdentifier( arg0.getResponsibleIdentityIdentifier() );
        activityUpdateRequestDto.setDescription( arg0.getDescription() );
        activityUpdateRequestDto.setSubAdministrativeUnitIdentifier( arg0.getSubAdministrativeUnitIdentifier() );

        return activityUpdateRequestDto;
    }
}
