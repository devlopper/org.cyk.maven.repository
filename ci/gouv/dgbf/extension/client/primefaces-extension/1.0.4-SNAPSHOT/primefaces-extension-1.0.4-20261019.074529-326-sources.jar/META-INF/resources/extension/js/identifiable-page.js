(function () {
  'use strict';
  if (window.dgbfIdentifiablePageFocusInstalled) return;
  window.dgbfIdentifiablePageFocusInstalled = true;
  var previous;
  var panelId;
  function begin() {
    previous = document.activeElement;
    var panel = previous && previous.closest('[data-identifiable-page]');
    panelId = panel && panel.id;
  }
  function complete() {
    if (!previous || previous === document.body || previous.isConnected) return;
    // Ne pas interrompre un déplacement de focus déjà effectué par l'application.
    if (document.activeElement && document.activeElement !== document.body) return;
    var panel = panelId && document.getElementById(panelId);
    var title = panel && panel.querySelector('[data-identifiable-state-title]');
    if (title) title.focus();
    previous = null;
  }
  var facesApi = window.faces || window.jsf;
  if (facesApi && facesApi.ajax) {
    facesApi.ajax.addOnEvent(function (event) {
      if (event.status === 'begin') begin();
      if (event.status === 'success') complete();
    });
  }
  if (window.jQuery) {
    window.jQuery(document).on('pfAjaxStart.identifiablePage', begin);
    window.jQuery(document).on('pfAjaxComplete.identifiablePage', complete);
  }
}());
