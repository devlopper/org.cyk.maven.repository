package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fonction.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link FunctionDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonction";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FunctionDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonction";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
