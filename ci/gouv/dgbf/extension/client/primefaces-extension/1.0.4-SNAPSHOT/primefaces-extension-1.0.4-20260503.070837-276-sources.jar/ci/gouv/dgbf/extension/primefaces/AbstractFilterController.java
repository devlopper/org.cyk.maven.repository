package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ClassHelper;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractFilter;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur de filtre.
 *
 * @author Christian
 *
 */
public abstract class AbstractFilterController<T extends AbstractFilter>
    extends AbstractController {

  @Getter
  protected T filter;

  @Setter
  protected Consumer<T> filterConsumer;

  @Getter
  protected boolean filtered;

  @Getter
  protected String filterAsString;

  protected Class<T> filterClass;

  @Inject
  protected ClassHelper classHelper;

  protected Consumer<T> filterProcessor;

  protected Function<T, String> filterStringifier;

  protected AbstractFilterController(Class<T> filterClass) {
    this.filterClass = filterClass;
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter = classHelper.instantiate(filterClass, null, null);
  }

  /**
   * Cette méthode permet d'ajouter des consommateurs de filtre.
   *
   * @param consumers consommateurs
   */
  @SuppressWarnings("unchecked")
  public void addFilterConsumers(Consumer<T>... consumers) {
    filterConsumer = Core.combineConsumersTo(filterConsumer, consumers);
  }

  /**
   * Cette méthode permet d'ajouter un consommateur de filtre.
   *
   * @param consumer consommateur
   */
  @SuppressWarnings("unchecked")
  public void addFilterConsumer(Consumer<T> consumer) {
    addFilterConsumers(consumer);
  }

  /**
   * Cette méthode permet de filtrer.
   *
   */
  public void filter() {
    Core.runIfNotNull(filterConsumer, () -> filterConsumer.accept(filter));
    Core.runIfNotNull(filterStringifier, () -> filterAsString = filterStringifier.apply(filter));
    filtered = true;
  }
}
