package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasMessage;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasProcessIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link LogDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LogFilter extends AbstractIdentifiableFilter
    implements FilterHasProcessIdentifier, FilterHasUserName, FilterHasLevelCode, FilterHasMessage {

  private String processIdentifier;
  
  private String userName;

  private String levelCode;

  private String message;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public LogFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public LogFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateProcessIdentifier(filter);
    updateUserName(filter);
    updateLevelCode(filter);
    updateMessage(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterProcessIdentifier(filter);
    updateFilterUserName(filter);
    updateFilterLevelCode(filter);
    updateFilterMessage(filter);
  }

}
