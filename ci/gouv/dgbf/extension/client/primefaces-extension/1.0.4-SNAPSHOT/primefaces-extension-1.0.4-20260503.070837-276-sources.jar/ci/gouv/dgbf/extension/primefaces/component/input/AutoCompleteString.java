package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import jakarta.faces.model.SelectItem;
import java.util.function.Function;

/**
 * Cette classe représente une sélection de chaine de caractères par suggestion.
 *
 * @author Christian
 *
 * @param <T> type
 */
public class AutoCompleteString extends AbstractAutoComplete<Object, String, Object, String> {

  /**
   * Cette méthode permet d'instantier.
   */
  public AutoCompleteString(ScriptManager scriptManager) {
    super(scriptManager);
    itemValueGetFunction = ITEM_VALUE_GET_FUNCTION;
    valueGetFunction = VALUE_GET_FUNCTION;
  }

  public static final Function<Object, String> ITEM_VALUE_GET_FUNCTION = t -> {
    if (t instanceof IdentifiableByString identifiable) {
      return identifiable.getIdentifier();
    }
    if (t instanceof SelectItem selectItem) {
      return String.valueOf(selectItem.getValue());
    }
    return String.valueOf(t);
  };

  @Deprecated(forRemoval = true)
  public static final Function<Object, String> VALUE_GET_FUNCTION = t -> {
    if (t instanceof IdentifiableByString identifiable) {
      return identifiable.getIdentifier();
    }
    if (t instanceof SelectItem selectItem) {
      return String.valueOf(selectItem.getValue());
    }
    return String.valueOf(t);
  };
}
