package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.UriBuilder;
import ci.gouv.dgbf.extension.primefaces.SessionManager;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverFilter;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeLocation;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Map;
import lombok.Setter;

/**
 * Cette classe représente le filtre de ressource partagée de l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public class ConnectedUserSharedResourceFilter implements Filter {

  SessionManager sessionManager;

  String resourceListPagepath;

  ResourceTypeLocation resourceTypeLocation;

  @Setter
  Map<String, String[]> parameters;

  /**
   * Cette méthode permet d'instantier.
   *
   * @param sessionManager {@link SessionManager}
   * @param resourceTypeLocation {@link ResourceTypeLocation}
   * @param parameters paramètres
   */
  public ConnectedUserSharedResourceFilter(SessionManager sessionManager,
      ResourceTypeLocation resourceTypeLocation, Map<String, String[]> parameters) {
    this.sessionManager = sessionManager;
    this.resourceListPagepath = ConnectedUserResourceListPage.PATH;
    this.resourceTypeLocation = resourceTypeLocation;
    this.parameters = parameters;
  }
  
  /**
   * Cette méthode permet d'instantier.
   *
   * @param sessionManager {@link SessionManager}
   * @param resourceTypeLocation {@link ResourceTypeLocation}
   */
  public ConnectedUserSharedResourceFilter(SessionManager sessionManager,
      ResourceTypeLocation resourceTypeLocation) {
    this(sessionManager, resourceTypeLocation, null);
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    HttpServletRequest httpRequest = (HttpServletRequest) request;
    HttpServletResponse httpResponse = (HttpServletResponse) response;
    if (redirectable(httpRequest)) {
      redirect(httpRequest, httpResponse);
    } else {
      chain.doFilter(request, response);
    }
  }

  /**
   * Cette méthode permet de savoir si une redirection doit se faire.
   *
   * @param request {@link ServletRequest}
   * @return vrai si une redirection doit se faire sinon faux
   */
  boolean redirectable(HttpServletRequest request) {
    return isResourceRequired(request) && getResource(request.getSession()) == null;
  }

  boolean isResourceRequired(HttpServletRequest httpRequest) {
    return Core.isStringDoesNotContains(httpRequest.getRequestURI(), resourceListPagepath,
        "RES_NOT_FOUND");
  }

  ResourceDto getResource(HttpSession session) {
    return SharingSessionController.getAttributeResource(resourceTypeLocation.getResourceType(),
        resourceTypeLocation.getLocation(), session);
  }

  void redirect(HttpServletRequest httpRequest, HttpServletResponse httpResponse)
      throws IOException {
    /*
     * On détermine l'uri courant afin d'y revenir
     */
    String url = buildCurrentRelativeUrl(httpRequest);
    /*
     * On stock l'uri courant en session
     */
    sessionManager.setAttributeRedirectUrl(url, httpRequest.getSession());
    /*
     * On redirige vers la page de sélection de ressource
     */
    httpResponse.sendRedirect(buildRedirectLocation(httpRequest));
  }

  String buildRedirectLocation(HttpServletRequest request) {
    UriBuilder uriBuilder = new UriBuilder();
    uriBuilder.relative(true);
    uriBuilder.pathBuilder().list().add(request.getContextPath(), resourceListPagepath);
    uriBuilder.queryBuilder().map().add(AbstractResourceOrReceiverFilter.JSON_TYPE,
        resourceTypeLocation.getResourceType().name());
    uriBuilder.queryBuilder().map().add(AbstractResourceOrReceiverFilter.JSON_LOCATION,
        resourceTypeLocation.getLocation().name());
    uriBuilder.queryBuilder().map().addArrays(parameters);
    return uriBuilder.build().toString();
  }

  /**
   * Cette méthode permet de construire l'uri relatif courant.
   *
   * @param request {@link HttpServletRequest}
   * @return uri relatif courant
   */
  String buildCurrentRelativeUrl(HttpServletRequest request) {
    UriBuilder uriBuilder = new UriBuilder();
    uriBuilder.relative(true);
    uriBuilder.path(request.getRequestURI());
    uriBuilder.queryBuilder().setAppendQuestionMarkIfNotBlank(true);
    uriBuilder.queryBuilder().map().addArrays(request.getParameterMap());
    return uriBuilder.build().toString();
  }
}
