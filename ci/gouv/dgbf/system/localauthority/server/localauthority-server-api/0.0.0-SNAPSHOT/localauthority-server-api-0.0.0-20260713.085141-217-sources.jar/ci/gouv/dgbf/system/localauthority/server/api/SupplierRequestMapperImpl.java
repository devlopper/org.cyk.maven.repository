package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupplierDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-13T08:52:07+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupplierRequestMapperImpl implements SupplierRequestMapper {

    @Override
    public SupplierService.SupplierCreateRequestDto mapCreate(SupplierDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupplierService.SupplierCreateRequestDto supplierCreateRequestDto = new SupplierService.SupplierCreateRequestDto();

        supplierCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        supplierCreateRequestDto.setCode( arg0.getCode() );
        supplierCreateRequestDto.setName( arg0.getName() );
        supplierCreateRequestDto.setTaxAccountNumber( arg0.getTaxAccountNumber() );

        return supplierCreateRequestDto;
    }

    @Override
    public SupplierService.SupplierUpdateRequestDto mapUpdate(SupplierDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupplierService.SupplierUpdateRequestDto supplierUpdateRequestDto = new SupplierService.SupplierUpdateRequestDto();

        supplierUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        supplierUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supplierUpdateRequestDto.setCode( arg0.getCode() );
        supplierUpdateRequestDto.setName( arg0.getName() );
        supplierUpdateRequestDto.setTaxAccountNumber( arg0.getTaxAccountNumber() );

        return supplierUpdateRequestDto;
    }
}
