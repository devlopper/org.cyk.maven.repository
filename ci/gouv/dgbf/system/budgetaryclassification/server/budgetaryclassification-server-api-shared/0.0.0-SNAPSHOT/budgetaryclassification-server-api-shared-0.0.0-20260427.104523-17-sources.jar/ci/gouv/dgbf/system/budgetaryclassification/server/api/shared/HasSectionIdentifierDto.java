package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de section.
 *
 * @author Christian
 */
public interface HasSectionIdentifierDto extends HasSectionIdentifier {

  /**
   * Identifiant json de l'identifiant de la section.
   */
  String JSON_SECTION_IDENTIFIER = "idSection";
}