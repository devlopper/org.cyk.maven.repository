package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.OutputLabel;
import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ProcessingStatus}.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingStatusSelectOneController
    extends AbstractSelectOneEnumerationController<ProcessingStatus> {

  /**
   * Cette méthode permet de construire.
   */
  protected ProcessingStatusSelectOneController() {
    super(ProcessingStatus.values());
  }

  @Override
  protected void processOutputLabel(OutputLabel outputLabel) {
    outputLabel.setValue("Statut");
  }

  
}
