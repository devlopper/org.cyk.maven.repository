package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * dépense.
 *
 * @author Christian
 */
public interface HasExpenditureAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la dépense.
   *
   * @return représentation en chaine de caractères de la dépense
   */
  String getExpenditureAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de la dépense.
   *
   * @param asString représentation en chaine de caractères de la dépense
   */
  void setExpenditureAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de la dépense.
   */
  String FIELD_EXPENDITURE_AS_STRING = "expenditureAsString";
}
