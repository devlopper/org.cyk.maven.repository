package ci.gouv.dgbf.system.localauthority.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 *
 */
@Getter
public enum BudgetActivityType {

  /**
   * Dépense.
   */
  EXPENDITURE(BudgetActivityTypeCode.EXPENDITURE, "Dépense"),

  /**
   * Recette.
   */
  REVENUE(BudgetActivityTypeCode.REVENUE, "Recette");

  private BudgetActivityType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le type par code.
   *
   * @param code code
   * @return type
   */
  public static BudgetActivityType getByCode(String code) {
    return Stream.of(BudgetActivityType.values())
        .filter(type -> type.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
