package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.OffsetDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un jeton.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TokenDto extends AbstractIdentifiableAuditableDto
    implements HasModuleIdentifierDto, HasProcessIdentifierDto, HasOperationIdentifierDto,
    HasSourceIdentifierDto, HasRecordIdentifierDto, HasStatusDto<TokenStatus>,
    HasStatusAsStringDto {

  @JsonbProperty(JSON_MODULE_IDENTIFIER)
  private String moduleIdentifier;

  @JsonbProperty(JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  @JsonbProperty(JSON_OPERATION_IDENTIFIER)
  private String operationIdentifier;

  @JsonbProperty(JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(JSON_RECORD_IDENTIFIER)
  private String recordIdentifier;

  @JsonbProperty(JSON_ISSUANCE_DATE)
  private OffsetDateTime issuanceDate;

  @JsonbProperty(JSON_EXPIRATION_DATE)
  private OffsetDateTime expirationDate;

  @JsonbProperty(JSON_CONSUMPTION_DATE)
  private OffsetDateTime consumptionDate;

  @JsonbProperty(JSON_REVOCATION_DATE)
  private OffsetDateTime revocationDate;

  @JsonbProperty(JSON_STATUS)
  private TokenStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant json de la date d'émission.
   */
  public static final String JSON_ISSUANCE_DATE = "dateEmission";

  /**
   * Identifiant json de la date d'expiration.
   */
  public static final String JSON_EXPIRATION_DATE = "dateExpiration";

  /**
   * Identifiant json de la date de consommation.
   */
  public static final String JSON_CONSUMPTION_DATE = "dateConsommation";

  /**
   * Identifiant json de la date de révocation.
   */
  public static final String JSON_REVOCATION_DATE = "dateRevocation";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "jeton";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "jetons";
}
