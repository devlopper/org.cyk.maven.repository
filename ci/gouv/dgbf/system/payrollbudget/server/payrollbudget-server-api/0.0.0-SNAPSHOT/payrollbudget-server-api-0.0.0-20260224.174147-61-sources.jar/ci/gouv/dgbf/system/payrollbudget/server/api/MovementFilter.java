package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitEmployeeIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementFilter extends AbstractIdentifiableFilter implements
    FilterHasAdministrativeUnitEmployeeStatusCode, FilterHasAdministrativeUnitEmployeeIdentifier,
    FilterHasPositionFieldCode, FilterHasMovementTypeIdentifier {

  /**
   * Identifiant {@link AdministrativeUnitEmployeeDto}.
   */
  String administrativeUnitEmployeeIdentifier;

  /**
   * Code {@link AdministrativeUnitEmployeeStatus}.
   */
  String administrativeUnitEmployeeStatusCode;

  /**
   * Identifiant {@link MovementTypeDto}.
   */
  String movementTypeIdentifier;

  /**
   * Code {@link PositionField}.
   */
  String positionFieldCode;
  
  /**
   * Cette méthode permet d'instancier un objet.
   */
  public MovementFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public MovementFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitEmployeeStatusCode(filter);
    updateAdministrativeUnitEmployeeIdentifier(filter);
    updateMovementTypeIdentifier(filter);
    updatePositionFieldCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitEmployeeStatusCode(filter);
    updateFilterAdministrativeUnitEmployeeIdentifier(filter);
    updateFilterMovementTypeIdentifier(filter);
    updateFilterPositionFieldCode(filter);
  }
}
