package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link EconomicNatureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-04T13:14:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class EconomicNatureRequestMapperImpl implements EconomicNatureRequestMapper {

    @Override
    public EconomicNatureService.EconomicNatureCreateRequestDto mapCreate(EconomicNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        EconomicNatureService.EconomicNatureCreateRequestDto economicNatureCreateRequestDto = new EconomicNatureService.EconomicNatureCreateRequestDto();

        economicNatureCreateRequestDto.setCode( arg0.getCode() );
        economicNatureCreateRequestDto.setName( arg0.getName() );

        return economicNatureCreateRequestDto;
    }

    @Override
    public EconomicNatureService.EconomicNatureUpdateRequestDto mapUpdate(EconomicNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        EconomicNatureService.EconomicNatureUpdateRequestDto economicNatureUpdateRequestDto = new EconomicNatureService.EconomicNatureUpdateRequestDto();

        economicNatureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        economicNatureUpdateRequestDto.setCode( arg0.getCode() );
        economicNatureUpdateRequestDto.setName( arg0.getName() );

        return economicNatureUpdateRequestDto;
    }
}
