package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;

/**
 * Cette classe représente la base des LazyDataModel.
 *
 * @author Christian
 *
 * @param <T> type identifiable
 * @param <R> type réponse
 */
public abstract class AbstractLazyDataModel<T, R> extends LazyDataModel<T> {

  protected String name;

  @Getter
  protected transient ActionExecutor<R> actionExecutor;

  @Getter
  protected transient R response;

  @Setter
  transient Consumer<List<T>> listConsumer;

  @Getter
  @Setter
  boolean loadEnabled = true;

  /* Selection */

  @Getter
  @Setter
  boolean selectable;

  @Getter
  @Setter
  Function<Object, String> getRowKeyFunction;

  @Getter
  @Setter
  Function<String, Object> getRowDataFunction;

  protected AbstractLazyDataModel(String name) {
    this.name = name;
  }

  @Override
  public List<T> load(int first, int pageSize, Map<String, SortMeta> sortBy,
      Map<String, FilterMeta> filterBy) {
    List<T> list;
    if (loadable(first, pageSize, sortBy, filterBy)) {
      list = doLoad(first, pageSize, sortBy, filterBy);
    } else {
      list = doWhenNotLoadable(first, pageSize, sortBy, filterBy);
    }
    if (!list.isEmpty()) {
      processWhenNotEnpty(list);
    }
    return list;
  }

  /**
   * Cette méthode permet de déterminer si le chargement est possible.
   *
   * @param first index premier élément
   * @param pageSize taille de la page
   * @param sortBy options de tri
   * @param filterBy options de filtre
   * @return vrai ou faux
   */
  protected boolean loadable(int first, int pageSize, Map<String, SortMeta> sortBy,
      Map<String, FilterMeta> filterBy) {
    return loadEnabled;
  }

  /**
   * Cette méthode permet d'exécuter le chargement.
   *
   * @param first index premier élément
   * @param pageSize taille de la page
   * @param sortBy options de tri
   * @param filterBy options de filtre
   * @return liste d'éléments chargés
   */
  protected List<T> doLoad(int first, int pageSize, Map<String, SortMeta> sortBy,
      Map<String, FilterMeta> filterBy) {
    PageDto page = new PageDto(first, pageSize);
    actionExecutor = instantiateActionExecutor(page);
    response = actionExecutor.execute();
    return processResponse(response);
  }

  /**
   * Cette méthode permet de réagir lorsque le chargement n'est pas possible.
   *
   * @param first index premier élément
   * @param pageSize taille de la page
   * @param sortBy options de tri
   * @param filterBy options de filtre
   * @return liste d'éléments
   */
  protected List<T> doWhenNotLoadable(int first, int pageSize, Map<String, SortMeta> sortBy,
      Map<String, FilterMeta> filterBy) {
    List<T> list = Collections.emptyList();
    setRowCount(0);
    return list;
  }

  protected ActionExecutor<R> instantiateActionExecutor(PageDto page) {
    return new ActionExecutor<R>(this, String.format("Obtention liste %s", name), () -> serve(page))
        .setExceptionShowableInDialog(false);
  }

  protected List<T> processResponse(R response) {
    List<T> list;
    if (response == null) {
      list = processWhenResponseNull();
    } else {
      list = processWhenResponseNotNull(response);
    }
    return list;
  }

  protected List<T> processWhenResponseNull() {
    List<T> list = Collections.emptyList();
    setRowCount(0);
    return list;
  }

  @SuppressWarnings("unchecked")
  protected List<T> processWhenResponseNotNull(R response) {
    List<T> list;
    if (response instanceof AbstractGetByPageResponseDto<?> r) {
      list = (List<T>) r.getDatas();
      setRowCount(r.getTotal() == null ? 0 : r.getTotal().intValue());
      return list;
    }
    throw new IllegalStateException(
        String.format("Le traitement d'une réponse de type %s n'a pas encore été implémenté",
            response.getClass()));
  }

  protected void processWhenNotEnpty(List<T> list) {
    if (listConsumer != null) {
      listConsumer.accept(list);
    }
  }

  /**
   * Cette méthode permet d'ajouter un consommateur de la liste.
   *
   * @param consumer consommateur de la liste
   */
  public void addListConsumer(Consumer<List<T>> consumer) {
    if (listConsumer == null) {
      listConsumer = consumer;
    } else {
      listConsumer = listConsumer.andThen(consumer);
    }
  }

  @Override
  public int count(Map<String, FilterMeta> filterBy) {
    return getRowCount();
  }

  protected abstract R serve(PageDto page);

  @Override
  public String getRowKey(T object) {
    if (selectable) {
      Core.doThrowIfNull(IllegalArgumentException.class,
          "fonction d'obtention de clé de ligne requise", getRowKeyFunction);
      return getRowKeyFunction.apply(object);
    }
    return null;
  }

  @SuppressWarnings("unchecked")
  @Override
  public T getRowData(String key) {
    if (selectable) {
      Core.doThrowIfNull(IllegalArgumentException.class,
          "fonction d'obtention de donnée de ligne requise", getRowDataFunction);
      return (T) getRowDataFunction.apply(key);
    }
    return null;
  }
}
