package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.ZoneClient;
import ci.gouv.dgbf.system.payroll.server.api.ZoneDto;
import ci.gouv.dgbf.system.payroll.server.api.ZoneService.ZoneGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ZoneDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ZoneSelectOneController extends AbstractSelectOneIdentifiableController<
    ZoneDto, ZoneGetManyResponseDto, ZoneClient> {

  @Inject
  @Getter
  ZoneClient client;

  protected ZoneSelectOneController() {
    super(ZoneDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
