package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * revenu.
 *
 * @author Christian
 */
public interface HasRevenueAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du revenu.
   *
   * @return représentation en chaine de caractères du revenu
   */
  String getRevenueAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du revenu.
   *
   * @param asString représentation en chaine de caractères du revenu
   */
  void setRevenueAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du revenu.
   */
  String FIELD_REVENUE_AS_STRING = "revenueAsString";
}
