package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimableDependencyDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-01T16:13:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimableDependencyRequestMapperImpl implements ClaimableDependencyRequestMapper {

    @Override
    public ClaimableDependencyService.ClaimableDependencyCreateRequestDto mapCreate(ClaimableDependencyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableDependencyService.ClaimableDependencyCreateRequestDto claimableDependencyCreateRequestDto = new ClaimableDependencyService.ClaimableDependencyCreateRequestDto();

        claimableDependencyCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableDependencyCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableDependencyCreateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        claimableDependencyCreateRequestDto.setRequiredClaimableIdentifier( arg0.getRequiredClaimableIdentifier() );

        return claimableDependencyCreateRequestDto;
    }

    @Override
    public ClaimableDependencyService.ClaimableDependencyUpdateRequestDto mapUpdate(ClaimableDependencyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableDependencyService.ClaimableDependencyUpdateRequestDto claimableDependencyUpdateRequestDto = new ClaimableDependencyService.ClaimableDependencyUpdateRequestDto();

        claimableDependencyUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableDependencyUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableDependencyUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimableDependencyUpdateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        claimableDependencyUpdateRequestDto.setRequiredClaimableIdentifier( arg0.getRequiredClaimableIdentifier() );

        return claimableDependencyUpdateRequestDto;
    }
}
