package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une procedure.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcedureDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;
  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING =
      TriennialProgramDto.JSON_THIS_AS_STRING;
  /**
   * Identifiant json {@link ProcedureDto#order}.
   */
  public static final String JSON_ORDER = "order";
  /**
   * Identifiant json {@link ProcedureDto#orderAsString}.
   */
  public static final String JSON_ORDER_AS_STRING = "orderChaine";
  /**
   * Identifiant json {@link ProcedureDto#date}.
   */
  public static final String JSON_DATE = "date";
  /**
   * Identifiant json {@link ProcedureDto#dateAsString}.
   */
  public static final String JSON_DATE_AS_STRING = "dateChaine";
  /**
   * Identifiant json {@link ProcedureDto#observation}.
   */
  public static final String JSON_OBSERVATION = "observation";
  /**
   * Identifiant json {@link ProcedureDto#observationAsString}.
   */
  public static final String JSON_OBSERVATION_AS_STRING = "observationChaine";
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "procedure";
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
  /**
   * Identifiant de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;
  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;
  /**
   * Ordre.
   */
  @JsonbProperty(JSON_ORDER)
  private Integer order;
  /**
   * Représentation en chaine de caractères d'ordre.
   */
  @JsonbProperty(JSON_ORDER_AS_STRING)
  private String orderAsString;
  /**
   * Date.
   */
  @JsonbProperty(JSON_DATE)
  private LocalDate date;
  /**
   * Représentation en chaine de caractères de date.
   */
  @JsonbProperty(JSON_DATE_AS_STRING)
  private String dateAsString;
  /**
   * Observation.
   */
  @JsonbProperty(JSON_OBSERVATION)
  private String observation;
  /**
   * Représentation en chaine de caractères d'observation.
   */
  @JsonbProperty(JSON_OBSERVATION_AS_STRING)
  private String observationAsString;
}
