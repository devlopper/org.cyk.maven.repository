package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services du journal du Fichier (RG_FILE_FIC_23), en lecture
 * seule : les entrées naissent des commandes de {@link FileService} (ajout d'un exemplaire,
 * modifications), dans leur transaction, jamais d'un appel d'écriture. Tant que le Fichier
 * existe, son journal suit sa visibilité ; après sa suppression, il reste lisible par
 * l'identifiant du Fichier.
 *
 * @author Christian
 */
@Path(value = FileJournalEntryService.PATH)
@Tag(name = "Journal des fichiers")
public interface FileJournalEntryService extends SpecificService {

  /**
   * Chemin du service.
   */
  String PATH = "entrees-journal-fichier";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ENTREE_JOURNAL_FICHIER";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir les entrées du journal d'un Fichier, triées par ordre. Le
   * filtre porte obligatoirement l'identifiant du Fichier ({@link FileJournalEntryFilter}).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir les entrées du journal d'un fichier")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = FileJournalEntryGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs entrées du journal.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FileJournalEntryGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileJournalEntryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileJournalEntryDto> datas;
  }

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_ENTREE_JOURNAL_FICHIER";

  /**
   * Chemin du service d'obtention du compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le nombre d'entrées du journal d'un Fichier.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER,
      description = "Ce service permet d'obtenir le nombre d'entrées du journal d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);
}
