package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * de rôle.
 *
 * @author BoobaCool
 */
public interface HasRoleAsStringDto extends HasRoleAsString {

  /**
   * Identifiant json de représentation en chaine de caractères du rôle.
   */
  String JSON_ROLE_AS_STRING = "roleChaine";
}
