package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementComponentService.SalaryElementComponentCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementComponentService.SalaryElementComponentGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementComponentService.SalaryElementComponentUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SalaryElementComponentService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SalaryElementComponentClient extends AbstractClient<SalaryElementComponentService>
    implements GetByIdentifier<SalaryElementComponentDto>,
    GetMany<SalaryElementComponentGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SalaryElementComponentClient service(SalaryElementComponentService service) {
    return (SalaryElementComponentClient) super.service(service);
  }

  /**
   * {@link SalaryElementComponentService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SalaryElementComponentCreateRequestDto request) {
    return new CreateExecutor(SalaryElementComponentService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SalaryElementComponentService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SalaryElementComponentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SalaryElementComponentGetManyResponseDto>(
        SalaryElementComponentGetManyResponseDto.class,
        SalaryElementComponentService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link SalaryElementComponentService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SalaryElementComponentGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SalaryElementComponentService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SalaryElementComponentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SalaryElementComponentDto>(SalaryElementComponentDto.class,
        SalaryElementComponentService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link SalaryElementComponentService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SalaryElementComponentDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SalaryElementComponentService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SalaryElementComponentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SalaryElementComponentDto>(SalaryElementComponentDto.class,
        SalaryElementComponentService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SalaryElementComponentService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SalaryElementComponentDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SalaryElementComponentService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SalaryElementComponentUpdateRequestDto request) {
    return new IdentifiableExecutor(SalaryElementComponentService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SalaryElementComponentService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SalaryElementComponentService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SalaryElementComponentService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
