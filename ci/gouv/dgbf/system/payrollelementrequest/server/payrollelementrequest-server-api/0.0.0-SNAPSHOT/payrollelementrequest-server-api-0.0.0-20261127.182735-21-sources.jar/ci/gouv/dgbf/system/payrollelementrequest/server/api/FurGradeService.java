package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link FurGradeDto}. N'étend
 * pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link FurGradeDto} n'a ni code ni nom propres : le grade est identifié par son couple
 * échelle / corps et grade.
 *
 * @author akm
 *
 */
@Path(FurGradeService.PATH)
@Tag(name = "Gestion des grades du FUR")
public interface FurGradeService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "grades-fur";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface FurGradeSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le code échelle / corps.
     *
     * @return le code échelle / corps
     */
    String getScaleCorpsCode();

    /**
     * Cette méthode permet d'assigner le code échelle / corps.
     *
     * @param scaleCorpsCode le code échelle / corps
     */
    void setScaleCorpsCode(String scaleCorpsCode);

    /**
     * Cette méthode permet d'obtenir le code du grade.
     *
     * @return le code du grade
     */
    String getGradeCode();

    /**
     * Cette méthode permet d'assigner le code du grade.
     *
     * @param gradeCode le code du grade
     */
    void setGradeCode(String gradeCode);

    /**
     * Cette méthode permet d'obtenir la catégorie.
     *
     * @return la catégorie
     */
    String getCategoryCode();

    /**
     * Cette méthode permet d'assigner la catégorie.
     *
     * @param categoryCode la catégorie
     */
    void setCategoryCode(String categoryCode);

    /**
     * Cette méthode permet d'obtenir le code de l'emploi CALO.
     *
     * @return le code de l'emploi CALO
     */
    String getCaloJobCode();

    /**
     * Cette méthode permet d'assigner le code de l'emploi CALO.
     *
     * @param caloJobCode le code de l'emploi CALO
     */
    void setCaloJobCode(String caloJobCode);

    /**
     * Cette méthode permet d'obtenir le code du grade CALO.
     *
     * @return le code du grade CALO
     */
    String getCaloGradeCode();

    /**
     * Cette méthode permet d'assigner le code du grade CALO.
     *
     * @param caloGradeCode le code du grade CALO
     */
    void setCaloGradeCode(String caloGradeCode);

    /**
     * Cette méthode permet d'obtenir le code de la classe CALO.
     *
     * @return le code de la classe CALO
     */
    String getCaloClassCode();

    /**
     * Cette méthode permet d'assigner le code de la classe CALO.
     *
     * @param caloClassCode le code de la classe CALO
     */
    void setCaloClassCode(String caloClassCode);

    /**
     * Cette méthode permet d'obtenir le code de l'échelon CALO.
     *
     * @return le code de l'échelon CALO
     */
    String getCaloStepCode();

    /**
     * Cette méthode permet d'assigner le code de l'échelon CALO.
     *
     * @param caloStepCode le code de l'échelon CALO
     */
    void setCaloStepCode(String caloStepCode);

    /**
     * {@link FurGradeDto#JSON_SCALE_CORPS_CODE}.
     */
    String JSON_SCALE_CORPS_CODE = FurGradeDto.JSON_SCALE_CORPS_CODE;

    /**
     * {@link FurGradeDto#JSON_GRADE_CODE}.
     */
    String JSON_GRADE_CODE = FurGradeDto.JSON_GRADE_CODE;

    /**
     * {@link FurGradeDto#JSON_CATEGORY_CODE}.
     */
    String JSON_CATEGORY_CODE = FurGradeDto.JSON_CATEGORY_CODE;

    /**
     * {@link FurGradeDto#JSON_CALO_JOB_CODE}.
     */
    String JSON_CALO_JOB_CODE = FurGradeDto.JSON_CALO_JOB_CODE;

    /**
     * {@link FurGradeDto#JSON_CALO_GRADE_CODE}.
     */
    String JSON_CALO_GRADE_CODE = FurGradeDto.JSON_CALO_GRADE_CODE;

    /**
     * {@link FurGradeDto#JSON_CALO_CLASS_CODE}.
     */
    String JSON_CALO_CLASS_CODE = FurGradeDto.JSON_CALO_CLASS_CODE;

    /**
     * {@link FurGradeDto#JSON_CALO_STEP_CODE}.
     */
    String JSON_CALO_STEP_CODE = FurGradeDto.JSON_CALO_STEP_CODE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GRADE_FUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FurGradeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FurGradeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurGradeCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements FurGradeSaveRequestDto {

    @JsonbProperty(JSON_SCALE_CORPS_CODE)
    private String scaleCorpsCode;

    @JsonbProperty(JSON_GRADE_CODE)
    private String gradeCode;

    @JsonbProperty(JSON_CATEGORY_CODE)
    private String categoryCode;

    @JsonbProperty(JSON_CALO_JOB_CODE)
    private String caloJobCode;

    @JsonbProperty(JSON_CALO_GRADE_CODE)
    private String caloGradeCode;

    @JsonbProperty(JSON_CALO_CLASS_CODE)
    private String caloClassCode;

    @JsonbProperty(JSON_CALO_STEP_CODE)
    private String caloStepCode;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GRADE_FUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class FurGradeGetManyResponseDto
      extends AbstractGetByPageResponseDto<FurGradeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FurGradeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GRADE_FUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GRADE_FUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link FurGradeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FurGradeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GRADE_FUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FurGradeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FurGradeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurGradeUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements FurGradeSaveRequestDto {

    @JsonbProperty(JSON_SCALE_CORPS_CODE)
    private String scaleCorpsCode;

    @JsonbProperty(JSON_GRADE_CODE)
    private String gradeCode;

    @JsonbProperty(JSON_CATEGORY_CODE)
    private String categoryCode;

    @JsonbProperty(JSON_CALO_JOB_CODE)
    private String caloJobCode;

    @JsonbProperty(JSON_CALO_GRADE_CODE)
    private String caloGradeCode;

    @JsonbProperty(JSON_CALO_CLASS_CODE)
    private String caloClassCode;

    @JsonbProperty(JSON_CALO_STEP_CODE)
    private String caloStepCode;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GRADE_FUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FurGradeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
