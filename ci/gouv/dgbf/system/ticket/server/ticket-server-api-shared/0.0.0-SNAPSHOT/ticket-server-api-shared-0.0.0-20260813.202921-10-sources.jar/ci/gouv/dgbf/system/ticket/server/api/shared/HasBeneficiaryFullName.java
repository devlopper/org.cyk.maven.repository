package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nom complet de bénéficiaire, saisi
 * librement lorsque le bénéficiaire n'est pas une identité connue.
 *
 * @author Christian
 */
public interface HasBeneficiaryFullName extends HasField {

  /**
   * Cette méthode permet d'obtenir le nom complet du bénéficiaire.
   *
   * @return le nom complet du bénéficiaire
   */
  String getBeneficiaryFullName();

  /**
   * Cette méthode permet d'assigner le nom complet du bénéficiaire.
   *
   * @param beneficiaryFullName le nom complet du bénéficiaire
   */
  void setBeneficiaryFullName(String beneficiaryFullName);

  /**
   * Identifiant java du nom complet du bénéficiaire.
   */
  String FIELD_BENEFICIARY_FULL_NAME = "beneficiaryFullName";
}
