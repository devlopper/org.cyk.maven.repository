package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationFunctionTypeService.RepresentationFunctionTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationFunctionTypeService.RepresentationFunctionTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RepresentationFunctionTypeDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RepresentationFunctionTypeDto}.

    @author akm
               """)
public interface RepresentationFunctionTypeRequestMapper extends 
    RequestMapper<RepresentationFunctionTypeDto,
    RepresentationFunctionTypeCreateRequestDto, RepresentationFunctionTypeUpdateRequestDto> {

}
