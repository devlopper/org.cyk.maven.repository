package ci.gouv.dgbf.extension.server.service.impl.converter;

import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Cette classe représente le convertisseur du type byte[].
 *
 * @author Christian
 *
 */
public class ByteArrayListParamConverter
    implements jakarta.ws.rs.ext.ParamConverter<List<byte[]>> {
  private static final Logger LOGGER =
      Logger.getLogger(ByteArrayListParamConverter.class.getName());

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet de construire une instance.
   *
   * @param stringHelper l'aide du type chaine de caractère
   */
  public ByteArrayListParamConverter(StringHelper stringHelper) {
    this.stringHelper = stringHelper;
  }

  @Override
  public List<byte[]> fromString(String string) {
    if (Boolean.TRUE.equals(stringHelper.isBlank(string))) {
      return Collections.emptyList();
    }
    List<byte[]> list = new ArrayList<>(
        Arrays.stream(string.split(",")).map(i -> Base64.getDecoder().decode(i)).toList());
    LOGGER.log(Level.FINE,
        "Chaine de caractère convertie en liste de tableau d''octets. #Catactère = {0}"
            + ", #Tableau = {1}",
        new Object[] {string.length(), list.size()});
    return list;
  }

  @Override
  public String toString(List<byte[]> list) {
    if (list == null) {
      return null;
    }
    String string = list.stream().map(bytes -> Base64.getEncoder().encodeToString(bytes))
        .collect(Collectors.joining(","));
    LOGGER.log(Level.FINE,
        "Liste de tableau d''octets convertie en chaine de caractère. #Tableau = {0}"
            + ", #Catactère = {1}",
        new Object[] {list.size(), string.length()});
    return string;
  }
}
