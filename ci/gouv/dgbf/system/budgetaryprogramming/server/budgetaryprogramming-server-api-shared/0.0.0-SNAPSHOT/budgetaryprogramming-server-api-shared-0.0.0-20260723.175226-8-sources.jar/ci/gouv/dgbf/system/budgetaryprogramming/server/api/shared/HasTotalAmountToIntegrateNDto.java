package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateNDto extends HasTotalAmountToIntegrateN {

  /**
   * Identifiant json du montant total à intégrer pour l'année N.
   */
  String JSON_TOTAL_AMOUNT_TO_INTEGRATE_N = "montantTotalAIntegrerN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName