package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant intégré à l'horizon N1.
 *
 * @author Christian
 */
public interface HasIntegratedAmountN1 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant intégré à l'horizon N1.
   *
   * @return le montant intégré à l'horizon N1
   */
  Long getIntegratedAmountN1();

  /**
   * Cette méthode permet d'assigner le montant intégré à l'horizon N1.
   *
   * @param amount le montant intégré à l'horizon N1
   */
  void setIntegratedAmountN1(Long amount);

  /**
   * Identifiant java du montant intégré à l'horizon N1.
   */
  String FIELD_INTEGRATED_AMOUNT_N1 = "integratedAmountN1";
}
