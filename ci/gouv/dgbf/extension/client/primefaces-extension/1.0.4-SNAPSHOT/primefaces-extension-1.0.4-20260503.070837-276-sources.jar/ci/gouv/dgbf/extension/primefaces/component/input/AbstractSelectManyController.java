package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente un contrôleur d'un sélecteur de plusieurs éléments.
 *
 * @author Christian
 *
 */
public abstract class AbstractSelectManyController extends AbstractSelectController {

  /* Controls */

  protected SelectManyCheckboxString selectManyCheckbox;

  protected AutoCompleteStrings autoComplete;
  
  /*------------------------------ Select many check box ------------------------------*/

  /**
   * Cette méthode permet d'obtenir selectManyCheckbox.
   *
   * @return selectManyCheckbox
   */
  public SelectManyCheckboxString getSelectManyCheckbox() {
    if (!initialized) {
      Core.runIfNull(selectManyCheckbox,
          () -> selectManyCheckbox = instantiateSelectManyCheckbox());
      initialized = true;
    }
    return selectManyCheckbox;
  }

  protected SelectManyCheckboxString instantiateSelectManyCheckbox() {
    SelectManyCheckboxString selector = new SelectManyCheckboxString();
    processSelectManyCheckbox(selector);
    processOutputLabel(selector.outputLabel());
    computeSelectManyCheckboxChoices(selector);
    return selector;
  }

  protected void computeSelectManyCheckboxChoices(SelectManyCheckboxString selector) {
    selector.setChoices(null);
    List<SelectItem> selectItems = computeSelectItems();
    selector.addChoices(selectItems);
  }

  /**
   * Cette méthode permet de calculer les choix du selectManyCheckbox.
   */
  public void computeSelectManyCheckboxChoices() {
    computeSelectManyCheckboxChoices(selectManyCheckbox);
  }

  protected void processSelectManyCheckbox(SelectManyCheckboxString selectManyCheckbox) {
    processInput(selectManyCheckbox);
  }
  
  /*------------------------------ Select many suggestions ------------------------------*/

  /**
   * Cette méthode permet d'obtenir autoComplete.
   *
   * @return autoComplete
   */
  public AutoCompleteStrings getAutoComplete() {
    if (!initialized) {
      Core.runIfNull(autoComplete,
          () -> autoComplete = instantiateAutoComplete());
      initialized = true;
    }
    return autoComplete;
  }

  protected AutoCompleteStrings instantiateAutoComplete() {
    AutoCompleteStrings selector = new AutoCompleteStrings(scriptManager);
    processAutoComplete(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processAutoComplete(AutoCompleteStrings autoComplete) {
    processInput(autoComplete);
  }
}
