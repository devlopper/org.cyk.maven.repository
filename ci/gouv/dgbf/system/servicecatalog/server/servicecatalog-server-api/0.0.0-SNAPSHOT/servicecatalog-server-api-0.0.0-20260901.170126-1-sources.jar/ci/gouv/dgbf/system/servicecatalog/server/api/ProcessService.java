package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProcessDto}.
 *
 * @author Christian
 */
@Path(value = ProcessService.PATH)
@Tag(name = "Gestion des Processus")
public interface ProcessService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "processus";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProcessSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir description du processus.
     *
     * @return description du processus
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner description du processus.
     *
     * @param description description du processus
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir nature du processus (Backend, Frontend Web, Frontend Mobile
     * Flutter/Android/iOS, ...) — champ libre, non contraint.
     *
     * @return nature du processus (Backend, Frontend Web, Frontend Mobile Flutter/Android/iOS,
     *     ...) — champ libre, non contraint
     */
    String getNature();

    /**
     * Cette méthode permet d'assigner nature du processus (Backend, Frontend Web, Frontend
     * Mobile Flutter/Android/iOS, ...) — champ libre, non contraint.
     *
     * @param nature nature du processus (Backend, Frontend Web, Frontend Mobile
     *     Flutter/Android/iOS, ...) — champ libre, non contraint
     */
    void setNature(String nature);

    /**
     * Cette méthode permet d'obtenir URL de base, adresse d'entrée du processus.
     *
     * @return URL de base, adresse d'entrée du processus
     */
    String getBaseUrl();

    /**
     * Cette méthode permet d'assigner URL de base, adresse d'entrée du processus.
     *
     * @param baseUrl URL de base, adresse d'entrée du processus
     */
    void setBaseUrl(String baseUrl);

    /**
     * Cette méthode permet d'obtenir si le processus est présenté à tous les utilisateurs
     * authentifiés dans le catalogue.
     *
     * @return si le processus est présenté à tous les utilisateurs authentifiés dans le
     *     catalogue
     */
    Boolean getVisible();

    /**
     * Cette méthode permet d'assigner si le processus est présenté à tous les utilisateurs
     * authentifiés dans le catalogue.
     *
     * @param visible si le processus est présenté à tous les utilisateurs authentifiés dans le
     *     catalogue
     */
    void setVisible(Boolean visible);

    /**
     * Cette méthode permet d'obtenir identifiant du Module auquel ce processus est
     * obligatoirement rattaché.
     *
     * @return identifiant du Module auquel ce processus est obligatoirement rattaché
     */
    String getModuleIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du Module auquel ce processus est
     * obligatoirement rattaché.
     *
     * @param moduleIdentifier identifiant du Module auquel ce processus est obligatoirement
     *     rattaché
     */
    void setModuleIdentifier(String moduleIdentifier);

    /**
     * {@link ProcessDto#JSON_DESCRIPTION}.
     */
    String JSON_DESCRIPTION = ProcessDto.JSON_DESCRIPTION;

    /**
     * {@link ProcessDto#JSON_NATURE}.
     */
    String JSON_NATURE = ProcessDto.JSON_NATURE;

    /**
     * {@link ProcessDto#JSON_BASE_URL}.
     */
    String JSON_BASE_URL = ProcessDto.JSON_BASE_URL;

    /**
     * {@link ProcessDto#JSON_VISIBLE}.
     */
    String JSON_VISIBLE = ProcessDto.JSON_VISIBLE;

    /**
     * {@link ProcessDto#JSON_MODULE_IDENTIFIER}.
     */
    String JSON_MODULE_IDENTIFIER = ProcessDto.JSON_MODULE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProcessDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_PROCESSUS";

  /**
   * Chemin du service de création unitaire de {@link ProcessDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProcessCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcessCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ProcessSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_BASE_URL)
    private String baseUrl;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_MODULE_IDENTIFIER)
    private String moduleIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProcessDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROCESSUS";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProcessDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProcessGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcessDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcessDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProcessDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_PROCESSUS";

  /**
   * Chemin du service d'obtention unitaire de {@link ProcessDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProcessDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROCESSUS";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProcessDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProcessDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROCESSUS";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProcessDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcessUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcessUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ProcessSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_BASE_URL)
    private String baseUrl;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_MODULE_IDENTIFIER)
    private String moduleIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProcessDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROCESSUS";

  /**
   * Chemin du service de suppression unitaire de {@link ProcessDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
