package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre back-office de
 * {@link IdentityPolicyConsentDto}.
 *
 * @author desysoft
 *
 */
@Dependent
public class IdentityPolicyConsentFilterController
    extends AbstractFilterController<IdentityPolicyConsentFilter> {

  @Inject
  @Getter
  IdentitySelectOneController identitySelectOneController;

  @Inject
  @Getter
  PolicySelectOneController policySelectOneController;

  @Inject
  @Getter
  PolicyVersionSelectOneController policyVersionSelectOneController;

  @Inject
  @Getter
  IdentityPolicyConsentStatusSelectOneController statusSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public IdentityPolicyConsentFilterController() {
    super(IdentityPolicyConsentFilter.class);
  }

  /**
   * Cette méthode permet d'initialiser les éléments de filtre.
   */
  public void initialize() {
    identitySelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setIdentityIdentifier(identifier));
    policySelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setPolicyIdentifier(identifier));
    policyVersionSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setPolicyVersionIdentifier(identifier));
    statusSelectOneController.getSelectOneMenu().addValueConsumer(
        name -> filter.setStatusCode(name == null ? null
            : IdentityPolicyConsentStatus.valueOf(name).getCode()));
  }
}
