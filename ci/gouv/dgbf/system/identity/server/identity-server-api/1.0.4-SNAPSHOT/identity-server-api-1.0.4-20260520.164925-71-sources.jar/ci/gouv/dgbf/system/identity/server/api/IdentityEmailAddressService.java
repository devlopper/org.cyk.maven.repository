package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IdentityEmailAddressDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = IdentityEmailAddressService.PATH)
@Tag(name = "Gestion des adresses email d'identités")
public interface IdentityEmailAddressService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "adresses-emails-identites";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IdentityEmailAddressCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface IdentityEmailAddressSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentityDto}.
     *
     * @return identifiant de {@link IdentityDto}
     */
    String getIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link IdentityDto}.
     *
     * @param identityIdentifier identifiant de {@link IdentityDto}
     */
    void setIdentityIdentifier(String identityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'adresse email.
     *
     * @return adresse email
     */
    String getEmailAddress();

    /**
     * Cette méthode permet d'assigner l'adresse email.
     *
     * @param emailAddress adresse email
     */
    void setEmailAddress(String emailAddress);

    /**
     * {@link HasIdentityIdentifierDto#JSON_IDENTITY_IDENTIFIER}.
     */
    String JSON_IDENTITY_IDENTIFIER = HasIdentityIdentifierDto.JSON_IDENTITY_IDENTIFIER;

    /**
     * {@link HasEmailAddressDto#JSON_EMAIL_ADDRESS}.
     */
    String JSON_EMAIL_ADDRESS = HasEmailAddressDto.JSON_EMAIL_ADDRESS;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityEmailAddressCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements IdentityEmailAddressSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(JSON_EMAIL_ADDRESS)
    private String emailAddress;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des identités de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class IdentityEmailAddressGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentityEmailAddressDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentityEmailAddressDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une identité de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link IdentityEmailAddressDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityEmailAddressDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentityEmailAddressDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IdentityEmailAddressUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityEmailAddressUpdateRequestDto extends ByIdentifierRequestDto
      implements IdentityEmailAddressSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(JSON_EMAIL_ADDRESS)
    private String emailAddress;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_IDENTITE_ADRESSE_EMAIL";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une identité de groupe")
  Response delete(DeleteOneRequestDto request);
}
