package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.user.server.api.UserRole;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserRoleDto}.
 *
 * @author Arnaud
 */
@Named
@ViewScoped
public class UserRoleListPage extends AbstractPage {

  @Inject
  @Getter
  UserRoleController controller;

  @Inject
  UserRights userRights;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + UserRoleDto.NAME;
    controller.initialize();
  }

  /**
   * Cette méthode indique si « Ajouter plusieurs » est proposé : l'Utilisateur connecté a le Droit
   * d'assigner des Rôles pour au moins une Application (TCH_UTI_773, RG_UTI_ROL_16).
   *
   * @return vrai s'il a le Droit
   */
  public boolean isCreateManyRendered() {
    return userRights.isGrantedForAny(UserRole.ASSIGN_USER_ROLE);
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "userRoleListPage";
}
