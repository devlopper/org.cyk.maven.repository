package ci.gouv.dgbf.system.sharing.server.api;

/**
 * Cette classe représente les codes de {@link VisibilityLevel}.
 *
 * @author Christian
 *
 */
public class VisibilityLevelCode {

  private VisibilityLevelCode() {

  }

  /**
   * Complet.
   */
  public static final String FULL = "COMPLET";
  /**
   * Résumé.
   */
  public static final String SUMMARY = "RESUME";
  /**
   * Aucun.
   */
  public static final String NONE = "AUCUN";
}
