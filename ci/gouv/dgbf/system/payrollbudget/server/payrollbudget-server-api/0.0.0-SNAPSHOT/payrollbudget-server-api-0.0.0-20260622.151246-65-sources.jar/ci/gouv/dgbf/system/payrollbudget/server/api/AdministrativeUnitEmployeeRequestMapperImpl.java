package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link AdministrativeUnitEmployeeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T15:13:09+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class AdministrativeUnitEmployeeRequestMapperImpl implements AdministrativeUnitEmployeeRequestMapper {

    @Override
    public AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateRequestDto mapCreate(AdministrativeUnitEmployeeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateRequestDto administrativeUnitEmployeeCreateRequestDto = new AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateRequestDto();

        administrativeUnitEmployeeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitEmployeeCreateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setEmployeeIdentifier( arg0.getEmployeeIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setJobIdentifier( arg0.getJobIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setPayIndexIdentifier( arg0.getPayIndexIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setFunctionIdentifier( arg0.getFunctionIdentifier() );
        administrativeUnitEmployeeCreateRequestDto.setBalanceTransferOriginAdministrativeUnitIdentifier( arg0.getBalanceTransferOriginAdministrativeUnitIdentifier() );

        return administrativeUnitEmployeeCreateRequestDto;
    }

    @Override
    public AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeUpdateRequestDto mapUpdate(AdministrativeUnitEmployeeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeUpdateRequestDto administrativeUnitEmployeeUpdateRequestDto = new AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeUpdateRequestDto();

        administrativeUnitEmployeeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitEmployeeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setEmployeeIdentifier( arg0.getEmployeeIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setJobIdentifier( arg0.getJobIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setPayIndexIdentifier( arg0.getPayIndexIdentifier() );
        administrativeUnitEmployeeUpdateRequestDto.setFunctionIdentifier( arg0.getFunctionIdentifier() );

        return administrativeUnitEmployeeUpdateRequestDto;
    }
}
