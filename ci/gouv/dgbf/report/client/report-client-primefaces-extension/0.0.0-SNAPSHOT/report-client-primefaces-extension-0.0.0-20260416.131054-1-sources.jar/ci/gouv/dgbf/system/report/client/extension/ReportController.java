package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.client.extension.DictionarySelectOneController;
import ci.gouv.dgbf.system.report.client.extension.viewer.PrintButtonController;
import ci.gouv.dgbf.system.report.client.extension.viewer.PrintParametersDialogController;
import ci.gouv.dgbf.system.report.client.extension.viewer.ReportPrintConfigurationController;
import ci.gouv.dgbf.system.report.client.extension.viewer.ViewerOpener;
import ci.gouv.dgbf.system.report.server.api.ReportClient;
import ci.gouv.dgbf.system.report.server.api.ReportDto;
import ci.gouv.dgbf.system.report.server.api.ReportFilter;
import ci.gouv.dgbf.system.report.server.api.ReportRequestMapper;
import ci.gouv.dgbf.system.report.server.api.ReportService;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportCreateRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link ReportDto}.
 *
 * @author Christian
 */
@Dependent
public class ReportController extends AbstractController {

  @Inject
  ReportClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ReportRequestMapper requestMapper;

  @Inject
  @Getter
  DictionarySelectOneController dictionarySelectOneController;

  @Inject
  @Getter
  IdentifiableProcessingController editReportParametersProcessingController;

  @Getter
  HashMap<String, String> reportParametersInput = new HashMap<>();

  @Getter
  @Inject
  ReportPrintConfigurationController reportPrintConfigurationController;


  @Getter
  @Inject
  PrintButtonController printButtonController;

  @Inject
  @Getter
  PrintParametersDialogController printParametersDialogController;

  @Getter
  @Setter
  ReportDto reportToPrint;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ReportDto.NAME;

    listController.setEntityClass(ReportDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ReportService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        ReportDto.JSON_DESCRIPTION,
        ReportDto.JSON_TEMPLATE_IDENTIFIER,
        ReportDto.JSON_PARAMETERS_DICTIONARY_AS_STRING,
        AbstractIdentifiableCodableDto.JSON_CODE,
        AbstractIdentifiableCodableNamableDto.JSON_NAME);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController()
        .setFunction(entity -> {
          ReportCreateRequestDto request = requestMapper.mapCreate((ReportDto) entity);
          request.setParametersDictionaryIdentifier(
              ((ReportDto) entity).getParametersDictionaryIdentifier());
          request.setAuditWho(userIdentifier);
          return client.create(request);
        });

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    ReportDto.JSON_DESCRIPTION,
                    ReportDto.JSON_TEMPLATE_IDENTIFIER,
                    ReportDto.JSON_PARAMETERS_DICTIONARY_IDENTIFIER,
                    AbstractIdentifiableCodableDto.JSON_CODE,
                    AbstractIdentifiableCodableNamableDto.JSON_NAME
                )
        );

    listController.getUpdateController()
        .setFunction(entity -> {
          ReportUpdateRequestDto request = requestMapper.mapUpdate((ReportDto) entity);
          request.setAuditWho(userIdentifier);
          return client.update(request);
        });

    dictionarySelectOneController
        .getSelectOneMenu()
        .addValueConsumer(parametersDictionaryIdentifierConsumer());

    prepareEditReportParametersValue();
  }

  Consumer<String> parametersDictionaryIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ReportDto.class)
        .setParametersDictionaryIdentifier(identifier);
  }


  void prepareEditReportParametersValue() {
    editReportParametersProcessingController.setViewer(
        IdentifiableProcessingController.Viewer.DIALOG);
    editReportParametersProcessingController.prepareDialog(ReportDto.class,
        "Editer",
        "pi pi-print", assignValueToReportEntriesFunction(), "editReportParametersForm", client);
    editReportParametersProcessingController.setListController(listController);
    editReportParametersProcessingController.addShowDialogConsumer(loadReportParametersInputs());
    editReportParametersProcessingController.initialize();
  }

  UnaryOperator<Object> assignValueToReportEntriesFunction() {
    return entity -> {
      ViewerOpener opener = new ViewerOpener();
      opener.scriptBuilder().uriBuilder().reportIdentifier(reportToPrint.getTemplateIdentifier());
      opener.scriptBuilder().uriBuilder().fileType("pdf");
      opener.scriptBuilder().uriBuilder().auditWho(userIdentifier);
      HashMap<String, List<String>> parametersForPrint = new HashMap<>();
      reportParametersInput.forEach((key, value) -> {
        parametersForPrint.put(key, List.of(value));
      });
      opener.scriptBuilder().uriBuilder().reportParametersAsJsonBuilder().map()
          .add(parametersForPrint);
      opener.open();
      return null;
    };
  }

  Consumer<String> loadReportParametersInputs() {
    return identifier -> {
      reportParametersInput.clear();
      ReportFilter filter = new ReportFilter();
      filter.setIdentifier(identifier);
      GetOneRequestDto request = new GetOneRequestDto();
      ProjectionDto projectionDto = new ProjectionDto();
      projectionDto.addNames(ReportDto.JSON_TEMPLATE_IDENTIFIER,
          ReportDto.JSON_PARAMETERS_DICTIONARY_ENTRIES_NAMES);
      request.setFilter(filter.toDto());
      request.setProjection(projectionDto);
      request.setAuditWho(this.userIdentifier);
      reportToPrint = client.getOne(request);
      if (reportToPrint.getParametersDictionaryEntriesNames() != null) {
        for (String dictionaryEntriesCode : reportToPrint.getParametersDictionaryEntriesNames()) {
          reportParametersInput.put(dictionaryEntriesCode, null);
        }
      }
    };
  }
}

