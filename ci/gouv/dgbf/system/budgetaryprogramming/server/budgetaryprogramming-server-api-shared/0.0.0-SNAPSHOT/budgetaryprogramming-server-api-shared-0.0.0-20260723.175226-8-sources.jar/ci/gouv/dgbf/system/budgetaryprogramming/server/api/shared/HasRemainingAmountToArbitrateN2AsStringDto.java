package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateN2AsStringDto
    extends HasRemainingAmountToArbitrateN2AsString {

  /**
   * Identifiant json du montant restant à arbitrer pour l'année N+2,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_ARBITRATE_N2_AS_STRING =
      "montantResteAArbitrerN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName