package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'informations complémentaires sur le
 * bénéficiaire, saisies librement lorsque le bénéficiaire n'est pas une identité connue.
 *
 * @author Christian
 */
public interface HasBeneficiaryAdditionalInformationDto
    extends HasBeneficiaryAdditionalInformation {

  /**
   * Identifiant json des informations complémentaires sur le bénéficiaire.
   */
  String JSON_BENEFICIARY_ADDITIONAL_INFORMATION = "informationsComplementairesBeneficiaire";
}
