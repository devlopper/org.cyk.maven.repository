package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.logging.server.api.LogService.GetManyResponseDto;
import ci.gouv.dgbf.system.logging.server.api.LogService.LogCreateRequestDto;
import ci.gouv.dgbf.system.logging.server.api.LogService.LogUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente le client de LogService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class LogClient extends AbstractClient<LogService> implements GetByIdentifier<LogDto>,
    GetMany<GetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {
  private static final Logger LOGGER = Logger.getLogger(LogClient.class.getName());

  @Override
  public LogClient service(LogService service) {
    return (LogClient) super.service(service);
  }

  void setProcessIdentifier(LogCreateRequestDto request) {
    if (request != null && Core.isStringBlank(request.getProcessIdentifier())) {
      request.setProcessIdentifier(callerIdentifier());
    }
  }

  void setLevel(LogCreateRequestDto request) {
    if (request != null && request.getLevel() == null) {
      request.setLevel(LogLevel.INFORMATION);
    }
  }

  /**
   * {@link LogService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(LogCreateRequestDto request) {
    CreateResponseDto response;
    if (Boolean.TRUE.equals(disabled)) {
      response = null;
      LOGGER.log(Level.WARNING, "Client {0} désactivé. Impossible de créer log.",
          serviceIdentifier());
    } else {
      setProcessIdentifier(request);
      setLevel(request);
      response = new CreateExecutor(LogService.CREATE_IDENTIFIER)
          .setExceptionThrowable(Boolean.FALSE).execute(() -> service().create(request));
      LOGGER.log(Level.FINER, "Un log a été créé. {0}",
          String.format("%s=%s, %s=%s", HasLevelDto.JSON_LEVEL, request.getLevel(),
              HasMessageDto.JSON_MESSAGE, request.getMessage()));
    }
    return response;
  }

  /**
   * {@link LogService#create}.
   *
   * @param processIdentifier identifiant du processus
   * @param level niveau
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto create(String processIdentifier, LogLevel level, String message,
      String auditWho, String auditSession) {
    LogCreateRequestDto request = new LogCreateRequestDto();
    request.setProcessIdentifier(processIdentifier);
    request.setLevel(level);
    request.setMessage(message);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link LogService#create}.
   *
   * @param level niveau
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto create(LogLevel level, String message, String auditWho,
      String auditSession) {
    return create(null, level, message, auditWho, auditSession);
  }

  /**
   * {@link LogService#create}.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto create(String message, String auditWho, String auditSession) {
    return create(null, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message d'erreur.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createError(String message, String auditWho, String auditSession) {
    return create(LogLevel.ERROR, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message d'avertissement.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createWarning(String message, String auditWho, String auditSession) {
    return create(LogLevel.WARNING, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message d'information.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createInformation(String message, String auditWho, String auditSession) {
    return create(LogLevel.INFORMATION, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message de debug.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createDebug(String message, String auditWho, String auditSession) {
    return create(LogLevel.DEBUG, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message de trace.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createTrace(String message, String auditWho, String auditSession) {
    return create(LogLevel.TRACE, message, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de créer un message de configuration.
   *
   * @param message message
   * @param auditWho qui
   * @param auditSession session
   * @return réponse
   */
  public CreateResponseDto createConfiguration(String message, String auditWho,
      String auditSession) {
    return create(LogLevel.CONFIGURATION, message, auditWho, auditSession);
  }

  /**
   * {@link LogService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        LogService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link LogService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link LogService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public LogDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<LogDto>(LogDto.class, LogService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link LogService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public LogDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link LogService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public LogDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<LogDto>(LogDto.class, LogService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link LogService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LogDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link LogService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(LogUpdateRequestDto request) {
    return new IdentifiableExecutor(LogService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link LogService#update}.
   *
   * @param identifier identifiant
   * @param processIdentifier identifiant du processus
   * @param level niveau
   * @param message message
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String processIdentifier, LogLevel level,
      String message, String auditWho, String auditSession) {
    LogUpdateRequestDto request = new LogUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setProcessIdentifier(processIdentifier);
    request.setLevel(level);
    request.setMessage(message);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link LogService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(LogService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link LogService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
