package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.

    @author stephane
               """)
public interface SubAdministrativeUnitRequestMapper extends RequestMapper<SubAdministrativeUnitDto,
    SubAdministrativeUnitCreateRequestDto, SubAdministrativeUnitUpdateRequestDto> {

}
