package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'utilisateur.
 *
 * @author Christian
 */
public interface FilterHasUserIdentifier extends HasUserIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'utilisateur.
   *
   * @param filter {@link FilterDto}
   */
  default void updateUserIdentifier(FilterDto filter) {
    setUserIdentifier(UserIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'utilisateur de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterUserIdentifier(FilterDto filter) {
    UserIdentifierFilter.set(filter, getUserIdentifier());
  }

}
