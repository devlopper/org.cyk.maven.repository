package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDeductionsAmountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasEmployerAmountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGrossAmountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasNetAmountAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByFilterRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiablesResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayslipDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = PayslipService.PATH)
@Tag(name = "Gestion des bulletins de paie")
public interface PayslipService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "bulletins-paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface PayslipSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollDto}.
     *
     * @return identifiant {@link PayrollDto}
     */
    String getPayrollIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollDto}.
     *
     * @param identifier identifiant {@link PayrollDto}
     */
    void setPayrollIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RemunerableDto}.
     *
     * @return identifiant {@link RemunerableDto}
     */
    String getRemunerableIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link RemunerableDto}.
     *
     * @param identifier identifiant {@link RemunerableDto}
     */
    void setRemunerableIdentifier(String identifier);

    /**
     * {@link PayslipDto#JSON_PAYROLL_IDENTIFIER}.
     */
    public static final String JSON_PAYROLL_IDENTIFIER = PayslipDto.JSON_PAYROLL_IDENTIFIER;

    /**
     * {@link PayslipDto#JSON_REMUNERABLE_IDENTIFIER}.
     */
    public static final String JSON_REMUNERABLE_IDENTIFIER = PayslipDto.JSON_REMUNERABLE_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_BULLETIN_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un nouveau bulletin de paie.<br/>
   * Le processus de création suit les étapes suivantes :
   * <ol>
   * <li><b>Génération des éléments de paie issus du référentiel global.</b><br/>
   * Ces éléments seront utilisés pour les différents calculs et permettront aussi de tracer les
   * changements effectués lors des opérations nécessaires pour actualiser la situation de
   * l'employé</li>
   * <li><b>Génération des postes de paie du bulletin.</b><br/>
   * Les postes sont générés sur la base des modèles de poste de paie de l'emploi de l'employé</li>
   * <li><b>Calcul des montants des postes de paie.</b><br/>
   * Le calcul est effectué à la demande</li>
   * <li><b>Attribution du statut.</b><br/>
   * {@link PayslipStatusCode#INITIALIZED} si les montants sont calculés,
   * {@link PayslipStatusCode#CREATED} sinon</li>
   * </ol>
   * <img src="doc-files/diagramme_sequence_creation_bulletin.png" alt=
   * "diagramme_sequence_creation_bulletin">
   *
   * @param request {@link PayslipCreateRequestDto}
   * @return réponse {@link CreateResponseDto}
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayslipCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayslipSaveRequestDto {
    /**
     * Identifiant de {@link PayrollDto}.
     */
    @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
    private String payrollIdentifier;

    /**
     * Identifiant de {@link RemunerableDto}.
     */
    @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
    private String remunerableIdentifier;

    /**
     * Calculer les montants.
     */
    @JsonbProperty(JSON_IS_COMPUTE_AMOUNTS)
    private Boolean isComputeAmounts;

    /**
     * Identifiant json de {@link #isComputeAmounts}.
     */
    public static final String JSON_IS_COMPUTE_AMOUNTS = "calculerMontant";
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class PayslipGetManyResponseDto extends AbstractGetByPageResponseDto<PayslipDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayslipDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention de {@link PayslipDto}.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de {@link PayslipDto}.
   */
  String GET_COUNT_PATH = "obtention/bulletin-paie";

  /**
   * Cette méthode permet d'obtenir un {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_BULLETIN_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayslipUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipUpdateRequestDto extends ByIdentifierRequestDto implements PayslipSaveRequestDto {
    /**
     * Identifiant de {@link PayrollDto}.
     */
    @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
    String payrollIdentifier;

    /**
     * Identifiant de {@link RemunerableDto}.
     */
    @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
    String remunerableIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_BULLETIN_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de calcul.
   */
  String CALCULATE_IDENTIFIER = "CALCUL_BULLETIN_PAIE";

  /**
   * Chemin du service de calcul.
   */
  String CALCULATE_PATH = "calcul";

  /**
   * Cette méthode permet de calculer {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CALCULATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CALCULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response calculate(PayslipCalculateRequestDto request);

  /**
   * Cette classe représente la requête de calcul.
   *
   * @author Christian
   */
  class PayslipCalculateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la requête de transmission au contentieux.
   *
   * @author akm
   */
  @Getter
  @Setter
  class PayslipTransmitLitigationRequestDto extends ByIdentifierRequestDto {
    @JsonbProperty(JSON_LITIGATION_REASON)
    private String litigationReason;

    /**
     * Identifiant json de la représentation en chaine de caratères de la raison
     * de l'envoie au contentieux.
     */
    public static final String JSON_LITIGATION_REASON =
        "raisonContentieux";

  }

  /**
   * Identifiant du service d'initialisation.
   */
  String INITIALIZE_IDENTIFIER = "INITIALISATION_BULLETIN_PAIE";

  /**
   * Chemin du service d'initialisation.
   */
  String INITIALIZE_PATH = "initialisation";

  /**
   * Cette méthode permet d'initialiser {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(INITIALIZE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = INITIALIZE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response initialize(ByFilterRequestDto request);

  /**
   * Identifiant du service de controle.
   */
  String CONTROL_IDENTIFIER = "CONTROLE_BULLETIN_PAIE";

  /**
   * Chemin du service de controle.
   */
  String CONTROL_PATH = "controle";

  /**
   * Cette méthode permet de controler {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONTROL_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response control(ByFilterRequestDto request);

  /**
   * Identifiant du service d'acceptation.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_BULLETIN_PAIE";

  /**
   * Chemin du service d'acceptation.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet de accepter {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = ACCEPT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response accept(ByFilterRequestDto request);

  /**
   * Identifiant du service de recalcul.
   */
  String RECALCULATE_IDENTIFIER = "RECALCUL_BULLETIN_PAIE";

  /**
   * Chemin du service de recalcul.
   */
  String RECALCULATE_PATH = "recalcul";

  /**
   * Cette méthode permet de recalculer {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(RECALCULATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = RECALCULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response recalculate(ByFilterRequestDto request);

  /**
   * Identifiant du service de validation bulletin.
   */
  String VALIDATE_IDENTIFIER = "VALIDATION_BULLETIN_PAIE";

  /**
   * Chemin du service de validation bulletin.
   */
  String VALIDATE_PATH = "validation";

  /**
   * Cette méthode permet de valider un bulletin {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VALIDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = VALIDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response validate(ByFilterRequestDto request);

  /**
   * Identifiant du service de transmission au contentieux.
   */
  String TRANSMIT_TO_LITIGATION_IDENTIFIER = "TRANSMISSION_BULLETIN_PAIE_AU_CONTENTEIUX";

  /**
   * Chemin du service de transmission au contentieux.
   */
  String TRANSMIT_TO_LITIGATION_PATH = "transmission_au_contentieux";

  /**
   * Cette méthode permet de transmettre au contentieux {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_LITIGATION_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TRANSMIT_TO_LITIGATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiablesResponseDto.class))})
  Response transmitToLitigation(PayslipTransmitLitigationRequestDto request);

  /**
   * Identifiant du service de réintegration du contentieux.
   */
  String REINTEGRATE_FROM_LITIGATION_IDENTIFIER = "REINTEGRATION_BULLETIN_PAIE_DU_CONTENTEIUX";

  /**
   * Chemin du service de reintegration du contentieux.
   */
  String REINTEGRATE_FROM_LITIGATION_PATH = "reintegration_du_contentieux";

  /**
   * Cette méthode permet de réintégrer du contentieux un {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REINTEGRATE_FROM_LITIGATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = REINTEGRATE_FROM_LITIGATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
          content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response reintegrateFromLitigation(PayslipReintegrateFromLitigationRequestDto request);

  /**
   * Cette classe représente la requête de réintégration du contentieux.
   *
   * @author akm
   */
  class PayslipReintegrateFromLitigationRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de traitement.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiablesResponseDto {

    /**
     * {@link PayslipDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private PayslipStatus status;

    /**
     * {@link PayslipDto#getInitializable()}.
     */
    @JsonbProperty(JSON_INITIALIZABLE)
    private Boolean initializable;

    /**
     * {@link PayslipDto#getTransmittableForControl()}.
     */
    @JsonbProperty(JSON_TRANSMITTABLE_FOR_CONTROL)
    private Boolean transmittableForControl;

    /**
     * {@link PayslipDto#getControllable()}.
     */
    @JsonbProperty(JSON_CONTROLLABLE)
    private Boolean controllable;

    /**
     * {@link PayslipDto#getAcceptable()}.
     */
    @JsonbProperty(JSON_ACCEPTABLE)
    private Boolean acceptable;

    /**
     * {@link PayslipDto#getRecalculable()}.
     */
    @JsonbProperty(JSON_RECALCULABLE)
    private Boolean recalculable;

    /**
     * {@link PayslipDto#getValidable()}.
     */
    @JsonbProperty(JSON_VALIDABLE)
    private Boolean validable;

    /**
     * {@link PayslipDto#getArbitrable()}.
     */
    @JsonbProperty(JSON_ARBITRABLE)
    private Boolean arbitrable;

    /**
     * {@link PayslipDto#getClosable()}.
     */
    @JsonbProperty(JSON_CLOSABLE)
    private Boolean closable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link PayslipStatus}
     */
    public void initialize(PayslipStatus status) {
      this.status = status;
      initializable = PayslipStatus.INITIALIZED.getPrevious().contains(status);
      transmittableForControl =
          PayslipStatus.TRANSMITTED_FOR_CONTROL.getPrevious().contains(status);
      controllable = PayslipStatus.CONTROLLED.getPrevious().contains(status);
      acceptable = PayslipStatus.ACCEPTED.getPrevious().contains(status);
      recalculable = PayslipStatus.RECALCULATED.getPrevious().contains(status);
      validable = PayslipStatus.VALIDATED.getPrevious().contains(status);
      arbitrable = PayslipStatus.ARBITRATED.getPrevious().contains(status);
      closable = PayslipStatus.CLOSED.getPrevious().contains(status);
    }

    /**
     * {@link PayslipDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = PayslipDto.JSON_STATUS;

    /**
     * {@link PayslipDto#JSON_INITIALIZABLE}.
     */
    public static final String JSON_INITIALIZABLE = PayslipDto.JSON_INITIALIZABLE;

    /**
     * {@link PayslipDto#JSON_TRANSMITTABLE_FOR_CONTROL}.
     */
    public static final String JSON_TRANSMITTABLE_FOR_CONTROL =
        PayslipDto.JSON_TRANSMITTABLE_FOR_CONTROL;

    /**
     * {@link PayslipDto#JSON_CONTROLLABLE}.
     */
    public static final String JSON_CONTROLLABLE = PayslipDto.JSON_CONTROLLABLE;

    /**
     * {@link PayslipDto#JSON_ACCEPTABLE}.
     */
    public static final String JSON_ACCEPTABLE = PayslipDto.JSON_ACCEPTABLE;

    /**
     * {@link PayslipDto#JSON_RECALCULABLE}.
     */
    public static final String JSON_RECALCULABLE = PayslipDto.JSON_RECALCULABLE;

    /**
     * {@link PayslipDto#JSON_VALIDABLE}.
     */
    public static final String JSON_VALIDABLE = PayslipDto.JSON_VALIDABLE;

    /**
     * {@link PayslipDto#JSON_ARBITRABLE}.
     */
    public static final String JSON_ARBITRABLE = PayslipDto.JSON_ARBITRABLE;

    /**
     * {@link PayslipDto#JSON_CLOSABLE}.
     */
    public static final String JSON_CLOSABLE = PayslipDto.JSON_CLOSABLE;
  }

  /**
   * Identifiant du service d'obtention des sommes.
   */
  String GET_SUMS_IDENTIFIER = "OBTENTION_SOMMES_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention des sommes.
   */
  String GET_SUMS_PATH = "obtention/sommes";

  /**
   * Cette méthode permet d'obtenir des sommes.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_SUMS_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_SUMS_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipGetSumsResponseDto.class))})
  Response getSums(PayslipGetSumsRequestDto request);

  /**
   * Cette classe représente la requête d'obtention des sommes.
   *
   * @author Christian
   */
  class PayslipGetSumsRequestDto extends ByFilterRequestDto {

  }

  /**
   * Cette classe représente la réponse d'obtention des sommes.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class PayslipGetSumsResponseDto implements HasGrossAmountAsStringDto,
      HasDeductionsAmountAsStringDto, HasNetAmountAsStringDto, HasEmployerAmountAsStringDto {

    private String grossAmountAsString;

    private String deductionsAmountAsString;

    private String netAmountAsString;

    private String employerAmountAsString;
  }
}
