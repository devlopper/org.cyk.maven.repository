package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette classe représente les codes de {@link PositionField}.
 *
 * @author Christian
 *
 */
public class PositionFieldCode {

  private PositionFieldCode() {

  }

  /**
   * Emploi.
   */
  public static final String JOB = "EMPLOI";

  /**
   * Indice de paie.
   */
  public static final String PAY_INDEX = "INDICE";

  /**
   * Fonction.
   */
  public static final String FUNCTION = "FONCTION";
}
