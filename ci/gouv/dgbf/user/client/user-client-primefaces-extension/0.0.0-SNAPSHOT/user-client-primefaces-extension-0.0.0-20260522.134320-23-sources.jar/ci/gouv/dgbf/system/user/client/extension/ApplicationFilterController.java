package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ApplicationDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ApplicationFilterController extends AbstractFilterController<ApplicationFilter> {

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController userIdentifierInputTextController;

  @Inject
  @Getter
  DomainSelectOneController domainSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public ApplicationFilterController() {
    super(ApplicationFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setName(getRequestParameter(ApplicationFilter.JSON_NAME));
    nameInputTextController.setOutputLableValue("Libellé");
    nameInputTextController.getInputText().addValueConsumer(name -> filter.setName(name));

    filter.setDomainIdentifier(getRequestParameter(ApplicationFilter.JSON_DOMAIN_IDENTIFIER));
    domainSelectOneController.setOutputLableValue("Domaine");
    domainSelectOneController.getSelectOneMenu()
        .addValueConsumer(domainIdentifier -> filter.setDomainIdentifier(domainIdentifier));

    userIdentifierInputTextController.setOutputLableValue("Nom utilisateur");
    userIdentifierInputTextController.getInputText()
        .addValueConsumer(nameContains -> filter.setUserName(nameContains));

  }
}