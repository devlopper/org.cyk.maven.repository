package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une version de politique.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PolicyVersionDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de la politique.
   */
  @JsonbProperty(JSON_POLICY_IDENTIFIER)
  private String policyIdentifier;

  /**
   * Représentation en chaine de caractères de la politique.
   */
  @JsonbProperty(JSON_POLICY_AS_STRING)
  private String policyAsString;

  /**
   * Numéro de version.
   */
  @JsonbProperty(JSON_VERSION)
  private Integer version;

  /**
   * Date de publication.
   */
  @JsonbProperty(JSON_PUBLICATION_DATE)
  private LocalDateTime publicationDate;

  /**
   * Identifiant du fichier.
   */
  @JsonbProperty(JSON_FILE_IDENTIFIER)
  private String fileIdentifier;

  /**
   * Indique si cette version est active.
   */
  @JsonbProperty(JSON_IS_ACTIVE)
  private Boolean isActive;

  /**
   * Identifiant json pour {@link #policyIdentifier}.
   */
  public static final String JSON_POLICY_IDENTIFIER = "idPolitique";

  /**
   * Identifiant json pour {@link #policyAsString}.
   */
  public static final String JSON_POLICY_AS_STRING = "politiqueChaine";

  /**
   * Identifiant json pour {@link #version}.
   */
  public static final String JSON_VERSION = "version";

  /**
   * Identifiant json pour {@link #publicationDate}.
   */
  public static final String JSON_PUBLICATION_DATE = "datePublication";

  /**
   * Identifiant json pour {@link #fileIdentifier}.
   */
  public static final String JSON_FILE_IDENTIFIER = "idFichier";

  /**
   * Identifiant json pour {@link #isActive}.
   */
  public static final String JSON_IS_ACTIVE = "estActive";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idVersionPolitique";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "versionPolitiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "version de politique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "versions de politique";
}
