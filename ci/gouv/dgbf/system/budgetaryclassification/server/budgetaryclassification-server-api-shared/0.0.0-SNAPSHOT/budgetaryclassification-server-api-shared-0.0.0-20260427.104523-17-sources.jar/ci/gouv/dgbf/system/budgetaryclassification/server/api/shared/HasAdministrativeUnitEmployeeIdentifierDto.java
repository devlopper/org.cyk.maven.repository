package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de d'employé d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeIdentifierDto
    extends HasAdministrativeUnitEmployeeIdentifier {

  /**
   * Identifiant json de l'identifiant de l'employé de l'unité administrative.
   */
  String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER = "idEmployeUniteAdministrative";
}
