package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SalaryElementDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = SalaryElementService.PATH)
@Tag(name = "Gestion d'élément de salaire")
public interface SalaryElementService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "elements-salaire";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface SalaryElementSaveRequestDto {

    /**
     * Cette méthode me permet d'obtenir l'identifiant de {@link SalaryElementGroupDto}.
     *
     * @return identifiant de {@link SalaryElementGroupDto}
     */
    String getSalaryElementGroupIdentifier();

    /**
     * Cette méthode me permet d'assigner l'identifiant de {@link SalaryElementGroupDto}.
     *
     * @param identifier identifiant de {@link SalaryElementGroupDto}
     */
    void setSalaryElementGroupIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir vrai si c'est un gain sinon faux.
     *
     * @return vrai si c'est un gain sinon faux
     */
    Boolean getIsEarning();

    /**
     * Cette méthode permet d'assigner vrai si c'est un gain sinon faux.
     *
     * @param isEarning vrai si c'est un gain sinon faux
     */
    void setIsEarning(Boolean isEarning);
    

    /**
     * Identifiant json de {@link SalaryElementGroupDto}.
     */
    String JSON_SALARY_ELEMENT_GROUP_IDENTIFIER = SalaryElementGroupDto.JSON_THIS_IDENTIFIER;

    /**
     * {@link SalaryElementDto#JSON_IS_EARNING}.
     */
    String JSON_IS_EARNING = SalaryElementDto.JSON_IS_EARNING;
    
  } 

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ELEMENT_SALAIRE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SalaryElementCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class SalaryElementCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SalaryElementSaveRequestDto {

    @JsonbProperty(JSON_SALARY_ELEMENT_GROUP_IDENTIFIER)
    private String salaryElementGroupIdentifier;

    @JsonbProperty(JSON_IS_EARNING)
    private Boolean isEarning;
    
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ELEMENTS_SALAIRE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = 
                  SalaryElementGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class SalaryElementGetManyResponseDto extends 
                      AbstractGetByPageResponseDto<SalaryElementDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SalaryElementDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ELEMENT_SALAIRE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SalaryElementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_UN_ELEMENT_SALAIRE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SalaryElementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ELEMENT_SALAIRE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SalaryElementUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class SalaryElementUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SalaryElementSaveRequestDto {

    @JsonbProperty(JSON_SALARY_ELEMENT_GROUP_IDENTIFIER)
    private String salaryElementGroupIdentifier;

    @JsonbProperty(JSON_IS_EARNING)
    private Boolean isEarning;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ELEMENT_SALAIRE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SalaryElementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
