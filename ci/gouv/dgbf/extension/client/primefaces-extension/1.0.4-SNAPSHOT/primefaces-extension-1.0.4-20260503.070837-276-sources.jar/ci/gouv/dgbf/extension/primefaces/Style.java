package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un style.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Style {

  String value;

  Set<String> classes;

  /**
   * Cette méthode permet d'assigner des classes.
   *
   * @param classes classes
   */
  public void setClasses(String... classes) {
    if (Core.isArrayEmpty(classes)) {
      this.classes = null;
    } else {
      this.classes = Arrays.stream(classes).collect(Collectors.toSet());
    }
  }

  public String getClassesAsString() {
    return Optional.ofNullable(classes).orElse(Collections.emptySet()).stream()
        .collect(Collectors.joining(" "));
  }
  
  /**
   * Cette méthode permet d'obtenir les classes du style en une chaine de caractères.
   *
   * @return classes du style en une chaine de caractères
   */
  public static String getClassesAsString(Style style) {
    if (style == null) {
      return null;
    }
    return style.getClassesAsString();
  }

  /**
   * Cette méthode permet d'instantier {@link Builder}.
   *
   * @return {@link Builder}
   */
  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représente un constructeur de {@link Style}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {

    String value;

    Set<String> classes;

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Style}
     */
    public Style build() {
      Style style = new Style();
      style.value = value;
      style.classes = classes;
      return style;
    }

    /**
     * Cette méthode permet d'instantier {@link Builder}.
     *
     * @param value valeur
     * @param classes classes
     * @return {@link Builder}
     */
    public static Builder instantiate(String value, String... classes) {
      Builder builder = new Builder();
      builder.value = value;
      if (!Core.isArrayEmpty(classes)) {
        builder.classes = Arrays.stream(classes).collect(Collectors.toSet());
      }
      return builder;
    }
  }
}
