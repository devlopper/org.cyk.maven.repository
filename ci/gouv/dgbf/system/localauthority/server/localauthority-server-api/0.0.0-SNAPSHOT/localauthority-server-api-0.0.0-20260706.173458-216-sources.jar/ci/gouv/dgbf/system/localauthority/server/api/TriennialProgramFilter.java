package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TriennialProgramDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class TriennialProgramFilter extends AbstractIdentifiableFilter {


  /**
   * Année maximum d'exercice.
   */
  Integer maximumExerciseYear;


  /**
   * Année minimum d'exercice.
   */
  Integer minimumExerciseYear;

  /**
   * Identifiant {@link ExerciseDto}.
   */
  String exerciseIdentifier;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * {@link TriennialProgramStatus}.
   */
  TriennialProgramStatus status;


  /**
   * Variable permettant de partitionnér la liste des programmes triennaux en deux parties
   * à partir d'une année considérée comme la ligne médiane.
   */
  Boolean partitioned;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TriennialProgramFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TriennialProgramFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    exerciseIdentifier = getExerciseIdentifier(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    status = getStatus(filter);
    maximumExerciseYear = getMaximumExerciseYear(filter);
    minimumExerciseYear = getMinimumExerciseYear(filter);
    partitioned = getPartitioned(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setExerciseIdentifier(filter, exerciseIdentifier);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setStatus(filter, status);
    setMaximumExerciseYear(filter, maximumExerciseYear);
    setMinimumExerciseYear(filter, minimumExerciseYear);
    setPartitioned(filter, partitioned);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ExerciseDto}
   */
  public static String getExerciseIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ExerciseDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link ExerciseDto}
   */
  public static void setExerciseIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXERCISE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner le {@link TriennialProgramStatus}.
   *
   * @param filter filtre
   * @param status {@link TriennialProgramStatus}
   */
  public static void setStatus(FilterDto filter, TriennialProgramStatus status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsEnum(status));
  }

  /**
   * Cette méthode permet d'obtenir le {@link TriennialProgramStatus}.
   *
   * @param filter filtre
   * @return {@link TriennialProgramStatus}
   */
  public static TriennialProgramStatus getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_STATUS, TriennialProgramStatus.class));
  }


  /**
   * Cette méthode permet d'obtenir l'année maximale de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return l'année maximale {@link ExerciseDto}
   */
  public static Integer getMaximumExerciseYear(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_MAXIMUM_EXERCICE_YEAR));
  }


  /**
   * Cette méthode permet d'assigner l'année maximale de {@link ExerciseDto}.
   *
   * @param filter              filtre
   * @param maximumExerciseYear année maximal de  {@link ExerciseDto}
   */
  public static void setMaximumExerciseYear(FilterDto filter, Integer maximumExerciseYear) {
    set(filter, JSON_MAXIMUM_EXERCICE_YEAR, f -> f.getValueAsInteger(),
        f -> f.setValueAsInteger(maximumExerciseYear));
  }

  /**
   * Cette méthode permet d'obtenir l'année maximale de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return l'année minimal {@link ExerciseDto}
   */
  public static Integer getMinimumExerciseYear(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_MINIMUM_EXERCICE_YEAR));
  }


  /**
   * Cette méthode permet d'assigner l'année minimale de {@link ExerciseDto}.
   *
   * @param filter              filtre
   * @param minimumExerciseYear année minimale de  {@link ExerciseDto}
   */
  public static void setMinimumExerciseYear(FilterDto filter, Integer minimumExerciseYear) {
    set(filter, JSON_MINIMUM_EXERCICE_YEAR, f -> f.getValueAsInteger(),
        f -> f.setValueAsInteger(minimumExerciseYear));
  }


  /**
   * Cette méthode permet d'obtenir la variable de partitionnement.
   *
   * @param filter              filtre
   * @return la valeur de la variable de {@link #partitioned}
   */
  public static Boolean getPartitioned(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_PARTITIONED));
  }



  /**
   * Cette méthode permet d'assigner la valeur de  {@link #partitioned}.
   *
   * @param filter              filtre
   * @param partitionned variable de partionnement
   */
  public static void setPartitioned(FilterDto filter, Boolean partitionned) {
    set(filter, JSON_PARTITIONED, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(partitionned));
  }


  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER =
      TriennialProgramDto.JSON_EXERCISE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      TriennialProgramDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = TriennialProgramDto.JSON_STATUS;

  /**
   * Identifiant json champ {@link #maximumExerciseYear}.
   */
  public static final String JSON_MAXIMUM_EXERCICE_YEAR = "anneeExerciceMaximal";


  /**
   * Identifiant json champ {@link #minimumExerciseYear}.
   */
  public static final String JSON_MINIMUM_EXERCICE_YEAR = "anneeExerciceMinimum";


  /**
   * Identifiant json champ {@link #partitioned}.
   */
  public static final String JSON_PARTITIONED = "estPartitionne";
}
