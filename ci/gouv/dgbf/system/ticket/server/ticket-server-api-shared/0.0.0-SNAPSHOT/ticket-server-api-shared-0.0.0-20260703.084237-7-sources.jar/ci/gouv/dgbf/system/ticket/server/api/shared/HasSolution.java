package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de solution.
 *
 * @author Christian
 */
public interface HasSolution extends HasField {

  /**
   * Cette méthode permet d'obtenir la solution.
   *
   * @return la solution
   */
  String getSolution();
  
  /**
   * Cette méthode permet d'assigner la solution.
   *
   * @param solution la solution
   */
  void setSolution(String solution);
  
  /**
   * Identifiant java de la solution.
   */
  String FIELD_SOLUTION = "solution";
}
