package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de fichier.
 *
 * @author Christian
 *
 */
public interface FileContainerable {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de fichier.
   *
   * @return représentation en chaine de caractères du nombre de fichier
   */
  String getFileCountAsString();

  /**
   * Identifiant json {@link FileContainerable#getFileCountAsString()}.
   */
  String FIELD_FILE_COUNT_AS_STRING = "fileCountAsString";
}
