package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenCreateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TokenDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TokenDto}.

    @author Christian
               """)
public interface TokenRequestMapper
    extends RequestMapper<TokenDto, TokenCreateRequestDto, TokenCreateRequestDto> {

}
