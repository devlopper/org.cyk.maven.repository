package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de mail.
 *
 * @author Christian
 */
public interface HasMailAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du mail.
   *
   * @return représentation en chaine de caractères du mail
   */
  String getMailAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du mail.
   *
   * @param asString représentation en chaine de caractères du mail
   */
  void setMailAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du mail.
   */
  String FIELD_MAIL_AS_STRING = "mailAsString";
}
