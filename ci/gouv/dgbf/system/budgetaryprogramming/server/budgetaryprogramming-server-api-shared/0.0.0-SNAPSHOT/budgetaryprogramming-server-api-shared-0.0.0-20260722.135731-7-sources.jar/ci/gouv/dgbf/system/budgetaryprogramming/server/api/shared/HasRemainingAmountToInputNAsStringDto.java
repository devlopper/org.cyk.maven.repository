package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputNAsStringDto extends HasRemainingAmountToInputNAsString {

  /**
   * Identifiant json du montant restant à saisir pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N_AS_STRING = "montantResteASaisirNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
