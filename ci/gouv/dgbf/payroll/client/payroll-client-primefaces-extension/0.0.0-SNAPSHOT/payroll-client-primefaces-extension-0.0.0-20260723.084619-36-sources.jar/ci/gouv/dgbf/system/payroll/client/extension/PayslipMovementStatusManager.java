package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Map;

/**
 * Cette classe représente le gestionnaire de {@link PayslipMovementStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class PayslipMovementStatusManager extends AbstractStatusManager<PayslipMovementStatus> {

  /**
   * Cette méthode permet d'instanctier.
   */
  public PayslipMovementStatusManager() {
    super(PayslipMovementStatus.class, e -> e.getName());
    severityMap = Map.of(PayslipMovementStatus.ACTIVATED, "success", PayslipMovementStatus.DEFERRED,
        "warning", PayslipMovementStatus.DEFERRED_PROPOSED, "warning",
        PayslipMovementStatus.REJECTED, "danger", PayslipMovementStatus.REJECTION_PROPOSED,
        "danger");
  }
}
