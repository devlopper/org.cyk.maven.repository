package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryService.DictionaryCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryService.DictionaryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DictionaryDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DictionaryDto}.
    
    @author Desysoft
    """)
public interface DictionaryRequestMapper
    extends RequestMapper<DictionaryDto, DictionaryCreateRequestDto, DictionaryUpdateRequestDto> {

}

