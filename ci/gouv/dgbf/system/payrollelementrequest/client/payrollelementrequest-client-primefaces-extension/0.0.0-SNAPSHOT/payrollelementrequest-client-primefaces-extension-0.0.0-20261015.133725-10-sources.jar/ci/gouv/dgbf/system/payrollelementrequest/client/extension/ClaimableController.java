package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.TypeIdentifierFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueService.ClaimableValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueSaveRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de choix des Éléments de Paie/Constantes de Paie
 * concernés par une réclamation, en Mode de Saisie FAE, avec leur nouvelle valeur (RG_REP_CIB_01
 * à 03, RG_REP_SOU_01). Le FAE ne raisonne pas en Réclamables de Type de Réclamation techniques :
 * chaque ligne porte le libellé métier du Réclamable (résolu via {@code TA_RECLAMABLE},
 * RG_REP_CIB_07) et le simple fait d'y renseigner une valeur vaut choix -- pas de case à cocher
 * séparée. La Date d'effet est unique pour tout le formulaire (RG_REP_CIB_02/03, les Constantes
 * n'en ont pas). Les Éléments et Constantes concernés partagent une seule {@link ClaimedValueDto}.
 *
 * @author akm
 *
 */
@Dependent
public class ClaimableController extends AbstractController {

  @Inject
  ClaimTypeClaimableClient claimTypeClaimableClient;

  @Inject
  ClaimableValueClient claimableValueClient;

  @Inject
  ClaimedValueClient claimedValueClient;

  @Getter
  List<ConcernedClaimable> concernedClaimables;

  /**
   * Tableau des mouvements intermédiaires (RG_REP_SOU_20) : une colonne par Cible éligible du Type,
   * une ligne par date antérieure à la situation actuelle.
   */
  @Getter
  HistoryTable history;

  /**
   * Valeurs Réclamées de périodes retirées de l'historique, à supprimer à la prochaine
   * synchronisation.
   */
  List<String> removedValueIdentifiers;

  /**
   * Mode <em>rétention</em> (RG_REP_PEC_11) : quand {@code true}, {@link #loadExistingValues} lit
   * et {@link #syncValues} écrit le jeu <em>retenu</em> de la Valeur Réclamée (déterminé ou
   * corrigé par l'Agent de Traitement pendant la Prise en charge), et non la saisie du FAE,
   * laissée intacte. En Mode Agent, toujours {@code true} (détermination, RG_REP_PEC_09) ; pour
   * les Cibles FAE, activé seulement quand la réclamation est Prise en charge et que l'Agent la
   * corrige.
   */
  @Getter
  @Setter
  boolean retentionMode;

  /**
   * Cette méthode permet de constuire.
   */
  public ClaimableController() {
    concernedClaimables = new ArrayList<>();
    history = new HistoryTable();
    removedValueIdentifiers = new ArrayList<>();
  }

  /**
   * Cette méthode permet de rafraichir la liste des Réclamables de Type de Réclamation en Mode de
   * Saisie FAE pour le Type de Réclamation choisi -- délègue à {@link #refresh(String, String)},
   * ceux en Mode Agent n'étant ni affichés ni demandés ici (cf.
   * {@code AbstractPayrollElementClaimReadDatasPage#agentModeClaimableController}, une instance
   * distincte de ce même contrôleur pour la Détermination Mode Agent, RG_REP_PEC_09).
   *
   * @param typeIdentifier identifiant du Type de Réclamation
   */
  public void refresh(String typeIdentifier) {
    refresh(typeIdentifier, ValueInputModeSelectOneController.VALUE_FAE);
  }

  /**
   * Cette méthode permet de rafraichir la liste des Réclamables de Type de Réclamation d'un Mode
   * de Saisie donné pour le Type de Réclamation choisi (RG_REP_CIB_01/04/05). Triés par ordre
   * d'affichage explicite (RG_REP_CIB_01), configuré par l'administrateur, plutôt que l'ordre de
   * retour du service, non garanti.
   *
   * @param typeIdentifier identifiant du Type de Réclamation
   * @param valueInputMode Mode de Saisie à charger ({@link
   *        ValueInputModeSelectOneController#VALUE_FAE} ou
   *        {@link ValueInputModeSelectOneController#VALUE_AGENT})
   */
  public void refresh(String typeIdentifier, String valueInputMode) {
    concernedClaimables.clear();
    history = new HistoryTable();
    removedValueIdentifiers.clear();
    if (typeIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_NATURE, ClaimTypeClaimableDto.JSON_CLAIMABLE_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_CLAIMABLE_AS_STRING, ClaimTypeClaimableDto.JSON_CLAIMABLE_CODE,
        ClaimTypeClaimableDto.JSON_VALUE_INPUT_MODE, ClaimTypeClaimableDto.JSON_MOVEMENT_NATURE,
        ClaimTypeClaimableDto.JSON_RANK, ClaimTypeClaimableDto.JSON_MANDATORY_FOR_FAE,
        ClaimTypeClaimableDto.JSON_WITH_HISTORY);
    FilterDto filter = new FilterDto().addCriteria(TypeIdentifierFilter.JSON_KEY, typeIdentifier);
    ClaimTypeClaimableGetManyResponseDto response =
        claimTypeClaimableClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().stream()
        .filter(target -> valueInputMode.equals(target.getValueInputMode()))
        .forEach(target -> {
          ConcernedClaimable concernedClaimable = new ConcernedClaimable(target.getIdentifier(),
              target.getNature(), target.getClaimableIdentifier());
          concernedClaimable.setObjectLabel(target.getClaimableAsString() == null
              ? target.getClaimableIdentifier() : target.getClaimableAsString());
          concernedClaimable.setClaimableCode(target.getClaimableCode());
          concernedClaimable.setMovementNature(target.getMovementNature());
          concernedClaimable.setRank(target.getRank());
          concernedClaimable.setHistoryEligible(isHistoryEligible(target));
          // Défaut true si absent (rétro-compatibilité d'une projection qui ne le demanderait
          // pas) -- cohérent avec le défaut serveur (RG_REP_CIB_10).
          concernedClaimable.setMandatoryForFae(
              target.getMandatoryForFae() == null ? Boolean.TRUE : target.getMandatoryForFae());
          if (ELEMENT_PAIE.equals(target.getNature())) {
            Map<String, String> instanceCodes = new LinkedHashMap<>();
            concernedClaimable.setInstanceOptions(
                instanceOptionsOf(target.getClaimableIdentifier(), instanceCodes));
            concernedClaimable.setInstanceCodes(instanceCodes);
          }
          concernedClaimables.add(concernedClaimable);
        });
    concernedClaimables.sort(Comparator.comparing(ConcernedClaimable::getRank,
        Comparator.nullsLast(Integer::compareTo)));
    buildHistory();
    ensureRow();
  }

  /**
   * Cette méthode permet de savoir si une Cible est éligible à l'historique (RG_REP_SOU_20) : un
   * Élément de Paie, en Mode de Saisie FAE, de Nature de Mouvement Création ou Modification, non
   * dont la saisie d'historique est autorisée.
   *
   * @param target Cible de Type de Réclamation
   * @return {@code true} si la Cible est éligible
   */
  private static boolean isHistoryEligible(ClaimTypeClaimableDto target) {
    boolean creationOrModification =
        MovementNatureSelectOneController.VALUE_CREATION.equals(target.getMovementNature())
            || MovementNatureSelectOneController.VALUE_MODIFICATION
                .equals(target.getMovementNature());
    return ELEMENT_PAIE.equals(target.getNature())
        && ValueInputModeSelectOneController.VALUE_FAE.equals(target.getValueInputMode())
        && creationOrModification && Boolean.TRUE.equals(target.getWithHistory());
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Élément de Paie (RG_REP_CIB_01).
   *
   * @return les Cibles de nature Élément de Paie
   */
  public List<ConcernedClaimable> getElementTargets() {
    return concernedClaimables.stream().filter(target -> ELEMENT_PAIE.equals(target.getNature()))
        .toList();
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Constante de Paie -- voir
   * {@link #getElementTargets()}.
   *
   * @return les Cibles de nature Constante de Paie
   */
  public List<ConcernedClaimable> getConstantTargets() {
    return concernedClaimables.stream()
        .filter(target -> CONSTANTE_PAIE.equals(target.getNature())).toList();
  }

  /**
   * Cette méthode permet d'obtenir les Cibles Élément de Paie saisies par des champs, chacune avec
   * sa propre date d'effet, c'est-à-dire non éligibles à l'historique (RG_REP_SOU_20).
   *
   * @return les Cibles Élément de Paie hors tableau
   */
  public List<ConcernedClaimable> getFieldElementTargets() {
    return getElementTargets().stream().filter(target -> !target.isHistoryEligible()).toList();
  }

  /**
   * Cette méthode permet de savoir si au moins une Cible Élément de Paie est saisie par des
   * champs.
   *
   * @return {@code true} si au moins une Cible Élément de Paie est hors tableau
   */
  public boolean hasFieldElementTargets() {
    return !getFieldElementTargets().isEmpty();
  }

  /**
   * Cette méthode permet d'obtenir la Date d'effet à afficher pour la Réclamation : la plus
   * récente parmi celles des champs et des mouvements du tableau (RG_REP_SOU_20).
   *
   * @return la date, ou {@code null} si aucune n'est saisie
   */
  public LocalDate getEffectiveDateForDisplay() {
    return Stream
        .concat(
            getFieldElementTargets().stream().filter(ConcernedClaimable::isConcerned)
                .map(ConcernedClaimable::getEffectiveDate),
            history.getRows().stream().filter(PeriodRow::isFilled)
                .map(PeriodRow::getEffectiveDate))
        .filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null);
  }

  /**
   * Cette méthode permet de savoir si la liste contient au moins une Cible Élément de Paie --
   * détermine si le champ Date d'effet (partagé, sans objet pour les Constantes seules) doit être
   * affiché.
   *
   * @return {@code true} si au moins une Cible est un Élément de Paie
   */
  public boolean hasElementTargets() {
    return concernedClaimables.stream()
        .anyMatch(target -> ELEMENT_PAIE.equals(target.getNature()));
  }

  /**
   * Nature Élément de Paie.
   */
  public static final String ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Nature Constante de Paie.
   */
  public static final String CONSTANTE_PAIE = "CONSTANTE_PAIE";

  /**
   * Type de {@link ConcernedClaimable#getValue()} pour la Valeur Réclamée d'une Constante de
   * Paie -- les montants saisis dans ce formulaire sont toujours décimaux ({@code ValueType},
   * {@code core-extension}).
   */
  private static final String VALUE_TYPE_FLOAT = "FLOAT";

  /**
   * Cette méthode permet d'obtenir les instances possibles d'un Élément de Paie, à partir de
   * l'identifiant de son {@code TA_RECLAMABLE} -- résolues via {@code TA_VALEUR_RECLAMABLE}
   * (synchronisées depuis {@code payroll} au même titre que les Éléments/Constantes eux-mêmes,
   * RG_REP_CIB_07), sans appel synchrone au module {@code payroll}.
   *
   * @param elementClaimableIdentifier identifiant {@code TA_RECLAMABLE} de l'Élément de Paie
   * @param instanceCodes rempli, en sortie, du code court de chaque instance retournée (clé
   *        {@link ClaimableValueDto#getIdentifier()}, valeur {@link ClaimableValueDto#getCode()})
   *        -- permet à l'appelant (qui seul connaît la structure du fonctionnaire) de faire
   *        correspondre ces options aux valeurs actuellement actives (RG_REP_IMP_01), sans
   *        second appel réseau
   * @return les instances possibles, en options de sélection
   */
  private List<SelectItem> instanceOptionsOf(String elementClaimableIdentifier,
      Map<String, String> instanceCodes) {
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimableValueDto.JSON_LABEL, ClaimableValueDto.JSON_CODE);
    FilterDto filter = new FilterDto();
    ClaimableValueFilter.setClaimableIdentifier(filter, elementClaimableIdentifier);
    ClaimableValueGetManyResponseDto response;
    try {
      response = claimableValueClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des instances de l'Élément de Paie " + elementClaimableIdentifier
              + " en échec.",
          exception);
      return List.of();
    }
    if (response == null || response.getDatas() == null) {
      return List.of();
    }
    response.getDatas().forEach(
        instance -> instanceCodes.put(instance.getIdentifier(), instance.getCode()));
    return response.getDatas().stream()
        .map(instance -> new SelectItem(instance.getIdentifier(), instance.getLabel())).toList();
  }

  /**
   * Cette méthode permet d'obtenir une instance d'Élément de Paie à partir de son identifiant
   * {@code TA_VALEUR_RECLAMABLE} -- résolue sans appel synchrone au module {@code payroll}
   * (RG_REP_CIB_07).
   *
   * @param instanceIdentifier identifiant {@code TA_VALEUR_RECLAMABLE} de l'instance
   * @return l'instance, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private ClaimableValueDto resolveClaimableValue(String instanceIdentifier) {
    if (instanceIdentifier == null || instanceIdentifier.isBlank()) {
      return null;
    }
    ProjectionDto projection = new ProjectionDto()
        .addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, ClaimableValueDto.JSON_LABEL);
    try {
      return claimableValueClient.getByIdentifier(instanceIdentifier, projection, userIdentifier,
          null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention de l'instance " + instanceIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de compléter la liste des Cibles concernées (déjà rafraîchie via
   * {@link #refresh(String)}) avec les Valeurs Réclamées déjà enregistrées pour une réclamation
   * existante -- utilisé à l'ouverture d'une réclamation existante en modification.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void loadExistingValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimedValueDto.JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER, ClaimedValueDto.JSON_NATURE,
        ClaimedValueDto.JSON_CLAIMABLE_VALUE_IDENTIFIER, ClaimedValueDto.JSON_EFFECTIVE_DATE,
        ClaimedValueDto.JSON_VALUE, ClaimedValueDto.JSON_RETAINED_CLAIMABLE_VALUE_IDENTIFIER,
        ClaimedValueDto.JSON_RETAINED_EFFECTIVE_DATE, ClaimedValueDto.JSON_RETAINED_VALUE,
        ClaimedValueDto.JSON_CORRECTED_BY, ClaimedValueDto.JSON_ADDED_BY);
    FilterDto filter =
        new FilterDto().addCriteria(ClaimedValueFilter.JSON_CLAIM_IDENTIFIER, claimIdentifier);
    ClaimedValueGetManyResponseDto response =
        claimedValueClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    Map<String, List<ClaimedValueDto>> valuesByTarget = new LinkedHashMap<>();
    response.getDatas().forEach(value -> valuesByTarget
        .computeIfAbsent(value.getClaimTypeClaimableIdentifier(), key -> new ArrayList<>())
        .add(value));
    // Une Cible dont la configuration n'autorise plus l'historique mais qui en porte un déjà saisi
    // reste dans le tableau : la configuration ne fait jamais perdre à l'écran des valeurs
    // enregistrées.
    valuesByTarget.forEach((targetIdentifier, values) -> concernedClaimables.stream()
        .filter(target -> target.getClaimTypeClaimableIdentifier().equals(targetIdentifier)
            && ELEMENT_PAIE.equals(target.getNature()) && !target.isHistoryEligible()
            && values.size() > 1)
        .findFirst().ifPresent(target -> target.setHistoryEligible(true)));
    history.getTargets().clear();
    buildHistory();
    history.getRows().removeIf(PeriodRow::isBlank);
    valuesByTarget.forEach((targetIdentifier, values) -> concernedClaimables.stream()
        .filter(target -> target.getClaimTypeClaimableIdentifier().equals(targetIdentifier))
        .findFirst().ifPresent(target -> loadTargetValues(target, values)));
    history.getRows().sort(Comparator.comparing(PeriodRow::getEffectiveDate,
        Comparator.nullsLast(Comparator.naturalOrder())));
    ensureRow();
  }

  /**
   * Cette méthode permet de garder au moins une ligne dans le tableau des mouvements dès que le
   * Type a une Cible éligible : le FAE n'a jamais à demander la première ligne.
   */
  private void ensureRow() {
    if (hasHistoryTargets() && history.getRows().isEmpty()) {
      history.getRows().add(new PeriodRow());
    }
  }

  /**
   * Cette méthode permet d'obtenir le libellé de la valeur actuelle d'une Cible quand elle est
   * unique, pour la première ligne du tableau.
   *
   * @param target Cible (colonne du tableau)
   * @return libellé de la valeur active, ou {@code null} si elle n'est pas unique
   */
  public String currentValueLabel(ConcernedClaimable target) {
    return target.getCurrentValueOptions().size() == 1
        ? target.getCurrentValueOptions().get(0).getLabel() : null;
  }

  /**
   * Cette méthode permet de charger les Valeurs Réclamées d'une Cible : la plus récente alimente
   * la valeur de la Cible saisie par champs ; pour une Cible éligible, toutes les valeurs sont des
   * lignes du tableau des mouvements (RG_REP_SOU_20).
   *
   * @param target Cible concernée
   * @param values Valeurs Réclamées de cette Cible
   */
  private void loadTargetValues(ConcernedClaimable target, List<ClaimedValueDto> values) {
    List<ClaimedValueDto> sorted = values.stream().sorted(Comparator.comparing(
        this::effectiveDate, Comparator.nullsFirst(Comparator.naturalOrder()))).toList();
    if (target.isHistoryEligible()) {
      sorted.forEach(value -> loadPeriod(target, value));
    } else {
      loadCurrentValue(target, sorted.get(sorted.size() - 1));
    }
  }

  private void loadPeriod(ConcernedClaimable target, ClaimedValueDto value) {
    PeriodRow row = history.rowOf(effectiveDate(value));
    row.getValueByTarget().put(target.getClaimTypeClaimableIdentifier(),
        effectiveClaimableValueIdentifier(value));
    row.getIdentifierByTarget().put(target.getClaimTypeClaimableIdentifier(),
        value.getIdentifier());
    row.addedByAgent |= value.getAddedBy() != null;
    row.corrected |= value.getCorrectedBy() != null;
    row.fromFae |= value.getAddedBy() == null;
  }

  /**
   * Cette méthode permet de savoir si une ligne de l'historique peut être retirée : en mode
   * rétention, l'Agent ne retire pas une période saisie par le FAE (il la corrige), seulement
   * celles qu'il a lui-même ajoutées (RG_REP_PEC_12).
   *
   * @param row ligne de l'historique
   * @return {@code true} si la ligne peut être retirée
   */
  public boolean isRemovable(PeriodRow row) {
    return !(retentionMode && row.isFromFae());
  }

  private void loadCurrentValue(ConcernedClaimable target, ClaimedValueDto value) {
    target.setValueIdentifier(value.getIdentifier());
    target.setCorrectedBy(value.getCorrectedBy());
    target.setAddedBy(value.getAddedBy());
    if (ELEMENT_PAIE.equals(value.getNature())) {
      String claimableValueIdentifier = effectiveClaimableValueIdentifier(value);
      target.setClaimableValueIdentifier(claimableValueIdentifier);
      // En Suppression, la valeur retirée est portée par le champ « actuel » : sans cette
      // reprise, le champ relu reste vide alors que la valeur est enregistrée.
      if (target.isDeletionNature()) {
        target.setSelectedCurrentValueIdentifier(claimableValueIdentifier);
      }
      ClaimableValueDto instance = resolveClaimableValue(claimableValueIdentifier);
      target.setInstanceLabel(instance == null ? claimableValueIdentifier : instance.getLabel());
      target.setEffectiveDate(effectiveDate(value));
    } else if (CONSTANTE_PAIE.equals(value.getNature())) {
      String rawValue = effectiveValue(value);
      target.setValue(rawValue == null ? null : new BigDecimal(rawValue));
    }
  }

  private String effectiveClaimableValueIdentifier(ClaimedValueDto value) {
    return retentionMode && value.getRetainedClaimableValueIdentifier() != null
        ? value.getRetainedClaimableValueIdentifier() : value.getClaimableValueIdentifier();
  }

  private LocalDate effectiveDate(ClaimedValueDto value) {
    return retentionMode && value.getRetainedEffectiveDate() != null
        ? value.getRetainedEffectiveDate() : value.getEffectiveDate();
  }

  private String effectiveValue(ClaimedValueDto value) {
    return retentionMode && value.getRetainedValue() != null ? value.getRetainedValue()
        : value.getValue();
  }

  /**
   * Cette méthode permet de synchroniser les Valeurs Réclamées des Cibles concernées avec l'état
   * courant de la liste (valeur renseignée/vidée par l'utilisateur) : création de celles
   * nouvellement renseignées, mise à jour de celles dont la valeur a changé, et suppression de
   * celles vidées (RG_REP_CIB_02/03) -- utilisée aussi bien à la Création (aucune Cible n'a
   * encore de {@code valueIdentifier}, le comportement se réduit alors à une simple création) qu'à
   * la Modification d'une réclamation existante.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void syncValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    concernedClaimables.forEach(target -> {
      if (ELEMENT_PAIE.equals(target.getNature())) {
        syncElementValue(claimIdentifier, target);
      } else if (CONSTANTE_PAIE.equals(target.getNature())) {
        syncConstantValue(claimIdentifier, target);
      }
    });
    syncHistory(claimIdentifier);
  }

  /**
   * Cette méthode permet de synchroniser l'historique des périodes antérieures (RG_REP_SOU_20) :
   * suppression des périodes retirées, puis création, mise à jour ou suppression de chaque valeur
   * de chaque ligne selon qu'elle est nouvellement renseignée, modifiée ou vidée.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  private void syncHistory(String claimIdentifier) {
    removedValueIdentifiers.forEach(
        identifier -> claimedValueClient.deleteByIdentifier(identifier, userIdentifier, null));
    removedValueIdentifiers.clear();
    history.getRows().forEach(row -> history.getTargets()
        .forEach(target -> syncPeriodValue(claimIdentifier, row, target)));
  }

  private void syncPeriodValue(String claimIdentifier, PeriodRow row,
      ConcernedClaimable target) {
    String targetIdentifier = target.getClaimTypeClaimableIdentifier();
    String claimableValueIdentifier = row.getValueByTarget().get(targetIdentifier);
    boolean filled = claimableValueIdentifier != null && !claimableValueIdentifier.isBlank();
    String valueIdentifier = row.getIdentifierByTarget().get(targetIdentifier);
    if (valueIdentifier != null && !filled) {
      claimedValueClient.deleteByIdentifier(valueIdentifier, userIdentifier, null);
      row.getIdentifierByTarget().remove(targetIdentifier);
    } else if (filled && valueIdentifier == null) {
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(targetIdentifier);
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, claimableValueIdentifier, row.getEffectiveDate());
      request.setAuditWho(userIdentifier);
      row.getIdentifierByTarget().put(targetIdentifier,
          claimedValueClient.create(request).getIdentifier());
    } else if (filled) {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(valueIdentifier);
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(targetIdentifier);
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, claimableValueIdentifier, row.getEffectiveDate());
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  /**
   * Cette méthode permet de contrôler le tableau des mouvements avant tout enregistrement
   * (RG_REP_SOU_21) : une ligne renseignée porte une date, une ligne datée porte au moins une
   * valeur, deux mouvements d'une même Cible n'ont pas la même date, une Cible obligatoire porte
   * au moins une valeur, et une Cible qui porte une valeur alors que plusieurs mouvements sont
   * actifs a sa valeur actuelle choisie.
   *
   * @return les anomalies relevées, vide si le tableau est acceptable
   */
  public List<String> validateHistory() {
    List<String> errors = new ArrayList<>();
    if (history.getRows().stream()
        .anyMatch(row -> row.isFilled() && row.getEffectiveDate() == null)) {
      errors.add("Un mouvement renseigné n'a pas de date d'effet");
    }
    history.getRows().stream().filter(row -> row.getEffectiveDate() != null && !row.isFilled())
        .forEach(row -> errors.add("Le mouvement du "
            + row.getEffectiveDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
            + " ne change aucune valeur : choisissez une valeur ou supprimez la ligne"));
    getFieldElementTargets().stream()
        .filter(target -> target.isConcerned() && target.getEffectiveDate() == null)
        .forEach(target -> errors.add("La date d'effet de « " + target.getObjectLabel()
            + " » est obligatoire"));
    history.getTargets().forEach(target -> {
      String identifier = target.getClaimTypeClaimableIdentifier();
      Set<LocalDate> dates = new HashSet<>();
      boolean hasValue = false;
      for (PeriodRow row : history.getRows()) {
        String value = row.getValueByTarget().get(identifier);
        if (value == null || value.isBlank()) {
          continue;
        }
        hasValue = true;
        if (row.getEffectiveDate() != null && !dates.add(row.getEffectiveDate())) {
          errors.add("Deux mouvements de « " + target.getObjectLabel() + " » ont la même date : "
              + row.getEffectiveDate());
        }
      }
      for (PeriodRow row : history.getRows()) {
        String value = row.getValueByTarget().get(identifier);
        if (row.getEffectiveDate() != null && value != null && !value.isBlank()
            && redundantValues(row, target).contains(value)) {
          errors.add("La valeur de « " + target.getObjectLabel() + " » du "
              + row.getEffectiveDate().format(DateTimeFormatter.ofPattern("dd/MM/yyyy"))
              + " est identique à la situation précédente : choisissez une autre valeur ou "
              + "supprimez la ligne");
        }
      }
      if (!hasValue && !Boolean.FALSE.equals(target.getMandatoryForFae())) {
        errors.add("« " + target.getObjectLabel()
            + " » est obligatoire : renseignez au moins une valeur dans le tableau");
      }
      if (hasValue && target.isCurrentValueSelectionRendered()
          && target.getSelectedCurrentValueIdentifier() == null) {
        errors.add("Choisissez la valeur actuelle de « " + target.getObjectLabel() + " »");
      }
    });
    return errors;
  }

  /**
   * Cette méthode permet d'obtenir les valeurs qui ne changeraient rien pour une Cible sur une
   * ligne du tableau (RG_REP_SOU_21) : celle de la ligne datée la plus proche avant celle-ci, ou,
   * à défaut, celles de la situation de départ. Une ligne sans date n'est comparée qu'à la
   * situation de départ.
   *
   * @param row ligne du tableau
   * @param target Cible (colonne du tableau)
   * @return identifiants des valeurs sans effet, vide si rien n'est à remplacer
   */
  private Set<String> redundantValues(PeriodRow row, ConcernedClaimable target) {
    String identifier = target.getClaimTypeClaimableIdentifier();
    LocalDate date = row.getEffectiveDate();
    Optional<PeriodRow> previous = date == null ? Optional.empty()
        : history.getRows().stream()
            .filter(other -> other != row && other.getEffectiveDate() != null
                && other.getEffectiveDate().isBefore(date)
                && isSet(other.getValueByTarget().get(identifier)))
            .max(Comparator.comparing(PeriodRow::getEffectiveDate));
    if (previous.isPresent()) {
      return Set.of(previous.get().getValueByTarget().get(identifier));
    }
    return target.getCurrentValueOptions().stream().map(option -> (String) option.getValue())
        .collect(Collectors.toSet());
  }

  private static boolean isSet(String value) {
    return value != null && !value.isBlank();
  }

  /**
   * Cette méthode permet d'obtenir les valeurs proposées à une ligne du tableau pour une Cible :
   * celles de la Cible, sans celles qui ne changeraient rien par rapport à la situation
   * précédente (RG_REP_SOU_21). La valeur déjà choisie sur la ligne reste proposée, pour qu'une
   * ligne enregistrée dont la situation de départ a changé ne soit pas rejetée sans explication ;
   * le contrôle de {@link #validateHistory()} la signale alors.
   *
   * @param row ligne du tableau
   * @param target Cible (colonne du tableau)
   * @return valeurs proposées
   */
  public List<SelectItem> periodOptions(PeriodRow row, ConcernedClaimable target) {
    Set<String> redundant = redundantValues(row, target);
    String selected = row.getValueByTarget().get(target.getClaimTypeClaimableIdentifier());
    return target.getInstanceOptions().stream()
        .filter(option -> !redundant.contains(option.getValue())
            || option.getValue().equals(selected))
        .toList();
  }

  /**
   * Cette méthode permet de savoir si le tableau contient au moins une ligne renseignée.
   *
   * @return {@code true} si une ligne est renseignée
   */
  public boolean hasHistory() {
    return history.getRows().stream().anyMatch(row -> !row.isBlank());
  }

  /**
   * Cette méthode permet de savoir si le Type a au moins une Cible éligible à l'historique : le
   * tiroir n'est affiché que dans ce cas (RG_REP_SOU_20).
   *
   * @return {@code true} si le tableau a au moins une colonne
   */
  public boolean hasHistoryTargets() {
    return !history.getTargets().isEmpty();
  }

  /**
   * Cette méthode permet d'obtenir le libellé de la valeur d'une Cible sur une ligne de
   * l'historique, pour l'affichage en lecture.
   *
   * @param row ligne de l'historique
   * @param target Cible (colonne du tableau)
   * @return libellé de la valeur, ou un tiret quand la Cible est inchangée à cette date
   */
  public String periodLabel(PeriodRow row, ConcernedClaimable target) {
    String valueIdentifier = row.getValueByTarget().get(target.getClaimTypeClaimableIdentifier());
    if (valueIdentifier == null || valueIdentifier.isBlank()) {
      return "—";
    }
    return target.getInstanceOptions().stream()
        .filter(option -> valueIdentifier.equals(option.getValue())).map(SelectItem::getLabel)
        .findFirst().orElse(valueIdentifier);
  }

  private void buildHistory() {
    getElementTargets().stream().filter(ConcernedClaimable::isHistoryEligible)
        .forEach(target -> history.getTargets().add(target));
  }

  /**
   * Cette méthode permet d'ajouter une ligne vide aux mouvements intermédiaires.
   */
  public void addPeriod() {
    history.getRows().add(new PeriodRow());
  }

  /**
   * Cette méthode permet de retirer une ligne des mouvements intermédiaires ; les valeurs déjà
   * enregistrées de cette ligne seront supprimées à la prochaine synchronisation.
   *
   * @param row ligne retirée
   */
  public void removePeriod(PeriodRow row) {
    removedValueIdentifiers.addAll(row.getIdentifierByTarget().values());
    history.getRows().remove(row);
    ensureRow();
  }

  private void syncElementValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, target);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, target);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  private void syncConstantValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      applyConstantValue(request, target);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      applyConstantValue(request, target);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  /**
   * Cette méthode permet de porter la valeur d'un Élément de Paie sur la requête : dans le jeu
   * <em>retenu</em> en mode rétention (RG_REP_PEC_11), dans la saisie FAE sinon (RG_REP_CIB_02).
   *
   * @param request requête de création ou de mise à jour
   * @param target Cible concernée
   */
  private void applyElementValue(ClaimedValueSaveRequestDto request, ConcernedClaimable target) {
    applyElementValue(request, target.getEffectiveClaimableValueIdentifier(),
        target.getEffectiveDate());
  }

  private void applyElementValue(ClaimedValueSaveRequestDto request,
      String claimableValueIdentifier, LocalDate effectiveDate) {
    if (retentionMode) {
      request.setRetainedClaimableValueIdentifier(claimableValueIdentifier);
      request.setRetainedEffectiveDate(effectiveDate);
    } else {
      request.setClaimableValueIdentifier(claimableValueIdentifier);
      request.setEffectiveDate(effectiveDate);
    }
  }

  /**
   * Cette méthode permet de porter la valeur d'une Constante de Paie sur la requête -- voir
   * {@link #applyElementValue(ClaimedValueSaveRequestDto, ConcernedClaimable)} (RG_REP_CIB_03).
   *
   * @param request requête de création ou de mise à jour
   * @param target Cible concernée
   */
  private void applyConstantValue(ClaimedValueSaveRequestDto request, ConcernedClaimable target) {
    if (retentionMode) {
      request.setRetainedValue(target.getValue().toString());
      request.setRetainedValueType(VALUE_TYPE_FLOAT);
    } else {
      request.setValue(target.getValue().toString());
      request.setValueType(VALUE_TYPE_FLOAT);
    }
  }

  /**
   * Cette classe représente un Réclamable de Type de Réclamation en Mode FAE, avec son éventuelle
   * Valeur Réclamée. Pas de case à cocher séparée : {@link #isConcerned()} se déduit directement
   * de la valeur renseignée (RG_REP_CIB_01) -- une instance choisie pour un Élément de Paie, une
   * valeur saisie pour une Constante de Paie.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ConcernedClaimable {

    String claimTypeClaimableIdentifier;
    String nature;
    String objectIdentifier;

    /**
     * Libellé métier du Réclamable ciblé (résolu via {@code TA_RECLAMABLE}), affiché au FAE à la
     * place de tout identifiant technique.
     */
    String objectLabel;

    /**
     * Code {@code payroll} du Réclamable ciblé (ex. {@code "010"} pour Fonction) --
     * {@link ClaimTypeClaimableDto#getClaimableCode()}. Détermine, côté page (qui seule connaît
     * la structure du fonctionnaire), quel attribut de {@code structures[i]} consulter pour
     * peupler {@link #currentValueOptions} (RG_REP_IMP_01).
     */
    String claimableCode;

    /**
     * Nature du Mouvement du Réclamable ({@link MovementNatureSelectOneController#VALUE_CREATION}/
     * {@code _MODIFICATION}/{@code _DELETION}) -- détermine le nombre de champs affichés et leur
     * rôle : Création n'affiche que {@link #instanceOptions} (« à attribuer ») ; Modification
     * affiche {@link #currentValueOptions} (« actuel ») puis {@link #instanceOptions}
     * (« nouveau ») ; Suppression n'affiche que {@link #currentValueOptions} (« à retirer »).
     */
    String movementNature;

    /**
     * Ordre d'affichage (RG_REP_CIB_01), configuré par l'administrateur -- sert à trier les
     * Cibles sur l'écran de saisie de la réclamation.
     */
    Integer rank;

    /**
     * Caractère obligatoire pour le FAE, à la Saisie comme à la Soumission (RG_REP_CIB_12) --
     * conditionne l'attribut {@code required} du champ de saisie FAE (movements.xhtml,
     * saveForm.xhtml) ; sans objet côté Mode Agent, toujours requis indépendamment de cet
     * indicateur (RG_REP_CIB_05).
     */
    Boolean mandatoryForFae;

    boolean historyEligible;

    /**
     * Identifiant de la Valeur Réclamée déjà persistée (renseigné par
     * {@link #loadExistingValues(String)}), ou {@code null} si aucune n'existe encore.
     */
    String valueIdentifier;

    /**
     * Identifiant de l'Agent ayant corrigé la valeur FAE (RG_REP_PEC_11), ou {@code null} : la
     * valeur retenue reprend alors la saisie FAE, ou provient d'une détermination Mode Agent.
     */
    String correctedBy;

    /**
     * Identifiant de l'Agent ayant ajouté la valeur que le FAE n'avait pas saisie (RG_REP_PEC_12),
     * ou {@code null}.
     */
    String addedBy;

    /**
     * Longueur maximale d'un libellé d'option pour que la colonne de la Cible reste étroite.
     */
    static final int COMPACT_LABEL_MAX_LENGTH = 20;

    /* Élément de Paie */

    /**
     * Date d'effet propre à cette Cible quand elle est saisie par un champ plutôt que dans le
     * tableau des mouvements (RG_REP_SOU_20) : deux Cibles peuvent porter la même date sans la
     * partager.
     */
    LocalDate effectiveDate;

    /**
     * Catalogue complet des instances possibles -- champ « à attribuer »/« nouveau » (Création/
     * Modification), jamais affiché en Suppression (cf. {@link #movementNature}).
     */
    List<SelectItem> instanceOptions = List.of();

    /**
     * Code court de chaque option de {@link #instanceOptions} (clé : son identifiant), pour
     * correspondance avec les valeurs actuellement actives d'un fonctionnaire -- rempli par
     * {@link ClaimableController#refresh(String, String)}, jamais par le formulaire lui-
     * même.
     */
    Map<String, String> instanceCodes = Map.of();

    String claimableValueIdentifier;

    /**
     * Libellé métier de l'instance choisie (résolu via {@code TA_RECLAMABLE}), affiché en
     * consultation à la place de l'identifiant technique de {@link #claimableValueIdentifier}.
     */
    String instanceLabel;

    /**
     * Sous-ensemble de {@link #instanceOptions} correspondant aux valeurs actuellement actives du
     * fonctionnaire pour ce Réclamable (RG_REP_IMP_01) -- champ « actuel(le) »/« à retirer »
     * (Modification/Suppression), jamais affiché en Création. Peuplé par la page (seule à
     * connaître la structure du fonctionnaire, cf. javadoc de {@link #claimableCode}), pas par ce
     * contrôleur.
     */
    List<SelectItem> currentValueOptions = List.of();

    /**
     * Valeur actuelle choisie parmi {@link #currentValueOptions} -- présélectionnée par la page
     * quand celle-ci n'en compte qu'une (jamais de choix par défaut sinon, même principe que
     * {@code StructureSelectionController.selectedEmploiCode}).
     */
    String selectedCurrentValueIdentifier;

    /* Constante de Paie */

    BigDecimal value;

    /**
     * Cette méthode permet de constuire.
     *
     * @param claimTypeClaimableIdentifier identifiant du Réclamable de Type de Réclamation
     * @param nature nature de l'objet ciblé
     * @param objectIdentifier identifiant de l'objet ciblé
     */
    public ConcernedClaimable(String claimTypeClaimableIdentifier, String nature,
        String objectIdentifier) {
      this.claimTypeClaimableIdentifier = claimTypeClaimableIdentifier;
      this.nature = nature;
      this.objectIdentifier = objectIdentifier;
    }

    /**
     * Cette méthode permet de savoir si cette Cible est concernée par la réclamation -- vaut le
     * simple fait d'avoir renseigné une valeur, sans case à cocher séparée (RG_REP_CIB_01).
     *
     * @return {@code true} si une valeur est renseignée
     */
    public boolean isConcerned() {
      return ClaimableController.ELEMENT_PAIE.equals(nature)
          ? getEffectiveClaimableValueIdentifier() != null : value != null;
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_CREATION}.
     *
     * @return {@code true} si Création
     */
    public boolean isCreationNature() {
      return MovementNatureSelectOneController.VALUE_CREATION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_MODIFICATION}.
     *
     * @return {@code true} si Modification
     */
    public boolean isModificationNature() {
      return MovementNatureSelectOneController.VALUE_MODIFICATION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_DELETION}.
     *
     * @return {@code true} si Suppression
     */
    public boolean isDeletionNature() {
      return MovementNatureSelectOneController.VALUE_DELETION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #currentValueOptions} doit être affiché actif (sélecteur
     * ouvert) plutôt que grisé -- même principe que
     * {@code StructureSelectionController.isEmploiSelectionRendered()} : grisé et présélectionné
     * si un seul candidat, choix explicite requis sinon.
     *
     * @return {@code true} si {@link #currentValueOptions} en compte plus d'un
     */
    public boolean isCurrentValueSelectionRendered() {
      return currentValueOptions.size() > 1;
    }

    /**
     * Cette méthode permet de savoir si tous les libellés de {@link #instanceOptions} sont courts,
     * pour que la colonne de cette Cible dans le tableau des mouvements reste étroite.
     *
     * @return {@code true} si aucun libellé n'excède {@value #COMPACT_LABEL_MAX_LENGTH} caractères
     */
    public boolean isCompactOptions() {
      return instanceOptions.stream()
          .allMatch(option -> option.getLabel().length() <= COMPACT_LABEL_MAX_LENGTH);
    }

    /**
     * Cette méthode permet de construire le libellé du champ unique affiché en Création --
     * jamais de mot technique (« Création ») affiché au FAE, le libellé porte l'action
     * elle-même. Locutions verbales/prépositionnelles volontairement invariables (pas d'accord de
     * genre avec {@link #objectLabel}, dont le genre n'est pas connu génériquement).
     *
     * @return libellé du champ unique en Création
     */
    public String getCreationFieldLabel() {
      return objectLabel + " à attribuer";
    }

    /**
     * Cette méthode permet de construire le libellé du champ "actuel" affiché en Modification --
     * voir {@link #getCreationFieldLabel()}.
     *
     * @return libellé du champ "actuel" en Modification
     */
    public String getCurrentFieldLabel() {
      return objectLabel + " actuellement en vigueur";
    }

    /**
     * Cette méthode permet de construire le libellé du champ "réclamé" affiché en Modification --
     * "Nouvelle valeur de X" reste grammaticalement correct quel que soit le genre de X (l'accord
     * porte sur "valeur", invariablement féminin), contrairement à "Nouveau/Nouvelle X".
     *
     * @return libellé du champ "réclamé" en Modification
     */
    public String getNewFieldLabel() {
      return "Nouvelle valeur de " + objectLabel;
    }

    /**
     * Cette méthode permet de construire le libellé du champ unique affiché en Suppression --
     * voir {@link #getCreationFieldLabel()}.
     *
     * @return libellé du champ unique en Suppression
     */
    public String getDeletionFieldLabel() {
      return objectLabel + " à retirer";
    }

    /**
     * Cette méthode permet d'obtenir l'identifiant {@code TA_VALEUR_RECLAMABLE} effectivement
     * soumis pour ce Réclamable : {@link #selectedCurrentValueIdentifier} en Suppression (seul
     * champ affiché, cf. {@link #movementNature}), {@link #claimableValueIdentifier} en Création
     * ou Modification (champ « à attribuer »/« nouveau »).
     *
     * @return identifiant effectivement soumis, ou {@code null} si rien n'est choisi
     */
    public String getEffectiveClaimableValueIdentifier() {
      return isDeletionNature() ? selectedCurrentValueIdentifier : claimableValueIdentifier;
    }

    /**
     * Cette méthode indique si la valeur retenue a été corrigée par l'Agent (RG_REP_PEC_11) --
     * pour un repère discret côté Agent, jamais affiché au FAE.
     *
     * @return {@code true} si {@link #correctedBy} est renseigné
     */
    public boolean isCorrected() {
      return correctedBy != null;
    }

    /**
     * Cette méthode indique si la valeur a été ajoutée par l'Agent, le FAE ne l'ayant pas saisie
     * (RG_REP_PEC_12).
     *
     * @return {@code true} si {@link #addedBy} est renseigné
     */
    public boolean isAddedByAgent() {
      return addedBy != null;
    }

  }

  /**
   * Cette classe représente le tableau des mouvements intermédiaires : une colonne par Cible
   * éligible du Type, une ligne par date (RG_REP_SOU_20).
   *
   * @author akm
   *
   */
  @Getter
  public static class HistoryTable {

    final List<ConcernedClaimable> targets = new ArrayList<>();

    final List<PeriodRow> rows = new ArrayList<>();

    /**
     * Première ligne du tableau : la situation avant le premier mouvement, sans date.
     */
    final PeriodRow pinnedRow = new PeriodRow(true);

    /**
     * Cette méthode permet d'obtenir les lignes affichées : la situation avant le premier
     * mouvement, puis les mouvements.
     *
     * @return lignes affichées
     */
    public List<PeriodRow> getDisplayRows() {
      List<PeriodRow> displayed = new ArrayList<>();
      displayed.add(pinnedRow);
      displayed.addAll(rows);
      return displayed;
    }

    PeriodRow rowOf(LocalDate date) {
      return rows.stream().filter(row -> Objects.equals(row.getEffectiveDate(), date))
          .findFirst().orElseGet(() -> {
            PeriodRow row = new PeriodRow();
            row.setEffectiveDate(date);
            rows.add(row);
            return row;
          });
    }
  }

  /**
   * Cette classe représente une ligne de l'historique : une date et, pour chaque Cible
   * éligible, la valeur prise à cette date (vide = inchangée).
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PeriodRow {

    LocalDate effectiveDate;

    /**
     * {@code true} pour la première ligne du tableau (situation avant le premier mouvement).
     */
    final boolean pinned;

    public PeriodRow() {
      this(false);
    }

    PeriodRow(boolean pinned) {
      this.pinned = pinned;
    }

    /**
     * Cette méthode permet de savoir si la ligne est vide : ni date, ni valeur, ni valeur déjà
     * enregistrée.
     *
     * @return {@code true} si la ligne est vide
     */
    public boolean isBlank() {
      return effectiveDate == null && !isFilled() && identifierByTarget.isEmpty();
    }

    /**
     * {@code true} si au moins une valeur de la ligne a été ajoutée par l'Agent (RG_REP_PEC_12).
     */
    boolean addedByAgent;

    /**
     * {@code true} si au moins une valeur de la ligne a été corrigée par l'Agent (RG_REP_PEC_11).
     */
    boolean corrected;

    /**
     * {@code true} si au moins une valeur de la ligne a été saisie par le FAE.
     */
    boolean fromFae;

    /**
     * Valeur choisie, par identifiant de Cible de Type.
     */
    final Map<String, String> valueByTarget = new LinkedHashMap<>();

    /**
     * Identifiant de la Valeur Réclamée déjà enregistrée, par identifiant de Cible de Type.
     */
    final Map<String, String> identifierByTarget = new LinkedHashMap<>();

    /**
     * Cette méthode permet de savoir si au moins une valeur est renseignée sur la ligne.
     *
     * @return {@code true} si une valeur est renseignée
     */
    public boolean isFilled() {
      return valueByTarget.values().stream().anyMatch(value -> value != null && !value.isBlank());
    }
  }
}
