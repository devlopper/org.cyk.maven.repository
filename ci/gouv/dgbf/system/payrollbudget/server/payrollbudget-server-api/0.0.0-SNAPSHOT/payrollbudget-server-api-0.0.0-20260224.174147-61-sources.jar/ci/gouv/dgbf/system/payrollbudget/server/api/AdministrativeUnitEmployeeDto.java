package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un employé d'unité administrative.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AdministrativeUnitEmployeeDto extends AbstractIdentifiableDto
    implements PayrollComponentProjectionContainerDto {

  /**
   * Identifiant de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  String exerciseAsString;

  /**
   * Identifiant de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  String administrativeUnitAsString;

  /**
   * Identifiant de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING)
  String budgetAdministrativeUnitAsString;

  /**
   * Identifiant employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
  String employeeIdentifier;

  /**
   * Représentation en chaine de caractères de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_AS_STRING)
  String employeeAsString;

  /**
   * Identifiant de l'emploi.
   */
  @JsonbProperty(JSON_JOB_IDENTIFIER)
  String jobIdentifier;

  /**
   * Représentation en chaine de caractères de l'emploi.
   */
  @JsonbProperty(JSON_JOB_AS_STRING)
  String jobAsString;

  /**
   * Identifiant de l'indice de paie.
   */
  @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
  String payIndexIdentifier;

  /**
   * Représentation en chaine de caractères de l'indice de paie.
   */
  @JsonbProperty(JSON_PAY_INDEX_AS_STRING)
  String payIndexAsString;

  /**
   * Identifiant de la fonction.
   */
  @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
  String functionIdentifier;

  /**
   * Représentation en chaine de caractères de la fonction.
   */
  @JsonbProperty(JSON_FUNCTION_AS_STRING)
  String functionAsString;

  /**
   * Identifiant {@link MovementTypeDto}.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
  String movementTypeIdentifier;

  /**
   * employé est fonctionnaire.
   */
  @JsonbProperty(JSON_IS_FUNCTIONARY)
  Boolean isFunctionary;

  /**
   * Représentation en chaine de caractères employé est fonctionnaire.
   */
  @JsonbProperty(JSON_IS_FUNCTIONARY_AS_STRING)
  String isFunctionaryAsString;

  /**
   * Identifiant fonctionnaire.
   */
  @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
  String functionaryIdentifier;

  /**
   * {@link AdministrativeUnitEmployeeStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  AdministrativeUnitEmployeeStatus status;

  /**
   * Identifiant de la catégorie de employé.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  String categoryIdentifier;

  /**
   * Représentation en chaine de caractères de la catégorie de employé.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  String categoryAsString;

  /**
   * Identifiant du grade de employé.
   */
  @JsonbProperty(JSON_GRADE_IDENTIFIER)
  String gradeIdentifier;

  /**
   * Représentation en chaine de caractères du grade de employé.
   */
  @JsonbProperty(JSON_GRADE_AS_STRING)
  String gradeAsString;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @Transient
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Représentation en chaine de caractères de la variance du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVarianceAsString;
  
  /**
   * Outgoingable.
   */
  @JsonbProperty(JSON_OUTGOINGABLE)
  Boolean outgoingable;

  /**
   * Outgoing cancelable.
   */
  @JsonbProperty(JSON_OUTGOING_CANCELABLE)
  Boolean outgoingCancelable;

  /**
   * Nombre de mouvement de présence.
   */
  @JsonbProperty(JSON_PRESENCE_MOVEMENT_COUNT)
  Integer presenceMovementCount;

  /**
   * Représentation en chaine de caractères du nombre de mouvement de présence.
   */
  @JsonbProperty(JSON_PRESENCE_MOVEMENT_COUNT_AS_STRING)
  String presenceMovementCountAsString;

  /**
   * Identifiant json de identifiant de {@link AdministrativeUnitEmployeeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEmployeUniteAdministrative";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link AdministrativeUnitEmployeeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "employeUniteAdministrativeChaine";

  /**
   * Identifiant json {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_ADMINISTRATIVE_UNIT_AS_STRING;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitAsString}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #employeeIdentifier}.
   */
  public static final String JSON_EMPLOYEE_IDENTIFIER = "idEmploye";

  /**
   * Identifiant json {@link #employeeAsString}.
   */
  public static final String JSON_EMPLOYEE_AS_STRING = "employeeChaine";

  /**
   * Identifiant json {@link #outgoingable}.
   */
  public static final String JSON_OUTGOINGABLE = "sortable";

  /**
   * Identifiant json {@link #outgoingCancelable}.
   */
  public static final String JSON_OUTGOING_CANCELABLE = "sortieAnnulable";

  /**
   * Identifiant json {@link #movementTypeIdentifier}.
   */
  public static final String JSON_MOVEMENT_TYPE_IDENTIFIER = MovementTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #jobIdentifier}.
   */
  public static final String JSON_JOB_IDENTIFIER = "idEmploi";

  /**
   * Identifiant json {@link #jobAsString}.
   */
  public static final String JSON_JOB_AS_STRING = "emploiChaine";

  /**
   * Identifiant json {@link #payIndexIdentifier}.
   */
  public static final String JSON_PAY_INDEX_IDENTIFIER = "idIndicePaie";

  /**
   * Identifiant json {@link #payIndexAsString}.
   */
  public static final String JSON_PAY_INDEX_AS_STRING = "indicePaieChaine";

  /**
   * Identifiant json {@link #functionIdentifier}.
   */
  public static final String JSON_FUNCTION_IDENTIFIER = "idFonction";

  /**
   * Identifiant json {@link #functionAsString}.
   */
  public static final String JSON_FUNCTION_AS_STRING = "fonctionChaine";

  /**
   * Identifiant json {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER =
      AdministrativeUnitEmployeeCategoryDto.JSON_EMPLOYEE_CATEGORY_IDENTIFIER;

  /**
   * Identifiant json {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING =
      AdministrativeUnitEmployeeCategoryDto.JSON_EMPLOYEE_CATEGORY_AS_STRING;

  /**
   * Identifiant json {@link #gradeIdentifier}.
   */
  public static final String JSON_GRADE_IDENTIFIER = "idGrade";

  /**
   * Identifiant json {@link #gradeAsString}.
   */
  public static final String JSON_GRADE_AS_STRING = "gradeChaine";

  /**
   * Identifiant json {@link #isFunctionary}.
   */
  public static final String JSON_IS_FUNCTIONARY = "estFonctionnaire";

  /**
   * Identifiant json {@link #isFunctionaryAsString}.
   */
  public static final String JSON_IS_FUNCTIONARY_AS_STRING = "estFonctionnaireChaine";

  /**
   * Identifiant json {@link #functionaryIdentifier}.
   */
  public static final String JSON_FUNCTIONARY_IDENTIFIER = "idFonctionnaire";

  /**
   * Identifiant json {@link #presenceMovementCount}.
   */
  public static final String JSON_PRESENCE_MOVEMENT_COUNT = "compteMouvementPresence";

  /**
   * Identifiant json {@link #presenceMovementCountAsString}.
   */
  public static final String JSON_PRESENCE_MOVEMENT_COUNT_AS_STRING =
      "compteMouvementPresenceChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "employé d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "employés d'unité administrative";
}
