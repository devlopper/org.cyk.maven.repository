package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entrée d'un dictionnaire.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DictionaryEntryDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasValueTypeDto, HasDefaultValueDto<String> {

  /**
   * Identifiant de {@link DictionaryDto}.
   */
  @JsonbProperty(JSON_DICTIONARY_IDENTIFIER)
  private String dictionaryIdentifier;

  /**
   * Représentation en chaine de caractères de {@link DictionaryDto}.
   */
  @JsonbProperty(JSON_DICTIONARY_AS_STRING)
  private String dictionaryAsString;

  /**
   * Valeur par défaut {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_DEFAULT_VALUE)
  private String defaultValue;

  /**
   * Type de valeur {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;


  /**
   * Identitiant json {@link DictionaryEntryDto#dictionaryIdentifier}.
   */
  public static final String JSON_DICTIONARY_IDENTIFIER = "idDictionnaire";

  /**
   * Identitiant json {@link DictionaryEntryDto#dictionaryAsString}.
   */
  public static final String JSON_DICTIONARY_AS_STRING = "dictionnaireChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "entrée Dictionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "entrées Dictionnaire";
}
