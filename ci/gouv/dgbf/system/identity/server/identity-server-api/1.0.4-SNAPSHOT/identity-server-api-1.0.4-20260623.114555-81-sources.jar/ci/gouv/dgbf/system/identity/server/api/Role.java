package ci.gouv.dgbf.system.identity.server.api;

/**
 * Cette classe représente l'énumération de {@link RoleDto}.
 *
 * @author Christian
 *
 */
public enum Role {

  /**
   * Responsable.
   */
  RESPONSIBLE
  
  ;
}
