package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette classe représente les codes de {@link BudgetAdministrativeUnitChart}.
 *
 * @author Christian
 *
 */
public class BudgetAdministrativeUnitChartCode {

  private BudgetAdministrativeUnitChartCode() {

  }

  /**
   * Compte des employés par catégorie.
   */
  public static final String EMPLOYEE_BY_CATEGORY_COUNT = "COMPTE_EMPLOYE_PAR_CATEGORIE";
}
