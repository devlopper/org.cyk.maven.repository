package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimTypeGroupDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimTypeGroupFilter extends AbstractIdentifiableFilter {

}
