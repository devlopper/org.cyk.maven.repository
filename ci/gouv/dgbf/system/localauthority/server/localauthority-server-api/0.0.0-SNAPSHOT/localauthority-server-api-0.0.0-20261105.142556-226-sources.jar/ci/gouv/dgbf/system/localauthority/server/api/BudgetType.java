package ci.gouv.dgbf.system.localauthority.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types de {@link BudgetDto}.
 *
 * @author Donsylla
 *
 */
@Getter
public enum BudgetType {

  /**
   * Primitif.
   */
  INITIAL(BudgetTypeCode.INITIAL, "Primitif", "BP");

  private BudgetType(String code, String name, String codePrefix) {
    this.code = code;
    this.name = name;
    this.codePrefix = codePrefix;
  }

  private String code;
  private String name;
  private String codePrefix;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le type par code.
   *
   * @param code code
   * @return type
   */
  public static BudgetType getByCode(String code) {
    return Stream.of(BudgetType.values())
        .filter(type -> type.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
