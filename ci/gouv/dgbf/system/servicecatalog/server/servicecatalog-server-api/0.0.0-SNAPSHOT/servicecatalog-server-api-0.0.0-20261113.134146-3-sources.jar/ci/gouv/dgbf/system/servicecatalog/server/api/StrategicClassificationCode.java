package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette classe représente les codes de {@link StrategicClassification}, valeurs du référentiel
 * {@code TR_CLASSIFICATION_STRATEGIQUE}.
 *
 * @author Christian
 *
 */
public class StrategicClassificationCode {

  private StrategicClassificationCode() {

  }

  /**
   * Domaine cœur.
   */
  public static final String CORE_DOMAIN = "DOMAINE_COEUR";

  /**
   * Sous-domaine support.
   */
  public static final String SUPPORTING_SUBDOMAIN = "SOUS_DOMAINE_SUPPORT";

  /**
   * Sous-domaine générique.
   */
  public static final String GENERIC_SUBDOMAIN = "SOUS_DOMAINE_GENERIQUE";
}
