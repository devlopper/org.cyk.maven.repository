package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ImputationLockDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ImputationLockFilter extends AbstractIdentifiableFilter {

}
