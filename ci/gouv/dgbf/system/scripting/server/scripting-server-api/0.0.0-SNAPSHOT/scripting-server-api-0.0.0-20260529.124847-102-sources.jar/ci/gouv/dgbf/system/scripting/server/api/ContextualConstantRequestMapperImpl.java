package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ContextualConstantDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ContextualConstantRequestMapperImpl implements ContextualConstantRequestMapper {

    @Override
    public ContextualConstantService.ContextualConstantCreateRequestDto mapCreate(ContextualConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantService.ContextualConstantCreateRequestDto contextualConstantCreateRequestDto = new ContextualConstantService.ContextualConstantCreateRequestDto();

        contextualConstantCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        contextualConstantCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        contextualConstantCreateRequestDto.setConstantIdentifier( arg0.getConstantIdentifier() );
        contextualConstantCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        contextualConstantCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        contextualConstantCreateRequestDto.setFromDate( arg0.getFromDate() );
        contextualConstantCreateRequestDto.setToDate( arg0.getToDate() );

        return contextualConstantCreateRequestDto;
    }

    @Override
    public ContextualConstantService.ContextualConstantUpdateRequestDto mapUpdate(ContextualConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantService.ContextualConstantUpdateRequestDto contextualConstantUpdateRequestDto = new ContextualConstantService.ContextualConstantUpdateRequestDto();

        contextualConstantUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        contextualConstantUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        contextualConstantUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        contextualConstantUpdateRequestDto.setConstantIdentifier( arg0.getConstantIdentifier() );
        contextualConstantUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        contextualConstantUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        contextualConstantUpdateRequestDto.setFromDate( arg0.getFromDate() );
        contextualConstantUpdateRequestDto.setToDate( arg0.getToDate() );

        return contextualConstantUpdateRequestDto;
    }
}
