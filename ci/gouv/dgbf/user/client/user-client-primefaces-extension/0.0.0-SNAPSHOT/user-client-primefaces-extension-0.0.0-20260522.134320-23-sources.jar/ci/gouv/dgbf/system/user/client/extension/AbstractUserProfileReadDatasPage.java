package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages de profile de l'utilisateur connecté.
 *
 * @author BoobaCool
 */
public abstract class AbstractUserProfileReadDatasPage extends AbstractPage {

  @Inject
  UserClient client;

  @Getter
  UserDto user;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Mon profile";

    GetOneRequestDto request = new GetOneRequestDto();
    UserFilter filter = new UserFilter();
    filter.setName(userIdentifier);
    request.useFilter(filter);
    request.projection().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING,
        UserDto.JSON_DOMAIN_AS_STRING,
        UserDto.JSON_ACCOUNT_EXISTS);
    request.setAuditWho(userIdentifier);
    user = client.getOne(request);
  }
}
