package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RoleDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class RoleSelectManyController extends
    AbstractSelectManyIdentifiableController<RoleDto, RoleGetManyResponseDto, RoleClient> {

  @Inject
  @Getter
  RoleClient client;

  /**
   * Cette méthode permet de construire.
   */
  public RoleSelectManyController() {
    super(RoleDto.class);
  }
}