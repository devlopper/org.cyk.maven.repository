package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCascadeDeleteWhenAllChildrenDeletedDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une partition.
 *
 * @author Arnaud
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PartitionDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto, HasValueIdentifierDto, HasValueAsStringDto,
    HasCascadeDeleteWhenAllChildrenDeletedDto {

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  @JsonbProperty(JSON_VALUE_IDENTIFIER)
  private String valueIdentifier;

  @JsonbProperty(JSON_VALUE_AS_STRING)
  private String valueAsString;

  @JsonbProperty(JSON_CASCADE_DELETE_WHEN_ALL_CHILDREN_DELETED)
  private Boolean cascadeDeleteWhenAllChildrenDeleted;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPartition";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "partitionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "partition";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "partitions";
}
