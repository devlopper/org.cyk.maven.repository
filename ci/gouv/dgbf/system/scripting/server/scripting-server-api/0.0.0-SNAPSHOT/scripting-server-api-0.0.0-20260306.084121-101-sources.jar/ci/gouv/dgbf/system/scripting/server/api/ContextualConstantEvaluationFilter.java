package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCategoryCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCategoryIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasGroupIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasValueIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ContextualConstantEvaluationDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ContextualConstantEvaluationFilter extends AbstractIdentifiableFilter
    implements FilterHasGroupIdentifier, FilterHasCategoryIdentifier, FilterHasCategoryCode,
    FilterHasValueIdentifier {

  private String groupIdentifier;

  private String categoryIdentifier;

  private String categoryCode;

  private String valueIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ContextualConstantEvaluationFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ContextualConstantEvaluationFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateGroupIdentifier(filter);
    updateCategoryIdentifier(filter);
    updateCategoryCode(filter);
    updateValueIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterGroupIdentifier(filter);
    updateFilterCategoryIdentifier(filter);
    updateFilterCategoryCode(filter);
    updateFilterValueIdentifier(filter);
  }

}
