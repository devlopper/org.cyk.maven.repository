package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ExpenditureSettlementService.ExpenditureSettlementCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpenditureSettlementService.ExpenditureSettlementGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpenditureSettlementService.ExpenditureSettlementUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ExpenditureSettlementService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ExpenditureSettlementClient extends AbstractClient<ExpenditureSettlementService>
    implements GetByIdentifier<ExpenditureSettlementDto>,
    GetMany<ExpenditureSettlementGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ExpenditureSettlementClient service(ExpenditureSettlementService service) {
    return (ExpenditureSettlementClient) super.service(service);
  }

  /**
   * {@link ExpenditureSettlementService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ExpenditureSettlementCreateRequestDto request) {
    return new CreateExecutor(ExpenditureSettlementService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ExpenditureSettlementService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpenditureSettlementGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ExpenditureSettlementGetManyResponseDto>(
        ExpenditureSettlementGetManyResponseDto.class,
        ExpenditureSettlementService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ExpenditureSettlementService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpenditureSettlementGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                                         PageDto page, String auditWho,
                                                         String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ExpenditureSettlementService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpenditureSettlementDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ExpenditureSettlementDto>(ExpenditureSettlementDto.class,
        ExpenditureSettlementService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ExpenditureSettlementService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpenditureSettlementDto getOne(ProjectionDto projection, FilterDto filter,
                                         String auditWho,
                                         String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ExpenditureSettlementService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ExpenditureSettlementDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ExpenditureSettlementDto>(ExpenditureSettlementDto.class,
        ExpenditureSettlementService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ExpenditureSettlementService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpenditureSettlementDto getByIdentifier(String identifier, ProjectionDto projection,
                                                  String auditWho,
                                                  String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ExpenditureSettlementService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ExpenditureSettlementUpdateRequestDto request) {
    return new IdentifiableExecutor(ExpenditureSettlementService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ExpenditureSettlementService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ExpenditureSettlementService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ExpenditureSettlementService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

