package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import java.util.List;
import java.util.StringJoiner;

/**
 * Cette classe représente les contraintes applicables à une entrée de dictionnaire selon son type
 * de valeur (RG_DST_DIC_14). Elle reprend la matrice contrôlée par le serveur, qui reste l'arbitre.
 *
 * @author Christian
 *
 */
public final class DictionaryEntryConstraints {

  private static final String SEPARATOR = " ; ";

  private DictionaryEntryConstraints() {}

  /**
   * Cette méthode permet de savoir si les longueurs s'appliquent au type.
   *
   * @param valueType type de valeur, null si non choisi
   * @return vrai pour STRING
   */
  public static boolean hasLengths(ValueType valueType) {
    return valueType == ValueType.STRING;
  }

  /**
   * Cette méthode permet de savoir si l'expression régulière s'applique au type.
   *
   * @param valueType type de valeur, null si non choisi
   * @return vrai pour STRING
   */
  public static boolean hasPattern(ValueType valueType) {
    return valueType == ValueType.STRING;
  }

  /**
   * Cette méthode permet de savoir si les bornes s'appliquent au type.
   *
   * @param valueType type de valeur, null si non choisi
   * @return vrai pour INTEGER, FLOAT et INSTANT
   */
  public static boolean hasBounds(ValueType valueType) {
    return valueType == ValueType.INTEGER || valueType == ValueType.FLOAT
        || valueType == ValueType.INSTANT;
  }

  /**
   * Cette méthode permet de savoir si les valeurs autorisées s'appliquent au type.
   *
   * @param valueType type de valeur, null si non choisi
   * @return vrai pour STRING et INTEGER
   */
  public static boolean hasAllowedValues(ValueType valueType) {
    return valueType == ValueType.STRING || valueType == ValueType.INTEGER;
  }

  /**
   * Cette méthode permet de savoir si la précision et l'échelle s'appliquent au type.
   *
   * @param valueType type de valeur, null si non choisi
   * @return vrai pour FLOAT
   */
  public static boolean hasPrecisionAndScale(ValueType valueType) {
    return valueType == ValueType.FLOAT;
  }

  /**
   * Cette méthode permet de vider les contraintes qui ne s'appliquent pas au type : le serveur
   * refuse une contrainte hors type, or un champ masqué après un changement de type garde sa
   * valeur.
   *
   * @param entry entrée en cours de saisie
   * @param valueType type de valeur, null si non choisi (toutes les contraintes sont vidées)
   */
  public static void clearInapplicable(DictionaryEntryDto entry, ValueType valueType) {
    if (!hasLengths(valueType)) {
      entry.setMinLength(null);
      entry.setMaxLength(null);
    }
    if (!hasPattern(valueType)) {
      entry.setPattern(null);
    }
    if (!hasBounds(valueType)) {
      entry.setMinValue(null);
      entry.setMaxValue(null);
    }
    if (!hasAllowedValues(valueType)) {
      entry.setAllowedValues(null);
    }
    if (!hasPrecisionAndScale(valueType)) {
      entry.setPrecision(null);
      entry.setScale(null);
    }
  }

  /**
   * Cette méthode permet de résumer en une ligne les contraintes renseignées d'une entrée.
   *
   * @param entry entrée
   * @return le résumé, vide si aucune contrainte
   */
  public static String summarize(DictionaryEntryDto entry) {
    StringJoiner joiner = new StringJoiner(SEPARATOR);
    if (entry.getMinLength() != null || entry.getMaxLength() != null) {
      joiner.add("longueur " + range(entry.getMinLength(), entry.getMaxLength()));
    }
    if (entry.getMinValue() != null || entry.getMaxValue() != null) {
      joiner.add("valeur " + range(entry.getMinValue(), entry.getMaxValue()));
    }
    if (entry.getPattern() != null) {
      joiner.add("motif " + entry.getPattern());
    }
    List<String> allowedValues = entry.getAllowedValues();
    if (allowedValues != null && !allowedValues.isEmpty()) {
      joiner.add("valeurs " + String.join(", ", allowedValues));
    }
    if (entry.getPrecision() != null) {
      joiner.add("précision " + entry.getPrecision());
    }
    if (entry.getScale() != null) {
      joiner.add("échelle " + entry.getScale());
    }
    return joiner.toString();
  }

  private static String range(Object minimum, Object maximum) {
    if (minimum != null && maximum != null) {
      return minimum + " – " + maximum;
    }
    return minimum != null ? "≥ " + minimum : "≤ " + maximum;
  }
}
