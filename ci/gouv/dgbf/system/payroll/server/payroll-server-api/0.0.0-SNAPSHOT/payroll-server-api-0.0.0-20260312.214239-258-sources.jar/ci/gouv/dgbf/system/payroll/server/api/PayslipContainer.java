package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette interface représente un conteneur de {@link PayslipDto}.
 */
public interface PayslipContainer {

  // Status

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du statut.
   *
   * @return Représentation en chaine de caractères du statut
   */
  String getStatusAsString();

  // Amounts

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant brut(total
   * des gains).
   *
   * @return Représentation en chaine de caractères du montant brut(total des gains)
   */
  String getGrossAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant du brut
   * imposable.
   *
   * @return Représentation en chaine de caractères du montant du brut imposable
   */
  String getTaxableGrossAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant des
   * éléments non soumis.
   *
   * @return Représentation en chaine de caractères du montant des éléments non soumis
   */
  String getNonTaxableAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant des
   * retenues.
   *
   * @return Représentation en chaine de caractères du montant des retenues
   */
  String getDeductionsAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant net.
   *
   * @return Représentation en chaine de caractères du montant net
   */
  String getNetAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant initialisé.
   *
   * @return Représentation en chaine de caractères du montant initialisé
   */
  String getInitializedAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant controlé.
   *
   * @return Représentation en chaine de caractères du montant controlé
   */
  String getControledAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la variation 
   * controlée.
   *
   * @return Représentation en chaine de caractères de la variation controlée
   */
  String getControledAmountVariationAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant ajusté.
   *
   * @return Représentation en chaine de caractères du montant ajusté
   */
  String getAjustedAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la variation 
   * ajustée.
   *
   * @return Représentation en chaine de caractères de la variation ajustée
   */
  String getAjustedAmountVariationAsString();

  // Counts

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipMovementDto}
   */
  String getMovementCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto} {@link PayslipMovementStatus#DEFERRED_PROPOSED}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipMovementDto}
   *         {@link PayslipMovementStatus#DEFERRED_PROPOSED}
   */
  String getMovementDeferredProposedCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto} {@link PayslipMovementStatus#DEFERRED}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipMovementDto}
   *         {@link PayslipMovementStatus#DEFERRED}
   */
  String getMovementDeferredCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto} {@link PayslipMovementStatus#REJECTION_PROPOSED}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipMovementDto}
   *         {@link PayslipMovementStatus#REJECTION_PROPOSED}
   */
  String getMovementRejectionProposedCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto} {@link PayslipMovementStatus#REJECTED}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipMovementDto}
   *         {@link PayslipMovementStatus#REJECTED}
   */
  String getMovementRejectedCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipConstantDto}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipConstantDto}
   */
  String getConstantCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto}.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipComponentDto}
   */
  String getComponentCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} en gain ayant un montant non zéro.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipComponentDto} en gain
   *         ayant un montant non zéro
   */
  String getEarningComponentHavingNonZeroAmountCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} en déduction ayant un montant non zéro.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipComponentDto} en
   *         déduction ayant un montant non zéro
   */
  String getDeductionComponentHavingNonZeroAmountCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} ayant un message d'évaluation de formule de calcul.
   *
   * @return Représentation en chaine de caractères du nombre de {@link PayslipComponentDto} ayant
   *         un message d'évaluation de formule de calcul non blanc
   */
  String getComponentHavingNonBlankMessageCountAsString();

  /**
   * Identifiant java du nombre de {@link PayslipMovementDto}.
   */
  public static final String FIELD_MOVEMENT_COUNT_AS_STRING = "movementCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#DEFERRED_PROPOSED}.
   */
  public static final String FIELD_MOVEMENT_DEFERRED_PROPOSED_COUNT_AS_STRING =
      "movementDeferredProposedCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#DEFERRED}.
   */
  public static final String FIELD_MOVEMENT_DEFERRED_COUNT_AS_STRING =
      "movementDeferredCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#REJECTION_PROPOSED}.
   */
  public static final String FIELD_MOVEMENT_REJECTION_PROPOSED_COUNT_AS_STRING =
      "movementRejectionProposedCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#REJECTED}.
   */
  public static final String FIELD_MOVEMENT_REJECTED_COUNT_AS_STRING =
      "movementRejectedCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipConstantDto}.
   */
  public static final String FIELD_CONSTANT_COUNT_AS_STRING = "constantCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipComponentDto}.
   */
  public static final String FIELD_COMPONENT_COUNT_AS_STRING = "componentCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipComponentDto} en gain ayant un montant non zéro.
   */
  public static final String FIELD_EARNING_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING =
      "earningComponentHavingNonZeroAmountCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipComponentDto} en déduction ayant un montant non
   * zéro.
   */
  public static final String FIELD_DEDUCTION_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING =
      "deductionComponentHavingNonZeroAmountCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipComponentDto} en déduction ayant un montant non
   * zéro.
   */
  public static final String FIELD_COMPONENT_HAVING_NON_BLANK_MESSAGE_COUNT_AS_STRING =
      "componentHavingNonBlankMessageCountAsString";
}
