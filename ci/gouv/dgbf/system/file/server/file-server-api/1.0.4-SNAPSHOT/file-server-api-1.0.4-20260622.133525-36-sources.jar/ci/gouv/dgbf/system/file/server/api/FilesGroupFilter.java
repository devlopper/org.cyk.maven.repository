package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FilesGroupFilter extends AbstractIdentifiableFilter {
  
}
