package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollConstantIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayslipIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipConstantDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayslipConstantFilter extends AbstractIdentifiableFilter
    implements FilterHasPayslipIdentifier, FilterHasPayrollConstantIdentifier {

  private String payslipIdentifier;

  private String payrollConstantIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipConstantFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipConstantFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayslipIdentifier(filter);
    updatePayrollConstantIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayslipIdentifier(filter);
    updateFilterPayrollConstantIdentifier(filter);
  }
}
