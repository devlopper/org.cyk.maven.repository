package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExerciseService.ProgrammingExerciseCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExerciseService.ProgrammingExerciseGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExerciseService.ProgrammingExerciseUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ProgrammingExerciseDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class ProgrammingExerciseClient extends AbstractClient<ProgrammingExerciseService>
    implements GetByIdentifier<ProgrammingExerciseDto>,
           GetMany<ProgrammingExerciseGetManyResponseDto>,
           DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ProgrammingExerciseService}
   * @return client {@link ProgrammingExerciseClient}
   */
  @Override
  public ProgrammingExerciseClient service(ProgrammingExerciseService service) {
    return (ProgrammingExerciseClient) super.service(service);
  }

  /**
   * {@link ProgrammingExerciseService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProgrammingExerciseCreateRequestDto request) {
    return new CreateExecutor(ProgrammingExerciseService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProgrammingExerciseService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProgrammingExerciseGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProgrammingExerciseGetManyResponseDto>(
        ProgrammingExerciseGetManyResponseDto.class,
        ProgrammingExerciseService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ProgrammingExerciseService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExerciseGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProgrammingExerciseService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExerciseDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ProgrammingExerciseDto>(ProgrammingExerciseDto.class,
        ProgrammingExerciseService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProgrammingExerciseService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExerciseDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ProgrammingExerciseDto>(ProgrammingExerciseDto.class,
        ProgrammingExerciseService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProgrammingExerciseService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProgrammingExerciseUpdateRequestDto request) {
    return new IdentifiableExecutor(ProgrammingExerciseService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProgrammingExerciseService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProgrammingExerciseService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
