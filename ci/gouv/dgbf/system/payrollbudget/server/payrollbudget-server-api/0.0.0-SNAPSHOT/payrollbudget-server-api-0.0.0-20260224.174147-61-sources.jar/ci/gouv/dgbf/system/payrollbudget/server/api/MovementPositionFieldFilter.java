package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link MovementPositionFieldDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementPositionFieldFilter extends AbstractIdentifiableFilter
    implements FilterHasAdministrativeUnitEmployeeStatusCode, FilterHasMovementIdentifier,
    FilterHasPositionFieldCodes {

  /**
   * Code {@link AdministrativeUnitEmployeeStatus}.
   */
  String administrativeUnitEmployeeStatusCode;

  /**
   * Codes {@link PositionField}.
   */
  Set<String> positionFieldCodes;

  /**
   * Identifiant {@link MovementDto}.
   */
  String movementIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public MovementPositionFieldFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public MovementPositionFieldFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitEmployeeStatusCode(filter);
    updatePositionFieldCodes(filter);
    updateMovementIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitEmployeeStatusCode(filter);
    updateFilterPositionFieldCodes(filter);
    updateFilterMovementIdentifier(filter);
  }
}
