package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import java.util.Collection;
import java.util.List;

/**
 * Cette classe représente une sélection de chaine de caractères par suggestion.
 *
 * @author Christian
 *
 * @param <T> type
 */
public class AutoCompleteStrings
    extends AbstractAutoComplete<Object, String, Object, List<String>> {

  /**
   * Cette méthode permet d'instantier.
   */
  public AutoCompleteStrings(ScriptManager scriptManager) {
    super(scriptManager);
    itemValueGetFunction = AutoCompleteString.ITEM_VALUE_GET_FUNCTION;

    valueGetFunction = t -> {
      if (t instanceof Collection<?> collection) {
        return collection.stream().map(AutoCompleteString.ITEM_VALUE_GET_FUNCTION::apply).toList();
      }
      return null;
    };
  }
}
