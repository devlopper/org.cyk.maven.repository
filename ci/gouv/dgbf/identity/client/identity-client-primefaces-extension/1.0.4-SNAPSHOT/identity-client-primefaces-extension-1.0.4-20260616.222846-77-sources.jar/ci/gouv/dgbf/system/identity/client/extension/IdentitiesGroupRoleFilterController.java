package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link IdentitiesGroupRoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class IdentitiesGroupRoleFilterController
    extends AbstractFilterController<IdentitiesGroupRoleFilter> {

  /**
   * Cette méthode permet d'instantier.
   */
  public IdentitiesGroupRoleFilterController() {
    super(IdentitiesGroupRoleFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setGroupIdentifier(
        getRequestParameter(IdentitiesGroupRoleFilter.JSON_GROUP_IDENTIFIER));
    filter.setRoleIdentifier(getRequestParameter(IdentitiesGroupRoleFilter.JSON_ROLE_IDENTIFIER));
  }
}

