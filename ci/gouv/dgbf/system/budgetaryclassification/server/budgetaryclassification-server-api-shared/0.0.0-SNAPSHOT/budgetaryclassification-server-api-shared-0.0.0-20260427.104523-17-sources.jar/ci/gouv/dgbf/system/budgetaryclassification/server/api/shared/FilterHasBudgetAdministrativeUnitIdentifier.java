package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'unité administrative de
 * budget.
 *
 * @author Christian
 */
public interface FilterHasBudgetAdministrativeUnitIdentifier
    extends HasBudgetAdministrativeUnitIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant l'unité administrative de budget.
   *
   * @param filter {@link FilterDto}
   */
  default void updateBudgetAdministrativeUnitIdentifier(FilterDto filter) {
    setBudgetAdministrativeUnitIdentifier(BudgetAdministrativeUnitIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant l'unité administrative de budget de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterBudgetAdministrativeUnitIdentifier(FilterDto filter) {
    BudgetAdministrativeUnitIdentifierFilter.set(filter, getBudgetAdministrativeUnitIdentifier());
  }

}
