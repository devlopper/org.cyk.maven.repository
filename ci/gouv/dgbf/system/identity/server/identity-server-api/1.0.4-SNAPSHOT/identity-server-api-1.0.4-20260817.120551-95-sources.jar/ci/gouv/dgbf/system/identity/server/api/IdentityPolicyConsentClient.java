package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentAcceptRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentAcceptResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRefuseRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRefuseResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRevokeRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRevokeResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client de {@link IdentityPolicyConsentService}.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
public class IdentityPolicyConsentClient extends AbstractClient<IdentityPolicyConsentService>
    implements GetMany<IdentityPolicyConsentGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetByIdentifier<IdentityPolicyConsentDto> {

  @Override
  public IdentityPolicyConsentClient service(IdentityPolicyConsentService service) {
    return (IdentityPolicyConsentClient) super.service(service);
  }

  /**
   * {@link IdentityPolicyConsentService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentityPolicyConsentGetManyResponseDto>(
        IdentityPolicyConsentGetManyResponseDto.class,
        IdentityPolicyConsentService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link IdentityPolicyConsentService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityPolicyConsentGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentityPolicyConsentService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentityPolicyConsentDto>(IdentityPolicyConsentDto.class,
        IdentityPolicyConsentService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentityPolicyConsentService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityPolicyConsentDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentityPolicyConsentService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentityPolicyConsentDto>(IdentityPolicyConsentDto.class,
        IdentityPolicyConsentService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentityPolicyConsentService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentityPolicyConsentDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentityPolicyConsentService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentityPolicyConsentService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un consentement.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link IdentityPolicyConsentService#sendConsentRequestMail}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto sendConsentRequestMail(
      IdentityPolicyConsentSendConsentRequestMailRequestDto request) {
    return new GetOneExecutor<>(IdentityPolicyConsentSendConsentRequestMailResponseDto.class,
        IdentityPolicyConsentService.SEND_CONSENT_REQUEST_MAIL_IDENTIFIER)
            .execute(() -> service().sendConsentRequestMail(request));
  }

  /**
   * {@link IdentityPolicyConsentService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentAcceptResponseDto accept(
      IdentityPolicyConsentAcceptRequestDto request) {
    return new GetOneExecutor<>(IdentityPolicyConsentAcceptResponseDto.class,
        IdentityPolicyConsentService.ACCEPT_IDENTIFIER)
            .execute(() -> service().accept(request));
  }

  /**
   * {@link IdentityPolicyConsentService#refuse}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentRefuseResponseDto refuse(
      IdentityPolicyConsentRefuseRequestDto request) {
    return new GetOneExecutor<>(IdentityPolicyConsentRefuseResponseDto.class,
        IdentityPolicyConsentService.REFUSE_IDENTIFIER)
            .execute(() -> service().refuse(request));
  }

  /**
   * {@link IdentityPolicyConsentService#revoke}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityPolicyConsentRevokeResponseDto revoke(
      IdentityPolicyConsentRevokeRequestDto request) {
    return new GetOneExecutor<>(IdentityPolicyConsentRevokeResponseDto.class,
        IdentityPolicyConsentService.REVOKE_IDENTIFIER)
            .execute(() -> service().revoke(request));
  }
}
