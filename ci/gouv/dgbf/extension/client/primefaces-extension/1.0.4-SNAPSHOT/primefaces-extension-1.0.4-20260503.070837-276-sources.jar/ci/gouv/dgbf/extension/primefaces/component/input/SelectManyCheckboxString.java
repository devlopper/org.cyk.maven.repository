package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection de plusieurs chaine de caratères par checkbox.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectManyCheckboxString extends AbstractSelectManyCheckbox<String> {

}
