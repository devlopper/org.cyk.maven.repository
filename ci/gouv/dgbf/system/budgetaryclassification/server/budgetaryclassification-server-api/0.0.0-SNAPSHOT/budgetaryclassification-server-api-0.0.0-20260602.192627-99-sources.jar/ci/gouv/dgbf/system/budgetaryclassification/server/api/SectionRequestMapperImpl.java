package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SectionDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T19:26:50+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SectionRequestMapperImpl implements SectionRequestMapper {

    @Override
    public SectionService.SectionCreateRequestDto mapCreate(SectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SectionService.SectionCreateRequestDto sectionCreateRequestDto = new SectionService.SectionCreateRequestDto();

        sectionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        sectionCreateRequestDto.setCode( arg0.getCode() );
        sectionCreateRequestDto.setName( arg0.getName() );

        return sectionCreateRequestDto;
    }

    @Override
    public SectionService.SectionUpdateRequestDto mapUpdate(SectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SectionService.SectionUpdateRequestDto sectionUpdateRequestDto = new SectionService.SectionUpdateRequestDto();

        sectionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        sectionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        sectionUpdateRequestDto.setCode( arg0.getCode() );
        sectionUpdateRequestDto.setName( arg0.getName() );

        return sectionUpdateRequestDto;
    }
}
