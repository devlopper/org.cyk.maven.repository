package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverType;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ReceiverType}.
 *
 * @author Christian
 *
 */
@Dependent
public class ReceiverTypeSelectOneController
    extends AbstractSelectOneEnumerationController<ReceiverType> {

  /**
   * Cette méthode permet de construire.
   */
  protected ReceiverTypeSelectOneController() {
    super(ReceiverType.values());
    outputLableValue = "Type de destinataire";
  }
}

