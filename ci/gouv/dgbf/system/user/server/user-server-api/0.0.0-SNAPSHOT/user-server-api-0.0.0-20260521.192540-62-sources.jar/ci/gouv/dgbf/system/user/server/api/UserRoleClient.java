package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleCreateManyRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link UserRoleService}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class UserRoleClient extends AbstractClient<UserRoleService>
    implements GetByIdentifier<UserRoleDto>, GetMany<UserRoleGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public UserRoleClient service(UserRoleService service) {
    return (UserRoleClient) super.service(service);
  }

  /**
   * {@link UserRoleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(UserRoleCreateRequestDto request) {
    return new CreateExecutor(UserRoleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link UserRoleService#create}.
   *
   * @param name           nom
   * @param userIdentifier identifiant utilisateur
   * @param roleIdentifier identifiant rôle
   * @param auditWho       audit acteur
   * @param auditSession   audit session
   * @return réponse
   */
  public CreateResponseDto create(String name, String userIdentifier, String roleIdentifier,
                                  String auditWho, String auditSession) {
    UserRoleCreateRequestDto request = new UserRoleCreateRequestDto();
    request.setName(name);
    request.setUserIdentifier(userIdentifier);
    request.setRoleIdentifier(roleIdentifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link UserRoleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public UserRoleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<UserRoleGetManyResponseDto>(UserRoleGetManyResponseDto.class,
        UserRoleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link UserRoleService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserRoleGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                            PageDto page,
                                            String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link UserRoleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public UserRoleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<UserRoleDto>(UserRoleDto.class, UserRoleService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link UserRoleService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public UserRoleDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                            String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link UserRoleService#getByIdentifier}.
   *
   * @param request requête
   * @return rôle utilisateur
   */
  public UserRoleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<UserRoleDto>(UserRoleDto.class,
        UserRoleService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link UserRoleService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserRoleDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
                                     String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link UserRoleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(UserRoleUpdateRequestDto request) {
    return new IdentifiableExecutor(UserRoleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link UserRoleService#update}.
   *
   * @param identifier     identifiant
   * @param name           nom
   * @param userIdentifier identifiant utilisateur
   * @param roleIdentifier identifiant rôle
   * @param auditWho       audit acteur
   * @param auditSession   audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String name, String userIdentifier,
                                        String roleIdentifier, String auditWho,
                                        String auditSession) {
    UserRoleUpdateRequestDto request = new UserRoleUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setUserIdentifier(userIdentifier);
    request.setRoleIdentifier(roleIdentifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link UserRoleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(UserRoleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link UserRoleService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link UserRoleService#createMany}.
   *
   * @param request requête
   * @return réponse
   */

  public UserRoleService.UserRoleCreateManyResponseDto createMany(
      UserRoleCreateManyRequestDto request) {
    return new GetOneExecutor<UserRoleService.UserRoleCreateManyResponseDto>(
        UserRoleService.UserRoleCreateManyResponseDto.class,
        UserRoleService.CREATE_MANY_IDENTIFIER)
        .setExpectedResponseStatusCode(Response.Status.CREATED.getStatusCode())
        .execute(() -> service().createMany(request));

  }
}
