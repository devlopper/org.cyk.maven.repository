package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MailLayoutDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link MailLayoutDto}.

    @author Christian
    """)
public interface MailLayoutRequestMapper
    extends RequestMapper<MailLayoutDto, MailLayoutCreateRequestDto,
        MailLayoutUpdateRequestDto> {

}
