package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FundGroupTypeDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FundGroupTypeDto}.

    @author akm
               """)
public interface FundGroupTypeRequestMapper extends RequestMapper<FundGroupTypeDto,
    FundGroupTypeCreateRequestDto, FundGroupTypeUpdateRequestDto> {

}
