package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+1.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateN1Dto extends HasTotalAmountToIntegrateN1 {

  /**
   * Identifiant json du montant total à intégrer pour l'année N+1.
   */
  String JSON_TOTAL_AMOUNT_TO_INTEGRATE_N1 = "montantTotalAIntegrerN1";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName