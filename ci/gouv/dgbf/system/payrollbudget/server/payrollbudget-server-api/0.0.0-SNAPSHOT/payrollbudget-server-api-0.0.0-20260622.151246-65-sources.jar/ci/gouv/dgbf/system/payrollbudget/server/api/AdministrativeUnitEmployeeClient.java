package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCalculateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateByFunctionaryRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeOffboardRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeRecordPayrollMovementsRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link AdministrativeUnitEmployeeService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class AdministrativeUnitEmployeeClient
    extends AbstractClient<AdministrativeUnitEmployeeService>
    implements GetByIdentifier<AdministrativeUnitEmployeeDto>,
    GetMany<AdministrativeUnitEmployeeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public AdministrativeUnitEmployeeClient service(AdministrativeUnitEmployeeService service) {
    return (AdministrativeUnitEmployeeClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitEmployeeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(AdministrativeUnitEmployeeCreateRequestDto request) {
    return new CreateExecutor(AdministrativeUnitEmployeeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#createByFunctionary}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByFunctionary(
      AdministrativeUnitEmployeeCreateByFunctionaryRequestDto request) {
    return new CreateExecutor(AdministrativeUnitEmployeeService.CREATE_BY_FUNCTIONARY_IDENTIFIER)
        .execute(() -> service().createByFunctionary(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitEmployeeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeGetManyResponseDto>(
        AdministrativeUnitEmployeeGetManyResponseDto.class,
        AdministrativeUnitEmployeeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitEmployeeGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitEmployeeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeDto>(AdministrativeUnitEmployeeDto.class,
        AdministrativeUnitEmployeeService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitEmployeeDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AdministrativeUnitEmployeeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitEmployeeDto>(AdministrativeUnitEmployeeDto.class,
        AdministrativeUnitEmployeeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AdministrativeUnitEmployeeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(AdministrativeUnitEmployeeUpdateRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitEmployeeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#offboard}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto offboard(AdministrativeUnitEmployeeOffboardRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitEmployeeService.OFFBOARD_IDENTIFIER)
        .execute(() -> service().offboard(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#cancelOffboard}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto cancelOffboard(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitEmployeeService.CANCEL_OFFBOARD_IDENTIFIER)
        .execute(() -> service().cancelOffboard(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitEmployeeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link AdministrativeUnitEmployeeService#calculate}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto calculate(AdministrativeUnitEmployeeCalculateRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitEmployeeService.CALCULATE_IDENTIFIER)
        .execute(() -> service().calculate(request));
  }

  /**
   * {@link AdministrativeUnitEmployeeService#recordPayrollMovements}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto recordPayrollMovements(
      AdministrativeUnitEmployeeRecordPayrollMovementsRequestDto request) {
    return new IdentifiableExecutor(
        AdministrativeUnitEmployeeService.RECORD_PAYROLL_MOVEMENTS_IDENTIFIER)
        .execute(() -> service().recordPayrollMovements(request));
  }

}
