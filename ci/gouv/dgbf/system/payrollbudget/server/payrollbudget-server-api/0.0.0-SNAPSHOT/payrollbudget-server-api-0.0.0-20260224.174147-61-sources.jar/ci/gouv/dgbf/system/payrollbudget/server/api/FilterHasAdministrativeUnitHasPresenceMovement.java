package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasAdministrativeUnitHasPresenceMovement
    extends HasAdministrativeUnitEmployeeHasPresenceMovement {

  /**
   * Cette méthode permet de mettre à jour a mouvement de présence.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAdministrativeUnitEmployeeHasPresenceMovement(FilterDto filter) {
    setIsAdministrativeUnitEmployeeHasPresenceMovement(
        AdministrativeUnitEmployeeHasPresenceMovementFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour a mouvement de présence de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAdministrativeUnitEmployeeHasPresenceMovement(FilterDto filter) {
    AdministrativeUnitEmployeeHasPresenceMovementFilter.set(filter,
        getIsAdministrativeUnitEmployeeHasPresenceMovement());
  }

}
