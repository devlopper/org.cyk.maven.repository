package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DomainDto}. Elle hérite des critères par code
 * (code, code exclu, codes exclus) ; le code exclu sert par exemple à retirer le Domaine réservé
 * {@code master} de la liste proposée en libre-service (TCH_UTI_715).
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DomainFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DomainFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DomainFilter() {
  }
}
