package ci.gouv.dgbf.system.sharing.server.api;

/**
 * Cette classe représente les codes de {@link Location}.
 *
 * @author Christian
 *
 */
public class LocationCode {

  private LocationCode() {

  }

  /**
   * Classification budgétaire.
   */
  public static final String BUDGETARY_CLASSIFICATION = "CLASSIFICATION_BUDGETAIRE";

  /**
   * Dossier.
   */
  public static final String FOLDER = "DOSSIER";

  /**
   * Utilisateur.
   */
  public static final String USER = "UTILISATEUR";
  
  /**
   * Tâche.
   */
  public static final String TASK = "TACHE";

  /**
   * Fichier.
   */
  public static final String FILE = "FICHIER";
}
