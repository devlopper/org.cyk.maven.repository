package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService.CategoryCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryService.CategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link CategoryDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link CategoryDto}.

    @author Christian
               """)
public interface CategoryRequestMapper
    extends RequestMapper<CategoryDto, CategoryCreateRequestDto, CategoryUpdateRequestDto> {

}
