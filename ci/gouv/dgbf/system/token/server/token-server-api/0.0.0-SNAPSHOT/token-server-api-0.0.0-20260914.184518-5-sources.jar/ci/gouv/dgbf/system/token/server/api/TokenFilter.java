package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasModuleIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TokenDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TokenFilter extends AbstractIdentifiableFilter
    implements FilterHasModuleIdentifier, FilterHasStatusCode, FilterHasStatusCodes {

  String moduleIdentifier;

  String statusCode;

  /**
   * Ensemble de codes de statut (ex. les statuts précédents du statut Révoqué, pour restreindre
   * la Liste des Jetons Révocables aux Jetons révocables — {@link TokenStatus#getPrevious()}).
   */
  Set<String> statusCodes;

  @Override
  protected void doInitialize(FilterDto filter) {
    updateModuleIdentifier(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterModuleIdentifier(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
  }
}
