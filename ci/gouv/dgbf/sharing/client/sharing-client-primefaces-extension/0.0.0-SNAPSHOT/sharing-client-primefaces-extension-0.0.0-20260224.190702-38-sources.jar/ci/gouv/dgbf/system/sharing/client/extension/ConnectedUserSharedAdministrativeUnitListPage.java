package ci.gouv.dgbf.system.sharing.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des unités administratives partagées de l'utilisateur
 * connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedAdministrativeUnitListPage
    extends AbstractConnectedUserSharedAdministrativeUnitListPage {
  
  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "connectedUserSharedAdministrativeUnitListPage";
  
  static final String PATH = "/private/resource/connecteduser/administrativesunits.xhtml";
}
