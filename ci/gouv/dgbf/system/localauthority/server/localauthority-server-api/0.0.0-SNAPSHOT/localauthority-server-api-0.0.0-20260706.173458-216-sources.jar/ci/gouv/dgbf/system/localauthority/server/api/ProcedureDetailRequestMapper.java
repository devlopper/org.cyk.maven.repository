package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailService.ProcedureDetailCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailService.ProcedureDetailUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcedureDetailDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ProcedureDetailDto}.

    @author Christian
               """)
public interface ProcedureDetailRequestMapper extends RequestMapper<ProcedureDetailDto,
    ProcedureDetailCreateRequestDto, ProcedureDetailUpdateRequestDto> {

}
