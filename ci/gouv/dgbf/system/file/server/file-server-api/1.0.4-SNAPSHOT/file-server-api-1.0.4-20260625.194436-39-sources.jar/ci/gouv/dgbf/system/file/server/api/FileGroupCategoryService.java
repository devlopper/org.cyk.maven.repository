package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link FileGroupCategoryDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FileGroupCategoryService.PATH)
@Tag(name = "Gestion des catégories de fichiers de groupes")
public interface FileGroupCategoryService extends SpecificService {

  /**
   * Chemin des services.
   */
  String PATH = "categories-fichiers-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une catégorie de fichier de groupe",
      description = "Ce service permet de créer une catégorie de fichier de groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileGroupCategoryCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface FileGroupCategorySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FileGroupDto}.
     *
     * @return identifiant de {@link FileGroupDto}
     */
    String getFileGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FileGroupDto}.
     *
     * @param fileGroupIdentifier identifiant de {@link FileGroupDto}
     */
    void setFileGroupIdentifier(String fileGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FileCategoryDto}.
     *
     * @return identifiant de {@link FileCategoryDto}
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de @link FileCategoryDto}.
     *
     * @param categoryIdentifier identifiant de @link FileCategoryDto}
     */
    void setCategoryIdentifier(String categoryIdentifier);

    /**
     * {@link FileGroupCategoryDto#JSON_FILE_GROUP_IDENTIFIER}.
     */
    String JSON_FILE_GROUP_IDENTIFIER = FileGroupCategoryDto.JSON_FILE_GROUP_IDENTIFIER;

    /**
     * {@link FileGroupCategoryDto#JSON_CATEGORY_IDENTIFIER}.
     */
    String JSON_CATEGORY_IDENTIFIER = FileGroupCategoryDto.JSON_CATEGORY_IDENTIFIER;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupCategoryCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements FileGroupCategorySaveRequestDto {
    @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
    private String fileGroupIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des rôles d'identités de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FileGroupCategoryGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileGroupCategoryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileGroupCategoryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une catégorie de fichier de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link FileGroupCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant"
          + " une catégorie de fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupCategoryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FileGroupCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une catégorie de fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FileGroupCategoryUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupCategoryUpdateRequestDto extends ByIdentifierRequestDto
      implements FileGroupCategorySaveRequestDto {
    @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
    private String fileGroupIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CATEGORIE_FICHIER_GROUPE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une catégorie de fichier de groupe")
  Response delete(DeleteOneRequestDto request);
}
