package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsConfirmedDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente un service de gestion de {@link FilesGroupDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FilesGroupService.PATH)
@Tag(name = "Gestion des groupes de fichiers")
public interface FilesGroupService extends SpecificService {

  /**
   * Chemin du service.
   */
  String PATH = "groupes";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface FilesGroupSaveRequestDto {

  }
  
  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_FICHIER";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un groupe de fichier.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un groupe de fichier",
      description = "Ce service permet de créer un groupe de fichier")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FilesGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements FilesGroupSaveRequestDto, HasIsConfirmedDto {
    
    @JsonbProperty(JSON_IS_CONFIRMED)
    private Boolean isConfirmed;
    
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_FICHIER";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des groupes de fichiers")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FilesGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<FilesGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FilesGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_FICHIER";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un groupe de fichier")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FilesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FilesGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_FICHIER";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FilesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FilesGroupUpdateRequestDto request);

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<FilesGroupStatus>, HasConfirmableDto {

    @JsonbProperty(JSON_STATUS)
    private FilesGroupStatus status;

    @JsonbProperty(JSON_CONFIRMABLE)
    private Boolean confirmable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link FilesGroupStatus}
     */
    public void initialize(FilesGroupStatus status) {
      this.status = status;
    }
  }
  
  /**
   * Identifiant du service de confirmation.
   */
  String CONFIRM_IDENTIFIER = "CONFIRMATION_GROUPE_FICHIER";

  /**
   * Chemin du service de confirmation.
   */
  String CONFIRM_PATH = "confirmation";

  /**
   * Cette méthode permet de confirmer {@link FilesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONFIRM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONFIRM_IDENTIFIER,
      description = "Ce service permet de confirmer")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FilesGroupConfirmResponseDto.class))})
  Response confirm(FilesGroupConfirmRequestDto request);

  /**
   * Cette classe représente la requête de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupConfirmRequestDto extends ByIdentifierRequestDto {

  }
  
  /**
   * Cette classe représente la réponse de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupConfirmResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de bascule de l'indicateur "Suppression en Cascade".
   */
  String UPDATE_CASCADE_ON_DELETE_IDENTIFIER = "MISE_A_JOUR_SUPPRESSION_EN_CASCADE_GROUPE_FICHIER";

  /**
   * Chemin du service de bascule de l'indicateur "Suppression en Cascade".
   */
  String UPDATE_CASCADE_ON_DELETE_PATH = "cascade";

  /**
   * Cette méthode permet de basculer l'indicateur "Suppression en Cascade" de
   * {@link FilesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_CASCADE_ON_DELETE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_CASCADE_ON_DELETE_IDENTIFIER,
      description = "Ce service permet de basculer l'indicateur \"Suppression en Cascade\"")
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = FilesGroupUpdateCascadeOnDeleteResponseDto.class))})
  Response updateCascadeOnDelete(FilesGroupUpdateCascadeOnDeleteRequestDto request);

  /**
   * Cette classe représente la requête de bascule de l'indicateur "Suppression en Cascade".
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupUpdateCascadeOnDeleteRequestDto extends ByIdentifierRequestDto {

    @NotNull
    @JsonbProperty(FilesGroupDto.JSON_CASCADE_ON_DELETE)
    private Boolean cascadeOnDelete;
  }

  /**
   * Cette classe représente la réponse de bascule de l'indicateur "Suppression en Cascade".
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupUpdateCascadeOnDeleteResponseDto extends IdentifiableResponseDto {

    @JsonbProperty(FilesGroupDto.JSON_CASCADE_ON_DELETE)
    private Boolean cascadeOnDelete;

    /**
     * Cette méthode permet d'initialiser la réponse à partir de l'indicateur.
     *
     * @param cascadeOnDelete indicateur "Suppression en Cascade"
     */
    public void initialize(Boolean cascadeOnDelete) {
      this.cascadeOnDelete = cascadeOnDelete;
    }
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FilesGroupUpdateRequestDto extends ByIdentifierRequestDto
      implements FilesGroupSaveRequestDto {

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_FICHIER";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un groupe de fichier")
  Response delete(DeleteOneRequestDto request);
  
  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_GROUPE_FICHIER";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir compte {@link FilesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);
}
