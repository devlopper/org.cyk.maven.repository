package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IdentitiesGroupDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = IdentitiesGroupService.PATH)
@Tag(name = "Gestion des groupes d'identité")
public interface IdentitiesGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_IDENTITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un groupe",
      description = "Ce service permet de créer un groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IdentitiesGroupCreateRequestDto request);

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface IdentitiesGroupSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir la suppression en cascade.
     *
     * @return suppression en cascade
     */
    Boolean getCascadeOnDelete();

    /**
     * Cette méthode permet d'assigner la suppression en cascade.
     *
     * @param cascadeOnDelete suppression en cascade
     */
    void setCascadeOnDelete(Boolean cascadeOnDelete);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentityDto}.
     *
     * @return identifiant de {@link IdentityDto}
     */
    String getIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link IdentityDto}.
     *
     * @param identityIdentifier identifiant de {@link IdentityDto}
     */
    void setIdentityIdentifier(String identityIdentifier);

    /**
     * Cette méthode permet d'obtenir le {@link Role} de {@link IdentityDto}.
     *
     * @return {@link Role} de {@link IdentityDto}
     */
    Role getIdentityRole();

    /**
     * Cette méthode permet d'assigner le {@link Role} de {@link IdentityDto}.
     *
     * @param identityRole {@link Role} de {@link IdentityDto}
     */
    void setIdentityRole(Role identityRole);

    /**
     * {@link IdentitiesGroupDto#JSON_CASCADE_ON_DELETE}.
     */
    String JSON_CASCADE_ON_DELETE = IdentitiesGroupDto.JSON_CASCADE_ON_DELETE;

    /**
     * {@link IdentitiesGroupDto#JSON_IDENTITY_IDENTIFIER}.
     */
    String JSON_IDENTITY_IDENTIFIER = IdentitiesGroupDto.JSON_IDENTITY_IDENTIFIER;

    /**
     * {@link IdentitiesGroupDto#JSON_IDENTITY_ROLE}.
     */
    String JSON_IDENTITY_ROLE = IdentitiesGroupDto.JSON_IDENTITY_ROLE;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentitiesGroupCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements IdentitiesGroupSaveRequestDto {

    @JsonbProperty(JSON_CASCADE_ON_DELETE)
    Boolean cascadeOnDelete;

    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    String identityIdentifier;

    @JsonbProperty(JSON_IDENTITY_ROLE)
    Role identityRole;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des types d'activités")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentitiesGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class IdentitiesGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentitiesGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentitiesGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentitiesGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_IDENTITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentitiesGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_IDENTITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IdentitiesGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentitiesGroupUpdateRequestDto extends ByIdentifierRequestDto
      implements IdentitiesGroupSaveRequestDto {

    @JsonbProperty(JSON_CASCADE_ON_DELETE)
    Boolean cascadeOnDelete;

    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    String identityIdentifier;

    @JsonbProperty(JSON_IDENTITY_ROLE)
    Role identityRole;
  }

  /**
   * Identifiant du service de mise à jour de {@link IdentityDto}.
   */
  String UPDATE_IDENTITY_IDENTIFIER = "MISE_A_JOUR_IDENTITE_GROUPE_IDENTITE";

  /**
   * Chemin du service de mise à jour de {@link IdentityDto}.
   */
  String UPDATE_IDENTITY_PATH = "identite";

  /**
   * Cette méthode permet de mettre à jour de {@link IdentityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_IDENTITY_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTITY_IDENTIFIER,
      description = "Ce service permet de mettre à jour une identité de groupe d'identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateIdentity(IdentitiesGroupUpdateIdentityRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de {@link IdentityDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentitiesGroupUpdateIdentityRequestDto extends ByIdentifierRequestDto {

    /**
     * Identifiant {@link IdentityDto}.
     */
    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    String identityIdentifier;

    /**
     * Identifiant JSON {@link #identityIdentifier}.
     */
    public static final String JSON_IDENTITY_IDENTIFIER =
        IdentitiesGroupDto.JSON_IDENTITY_IDENTIFIER;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_IDENTITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link IdentitiesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
