package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentGetManyResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentUpdateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de dépôt des pièces justificatives attendues pour un Type
 * de Réclamation (RG_REP_PCE_01, RG_REP_PCE_02).
 *
 * @author akm
 *
 */
@Dependent
public class ExpectedDocumentUploadController extends AbstractController {

  @Inject
  DocumentTypeGroupClient documentTypeGroupClient;

  @Inject
  DocumentGroupClient documentGroupClient;

  @Inject
  DocumentClient documentClient;

  @Inject
  FileClient fileClient;

  @Getter
  List<ExpectedDocument> expectedDocuments;

  /**
   * Cette méthode permet de constuire.
   */
  public ExpectedDocumentUploadController() {
    expectedDocuments = new ArrayList<>();
  }

  /**
   * Cette méthode permet de rafraichir la liste des pièces attendues à partir du groupe de types
   * de document du Type de Réclamation choisi. Une indisponibilité du module {@code documentation}
   * ne doit pas empêcher l'ouverture du dialogue de création/modification (RG_REP_PCE_01) : on se
   * contente de journaliser et de retomber sur une liste vide, comme {@link #resolveFile(String)}.
   *
   * @param typeGroupIdentifier identifiant du groupe de types de document attendu
   */
  public void refresh(String typeGroupIdentifier) {
    expectedDocuments.clear();
    if (typeGroupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentTypeGroupDto.JSON_TYPE_IDENTIFIER, DocumentTypeGroupDto.JSON_TYPE_AS_STRING);
    FilterDto filter = new FilterDto().addCriteria(DocumentTypeGroupDto.JSON_GROUP_IDENTIFIER,
        typeGroupIdentifier);
    DocumentTypeGroupGetManyResponseDto response;
    try {
      response = documentTypeGroupClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des pièces attendues pour le groupe " + typeGroupIdentifier + " en échec.",
          exception);
      return;
    }
    if (response != null && response.getDatas() != null) {
      response.getDatas().forEach(rattachement -> expectedDocuments.add(
          new ExpectedDocument(rattachement.getTypeIdentifier(), rattachement.getTypeAsString())));
    }
  }

  /**
   * Cette méthode permet de compléter la liste des pièces attendues (déjà rafraîchie via
   * {@link #refresh(String)}) avec les documents déjà déposés dans un dossier de pièces
   * existant -- utilisé à l'ouverture d'une réclamation existante en modification. Une
   * indisponibilité du module {@code documentation} ne doit pas empêcher cette ouverture : on se
   * contente de journaliser et de retomber sur la liste de pièces attendues sans documents déjà
   * déposés, comme {@link #refresh(String)}/{@link #resolveFile(String)}.
   *
   * @param groupIdentifier identifiant du dossier de pièces
   */
  public void loadExistingDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentDto.JSON_TYPE_IDENTIFIER, DocumentDto.JSON_FILE_IDENTIFIER);
    FilterDto filter =
        new FilterDto().addCriteria(DocumentDto.JSON_GROUP_IDENTIFIER, groupIdentifier);
    DocumentGetManyResponseDto response;
    try {
      response = documentClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des documents du dossier " + groupIdentifier + " en échec.", exception);
      return;
    }
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(document -> expectedDocuments.stream()
        .filter(expectedDocument -> expectedDocument.getTypeIdentifier()
            .equals(document.getTypeIdentifier()))
        .findFirst().ifPresent(expectedDocument -> {
          // Conservés pour permettre à syncDocuments(String) de distinguer une pièce déjà
          // persistée (à mettre à jour ou supprimer) d'une pièce nouvellement déposée (à
          // créer), et de détecter un remplacement de fichier (RG_REP_PCE_02).
          expectedDocument.setDocumentIdentifier(document.getIdentifier());
          expectedDocument.setOriginalFileIdentifier(document.getFileIdentifier());
          expectedDocument.setFileIdentifier(document.getFileIdentifier());
          FileDto file = resolveFile(document.getFileIdentifier());
          expectedDocument
              .setFileName(file == null ? document.getFileIdentifier() : file.getName());
        }));
  }

  /**
   * Cette méthode permet d'obtenir le fichier déjà déposé pour un document existant, à partir de
   * son identifiant -- une indisponibilité du module {@code file} ne doit pas empêcher l'ouverture
   * du dialogue de modification d'une réclamation existante (RG_REP_PCE_02 reste consultable/
   * modifiable même si son nom de fichier ne peut pas être affiché) : on se contente de
   * journaliser et de retomber sur l'identifiant brut du fichier (cf.
   * {@link #loadExistingDocuments}).
   *
   * @param fileIdentifier identifiant du fichier
   * @return le fichier, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private FileDto resolveFile(String fileIdentifier) {
    try {
      return fileClient.getByIdentifier(fileIdentifier,
          new ProjectionDto().addNames(FileDto.JSON_NAME), userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention du fichier " + fileIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de déposer un fichier pour une pièce attendue. La pièce concernée est
   * retrouvée via l'attribut {@code typeIdentifier} posé sur le composant ({@code p:fileUpload}
   * n'expose pas de variable EL implicite permettant de la passer autrement).
   *
   * @param event évènement de dépôt de fichier
   */
  public void upload(FileUploadEvent event) {
    String typeIdentifier =
        (String) event.getComponent().getAttributes().get(ATTRIBUTE_TYPE_IDENTIFIER);
    expectedDocuments.stream()
        .filter(document -> document.getTypeIdentifier().equals(typeIdentifier)).findFirst()
        .ifPresent(document -> {
          String fileIdentifier = fileClient.getIdentifierByBytesOrByCreate(
              event.getFile().getFileName(), event.getFile().getContent(), userIdentifier, null);
          document.setFileIdentifier(fileIdentifier);
          document.setFileName(event.getFile().getFileName());
        });
  }

  /**
   * Nom de l'attribut du composant {@code p:fileUpload} portant l'identifiant du type de document
   * concerné.
   */
  public static final String ATTRIBUTE_TYPE_IDENTIFIER = "typeIdentifier";

  /**
   * Cette méthode permet de retirer le fichier déposé pour une pièce attendue.
   *
   * @param document pièce attendue
   */
  public void remove(ExpectedDocument document) {
    document.setFileIdentifier(null);
    document.setFileName(null);
  }

  /**
   * Identifiant du processus métier transmis au module {@code documentation} (contexte
   * obligatoire, RG_DOC_GRP_01).
   */
  public static final String PROCESS_IDENTIFIER = "RECLAMATION_ELEMENTS_PAIE";

  /**
   * Identifiant du module source transmis au module {@code documentation}.
   */
  public static final String SOURCE_IDENTIFIER = "reclamation-elements-paie";

  /**
   * Identifiant de l'opération transmise au module {@code documentation}.
   */
  public static final String OPERATION_IDENTIFIER = "CREATION_RECLAMATION";

  /**
   * Cette méthode permet de créer le dossier de pièces ({@link DocumentGroupDto}) d'une
   * réclamation (RG_REP_PCE_02). La réclamation n'existe pas encore à cet instant (le dossier de
   * pièces est créé avant elle, pour disposer de son identifiant à la création) : l'identifiant
   * d'enregistrement transmis au module {@code documentation} est donc un identifiant de
   * corrélation généré ici, sans lien de clé étrangère (couplage faible, comme les autres
   * références inter-modules de la Réclamation).
   *
   * @param typeGroupIdentifier identifiant du groupe de types de document attendu
   * @return identifiant du dossier de pièces créé
   */
  public String createDocumentGroup(String typeGroupIdentifier) {
    DocumentGroupCreateRequestDto request = new DocumentGroupCreateRequestDto();
    request.setTypeGroupIdentifier(typeGroupIdentifier);
    request.setProcessIdentifier(PROCESS_IDENTIFIER);
    request.setSourceIdentifier(SOURCE_IDENTIFIER);
    request.setRecordIdentifier(UUID.randomUUID().toString());
    request.setOperationIdentifier(OPERATION_IDENTIFIER);
    request.setAuditWho(userIdentifier);
    CreateResponseDto response = documentGroupClient.create(request);
    return response.getIdentifier();
  }

  /**
   * Cette méthode permet de créer, dans le dossier de pièces, un document pour chaque pièce
   * attendue dont un fichier a été déposé.
   *
   * @param groupIdentifier identifiant du dossier de pièces
   */
  public void createDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    expectedDocuments.stream().filter(document -> document.getFileIdentifier() != null)
        .forEach(document -> {
          DocumentCreateRequestDto request = new DocumentCreateRequestDto();
          request.setTypeIdentifier(document.getTypeIdentifier());
          request.setGroupIdentifier(groupIdentifier);
          request.setFileIdentifier(document.getFileIdentifier());
          request.setAuditWho(userIdentifier);
          documentClient.create(request);
        });
  }

  /**
   * Cette méthode permet de synchroniser, en modification d'une réclamation existante, les
   * documents du dossier de pièces avec l'état courant des pièces attendues : création des
   * pièces nouvellement déposées, mise à jour de celles dont le fichier a été remplacé, et
   * suppression de celles retirées par l'utilisateur (RG_REP_PCE_02).
   *
   * @param groupIdentifier identifiant du dossier de pièces
   */
  public void syncDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    expectedDocuments.forEach(document -> {
      if (document.getDocumentIdentifier() == null) {
        if (document.getFileIdentifier() != null) {
          DocumentCreateRequestDto request = new DocumentCreateRequestDto();
          request.setTypeIdentifier(document.getTypeIdentifier());
          request.setGroupIdentifier(groupIdentifier);
          request.setFileIdentifier(document.getFileIdentifier());
          request.setAuditWho(userIdentifier);
          documentClient.create(request);
        }
      } else if (document.getFileIdentifier() == null) {
        documentClient.deleteByIdentifier(document.getDocumentIdentifier(), userIdentifier, null);
      } else if (!document.getFileIdentifier().equals(document.getOriginalFileIdentifier())) {
        DocumentUpdateRequestDto request = new DocumentUpdateRequestDto();
        request.setIdentifier(document.getDocumentIdentifier());
        request.setTypeIdentifier(document.getTypeIdentifier());
        request.setGroupIdentifier(groupIdentifier);
        request.setFileIdentifier(document.getFileIdentifier());
        request.setAuditWho(userIdentifier);
        documentClient.update(request);
      }
    });
  }

  /**
   * Cette classe représente une pièce attendue, avec le fichier éventuellement déposé.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ExpectedDocument {

    String typeIdentifier;
    String typeAsString;
    String fileIdentifier;
    String fileName;

    /**
     * Identifiant du document déjà persisté pour cette pièce (renseigné par
     * {@link #loadExistingDocuments(String)}), ou {@code null} si aucun document n'existe encore
     * en base pour cette pièce.
     */
    String documentIdentifier;

    /**
     * Identifiant du fichier tel que chargé depuis le document existant (renseigné par
     * {@link #loadExistingDocuments(String)}), utilisé par {@link #syncDocuments(String)} pour
     * détecter un remplacement de fichier.
     */
    String originalFileIdentifier;

    /**
     * Cette méthode permet de constuire.
     *
     * @param typeIdentifier identifiant du type de document attendu
     * @param typeAsString libellé du type de document attendu
     */
    public ExpectedDocument(String typeIdentifier, String typeAsString) {
      this.typeIdentifier = typeIdentifier;
      this.typeAsString = typeAsString;
    }
  }
}
