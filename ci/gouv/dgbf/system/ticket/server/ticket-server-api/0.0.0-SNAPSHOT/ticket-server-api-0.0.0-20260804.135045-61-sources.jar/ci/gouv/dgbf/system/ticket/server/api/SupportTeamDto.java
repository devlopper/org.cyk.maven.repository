package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un equipe support.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamDto extends AbstractIdentifiableAuditableDto
    implements HasUsersGroupIdentifierDto, HasUsersGroupAsStringDto {

  @JsonbProperty(JSON_USERS_GROUP_IDENTIFIER)
  private String usersGroupIdentifier;

  @JsonbProperty(JSON_USERS_GROUP_AS_STRING)
  private String usersGroupAsString;

  /**
   * Nombre maximal de prises en charge par support.
   */
  @JsonbProperty(JSON_MAX_CLAIMS_PER_SUPPORT)
  private Integer maxClaimsPerSupport;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idServiceSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "serviceSupportChaine";

  /**
   * Identifiant json champ {@link #maxClaimsPerSupport}.
   */
  public static final String JSON_MAX_CLAIMS_PER_SUPPORT = "nombreMaximalPrisesEnChargeParSupport";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "service support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "services support";

}
