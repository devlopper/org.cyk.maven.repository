package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCategoryIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasGroupIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeFromDate;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeToDate;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ContextualConstantDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ContextualConstantFilter extends AbstractIdentifiableFilter
    implements FilterHasCategoryIdentifier, FilterHasGroupIdentifier,
    FilterHasLocalDateTimeFromDate, FilterHasLocalDateTimeToDate {

  private String categoryIdentifier;
  
  private String groupIdentifier;
  
  private LocalDateTime fromDate;
  
  private LocalDateTime toDate;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ContextualConstantFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ContextualConstantFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateCategoryIdentifier(filter);
    updateGroupIdentifier(filter);
    updateFromDate(filter);
    updateToDate(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterCategoryIdentifier(filter);
    updateFilterGroupIdentifier(filter);
    updateFilterFromDate(filter);
    updateFilterToDate(filter);
  }
}
