package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'utilisateur groupe.
 *
 * @author Christian
 */
public interface FilterHasUserGroupIdentifier extends HasUserGroupIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'utilisateur groupe.
   *
   * @param filter {@link FilterDto}
   */
  default void updateUserGroupIdentifier(FilterDto filter) {
    setUserGroupIdentifier(UserGroupIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'utilisateur groupe de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterUserGroupIdentifier(FilterDto filter) {
    UserGroupIdentifierFilter.set(filter, getUserGroupIdentifier());
  }

}
