package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamExpertiseService.SupportTeamExpertiseCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamExpertiseService.SupportTeamExpertiseGetManyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamExpertiseService.SupportTeamExpertiseUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SupportTeamExpertiseService}.
 *
 * @author kimou
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupportTeamExpertiseClient extends AbstractClient<SupportTeamExpertiseService>
    implements GetByIdentifier<SupportTeamExpertiseDto>,
               GetMany<SupportTeamExpertiseGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SupportTeamExpertiseClient service(SupportTeamExpertiseService service) {
    return (SupportTeamExpertiseClient) super.service(service);
  }

  /**
   * {@link SupportTeamExpertiseService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SupportTeamExpertiseCreateRequestDto request) {
    return new CreateExecutor(SupportTeamExpertiseService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SupportTeamExpertiseService#create}.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    SupportTeamExpertiseCreateRequestDto request = new SupportTeamExpertiseCreateRequestDto();
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link SupportTeamExpertiseService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamExpertiseGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SupportTeamExpertiseGetManyResponseDto>(
      SupportTeamExpertiseGetManyResponseDto.class,
        SupportTeamExpertiseService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SupportTeamExpertiseService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamExpertiseGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SupportTeamExpertiseService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamExpertiseDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupportTeamExpertiseDto>(SupportTeamExpertiseDto.class,
        SupportTeamExpertiseService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SupportTeamExpertiseService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SupportTeamExpertiseDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SupportTeamExpertiseService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SupportTeamExpertiseDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupportTeamExpertiseDto>(SupportTeamExpertiseDto.class,
        SupportTeamExpertiseService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SupportTeamExpertiseService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamExpertiseDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SupportTeamExpertiseService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SupportTeamExpertiseUpdateRequestDto request) {
    return new IdentifiableExecutor(SupportTeamExpertiseService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SupportTeamExpertiseService#update}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    SupportTeamExpertiseUpdateRequestDto request = new SupportTeamExpertiseUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link SupportTeamExpertiseService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SupportTeamExpertiseService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SupportTeamExpertiseService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
