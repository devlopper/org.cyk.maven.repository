package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente une icône.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Icon {
  
  String value;
  
  Style style;
  
  boolean isPositionedAtRight;

  Style style() {
    if (style == null) {
      style = new Style();
    }
    return style;
  }
  
  /**
   * {@link Style#getClassesAsString(Style)}.
   *
   * @return classes du style
   */
  public String getStyleClass() {
    return Style.getClassesAsString(style);
  }
  
  /**
   * Cette méthode permet d'assigner la classe du style.
   *
   * @param styleClass classe du style.
   */
  public void setStyleClass(String styleClass) {
    style().setClasses(styleClass);
  }
  
  /**
   * Cette classe représente un constructeur de {@link Icon}.
   *
   * @author Christian
   *
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {
    String value;
    String style;
    boolean isPositionedAtRight;

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Icon}
     */
    public Icon build() {
      return instantiate(value, isPositionedAtRight);
    }

    /**
     * Cette méthode permet d'instantier.
     *
     * @param value valeur
     * @param isPositionedAtRight est positionnée à droite si vrai sinon à gauche
     * @return {@link Icon}
     */
    public static Icon instantiate(String value, boolean isPositionedAtRight) {
      Icon text = new Icon();
      text.value = value;
      text.isPositionedAtRight = isPositionedAtRight;
      return text;
    }
  }
}
