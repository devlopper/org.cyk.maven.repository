package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'unité
 * administrative de budget.
 *
 * @author Christian
 */
public interface HasBudgetAdministrativeUnitAsStringDto
    extends HasBudgetAdministrativeUnitAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'unité administrative de
   * budget.
   */
  String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeBudgetChaine";
}
