package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN2AsString {

  /**
   * Obtient le montant total à arbitrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant total à arbitrer pour l'année N+2 sous forme de chaîne de caractères
   */
  String getTotalAmountToArbitrateN2AsString();

  /**
   * Définit le montant total à arbitrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param totalAmountToArbitrateN2AsString le montant total à arbitrer pour l'année N+2 sous forme
   *        de chaîne de caractères
   */
  void setTotalAmountToArbitrateN2AsString(String totalAmountToArbitrateN2AsString);

  /**
   * Identifiant java du montant total à arbitrer pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N2_AS_STRING = "totalAmountToArbitrateN2AsString";
}
