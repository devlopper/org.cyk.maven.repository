package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de bailleur.
 *
 * @author Christian
 */
public interface HasLessorAsStringDto extends HasLessorAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la bailleur.
   */
  String JSON_LESSOR_AS_STRING = "bailleurChaine";
}
