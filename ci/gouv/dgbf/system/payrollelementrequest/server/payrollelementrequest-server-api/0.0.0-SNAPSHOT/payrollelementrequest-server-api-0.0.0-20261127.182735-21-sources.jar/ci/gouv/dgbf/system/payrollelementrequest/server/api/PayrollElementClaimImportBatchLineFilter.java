package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasFunctionaryRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimImportBatchLineDto}. Implémente
 * {@link FilterHasFunctionaryRegistrationNumber} pour une recherche par matricule.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimImportBatchLineFilter extends AbstractIdentifiableFilter
    implements FilterHasFunctionaryRegistrationNumber {

  /**
   * Matricule.
   */
  String functionaryRegistrationNumber;

  /**
   * Identifiant du Lot d'Import, {@code null} pour tous les Lots de la période.
   */
  String importBatchIdentifier;

  /**
   * Premier jour du mois de la période de son Lot, {@code null} pour ne pas filtrer dessus.
   */
  LocalDate period;

  /**
   * Type de FUR de son Lot, {@code null} pour ne pas filtrer dessus.
   */
  String furType;

  /**
   * Version de la ligne : d'origine ou finale.
   */
  String version;

  /**
   * {@code true} pour les lignes qui ont produit une réclamation, {@code false} pour celles qui
   * n'en ont produit aucune, {@code null} pour toutes.
   */
  Boolean hasClaim;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementClaimImportBatchLineFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementClaimImportBatchLineFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    importBatchIdentifier = getImportBatchIdentifier(filter);
    period = getPeriod(filter);
    furType = getFurType(filter);
    version = getVersion(filter);
    hasClaim = getHasClaim(filter);
    updateFunctionaryRegistrationNumber(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setImportBatchIdentifier(filter, importBatchIdentifier);
    setPeriod(filter, period);
    setFurType(filter, furType);
    setVersion(filter, version);
    setHasClaim(filter, hasClaim);
    updateFilterFunctionaryRegistrationNumber(filter);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Lot d'Import.
   *
   * @param filter filtre
   * @param importBatchIdentifier identifiant du Lot d'Import
   */
  public static void setImportBatchIdentifier(FilterDto filter, String importBatchIdentifier) {
    set(filter, JSON_IMPORT_BATCH_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(importBatchIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Lot d'Import.
   *
   * @param filter filtre
   * @return identifiant du Lot d'Import
   */
  public static String getImportBatchIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IMPORT_BATCH_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner la période du Lot.
   *
   * @param filter filtre
   * @param period premier jour du mois de la période
   */
  public static void setPeriod(FilterDto filter, LocalDate period) {
    set(filter, JSON_PERIOD, f -> f.getValueAsDate(), f -> f.setValueAsDate(period));
  }

  /**
   * Cette méthode permet d'obtenir la période du Lot.
   *
   * @param filter filtre
   * @return premier jour du mois de la période
   */
  public static LocalDate getPeriod(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsDateByName(JSON_PERIOD));
  }

  /**
   * Cette méthode permet d'assigner le type de FUR du Lot.
   *
   * @param filter filtre
   * @param furType type de FUR
   */
  public static void setFurType(FilterDto filter, String furType) {
    set(filter, JSON_FUR_TYPE, f -> f.getValueAsString(), f -> f.setValueAsString(furType));
  }

  /**
   * Cette méthode permet d'obtenir le type de FUR du Lot.
   *
   * @param filter filtre
   * @return type de FUR
   */
  public static String getFurType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUR_TYPE));
  }

  /**
   * Cette méthode permet d'assigner la version de la ligne.
   *
   * @param filter filtre
   * @param version version
   */
  public static void setVersion(FilterDto filter, String version) {
    set(filter, JSON_VERSION, f -> f.getValueAsString(), f -> f.setValueAsString(version));
  }

  /**
   * Cette méthode permet d'obtenir la version de la ligne.
   *
   * @param filter filtre
   * @return version
   */
  public static String getVersion(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_VERSION));
  }

  /**
   * Cette méthode permet d'assigner la présence d'une réclamation générée.
   *
   * @param filter filtre
   * @param hasClaim {@code true} pour les lignes qui ont produit une réclamation
   */
  public static void setHasClaim(FilterDto filter, Boolean hasClaim) {
    set(filter, JSON_HAS_CLAIM, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(hasClaim));
  }

  /**
   * Cette méthode permet d'obtenir la présence d'une réclamation générée.
   *
   * @param filter filtre
   * @return présence d'une réclamation
   */
  public static Boolean getHasClaim(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_HAS_CLAIM));
  }

  /**
   * Identifiant json champ {@link #importBatchIdentifier}.
   */
  public static final String JSON_IMPORT_BATCH_IDENTIFIER =
      PayrollElementClaimImportBatchLineDto.JSON_IMPORT_BATCH_IDENTIFIER;

  /**
   * Identifiant json champ {@link #period}.
   */
  public static final String JSON_PERIOD = FurPeriodLineDto.JSON_PERIOD;

  /**
   * Identifiant json champ {@link #furType}.
   */
  public static final String JSON_FUR_TYPE = FurPeriodLineDto.JSON_FUR_TYPE;

  /**
   * Identifiant json champ {@link #version}.
   */
  public static final String JSON_VERSION = PayrollElementClaimImportBatchLineDto.JSON_VERSION;

  /**
   * Identifiant json champ {@link #hasClaim}.
   */
  public static final String JSON_HAS_CLAIM = "avecReclamation";
}
