package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un utilisateur.
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserRoleDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Identifiant de {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_IDENTIFIER)
  private String roleIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_AS_STRING)
  private String roleAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUserRole";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "roleUtilisateurChaine";

  /**
   * Identifiant champ java {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #userAsString}.
   */
  public static final String JSON_USER_AS_STRING = UserDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = RoleDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #roleAsString}.
   */
  public static final String JSON_ROLE_AS_STRING = RoleDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "role utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "roles utilisateurs";
}
