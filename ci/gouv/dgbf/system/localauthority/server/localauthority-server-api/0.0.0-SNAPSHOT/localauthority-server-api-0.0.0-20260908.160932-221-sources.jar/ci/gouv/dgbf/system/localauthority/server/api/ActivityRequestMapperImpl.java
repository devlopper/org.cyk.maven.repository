package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ActivityDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-08T16:10:22+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ActivityRequestMapperImpl implements ActivityRequestMapper {

    @Override
    public ActivityService.ActivityCreateRequestDto mapCreate(ActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityService.ActivityCreateRequestDto activityCreateRequestDto = new ActivityService.ActivityCreateRequestDto();

        activityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityCreateRequestDto.setName( arg0.getName() );
        activityCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        activityCreateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );
        activityCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        activityCreateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        activityCreateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        activityCreateRequestDto.setBeneficiaryIdentifier( arg0.getBeneficiaryIdentifier() );
        activityCreateRequestDto.setExpertiseDomainIdentifier( arg0.getExpertiseDomainIdentifier() );
        if ( arg0.getAmount() != null ) {
            activityCreateRequestDto.setAmount( arg0.getAmount() );
        }
        activityCreateRequestDto.setCategoryEnum( arg0.getCategoryEnum() );
        activityCreateRequestDto.setDescription( arg0.getDescription() );
        activityCreateRequestDto.setJustification( arg0.getJustification() );
        activityCreateRequestDto.setReferencedActivityIdentifier( arg0.getReferencedActivityIdentifier() );
        activityCreateRequestDto.setPndReference( arg0.getPndReference() );
        activityCreateRequestDto.setEventualReference( arg0.getEventualReference() );
        activityCreateRequestDto.setPriority( arg0.getPriority() );
        if ( arg0.getGuaranteeRetention() != null ) {
            activityCreateRequestDto.setGuaranteeRetention( arg0.getGuaranteeRetention() );
        }
        activityCreateRequestDto.setYearBudgetBeforeCarryover( arg0.getYearBudgetBeforeCarryover() );
        activityCreateRequestDto.setPlannedPaymentYear( arg0.getPlannedPaymentYear() );
        activityCreateRequestDto.setDuration( arg0.getDuration() );
        activityCreateRequestDto.setExpectedImpact( arg0.getExpectedImpact() );
        activityCreateRequestDto.setObservation( arg0.getObservation() );

        return activityCreateRequestDto;
    }

    @Override
    public ActivityService.ActivityUpdateRequestDto mapUpdate(ActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityService.ActivityUpdateRequestDto activityUpdateRequestDto = new ActivityService.ActivityUpdateRequestDto();

        activityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        activityUpdateRequestDto.setName( arg0.getName() );
        activityUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        activityUpdateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );
        activityUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        activityUpdateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        activityUpdateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        activityUpdateRequestDto.setBeneficiaryIdentifier( arg0.getBeneficiaryIdentifier() );
        if ( arg0.getAmount() != null ) {
            activityUpdateRequestDto.setAmount( arg0.getAmount() );
        }
        activityUpdateRequestDto.setCategoryEnum( arg0.getCategoryEnum() );
        activityUpdateRequestDto.setDescription( arg0.getDescription() );
        activityUpdateRequestDto.setJustification( arg0.getJustification() );
        activityUpdateRequestDto.setReferencedActivityIdentifier( arg0.getReferencedActivityIdentifier() );
        activityUpdateRequestDto.setPndReference( arg0.getPndReference() );
        activityUpdateRequestDto.setEventualReference( arg0.getEventualReference() );
        activityUpdateRequestDto.setExpertiseDomainIdentifier( arg0.getExpertiseDomainIdentifier() );
        if ( arg0.getGuaranteeRetention() != null ) {
            activityUpdateRequestDto.setGuaranteeRetention( arg0.getGuaranteeRetention() );
        }
        activityUpdateRequestDto.setYearBudgetBeforeCarryover( arg0.getYearBudgetBeforeCarryover() );
        activityUpdateRequestDto.setPlannedPaymentYear( arg0.getPlannedPaymentYear() );
        activityUpdateRequestDto.setDuration( arg0.getDuration() );
        activityUpdateRequestDto.setExpectedImpact( arg0.getExpectedImpact() );
        activityUpdateRequestDto.setObservation( arg0.getObservation() );
        activityUpdateRequestDto.setPriority( arg0.getPriority() );

        return activityUpdateRequestDto;
    }
}
