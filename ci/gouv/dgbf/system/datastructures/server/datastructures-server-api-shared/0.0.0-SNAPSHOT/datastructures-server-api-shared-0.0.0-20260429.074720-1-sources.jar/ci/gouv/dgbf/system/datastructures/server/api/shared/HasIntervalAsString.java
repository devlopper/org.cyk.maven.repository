package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'intervalle.
 *
 * @author Christian
 */
public interface HasIntervalAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'intervalle.
   *
   * @return représentation en chaine de caractères de l'intervalle
   */
  String getIntervalAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'intervalle.
   *
   * @param asString représentation en chaine de caractères de l'intervalle
   */
  void setIntervalAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'intervalle.
   */
  String FIELD_INTERVAL_AS_STRING = "intervalAsString";
}
