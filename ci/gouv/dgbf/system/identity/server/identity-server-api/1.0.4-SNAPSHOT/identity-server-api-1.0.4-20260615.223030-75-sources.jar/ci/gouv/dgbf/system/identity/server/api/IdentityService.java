package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Path(IdentityService.PATH)
@Tag(name = "Gestion des identités")
public interface IdentityService extends Service {

  /**
   * Chemin du service de gestion des identités.
   */
  String PATH = "identites";

  /**
   * Cette interface représente une requête de déclaration d'identité.
   *
   * @author Christian
   *
   */
  interface IdentityDeclareRequest {

    /**
     * Cette méthode permet d'obtenir le nom.
     *
     * @return nom
     */
    String getFirstName();

    /**
     * Cette méthode permet d'assigner le nom.
     *
     * @param firstName nom
     */
    void setFirstName(String firstName);

    /**
     * Cette méthode permet d'obtenir les prénoms.
     *
     * @return prénoms
     */
    String getLastNames();

    /**
     * Cette méthode permet d'assigner les prénoms.
     *
     * @param lastNames prénoms
     */
    void setLastNames(String lastNames);

    /**
     * Cette méthode permet d'obtenir l'adresse email.
     *
     * @return adresse email
     */
    String getEmailAddress();

    /**
     * Cette méthode permet d'assigner l'adresse email.
     *
     * @param emailAddress adresse email
     */
    void setEmailAddress(String emailAddress);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link GenderDto}.
     *
     * @return identifiant {@link GenderDto}
     */
    String getGenderIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link GenderDto}.
     *
     * @param genderIdentifier identifiant de {@link GenderDto}
     */
    void setGenderIdentifier(String genderIdentifier);

    /**
     * Cette méthode permet d'obtenir est masculin.
     *
     * @return est masculin
     */
    Boolean getIsGenderMasculine();

    /**
     * Cette méthode permet d'assigner est masculin.
     *
     * @param isGenderMasculine est masculin
     */
    void setIsGenderMasculine(Boolean isGenderMasculine);

    /**
     * Cette méthode permet d'obtenir la date de naissance.
     *
     * @return date de naissance
     */
    LocalDate getBirthDate();

    /**
     * Cette méthode permet d'assigner la date de naissance.
     *
     * @param birthDate date de naissance
     */
    void setBirthDate(LocalDate birthDate);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'unité administrative.
     *
     * @return identifiant de l'unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner lidentifiant de l'unité administrative.
     *
     * @param administrativeUnitIdentifier identifiant de l'unité administrative
     */
    void setAdministrativeUnitIdentifier(String administrativeUnitIdentifier);

    /**
     * Cette méthode permet d'assigner les attributes à partir d'une identité.
     *
     * @param identity identité
     */
    default void set(IdentityDto identity) {
      Core.runIfNotNull(identity, () -> {
        setFirstName(identity.getFirstName());
        setLastNames(identity.getLastNames());
        setEmailAddress(identity.getEmailAddress());
        setAdministrativeUnitIdentifier(identity.getAdministrativeUnitIdentifier());
      });
    }

    /**
     * {@link IdentityDto#JSON_FIRST_NAME}.
     */
    String JSON_FIRST_NAME = AbstractIdentityDto.JSON_FIRST_NAME;

    /**
     * {@link IdentityDto#JSON_LAST_NAMES}.
     */
    String JSON_LAST_NAMES = AbstractIdentityDto.JSON_LAST_NAMES;

    /**
     * {@link IdentityDto#JSON_EMAIL_ADDRESS}.
     */
    String JSON_EMAIL_ADDRESS = AbstractIdentityDto.JSON_EMAIL_ADDRESS;

    /**
     * {@link IdentityDto#JSON_GENDER_IDENTIFIER}.
     */
    String JSON_GENDER_IDENTIFIER = AbstractIdentityDto.JSON_GENDER_IDENTIFIER;

    /**
     * {@link IdentityDto#JSON_IS_MASCULINE}.
     */
    String JSON_IS_GENDER_MASCULINE = AbstractIdentityDto.JSON_IS_MASCULINE;

    /**
     * {@link IdentityDto#JSON_BIRTH_DATE}.
     */
    String JSON_BIRTH_DATE = AbstractIdentityDto.JSON_BIRTH_DATE;

    /**
     * {@link IdentityDto#JSON_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AbstractIdentityDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;
  }

  /**
   * Identifiant du service de déclaration d'une identité.
   */
  String DECLARE_IDENTIFIER = "DECLARATION_IDENTITE";

  /**
   * Chemin du service de déclaration d'une identité.
   */
  String DECLARE_PATH = "declaration";

  /**
   * Cette méthode permet de déclarer une identité.
   *
   * @param request la requête de déclaration d'une identité
   * @return la réponse de déclaration d'une identité
   */
  @Path(DECLARE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DECLARE_IDENTIFIER, summary = "Déclaration d'une identité",
      description = "Ce service permet de déclarer une identité")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  @APIResponse(responseCode = "400",
      content = {@Content(schema = @Schema(implementation = String.class))})
  Response declare(IdentityDeclareRequestDto request);

  /**
   * Cette classe représente la requête de déclaration.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityDeclareRequestDto extends AbstractAuditedRequestJsonDto
      implements IdentityDeclareRequest {

    @JsonbProperty(value = JSON_FIRST_NAME)
    private String firstName;

    @JsonbProperty(value = JSON_LAST_NAMES)
    private String lastNames;

    @JsonbProperty(value = JSON_EMAIL_ADDRESS)
    private String emailAddress;

    @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
    private String genderIdentifier;

    @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
    private Boolean isGenderMasculine;

    @JsonbProperty(value = JSON_BIRTH_DATE)
    private LocalDate birthDate;

    @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;
  }

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface IdentitySaveRequestDto extends IdentityDeclareRequest {

    /**
     * Cette méthode permet d'obtenir le matricule.
     *
     * @return matricule
     */
    String getRegistrationNumber();

    /**
     * Cette méthode permet d'assigner le matricule.
     *
     * @param registrationNumber matricule
     */
    void setRegistrationNumber(String registrationNumber);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RegistrationNumberGroupDto}.
     *
     * @return nom
     */
    String getRegistrationNumberGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link RegistrationNumberGroupDto}.
     *
     * @param registrationNumberGroupIdentifier identifiant de {@link RegistrationNumberGroupDto}
     */
    void setRegistrationNumberGroupIdentifier(String registrationNumberGroupIdentifier);

    /**
     * {@link IdentityDto#JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER}.
     */
    String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER =
        AbstractIdentityDto.JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER;

    /**
     * {@link IdentityDto#JSON_REGISTRATION_NUMBER}.
     */
    String JSON_REGISTRATION_NUMBER = AbstractIdentityDto.JSON_REGISTRATION_NUMBER;

    /**
     * {@link IdentityDto#JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION}.
     */
    String JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION =
        AbstractIdentityDto.JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION;
  }

  /**
   * Identifiant du service de création d'une identité.
   */
  String CREATE_IDENTIFIER = "CREATION_IDENTITE";

  /**
   * Chemin du service de création d'une identité.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer une identité.
   *
   * @param request la requête de création d'une identité
   * @return la réponse de création d'une identité
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une identité",
      description = "Ce service permet de créer une identité")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  @APIResponse(responseCode = "400",
      content = {@Content(schema = @Schema(implementation = String.class))})
  Response create(IdentityCreateRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityCreateRequestDto extends IdentityDeclareRequestDto
      implements IdentitySaveRequestDto {

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
    private String registrationNumberGroupIdentifier;

    @JsonbProperty(value = JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
    private Boolean isRegistrationNumberGroupPublicFunction;

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IDENTITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir des identités.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des identités")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class IdentityGetManyResponseDto extends AbstractGetByPageResponseDto<IdentityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_IDENTITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une identité")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IDENTITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link IdentityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "COMPTE_IDENTITE";

  /**
   * Chemin du service d'obtention du compte.
   */
  String GET_COUNT_PATH = "compte";

  /**
   * Cette méthode permet d'obtenir le compte de {@link IdentityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER,
      description = "Ce service permet d'obtenir le compte d'identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityDto.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_IDENTITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityUpdateRequestDto.class))})
  Response update(IdentityUpdateRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityUpdateRequestDto extends ByIdentifierRequestDto implements IdentitySaveRequestDto {

    @JsonbProperty(value = JSON_FIRST_NAME)
    private String firstName;

    @JsonbProperty(value = JSON_LAST_NAMES)
    private String lastNames;

    @JsonbProperty(value = JSON_EMAIL_ADDRESS)
    private String emailAddress;

    @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
    private String genderIdentifier;

    @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
    private Boolean isGenderMasculine;

    @JsonbProperty(value = JSON_BIRTH_DATE)
    private LocalDate birthDate;

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
    private String registrationNumberGroupIdentifier;

    @JsonbProperty(value = JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
    private Boolean isRegistrationNumberGroupPublicFunction;

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

    @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_IDENTITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link IdentityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une identité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'importation d'identité par matricule fonctionnaire.
   */
  String IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_IDENTIFIER =
      "IMPORTATION_PAR_MATRICULE_FONCTIONNAIRE_IDENTITE";

  /**
   * Chemin du service d'imporation d'identité par matricule fonctionnaire.
   */
  String IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_PATH = "importation-par-matricule-fonctionnaire";

  /**
   * Cette méthode permet d'importer une identité par matricule fonctionnaire.
   *
   * @param request requête
   * @return réponse
   */
  @Path(IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response importByFunctionaryRegistrationNumber(
      IdentityImportByFunctionaryRegistrationNumberRequestDto request);

  /**
   * Cette classe représente la requête d'importation d'identité par matricule fonctionnaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityImportByFunctionaryRegistrationNumberRequestDto
      extends AbstractAuditedRequestJsonDto {

    /**
     * {@link IdentityDto#getRegistrationNumber()}.
     */
    @NotNull
    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

    /**
     * {@link IdentityDto#JSON_REGISTRATION_NUMBER}.
     */
    public static final String JSON_REGISTRATION_NUMBER =
        AbstractIdentityDto.JSON_REGISTRATION_NUMBER;
  }

  /**
   * Identifiant du service d'importation de tout.
   */
  String IMPORT_ALL_IDENTIFIER = "IMPORTATION_TOUT_IDENTITE";

  /**
   * Chemin du service d'imporation de tout.
   */
  String IMPORT_ALL_PATH = "importation-tout";

  /**
   * Cette méthode permet d'importer tout.
   *
   * @param request requête
   * @return réponse
   */
  @Path(IMPORT_ALL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = IMPORT_ALL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = CreateManyResponseDto.class))})
  Response importAll(IdentityImportAllRequestDto request);

  /**
   * Cette classe représente la requête d'importation de tout.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityImportAllRequestDto extends AbstractAuditedRequestJsonDto {
  }
}
