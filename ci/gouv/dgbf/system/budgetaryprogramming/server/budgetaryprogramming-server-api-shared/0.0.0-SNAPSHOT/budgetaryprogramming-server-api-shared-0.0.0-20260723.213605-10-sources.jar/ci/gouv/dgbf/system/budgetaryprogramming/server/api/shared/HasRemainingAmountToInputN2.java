package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+2.
 *
 * @author Christian
 */
public interface HasRemainingAmountToInputN2 {

  /**
   * Obtient le montant restant à saisir pour l'année N+2.
   *
   * @return le montant restant à saisir pour l'année N+2
   */
  Long getRemainingAmountToInputN2();

  /**
   * Définit le montant restant à saisir pour l'année N+2.
   *
   * @param remainingAmountToInputN2 le montant restant à saisir pour l'année N+2
   */
  void setRemainingAmountToInputN2(Long remainingAmountToInputN2);

  /**
   * Identifiant java du montant restant à saisir pour l'année N+2.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N2 = "remainingAmountToInputN2";
}