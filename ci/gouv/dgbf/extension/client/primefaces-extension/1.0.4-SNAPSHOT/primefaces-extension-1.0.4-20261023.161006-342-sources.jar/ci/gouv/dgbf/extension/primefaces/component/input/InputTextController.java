package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;
import java.util.function.Consumer;

/**
 * Cette classe représente un contrôleur de d'entrée de texte.
 *
 * @author Christian
 *
 */
@Dependent
public class InputTextController extends AbstractInputController {

  /** Longueur maximale par défaut d'un libellé. */
  public static final int NAME_MAX_LENGTH = 255;

  /* Controls */

  protected InputText inputText;
  protected InputTextarea inputTextarea;

  /*------------------------------ Input Text ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputText}.
   *
   * @return {@link InputText}
   */
  public InputText getInputText() {
    if (!initialized) {
      Core.runIfNull(inputText, () -> inputText = instantiateInputText());
      initialized = true;
    }
    return inputText;
  }

  protected InputText instantiateInputText() {
    InputText input = new InputText();
    processInputText(input);
    processOutputLabel(input.outputLabel());
    input.computePlaceholderFromOutputLabelValue();
    return input;
  }

  protected void processInputText(InputText inputText) {
    processInput(inputText);
  }

  /*------------------------------ Input Text area ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputTextarea}.
   *
   * @return {@link InputTextarea}
   */
  public InputTextarea getInputTextarea() {
    if (!initialized) {
      Core.runIfNull(inputTextarea, () -> inputTextarea = instantiateInputTextarea());
      initialized = true;
    }
    return inputTextarea;
  }

  protected InputTextarea instantiateInputTextarea() {
    InputTextarea input = new InputTextarea();
    processInputTextarea(input);
    processOutputLabel(input.outputLabel());
    input.computePlaceholderFromOutputLabelValue();
    return input;
  }

  protected void processInputTextarea(InputTextarea inputTextarea) {
    processInput(inputTextarea);
  }

  /* Initialisation */

  /**
   * Cette méthode permet d'initialiser le champ pour la saisie d'un code.
   *
   * @param valueConsumer consommateur de la valeur.
   */
  public void initializeCode(Consumer<String> valueConsumer) {
    initializeInputText("Code", valueConsumer, true);
    getInputText().container().addStyleClass("dgbf-form-field-md");
  }

  /**
   * Cette méthode permet d'initialiser le champ pour la saisie d'un code dont la longueur maximale
   * est celle de la colonne du concept (elle varie d'un concept à l'autre : constitution-ui §3.9).
   * Sans cette longueur, le champ n'est pas borné et l'erreur n'apparaît qu'à l'enregistrement.
   *
   * @param valueConsumer consommateur de la valeur.
   * @param maxLength nombre maximal de caractères, celui de la colonne du concept.
   */
  public void initializeCode(Consumer<String> valueConsumer, int maxLength) {
    initializeCode(valueConsumer);
    getInputText().setMaxLength(maxLength);
  }

  /**
   * Cette méthode permet d'initialiser le champ pour la saisie d'un libellé.
   *
   * @param valueConsumer consommateur de la valeur.
   */
  public void initializeName(Consumer<String> valueConsumer) {
    initializeInputText("Libellé", valueConsumer, true);
    getInputText().setMaxLength(NAME_MAX_LENGTH);
    getInputText().container().addStyleClass("dgbf-form-field-wide");
  }
  
  /**
   * Cette méthode permet d'initialiser un champ de texte multiligne, sur toute la largeur.
   *
   * @param name libellé
   * @param valueConsumer consommateur de la valeur.
   * @param required obligatoire
   */
  public void initializeInputTextarea(String name, Consumer<String> valueConsumer,
      Boolean required) {
    outputLableValue = name;
    getInputTextarea().addValueConsumer(valueConsumer);
    getInputTextarea().setRequired(required);
    getInputTextarea().container().addStyleClass("dgbf-form-field-wide");
  }

  void initializeInputText(String name, Consumer<String> valueConsumer, Boolean required) {
    outputLableValue = name;
    getInputText().addValueConsumer(valueConsumer);
    getInputText().setRequired(required);
  }
}
