package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueSelectorFilterAttributeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueSelectorFilterAttributeDto}.

    @author Christian
               """)
public interface ValueSelectorFilterAttributeRequestMapper extends
    RequestMapper<ValueSelectorFilterAttributeDto, ValueSelectorFilterAttributeCreateRequestDto,
        ValueSelectorFilterAttributeUpdateRequestDto> {

}
