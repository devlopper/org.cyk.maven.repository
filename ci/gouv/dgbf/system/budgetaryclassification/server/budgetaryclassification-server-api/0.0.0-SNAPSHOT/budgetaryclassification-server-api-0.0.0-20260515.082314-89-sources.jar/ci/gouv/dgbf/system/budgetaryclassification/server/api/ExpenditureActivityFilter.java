package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExpenditureActivityDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ExpenditureActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ExpenditureNatureDto}.
   */
  private String natureIdentifier;

  /**
   * Identifiant {@link LocalityDto}.
   */
  private String localityIdentifier;

  /**
   * Code.
   */
  private String code;

  /**
   * Libellé.
   */
  private String name;


  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ExpenditureActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ExpenditureActivityFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    natureIdentifier = getNatureIdentifier(filter);
    localityIdentifier = getLocalityIdentifier(filter);
    code = getCode(filter);
    name = getName(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setNatureIdentifier(filter, natureIdentifier);
    setLocalityIdentifier(filter, localityIdentifier);
    setCode(filter, code);
    setName(filter, name);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ExpenditureNatureDto}.
   *
   * @param filter             filtre
   * @param natureIdentifier identifiant de {@link ExpenditureNatureDto}
   */
  public static void setNatureIdentifier(FilterDto filter, String natureIdentifier) {
    set(filter, JSON_NATURE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(natureIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ExpenditureNatureDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ExpenditureNatureDto}
   */
  public static String getNatureIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NATURE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LocalityDto}.
   *
   * @param filter         filtre
   * @param localityIdentifier identifiant de {@link LocalityDto}
   */
  public static void setLocalityIdentifier(FilterDto filter, String localityIdentifier) {
    set(filter, JSON_LOCALITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(localityIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LocalityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LocalityDto}
   */
  public static String getLocalityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCALITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code.
   *
   * @param filter         filtre
   * @param code code
   */
  public static void setCode(FilterDto filter, String code) {
    set(filter, JSON_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code.
   *
   * @param filter filtre
   * @return code
   */
  public static String getCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CODE));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter         filtre
   * @param name nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }



  /**
   * Identifiant json champ {@link #expenditureNatureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER = ExpenditureNatureDto.JSON_IDENTIFIER;

  /**
   * Identifiant json champ {@link #localityIdentifier}.
   */
  public static final String JSON_LOCALITY_IDENTIFIER = LocalityDto.JSON_IDENTIFIER;


  /**
   * Identifiant json champ {@link #code}.
   */
  public static final String JSON_CODE = "code";

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;


}
