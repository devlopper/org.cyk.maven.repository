package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayIndexDto}.
*
* @author AKM
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayIndexRequestMapperImpl implements PayIndexRequestMapper {

    @Override
    public PayIndexService.PayIndexCreateRequestDto mapCreate(PayIndexDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayIndexService.PayIndexCreateRequestDto payIndexCreateRequestDto = new PayIndexService.PayIndexCreateRequestDto();

        payIndexCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payIndexCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payIndexCreateRequestDto.setValue( arg0.getValue() );
        payIndexCreateRequestDto.setPayScaleIdentifier( arg0.getPayScaleIdentifier() );
        payIndexCreateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );
        payIndexCreateRequestDto.setGradeClassIdentifier( arg0.getGradeClassIdentifier() );
        payIndexCreateRequestDto.setEchelonIdentifier( arg0.getEchelonIdentifier() );

        return payIndexCreateRequestDto;
    }

    @Override
    public PayIndexService.PayIndexUpdateRequestDto mapUpdate(PayIndexDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayIndexService.PayIndexUpdateRequestDto payIndexUpdateRequestDto = new PayIndexService.PayIndexUpdateRequestDto();

        payIndexUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payIndexUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payIndexUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payIndexUpdateRequestDto.setValue( arg0.getValue() );
        payIndexUpdateRequestDto.setPayScaleIdentifier( arg0.getPayScaleIdentifier() );
        payIndexUpdateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );
        payIndexUpdateRequestDto.setGradeClassIdentifier( arg0.getGradeClassIdentifier() );
        payIndexUpdateRequestDto.setEchelonIdentifier( arg0.getEchelonIdentifier() );

        return payIndexUpdateRequestDto;
    }
}
