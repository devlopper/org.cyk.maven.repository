package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AdministrativeUnitService.AdministrativeUnitCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AdministrativeUnitService.AdministrativeUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link AdministrativeUnitDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link AdministrativeUnitDto}.

    @author stephane
               """)
public interface AdministrativeUnitRequestMapper extends RequestMapper<AdministrativeUnitDto,
    AdministrativeUnitCreateRequestDto, AdministrativeUnitUpdateRequestDto> {

}
