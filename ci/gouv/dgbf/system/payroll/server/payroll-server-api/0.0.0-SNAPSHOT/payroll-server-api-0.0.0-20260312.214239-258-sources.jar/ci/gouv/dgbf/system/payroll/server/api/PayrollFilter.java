package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollDto}.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
public class PayrollFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link PayrollPeriodGroupDto}.
   */
  String periodGroupIdentifier;

  /**
   * Identifiant de {@link PayrollTypeDto}.
   */
  String typeIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    periodGroupIdentifier = getPeriodGroupIdentifier(filter);
    typeIdentifier = getTypeIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setPeriodGroupIdentifier(filter, periodGroupIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de {@link PayrollPeriodGroupDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link PayrollPeriodGroupDto}
   */
  public static void setPeriodGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PERIOD_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link PayrollPeriodGroupDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link PayrollPeriodGroupDto}
   */
  public static String getPeriodGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PERIOD_GROUP_IDENTIFIER));
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de {@link PayrollTypeDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link PayrollTypeDto}
   */
  public static void setTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link PayrollTypeDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link PayrollTypeDto}
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #periodGroupIdentifier}.
   */
  public static final String JSON_PERIOD_GROUP_IDENTIFIER =
      PayrollPeriodGroupDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
      PayrollTypeDto.JSON_THIS_IDENTIFIER;
}
  
