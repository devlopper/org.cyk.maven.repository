package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représnte le libellé d'un composant.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class OutputLabel extends AbstractWidget {

  String value;
  
  String forId;
  
}
