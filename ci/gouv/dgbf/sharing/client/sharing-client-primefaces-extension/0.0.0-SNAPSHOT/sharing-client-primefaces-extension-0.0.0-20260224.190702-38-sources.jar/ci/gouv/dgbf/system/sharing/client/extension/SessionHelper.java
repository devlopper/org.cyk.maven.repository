package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingClient;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.servlet.http.HttpSession;

/**
 * Cette classe représente une aide de session.
 *
 * @author Christian
 *
 */
@Deprecated(forRemoval = true)
public class SessionHelper {

  private SessionHelper() {}

  /**
   * Cette méthode permet d'initialiser l'unité administrative.
   *
   * @param client {@link SharingClient}
   * @param userName Nom utilisateur
   * @param session {@link HttpSession}
   */
  public static void initializeAdministrativeUnit(SharingClient client, String userName,
      HttpSession session) {
    SharingDto administrativeUnit = client.getAdministrativeUnitByUserName(userName);
    if (administrativeUnit != null) {
      ResourceDto resource = new ResourceDto();
      resource.setIdentifier(administrativeUnit.getResourceReference());
      resource.setAsString(administrativeUnit.getResourceAsString());
      session.setAttribute(ADMINISTRATIVE_UNIT_IDENTIFIER_NAME, resource);
    }
  }

  /**
   * Identifiant de l'unité administrative.
   */
  public static final String ADMINISTRATIVE_UNIT_IDENTIFIER_NAME = "unite_administrative";
}
