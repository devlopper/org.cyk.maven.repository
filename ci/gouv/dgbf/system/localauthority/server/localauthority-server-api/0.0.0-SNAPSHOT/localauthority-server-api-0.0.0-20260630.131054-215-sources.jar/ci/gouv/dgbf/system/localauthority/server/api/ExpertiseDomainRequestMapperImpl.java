package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ExpertiseDomainDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-30T13:11:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ExpertiseDomainRequestMapperImpl implements ExpertiseDomainRequestMapper {

    @Override
    public ExpertiseDomainService.ExpertiseDomainCreateRequestDto mapCreate(ExpertiseDomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpertiseDomainService.ExpertiseDomainCreateRequestDto expertiseDomainCreateRequestDto = new ExpertiseDomainService.ExpertiseDomainCreateRequestDto();

        expertiseDomainCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        expertiseDomainCreateRequestDto.setCode( arg0.getCode() );
        expertiseDomainCreateRequestDto.setName( arg0.getName() );

        return expertiseDomainCreateRequestDto;
    }

    @Override
    public ExpertiseDomainService.ExpertiseDomainUpdateRequestDto mapUpdate(ExpertiseDomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpertiseDomainService.ExpertiseDomainUpdateRequestDto expertiseDomainUpdateRequestDto = new ExpertiseDomainService.ExpertiseDomainUpdateRequestDto();

        expertiseDomainUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        expertiseDomainUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        expertiseDomainUpdateRequestDto.setCode( arg0.getCode() );
        expertiseDomainUpdateRequestDto.setName( arg0.getName() );

        return expertiseDomainUpdateRequestDto;
    }
}
