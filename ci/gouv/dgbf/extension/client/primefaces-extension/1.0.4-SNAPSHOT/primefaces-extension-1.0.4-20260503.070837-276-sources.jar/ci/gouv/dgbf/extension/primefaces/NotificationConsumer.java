package ci.gouv.dgbf.extension.primefaces;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente un consommateur de notification.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class NotificationConsumer {
  private static final Logger LOGGER = Logger.getLogger(NotificationConsumer.class.getName());

  @Inject
  WebSocketController webSocketController;
  
  void observe(@Observes Notification notification) {
    webSocketController.send(notification.channel, notification.message);
    LOGGER.log(Level.FINEST, "Notification consommée. {0}", notification);
  }
  
}
