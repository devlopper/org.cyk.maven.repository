package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant intégré pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountN2AsStringDto extends HasIntegratedAmountN2AsString {

  /**
   * Identifiant json du montant intégré pour l'année N+2.
   */
  String JSON_INTEGRATED_AMOUNT_N2_AS_STRING = "montantIntegreN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName