package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link JobGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class JobGroupRequestMapperImpl implements JobGroupRequestMapper {

    @Override
    public JobGroupService.JobGroupCreateRequestDto mapCreate(JobGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobGroupService.JobGroupCreateRequestDto jobGroupCreateRequestDto = new JobGroupService.JobGroupCreateRequestDto();

        jobGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobGroupCreateRequestDto.setCode( arg0.getCode() );
        jobGroupCreateRequestDto.setName( arg0.getName() );
        jobGroupCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return jobGroupCreateRequestDto;
    }

    @Override
    public JobGroupService.JobGroupUpdateRequestDto mapUpdate(JobGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobGroupService.JobGroupUpdateRequestDto jobGroupUpdateRequestDto = new JobGroupService.JobGroupUpdateRequestDto();

        jobGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        jobGroupUpdateRequestDto.setCode( arg0.getCode() );
        jobGroupUpdateRequestDto.setName( arg0.getName() );
        jobGroupUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return jobGroupUpdateRequestDto;
    }
}
