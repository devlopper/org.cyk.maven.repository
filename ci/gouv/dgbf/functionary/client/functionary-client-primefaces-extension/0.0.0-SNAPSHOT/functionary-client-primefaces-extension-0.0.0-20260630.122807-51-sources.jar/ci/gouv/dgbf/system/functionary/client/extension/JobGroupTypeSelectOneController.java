package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupTypeClient;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupTypeDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupTypeService.JobGroupTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link JobGroupTypeDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class JobGroupTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    JobGroupTypeDto, JobGroupTypeGetManyResponseDto, JobGroupTypeClient> {

  @Getter
  @Inject
  JobGroupTypeClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected JobGroupTypeSelectOneController() {
    super(JobGroupTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
