package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptEvaluationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptEvaluationRequestMapperImpl implements ScriptEvaluationRequestMapper {

    @Override
    public ScriptEvaluationService.ScriptEvaluationCreateRequestDto mapCreate(ScriptEvaluationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptEvaluationService.ScriptEvaluationCreateRequestDto scriptEvaluationCreateRequestDto = new ScriptEvaluationService.ScriptEvaluationCreateRequestDto();

        scriptEvaluationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptEvaluationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptEvaluationCreateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptEvaluationCreateRequestDto.setArguments( stringStringMapToStringObjectMap( arg0.getArguments() ) );
        scriptEvaluationCreateRequestDto.setResultAsStringFormat( arg0.getResultAsStringFormat() );

        return scriptEvaluationCreateRequestDto;
    }

    @Override
    public ScriptEvaluationService.ScriptEvaluationUpdateRequestDto mapUpdate(ScriptEvaluationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptEvaluationService.ScriptEvaluationUpdateRequestDto scriptEvaluationUpdateRequestDto = new ScriptEvaluationService.ScriptEvaluationUpdateRequestDto();

        scriptEvaluationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptEvaluationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptEvaluationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptEvaluationUpdateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptEvaluationUpdateRequestDto.setArguments( stringStringMapToStringObjectMap( arg0.getArguments() ) );
        scriptEvaluationUpdateRequestDto.setResultAsStringFormat( arg0.getResultAsStringFormat() );

        return scriptEvaluationUpdateRequestDto;
    }

    protected Map<String, Object> stringStringMapToStringObjectMap(Map<String, String> map) {
        if ( map == null ) {
            return null;
        }

        Map<String, Object> map1 = new LinkedHashMap<String, Object>( Math.max( (int) ( map.size() / .75f ) + 1, 16 ) );

        for ( java.util.Map.Entry<String, String> entry : map.entrySet() ) {
            String key = entry.getKey();
            Object value = entry.getValue();
            map1.put( key, value );
        }

        return map1;
    }
}
