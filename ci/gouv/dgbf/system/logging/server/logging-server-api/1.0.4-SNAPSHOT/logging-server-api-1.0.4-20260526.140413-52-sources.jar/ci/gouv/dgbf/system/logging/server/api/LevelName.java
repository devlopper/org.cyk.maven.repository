package ci.gouv.dgbf.system.logging.server.api;

/**
 * Cette classe représenete les noms des niveaux.
 *
 * @author Christian
 *
 */
@Deprecated(forRemoval = true)
public class LevelName {

  private LevelName() {}

  /**
   * Erreur.
   */
  public static final String ERROR = "ERREUR";
  
  /**
   * Avertissement.
   */
  public static final String WARNING = "AVERTISSEMENT";
  
  /**
   * Information.
   */
  public static final String INFORMATION = "INFORMATION";
  
  /**
   * Configuration.
   */
  public static final String CONFIGURATION = "CONFIGURATION";
  
  /**
   * Deboggage.
   */
  public static final String DEBUG = "DEBOGGAGE";
  
  /**
   * Trace.
   */
  public static final String TRACE = "TRACE";
}