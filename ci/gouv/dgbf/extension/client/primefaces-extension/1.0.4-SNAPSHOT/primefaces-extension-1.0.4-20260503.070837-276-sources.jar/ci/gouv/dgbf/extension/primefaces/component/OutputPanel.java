package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représnte un conteneur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class OutputPanel extends AbstractWidget {
  
}
