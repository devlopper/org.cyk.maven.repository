package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;
import java.util.function.Consumer;

/**
 * Cette classe représente un contrôleur de d'entrée de texte.
 *
 * @author Christian
 *
 */
@Dependent
public class InputTextController extends AbstractInputController {

  /* Controls */

  protected InputText inputText;
  protected InputTextarea inputTextarea;

  /*------------------------------ Input Text ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputText}.
   *
   * @return {@link InputText}
   */
  public InputText getInputText() {
    if (!initialized) {
      Core.runIfNull(inputText, () -> inputText = instantiateInputText());
      initialized = true;
    }
    return inputText;
  }

  protected InputText instantiateInputText() {
    InputText input = new InputText();
    processInputText(input);
    processOutputLabel(input.outputLabel());
    input.computePlaceholderFromOutputLabelValue();
    return input;
  }

  protected void processInputText(InputText inputText) {
    processInput(inputText);
  }

  /*------------------------------ Input Text area ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputTextarea}.
   *
   * @return {@link InputTextarea}
   */
  public InputTextarea getInputTextarea() {
    if (!initialized) {
      Core.runIfNull(inputTextarea, () -> inputTextarea = instantiateInputTextarea());
      initialized = true;
    }
    return inputTextarea;
  }

  protected InputTextarea instantiateInputTextarea() {
    InputTextarea input = new InputTextarea();
    processInputTextarea(input);
    processOutputLabel(input.outputLabel());
    input.computePlaceholderFromOutputLabelValue();
    return input;
  }

  protected void processInputTextarea(InputTextarea inputTextarea) {
    processInput(inputTextarea);
  }

  /* Initialisation */

  /**
   * Cette méthode permet d'initialiser le champ pour la saisie d'un code.
   *
   * @param valueConsumer consommateur de la valeur.
   */
  public void initializeCode(Consumer<String> valueConsumer) {
    initializeInputText("Code", valueConsumer, true);
  }
  
  /**
   * Cette méthode permet d'initialiser le champ pour la saisie d'un libellé.
   *
   * @param valueConsumer consommateur de la valeur.
   */
  public void initializeName(Consumer<String> valueConsumer) {
    initializeInputText("Libellé", valueConsumer, true);
  }
  
  void initializeInputText(String name, Consumer<String> valueConsumer, Boolean required) {
    outputLableValue = name;
    getInputText().addValueConsumer(valueConsumer);
    getInputText().setRequired(required);
  }
}
