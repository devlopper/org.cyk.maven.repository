package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une archive de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileGroupArchiveDto extends AbstractIdentifiableAuditableDto {

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "archive de fichier de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

  /**
   * Identifiant du fichier de groupe maître.
   */
  @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
  private String fileGroupIdentifier;

  /**
   * Identifiant de l'auteur de début d'archivage.
   */
  @JsonbProperty(JSON_START_AUTHOR_IDENTIFIER)
  private String startAuthorIdentifier;

  /**
   * Date de début d'archivage.
   */
  @JsonbProperty(JSON_START_DATE)
  private LocalDateTime startDate;

  /**
   * Motif de début d'archivage.
   */
  @JsonbProperty(JSON_START_REASON)
  private String startReason;

  /**
   * Identifiant de la demande de début d'archivage.
   */
  @JsonbProperty(JSON_START_SOLICITATION_IDENTIFIER)
  private String startSolicitationIdentifier;

  /**
   * Identifiant de l'auteur de fin d'archivage.
   */
  @JsonbProperty(JSON_END_AUTHOR_IDENTIFIER)
  private String endAuthorIdentifier;

  /**
   * Date de fin d'archivage.
   */
  @JsonbProperty(JSON_END_DATE)
  private LocalDateTime endDate;

  /**
   * Motif de fin d'archivage.
   */
  @JsonbProperty(JSON_END_REASON)
  private String endReason;

  /**
   * Identifiant de la demande de fin d'archivage.
   */
  @JsonbProperty(JSON_END_SOLICITATION_IDENTIFIER)
  private String endSolicitationIdentifier;

  /**
   * Indique si l'archive est applicable.
   */
  @JsonbProperty(JSON_APPLICABLE)
  private Boolean applicable;

  /**
   * Indique si un retrait peut être demandé.
   */
  @JsonbProperty(JSON_WITHDRAWAL_REQUESTABLE)
  private Boolean withdrawalRequestable;

  /**
   * Indique si l'archive peut être désarchivée directement.
   */
  @JsonbProperty(JSON_DIRECT_UNARCHIVING_ALLOWED)
  private Boolean directUnarchivingAllowed;

  /**
   * Indique si un motif de voie directe de cette archive peut être corrigé.
   */
  @JsonbProperty(JSON_CORRECTABLE)
  private Boolean correctable;

  /**
   * Clé JSON de l'identifiant du fichier de groupe.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER = "identifiantFichierGroupe";

  /**
   * Clé JSON de l'identifiant de l'auteur de début.
   */
  public static final String JSON_START_AUTHOR_IDENTIFIER = "identifiantAuteurDebut";

  /**
   * Clé JSON de la date de début.
   */
  public static final String JSON_START_DATE = "dateDebut";

  /**
   * Clé JSON du motif de début.
   */
  public static final String JSON_START_REASON = "motifDebut";

  /**
   * Clé JSON de l'identifiant de la demande de début.
   */
  public static final String JSON_START_SOLICITATION_IDENTIFIER = "identifiantDemandeDebut";

  /**
   * Clé JSON de l'identifiant de l'auteur de fin.
   */
  public static final String JSON_END_AUTHOR_IDENTIFIER = "identifiantAuteurFin";

  /**
   * Clé JSON de la date de fin.
   */
  public static final String JSON_END_DATE = "dateFin";

  /**
   * Clé JSON du motif de fin.
   */
  public static final String JSON_END_REASON = "motifFin";

  /**
   * Clé JSON de l'identifiant de la demande de fin.
   */
  public static final String JSON_END_SOLICITATION_IDENTIFIER = "identifiantDemandeFin";

  /**
   * Clé JSON indiquant si l'archive est applicable.
   */
  public static final String JSON_APPLICABLE = "estApplicable";

  /**
   * Clé JSON indiquant si un retrait peut être demandé.
   */
  public static final String JSON_WITHDRAWAL_REQUESTABLE = "peutEtreDemandeRetrait";

  /**
   * Clé JSON indiquant si l'archive peut être désarchivée directement.
   */
  public static final String JSON_DIRECT_UNARCHIVING_ALLOWED = "peutEtreDesarchiveDirectement";

  /**
   * Clé JSON indiquant si un motif de voie directe peut être corrigé.
   */
  public static final String JSON_CORRECTABLE = "peutEtreCorrige";
}
