package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleRequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserRoleService;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link UserRoleDto}.
 *
 * @author Arnaud
 */
@Dependent
public class UserRoleController extends AbstractController {

  @Inject
  UserRoleClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  UserRoleFilterController filterController;

  @Inject
  UserRoleRequestMapper requestMapper;

  @Inject
  @Getter
  RoleSelectOneController roleSelectOneController;

  @Inject
  @Getter
  UserSelectOneController userSelectOneController;

  @Inject
  @Getter
  ListController applicationsListController;

  @Inject
  @Getter
  ListController usersListController;

  @Inject
  UserClient userClient;

  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;

  @Getter
  @Setter
  List<UserDto> selectedUsers;

  @Getter
  @Setter
  Map<String, Boolean> userSelectionMap = new HashMap<>();

  @Inject
  MessageManager messageManager;

  @Inject
  @Getter
  UserRoleCreateManyController createManyController;

  @Inject
  @Getter
  UserSelectManyController userSelectManyController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = UserRoleDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(UserRoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(UserRoleService.PATH);
    listController.setFilterController(filterController);

    listController.getDataTable().getFilterButton().setRendered(true);

    ProjectionDto projection =
        new ProjectionDto()
            .addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, UserRoleDto.JSON_USER_AS_STRING);

    projection.addNamesIfStringBlank(
        filterController.getFilter().getRoleIdentifier(), UserRoleDto.JSON_ROLE_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getShowCreateDialogButton().setRendered(true);

    listController.initialize();

    listController
        .getCreateController()
        .setFunction(
            entity -> {
              UserRoleCreateRequestDto request = requestMapper.mapCreate((UserRoleDto) entity);
              request.setAuditWho(userIdentifier);
              return client.create(request);
            });

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    UserRoleDto.JSON_ROLE_IDENTIFIER,
                    UserRoleDto.JSON_USER_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    userSelectOneController.getSelectOneMenu().setRequired(true);
    userSelectOneController.getSelectOneMenu().addValueConsumer(userIdentifierConsumer());

    roleSelectOneController.getSelectOneMenu().setRequired(true);
    roleSelectOneController.getSelectOneMenu().addValueConsumer(roleIdentifierConsumer());

    // Initialiser le ListController pour les utilisateurs
    initializeUsersListController();

    roleSelectManyController.setOutputLableValue("Rôles à assigner");
    roleSelectManyController.getSelectManyCheckbox().setRequired(true);
    roleSelectManyController.setChoicable(true);
    roleSelectManyController.getSelectManyCheckbox().setLayout("responsive");
    roleSelectManyController.getSelectManyCheckbox().setColumns(3);
    // Configurer pour afficher le code au lieu du nom
    ProjectionDto projectionRole = new ProjectionDto();
    projectionRole.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, AbstractIdentifiableCodableDto.JSON_CODE);
    roleSelectManyController.setProjection(projectionRole);
    roleSelectManyController.computeSelectManyCheckboxChoices();

  }

  /**
   * Cette méthode initialise le ListController pour les utilisateurs.
   */
  private void initializeUsersListController() {
    usersListController.setEntityClass(UserDto.class);
    usersListController.setClient(userClient);
    usersListController.setNotificationChannel(UserService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING,
        UserDto.JSON_DOMAIN_AS_STRING);

    usersListController.getReadController().setProjection(projection);
    usersListController.initialize();
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      userSelectOneController
          .getSelectOneMenu()
          .writeValue(((UserRoleDto) entity).getUserIdentifier());

      roleSelectOneController
          .getSelectOneMenu()
          .writeValue(((UserRoleDto) entity).getRoleIdentifier());
    };
  }

  Consumer<String> userIdentifierConsumer() {
    return identifier ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(UserRoleDto.class)
            .setUserIdentifier(identifier);
  }

  Consumer<String> roleIdentifierConsumer() {
    return identifier ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(UserRoleDto.class)
            .setRoleIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      UserRoleUpdateRequestDto request = requestMapper.mapUpdate((UserRoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(
            userSelectOneController.getSelectOneMenu(), roleSelectOneController.getSelectOneMenu())
        .stream()
        .map(input -> input.getMessage().getIdentifier())
        .collect(Collectors.joining(","));
  }

  /**
   * Cette méthode permet de créer plusieurs rôles pour plusieurs utilisateurs.
   */
  public void createMany() {
    // Récupérer les utilisateurs sélectionnés
    Set<String> selectedUserIds =
        userSelectionMap.entrySet().stream()
            .filter(Map.Entry::getValue)
            .map(Map.Entry::getKey)
            .collect(Collectors.toSet());
    // Récupérer les rôles sélectionnés
    Set<String> selectedRoleIds =
        new HashSet<>(roleSelectManyController.getSelectManyCheckbox().getValue());
    UserRoleService.UserRoleCreateManyRequestDto request =
        new UserRoleService.UserRoleCreateManyRequestDto();
    request.setUserIdentifiers(selectedUserIds);
    request.setRoleIdentifiers(selectedRoleIds);
    request.setAuditWho(userIdentifier);
    client.createMany(request);
  }
}
