package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de budget.
 *
 * @author Christian
 */
public interface FilterHasBudgetIdentifier extends HasBudgetIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant budget.
   *
   * @param filter {@link FilterDto}
   */
  default void updateBudgetIdentifier(FilterDto filter) {
    setBudgetIdentifier(BudgetIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant budget de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterBudgetIdentifier(FilterDto filter) {
    BudgetIdentifierFilter.set(filter, getBudgetIdentifier());
  }

}
