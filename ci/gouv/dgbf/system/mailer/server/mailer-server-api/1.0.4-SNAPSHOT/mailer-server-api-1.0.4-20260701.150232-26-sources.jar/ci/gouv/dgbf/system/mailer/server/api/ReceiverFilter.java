package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.FilterHasMailIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ReceiverFilter extends AbstractIdentifiableFilter implements FilterHasMailIdentifier {

  String mailIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    updateMailIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterMailIdentifier(filter);
  }
}
