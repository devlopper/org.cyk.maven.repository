package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de nombre
 * de fichiers.
 *
 * @author Christian
 */
public interface HasFilesCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de fichiers.
   *
   * @return représentation en chaine de caractères du nombre de fichiers
   */
  String getFilesCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * fichiers.
   *
   * @param asString représentation en chaine de caractères du nombre de fichiers
   */
  void setFilesCountAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de fichiers.
   */
  String FIELD_FILES_COUNT_AS_STRING = "filesCountAsString";
}
