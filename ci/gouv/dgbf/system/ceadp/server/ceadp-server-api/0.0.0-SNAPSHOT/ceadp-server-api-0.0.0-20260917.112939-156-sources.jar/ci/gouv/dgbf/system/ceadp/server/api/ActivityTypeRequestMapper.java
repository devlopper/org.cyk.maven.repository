package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.ActivityTypeService.ActivityTypeCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.ActivityTypeService.ActivityTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ActivityTypeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ActivityTypeDto}.

    @author Christian
               """)
public interface ActivityTypeRequestMapper extends
    RequestMapper<ActivityTypeDto, ActivityTypeCreateRequestDto, ActivityTypeUpdateRequestDto> {

}
