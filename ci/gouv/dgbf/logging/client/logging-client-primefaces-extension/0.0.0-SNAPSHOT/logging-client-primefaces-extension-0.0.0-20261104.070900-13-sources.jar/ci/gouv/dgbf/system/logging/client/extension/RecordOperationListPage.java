package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link RecordOperationDto}.
 *
 * @author Arnaud
 *
 */
@Named
@ViewScoped
public class RecordOperationListPage extends AbstractPage {

  @Inject
  @Getter
  RecordOperationController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + RecordOperationDto.NAME;
    controller.initialize();
  }
  
  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "recordOperationListPage";
}
