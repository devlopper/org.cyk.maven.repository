package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.file.server.api.ContentForm;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link ContentForm}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class ContentFormManager extends AbstractStatusManager<ContentForm> {

  /**
   * Cette méthode permet d'instancier.
   */
  public ContentFormManager() {
    super(ContentForm.class, e -> e.getName());
  }
}
