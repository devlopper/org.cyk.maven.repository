package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverFilter;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverFilter;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverType;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ReceiverFilterController extends AbstractFilterController<ReceiverFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public ReceiverFilterController() {
    super(ReceiverFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setReference(getRequestParameter(AbstractResourceOrReceiverFilter.JSON_REFERENCE));
    filter.setType(Core.getEnumerationValueByName(ReceiverType.class,
        getRequestParameter(AbstractResourceOrReceiverFilter.JSON_TYPE)));
    filter.setLocation(Core.getEnumerationValueByName(Location.class,
        getRequestParameter(AbstractResourceOrReceiverFilter.JSON_LOCATION)));
  }
}

