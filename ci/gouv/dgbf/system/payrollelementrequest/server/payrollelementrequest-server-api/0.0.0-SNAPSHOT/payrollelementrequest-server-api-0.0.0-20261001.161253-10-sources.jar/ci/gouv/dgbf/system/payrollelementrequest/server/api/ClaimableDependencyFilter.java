package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableDependencyDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableDependencyFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant d'un Réclamable -- retrouve les paires l'impliquant dans les deux sens
   * (RG_REP_CIB_11), quel que soit celui des deux Réclamables porté par {@link
   * ClaimableDependencyDto#getClaimableIdentifier()}/{@link
   * ClaimableDependencyDto#getRequiredClaimableIdentifier()}.
   */
  String claimableIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableDependencyFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableDependencyFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    claimableIdentifier = getClaimableIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setClaimableIdentifier(filter, claimableIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Réclamable.
   *
   * @param filter filtre
   * @param claimableIdentifier identifiant du Réclamable
   */
  public static void setClaimableIdentifier(FilterDto filter, String claimableIdentifier) {
    set(filter, JSON_CLAIMABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(claimableIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Réclamable.
   *
   * @param filter filtre
   * @return identifiant du Réclamable
   */
  public static String getClaimableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CLAIMABLE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER =
      ClaimableDependencyDto.JSON_CLAIMABLE_IDENTIFIER;
}
