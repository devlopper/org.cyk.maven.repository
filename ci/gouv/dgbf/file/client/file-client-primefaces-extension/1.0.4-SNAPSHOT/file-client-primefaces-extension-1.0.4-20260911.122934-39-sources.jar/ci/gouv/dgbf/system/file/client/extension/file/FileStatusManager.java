package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.file.server.api.FileStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link FileStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class FileStatusManager extends AbstractStatusManager<FileStatus> {

  /**
   * Cette méthode permet d'instanctier.
   */
  public FileStatusManager() {
    super(FileStatus.class, e -> e.getName());
  }
}
