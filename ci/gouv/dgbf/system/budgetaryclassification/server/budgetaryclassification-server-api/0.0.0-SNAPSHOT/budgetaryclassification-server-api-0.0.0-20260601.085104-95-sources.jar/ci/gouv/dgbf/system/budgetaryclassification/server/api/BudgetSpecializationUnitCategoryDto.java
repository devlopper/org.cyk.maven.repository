package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un catégorie unité de spécialisation budget.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetSpecializationUnitCategoryDto extends
     AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link BudgetSpecializationUnitCategoryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCategorieUniteSpecialisationBudget";

  /**
   * Identifiant json de représentation en chaine de caractères de.
   * {@link BudgetSpecializationUnitCategoryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "categorieUniteSpecialisationBudgetChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie unité spécialisation budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories unité spécialisation budget";
}
