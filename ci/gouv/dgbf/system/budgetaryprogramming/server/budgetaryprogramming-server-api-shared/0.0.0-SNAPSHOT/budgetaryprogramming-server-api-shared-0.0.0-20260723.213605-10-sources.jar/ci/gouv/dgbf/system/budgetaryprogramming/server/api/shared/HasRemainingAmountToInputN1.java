package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+1.
 *
 * @author Christian
 */
public interface HasRemainingAmountToInputN1 {

  /**
   * Obtient le montant restant à saisir pour l'année N+1.
   *
   * @return le montant restant à saisir pour l'année N+1
   */
  Long getRemainingAmountToInputN1();

  /**
   * Définit le montant restant à saisir pour l'année N+1.
   *
   * @param remainingAmountToInputN1 le montant restant à saisir pour l'année N+1
   */
  void setRemainingAmountToInputN1(Long remainingAmountToInputN1);

  /**
   * Identifiant java du montant restant à saisir pour l'année N+1.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N1 = "remainingAmountToInputN1";
}