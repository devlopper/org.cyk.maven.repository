package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link AdministrativeUnitPunctualMeasureService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class AdministrativeUnitPunctualMeasureClient
    extends AbstractClient<AdministrativeUnitPunctualMeasureService>
    implements GetByIdentifier<AdministrativeUnitPunctualMeasureDto>,
    GetMany<AdministrativeUnitPunctualMeasureGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public AdministrativeUnitPunctualMeasureClient service(
      AdministrativeUnitPunctualMeasureService service) {
    return (AdministrativeUnitPunctualMeasureClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(AdministrativeUnitPunctualMeasureCreateRequestDto request) {
    return new CreateExecutor(AdministrativeUnitPunctualMeasureService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitPunctualMeasureGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitPunctualMeasureGetManyResponseDto>(
        AdministrativeUnitPunctualMeasureGetManyResponseDto.class,
        AdministrativeUnitPunctualMeasureService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public AdministrativeUnitPunctualMeasureGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitPunctualMeasureDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitPunctualMeasureDto>(
        AdministrativeUnitPunctualMeasureDto.class,
        AdministrativeUnitPunctualMeasureService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitPunctualMeasureDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitPunctualMeasureDto>(
        AdministrativeUnitPunctualMeasureDto.class,
        AdministrativeUnitPunctualMeasureService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public AdministrativeUnitPunctualMeasureDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(AdministrativeUnitPunctualMeasureUpdateRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitPunctualMeasureService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link AdministrativeUnitPunctualMeasureService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(AdministrativeUnitPunctualMeasureService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
