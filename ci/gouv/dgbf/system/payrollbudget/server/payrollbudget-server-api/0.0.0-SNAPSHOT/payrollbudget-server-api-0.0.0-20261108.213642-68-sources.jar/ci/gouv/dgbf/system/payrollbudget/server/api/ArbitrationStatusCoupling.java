package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * La subordination des statuts : une ligne ne va pas plus loin que son dossier ne l'y autorise.
 *
 * <p>Jusqu'au 05/10/2026 le dossier acheminait et la ligne décidait, chacun son cycle, sans que
 * l'un ne contraigne l'autre. Deux conséquences, et elles se voyaient à l'écran : une ligne
 * pouvait être consolidée dans un dossier que personne n'avait clos, et rien ne marquait la fin
 * d'une étape — on ne savait pas dire si le traitement d'un dossier était achevé ou simplement
 * en cours. Le métier a tranché : <strong>le statut du dossier ouvre les étapes</strong>, et c'est
 * le chef d'équipe qui l'avance.</p>
 *
 * <h2>Les deux sens de la règle</h2>
 *
 * <p>La subordination se lit dans les deux sens, et cette classe porte les deux :</p>
 * <ul>
 *   <li><strong>vers le bas</strong> — {@link #isStageOpen} : une ligne ne prend un statut que si
 *       son dossier a ouvert l'étape correspondante. C'est la garde qu'interroge toute
 *       transition de ligne ;</li>
 *   <li><strong>vers le haut</strong> — {@link #getClosingStatuses} : le chef n'avance le dossier
 *       que si chaque ligne a fini l'étape qu'il referme. C'est la garde qu'interroge toute
 *       transition de dossier.</li>
 * </ul>
 *
 * <p>Les deux ensemble font une alternance : le dossier ouvre, les lignes franchissent, le
 * dossier referme et ouvre la suivante. Aucune ligne ne devance le groupe, aucune ne reste en
 * arrière sans que la fermeture ne s'en plaigne.</p>
 *
 * <p><strong>L'alternance n'est pas stricte pour autant, et c'est voulu.</strong> L'étape
 * exigée est un plancher, pas un palier : dans un dossier déjà validé, le chef peut encore
 * renvoyer une ligne au traitement, et elle rattrapera le groupe. C'est la reprise, et la
 * refuser obligerait à faire reculer tout un dossier pour une seule ligne. Rien ne se perd :
 * la fermeture suivante attend cette ligne comme les autres. Seule la clôture fait exception,
 * puisqu'elle arrête un montant — un dossier consolidé ne laisse plus rien bouger.</p>
 *
 * <h2>Pourquoi « ouvrir une étape » et non « avoir le même statut »</h2>
 *
 * <p>La règle énoncée par le métier est que la ligne ne peut prendre un statut supérieur que si
 * son dossier porte <em>au préalable</em> ce statut. Prise au pied de la lettre — même statut de
 * part et d'autre — elle se contredit sur sa propre fin : la consolidation du dossier est le
 * <em>dernier</em> geste, posé une fois chaque ligne consolidée, donc le dossier ne peut pas être
 * consolidé avant ses lignes. Le décalage d'un cran lève la contradiction et dit la même chose :
 * le dossier <em>Traité</em> ouvre la validation des lignes, le dossier <em>Validé</em> ouvre leur
 * consolidation. C'est bien ce que décrit le circuit, étape par étape.</p>
 *
 * <p>Un dossier consolidé ferme tout : {@link BudgetAdministrativeUnitStatus#CONSOLIDATED} est
 * terminal et plus aucune ligne n'y bouge. Cette fermeture-là n'est pas ici — elle est déjà dans
 * le cycle du dossier, et elle y est à sa place.</p>
 *
 * @author Christian
 *
 */
public final class ArbitrationStatusCoupling {

  private ArbitrationStatusCoupling() {
  }

  /**
   * L'étape que le dossier doit avoir ouverte pour que la ligne prenne ce statut.
   *
   * <p>Les états d'avant la réception n'y figurent pas, et c'est voulu : le visa, la
   * transmission et la réception de la ligne appartiennent au circuit de l'EPN et à la réception
   * elle-même, qui est le geste par lequel le dossier <em>devient</em> réceptionné. Les
   * subordonner à un statut de dossier qui n'existe pas encore interdirait l'entrée du
   * circuit.</p>
   *
   * <p>{@link ArbitrationMovementStatus#DEFERRED} y figure, lui : différer est une décision de
   * la DCB, elle se prend dans un dossier réceptionné.</p>
   */
  private static final Map<ArbitrationMovementStatus, BudgetAdministrativeUnitStatus> REQUIRED =
      Map.ofEntries(
          Map.entry(ArbitrationMovementStatus.DEFERRED, BudgetAdministrativeUnitStatus.RECEIVED),
          Map.entry(ArbitrationMovementStatus.DEFERRED_SATISFIED,
              BudgetAdministrativeUnitStatus.RECEIVED),
          Map.entry(ArbitrationMovementStatus.PROCESSING_ACCEPTED,
              BudgetAdministrativeUnitStatus.RECEIVED),
          Map.entry(ArbitrationMovementStatus.PROCESSING_REJECTED,
              BudgetAdministrativeUnitStatus.RECEIVED),
          // La validation d'une ligne suppose le traitement du dossier clos par le chef.
          Map.entry(ArbitrationMovementStatus.VALIDATED,
              BudgetAdministrativeUnitStatus.PROCESSED),
          Map.entry(ArbitrationMovementStatus.CONSOLIDATED,
              BudgetAdministrativeUnitStatus.VALIDATED),
          Map.entry(ArbitrationMovementStatus.NOT_CONSOLIDATED,
              BudgetAdministrativeUnitStatus.VALIDATED));

  /**
   * Les statuts de ligne qui comptent comme « étape finie » pour chaque fermeture de dossier.
   *
   * <p>Trois fermetures, trois exigences, et un même principe : une ligne ne retient le chef que
   * si elle a encore quelque chose à faire dans l'étape qu'il referme.</p>
   *
   * <p>{@link ArbitrationMovementStatus#PROCESSING_REJECTED} ne retient jamais : la ligne est
   * sortie du circuit par une décision définitive, l'attendre serait l'attendre indéfiniment.</p>
   *
   * <p>{@link ArbitrationMovementStatus#DEFERRED} ne retient pas les deux premières fermetures,
   * <strong>mais retient la dernière</strong>, et cette asymétrie est voulue. Une ligne différée
   * est repartie à l'EPN : laisser l'équipe avancer son traitement et sa validation sans elle est
   * normal, car elle n'y participe pas. La consolidation, elle, <em>arrête un montant et ferme le
   * dossier pour toujours</em> — et jusqu'au 05/10/2026 elle le faisait en comptant la ligne
   * différée dans la masse. Un dossier clos portait ainsi de l'argent pour une ligne repartie, qui
   * ne pouvait plus revenir puisque la clôture fige tout. Le métier a tranché : la consolidation
   * attend que la ligne différée soit revenue et menée à son terme.</p>
   *
   * <p>Ce que ce choix coûte, et il faut le savoir : un EPN qui ne retransmet jamais bloque la
   * consolidation de son dossier. C'est assumé — mieux vaut un dossier qu'on voit bloqué qu'une
   * masse salariale fausse qu'on ne voit pas.</p>
   *
   * <p>{@link ArbitrationMovementStatus#CONSOLIDATED} figure dans les trois : une ligne
   * d'initialisation se consolide dès la réception (RG_PRB_ARB_17) et n'a ni traitement ni
   * validation à franchir. Sans cela, un dossier d'initialisation ne pourrait jamais être
   * refermé.</p>
   */
  private static final Map<BudgetAdministrativeUnitStatus, Set<ArbitrationMovementStatus>>
      CLOSING = Map.of(
          BudgetAdministrativeUnitStatus.PROCESSED,
          Set.of(ArbitrationMovementStatus.PROCESSING_ACCEPTED,
              ArbitrationMovementStatus.PROCESSING_REJECTED,
              ArbitrationMovementStatus.DEFERRED,
              ArbitrationMovementStatus.CONSOLIDATED),
          BudgetAdministrativeUnitStatus.VALIDATED,
          Set.of(ArbitrationMovementStatus.VALIDATED,
              ArbitrationMovementStatus.PROCESSING_REJECTED,
              ArbitrationMovementStatus.DEFERRED,
              ArbitrationMovementStatus.CONSOLIDATED),
          // LE REPORT NE FIGURE PAS ICI, a la difference des deux fermetures precedentes :
          // consolider arrete un montant et ferme le dossier pour toujours.
          BudgetAdministrativeUnitStatus.CONSOLIDATED,
          Set.of(ArbitrationMovementStatus.CONSOLIDATED,
              ArbitrationMovementStatus.NOT_CONSOLIDATED,
              ArbitrationMovementStatus.PROCESSING_REJECTED));

  /**
   * Retourne l'étape que le dossier doit avoir ouverte pour que la ligne prenne ce statut.
   *
   * @param lineStatus statut visé par la ligne
   * @return le statut de dossier exigé, ou vide si ce statut de ligne n'en exige aucun
   */
  public static Optional<BudgetAdministrativeUnitStatus> getRequiredDossierStatus(
      ArbitrationMovementStatus lineStatus) {
    return getRequiredDossierStatus(lineStatus, null);
  }

  /**
   * Retourne l'étape exigée, en tenant compte de la nature de la ligne.
   *
   * <p><strong>L'initialisation se consolide dès la réception</strong> (RG_PRB_ARB_17), là où
   * toute autre ligne attend la validation du dossier. Sans cette distinction, la règle se
   * refermait sur elle-même : la ligne d'initialisation reçue n'avait d'autre suite que la
   * consolidation, la consolidation exigeait un dossier validé, et le dossier ne pouvait pas
   * même être traité tant que cette ligne le retenait. Un dossier d'initialisation ne se
   * refermait donc jamais.</p>
   *
   * <p>La nature n'allège <em>que</em> la consolidation. Les autres étapes ne la regardent pas,
   * et une ligne d'initialisation ne les franchit de toute façon pas.</p>
   *
   * @param lineStatus statut visé par la ligne
   * @param natureCode nature du mouvement, éventuellement nulle
   * @return le statut de dossier exigé, ou vide si ce statut de ligne n'en exige aucun
   */
  public static Optional<BudgetAdministrativeUnitStatus> getRequiredDossierStatus(
      ArbitrationMovementStatus lineStatus, String natureCode) {
    if (lineStatus == ArbitrationMovementStatus.CONSOLIDATED
        && ArbitrationMovementDto.NATURE_INITIALIZATION.equals(natureCode)) {
      return Optional.of(BudgetAdministrativeUnitStatus.RECEIVED);
    }
    return Optional.ofNullable(REQUIRED.get(lineStatus));
  }

  /**
   * Indique si le dossier a ouvert l'étape que la ligne veut franchir.
   *
   * <p>« Au moins » et non « exactement » : un dossier que le chef a déjà fait avancer n'a pas à
   * rouvrir une étape qu'il a refermée. Le cas se produit pour la ligne qu'une reprise ramène
   * en arrière — elle rattrape le groupe sans que le dossier recule.</p>
   *
   * @param lineStatus statut visé par la ligne
   * @param dossierStatus statut actuel du dossier qui la contient
   * @return vrai si la ligne peut prendre ce statut dans ce dossier
   */
  public static boolean isStageOpen(ArbitrationMovementStatus lineStatus,
      BudgetAdministrativeUnitStatus dossierStatus) {
    return isStageOpen(lineStatus, dossierStatus, null);
  }

  /**
   * Indique si le dossier a ouvert l'étape, pour une ligne de la nature donnée.
   *
   * <p><strong>Un dossier consolidé ne laisse plus rien bouger.</strong> La clôture arrête un
   * montant, et trois chemins restaient pourtant ouverts derrière elle : la ligne mise à
   * l'écart pouvait revenir dans la masse, la ligne différée repartir à l'EPN, la ligne
   * acceptée être renvoyée au traitement. Deux Javadoc affirmaient déjà que plus aucune
   * transition n'était acceptée ; aucune garde ne le vérifiait. C'est ici que cela se dit.</p>
   *
   * @param lineStatus statut visé par la ligne
   * @param dossierStatus statut actuel du dossier qui la contient
   * @param natureCode nature du mouvement, éventuellement nulle
   * @return vrai si la ligne peut prendre ce statut dans ce dossier
   */
  public static boolean isStageOpen(ArbitrationMovementStatus lineStatus,
      BudgetAdministrativeUnitStatus dossierStatus, String natureCode) {
    if (dossierStatus != null && dossierStatus.isTerminal()) {
      return false;
    }
    Optional<BudgetAdministrativeUnitStatus> required =
        getRequiredDossierStatus(lineStatus, natureCode);
    if (required.isEmpty()) {
      return true;
    }
    return dossierStatus != null && dossierStatus.rank() >= required.get().rank();
  }

  /**
   * Retourne les statuts de ligne qui n'empêchent pas le chef de refermer l'étape.
   *
   * <p>Une ligne dont le statut n'est pas dans cet ensemble retient le dossier : elle a encore
   * quelque chose à faire dans l'étape qu'on referme.</p>
   *
   * @param dossierTarget statut que le dossier va prendre
   * @return les statuts de ligne admis, vide si cette fermeture n'exige rien des lignes
   */
  public static Set<ArbitrationMovementStatus> getClosingStatuses(
      BudgetAdministrativeUnitStatus dossierTarget) {
    return CLOSING.getOrDefault(dossierTarget, Set.of());
  }

  /**
   * Indique si une ligne retient le dossier au moment de refermer une étape.
   *
   * @param lineStatus statut actuel de la ligne
   * @param dossierTarget statut que le dossier va prendre
   * @return vrai si cette ligne empêche la fermeture
   */
  public static boolean isHoldingBack(ArbitrationMovementStatus lineStatus,
      BudgetAdministrativeUnitStatus dossierTarget) {
    Set<ArbitrationMovementStatus> allowed = getClosingStatuses(dossierTarget);
    return !allowed.isEmpty() && !allowed.contains(lineStatus);
  }

  /**
   * Indique si le code de statut de ligne donné retient le dossier.
   *
   * <p>Variante par code, pour la couche de persistance qui ne manipule que des chaînes. Un code
   * inconnu retient : on ne referme pas une étape sur ce qu'on ne sait pas lire.</p>
   *
   * <p><strong>Mais il ne retient que ce qui exige quelque chose.</strong> La prudence ne vaut
   * que pour les fermetures : un statut de dossier qui n'impose rien aux lignes ne doit pas
   * être bloqué par une ligne illisible. Sans cette borne, un seul code abimé en base arrêtait
   * des transitions qui ne vérifient rien.</p>
   *
   * @param lineStatusCode code du statut actuel de la ligne
   * @param dossierTarget statut que le dossier va prendre
   * @return vrai si cette ligne empêche la fermeture
   */
  public static boolean isHoldingBack(String lineStatusCode,
      BudgetAdministrativeUnitStatus dossierTarget) {
    if (getClosingStatuses(dossierTarget).isEmpty()) {
      return false;
    }
    try {
      return isHoldingBack(ArbitrationMovementStatus.getByCode(lineStatusCode), dossierTarget);
    } catch (IllegalArgumentException exception) {
      return true;
    }
  }
}
