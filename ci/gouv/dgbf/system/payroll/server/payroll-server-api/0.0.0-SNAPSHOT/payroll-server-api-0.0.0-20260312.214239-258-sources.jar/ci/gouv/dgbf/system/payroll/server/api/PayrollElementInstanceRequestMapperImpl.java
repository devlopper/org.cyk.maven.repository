package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementInstanceDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-12T21:43:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementInstanceRequestMapperImpl implements PayrollElementInstanceRequestMapper {

    @Override
    public PayrollElementInstanceService.PayrollElementInstanceCreateRequestDto mapCreate(PayrollElementInstanceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementInstanceService.PayrollElementInstanceCreateRequestDto payrollElementInstanceCreateRequestDto = new PayrollElementInstanceService.PayrollElementInstanceCreateRequestDto();

        payrollElementInstanceCreateRequestDto.setCode( arg0.getCode() );
        payrollElementInstanceCreateRequestDto.setName( arg0.getName() );
        payrollElementInstanceCreateRequestDto.setPayrollElementIdentifier( arg0.getPayrollElementIdentifier() );

        return payrollElementInstanceCreateRequestDto;
    }

    @Override
    public PayrollElementInstanceService.PayrollElementInstanceUpdateRequestDto mapUpdate(PayrollElementInstanceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementInstanceService.PayrollElementInstanceUpdateRequestDto payrollElementInstanceUpdateRequestDto = new PayrollElementInstanceService.PayrollElementInstanceUpdateRequestDto();

        payrollElementInstanceUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementInstanceUpdateRequestDto.setCode( arg0.getCode() );
        payrollElementInstanceUpdateRequestDto.setName( arg0.getName() );
        payrollElementInstanceUpdateRequestDto.setPayrollElementIdentifier( arg0.getPayrollElementIdentifier() );

        return payrollElementInstanceUpdateRequestDto;
    }
}
