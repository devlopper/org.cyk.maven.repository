package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de la catégorie de budget.
 *
 * @author arnaud
 */
public interface HasBudgetCategoryAsStringDto
       extends HasBudgetCategoryAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la catégorie de budget.
   */
  String JSON_BUDGET_CATEGORY_AS_STRING = "categorieBudgetChaine";
}
