package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateNAsStringDto
    extends HasRemainingAmountToIntegrateNAsString {

  /**
   * Identifiant json du montant restant à intégrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INTEGRATE_N_AS_STRING =
      "montantResteAIntegrerNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName