package ci.gouv.dgbf.system.identity.server.api;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ImportableIdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ImportableIdentityFilter extends AbstractIdentityFilter {

}

