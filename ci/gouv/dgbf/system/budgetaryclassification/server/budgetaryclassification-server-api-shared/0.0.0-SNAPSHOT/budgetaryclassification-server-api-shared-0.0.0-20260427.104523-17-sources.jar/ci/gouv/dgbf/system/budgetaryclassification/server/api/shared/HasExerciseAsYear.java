package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une année
 * d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseAsYear extends HasField {

  /**
   * Cette méthode permet d'obtenir l'année de l'exercice.
   *
   * @return année de l'exercice
   */
  Integer getExerciseYear();

  /**
   * Cette méthode permet d'assigner l'année de l'exercice.
   *
   * @param year année de l'exercice
   */
  void setExerciseYear(Integer year);

  /**
   * Identifiant java de l'année de l'exercice.
   */
  String FIELD_EXERCISE_YEAR = "exerciseYear";
}
