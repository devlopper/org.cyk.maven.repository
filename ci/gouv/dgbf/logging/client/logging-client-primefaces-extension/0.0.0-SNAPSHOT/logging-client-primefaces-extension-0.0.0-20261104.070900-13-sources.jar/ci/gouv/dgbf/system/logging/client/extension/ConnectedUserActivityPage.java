package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.logging.server.api.UserRole;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page d'activité d'un utilisateur.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserActivityPage extends AbstractPage {

  @Inject
  @Getter
  ConnectedUserActivityController controller;

  @Getter
  String targetUser;

  @Getter
  boolean consultingOtherUser;

  @Getter
  boolean accessGranted = true;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    String paramSubject = getRequestParameter("sujet");
    if (paramSubject != null && !paramSubject.isBlank()) {
      targetUser = paramSubject.trim();
    } else {
      targetUser = userIdentifier;
    }

    if (targetUser != null && userIdentifier != null) {
      consultingOtherUser = !targetUser.equalsIgnoreCase(userIdentifier);
    } else {
      consultingOtherUser = false;
    }

    if (consultingOtherUser && !isUserInRole(UserRole.ADMINISTRATOR.getCode())) {
      accessGranted = false;
      contentTitle = "Accès refusé";
      return;
    }

    if (consultingOtherUser) {
      contentTitle = "Activité de " + targetUser;
    } else {
      contentTitle = "Mon activité";
    }

    controller.setTargetUser(targetUser);
    controller.setConsultingOtherUser(consultingOtherUser);
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "connectedUserActivityPage";
}

