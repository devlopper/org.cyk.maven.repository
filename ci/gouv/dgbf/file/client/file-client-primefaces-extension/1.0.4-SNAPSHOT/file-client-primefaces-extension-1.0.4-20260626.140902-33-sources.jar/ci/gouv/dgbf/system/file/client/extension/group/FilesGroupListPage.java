package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FilesGroupListPage extends AbstractPage {

  @Inject
  @Getter
  FilesGroupController controller;

  @Inject
  @Getter
  FilesGroupCollectionTabMenuController tabMenuController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste des groupes de fichiers";
    controller.initialize();
    
    tabMenuController.initialize();
  }
  
  public static final String OUTCOME = "filesGroupListPage";
}
