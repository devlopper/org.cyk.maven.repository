package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représentante un filtre basé sur la notion de est EPN.
 *
 * @author Christian
 */
public interface IsNationalPublicInstitutionFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir est EPN.
   *
   * @param filter {@link FilterDto}
   * @return est EPN
   */
  public static Boolean get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsBooleanByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner est EPN.
   *
   * @param filter {@link FilterDto}
   * @param isNationalPublicInstitution est EPN
   */
  public static void set(FilterDto filter, Boolean isNationalPublicInstitution) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isNationalPublicInstitution));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = HasIsNationalPublicInstitutionDto.JSON_IS_NATIONAL_PUBLIC_INSTITUTION;


}

