package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeFromDate;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeToDate;
import ci.gouv.dgbf.extension.server.service.api.filter.LocalDateTimeFromDateFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.LocalDateTimeToDateFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche pour les anomalies inter-modules.
 */
@Getter
@Setter
public class AnomalyFilter extends AbstractIdentifiableFilter
    implements FilterHasLocalDateTimeFromDate, FilterHasLocalDateTimeToDate {

  /** Durée maximale autorisée pour une période en jours (RG_LOG_TRA_11). */
  public static final long MAX_PERIOD_DAYS = 90L;

  public static final String JSON_TYPE = "type";
  public static final String JSON_MODULE = "module";
  public static final String JSON_STATUS = "statut";
  public static final String JSON_CONTAINS_MASKED_DATA = "contientDonneesMasquees";
  public static final String JSON_DATE_FROM = "dateFrom";
  public static final String JSON_DATE_TO = "dateTo";
  public static final String JSON_AUDIT_SESSION = "auditSession";

  private AnomalyType type;
  private String module;
  private AnomalyStatus status;
  private Boolean containsMaskedData;
  private LocalDateTime dateFrom;
  private LocalDateTime dateTo;
  private String auditSession;

  public AnomalyFilter() {}

  public AnomalyFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  public LocalDateTime getFromDate() {
    return dateFrom;
  }

  @Override
  public void setFromDate(LocalDateTime fromDate) {
    this.dateFrom = fromDate;
  }

  @Override
  public LocalDateTime getToDate() {
    return dateTo;
  }

  @Override
  public void setToDate(LocalDateTime toDate) {
    this.dateTo = toDate;
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    type = get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, AnomalyType.class));
    module = get(filter, d -> d.getFieldValueAsStringByName(JSON_MODULE));
    status = get(filter, d -> d.getFieldValueAsEnum(JSON_STATUS, AnomalyStatus.class));
    containsMaskedData =
        get(filter, d -> d.getFieldValueAsBooleanByName(JSON_CONTAINS_MASKED_DATA));
    dateFrom = get(filter, d -> d.getFieldValueAsDateTimeByName(JSON_DATE_FROM));
    if (dateFrom == null) {
      dateFrom = LocalDateTimeFromDateFilter.get(filter);
    }
    dateTo = get(filter, d -> d.getFieldValueAsDateTimeByName(JSON_DATE_TO));
    if (dateTo == null) {
      dateTo = LocalDateTimeToDateFilter.get(filter);
    }
    auditSession = get(filter, d -> d.getFieldValueAsStringByName(JSON_AUDIT_SESSION));
  }

  @Override
  public FilterDto toDto() {
    FilterDto filter = new FilterDto();
    super.toDto(filter);
    filter.addCriteria(JSON_TYPE, type);
    filter.addCriteria(JSON_MODULE, module);
    filter.addCriteria(JSON_STATUS, status);
    filter.addCriteria(JSON_CONTAINS_MASKED_DATA, containsMaskedData);
    filter.addCriteria(JSON_AUDIT_SESSION, auditSession);
    set(filter, JSON_DATE_FROM, f -> f.getValueAsDateTime(), f -> f.setValueAsDateTime(dateFrom));
    LocalDateTimeFromDateFilter.set(filter, dateFrom);
    set(filter, JSON_DATE_TO, f -> f.getValueAsDateTime(), f -> f.setValueAsDateTime(dateTo));
    LocalDateTimeToDateFilter.set(filter, dateTo);
    return filter;
  }

  /**
   * Valide la période selon les exigences de RG_LOG_TRA_11.
   *
   * @param from date de début
   * @param to date de fin
   * @throws IllegalArgumentException si la période est invalide ou dépasse 90 jours
   */
  public static void validatePeriod(LocalDateTime from, LocalDateTime to) {
    if (from == null || to == null) {
      throw new IllegalArgumentException(
          "La période est obligatoire (dateDebut et dateFin requises)");
    }
    if (from.isAfter(to)) {
      throw new IllegalArgumentException(
          "La date de début doit être antérieure ou égale à la date de fin");
    }
    long days = ChronoUnit.DAYS.between(from, to);
    if (days > MAX_PERIOD_DAYS) {
      throw new IllegalArgumentException(
          String.format("La période (%d jours) dépasse la durée maximale autorisée (%d jours)",
              days, MAX_PERIOD_DAYS));
    }
  }
}

