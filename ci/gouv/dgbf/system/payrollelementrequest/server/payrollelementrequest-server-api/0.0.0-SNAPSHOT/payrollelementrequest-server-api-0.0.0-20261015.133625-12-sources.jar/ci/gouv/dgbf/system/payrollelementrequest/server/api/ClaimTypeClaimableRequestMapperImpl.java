package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimTypeClaimableDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-15T13:36:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimTypeClaimableRequestMapperImpl implements ClaimTypeClaimableRequestMapper {

    @Override
    public ClaimTypeClaimableService.ClaimTypeClaimableCreateRequestDto mapCreate(ClaimTypeClaimableDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimTypeClaimableService.ClaimTypeClaimableCreateRequestDto claimTypeClaimableCreateRequestDto = new ClaimTypeClaimableService.ClaimTypeClaimableCreateRequestDto();

        claimTypeClaimableCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimTypeClaimableCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimTypeClaimableCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        claimTypeClaimableCreateRequestDto.setNature( arg0.getNature() );
        claimTypeClaimableCreateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        claimTypeClaimableCreateRequestDto.setValueInputMode( arg0.getValueInputMode() );
        claimTypeClaimableCreateRequestDto.setMovementNature( arg0.getMovementNature() );
        claimTypeClaimableCreateRequestDto.setRank( arg0.getRank() );
        claimTypeClaimableCreateRequestDto.setMandatoryForFae( arg0.getMandatoryForFae() );
        claimTypeClaimableCreateRequestDto.setWithHistory( arg0.getWithHistory() );

        return claimTypeClaimableCreateRequestDto;
    }

    @Override
    public ClaimTypeClaimableService.ClaimTypeClaimableUpdateRequestDto mapUpdate(ClaimTypeClaimableDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimTypeClaimableService.ClaimTypeClaimableUpdateRequestDto claimTypeClaimableUpdateRequestDto = new ClaimTypeClaimableService.ClaimTypeClaimableUpdateRequestDto();

        claimTypeClaimableUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimTypeClaimableUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimTypeClaimableUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimTypeClaimableUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        claimTypeClaimableUpdateRequestDto.setNature( arg0.getNature() );
        claimTypeClaimableUpdateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        claimTypeClaimableUpdateRequestDto.setValueInputMode( arg0.getValueInputMode() );
        claimTypeClaimableUpdateRequestDto.setMovementNature( arg0.getMovementNature() );
        claimTypeClaimableUpdateRequestDto.setRank( arg0.getRank() );
        claimTypeClaimableUpdateRequestDto.setMandatoryForFae( arg0.getMandatoryForFae() );
        claimTypeClaimableUpdateRequestDto.setWithHistory( arg0.getWithHistory() );

        return claimTypeClaimableUpdateRequestDto;
    }
}
