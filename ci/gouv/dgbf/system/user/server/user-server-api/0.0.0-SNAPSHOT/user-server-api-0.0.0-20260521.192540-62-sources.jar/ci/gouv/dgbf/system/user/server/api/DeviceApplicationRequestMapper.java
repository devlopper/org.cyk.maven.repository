package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DeviceApplicationDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DeviceApplicationDto}.

    @author Arnaud
               """)
public interface DeviceApplicationRequestMapper
    extends RequestMapper<DeviceApplicationDto, 
    DeviceApplicationCreateRequestDto, DeviceApplicationUpdateRequestDto> {

}
