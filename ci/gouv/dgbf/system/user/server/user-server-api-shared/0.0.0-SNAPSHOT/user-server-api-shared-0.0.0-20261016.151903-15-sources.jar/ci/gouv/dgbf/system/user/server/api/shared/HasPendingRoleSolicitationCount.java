package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de demandes de rôle en attente.
 *
 * @author Christian Yao Komenan
 */
public interface HasPendingRoleSolicitationCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de demandes de rôle en attente.
   *
   * @return le nombre de demandes de rôle en attente
   */
  Integer getPendingRoleSolicitationCount();

  /**
   * Cette méthode permet d'assigner le nombre de demandes de rôle en attente.
   *
   * @param pendingRoleSolicitationCount le nombre de demandes de rôle en attente
   */
  void setPendingRoleSolicitationCount(Integer pendingRoleSolicitationCount);

  /**
   * Identifiant java du nombre de demandes de rôle en attente.
   */
  String FIELD_PENDING_ROLE_SOLICITATION_COUNT = "pendingRoleSolicitationCount";
}
