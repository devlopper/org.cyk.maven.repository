package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un financement de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetActivityFundingDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link BudgetActivityDto}.
   */
  @JsonbProperty(JSON_BUDGET_ACTIVITY_IDENTIFIER)
  private String budgetActivityIdentifier;

  /**
   * Identifiant {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Identifiant de la nature économique.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Représentation en chaine de caractères de la nature économique.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;

  /**
   * Identifiant {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
  private String fundingTypeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_AS_STRING)
  private String fundingTypeAsString;

  /**
   * Identifiant {@link LessorDto}.
   */
  @JsonbProperty(JSON_LESSOR_IDENTIFIER)
  private String lessorIdentifier;

  /**
   * Représentation en chaine de caractères de {@link LessorDto}.
   */
  @JsonbProperty(JSON_LESSOR_AS_STRING)
  private String lessorAsString;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Long amount;

  /**
   * Représentation en chaine de caractères de {@link #amount}.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;

  /**
   * Commentaire.
   */
  @JsonbProperty(JSON_COMMENT)
  private String comment;

  /**
   * Identifiant json de l'identifiant de cette classe.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFinancementActiviteBudget";

  /**
   * Identifiant json {@link #budgetActivityIdentifier}.
   */
  public static final String JSON_BUDGET_ACTIVITY_IDENTIFIER =
      BudgetActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER =
      FundingDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

  /**
   * Identifiant json {@link #economicNatureAsString}.
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING =
      FundingDto.JSON_ECONOMIC_NATURE_AS_STRING;

  /**
   * Identifiant json {@link #fundingTypeIdentifier}.
   */
  public static final String JSON_FUNDING_TYPE_IDENTIFIER = FundingDto.JSON_FUNDING_TYPE_IDENTIFIER;

  /**
   * Identifiant json {@link #fundingTypeAsString}.
   */
  public static final String JSON_FUNDING_TYPE_AS_STRING = FundingDto.JSON_FUNDING_TYPE_AS_STRING;

  /**
   * Identifiant json {@link #lessorIdentifier}.
   */
  public static final String JSON_LESSOR_IDENTIFIER = FundingDto.JSON_LESSOR_IDENTIFIER;

  /**
   * Identifiant json {@link #lessorAsString}.
   */
  public static final String JSON_LESSOR_AS_STRING = FundingDto.JSON_LESSOR_AS_STRING;

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Identifiant json {@link #comment}.
   */
  public static final String JSON_COMMENT = FundingDto.JSON_COMMENT;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "financement d'activité de budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "financements d'activités de budgets";
}
