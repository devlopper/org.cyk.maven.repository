package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityPolicyConsentDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-17T12:06:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityPolicyConsentRequestMapperImpl implements IdentityPolicyConsentRequestMapper {

    @Override
    public IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto mapCreate(IdentityPolicyConsentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto identityPolicyConsentSendConsentRequestMailRequestDto = new IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto();

        identityPolicyConsentSendConsentRequestMailRequestDto.setAuditWho( arg0.getAuditWho() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setAuditSession( arg0.getAuditSession() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setPolicyVersionIdentifier( arg0.getPolicyVersionIdentifier() );

        return identityPolicyConsentSendConsentRequestMailRequestDto;
    }

    @Override
    public IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto mapUpdate(IdentityPolicyConsentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto identityPolicyConsentSendConsentRequestMailRequestDto = new IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto();

        identityPolicyConsentSendConsentRequestMailRequestDto.setAuditWho( arg0.getAuditWho() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setAuditSession( arg0.getAuditSession() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityPolicyConsentSendConsentRequestMailRequestDto.setPolicyVersionIdentifier( arg0.getPolicyVersionIdentifier() );

        return identityPolicyConsentSendConsentRequestMailRequestDto;
    }
}
