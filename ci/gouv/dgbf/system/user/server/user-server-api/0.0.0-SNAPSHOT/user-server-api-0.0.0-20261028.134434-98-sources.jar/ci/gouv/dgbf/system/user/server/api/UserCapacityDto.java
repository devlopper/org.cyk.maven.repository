package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une qualité d'utilisateur.
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserCapacityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idQualiteUtilisateur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "qualiteUtilisateurChaine";

  /**
   * Code de la Qualité qui fait d'un membre le Responsable de son Groupe (RG_UTI_GRP_06).
   */
  public static final String RESPONSIBLE_CODE = "RESPONSABLE";

  /**
   * Code de la Qualité qui fait d'un membre le Superviseur de son Groupe.
   */
  public static final String SUPERVISOR_CODE = "SUPERVISEUR";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "qualité d'utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "qualités d'utilisateur";
}
