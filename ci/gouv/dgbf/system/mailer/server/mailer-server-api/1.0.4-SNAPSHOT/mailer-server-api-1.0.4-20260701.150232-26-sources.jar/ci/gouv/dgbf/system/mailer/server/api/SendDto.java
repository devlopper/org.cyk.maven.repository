package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.HasMailIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente l'envoi de {@link MailDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SendDto extends AbstractIdentifiableAuditableDto implements HasMailIdentifierDto {

  @JsonbProperty(JSON_MAIL_IDENTIFIER)
  private String mailIdentifier;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "envoi de mail";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "envois de mail";
}
