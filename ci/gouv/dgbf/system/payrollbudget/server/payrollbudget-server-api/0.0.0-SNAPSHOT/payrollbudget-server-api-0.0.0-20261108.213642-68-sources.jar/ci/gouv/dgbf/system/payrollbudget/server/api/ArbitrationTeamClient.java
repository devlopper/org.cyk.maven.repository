package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamService.ArbitrationTeamCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamService.ArbitrationTeamGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamService.ArbitrationTeamUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des équipes d'arbitrage.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ArbitrationTeamClient extends AbstractClient<ArbitrationTeamService>
    implements OneRetrievable<ArbitrationTeamDto>, GetByIdentifier<ArbitrationTeamDto>,
    GetMany<ArbitrationTeamGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ArbitrationTeamClient service(ArbitrationTeamService service) {
    return (ArbitrationTeamClient) super.service(service);
  }

  /**
   * Création d'une équipe.
   *
   * @param request l'équipe à créer
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(ArbitrationTeamCreateRequestDto request) {
    return new CreateExecutor(ArbitrationTeamService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des équipes.
   *
   * @param request critères, projection et pagination
   * @return les équipes correspondantes
   */
  public ArbitrationTeamGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamGetManyResponseDto>(
        ArbitrationTeamGetManyResponseDto.class, ArbitrationTeamService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public ArbitrationTeamGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'une équipe unique.
   *
   * @param request critères et projection
   * @return l'équipe correspondante
   */
  public ArbitrationTeamDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamDto>(ArbitrationTeamDto.class,
        ArbitrationTeamService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  @Override
  public ArbitrationTeamDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'une équipe par son identifiant.
   *
   * @param request identifiant et projection
   * @return l'équipe correspondante
   */
  public ArbitrationTeamDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamDto>(ArbitrationTeamDto.class,
        ArbitrationTeamService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public ArbitrationTeamDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Modification d'une équipe.
   *
   * @param request l'équipe modifiée
   * @return l'identifiant touché
   */
  public IdentifiableResponseDto update(ArbitrationTeamUpdateRequestDto request) {
    return new IdentifiableExecutor(ArbitrationTeamService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * Suppression d'une équipe.
   *
   * @param request l'identifiant à supprimer
   * @return l'identifiant supprimé
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ArbitrationTeamService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
