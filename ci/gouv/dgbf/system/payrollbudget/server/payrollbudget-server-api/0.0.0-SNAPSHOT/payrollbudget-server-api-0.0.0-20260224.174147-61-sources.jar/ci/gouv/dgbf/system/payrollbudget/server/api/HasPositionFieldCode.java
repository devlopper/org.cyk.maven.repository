package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasPositionFieldCode extends HasField {

  /**
   * Cette méthode permet d'obtenir le code de {@link PositionField}.
   *
   * @return code de {@link PositionField}
   */
  String getPositionFieldCode();

  /**
   * Cette méthode permet d'assigner le code de {@link PositionField}.
   *
   * @param code code de {@link PositionField}
   */
  void setPositionFieldCode(String code);

}
