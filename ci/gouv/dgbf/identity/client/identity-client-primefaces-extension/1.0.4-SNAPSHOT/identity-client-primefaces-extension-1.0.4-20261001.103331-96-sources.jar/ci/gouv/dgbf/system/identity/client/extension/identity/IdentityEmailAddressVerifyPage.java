package ci.gouv.dgbf.system.identity.client.extension.identity;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.ContentLoaderController;
import ci.gouv.dgbf.extension.primefaces.NavigationManager;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressVerifyRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressVerifyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.shared.IdentityIdentifierFilter;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.net.URI;
import java.util.List;
import java.util.Map;
import lombok.Getter;

/**
 * Cette classe représente la page de {@link IdentityEmailAddressService#VERIFY_IDENTIFIER}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityEmailAddressVerifyPage extends AbstractPage {

  @Inject
  IdentityEmailAddressClient client;

  @Inject
  @Getter
  ContentLoaderController processingContentLoaderController;

  String token;

  String identifier;

  @Inject
  NavigationManager navigationManager;

  URI baseUri;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Vérification de l'adresse email";

    processingContentLoaderController.getLoadingText().setValue("Vérification en cours. "
        + "Nous vérifions votre adresse e-mail. Veuillez patienter quelques instants.");
    processingContentLoaderController.getLoadedText()
        .setValue("Adresse e-mail vérifiée. " + "Votre adresse e-mail a été vérifiée avec succès.");
    processingContentLoaderController.loader().name("Vérificateur").loader(this::process);

    token =
        getRequestParameter(IdentityEmailAddressService.VERIFICATION_MAIL_REQUEST_PARAMETER_TOKEN);
    identifier = getRequestParameter(
        IdentityEmailAddressService.VERIFICATION_MAIL_REQUEST_PARAMETER_IDENTIFIER);

    baseUri = buildBaseUri();
  }

  void process() {
    IdentityEmailAddressVerifyRequestDto request = new IdentityEmailAddressVerifyRequestDto();
    request.setIdentifier(identifier);
    request.setToken(token);
    request.setFrontEndBaseUri(baseUri.toString());
    request.setAuditWho(IdentityEmailAddressService.VERIFY_IDENTIFIER);
    IdentityEmailAddressVerifyResponseDto response = client.verify(request);

    if (StringCore.isNotBlank(requestParameterTargetOutcomeValue)) {
      navigationManager.navigate(requestParameterTargetOutcomeValue,
          Map.of(IdentityIdentifierFilter.JSON_KEY, List.of(response.getIdentityIdentifier())));
    } else {
      navigationManager.navigate(IdentityEmailAddressVerifySuccessPage.OUTCOME,
          Map.of(EmailAddressFilter.JSON_KEY, List.of(response.getMaskedEmailAddress())));
    }
  }

  public static final String OUTCOME = "identityEmailAddressVerifyPage";
}
