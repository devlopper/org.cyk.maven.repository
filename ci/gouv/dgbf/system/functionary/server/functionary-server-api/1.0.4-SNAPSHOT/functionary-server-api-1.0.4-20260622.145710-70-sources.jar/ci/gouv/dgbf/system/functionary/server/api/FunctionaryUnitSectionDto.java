package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link FunctionaryDto} de unité Section.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryUnitSectionDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link FunctionaryDto}.
   */
  @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
  private String fonctionaryIdentifier;

  /**
   * Identifiant unité section.
   */
  @JsonbProperty(JSON_UNIT_SECTION_IDENTIFIER)
  private String unitSectionIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaireUniteSection";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnaireUniteSectionChaine";

  /**
   * Identifiant json {@link FunctionaryUnitSectionDto#unitSectionIdentifier}.
   */
  public static final String JSON_UNIT_SECTION_IDENTIFIER = "idUnitSectionDto";

  /**
   * Identifiant json {@link FunctionaryUnitSectionDto#fonctionaryIdentifier}.
   */
  public static final String JSON_FUNCTIONARY_IDENTIFIER =
      FunctionaryDto.JSON_THIS_IDENTIFIER;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "unité de section de fonctionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "unités de section de fonctionnaires";
}
