package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Interface représentant une classe qui a un filtre par identifiant d'équipe support.
 *
 * @author Arnaud
 */
public interface FilterHasSupportTeamIdentifier extends HasSupportTeamIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'équipe support.
   *
   * @param filter {@link FilterDto}
   */
  default void updateSupportTeamIdentifier(FilterDto filter) {
    setSupportTeamIdentifier(SupportTeamIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'équipe support de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterSupportTeamIdentifier(FilterDto filter) {
    SupportTeamIdentifierFilter.set(filter, getSupportTeamIdentifier());
  }

}
