package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FileGroupCategoryService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileGroupCategoryClient extends AbstractClient<FileGroupCategoryService>
    implements GetMany<FileGroupCategoryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetByIdentifier<FileGroupCategoryDto> {

  @Override
  public FileGroupCategoryClient service(FileGroupCategoryService service) {
    return (FileGroupCategoryClient) super.service(service);
  }

  /**
   * {@link FileGroupCategoryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FileGroupCategoryCreateRequestDto request) {
    return new CreateExecutor(FileGroupCategoryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FileGroupCategoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupCategoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FileGroupCategoryGetManyResponseDto>(
        FileGroupCategoryGetManyResponseDto.class, FileGroupCategoryService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link FileGroupCategoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupCategoryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FileGroupCategoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupCategoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FileGroupCategoryDto>(FileGroupCategoryDto.class,
        FileGroupCategoryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FileGroupCategoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupCategoryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FileGroupCategoryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FileGroupCategoryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FileGroupCategoryDto>(FileGroupCategoryDto.class,
        FileGroupCategoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FileGroupCategoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FileGroupCategoryDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FileGroupCategoryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FileGroupCategoryUpdateRequestDto request) {
    return new IdentifiableExecutor(FileGroupCategoryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FileGroupCategoryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FileGroupCategoryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
