package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSupportTeamIdentifierDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


/**
 * Cette interface représente les services de {@link DomainLevelDto}.
 *
 * @author Christian
 *
 */
@Path(value = DomainLevelService.PATH)
@Tag(name = "Gestion des niveaux de domaine")
public interface DomainLevelService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "niveaux-domaines";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_NIVEAU_DOMAINE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author kimou
   */
  interface DomainLevelSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionalDomainDto}.
     *
     * @return identifiant de {@link FunctionalDomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionalDomainDto}.
     *
     * @param identifier identifiant de {@link FunctionalDomainDto}
     */
    void setDomainIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link SupportLevelDto}.
     *
     * @return identifiant de {@link SupportLevelDto}
     */
    String getLevelIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link SupportLevelDto}.
     *
     * @param identifier identifiant de {@link SupportLevelDto}
     */
    void setLevelIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link SupportTeamDto}.
     *
     * @return identifiant de {@link SupportTeamDto}
     */
    String getSupportTeamIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link SupportTeamDto}.
     *
     * @param identifier identifiant de {@link SupportTeamDto}
     */
    void setSupportTeamIdentifier(String identifier);

    /**
     * Identifiant json identifiant de {@link FunctionalDomainDto}.
     */
    String JSON_DOMAIN_IDENTIFIER = FunctionalDomainDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link SupportLevelDto}.
     */
    String JSON_LEVEL_IDENTIFIER = SupportLevelDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link SupportTeamDto}.
     */
    String JSON_SUPPORT_TEAM_IDENTIFIER =
        HasSupportTeamIdentifierDto.JSON_SUPPORT_TEAM_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe d'utilisateurs.
     *
     * @return identifiant du groupe d'utilisateurs
     * @deprecated remplacé par {@link #getSupportTeamIdentifier()} (TCH_TK_556). Conservé pour ne
     *             pas casser la compilation de
     *             ticket-server-impl-quarkus/ticket-client-quarkus-primefaces tant qu'ils ne sont
     *             pas migrés.
     */
    @Deprecated
    String getUsersGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe d'utilisateurs.
     *
     * @param identifier identifiant du groupe d'utilisateurs
     * @deprecated remplacé par {@link #setSupportTeamIdentifier(String)} (TCH_TK_556).
     */
    @Deprecated
    void setUsersGroupIdentifier(String identifier);

    /**
     * Identifiant json identifiant du groupe d'utilisateurs.
     *
     * @deprecated remplacé par {@link #JSON_SUPPORT_TEAM_IDENTIFIER} (TCH_TK_556).
     */
    @Deprecated
    String JSON_USERS_GROUP_IDENTIFIER = HasUsersGroupIdentifierDto.JSON_USERS_GROUP_IDENTIFIER;

  }

  /**
   * Cette méthode permet de créer {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DomainLevelCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author kimou
   *
   */
  @Getter
  @Setter
  class DomainLevelCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements DomainLevelSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_LEVEL_IDENTIFIER)
    private String levelIdentifier;

    @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
    private String supportTeamIdentifier;

    /**
     * Ancien identifiant du groupe d'utilisateurs, avant TCH_TK_556.
     *
     * @deprecated remplacé par {@link #supportTeamIdentifier}.
     */
    @Deprecated
    @JsonbProperty(JSON_USERS_GROUP_IDENTIFIER)
    private String usersGroupIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_NIVEAU_DOMAINE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DomainLevelGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class DomainLevelGetManyResponseDto
      extends AbstractGetByPageResponseDto<DomainLevelDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DomainLevelDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_NIVEAU_DOMAINE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DomainLevelDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_NIVEAU_DOMAINE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DomainLevelDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_NIVEAU_DOMAINE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DomainLevelUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DomainLevelUpdateRequestDto extends ByIdentifierRequestDto
      implements DomainLevelSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_LEVEL_IDENTIFIER)
    private String levelIdentifier;

    @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
    private String supportTeamIdentifier;

    /**
     * Ancien identifiant du groupe d'utilisateurs, avant TCH_TK_556.
     *
     * @deprecated remplacé par {@link #supportTeamIdentifier}.
     */
    @Deprecated
    @JsonbProperty(JSON_USERS_GROUP_IDENTIFIER)
    private String usersGroupIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_NIVEAU_DOMAINE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DomainLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
