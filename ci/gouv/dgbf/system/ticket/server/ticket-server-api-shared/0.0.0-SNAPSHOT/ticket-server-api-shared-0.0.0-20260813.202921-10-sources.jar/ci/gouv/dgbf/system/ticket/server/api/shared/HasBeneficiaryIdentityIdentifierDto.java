package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'identité de bénéficiaire.
 *
 * @author Christian
 */
public interface HasBeneficiaryIdentityIdentifierDto extends HasBeneficiaryIdentityIdentifier {

  /**
   * Identifiant json de l'identifiant de l'identité du bénéficiaire.
   */
  String JSON_BENEFICIARY_IDENTITY_IDENTIFIER = "idIdentiteBeneficiaire";
}
