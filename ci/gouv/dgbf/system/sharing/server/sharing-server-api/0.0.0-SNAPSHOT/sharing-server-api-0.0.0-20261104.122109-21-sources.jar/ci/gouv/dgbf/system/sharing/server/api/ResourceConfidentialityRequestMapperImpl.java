package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Mapping des requêtes REST de confidentialité.
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-04T12:21:41+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ResourceConfidentialityRequestMapperImpl implements ResourceConfidentialityRequestMapper {

    @Override
    public ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto mapCreate(ResourceConfidentialityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto resourceConfidentialityCreateRequestDto = new ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto();

        resourceConfidentialityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceConfidentialityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceConfidentialityCreateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        resourceConfidentialityCreateRequestDto.setConfidentialityLevel( arg0.getConfidentialityLevel() );

        return resourceConfidentialityCreateRequestDto;
    }

    @Override
    public ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto mapUpdate(ResourceConfidentialityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto resourceConfidentialityUpdateRequestDto = new ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto();

        resourceConfidentialityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceConfidentialityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceConfidentialityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        resourceConfidentialityUpdateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        resourceConfidentialityUpdateRequestDto.setConfidentialityLevel( arg0.getConfidentialityLevel() );

        return resourceConfidentialityUpdateRequestDto;
    }
}
