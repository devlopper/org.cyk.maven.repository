package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceCreateRequestDto;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentCorrespondenceDto}.
 *
 * @author desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentCorrespondenceDto}.

    @author desysoft
               """)
public interface PayrollComponentCorrespondenceRequestMapper extends
    RequestMapper<PayrollComponentCorrespondenceDto, PayrollComponentCorrespondenceCreateRequestDto,
        PayrollComponentCorrespondenceUpdateRequestDto> {

}
