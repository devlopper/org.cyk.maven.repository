package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une instance d'élément de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementInstanceDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasPayrollElementIdentifierDto, HasPayrollElementAsStringDto {

  @JsonbProperty(JSON_PAYROLL_ELEMENT_IDENTIFIER)
  private String payrollElementIdentifier;

  @JsonbProperty(JSON_PAYROLL_ELEMENT_AS_STRING)
  private String payrollElementAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idInstanceElementPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "instanceElementPaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "instance d'élement de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "instances d'elements de paie";
}
