package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN1AsString {

  /**
   * Obtient le montant total à saisir pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant total à saisir pour l'année N+1 sous forme de chaîne de caractères
   */
  String getTotalAmountToInputN1AsString();

  /**
   * Définit le montant total à saisir pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param totalAmountToInputN1AsString le montant total à saisir pour l'année N+1 sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToInputN1AsString(String totalAmountToInputN1AsString);

  /**
   * Identifiant java du montant total à saisir pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N1_AS_STRING = "totalAmountToInputN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName