package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link AdministrativeUnitIdentityDto} de {@link AdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AdministrativeUnitIdentityDto extends AbstractIdentifiableDto implements
    IdentificationDto, FolderContainerableDto, ActivityContainerableDto, TaskContainerableDto {

  /**
   * Représentation en chaine de caractères de l'unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;
  
  /* Identification */

  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  private String emailAddress;

  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  @JsonbProperty(value = JSON_FIRST_NAME_AND_LAST_NAMES)
  private String firstNameAndLastNames;

  /* Folder */

  @JsonbProperty(JSON_FOLDER_COUNT)
  private Integer folderCount;

  @JsonbProperty(JSON_FOLDER_COUNT_AS_STRING)
  private String folderCountAsString;

  /* Activity container */

  @JsonbProperty(JSON_ACTIVITY_COUNT)
  private Integer activityCount;

  @JsonbProperty(JSON_ACTIVITY_COUNT_AS_STRING)
  private String activityCountAsString;

  @JsonbProperty(JSON_CREATED_ACTIVITY_COUNT_AS_STRING)
  private String createdActivityCountAsString;

  @JsonbProperty(JSON_SUSPENDED_ACTIVITY_COUNT_AS_STRING)
  private String suspendedActivityCountAsString;

  @JsonbProperty(JSON_STARTED_ACTIVITY_COUNT)
  private Integer startedActivityCount;

  @JsonbProperty(JSON_STARTED_ACTIVITY_COUNT_AS_STRING)
  private String startedActivityCountAsString;

  @JsonbProperty(JSON_STOPPED_ACTIVITY_COUNT_AS_STRING)
  private String stoppedActivityCountAsString;

  @JsonbProperty(JSON_REALIZED_ACTIVITY_COUNT)
  private Integer realizedActivityCount;

  @JsonbProperty(JSON_REALIZED_ACTIVITY_COUNT_AS_STRING)
  private String realizedActivityCountAsString;

  @JsonbProperty(JSON_LATE_ACTIVITY_COUNT)
  private Integer lateActivityCount;

  @JsonbProperty(JSON_LATE_ACTIVITY_COUNT_AS_STRING)
  private String lateActivityCountAsString;

  @JsonbProperty(JSON_NOT_LATE_ACTIVITY_COUNT_AS_STRING)
  private String notLateActivityCountAsString;

  @JsonbProperty(JSON_PENDING_START_ACTIVITY_COUNT)
  private Integer pendingStartActivityCount;

  @JsonbProperty(JSON_PENDING_START_ACTIVITY_COUNT_AS_STRING)
  private String pendingStartActivityCountAsString;

  @JsonbProperty(JSON_DONE_ACTIVITY_COUNT)
  private Integer doneActivityCount;

  @JsonbProperty(JSON_DONE_ACTIVITY_COUNT_AS_STRING)
  private String doneActivityCountAsString;

  @JsonbProperty(JSON_NOT_DONE_ACTIVITY_COUNT_AS_STRING)
  private String notDoneActivityCountAsString;

  /* Task container */

  @JsonbProperty(JSON_CREATED_TASK_COUNT_AS_STRING)
  private String createdTaskCountAsString;

  @JsonbProperty(JSON_SUSPENDED_TASK_COUNT_AS_STRING)
  private String suspendedTaskCountAsString;

  @JsonbProperty(JSON_STARTED_TASK_COUNT)
  private Integer startedTaskCount;

  @JsonbProperty(JSON_STARTED_TASK_COUNT_AS_STRING)
  private String startedTaskCountAsString;

  @JsonbProperty(JSON_STOPPED_TASK_COUNT_AS_STRING)
  private String stoppedTaskCountAsString;

  @JsonbProperty(JSON_REALIZED_TASK_COUNT)
  private Integer realizedTaskCount;

  @JsonbProperty(JSON_REALIZED_TASK_COUNT_AS_STRING)
  private String realizedTaskCountAsString;

  @JsonbProperty(JSON_LATE_TASK_COUNT)
  private Integer lateTaskCount;

  @JsonbProperty(JSON_LATE_TASK_COUNT_AS_STRING)
  private String lateTaskCountAsString;

  @JsonbProperty(JSON_NOT_LATE_TASK_COUNT_AS_STRING)
  private String notLateTaskCountAsString;

  @JsonbProperty(JSON_TASK_EARLIEST_FROM_DATE_AS_STRING)
  private String taskEarliestFromDateAsString;

  @JsonbProperty(JSON_TASK_LATEST_TO_DATE_AS_STRING)
  private String taskLatestToDateAsString;

  @JsonbProperty(JSON_TASK_COUNT)
  private Integer taskCount;

  @JsonbProperty(JSON_TASK_COUNT_AS_STRING)
  private String taskCountAsString;

  @JsonbProperty(JSON_DONE_TASK_COUNT)
  private Integer doneTaskCount;

  @JsonbProperty(JSON_DONE_TASK_COUNT_AS_STRING)
  private String doneTaskCountAsString;

  @JsonbProperty(JSON_NOT_DONE_TASK_COUNT_AS_STRING)
  private String notDoneTaskCountAsString;

  @JsonbProperty(JSON_PENDING_START_TASK_COUNT)
  private Integer pendingStartTaskCount;

  @JsonbProperty(JSON_PENDING_START_TASK_COUNT_AS_STRING)
  private String pendingStartTaskCountAsString;

  /**
   * Identifiant json de {@link AdministrativeUnitIdentityDto}.
   */
  public static final String JSON_THIS = "identite";

  /**
   * Identifiant json identifiant de {@link AdministrativeUnitIdentityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idIdentite";

  /**
   * Identifiant json champ {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "identité d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "identités d'unités administratives";
}
