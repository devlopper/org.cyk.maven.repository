package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre du journal des événements d'Archivage de fichier de groupe.
 *
 * @author Christian
 */
@Getter
@Setter
public class FileGroupArchivalJournalEntryFilter extends AbstractIdentifiableFilter {

  private String fileGroupIdentifier;
  private Set<String> eventTypes;
  private String requestIdentifier;
  private String archiveIdentifier;
  private String actorIdentifier;

  public FileGroupArchivalJournalEntryFilter() {
    super();
  }

  public FileGroupArchivalJournalEntryFilter(FilterDto filter) {
    super(filter);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    fileGroupIdentifier = getFileGroupIdentifier(filter);
    eventTypes = getEventTypes(filter);
    requestIdentifier = getRequestIdentifier(filter);
    archiveIdentifier = getArchiveIdentifier(filter);
    actorIdentifier = getActorIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFileGroupIdentifier(filter, fileGroupIdentifier);
    setEventTypes(filter, eventTypes);
    setRequestIdentifier(filter, requestIdentifier);
    setArchiveIdentifier(filter, archiveIdentifier);
    setActorIdentifier(filter, actorIdentifier);
  }

  public static void setFileGroupIdentifier(FilterDto filter, String fileGroupIdentifier) {
    set(filter, JSON_FILE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(fileGroupIdentifier));
  }

  public static String getFileGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FILE_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les types d'événement.
   *
   * @param filter filtre
   * @param eventTypes types d'événement
   */
  public static void setEventTypes(FilterDto filter, Set<String> eventTypes) {
    set(filter, JSON_EVENT_TYPES, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet((LinkedHashSet<String>) Core
            .getOrNullifyIfCollectionEmpty(Core.getLinkedHashSet(eventTypes))));
  }

  public static Set<String> getEventTypes(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_EVENT_TYPES));
  }

  public static void setRequestIdentifier(FilterDto filter, String requestIdentifier) {
    set(filter, JSON_REQUEST_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(requestIdentifier));
  }

  public static String getRequestIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REQUEST_IDENTIFIER));
  }

  public static void setArchiveIdentifier(FilterDto filter, String archiveIdentifier) {
    set(filter, JSON_ARCHIVE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(archiveIdentifier));
  }

  public static String getArchiveIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ARCHIVE_IDENTIFIER));
  }

  public static void setActorIdentifier(FilterDto filter, String actorIdentifier) {
    set(filter, JSON_ACTOR_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(actorIdentifier));
  }

  public static String getActorIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTOR_IDENTIFIER));
  }

  public static final String JSON_FILE_GROUP_IDENTIFIER =
      FileGroupArchivalJournalEntryDto.JSON_FILE_GROUP_IDENTIFIER;
  public static final String JSON_EVENT_TYPES = "typesEvenement";
  public static final String JSON_REQUEST_IDENTIFIER =
      FileGroupArchivalJournalEntryDto.JSON_REQUEST_IDENTIFIER;
  public static final String JSON_ARCHIVE_IDENTIFIER =
      FileGroupArchivalJournalEntryDto.JSON_ARCHIVE_IDENTIFIER;
  public static final String JSON_ACTOR_IDENTIFIER =
      FileGroupArchivalJournalEntryDto.JSON_ACTOR_IDENTIFIER;
}
