package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueSelectorDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueSelectorRequestMapperImpl implements ValueSelectorRequestMapper {

    @Override
    public ValueSelectorService.ValueSelectorCreateRequestDto mapCreate(ValueSelectorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSelectorService.ValueSelectorCreateRequestDto valueSelectorCreateRequestDto = new ValueSelectorService.ValueSelectorCreateRequestDto();

        valueSelectorCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueSelectorCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueSelectorCreateRequestDto.setCode( arg0.getCode() );
        valueSelectorCreateRequestDto.setName( arg0.getName() );
        valueSelectorCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        valueSelectorCreateRequestDto.setFilterAttributeName( arg0.getFilterAttributeName() );

        return valueSelectorCreateRequestDto;
    }

    @Override
    public ValueSelectorService.ValueSelectorUpdateRequestDto mapUpdate(ValueSelectorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSelectorService.ValueSelectorUpdateRequestDto valueSelectorUpdateRequestDto = new ValueSelectorService.ValueSelectorUpdateRequestDto();

        valueSelectorUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueSelectorUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueSelectorUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueSelectorUpdateRequestDto.setCode( arg0.getCode() );
        valueSelectorUpdateRequestDto.setName( arg0.getName() );
        valueSelectorUpdateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        valueSelectorUpdateRequestDto.setFilterAttributeName( arg0.getFilterAttributeName() );

        return valueSelectorUpdateRequestDto;
    }

    @Override
    public ValueSelectorService.ValueSelectorEvaluateRequestDto mapEvaluate(ValueSelectorDto valueSelector) {
        if ( valueSelector == null ) {
            return null;
        }

        ValueSelectorService.ValueSelectorEvaluateRequestDto valueSelectorEvaluateRequestDto = new ValueSelectorService.ValueSelectorEvaluateRequestDto();

        valueSelectorEvaluateRequestDto.setAuditWho( valueSelector.getAuditWho() );
        valueSelectorEvaluateRequestDto.setAuditSession( valueSelector.getAuditSession() );
        valueSelectorEvaluateRequestDto.setIdentifier( valueSelector.getIdentifier() );
        valueSelectorEvaluateRequestDto.setFilterAttributeValue( valueSelector.getFilterAttributeValue() );
        valueSelectorEvaluateRequestDto.setDataEntityIdentifier( valueSelector.getDataEntityIdentifier() );

        return valueSelectorEvaluateRequestDto;
    }
}
