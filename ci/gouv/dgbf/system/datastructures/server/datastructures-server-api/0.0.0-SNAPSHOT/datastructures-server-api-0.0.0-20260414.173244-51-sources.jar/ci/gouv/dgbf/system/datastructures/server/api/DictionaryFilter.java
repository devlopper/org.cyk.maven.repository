package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DictionaryDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class DictionaryFilter extends AbstractIdentifiableFilter {
  
}

