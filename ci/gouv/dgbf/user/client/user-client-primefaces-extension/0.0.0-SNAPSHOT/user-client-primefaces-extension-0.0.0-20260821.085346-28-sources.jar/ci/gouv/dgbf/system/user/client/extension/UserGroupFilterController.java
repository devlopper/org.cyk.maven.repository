package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link UserGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UserGroupFilterController extends AbstractFilterController<UserGroupFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public UserGroupFilterController() {
    super(UserGroupFilter.class);
  }
}
