package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un poste de dépense.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureItemDto extends AbstractExpenditureOrResourceItemDto {

  /*
   * Identifiant {@link ExpenditureActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /*
   * Code {@link ExpenditureActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_CODE)
  private String activityCode;

  /*
   * Réprésentation en chaine de caractère {@link ExpenditureActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /*
   * Identifiant {@link FundingSourceDto}.
   */
  @JsonbProperty(JSON_FUNDING_SOURCE_IDENTIFIER)
  private String fundingSourceIdentifier;

  /*
   * Code {@link FundingSourceDto}.
   */
  @JsonbProperty(JSON_FUNDING_SOURCE_CODE)
  private String fundingSourceCode;

  /*
   * Réprésentation en chaine de caractère {@link FundingSourceDto}.
   */
  @JsonbProperty(JSON_FUNDING_SOURCE_AS_STRING)
  private String fundingSourceAsString;

  /*
   * Identifiant {@link LessorDto}.
   */
  @JsonbProperty(JSON_LESSOR_IDENTIFIER)
  private String lessorIdentifier;

  /*
   * Code {@link LessorDto}.
   */
  @JsonbProperty(JSON_LESSOR_CODE)
  private String lessorCode;

  /*
   * Réprésentation en chaine de caractère {@link LessorDto}.
   */
  @JsonbProperty(JSON_LESSOR_AS_STRING)
  private String lessorAsString;

  /*
   * Identifiant {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /*
   * Code {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CODE)
  private String administrativeUnitCode;

  /*
   * Réprésentation en chaine de caractères {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /*
   * Identifiant {@link SectionDto}.
   */
  @JsonbProperty(JSON_SECTION_IDENTIFIER)
  private String sectionIdentifier;

  /*
   * Réprésentation en chaine de caractères {@link SectionDto}.
   */
  @JsonbProperty(JSON_SECTION_AS_STRING)
  private String sectionAsString;

  /**
   * Identifiant json champ {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #activityCode}.
   */
  public static final String JSON_ACTIVITY_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_CODE;

  /**
   * Identifiant json champ {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_AS_STRING;

  /**
   * Identifiant json champ {@link #fundingSourceIdentifier}.
   */
  public static final String JSON_FUNDING_SOURCE_IDENTIFIER = FundingSourceDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #fundingSourceCode}.
   */
  public static final String JSON_FUNDING_SOURCE_CODE = "codeSourceFinancement";

  /**
   * Identifiant json champ {@link #fundingSourceAsString}.
   */
  public static final String JSON_FUNDING_SOURCE_AS_STRING = FundingSourceDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #lessorIdentifier}.
   */
  public static final String JSON_LESSOR_IDENTIFIER = LessorDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #lessorCode}.
   */
  public static final String JSON_LESSOR_CODE = "codeBailleur";

  /**
   * Identifiant json champ {@link #lessorAsString}.
   */
  public static final String JSON_LESSOR_AS_STRING = LessorDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #administrativeUnitCode}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_CODE = AdministrativeUnitDto.JSON_THIS_CODE;

  /**
   * Identifiant json champ {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      AdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #sectionIdentifier}.
   */
  public static final String JSON_SECTION_IDENTIFIER = SectionDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #sectionAsString}.
   */
  public static final String JSON_SECTION_AS_STRING = SectionDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de dépense";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de dépense";
}
