package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le rattachement d'un Élément de Paie ou d'une Constante de Paie à un
 * Type de Réclamation, avec son Mode de Saisie (RG_REP_CIB_01/04).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimTypeObjectDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Nature de l'objet ciblé : {@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE} (RG_REP_CIB_01).
   */
  @JsonbProperty(JSON_OBJECT_NATURE)
  private String objectNature;

  /**
   * Identifiant de l'Élément de Paie ou de la Constante de Paie ciblé(e), module {@code payroll}
   * -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_OBJECT_IDENTIFIER)
  private String objectIdentifier;

  /**
   * Mode de Saisie : {@code FAE} ou {@code AGENT} (RG_REP_CIB_04).
   */
  @JsonbProperty(JSON_VALUE_INPUT_MODE)
  private String valueInputMode;

  /**
   * Identifiant json {@link #objectNature}.
   */
  public static final String JSON_OBJECT_NATURE = "nature";

  /**
   * Identifiant json {@link #objectIdentifier}.
   */
  public static final String JSON_OBJECT_IDENTIFIER = "idCible";

  /**
   * Identifiant json {@link #valueInputMode}.
   */
  public static final String JSON_VALUE_INPUT_MODE = "modeSaisie";

  /**
   * Identifiant json de identifiant de {@link ClaimTypeObjectDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRattachement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimTypeObjectDto}.
   */
  public static final String JSON_THIS_AS_STRING = "rattachementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rattachement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "rattachements";
}
