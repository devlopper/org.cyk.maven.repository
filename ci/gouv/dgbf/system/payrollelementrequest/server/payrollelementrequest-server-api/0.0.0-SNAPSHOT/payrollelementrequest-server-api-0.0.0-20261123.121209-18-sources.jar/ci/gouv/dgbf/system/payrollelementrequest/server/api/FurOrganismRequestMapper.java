package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurOrganismService.FurOrganismCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurOrganismService.FurOrganismUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FurOrganismDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FurOrganismDto}.

    @author akm
               """)
public interface FurOrganismRequestMapper extends
    RequestMapper<FurOrganismDto, FurOrganismCreateRequestDto,
        FurOrganismUpdateRequestDto> {

}
