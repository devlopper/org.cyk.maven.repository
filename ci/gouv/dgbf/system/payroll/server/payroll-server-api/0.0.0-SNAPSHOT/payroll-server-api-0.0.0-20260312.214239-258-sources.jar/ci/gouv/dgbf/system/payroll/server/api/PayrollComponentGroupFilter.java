package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollComponentGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class PayrollComponentGroupFilter extends AbstractIdentifiableFilter {
  
}
