package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette énumeration représente les catégories d'activités.
 *
 * @author Christian
 *
 */
public enum ActivityCategory {

  /**
   * Action.
   */
  ACTION,
  
  /**
   * Fonctionnement.
   */
  FUNCTIONING,
  
  /**
   * Opération.
   */
  OPERATION

  ;
  
  /**
   * Cette méthode permet de savoir si il y a une nature économique.
   *
   * @param category catégorie
   * @return vrai ou faux
   */
  public static boolean hasEconomicNature(ActivityCategory category) {
    return ACTION.equals(category) || FUNCTIONING.equals(category);
  }

}
