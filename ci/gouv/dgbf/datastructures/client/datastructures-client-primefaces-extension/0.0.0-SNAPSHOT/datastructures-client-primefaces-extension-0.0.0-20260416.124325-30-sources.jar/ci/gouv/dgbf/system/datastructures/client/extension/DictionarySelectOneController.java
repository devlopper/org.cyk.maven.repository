package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryClient;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryFilter;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryService.DictionaryGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DictionaryDto}.
 *
 * @author Desysoft
 */
@Dependent
public class DictionarySelectOneController extends AbstractSelectOneIdentifiableController<
    DictionaryDto, DictionaryGetManyResponseDto, DictionaryClient> {

  @Getter
  @Inject
  DictionaryClient client;


  protected DictionarySelectOneController() {
    super(DictionaryDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
