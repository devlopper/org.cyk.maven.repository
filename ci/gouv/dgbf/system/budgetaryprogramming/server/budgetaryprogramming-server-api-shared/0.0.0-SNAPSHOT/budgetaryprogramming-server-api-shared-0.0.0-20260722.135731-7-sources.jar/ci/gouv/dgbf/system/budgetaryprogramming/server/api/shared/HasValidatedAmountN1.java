package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant validé à l'horizon N1.
 *
 * @author Christian
 */
public interface HasValidatedAmountN1 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant validé à l'horizon N1.
   *
   * @return le montant validé à l'horizon N1
   */
  Long getValidatedAmountN1();

  /**
   * Cette méthode permet d'assigner le montant validé à l'horizon N1.
   *
   * @param amount le montant validé à l'horizon N1
   */
  void setValidatedAmountN1(Long amount);

  /**
   * Identifiant java du montant validé à l'horizon N1.
   */
  String FIELD_VALIDATED_AMOUNT_N1 = "validatedAmountN1";
}
