package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de
 * caractères de groupe de type de réclamation.
 *
 * @author akm
 *
 */
public interface HasClaimTypeGroupAsStringDto {

  /**
   * Identifiant json de la représentation en chaine de caractères du groupe de type de
   * réclamation.
   */
  String JSON_CLAIM_TYPE_GROUP_AS_STRING = "groupeTypeReclamationChaine";

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du groupe de type
   * de réclamation.
   *
   * @return représentation en chaine de caractères du groupe de type de réclamation
   */
  String getClaimTypeGroupAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du groupe de type
   * de réclamation.
   *
   * @param claimTypeGroupAsString représentation en chaine de caractères du groupe de type de
   *        réclamation
   */
  void setClaimTypeGroupAsString(String claimTypeGroupAsString);
}
