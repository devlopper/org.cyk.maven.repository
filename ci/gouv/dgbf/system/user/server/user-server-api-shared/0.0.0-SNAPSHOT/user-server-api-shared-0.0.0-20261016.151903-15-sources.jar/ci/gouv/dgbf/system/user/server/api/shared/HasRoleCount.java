package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de rôles métier.
 *
 * @author Christian Yao Komenan
 */
public interface HasRoleCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de rôles métier.
   *
   * @return le nombre de rôles métier
   */
  Integer getRoleCount();

  /**
   * Cette méthode permet d'assigner le nombre de rôles métier.
   *
   * @param roleCount le nombre de rôles métier
   */
  void setRoleCount(Integer roleCount);

  /**
   * Identifiant java du nombre de rôles métier.
   */
  String FIELD_ROLE_COUNT = "roleCount";
}
