package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingImputationDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingImputationService.PATH)
@Tag(name = "Gestion des Imputations de Programmation")
public interface ProgrammingImputationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "imputationsProgrammation";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingImputationSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de la programmation.
     *
     * @return identifiant de la programmation
     */
    String getProgrammingIdentifier();

    /**
     * Définit l'identifiant de la programmation.
     *
     * @param programmingIdentifier l'identifiant de la programmation
     */
    void setProgrammingIdentifier(String programmingIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'imputation.
     *
     * @return identifiant de l'imputation
     */
    String getImputationIdentifier();

    /**
     * Définit l'identifiant de l'imputation.
     *
     * @param imputationIdentifier l'identifiant de l'imputation
     */
    void setImputationIdentifier(String imputationIdentifier);

    /**
     * Cette méthode indique si l'imputation est une dépense.
     *
     * @return oui ou non si l'imputation est une dépense
     */
    Boolean getExpenditure();

    /**
     * Définit si l'imputation est une dépense.
     *
     * @param expenditure indique si l'imputation est une dépense
     */
    void setExpenditure(Boolean expenditure);

    /**
     * Montant saisi pour l'horizon N.
     *
     * @return montant ou {@code null}
     */
    Long getInputtedAmountN();

    /**
     * Définit le montant saisi pour l'horizon N.
     *
     * @param inputtedAmountN montant
     */
    void setInputtedAmountN(Long inputtedAmountN);

    /**
     * Montant saisi pour l'horizon N+1.
     *
     * @return montant ou {@code null}
     */
    Long getInputtedAmountN1();

    /**
     * Définit le montant saisi pour l'horizon N+1.
     *
     * @param inputtedAmountN1 montant
     */
    void setInputtedAmountN1(Long inputtedAmountN1);

    /**
     * Montant saisi pour l'horizon N+2.
     *
     * @return montant ou {@code null}
     */
    Long getInputtedAmountN2();

    /**
     * Définit le montant saisi pour l'horizon N+2.
     *
     * @param inputtedAmountN2 montant
     */
    void setInputtedAmountN2(Long inputtedAmountN2);

    /**
     * Montant arbitré pour l'horizon N.
     *
     * @return montant ou {@code null}
     */
    Long getArbitratedAmountN();

    /**
     * Définit le montant arbitré pour l'horizon N.
     *
     * @param arbitratedAmountN montant
     */
    void setArbitratedAmountN(Long arbitratedAmountN);

    /**
     * Montant arbitré pour l'horizon N+1.
     *
     * @return montant ou {@code null}
     */
    Long getArbitratedAmountN1();

    /**
     * Définit le montant arbitré pour l'horizon N+1.
     *
     * @param arbitratedAmountN1 montant
     */
    void setArbitratedAmountN1(Long arbitratedAmountN1);

    /**
     * Montant arbitré pour l'horizon N+2.
     *
     * @return montant ou {@code null}
     */
    Long getArbitratedAmountN2();

    /**
     * Définit le montant arbitré pour l'horizon N+2.
     *
     * @param arbitratedAmountN2 montant
     */
    void setArbitratedAmountN2(Long arbitratedAmountN2);

    /**
     * Montant validé pour l'horizon N.
     *
     * @return montant ou {@code null}
     */
    Long getValidatedAmountN();

    /**
     * Définit le montant validé pour l'horizon N.
     *
     * @param validatedAmountN montant
     */
    void setValidatedAmountN(Long validatedAmountN);

    /**
     * Montant validé pour l'horizon N+1.
     *
     * @return montant ou {@code null}
     */
    Long getValidatedAmountN1();

    /**
     * Définit le montant validé pour l'horizon N+1.
     *
     * @param validatedAmountN1 montant
     */
    void setValidatedAmountN1(Long validatedAmountN1);

    /**
     * Montant validé pour l'horizon N+2.
     *
     * @return montant ou {@code null}
     */
    Long getValidatedAmountN2();

    /**
     * Définit le montant validé pour l'horizon N+2.
     *
     * @param validatedAmountN2 montant
     */
    void setValidatedAmountN2(Long validatedAmountN2);

    /**
     * Montant intégré pour l'horizon N.
     *
     * @return montant ou {@code null}
     */
    Long getIntegratedAmountN();

    /**
     * Définit le montant intégré pour l'horizon N.
     *
     * @param integratedAmountN montant
     */
    void setIntegratedAmountN(Long integratedAmountN);

    /**
     * Montant intégré pour l'horizon N+1.
     *
     * @return montant ou {@code null}
     */
    Long getIntegratedAmountN1();

    /**
     * Définit le montant intégré pour l'horizon N+1.
     *
     * @param integratedAmountN1 montant
     */
    void setIntegratedAmountN1(Long integratedAmountN1);

    /**
     * Montant intégré pour l'horizon N+2.
     *
     * @return montant ou {@code null}
     */
    Long getIntegratedAmountN2();

    /**
     * Définit le montant intégré pour l'horizon N+2.
     *
     * @param integratedAmountN2 montant
     */
    void setIntegratedAmountN2(Long integratedAmountN2);

    /**
     * Identifiant de la programmation.
     */
    String JSON_PROGRAMMING_IDENTIFIER = ProgrammingImputationDto.JSON_PROGRAMMING_IDENTIFIER;

    /**
     * Identifiant de l'imputation.
     */
    String JSON_IMPUTATION_IDENTIFIER = ProgrammingImputationDto.JSON_IMPUTATION_IDENTIFIER;

    /**
     * Indicateur si l'imputation est une dépense.
     */
    String JSON_EXPENDITURE = ProgrammingImputationDto.JSON_EXPENDITURE;

    /**
     * Identifiant json pour le montant saisi N.
     */
    String JSON_INPUTTED_AMOUNT_N = ProgrammingImputationDto.JSON_INPUTTED_AMOUNT_N;

    /**
     * Identifiant json pour le montant saisi N+1.
     */
    String JSON_INPUTTED_AMOUNT_N1 = ProgrammingImputationDto.JSON_INPUTTED_AMOUNT_N1;

    /**
     * Identifiant json pour le montant saisi N+2.
     */
    String JSON_INPUTTED_AMOUNT_N2 = ProgrammingImputationDto.JSON_INPUTTED_AMOUNT_N2;

    /**
     * Identifiant json pour le montant arbitré N.
     */
    String JSON_ARBITRATED_AMOUNT_N = ProgrammingImputationDto.JSON_ARBITRATED_AMOUNT_N;

    /**
     * Identifiant json pour le montant arbitré N+1.
     */
    String JSON_ARBITRATED_AMOUNT_N1 = ProgrammingImputationDto.JSON_ARBITRATED_AMOUNT_N1;

    /**
     * Identifiant json pour le montant arbitré N+2.
     */
    String JSON_ARBITRATED_AMOUNT_N2 = ProgrammingImputationDto.JSON_ARBITRATED_AMOUNT_N2;

    /**
     * Identifiant json pour le montant validé N.
     */
    String JSON_VALIDATED_AMOUNT_N = ProgrammingImputationDto.JSON_VALIDATED_AMOUNT_N;

    /**
     * Identifiant json pour le montant validé N+1.
     */
    String JSON_VALIDATED_AMOUNT_N1 = ProgrammingImputationDto.JSON_VALIDATED_AMOUNT_N1;

    /**
     * Identifiant json pour le montant validé N+2.
     */
    String JSON_VALIDATED_AMOUNT_N2 = ProgrammingImputationDto.JSON_VALIDATED_AMOUNT_N2;

    /**
     * Identifiant json pour le montant intégré N.
     */
    String JSON_INTEGRATED_AMOUNT_N = ProgrammingImputationDto.JSON_INTEGRATED_AMOUNT_N;

    /**
     * Identifiant json pour le montant intégré N+1.
     */
    String JSON_INTEGRATED_AMOUNT_N1 = ProgrammingImputationDto.JSON_INTEGRATED_AMOUNT_N1;

    /**
     * Identifiant json pour le montant intégré N+2.
     */
    String JSON_INTEGRATED_AMOUNT_N2 = ProgrammingImputationDto.JSON_INTEGRATED_AMOUNT_N2;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingImputationDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingImputationDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingImputationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingImputationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingImputationCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingImputationSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_IMPUTATION_IDENTIFIER)
    private String imputationIdentifier;
    
    @JsonbProperty(JSON_EXPENDITURE)
    private Boolean expenditure;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N)
    private Long inputtedAmountN;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N1)
    private Long inputtedAmountN1;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N2)
    private Long inputtedAmountN2;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N)
    private Long arbitratedAmountN;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1)
    private Long arbitratedAmountN1;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2)
    private Long arbitratedAmountN2;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N)
    private Long validatedAmountN;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N1)
    private Long validatedAmountN1;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N2)
    private Long validatedAmountN2;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N)
    private Long integratedAmountN;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N1)
    private Long integratedAmountN1;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N2)
    private Long integratedAmountN2;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingImputationDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingImputationDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingImputationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingImputationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingImputationGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingImputationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingImputationDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingImputationDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingImputationDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingImputationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingImputationDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingImputationDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingImputationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingImputationDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingImputationDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingImputationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProgrammingImputationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingImputationUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingImputationSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_IMPUTATION_IDENTIFIER)
    private String imputationIdentifier;
    
    @JsonbProperty(JSON_EXPENDITURE)
    private Boolean expenditure;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N)
    private Long inputtedAmountN;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N1)
    private Long inputtedAmountN1;

    @JsonbProperty(JSON_INPUTTED_AMOUNT_N2)
    private Long inputtedAmountN2;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N)
    private Long arbitratedAmountN;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1)
    private Long arbitratedAmountN1;

    @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2)
    private Long arbitratedAmountN2;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N)
    private Long validatedAmountN;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N1)
    private Long validatedAmountN1;

    @JsonbProperty(JSON_VALIDATED_AMOUNT_N2)
    private Long validatedAmountN2;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N)
    private Long integratedAmountN;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N1)
    private Long integratedAmountN1;

    @JsonbProperty(JSON_INTEGRATED_AMOUNT_N2)
    private Long integratedAmountN2;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingImputationDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_IMPUTATION_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingImputationDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingImputationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
