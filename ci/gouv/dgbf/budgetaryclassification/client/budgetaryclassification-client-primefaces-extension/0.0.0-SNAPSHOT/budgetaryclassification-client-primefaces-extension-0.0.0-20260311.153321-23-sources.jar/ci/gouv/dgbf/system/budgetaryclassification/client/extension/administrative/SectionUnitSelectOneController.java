package ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SectionUnitDto}.
 *
 * @author stephane
 *
 */
@Dependent
public class SectionUnitSelectOneController extends AbstractSelectOneIdentifiableController<
    SectionUnitDto, SectionUnitGetManyResponseDto, SectionUnitClient> {

  @Getter
  @Inject
  SectionUnitClient client;

  protected SectionUnitSelectOneController() {
    super(SectionUnitDto.class, SelectItemLabelStrategy.NAME);
  }
}
