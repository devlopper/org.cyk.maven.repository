package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SubAdministrativeUnitDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-17T13:14:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SubAdministrativeUnitRequestMapperImpl implements SubAdministrativeUnitRequestMapper {

    @Override
    public SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto mapCreate(SubAdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto subAdministrativeUnitCreateRequestDto = new SubAdministrativeUnitService.SubAdministrativeUnitCreateRequestDto();

        subAdministrativeUnitCreateRequestDto.setName( arg0.getName() );
        subAdministrativeUnitCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        subAdministrativeUnitCreateRequestDto.setType( arg0.getType() );

        return subAdministrativeUnitCreateRequestDto;
    }

    @Override
    public SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto mapUpdate(SubAdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto subAdministrativeUnitUpdateRequestDto = new SubAdministrativeUnitService.SubAdministrativeUnitUpdateRequestDto();

        subAdministrativeUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        subAdministrativeUnitUpdateRequestDto.setName( arg0.getName() );
        subAdministrativeUnitUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        subAdministrativeUnitUpdateRequestDto.setType( arg0.getType() );

        return subAdministrativeUnitUpdateRequestDto;
    }
}
