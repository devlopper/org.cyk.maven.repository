package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.ActivityService.ActivityCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.ActivityService.ActivityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ActivityDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ActivityDto}.

    @author Christian
               """)
public interface ActivityRequestMapper extends
    RequestMapper<ActivityDto, ActivityCreateRequestDto, ActivityUpdateRequestDto> {

}
