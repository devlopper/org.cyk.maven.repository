package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+1 est complétée,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN1AsString {

  /**
   * Obtient l'indicateur indiquant si l'année N+1 est complétée,
   * sous forme de chaîne de caractères.
   *
   * @return l'indicateur indiquant si l'année N+1 est complétée sous forme de chaîne de caractères
   */
  String getCompletedN1AsString();

  /**
   * Définit l'indicateur indiquant si l'année N+1 est complétée,
   * sous forme de chaîne de caractères.
   *
   * @param completedN1AsString indicateur indiquant si l'année N+1 est complétée
   *        sous forme de chaîne de caractères
   */
  void setCompletedN1AsString(String completedN1AsString);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N+1 est complétée,
   * sous forme de chaîne de caractères.
   */
  String FIELD_COMPLETED_N1_AS_STRING = "completedN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName