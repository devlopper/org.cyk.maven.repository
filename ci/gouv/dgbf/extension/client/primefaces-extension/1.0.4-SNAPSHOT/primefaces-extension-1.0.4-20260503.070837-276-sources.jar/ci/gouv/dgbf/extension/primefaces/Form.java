package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un formulaire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Form implements IdentifiableByString {

  String identifier;
  
}
