package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterColumnNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasProjectionColumnNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasTableNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueReferenceDto}.
 *
 * @author Christian
 *
 */
@Path(value = ValueReferenceService.PATH)
@Tag(name = "Gestion des références de valeur")
public interface ValueReferenceService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "references-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueReferenceSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
     *
     * @return identifiant de {@link DomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
     *
     * @param domainIdentifier identifiant de {@link DomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir le nom de la table.
     *
     * @return nom de la table
     */
    String getTableName();

    /**
     * Cette méthode permet d'assigner le nom de la table.
     *
     * @param tableName nom de la table
     */
    void setTableName(String tableName);

    /**
     * Cette méthode permet d'obtenir le nom de la colonne de projection.
     *
     * @return nom de la colonne de projection
     */
    String getProjectionColumnName();

    /**
     * Cette méthode permet d'assigner le nom de la colonne de projection.
     *
     * @param projectionColumnName nom de la colonne de projection
     */
    void setProjectionColumnName(String projectionColumnName);

    /**
     * Cette méthode permet d'obtenir le nom de la colonne de filtre.
     *
     * @return nom de la colonne de filtre
     */
    String getFilterColumnName();

    /**
     * Cette méthode permet d'assigner le nom de la colonne de filtre.
     *
     * @param filterColumnName nom de la colonne de filtre
     */
    void setFilterColumnName(String filterColumnName);

    /**
     * Cette méthode permet d'obtenir {@link ValueType}.
     *
     * @return {@link ValueType}
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner {@link ValueType}.
     *
     * @param valueType {@link ValueType}
     */
    void setValueType(ValueType valueType);

    /**
     * {@link HasDomainIdentifierDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * {@link HasTableNameDto#JSON_TABLE_NAME}.
     */
    String JSON_TABLE_NAME = HasTableNameDto.JSON_TABLE_NAME;

    /**
     * {@link HasProjectionColumnNameDto#JSON_PROJECTION_COLUMN_NAME}.
     */
    String JSON_PROJECTION_COLUMN_NAME = HasProjectionColumnNameDto.JSON_PROJECTION_COLUMN_NAME;

    /**
     * {@link HasFilterColumnNameDto#JSON_FILTER_COLUMN_NAME}.
     */
    String JSON_FILTER_COLUMN_NAME = HasFilterColumnNameDto.JSON_FILTER_COLUMN_NAME;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SOURCE_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueReferenceCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueReferenceCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ValueReferenceSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_TABLE_NAME)
    private String tableName;

    @JsonbProperty(JSON_PROJECTION_COLUMN_NAME)
    private String projectionColumnName;

    @JsonbProperty(JSON_FILTER_COLUMN_NAME)
    private String filterColumnName;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueReferenceGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueReferenceGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueReferenceDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueReferenceDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueReferenceDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueReferenceDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SOURCE_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueReferenceUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueReferenceUpdateRequestDto extends ByIdentifierRequestDto
      implements ValueReferenceSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_TABLE_NAME)
    private String tableName;

    @JsonbProperty(JSON_PROJECTION_COLUMN_NAME)
    private String projectionColumnName;

    @JsonbProperty(JSON_FILTER_COLUMN_NAME)
    private String filterColumnName;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SOURCE_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueReferenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
