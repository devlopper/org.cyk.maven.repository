package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.OutputLabel;
import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.extension.primefaces.component.input.AutoCompleteString;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneMenuString;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneRadioString;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link AbstractSelectOneController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class SelectOneControllerMocker<T extends AbstractSelectOneController> {

  Class<T> clazz;

  SelectOneMenuString selectOneMenu;

  SelectOneRadioString selectOneRadio;

  AutoCompleteString autoComplete;

  /**
   * Cette méthode permet d'instancier.
   *
   * @param clazz classe
   */
  public SelectOneControllerMocker(Class<T> clazz) {
    this.clazz = clazz;
    selectOneMenu = new SelectOneMenuString();
    selectOneMenu.setOutputLabel(new OutputLabel());
    
    selectOneRadio = new SelectOneRadioString();
    selectOneRadio.setOutputLabel(new OutputLabel());
    
    autoComplete = new AutoCompleteString(new ScriptManager());
    autoComplete.setOutputLabel(new OutputLabel());
  }

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link AbstractSelectOneController}
   */
  public T mock() {
    T controller = Mockito.mock(clazz);
    Mockito.when(controller.getSelectOneMenu()).thenReturn(selectOneMenu);
    Mockito.when(controller.getSelectOneRadio()).thenReturn(selectOneRadio);
    Mockito.when(controller.getAutoComplete()).thenReturn(autoComplete);

    if (controller instanceof AbstractSelectOneIdentifiableController<?, ?,
        ?> selectOneIdentifiableController) {
      Mockito.when(selectOneIdentifiableController.filter()).thenReturn(new FilterDto());
    }

    return controller;
  }

}
