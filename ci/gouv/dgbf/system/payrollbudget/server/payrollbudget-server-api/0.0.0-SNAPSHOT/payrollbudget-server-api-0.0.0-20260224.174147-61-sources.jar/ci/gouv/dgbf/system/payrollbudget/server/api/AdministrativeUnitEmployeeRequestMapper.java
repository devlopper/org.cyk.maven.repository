package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitEmployeeService.AdministrativeUnitEmployeeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link AdministrativeUnitEmployeeDto}.

    @author Christian
               """)
public interface AdministrativeUnitEmployeeRequestMapper
    extends RequestMapper<AdministrativeUnitEmployeeDto, AdministrativeUnitEmployeeCreateRequestDto,
        AdministrativeUnitEmployeeUpdateRequestDto> {

}
