package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitIdentifierDto extends HasAdministrativeUnitIdentifier {

  /**
   * Identifiant json de l'identifiant de l'unité administrative.
   */
  String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";
}