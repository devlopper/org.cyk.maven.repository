package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de rôle.
 *
 * @author BoobaCool
 */
public interface FilterHasRoleIdentifier extends HasRoleIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du rôle.
   *
   * @param filter {@link FilterDto}
   */
  default void updateRoleIdentifier(FilterDto filter) {
    setRoleIdentifier(RoleIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du rôle de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterRoleIdentifier(FilterDto filter) {
    RoleIdentifierFilter.set(filter, getRoleIdentifier());
  }

}
