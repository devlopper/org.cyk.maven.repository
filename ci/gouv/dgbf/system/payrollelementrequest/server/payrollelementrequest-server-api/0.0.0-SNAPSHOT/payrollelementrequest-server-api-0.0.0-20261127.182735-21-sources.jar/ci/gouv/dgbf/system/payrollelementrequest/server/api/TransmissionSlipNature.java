package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import lombok.Getter;

/**
 * Cette énumération représente la nature d'un bordereau de transmission (RG_REP_RVR_17) : l'étape
 * du circuit de validation dont la transmission est constatée. {@link #code} est la valeur
 * transmise au gabarit d'impression, {@link #numberCode} la partie du numéro de bordereau propre à
 * la nature.
 *
 * @author akm
 *
 */
@Getter
public enum TransmissionSlipNature {

  /**
   * Transmission pour Visa : de l'Agent de Traitement vers son Responsable.
   */
  VISA("VISA", "VIS", "Visa"),

  /**
   * Transmission pour Contrôle : du Responsable vers l'Agent de Contrôle.
   */
  CONTROL("CONTROLE", "CTR", "Contrôle"),

  /**
   * Transmission pour Validation : de l'Agent de Contrôle vers le Responsable de Structure.
   */
  VALIDATION("VALIDATION", "VAL", "Validation"),

  /**
   * Transmission au Trésor : du Responsable de Structure vers l'Agent Trésor (Validation
   * Déléguée).
   */
  TREASURY("TRESOR", "TRS", "Trésor");

  private final String code;

  private final String numberCode;

  private final String name;

  TransmissionSlipNature(String code, String numberCode, String name) {
    this.code = code;
    this.numberCode = numberCode;
    this.name = name;
  }

  /**
   * Cette méthode permet d'obtenir une nature à partir de son code.
   *
   * @param code code de la nature
   * @return nature correspondante
   * @throws IllegalArgumentException si le code est inconnu
   */
  public static TransmissionSlipNature getByCode(String code) {
    for (TransmissionSlipNature nature : values()) {
      if (nature.code.equals(code)) {
        return nature;
      }
    }
    throw new IllegalArgumentException("Code <<%s>> inconnu".formatted(code));
  }

  /**
   * Cette méthode permet d'obtenir la nature d'un bordereau à partir de son numéro
   * ({@code BT-<nature>-<année>-<suite>}).
   *
   * @param number numéro du bordereau
   * @return nature correspondante
   * @throws IllegalArgumentException si le numéro n'est pas celui d'un bordereau
   */
  public static TransmissionSlipNature getByNumber(String number) {
    String[] parts = number == null ? new String[0] : number.split("-");
    if (parts.length == NUMBER_PARTS && NUMBER_PREFIX.equals(parts[0])) {
      for (TransmissionSlipNature nature : values()) {
        if (nature.numberCode.equals(parts[1])) {
          return nature;
        }
      }
    }
    throw new IllegalArgumentException("Numéro <<%s>> inconnu".formatted(number));
  }

  /**
   * Préfixe commun des numéros de bordereau.
   */
  public static final String NUMBER_PREFIX = "BT";

  private static final int NUMBER_PARTS = 4;

  @Override
  public String toString() {
    return name;
  }
}
