package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableInstanceService.ClaimableInstanceGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableInstanceService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableInstanceClient extends AbstractClient<ClaimableInstanceService>
    implements GetByIdentifier<ClaimableInstanceDto>,
    GetMany<ClaimableInstanceGetManyResponseDto> {

  @Override
  public ClaimableInstanceClient service(ClaimableInstanceService service) {
    return (ClaimableInstanceClient) super.service(service);
  }

  /**
   * {@link ClaimableInstanceService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableInstanceGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableInstanceGetManyResponseDto>(
        ClaimableInstanceGetManyResponseDto.class, ClaimableInstanceService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableInstanceService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableInstanceGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableInstanceService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableInstanceDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableInstanceDto>(ClaimableInstanceDto.class,
        ClaimableInstanceService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableInstanceService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableInstanceDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
