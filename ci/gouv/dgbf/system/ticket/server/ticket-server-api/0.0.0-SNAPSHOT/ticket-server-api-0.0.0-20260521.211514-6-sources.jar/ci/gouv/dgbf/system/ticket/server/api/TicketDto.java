package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCategoryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusCommentDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasDiagnosticDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSolutionDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un ticket .
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TicketDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasFilesGroupIdentifierDto, HasStatusAsStringDto,
    HasStatusCommentDto, HasCategoryIdentifierDto, HasCategoryAsStringDto, HasPriorityIdentifierDto,
    HasPriorityAsStringDto, HasDiagnosticDto, HasSolutionDto, HasUserIdentifierDto,
    HasUserAsStringDto {


  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  @JsonbProperty(JSON_STATUS)
  private TicketStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_STATUS_COMMENT)
  private String statusComment;

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
  private String priorityIdentifier;

  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;

  @JsonbProperty(JSON_DIAGNOSTIC)
  private String diagnostic;

  @JsonbProperty(JSON_SOLUTION)
  private String solution;

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTicket";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "ticketChaine";

  /**
   * Identifiant json {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ticket";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

}
