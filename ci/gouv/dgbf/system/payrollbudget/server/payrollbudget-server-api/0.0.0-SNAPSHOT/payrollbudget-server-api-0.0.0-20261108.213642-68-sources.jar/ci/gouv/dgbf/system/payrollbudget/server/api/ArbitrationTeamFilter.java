package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des équipes d'arbitrage.
 *
 * <p>Le critère du chef est celui qui sert le plus : « quelle est mon équipe ? » est la
 * première question que l'écran pose au nom de celui qui l'ouvre.</p>
 *
 * <p>Il n'y a <strong>pas</strong> de critère « agent ». Demander les équipes auxquelles un
 * agent appartient exigerait une sous-requête sur la table des membres, que le constructeur de
 * prédicats ne sait pas exprimer. L'écran procède donc en deux lectures : les membres dont
 * l'utilisateur est l'agent, puis les équipes ainsi désignées. Deux requêtes simples valent
 * mieux qu'une jointure qu'on force.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ArbitrationTeamFilter extends AbstractIdentifiableFilter {

  /**
   * Exercice budgétaire de l'équipe.
   */
  String exercise;

  /**
   * Identifiant de connexion du chef d'équipe.
   */
  String leader;

  public ArbitrationTeamFilter() {
    super();
  }

  public ArbitrationTeamFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setExercise(ArbitrationMovementFilter.read(filter, ArbitrationTeamDto.JSON_EXERCISE));
    setLeader(ArbitrationMovementFilter.read(filter, ArbitrationTeamDto.JSON_LEADER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    ArbitrationMovementFilter.write(filter, ArbitrationTeamDto.JSON_EXERCISE, getExercise());
    ArbitrationMovementFilter.write(filter, ArbitrationTeamDto.JSON_LEADER, getLeader());
  }
}
