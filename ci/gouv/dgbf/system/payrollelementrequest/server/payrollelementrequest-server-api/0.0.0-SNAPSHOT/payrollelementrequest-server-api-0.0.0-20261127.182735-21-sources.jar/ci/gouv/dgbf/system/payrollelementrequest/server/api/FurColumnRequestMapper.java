package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurColumnService.FurColumnCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurColumnService.FurColumnUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FurColumnDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FurColumnDto}.

    @author akm
               """)
public interface FurColumnRequestMapper extends
    RequestMapper<FurColumnDto, FurColumnCreateRequestDto,
        FurColumnUpdateRequestDto> {

}
