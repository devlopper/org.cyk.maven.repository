package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipMovementDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipMovementDto}.

    @author stephane
               """)
public interface PayslipMovementRequestMapper
    extends RequestMapper<PayslipMovementDto, PayslipMovementCreateRequestDto, 
        PayslipMovementUpdateRequestDto> {

}
