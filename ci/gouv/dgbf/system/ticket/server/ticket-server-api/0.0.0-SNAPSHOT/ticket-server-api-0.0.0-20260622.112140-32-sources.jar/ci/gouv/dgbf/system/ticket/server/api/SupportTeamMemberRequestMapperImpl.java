package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupportTeamMemberDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T11:22:03+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupportTeamMemberRequestMapperImpl implements SupportTeamMemberRequestMapper {

    @Override
    public SupportTeamMemberService.SupportTeamMemberCreateRequestDto mapCreate(SupportTeamMemberDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamMemberService.SupportTeamMemberCreateRequestDto supportTeamMemberCreateRequestDto = new SupportTeamMemberService.SupportTeamMemberCreateRequestDto();

        supportTeamMemberCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamMemberCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        supportTeamMemberCreateRequestDto.setSupportTeamIdentifier( arg0.getSupportTeamIdentifier() );
        supportTeamMemberCreateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        supportTeamMemberCreateRequestDto.setIsResponsible( arg0.getIsResponsible() );

        return supportTeamMemberCreateRequestDto;
    }

    @Override
    public SupportTeamMemberService.SupportTeamMemberUpdateRequestDto mapUpdate(SupportTeamMemberDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamMemberService.SupportTeamMemberUpdateRequestDto supportTeamMemberUpdateRequestDto = new SupportTeamMemberService.SupportTeamMemberUpdateRequestDto();

        supportTeamMemberUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamMemberUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        supportTeamMemberUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportTeamMemberUpdateRequestDto.setSupportTeamIdentifier( arg0.getSupportTeamIdentifier() );
        supportTeamMemberUpdateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        supportTeamMemberUpdateRequestDto.setIsResponsible( arg0.getIsResponsible() );

        return supportTeamMemberUpdateRequestDto;
    }
}
