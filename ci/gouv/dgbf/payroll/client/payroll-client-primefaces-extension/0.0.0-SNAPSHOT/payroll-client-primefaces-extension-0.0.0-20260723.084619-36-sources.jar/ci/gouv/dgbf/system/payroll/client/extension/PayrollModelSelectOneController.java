package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollModelClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollModelDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollModelService.PayrollModelGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollModelDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollModelSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollModelDto, PayrollModelGetManyResponseDto, PayrollModelClient> {

  @Getter
  @Inject
  PayrollModelClient client;

  protected PayrollModelSelectOneController() {
    super(PayrollModelDto.class, SelectItemLabelStrategy.NAME);
  }
}
