package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un élément de paie.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_VALUE_SOURCE_IDENTIFIER)
  private String valueSourceIdentifier;

  @JsonbProperty(JSON_VALUE_SOURCE_AS_STRING)
  private String valueSourceAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idElementPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "elementPaieChaine";

  /**
   * Identifiant json de {@link #valueSourceIdentifier}.
   */
  public static final String JSON_VALUE_SOURCE_IDENTIFIER = "idSourceValeur";

  /**
   * Identifiant json de {@link #valueSourceAsString}.
   */
  public static final String JSON_VALUE_SOURCE_AS_STRING = "sourceValeurChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "élément de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "éléments de paie";
}
