package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurGradeService.FurGradeCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurGradeService.FurGradeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FurGradeDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FurGradeDto}.

    @author akm
               """)
public interface FurGradeRequestMapper extends
    RequestMapper<FurGradeDto, FurGradeCreateRequestDto,
        FurGradeUpdateRequestDto> {

}
