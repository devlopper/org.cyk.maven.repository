package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SharingDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SharingDto}.

    @author Christian
               """)
public interface SharingRequestMapper
    extends RequestMapper<SharingDto, SharingCreateRequestDto, SharingUpdateRequestDto> {

}
