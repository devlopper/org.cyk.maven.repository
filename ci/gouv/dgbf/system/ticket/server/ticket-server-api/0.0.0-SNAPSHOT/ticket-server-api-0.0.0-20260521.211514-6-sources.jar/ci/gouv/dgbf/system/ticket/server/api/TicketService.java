package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Path(value = TicketService.PATH)
@Tag(name = "Gestion des tickets")
public interface TicketService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "tickets";


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   */
  interface TicketSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return la description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description la description
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionalDomainDto}.
     *
     * @return identifiant de {@link FunctionalDomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionalDomainDto}.
     *
     * @param domainIdentifier identifiant de {@link FunctionalDomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);


    /**
     * Identifiant json identifiant de la description.
     */
    String JSON_DESCRIPTION = HasDescriptionDto.JSON_DESCRIPTION;

    /**
     * Identifiant json identifiant de {@link FunctionalDomainDto}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TICKET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TicketCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
        implements TicketSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TICKET";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = TicketGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class TicketGetManyResponseDto
      extends AbstractGetByPageResponseDto<TicketDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TicketDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TICKET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TICKET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TICKET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TicketUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketUpdateRequestDto extends ByIdentifierRequestDto implements
        TicketSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

  }

  /**
   * Identifiant du service de prise en charge .
   */
  String TAKE_IN_CHARGE_IDENTIFIER = "PRISE_EN_CHARGE_TICKET";

  /**
   * Chemin du service prise en charge .
   */
  String TAKE_IN_CHARGE_PATH = "prise-en-charge";

  /**
   * Cette méthode permet de prendre en charge .
   *
   * @param request requête
   * @return réponse
   */
  @Path(TAKE_IN_CHARGE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TAKE_IN_CHARGE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response takeInCharge(TicketTakeInChargeRequestDto request);

  /**
   * Cette classe représente la requête de prise en charge.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketTakeInChargeRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de prise en charge.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketTakeInChargeResponseDto extends ProcessResponseDto {

  }


  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto {

    /**
     * {@link TicketDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private TicketStatus status;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link TicketStatus}
     */
    public void initialize(TicketStatus status) {
      this.status = status;

    }

    /**
     * {@link TicketDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = TicketDto.JSON_STATUS;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TICKET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de la resolution.
   */
  String RESOLVE_IDENTIFIER = "RESOLUTION_TICKET";

  /**
   * Chemin du service de résolution.
   */
  String RESOLVE_PATH = "resolution";

  /**
   * Cette méthode permet de résoudre .
   *
   * @param request requête
   * @return réponse
   */

  @Path(RESOLVE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = RESOLVE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response resolve(TicketResolveRequestDto request);

  /**
   * Cette classe représente la requête de la resolution.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketResolveRequestDto extends ByIdentifierRequestDto {

    
  }

  /**
   * Cette classe représente la réponse de la résolution.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class TicketResolveResponseDto extends ProcessResponseDto {

  }


}
