package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette classe représente le code de {@link BudgetActivityType}.
 *
 * @author Donsylla
 *
 */
public class BudgetActivityTypeCode {

  private BudgetActivityTypeCode() {

  }

  /**
   * Dépense.
   */
  public static final String EXPENDITURE = "DEPENSE";

  /**
   * Recette.
   */
  public static final String REVENUE = "RECETTE";
}
