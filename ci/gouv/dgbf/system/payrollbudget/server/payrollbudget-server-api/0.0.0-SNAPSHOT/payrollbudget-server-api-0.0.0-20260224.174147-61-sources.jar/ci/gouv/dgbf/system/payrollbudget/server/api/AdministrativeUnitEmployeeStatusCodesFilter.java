package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;

/**
 * Interface représentant un filtre basé sur la notion de codes de
 * {@link AdministrativeUnitEmployeeStatus}.
 *
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface AdministrativeUnitEmployeeStatusCodesFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir les codes de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   * @return codes de {@link AdministrativeUnitEmployeeStatus}
   */
  public static Set<String> get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner les codes de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   * @param codes codes de {@link AdministrativeUnitEmployeeStatus}
   */
  public static void set(FilterDto filter, Set<String> codes) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsStringsSetIfNotNull(codes));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = "codesStatutEmployeUniteAdministrative";


}

