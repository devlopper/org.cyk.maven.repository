package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitIdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitIdentityFilter extends AbstractIdentificationFilter {

  /**
   * Identifiant {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Identifiant {@link IdentityDto}.
   */
  @JsonbProperty(value = JSON_IDENTITY_IDENTIFIER)
  String identityIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    identityIdentifier = getIdentityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setIdentityIdentifier(filter, identityIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @param administrativeUnitIdentifier {@link #administrativeUnitIdentifier}
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter,
      String administrativeUnitIdentifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(administrativeUnitIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @return {@link #administrativeUnitIdentifier}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner {@link #identityIdentifier}.
   *
   * @param filter filtre
   * @param identityIdentifier {@link #identityIdentifier}
   */
  public static void setIdentityIdentifier(FilterDto filter, String identityIdentifier) {
    set(filter, JSON_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identityIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #identityIdentifier}.
   *
   * @param filter filtre
   * @return {@link #identityIdentifier}
   */
  public static String getIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant JSON {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = IdentityDto.JSON_THIS_IDENTIFIER;
}

