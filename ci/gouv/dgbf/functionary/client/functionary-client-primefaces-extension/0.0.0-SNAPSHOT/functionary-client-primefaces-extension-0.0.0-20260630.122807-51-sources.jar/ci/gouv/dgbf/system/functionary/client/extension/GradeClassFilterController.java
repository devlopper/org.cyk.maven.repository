package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link GradeClassDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class GradeClassFilterController extends AbstractFilterController<GradeClassFilter> {



  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public GradeClassFilterController() {
    super(GradeClassFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setCivilServiceStatusIdentifier(
        getRequestParameter(GradeClassFilter.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));

    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setCivilServiceStatusIdentifier(identifier));
  }
}
