package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserGroupDto} d'un {@link UsersGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class UsersGroupReadUsersPage extends AbstractUsersGroupReadDatasPage {

  @Inject
  @Getter
  protected UserGroupController userGroupController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    userGroupController.getFilterController().getFilter()
        .setGroupIdentifier(usersGroup.getIdentifier());
    userGroupController.initialize();
  }

  /**
   * Cas de navigation.
   */
  public static final String OUTCOME = "usersGroupReadUsersPage";
}
