package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.DataTable.RecordComponentController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputDateController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.UpdateController;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link IdentifiableProcessingControllerMocker}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class IdentifiableProcessingControllerMocker {

  Object entity;
  
  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link InputDateController}
   */
  public IdentifiableProcessingController mock() {
    IdentifiableProcessingController controller =
        Mockito.mock(IdentifiableProcessingController.class);
    UpdateController updateController = Mockito.mock(UpdateController.class);
    Mockito.when(updateController.getIsEnabledFunction()).thenReturn(o -> true);
    Mockito.when(updateController.getEntity()).thenReturn(entity);
    
    Mockito.when(controller.getController()).thenReturn(updateController);
    
    Button submitButton = new Button();
    Mockito.when(controller.submitButton()).thenReturn(submitButton);
    Mockito.when(controller.getSubmitButton()).thenReturn(submitButton);
    RecordComponentController submitButtonController = new RecordComponentController();
    Mockito.when(controller.getSubmitButtonController()).thenReturn(submitButtonController);
    Mockito.when(controller.submitButtonController()).thenReturn(submitButtonController);
    
    Button showDialogButton = new Button();
    Mockito.when(controller.showDialogButton()).thenReturn(showDialogButton);
    Mockito.when(controller.getShowDialogButton()).thenReturn(showDialogButton);
    RecordComponentController showDialogButtonController = new RecordComponentController();
    Mockito.when(controller.getShowDialogButtonController()).thenReturn(showDialogButtonController);
    Mockito.when(controller.showDialogButtonController()).thenReturn(showDialogButtonController);
    return controller;
  }

}
