package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représentante un filtre basé sur la notion de budget est par défaut.
 *
 * @author Christian
 */
public interface BudgetIsDefaultFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir budget est par défaut.
   *
   * @param filter {@link FilterDto}
   * @return budget est par défaut
   */
  public static Boolean get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsBooleanByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner budget est par défaut.
   *
   * @param filter {@link FilterDto}
   * @param isBudgetDefault budget est par défaut
   */
  public static void set(FilterDto filter, Boolean isBudgetDefault) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isBudgetDefault));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = HasBudgetIsDefaultDto.JSON_BUDGET_IS_DEFAULT;


}

