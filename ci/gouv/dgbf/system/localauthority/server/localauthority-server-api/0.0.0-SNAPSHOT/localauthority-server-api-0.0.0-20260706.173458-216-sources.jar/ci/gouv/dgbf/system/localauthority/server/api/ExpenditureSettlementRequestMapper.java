package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ExpenditureSettlementService.ExpenditureSettlementCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpenditureSettlementService.ExpenditureSettlementUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ExpenditureSettlementDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ExpenditureSettlementDto}.
    
    @author Desysoft
    """)
public interface ExpenditureSettlementRequestMapper extends RequestMapper<ExpenditureSettlementDto,
    ExpenditureSettlementCreateRequestDto, ExpenditureSettlementUpdateRequestDto> {

}

