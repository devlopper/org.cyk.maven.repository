package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseIdentifierDto extends HasExerciseIdentifier {

  /**
   * Identifiant json de l'identifiant de l'exercice.
   */
  String JSON_EXERCISE_IDENTIFIER = "idExercice";
}