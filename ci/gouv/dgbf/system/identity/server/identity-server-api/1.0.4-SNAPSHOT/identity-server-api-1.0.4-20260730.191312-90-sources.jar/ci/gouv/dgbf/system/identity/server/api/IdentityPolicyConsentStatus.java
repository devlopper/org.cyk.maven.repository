package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link IdentityPolicyConsentDto}.
 *
 * @author Desysoft
 *
 */
@Getter
public enum IdentityPolicyConsentStatus {

  /**
   * #{@link IdentityPolicyConsentStatusCode#CREATED}.
   */
  CREATED(IdentityPolicyConsentStatusCode.CREATED, "Créé", "Création"),

  /**
   * #{@link IdentityPolicyConsentStatusCode#ACCEPTED}.
   */
  ACCEPTED(IdentityPolicyConsentStatusCode.ACCEPTED, "Accepté", "Acceptation"),

  /**
   * #{@link IdentityPolicyConsentStatusCode#REFUSED}.
   */
  REFUSED(IdentityPolicyConsentStatusCode.REFUSED, "Refusé", "Refus"),

  /**
   * #{@link IdentityPolicyConsentStatusCode#REVOKED}.
   */
  REVOKED(IdentityPolicyConsentStatusCode.REVOKED, "Révoqué", "Révocation");


  private IdentityPolicyConsentStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<IdentityPolicyConsentStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link IdentityPolicyConsentStatus} par code.
   *
   * @param code code
   * @return {@link IdentityPolicyConsentStatus}
   */
  public static IdentityPolicyConsentStatus getByCode(String code) {
    return Stream.of(IdentityPolicyConsentStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }

  static {
    CREATED.previous = Collections.emptySet();
    ACCEPTED.previous = Core.getSet(List.of(CREATED));
    REFUSED.previous = Core.getSet(List.of(CREATED));
    REVOKED.previous = Core.getSet(List.of(CREATED, ACCEPTED));
  }
}
