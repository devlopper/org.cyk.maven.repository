package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de l'activité.
 *
 * @author Arnaud
 */
public interface HasActivityAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'activité.
   *
   * @return représentation en chaine de caractères de l'activité
   */
  String getActivityAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'activité.
   *
   * @param asString représentation en chaine de caractères de l'activité
   */
  void setActivityAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'activité.
   */
  String FIELD_ACTIVITY_AS_STRING = "activityAsString";
}
