package ci.gouv.dgbf.system.servicecatalog.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcessDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-01T17:01:40+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcessRequestMapperImpl implements ProcessRequestMapper {

    @Override
    public ProcessService.ProcessCreateRequestDto mapCreate(ProcessDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessService.ProcessCreateRequestDto processCreateRequestDto = new ProcessService.ProcessCreateRequestDto();

        processCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        processCreateRequestDto.setCode( arg0.getCode() );
        processCreateRequestDto.setName( arg0.getName() );
        processCreateRequestDto.setDescription( arg0.getDescription() );
        processCreateRequestDto.setNature( arg0.getNature() );
        processCreateRequestDto.setBaseUrl( arg0.getBaseUrl() );
        processCreateRequestDto.setVisible( arg0.getVisible() );
        processCreateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );

        return processCreateRequestDto;
    }

    @Override
    public ProcessService.ProcessUpdateRequestDto mapUpdate(ProcessDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessService.ProcessUpdateRequestDto processUpdateRequestDto = new ProcessService.ProcessUpdateRequestDto();

        processUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        processUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        processUpdateRequestDto.setCode( arg0.getCode() );
        processUpdateRequestDto.setName( arg0.getName() );
        processUpdateRequestDto.setDescription( arg0.getDescription() );
        processUpdateRequestDto.setNature( arg0.getNature() );
        processUpdateRequestDto.setBaseUrl( arg0.getBaseUrl() );
        processUpdateRequestDto.setVisible( arg0.getVisible() );
        processUpdateRequestDto.setModuleIdentifier( arg0.getModuleIdentifier() );

        return processUpdateRequestDto;
    }
}
