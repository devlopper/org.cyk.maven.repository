package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant arbitré à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountNAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant arbitré à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @return le montant arbitré à l'horizon N, sous forme de chaîne de caractères
   */
  String getArbitratedAmountNAsString();

  /**
   * Cette méthode permet d'assigner le montant arbitré à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @param amount le montant arbitré à l'horizon N, sous forme de chaîne de caractères
   */
  void setArbitratedAmountNAsString(String amount);

  /**
   * Identifiant java du montant arbitré à l'horizon N, sous forme de chaîne de caractères.
   */
  String FIELD_ARBITRATED_AMOUNT_N_AS_STRING = "arbitratedAmountNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
