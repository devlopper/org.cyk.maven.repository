package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Le poste de paie qu'un type de mouvement impacte.
 *
 * <p>C'est le maillon qui manquait. Le référentiel de la paie sait déjà quelle nature économique
 * porte chaque poste ; il ne sait pas quels postes un <em>glissement catégoriel</em> fait bouger,
 * ni lesquels une <em>prime de recherche</em> touche. Cette information n'existait nulle part —
 * elle vivait dans le tableau des entrées et sorties, refaite à la main chaque exercice.</p>
 *
 * <p>Le paramétrage se fait au poste, et non à la nature économique, bien que le tableau des
 * entrées et sorties se lise par nature : le poste est le grain fin, la nature s'en déduit. Faire
 * l'inverse — paramétrer la nature et deviner les postes — reviendrait à décider pour mille
 * quatre cent quarante-deux postes à la fois.</p>
 *
 * <p>Rien de plus que les deux extrémités du lien : une association qui porterait des attributs
 * propres cesserait d'être une association et deviendrait un objet, qu'il faudrait alors savoir
 * modifier, dater, justifier.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementTypePayrollComponentDto extends AbstractIdentifiableDto {

  /**
   * Type de mouvement paramétré.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
  private String movementTypeIdentifier;

  /**
   * Libellé du type de mouvement.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_AS_STRING)
  private String movementTypeAsString;

  /**
   * Poste de paie impacté.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPostePaieTypeMouvement";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "postePaieTypeMouvementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de paie d'un type de mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de paie des types de mouvement";

  /**
   * Identifiant json pour {@link #movementTypeIdentifier}.
   */
  public static final String JSON_MOVEMENT_TYPE_IDENTIFIER = MovementTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #movementTypeAsString}.
   */
  public static final String JSON_MOVEMENT_TYPE_AS_STRING = MovementTypeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #payrollComponentIdentifier}.
   */
  public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
      PayrollComponentDto.JSON_THIS_IDENTIFIER;
}
