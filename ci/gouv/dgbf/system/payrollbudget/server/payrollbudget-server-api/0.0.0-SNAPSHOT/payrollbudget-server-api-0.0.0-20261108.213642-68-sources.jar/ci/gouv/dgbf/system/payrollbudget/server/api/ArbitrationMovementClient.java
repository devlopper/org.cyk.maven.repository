package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationMovementService.ArbitrationMovementCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationMovementService.ArbitrationMovementGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationMovementService.ArbitrationMovementProcessingRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationMovementService.ArbitrationMovementTransitionRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des lignes d'arbitrage.
 *
 * <p>Le client est seul responsable de la désérialisation : il masque au consommateur la
 * manipulation des objets {@code Response}.</p>
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ArbitrationMovementClient extends AbstractClient<ArbitrationMovementService>
    implements GetByIdentifier<ArbitrationMovementDto>,
    GetMany<ArbitrationMovementGetManyResponseDto> {

  @Override
  public ArbitrationMovementClient service(ArbitrationMovementService service) {
    return (ArbitrationMovementClient) super.service(service);
  }

  /**
   * Ajoute au dossier un élément parvenu après la transmission.
   *
   * @param request l'élément à ajouter
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(ArbitrationMovementCreateRequestDto request) {
    return new CreateExecutor(ArbitrationMovementService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des lignes d'arbitrage.
   *
   * @param request critères, projection et pagination
   * @return les lignes correspondantes
   */
  public ArbitrationMovementGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ArbitrationMovementGetManyResponseDto>(
        ArbitrationMovementGetManyResponseDto.class,
        ArbitrationMovementService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  @Override
  public ArbitrationMovementGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'une ligne d'arbitrage unique.
   *
   * @param request critères et projection
   * @return la ligne correspondante
   */
  public ArbitrationMovementDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ArbitrationMovementDto>(ArbitrationMovementDto.class,
        ArbitrationMovementService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * Recherche d'une ligne d'arbitrage unique.
   *
   * @param projection champs à retourner
   * @param filter critères de recherche
   * @param auditWho acteur de l'appel
   * @param auditSession session de l'appel
   * @return la ligne correspondante
   */
  public ArbitrationMovementDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'une ligne d'arbitrage par son identifiant.
   *
   * @param request identifiant et projection
   * @return la ligne correspondante
   */
  public ArbitrationMovementDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ArbitrationMovementDto>(ArbitrationMovementDto.class,
        ArbitrationMovementService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public ArbitrationMovementDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Vise une ligne d'arbitrage.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto endorse(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.ENDORSE_IDENTIFIER)
        .execute(() -> service().endorse(request));
  }

  /**
   * Marque une ligne d'arbitrage comme non visée.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto notEndorse(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.NOT_ENDORSE_IDENTIFIER)
        .execute(() -> service().notEndorse(request));
  }

  /**
   * Transmettre une ligne d'arbitrage.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto transmit(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.TRANSMIT_IDENTIFIER)
        .execute(() -> service().transmit(request));
  }

  /**
   * Réceptionner une ligne d'arbitrage.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto receive(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.RECEIVE_IDENTIFIER)
        .execute(() -> service().receive(request));
  }

  /**
   * Différer une ligne d'arbitrage.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto defer(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.DEFER_IDENTIFIER)
        .execute(() -> service().defer(request));
  }

  /**
   * Constater la levée du blocage d'une ligne différée.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto satisfyDeferral(
      ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.SATISFY_DEFER_IDENTIFIER)
        .execute(() -> service().satisfyDeferral(request));
  }

  /**
   * Renvoie une ligne au traitement : le chef d'équipe n'a pas retenu le travail rendu.
   *
   * @param request identifiant de la ligne et motif du renvoi
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto returnToProcessing(
      ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.RETURN_TO_PROCESSING_IDENTIFIER)
        .execute(() -> service().returnToProcessing(request));
  }

  /**
   * Valide une ligne d'arbitrage : ce que le traitement a retenu est tenu pour bon.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto validate(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.VALIDATE_IDENTIFIER)
        .execute(() -> service().validate(request));
  }

  /**
   * Consolide une ligne d'arbitrage.
   *
   * @param request identifiant de la ligne
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto consolidate(ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.CONSOLIDATE_IDENTIFIER)
        .execute(() -> service().consolidate(request));
  }

  /**
   * Met une ligne d'arbitrage à l'écart de la masse salariale finale.
   *
   * @param request identifiant de la ligne et motif
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto notConsolidate(
      ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.NOT_CONSOLIDATE_IDENTIFIER)
        .execute(() -> service().notConsolidate(request));
  }

  /**
   * Accepte le traitement d'une ligne, avec ou sans ajustement.
   *
   * @param request identifiant, ajustement éventuel et motif
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto acceptProcessing(
      ArbitrationMovementProcessingRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.ACCEPT_PROCESSING_IDENTIFIER)
        .execute(() -> service().acceptProcessing(request));
  }

  /**
   * Rejette le traitement d'une ligne.
   *
   * @param request identifiant de la ligne et motif
   * @return l'identifiant de la ligne touchée
   */
  public IdentifiableResponseDto rejectProcessing(
      ArbitrationMovementTransitionRequestDto request) {
    return new IdentifiableExecutor(ArbitrationMovementService.REJECT_PROCESSING_IDENTIFIER)
        .execute(() -> service().rejectProcessing(request));
  }

}
