package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link LogLevel}.
 *
 * @author Christian
 *
 */
@Dependent
public class LogLevelSelectOneController
    extends AbstractSelectOneEnumerationController<LogLevel> {

  protected LogLevelSelectOneController() {
    super(LogLevel.values());
    outputLableValue = "Niveau de log";
  }

  @Override
  protected String computeSelectItemLabel(LogLevel type) {
    return type.getName();
  }
}
