package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RevenueDto}.
 *
 * @author Christian
 */
@Path(value = RevenueService.PATH)
@Tag(name = "Gestion des Revenus")
public interface RevenueService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "revenus";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface RevenueSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'exercice.
     *
     * @return identifiant de l'exercice
     */
    String getExerciseIdentifier();

    /**
     * Définit l'identifiant de l'exercice.
     *
     * @param exerciseIdentifier l'identifiant de l'exercice
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir ldentifiant de l'activité.
     *
     * @return identifiant de l'exercice
     */
    String getActivityIdentifier();

    /**
     * Définit l'identifiant de l'activité.
     *
     * @param activityIdentifier l'identifiant de l'activité
     */
    void setActivityIdentifier(String activityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la nature économique.
     *
     * @return identifiant de la nature économique
     */
    String getEconomicNatureIdentifier();

    /**
     * Définit l'identifiant de la nature économique.
     *
     * @param economicNatureIdentifier l'identifiant de la nature économique
     */
    void setEconomicNatureIdentifier(String economicNatureIdentifier);
    
    /**
     * Identifiant de l'exercice.
     */
    String JSON_EXERCISE_IDENTIFIER = RevenueDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * Identifiant de l'activité.
     */
    String JSON_ACTIVITY_IDENTIFIER = RevenueDto.JSON_ACTIVITY_IDENTIFIER;

    /**
     * Identifiant de la nature économique.
     */
    String JSON_ECONOMIC_NATURE_IDENTIFIER = RevenueDto.JSON_ECONOMIC_NATURE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link RevenueDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_REVENU";

  /**
   * Chemin du service de création unitaire de {@link RevenueDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RevenueCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link RevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class RevenueCreateRequestDto extends AbstractAuditedRequestJsonDto 
      implements RevenueSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link RevenueDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REVENU";

  /**
   * Chemin du service d'obtention de plusieurs {@link RevenueDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RevenueGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link RevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class RevenueGetManyResponseDto
      extends AbstractGetByPageResponseDto<RevenueDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RevenueDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link RevenueDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_REVENU";

  /**
   * Chemin du service d'obtention unitaire de {@link RevenueDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RevenueDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link RevenueDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REVENU";

  /**
   * Chemin du service d'obtention par identifiant de {@link RevenueDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RevenueDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link RevenueDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_REVENU";

  /**
   * Chemin du service de mise à jour unitaire de {@link RevenueDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RevenueUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link RevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class RevenueUpdateRequestDto extends ByIdentifierRequestDto 
      implements RevenueSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link RevenueDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_REVENU";

  /**
   * Chemin du service de suppression unitaire de {@link RevenueDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link RevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
