package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ScriptFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ScriptFilter(FilterDto dto) {
    super(dto);
  }

}
