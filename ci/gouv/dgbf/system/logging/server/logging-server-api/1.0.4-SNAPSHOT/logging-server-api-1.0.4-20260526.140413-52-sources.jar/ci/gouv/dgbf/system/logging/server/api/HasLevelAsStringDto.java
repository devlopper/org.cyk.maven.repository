package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;

/**
 * Cette interface représente une classe avec une notion de {@link LogLevel} en chaine de
 * caractères.
 *
 * @author Christian
 */
public interface HasLevelAsStringDto extends HasLevelAsString {

  /**
   * Identifiant json de {@link LogLevel} en chaine de caractères.
   */
  String JSON_LEVEL_AS_STRING = "niveauChaine";
}
