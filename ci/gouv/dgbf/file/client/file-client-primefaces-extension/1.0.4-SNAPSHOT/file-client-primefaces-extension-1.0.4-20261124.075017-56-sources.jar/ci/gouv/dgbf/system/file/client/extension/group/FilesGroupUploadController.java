package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.ByteCore;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.file.client.extension.file.OpenFileViewerButtonController;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupFilter;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de téléchargement multiple de {@link FilesGroupDto}.
 * Par défaut, seul le dépôt numérique rapide est affiché ; le développeur peut autoriser le
 * papier et/ou l'hybride via {@link #setAllowedMediumNatures(Set)} ou
 * {@link #allowAllMediumNatures()}.
 *
 * @author Christian
 */
@Dependent
public class FilesGroupUploadController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  FileGroupClient fileGroupClient;

  @Inject
  FileClient fileClient;

  @Inject
  @Getter
  OpenFileViewerButtonController openFileViewerButtonController;

  /**
   * Si actif, n'affiche que les fichiers déjà rattachés, sans possibilité d'ajout ni de
   * suppression (widget d'upload et boutons de retrait masqués).
   */
  @Getter
  @Setter
  boolean readOnly;

  /**
   * Natures de support autorisées à l'ajout : numérique seul par défaut.
   */
  @Getter
  private Set<MediumNature> allowedMediumNatures = EnumSet.of(MediumNature.DIGITAL);

  @Getter
  Map<String, FileDto> files;

  /**
   * Requêtes de création complètes associées aux fichiers papier ou hybrides en attente (même clé
   * que {@link #files}).
   */
  Map<String, FileCreateRequestDto> pendingRequests;

  /**
   * Fichiers déjà rattachés au groupe en cours de modification (clé = identifiant du rattachement
   * Fichier de Groupe), chargés à l'ouverture du dialogue de modification.
   */
  @Getter
  Map<String, FileGroupDto> existingFileGroups;

  /**
   * Identifiants des rattachements Fichier de Groupe existants dont la suppression a été demandée,
   * en attente de confirmation par {@link #update(String, String)}.
   */
  Set<String> removedFileGroupIdentifiers;

  @Getter
  private boolean physicalFormVisible;

  @Getter
  @Setter
  private String pendingMediumNatureCode = MediumNature.PHYSICAL.getCode();

  @Getter
  @Setter
  private String pendingName;

  @Getter
  @Setter
  private String pendingHolder;

  @Getter
  @Setter
  private String pendingContainer;

  @Getter
  @Setter
  private String pendingPhysicalExtent;

  @Getter
  @Setter
  private String pendingPhysicalCondition;

  @Getter
  @Setter
  private String pendingOriginalMediumCode;

  @Getter
  private String pendingUploadedFileName;

  @Getter
  private byte[] pendingBytes;

  @Getter
  private String pendingErrorMessage;

  /**
   * Cette méthode permet de construire.
   */
  public FilesGroupUploadController() {
    files = new LinkedHashMap<>();
    pendingRequests = new LinkedHashMap<>();
    existingFileGroups = new LinkedHashMap<>();
    removedFileGroupIdentifiers = new LinkedHashSet<>();
  }

  /**
   * Définit les natures de support autorisées à l'ajout.
   *
   * @param natures ensemble non vide des natures autorisées
   */
  public void setAllowedMediumNatures(Set<MediumNature> natures) {
    if (natures == null || natures.isEmpty()) {
      throw new IllegalArgumentException(
          "Au moins une nature de support doit être autorisée.");
    }
    allowedMediumNatures = EnumSet.copyOf(natures);
    pendingMediumNatureCode = defaultPhysicalOrHybridCode();
  }

  /**
   * Autorise toutes les natures de support (numérique, papier et hybride).
   */
  public void allowAllMediumNatures() {
    setAllowedMediumNatures(EnumSet.allOf(MediumNature.class));
  }

  /**
   * Indique si le dépôt rapide de fichiers numériques est autorisé.
   *
   * @return {@code true} si {@link MediumNature#DIGITAL} est autorisé
   */
  public boolean isDigitalAllowed() {
    return allowedMediumNatures.contains(MediumNature.DIGITAL);
  }

  /**
   * Indique si l'ajout de documents papier ou hybrides est autorisé.
   *
   * @return {@code true} si {@link MediumNature#PHYSICAL} ou {@link MediumNature#HYBRID} est
   *         autorisé
   */
  public boolean isPhysicalOrHybridAllowed() {
    return allowedMediumNatures.contains(MediumNature.PHYSICAL)
        || allowedMediumNatures.contains(MediumNature.HYBRID);
  }

  /**
   * Indique si la colonne Nature est affichée dans le tableau des fichiers en attente.
   *
   * @return {@code true} quand au moins deux natures sont autorisées
   */
  public boolean isMediumNatureColumnRendered() {
    return allowedMediumNatures.size() > 1;
  }

  /**
   * Indique si le sélecteur de nature dans le panneau papier/hybride doit être affiché.
   *
   * @return {@code true} quand papier et hybride sont tous deux autorisés
   */
  public boolean isPendingNatureChoiceRendered() {
    return allowedMediumNatures.contains(MediumNature.PHYSICAL)
        && allowedMediumNatures.contains(MediumNature.HYBRID);
  }

  /**
   * Indique si la saisie en cours dans le panneau papier/hybride concerne un fichier hybride.
   *
   * @return {@code true} pour un fichier hybride
   */
  public boolean isPendingHybrid() {
    return MediumNature.HYBRID.getCode().equals(pendingMediumNatureCode);
  }

  /**
   * Options papier / hybride proposées dans le panneau d'ajout.
   *
   * @return liste des options
   */
  public List<SelectItem> getPhysicalOrHybridSelectItems() {
    List<SelectItem> items = new ArrayList<>();
    if (allowedMediumNatures.contains(MediumNature.PHYSICAL)) {
      items.add(new SelectItem(MediumNature.PHYSICAL.getCode(),
          "Papier : exemplaire physique seulement"));
    }
    if (allowedMediumNatures.contains(MediumNature.HYBRID)) {
      items.add(new SelectItem(MediumNature.HYBRID.getCode(),
          "Les deux : contenu numérique et exemplaire papier"));
    }
    return items;
  }

  /**
   * Libellé du bouton d'ouverture du panneau papier/hybride, adapté aux natures autorisées.
   *
   * @return libellé du bouton
   */
  public String getAddPhysicalOrHybridButtonLabel() {
    if (isPendingNatureChoiceRendered()) {
      return "Ajouter un document papier ou hybride";
    }
    if (allowedMediumNatures.contains(MediumNature.HYBRID)) {
      return "Ajouter un document hybride";
    }
    return "Ajouter un document papier";
  }

  /**
   * Ouvre le panneau de saisie d'un document papier ou hybride.
   */
  public void openPhysicalForm() {
    resetPendingFields();
    physicalFormVisible = true;
  }

  /**
   * Ferme et réinitialise le panneau de saisie d'un document papier ou hybride.
   */
  public void cancelPhysicalForm() {
    resetPendingFields();
    physicalFormVisible = false;
  }

  /**
   * Réagit au téléversement du contenu numérique d'un document hybride dans le panneau d'ajout.
   *
   * @param event évènement de téléversement
   */
  public void handlePendingFileUpload(FileUploadEvent event) {
    pendingUploadedFileName = event.getFile().getFileName();
    pendingBytes = event.getFile().getContent();
    if (Core.isStringBlank(pendingName)) {
      pendingName = pendingUploadedFileName;
    }
  }

  /**
   * Valide et ajoute le document papier ou hybride en cours de saisie à la liste d'attente.
   */
  public void addPendingPhysicalOrHybrid() {
    boolean hybrid = isPendingHybrid();
    if (hybrid && pendingBytes == null) {
      pendingErrorMessage = "Déposez le contenu numérique.";
      return;
    }
    if (hybrid && Core.isStringBlank(pendingOriginalMediumCode)) {
      pendingErrorMessage = "Indiquez quel exemplaire est l'original.";
      return;
    }
    String resolvedName =
        Core.isStringBlank(pendingName) && hybrid ? pendingUploadedFileName : pendingName;
    if (Core.isStringBlank(resolvedName)) {
      pendingErrorMessage = "Le nom est obligatoire pour un fichier papier.";
      return;
    }
    if (Core.isStringBlank(pendingHolder)) {
      pendingErrorMessage = "Le détenteur du papier est obligatoire.";
      return;
    }

    FileDto file = new FileDto();
    file.setName(resolvedName);
    file.setMediumNature(hybrid ? MediumNature.HYBRID : MediumNature.PHYSICAL);
    if (hybrid) {
      file.setBytes(pendingBytes);
    }

    FileCreateRequestDto request = new FileCreateRequestDto();
    request.setName(resolvedName);
    request.setBytes(hybrid ? pendingBytes : null);
    request.setHolder(pendingHolder);
    request.setContainer(pendingContainer);
    request.setPhysicalExtent(pendingPhysicalExtent);
    request.setPhysicalCondition(pendingPhysicalCondition);
    request.setOriginalMedium(hybrid ? pendingOriginalMediumCode : null);

    String key = UUID.randomUUID().toString();
    files.put(key, file);
    pendingRequests.put(key, request);
    cancelPhysicalForm();
  }

  /**
   * Cette méthode permet d'ajouter un fichier numérique par dépôt rapide.
   *
   * @param event {@link FileUploadEvent}
   */
  public void add(FileUploadEvent event) {
    FileDto file = new FileDto();
    file.setName(event.getFile().getFileName());
    file.setBytes(event.getFile().getContent());
    file.setMediumNature(MediumNature.DIGITAL);
    file.setHash(ByteCore.digestToString(file.getBytes(), "SHA-256"));
    files.put(file.getHash(), file);
  }

  /**
   * Cette méthode permet de supprimer un fichier en attente.
   *
   * @param key clé
   */
  public void remove(String key) {
    files.remove(key);
    pendingRequests.remove(key);
  }

  /**
   * Cette méthode permet de créer {@link FilesGroupDto}.
   *
   * @return identifiant du groupe créé
   */
  public String createTemporary() {
    FilesGroupCreateRequestDto request = new FilesGroupCreateRequestDto();
    request.setIsConfirmed(false);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(UUID.randomUUID().toString());
    CreateResponseDto response = client.create(request);
    String identifier = response.getIdentifier();
    createFiles(identifier, request.getAuditSession());
    return identifier;
  }

  /**
   * Cette méthode permet de créer les fichiers du groupe.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}.
   * @param auditSession session
   */
  public void createFiles(String groupIdentifier, String auditSession) {
    files.forEach((key, file) -> createFileGroup(key, file, groupIdentifier, auditSession));
    files.clear();
    pendingRequests.clear();
  }

  /**
   * Cette méthode permet de charger les fichiers déjà rattachés à un groupe existant, à
   * l'ouverture du dialogue de modification.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   * @param auditWho audit acteur
   */
  public void loadExisting(String groupIdentifier, String auditWho) {
    files.clear();
    pendingRequests.clear();
    existingFileGroups.clear();
    removedFileGroupIdentifiers.clear();
    cancelPhysicalForm();
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileGroupDto.JSON_FILE_AS_STRING,
        FileGroupDto.JSON_FILE_IDENTIFIER, FileGroupDto.JSON_FILE_OWNER_IDENTIFIER);
    FilterDto filter = new FilterDto();
    FileGroupFilter.setGroupIdentifier(filter, groupIdentifier);
    FileGroupGetManyResponseDto response =
        fileGroupClient.getMany(projection, filter, null, auditWho, null);
    Optional.ofNullable(response).map(r -> r.getDatas())
        .orElse(Collections.emptyList())
        .forEach(fileGroup -> existingFileGroups.put(fileGroup.getIdentifier(), fileGroup));
  }

  /**
   * Cette méthode permet de retirer un fichier déjà rattaché (suppression différée, appliquée par
   * {@link #update(String, String)}).
   *
   * @param fileGroupIdentifier identifiant du rattachement Fichier de Groupe
   */
  public void removeExisting(String fileGroupIdentifier) {
    existingFileGroups.remove(fileGroupIdentifier);
    removedFileGroupIdentifiers.add(fileGroupIdentifier);
  }

  /**
   * Cette méthode permet d'appliquer, pour un groupe existant, les ajouts ({@link #files}) et les
   * suppressions ({@link #removedFileGroupIdentifiers}) demandés depuis l'ouverture du dialogue de
   * modification.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   * @param auditWho audit acteur
   */
  public void update(String groupIdentifier, String auditWho) {
    String auditSession = UUID.randomUUID().toString();
    removedFileGroupIdentifiers.forEach(
        identifier -> fileGroupClient.deleteByIdentifier(identifier, auditWho, auditSession));
    removedFileGroupIdentifiers.clear();
    createFiles(groupIdentifier, auditSession);
  }

  void createFileGroup(String key, FileDto file, String groupIdentifier, String auditSession) {
    FileGroupCreateRequestDto request = new FileGroupCreateRequestDto();
    request.setGroupIdentifier(groupIdentifier);
    String fileIdentifier = createFileOrGetIdentifier(key, file, auditSession);
    request.setFileIdentifier(fileIdentifier);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(auditSession);
    fileGroupClient.create(request);
  }

  String createFileOrGetIdentifier(String key, FileDto file, String auditSession) {
    FileCreateRequestDto pendingRequest = pendingRequests.get(key);
    if (pendingRequest != null) {
      pendingRequest.setAuditWho(userIdentifier);
      pendingRequest.setAuditSession(auditSession);
      return fileClient.create(pendingRequest).getIdentifier();
    }
    return fileClient.getIdentifierByBytesOrByCreate(file.getName(), file.getBytes(),
        userIdentifier, auditSession);
  }

  private void resetPendingFields() {
    pendingMediumNatureCode = defaultPhysicalOrHybridCode();
    pendingName = null;
    pendingHolder = null;
    pendingContainer = null;
    pendingPhysicalExtent = null;
    pendingPhysicalCondition = null;
    pendingOriginalMediumCode = null;
    pendingUploadedFileName = null;
    pendingBytes = null;
    pendingErrorMessage = null;
  }

  private String defaultPhysicalOrHybridCode() {
    if (allowedMediumNatures.contains(MediumNature.PHYSICAL)) {
      return MediumNature.PHYSICAL.getCode();
    }
    return MediumNature.HYBRID.getCode();
  }
}
