package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-01T19:39:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketRequestMapperImpl implements TicketRequestMapper {

    @Override
    public TicketService.TicketCreateRequestDto mapCreate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketCreateRequestDto ticketCreateRequestDto = new TicketService.TicketCreateRequestDto();

        ticketCreateRequestDto.setCode( arg0.getCode() );
        ticketCreateRequestDto.setName( arg0.getName() );
        ticketCreateRequestDto.setDescription( arg0.getDescription() );
        ticketCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        ticketCreateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketCreateRequestDto;
    }

    @Override
    public TicketService.TicketUpdateRequestDto mapUpdate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketUpdateRequestDto ticketUpdateRequestDto = new TicketService.TicketUpdateRequestDto();

        ticketUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketUpdateRequestDto.setDescription( arg0.getDescription() );
        ticketUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        ticketUpdateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketUpdateRequestDto;
    }

    @Override
    public TicketService.TicketClaimRequestDto mapClaimRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketClaimRequestDto ticketClaimRequestDto = new TicketService.TicketClaimRequestDto();

        ticketClaimRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketClaimRequestDto.setUserIdentifier( ticket.getUserIdentifier() );
        ticketClaimRequestDto.setCategoryIdentifier( ticket.getCategoryIdentifier() );
        ticketClaimRequestDto.setPriorityIdentifier( ticket.getPriorityIdentifier() );

        return ticketClaimRequestDto;
    }

    @Override
    public TicketService.TicketResolveRequestDto mapResolveRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketResolveRequestDto ticketResolveRequestDto = new TicketService.TicketResolveRequestDto();

        ticketResolveRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketResolveRequestDto.setDiagnostic( ticket.getDiagnostic() );
        ticketResolveRequestDto.setSolution( ticket.getSolution() );

        return ticketResolveRequestDto;
    }

    @Override
    public TicketService.TicketSatisfyRequestDto mapSatisfyRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketSatisfyRequestDto ticketSatisfyRequestDto = new TicketService.TicketSatisfyRequestDto();

        ticketSatisfyRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketSatisfyRequestDto.setStatusComment( ticket.getStatusComment() );
        ticketSatisfyRequestDto.setFilesGroupIdentifier( ticket.getFilesGroupIdentifier() );

        return ticketSatisfyRequestDto;
    }

    @Override
    public TicketService.TicketDissatisfyRequestDto mapUnsatisfyRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketDissatisfyRequestDto ticketDissatisfyRequestDto = new TicketService.TicketDissatisfyRequestDto();

        ticketDissatisfyRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketDissatisfyRequestDto.setStatusComment( ticket.getStatusComment() );
        ticketDissatisfyRequestDto.setFilesGroupIdentifier( ticket.getFilesGroupIdentifier() );

        return ticketDissatisfyRequestDto;
    }
}
