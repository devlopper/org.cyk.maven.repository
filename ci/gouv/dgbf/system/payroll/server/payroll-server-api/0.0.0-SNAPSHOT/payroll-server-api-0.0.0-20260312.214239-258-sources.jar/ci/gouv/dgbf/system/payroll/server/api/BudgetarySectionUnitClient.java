package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.BudgetarySectionUnitService.BudgetarySectionUnitGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link BudgetarySectionUnitService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class BudgetarySectionUnitClient extends AbstractClient<
    BudgetarySectionUnitService> implements GetByIdentifier<BudgetarySectionUnitDto>, 
    GetMany<BudgetarySectionUnitGetManyResponseDto> {

  @Override
  public BudgetarySectionUnitClient service(BudgetarySectionUnitService service) {
    return (BudgetarySectionUnitClient) super.service(service);
  }

  /**
   * {@link BudgetarySectionUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetarySectionUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<BudgetarySectionUnitGetManyResponseDto>(
        BudgetarySectionUnitGetManyResponseDto.class, 
        BudgetarySectionUnitService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link BudgetarySectionUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetarySectionUnitGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BudgetarySectionUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetarySectionUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetarySectionUnitDto>(BudgetarySectionUnitDto.class,
        BudgetarySectionUnitService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link BudgetarySectionUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetarySectionUnitDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BudgetarySectionUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public BudgetarySectionUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetarySectionUnitDto>(BudgetarySectionUnitDto.class,
        BudgetarySectionUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BudgetarySectionUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetarySectionUnitDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
