package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ServiceDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ServiceFilter extends AbstractIdentifiableFilter {
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ServiceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ServiceFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
  }
}
