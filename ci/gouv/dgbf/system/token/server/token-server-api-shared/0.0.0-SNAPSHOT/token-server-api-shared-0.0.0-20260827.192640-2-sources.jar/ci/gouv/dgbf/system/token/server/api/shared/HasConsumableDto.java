package ci.gouv.dgbf.system.token.server.api.shared;

/**
 * Cette interface représente un classe avec une notion de peut être consommé.
 *
 * @author Christian
 */
public interface HasConsumableDto extends HasConsumable {

  /**
   * Identifiant json de peut être consommé.
   */
  String JSON_CONSUMABLE = "consommable";
}
