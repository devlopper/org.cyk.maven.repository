package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente la capacité à indiquer si l'année N+2 est complétée.
 *
 * @author Christian
 */
public interface HasCompletedN2 extends HasField {

  /**
   * Obtient l'indicateur indiquant si l'année N+2 est complétée.
   *
   * @return {@code true} si l'année N+2 est complétée, sinon {@code false}
   */
  Boolean getCompletedN2();

  /**
   * Définit l'indicateur indiquant si l'année N+2 est complétée.
   *
   * @param completedN2 indicateur indiquant si l'année N+2 est complétée
   */
  void setCompletedN2(Boolean completedN2);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N+2 est complétée.
   */
  String FIELD_COMPLETED_N2 = "completedN2";
}