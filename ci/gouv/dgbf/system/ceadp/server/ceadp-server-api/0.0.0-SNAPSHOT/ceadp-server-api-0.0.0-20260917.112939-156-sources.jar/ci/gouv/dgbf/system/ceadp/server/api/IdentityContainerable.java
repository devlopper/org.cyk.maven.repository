package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
public interface IdentityContainerable {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link IdentityDto}.
   *
   * @return représentation en chaine de caractères du nombre {@link IdentityDto}
   */
  String getIdentityCountAsString();

  /**
   * Identifiant java du nombre de {@link IdentityDto}.
   */
  String FIELD_IDENTITY_COUNT_AS_STRING = "identityCountAsString";
}
