package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente le contrôleur de sélection de la nature d'une Entité Traitante
 * (référentiel {@code TR_NATURE_ENTITE_TRAITANTE}).
 *
 * @author akm
 *
 */
@Dependent
public class ProcessingEntityNatureSelectOneController extends AbstractSelectOneController {

  protected ProcessingEntityNatureSelectOneController() {
    outputLableValue = "Nature";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem("CENTRALE", "Centrale"),
        new SelectItem("REGIONALE", "Regionale"));
  }
}
