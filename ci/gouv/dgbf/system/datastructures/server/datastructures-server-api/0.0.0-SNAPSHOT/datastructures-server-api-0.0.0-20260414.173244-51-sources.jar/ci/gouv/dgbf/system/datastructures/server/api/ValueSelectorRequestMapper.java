package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueSelectorDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueSelectorDto}.

    @author Christian
               """)
public interface ValueSelectorRequestMapper extends RequestMapper<ValueSelectorDto,
    ValueSelectorCreateRequestDto, ValueSelectorUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link ValueSelectorEvaluateRequestDto}.
   *
   * @param valueSelector {@link ValueSelectorDto}
   * @return {@link ValueSelectorEvaluateRequestDto}
   */
  ValueSelectorEvaluateRequestDto mapEvaluate(ValueSelectorDto valueSelector);
  
}
