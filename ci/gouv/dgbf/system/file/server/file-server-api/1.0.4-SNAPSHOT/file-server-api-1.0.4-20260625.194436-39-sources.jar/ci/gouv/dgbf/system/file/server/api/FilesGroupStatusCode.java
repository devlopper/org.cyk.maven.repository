package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FilesGroupStatus}.
 *
 * @author Christian
 *
 */
public class FilesGroupStatusCode {

  private FilesGroupStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Confirmé.
   */
  public static final String CONFIRMED = "CONFIRME";
}
