package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action
 * Différer (RG_REP_PEC_06) sur une réponse de traitement (motif R44/R45).
 *
 * @author akm
 *
 */
public interface HasDeferableDto {

  /**
   * Identifiant json de {@link #getDeferable()}.
   */
  String JSON_DEFERABLE = "differable";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Différer.
   *
   * @return indicateur de disponibilité de l'action Différer
   */
  Boolean getDeferable();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Différer.
   *
   * @param deferable indicateur de disponibilité de l'action Différer
   */
  void setDeferable(Boolean deferable);
}
