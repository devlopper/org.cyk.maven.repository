package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'employé
 * d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeAsStringDto
    extends HasAdministrativeUnitEmployeeAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'employé de l'unité
   * administrative.
   */
  String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING = "employeUniteAdministrativeChaine";
}
