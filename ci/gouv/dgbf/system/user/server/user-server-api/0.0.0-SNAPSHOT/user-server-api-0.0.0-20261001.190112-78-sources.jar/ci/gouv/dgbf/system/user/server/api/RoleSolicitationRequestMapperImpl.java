package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RoleSolicitationDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-01T19:01:38+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RoleSolicitationRequestMapperImpl implements RoleSolicitationRequestMapper {

    @Override
    public RoleSolicitationService.RoleSolicitationCreateRequestDto mapCreate(RoleSolicitationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleSolicitationService.RoleSolicitationCreateRequestDto roleSolicitationCreateRequestDto = new RoleSolicitationService.RoleSolicitationCreateRequestDto();

        roleSolicitationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleSolicitationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        roleSolicitationCreateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        roleSolicitationCreateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );
        roleSolicitationCreateRequestDto.setReason( arg0.getReason() );

        return roleSolicitationCreateRequestDto;
    }

    @Override
    public RoleSolicitationService.RoleSolicitationUpdateRequestDto mapUpdate(RoleSolicitationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleSolicitationService.RoleSolicitationUpdateRequestDto roleSolicitationUpdateRequestDto = new RoleSolicitationService.RoleSolicitationUpdateRequestDto();

        roleSolicitationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleSolicitationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        roleSolicitationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        roleSolicitationUpdateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        roleSolicitationUpdateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );
        roleSolicitationUpdateRequestDto.setReason( arg0.getReason() );

        return roleSolicitationUpdateRequestDto;
    }
}
