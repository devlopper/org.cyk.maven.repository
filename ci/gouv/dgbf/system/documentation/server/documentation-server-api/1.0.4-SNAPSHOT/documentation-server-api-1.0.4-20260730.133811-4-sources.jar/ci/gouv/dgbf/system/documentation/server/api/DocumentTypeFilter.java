package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les types de document.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentTypeFilter extends AbstractIdentifiableFilter {

}
