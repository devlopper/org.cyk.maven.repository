package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T18:33:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentRequestMapperImpl implements PayrollComponentRequestMapper {

    @Override
    public PayrollComponentService.PayrollComponentCreateRequestDto mapCreate(PayrollComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentService.PayrollComponentCreateRequestDto payrollComponentCreateRequestDto = new PayrollComponentService.PayrollComponentCreateRequestDto();

        payrollComponentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentCreateRequestDto.setCode( arg0.getCode() );
        payrollComponentCreateRequestDto.setName( arg0.getName() );
        payrollComponentCreateRequestDto.setIsEarning( arg0.getIsEarning() );
        payrollComponentCreateRequestDto.setIsTaxable( arg0.getIsTaxable() );
        payrollComponentCreateRequestDto.setIsPensionable( arg0.getIsPensionable() );
        payrollComponentCreateRequestDto.setIsNetCumulable( arg0.getIsNetCumulable() );
        payrollComponentCreateRequestDto.setEmployeeCalculationFormulaIdentifier( arg0.getEmployeeCalculationFormulaIdentifier() );
        payrollComponentCreateRequestDto.setEmployerCalculationFormulaIdentifier( arg0.getEmployerCalculationFormulaIdentifier() );
        payrollComponentCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        payrollComponentCreateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        payrollComponentCreateRequestDto.setIsEvaluableInSecondaryContext( arg0.getIsEvaluableInSecondaryContext() );

        return payrollComponentCreateRequestDto;
    }

    @Override
    public PayrollComponentService.PayrollComponentUpdateRequestDto mapUpdate(PayrollComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentService.PayrollComponentUpdateRequestDto payrollComponentUpdateRequestDto = new PayrollComponentService.PayrollComponentUpdateRequestDto();

        payrollComponentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentUpdateRequestDto.setCode( arg0.getCode() );
        payrollComponentUpdateRequestDto.setName( arg0.getName() );
        payrollComponentUpdateRequestDto.setIsEarning( arg0.getIsEarning() );
        payrollComponentUpdateRequestDto.setIsTaxable( arg0.getIsTaxable() );
        payrollComponentUpdateRequestDto.setIsPensionable( arg0.getIsPensionable() );
        payrollComponentUpdateRequestDto.setIsNetCumulable( arg0.getIsNetCumulable() );
        payrollComponentUpdateRequestDto.setEmployeeCalculationFormulaIdentifier( arg0.getEmployeeCalculationFormulaIdentifier() );
        payrollComponentUpdateRequestDto.setEmployerCalculationFormulaIdentifier( arg0.getEmployerCalculationFormulaIdentifier() );
        payrollComponentUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        payrollComponentUpdateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        payrollComponentUpdateRequestDto.setIsEvaluableInSecondaryContext( arg0.getIsEvaluableInSecondaryContext() );

        return payrollComponentUpdateRequestDto;
    }
}
