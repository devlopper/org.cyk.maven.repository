package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ConstantGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ConstantGroupFilter extends AbstractIdentifiableFilter {
  
}
