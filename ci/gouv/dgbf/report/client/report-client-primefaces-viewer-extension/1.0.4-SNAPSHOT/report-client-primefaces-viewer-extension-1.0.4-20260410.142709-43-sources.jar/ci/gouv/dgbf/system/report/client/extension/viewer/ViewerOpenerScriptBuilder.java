package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente un constructeur de script d'ouverture de visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerOpenerScriptBuilder {
  private static final Logger LOGGER = Logger.getLogger(ViewerOpenerScriptBuilder.class.getName());

  @Inject
  ViewerUriBuilder uriBuilder;

  @Inject
  StringHelper stringHelper;

  String windowName;

  String parameters;

  /**
   * Cette méthode permet de construire le script d'ouverture d'un visualisateur.
   *
   * @return script d'ouverture de visualisateur
   */
  public String build() {
    validate();
    URI uri = uriBuilder.build();
    String localWindowName = stringHelper().defaultToIfBlank(this.windowName, "etat");
    String localParameters = stringHelper().defaultToIfBlank(this.parameters,
        "scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,titlebar=no");
    String script = String.format(SCRIPT_FORMAT, uri, localWindowName, localParameters);
    LOGGER.log(Level.FINER, "Script d''ouverture du visualisateur de rapport construit. {0}",
        script);
    return script;
  }
  
  void validate() {
    if (uriBuilder == null) {
      throw new IllegalArgumentException("Le constructeur d'uri est obligatoire");
    }
  }

  /**
   * Cette méthode permet d'obtenir un constructeur d'URI de visualisateur.
   *
   * @return URI visualisateur
   */
  public ViewerUriBuilder uriBuilder() {
    if (uriBuilder == null) {
      uriBuilder = new ViewerUriBuilder();
    }
    return uriBuilder;
  }

  StringHelper stringHelper() {
    if (stringHelper == null) {
      stringHelper = new StringHelper();
    }
    return stringHelper;
  }

  /*
   * Problème de CORS probable : w.document.title = '%2$s';
   */
  private static final String SCRIPT_FORMAT =
      "var w = window.open('%1$s','%2$s','%3$s');";
}
