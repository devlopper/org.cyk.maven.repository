package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasOrderNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTemplateAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTemplateIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link PayrollComponentDto} de {@link PayslipTemplateDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipTemplateComponentDto extends AbstractIdentifiableAuditableDto
    implements HasPayslipTemplateIdentifierDto, HasPayslipTemplateAsStringDto,
    HasPayrollComponentIdentifierDto, HasPayrollComponentAsStringDto, HasOrderNumberDto {

  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  private String payrollComponentAsString;

  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
  private String payslipTemplateIdentifier;

  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_AS_STRING)
  private String payslipTemplateAsString;

  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPosteModeleBulletinPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "posteModeleBulletinPaieChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de modèle de bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de modèle de bulletin de paie";
}
