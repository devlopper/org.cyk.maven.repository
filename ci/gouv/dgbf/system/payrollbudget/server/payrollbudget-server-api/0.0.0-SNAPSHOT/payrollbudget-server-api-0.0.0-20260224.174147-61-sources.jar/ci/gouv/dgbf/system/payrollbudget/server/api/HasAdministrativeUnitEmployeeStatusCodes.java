package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;
import java.util.Set;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeStatusCodes extends HasField {

  /**
   * Cette méthode permet d'obtenir les codes de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @return codes de {@link AdministrativeUnitEmployeeStatus}
   */
  Set<String> getAdministrativeUnitEmployeeStatusCodes();

  /**
   * Cette méthode permet d'assigner les codes de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param codes codes de {@link AdministrativeUnitEmployeeStatus}
   */
  void setAdministrativeUnitEmployeeStatusCodes(Set<String> codes);

}
