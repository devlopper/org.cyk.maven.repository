package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasMovementTypeIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link MovementTypeDto}.
   *
   * @return identifiant de {@link MovementTypeDto}
   */
  String getMovementTypeIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link MovementTypeDto}.
   *
   * @param identifier identifiant de {@link MovementTypeDto}
   */
  void setMovementTypeIdentifier(String identifier);

}
