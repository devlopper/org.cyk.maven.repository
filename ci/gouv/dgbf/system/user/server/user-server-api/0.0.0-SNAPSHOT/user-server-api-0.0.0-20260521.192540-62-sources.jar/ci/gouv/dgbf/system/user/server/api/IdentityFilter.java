package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityFilter extends AbstractIdentifiableFilter {

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  String emailAddress;

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  String registrationNumber;

  /**
   * Identifiant unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    emailAddress = getEmailAddress(filter);
    registrationNumber = getRegistrationNumber(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setEmailAddress(filter, emailAddress);
    setRegistrationNumber(filter, registrationNumber);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #emailAddress}.
   *
   * @param filter filtre
   * @param emailAddress {@link #emailAddress}
   */
  public static void setEmailAddress(FilterDto filter, String emailAddress) {
    set(filter, JSON_EMAIL_ADDRESS, f -> f.getValueAsString(),
        f -> f.setValueAsString(emailAddress));
  }

  /**
   * Cette méthode permet d'obtenir {@link #emailAddress}.
   *
   * @param filter filtre
   * @return {@link #emailAddress}
   */
  public static String getEmailAddress(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EMAIL_ADDRESS));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumber}.
   *
   * @param filter filtre
   * @param registrationNumber {@link #registrationNumber}
   */
  public static void setRegistrationNumber(FilterDto filter, String registrationNumber) {
    set(filter, JSON_REGISTRATION_NUMBER, f -> f.getValueAsString(),
        f -> f.setValueAsString(registrationNumber));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumber}.
   *
   * @param filter filtre
   * @return {@link #registrationNumber}
   */
  public static String getRegistrationNumber(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER));
  }

  /**
   * Cette méthode permet d'assigner {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @param administrativeUnitIdentifier {@link #administrativeUnitIdentifier}
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter,
      String administrativeUnitIdentifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(administrativeUnitIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @return {@link #administrativeUnitIdentifier}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = IdentityDto.JSON_EMAIL_ADDRESS;

  /**
   * Identifiant JSON {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = IdentityDto.JSON_REGISTRATION_NUMBER;

  /**
   * Identifiant JSON {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      "idUniteAdministrative";
}

