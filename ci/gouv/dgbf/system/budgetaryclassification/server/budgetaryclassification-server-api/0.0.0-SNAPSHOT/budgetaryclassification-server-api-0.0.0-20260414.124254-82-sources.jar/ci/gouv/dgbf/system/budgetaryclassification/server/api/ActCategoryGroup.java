package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les groupes de categories d'acte de {@link ActCategoryGroup}.
 *
 * @author AKM
 *
 */
@Getter
public enum ActCategoryGroup {

  /**
   * Intégration de resources.
   */
  RESOURCE_INTEGRATION(ActCategoryGroupCode.RESOURCE_INTEGRATION, "Intégration de resources"),
  /**
   * Répartition de crédits.
   */
  CREDIT_DISTRIBUTION(ActCategoryGroupCode.CREDIT_DISTRIBUTION, "Répartition de crédits"),
  /**
   * Répartition de resources.
   */
  RESOURCE_DISTRIBUTION(ActCategoryGroupCode.RESOURCE_DISTRIBUTION, "Répartition de resources")

  ;

  private ActCategoryGroup(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le groupe de catégorie par code.
   *
   * @param code code
   * @return statut
   */
  public static ActCategoryGroup getByCode(String code) {
    return Stream.of(ActCategoryGroup.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
