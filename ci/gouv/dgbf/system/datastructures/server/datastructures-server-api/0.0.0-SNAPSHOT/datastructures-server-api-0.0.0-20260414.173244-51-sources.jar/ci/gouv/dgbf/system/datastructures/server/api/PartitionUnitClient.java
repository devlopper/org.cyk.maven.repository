package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitCreateByNameRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitUpdateByNameRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PartitionUnitService}.
 *
 * @author Arnaud
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PartitionUnitClient extends AbstractClient<PartitionUnitService>
    implements GetByIdentifier<PartitionUnitDto>, GetMany<PartitionUnitGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PartitionUnitClient service(PartitionUnitService service) {
    return (PartitionUnitClient) super.service(service);
  }

  /**
   * {@link PartitionUnitService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PartitionUnitCreateRequestDto request) {
    return new CreateExecutor(PartitionUnitService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PartitionUnitService#createByName}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByName(PartitionUnitCreateByNameRequestDto request) {
    return new CreateExecutor(PartitionUnitService.CREATE_BY_NAME_IDENTIFIER)
        .execute(() -> service().createByName(request));
  }

  /**
   * {@link PartitionUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PartitionUnitGetManyResponseDto>(
        PartitionUnitGetManyResponseDto.class, PartitionUnitService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PartitionUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionUnitGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link HierarchyService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PartitionUnitDto>(PartitionUnitDto.class,
        PartitionUnitService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PartitionUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PartitionUnitDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PartitionUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PartitionUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PartitionUnitDto>(PartitionUnitDto.class,
        PartitionUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PartitionUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionUnitDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PartitionUnitService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PartitionUnitUpdateRequestDto request) {
    return new IdentifiableExecutor(PartitionUnitService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PartitionUnitService#updateByName}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateByName(PartitionUnitUpdateByNameRequestDto request) {
    return new IdentifiableExecutor(PartitionUnitService.UPDATE_BY_NAME_IDENTIFIER)
        .execute(() -> service().updateByName(request));
  }

  /**
   * {@link PartitionUnitService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PartitionUnitService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PartitionUnitService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
