package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentitiesGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentitiesGroupFilter extends AbstractIdentifiableFilter {
  
}
