package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un poste budgétaire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetItemDto extends AbstractIdentifiableCodableNamableAuditableDto {
  
  /**
   * est une dépense.
   */
  @JsonbProperty(JSON_IS_EXPENDITURE)
  private Boolean isExpenditure;
  
  /**
   * Identifiant java champ {@link BudgetItemDto#isExpenditure}.
   */
  public static final String FIELD_IS_EXPENDITURE = "status";
  
  /**
   * Identifiant json champ {@link BudgetItemDto#isExpenditure}.
   */
  public static final String JSON_IS_EXPENDITURE = "estDepense";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste budgétaire";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes budgétaires";
}
