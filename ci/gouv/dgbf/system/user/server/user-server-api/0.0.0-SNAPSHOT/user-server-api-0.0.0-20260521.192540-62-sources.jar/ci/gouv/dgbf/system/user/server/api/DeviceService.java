package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DeviceDto}.
 *
 * @author Christian
 *
 */
@Path(value = DeviceService.PATH)
@Tag(name = "Gestion des équipements")
public interface DeviceService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "equipments";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface DeviceSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir la marque.
     *
     * @return la marque
     */
    String getBrand();

    /**
     * Cette méthode permet d'assigner la marque.
     *
     * @param brand la marque
     
     */
    void setBrand(String brand);

    /**
     * {@link DeviceDto#JSON_BRAND}.
     */
    String JSON_BRAND = DeviceDto.JSON_BRAND;

    /**
     * Cette méthode permet d'obtenir le modèle.
     *
     * @return le modèle
     */
    String getModel();

    /**
     * Cette méthode permet d'assigner la modèle.
     *
     * @param model le modèle
     */
    void setModel(String model);

    /**
     * {@link DeviceDto#JSON_MODEL}.
     */
    String JSON_MODEL = DeviceDto.JSON_MODEL;

    /**
     * Cette méthode permet d'obtenir le système d'exploitation.
     *
     * @return le système d'exploitation
     */
    String getOperatingSystem();

    /**
     * Cette méthode permet d'assigner le système d'exploitation.
     *
     * @param operatingSystem le système d'exploitation
     */
    void setOperatingSystem(String operatingSystem);

    /**
     * {@link DeviceDto#JSON_OPERATING_SYSTEM}.
     */
    String JSON_OPERATING_SYSTEM = DeviceDto.JSON_OPERATING_SYSTEM;

    /**
     * Cette méthode permet d'obtenir l'imei.
     *
     * @return l'imei
     */
    String getImei();

    /**
     * Cette méthode permet d'assigner l'imei.
     *
     * @param imei l'imei
     */
    void setImei(String imei);

    /**
     * {@link DeviceDto#JSON_IMEI}.
     */
    String JSON_IMEI = DeviceDto.JSON_IMEI;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EQUIPEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DeviceCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeviceCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DeviceSaveRequestDto {

    @JsonbProperty(JSON_BRAND)
    private String brand;

    @JsonbProperty(JSON_MODEL)
    private String model;

    @JsonbProperty(JSON_OPERATING_SYSTEM)
    private String operatingSystem;

    @JsonbProperty(JSON_IMEI)
    private String imei;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EQUIPEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeviceGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  public static class DeviceGetManyResponseDto 
       extends AbstractGetByPageResponseDto<DeviceDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DeviceDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EQUIPEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeviceDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EQUIPEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeviceDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EQUIPEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DeviceUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class DeviceUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DeviceSaveRequestDto {

    
    @JsonbProperty(JSON_BRAND)
    private String brand;

    @JsonbProperty(JSON_MODEL)
    private String model;

    @JsonbProperty(JSON_OPERATING_SYSTEM)
    private String operatingSystem;

    @JsonbProperty(JSON_IMEI)
    private String imei;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UN_EQUIPEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DeviceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
