package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'utilisateur groupe.
 *
 * @author Christian
 */
public interface HasUserGroupIdentifierDto extends HasUserGroupIdentifier {

  /**
   * Identifiant json de l'identifiant de l'utilisateur groupe.
   */
  String JSON_USER_GROUP_IDENTIFIER = "idUtilisateurGroupe";
}
