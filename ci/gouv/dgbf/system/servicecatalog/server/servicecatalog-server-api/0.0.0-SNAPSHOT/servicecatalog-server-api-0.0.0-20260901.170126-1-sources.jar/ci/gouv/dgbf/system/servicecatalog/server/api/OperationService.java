package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link OperationDto}.
 *
 * @author Christian
 */
@Path(value = OperationService.PATH)
@Tag(name = "Gestion des Opérations")
public interface OperationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "operations";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface OperationSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir description de l'opération.
     *
     * @return description de l'opération
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner description de l'opération.
     *
     * @param description description de l'opération
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir chemin technique ({@code @Path}) du endpoint réel, combiné
     * à l'URL de base du Processus implémenteur — adresse d'appel, jamais de navigation
     * humaine.
     *
     * @return chemin technique ({@code @Path}) du endpoint réel, combiné à l'URL de base du
     *     Processus implémenteur — adresse d'appel, jamais de navigation humaine
     */
    String getExecutionPath();

    /**
     * Cette méthode permet d'assigner chemin technique ({@code @Path}) du endpoint réel, combiné
     * à l'URL de base du Processus implémenteur — adresse d'appel, jamais de navigation
     * humaine.
     *
     * @param executionPath chemin technique ({@code @Path}) du endpoint réel, combiné à l'URL
     *     de base du Processus implémenteur — adresse d'appel, jamais de navigation humaine
     */
    void setExecutionPath(String executionPath);

    /**
     * Cette méthode permet d'obtenir verbe HTTP du endpoint (GET, POST, PUT, DELETE, PATCH).
     *
     * @return verbe HTTP du endpoint (GET, POST, PUT, DELETE, PATCH)
     */
    String getHttpMethod();

    /**
     * Cette méthode permet d'assigner verbe HTTP du endpoint (GET, POST, PUT, DELETE, PATCH).
     *
     * @param httpMethod verbe HTTP du endpoint (GET, POST, PUT, DELETE, PATCH)
     */
    void setHttpMethod(String httpMethod);

    /**
     * Cette méthode permet d'obtenir référence optionnelle vers le Cas d'Utilisation du
     * module propriétaire (ex: CU_DOC_004) — best-effort, non garantie à jour, jamais utilisée
     * par une règle de gestion.
     *
     * @return référence optionnelle vers le Cas d'Utilisation du module propriétaire (ex:
     *     CU_DOC_004) — best-effort, non garantie à jour, jamais utilisée par une règle de
     *     gestion
     */
    String getUseCaseReference();

    /**
     * Cette méthode permet d'assigner référence optionnelle vers le Cas d'Utilisation du
     * module propriétaire (ex: CU_DOC_004) — best-effort, non garantie à jour, jamais utilisée
     * par une règle de gestion.
     *
     * @param useCaseReference référence optionnelle vers le Cas d'Utilisation du module
     *     propriétaire (ex: CU_DOC_004) — best-effort, non garantie à jour, jamais utilisée
     *     par une règle de gestion
     */
    void setUseCaseReference(String useCaseReference);

    /**
     * Cette méthode permet d'obtenir identifiant du Processus auquel cette opération est
     * obligatoirement rattachée.
     *
     * @return identifiant du Processus auquel cette opération est obligatoirement rattachée
     */
    String getProcessIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du Processus auquel cette opération est
     * obligatoirement rattachée.
     *
     * @param processIdentifier identifiant du Processus auquel cette opération est
     *     obligatoirement rattachée
     */
    void setProcessIdentifier(String processIdentifier);

    /**
     * {@link OperationDto#JSON_DESCRIPTION}.
     */
    String JSON_DESCRIPTION = OperationDto.JSON_DESCRIPTION;

    /**
     * {@link OperationDto#JSON_EXECUTION_PATH}.
     */
    String JSON_EXECUTION_PATH = OperationDto.JSON_EXECUTION_PATH;

    /**
     * {@link OperationDto#JSON_HTTP_METHOD}.
     */
    String JSON_HTTP_METHOD = OperationDto.JSON_HTTP_METHOD;

    /**
     * {@link OperationDto#JSON_USE_CASE_REFERENCE}.
     */
    String JSON_USE_CASE_REFERENCE = OperationDto.JSON_USE_CASE_REFERENCE;

    /**
     * {@link OperationDto#JSON_PROCESS_IDENTIFIER}.
     */
    String JSON_PROCESS_IDENTIFIER = OperationDto.JSON_PROCESS_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link OperationDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_OPERATION";

  /**
   * Chemin du service de création unitaire de {@link OperationDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(OperationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link OperationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class OperationCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements OperationSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_EXECUTION_PATH)
    private String executionPath;

    @JsonbProperty(JSON_HTTP_METHOD)
    private String httpMethod;

    @JsonbProperty(JSON_USE_CASE_REFERENCE)
    private String useCaseReference;

    @JsonbProperty(JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link OperationDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_OPERATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link OperationDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = OperationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link OperationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class OperationGetManyResponseDto
      extends AbstractGetByPageResponseDto<OperationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<OperationDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link OperationDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_OPERATION";

  /**
   * Chemin du service d'obtention unitaire de {@link OperationDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = OperationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link OperationDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_OPERATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link OperationDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = OperationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link OperationDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_OPERATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link OperationDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(OperationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link OperationDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class OperationUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements OperationSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_EXECUTION_PATH)
    private String executionPath;

    @JsonbProperty(JSON_HTTP_METHOD)
    private String httpMethod;

    @JsonbProperty(JSON_USE_CASE_REFERENCE)
    private String useCaseReference;

    @JsonbProperty(JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link OperationDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_OPERATION";

  /**
   * Chemin du service de suppression unitaire de {@link OperationDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link OperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
