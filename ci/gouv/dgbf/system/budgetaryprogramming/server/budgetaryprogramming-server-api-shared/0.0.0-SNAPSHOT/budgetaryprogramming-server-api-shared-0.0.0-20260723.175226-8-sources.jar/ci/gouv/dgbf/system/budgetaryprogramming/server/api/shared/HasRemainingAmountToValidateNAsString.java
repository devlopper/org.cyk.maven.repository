package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateNAsString {

  /**
   * Obtient le montant restant à valider pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant restant à valider pour l'année N sous forme de chaîne de caractères,
   *         {@code null} si aucun plafond n'est défini pour l'année N
   */
  String getRemainingAmountToValidateNAsString();

  /**
   * Définit le montant restant à valider pour l'année N, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToValidateNAsString le montant restant à valider pour l'année N sous
   *        forme de chaîne de caractères
   */
  void setRemainingAmountToValidateNAsString(String remainingAmountToValidateNAsString);

  /**
   * Identifiant java du montant restant à valider pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_VALIDATE_N_AS_STRING = "remainingAmountToValidateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
