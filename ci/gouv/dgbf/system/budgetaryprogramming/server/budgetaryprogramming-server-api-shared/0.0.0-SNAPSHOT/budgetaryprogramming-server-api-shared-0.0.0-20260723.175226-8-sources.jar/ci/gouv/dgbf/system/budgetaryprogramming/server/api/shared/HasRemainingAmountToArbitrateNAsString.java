package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateNAsString {

  /**
   * Obtient le montant restant à arbitrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant restant à arbitrer pour l'année N sous forme de chaîne de caractères
   */
  String getRemainingAmountToArbitrateNAsString();

  /**
   * Définit le montant restant à arbitrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToArbitrateNAsString le montant restant à arbitrer pour l'année N sous
   *        forme de chaîne de caractères
   */
  void setRemainingAmountToArbitrateNAsString(String remainingAmountToArbitrateNAsString);

  /**
   * Identifiant java du montant restant à arbitrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_ARBITRATE_N_AS_STRING =
      "remainingAmountToArbitrateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName