package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépense.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetSpecializationUnitDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_BUDGET_CATEGORY_IDENTIFIER)
  private String budgetCategoryIdentifier;

  @JsonbProperty(JSON_BUDGET_CATEGORY_AS_STRING)
  private String budgetCategoryAsString;

  @JsonbProperty(JSON_SECTION_IDENTIFIER)
  private String sectionIdentifier;

  @JsonbProperty(JSON_SECTION_AS_STRING)
  private String sectionAsString;

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;


  /**
   * Identifiant json champ {@link #budgetCategoryIdentifier}.
   */
  public static final String JSON_BUDGET_CATEGORY_IDENTIFIER =
      BudgetCategoryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #budgetCategoryAsString}.
   */
  public static final String JSON_BUDGET_CATEGORY_AS_STRING = BudgetCategoryDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #sectionIdentifier}.
   */
  public static final String JSON_SECTION_IDENTIFIER =
      SectionDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #sectionAsString}.
   */
  public static final String JSON_SECTION_AS_STRING =
      SectionDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER =
      BudgetSpecializationUnitCategoryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING =
      BudgetSpecializationUnitCategoryDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant json de identifiant de {@link BudgetSpecializationUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUniteSpecialisationBudget";

  /**
   * Identifiant json de représentation en chaine de caractères de.
   * {@link BudgetSpecializationUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "uniteSpecialisationBudgetChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "unité de spécialisation de budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "unités de spécialisation de budget";
}

