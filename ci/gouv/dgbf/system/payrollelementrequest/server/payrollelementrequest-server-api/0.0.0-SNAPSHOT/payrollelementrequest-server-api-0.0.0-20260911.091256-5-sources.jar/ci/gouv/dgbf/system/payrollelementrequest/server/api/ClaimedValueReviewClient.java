package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToVisaRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueReviewService.ClaimedValueReviewTransmitToVisaResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ClaimedValueReviewService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ClaimedValueReviewClient extends AbstractClient<ClaimedValueReviewService> {

  @Override
  public ClaimedValueReviewClient service(ClaimedValueReviewService service) {
    return (ClaimedValueReviewClient) super.service(service);
  }

  /**
   * {@link ClaimedValueReviewService#transmitToVisa}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueReviewTransmitToVisaResponseDto transmitToVisa(
      ClaimedValueReviewTransmitToVisaRequestDto request) {
    return new GetOneExecutor<ClaimedValueReviewTransmitToVisaResponseDto>(
        ClaimedValueReviewTransmitToVisaResponseDto.class,
        ClaimedValueReviewService.TRANSMIT_TO_VISA_IDENTIFIER)
            .execute(() -> service().transmitToVisa(request));
  }
}
