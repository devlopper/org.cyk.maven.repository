package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une liquidation.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureSettlementDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Code {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_CODE)
  private String localAuthorityCode;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Identifiant json de l'identifiant du fournisseur.
   */
  @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
  private String supplierIdentifier;

  /**
   * Identifiant json du code du fournisseur}.
   */
  @JsonbProperty(JSON_SUPPLIER_CODE)
  private String supplierCode;

  /**
   * Identifiant json du libellé du fournisseur}.
   */
  @JsonbProperty(JSON_SUPPLIER_NAME)
  private String supplierName;


  /**
   * Représentation en chaine de caractères du fournisseur.
   */
  @JsonbProperty(JSON_SUPPLIER_AS_STRING)
  private String supplierAsString;


  /**
   * Identifiant json de l'identifiant de la nature économique.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Identifiant json du code de la nature économique}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_CODE)
  private String economicNatureCode;


  /**
   * Identifiant json du libellé de la nature économique}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_NAME)
  private String economicNatureName;

  /**
   * Représentation en chaine de caractères de la nature économique.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String natureDepenseAsString;


  /**
   * Identifiant de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  public String triennialProgramIdentifier;


  /**
   * Identitiant json de l'identifiant du fournisseur.
   */
  public static final String JSON_SUPPLIER_IDENTIFIER = "idFournisseur";

  /**
   * Identitiant json du code fournisseur.
   */
  public static final String JSON_SUPPLIER_CODE = "codeFournisseur";


  /**
   * Identitiant json du libelle fournisseur.
   */
  public static final String JSON_SUPPLIER_NAME = "libelleFournisseur";

  /**
   * Représentation en chaine de caractères du fournisseur .
   */
  public static final String JSON_SUPPLIER_AS_STRING = "fournisseurChaine";


  /**
   * Identitiant json de l'identifiant de la nature économique.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureDepense";

  /**
   * Identitiant json du code de la nature économique.
   */
  public static final String JSON_ECONOMIC_NATURE_CODE = "codeNatureDepense";


  /**
   * Identitiant json du libelle de la nature économique.
   */
  public static final String JSON_ECONOMIC_NATURE_NAME = "libelleNatureDepense";

  /**
   * Représentation en chaine de caractères de la nature économique .
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING = "natureDeDepenseChaine";


  /**
   * Objet de la liquidation.
   */
  @JsonbProperty(JSON_SUBJECT)
  private String subject;

  /**
   * Référence de la liquidation.
   */
  @JsonbProperty(JSON_COMMITMENT_REFERENCE)
  private String commitmentReference;

  /**
   * Numéro facture decompte.
   */
  @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
  private String invoiceReferenceNumber;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Long amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;


  /**
   * Montant mandaté.
   */
  @JsonbProperty(JSON_AUTHORIZED_AMOUNT)
  private Long authorizedAmount;

  /**
   * Représentation en chaine de caractères du montant mandaté.
   */
  @JsonbProperty(JSON_AUTHORIZED_AMOUNT_AS_STRING)
  private String authorizedAmountAsString;


  /**
   * Montant restant à mandater.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_AUTHORIZE)
  private Long remainingAmountToAuthorize;

  /**
   * Représentation en chaine de caractères du montant restant à mandater.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_AUTHORIZE_AS_STRING)
  private String remainingAmountToAuthorizeAsString;

  /**
   * Représentation en chaine de caractères de la date.
   */
  @JsonbProperty(JSON_DATE)
  private LocalDate date;

  /**
   * Représentation en chaine de caractères de la date.
   */
  @JsonbProperty(JSON_DATE_AS_STRING)
  private String dateAsString;


  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityCode}.
   */
  public static final String JSON_LOCAL_AUTHORITY_CODE = LocalAuthorityDto.JSON_THIS_CODE;


  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";


  /**
   * Identifiant json {@link #authorizedAmount}.
   */
  public static final String JSON_AUTHORIZED_AMOUNT = "montantMandate";

  /**
   * Identifiant json {@link #authorizedAmountAsString}.
   */
  public static final String JSON_AUTHORIZED_AMOUNT_AS_STRING = "montantMandateChaine";


  /**
   * Identifiant json {@link #remainingAmountToAuthorize}.
   */
  public static final String JSON_REMAINING_AMOUNT_TO_AUTHORIZE = "montantRestantAPayer";

  /**
   * Identifiant json {@link #remainingAmountToAuthorizeAsString}.
   */
  public static final String JSON_REMAINING_AMOUNT_TO_AUTHORIZE_AS_STRING =
      "montantRestantAPayerChaine";


  /**
   * Identifiant json {@link #subject}.
   */
  public static final String JSON_SUBJECT = "objet";


  /**
   * Identifiant json {@link #commitmentReference}.
   */
  public static final String JSON_COMMITMENT_REFERENCE = "referenceEngagement";

  /**
   * Identifiant json {@link #invoiceReferenceNumber}.
   */
  public static final String JSON_INVOICE_REFERENCE_NUMBER = "numeroFactureDecompte";

  /**
   * Identifiant json {@link #date}.
   */
  public static final String JSON_DATE = "date";

  /**
   * Identifiant json {@link #dateAsString}.
   */
  public static final String JSON_DATE_AS_STRING = "dateChaine";

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "liquidation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}

