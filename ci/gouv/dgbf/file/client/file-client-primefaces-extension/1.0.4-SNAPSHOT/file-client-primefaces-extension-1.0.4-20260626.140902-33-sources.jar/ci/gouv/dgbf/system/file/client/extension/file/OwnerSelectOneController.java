package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.file.server.api.OwnerClient;
import ci.gouv.dgbf.system.file.server.api.OwnerDto;
import ci.gouv.dgbf.system.file.server.api.OwnerService.OwnerGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link OwnerDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class OwnerSelectOneController
    extends AbstractSelectOneIdentifiableController<OwnerDto,
        OwnerGetManyResponseDto, OwnerClient> {

  @Inject
  @Getter
  OwnerClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected OwnerSelectOneController() {
    super(OwnerDto.class);
  }
}
