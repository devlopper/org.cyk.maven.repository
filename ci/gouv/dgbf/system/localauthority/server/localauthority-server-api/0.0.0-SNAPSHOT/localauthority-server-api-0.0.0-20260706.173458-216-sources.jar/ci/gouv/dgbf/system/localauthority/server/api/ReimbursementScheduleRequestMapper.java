package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ReimbursementScheduleService.ReimbursementScheduleCreateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ReimbursementScheduleDto}.
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ReimbursementScheduleDto}.
    
    @author Desysoft
    """)
public interface ReimbursementScheduleRequestMapper
    extends
    RequestMapper<ReimbursementScheduleDto, ReimbursementScheduleCreateRequestDto,
        ReimbursementScheduleService.ReimbursementScheduleUpdateRequestDto> {
}

