package ci.gouv.dgbf.system.sharing.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des unités de spécialisation de budget partagées de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedBudgetSpecializationUnitListPage
    extends AbstractConnectedUserSharedBudgetSpecializationUnitListPage {

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "connectedUserSharedBudgetSpecializationUnitListPage";

  static final String PATH = "/private/resource/connecteduser/budgetspecializationunits.xhtml";
}
