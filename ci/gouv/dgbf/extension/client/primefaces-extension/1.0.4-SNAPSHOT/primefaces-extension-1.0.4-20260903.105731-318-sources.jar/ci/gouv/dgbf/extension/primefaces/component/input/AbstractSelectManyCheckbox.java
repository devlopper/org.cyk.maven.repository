package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une sélection de plusieurs valeurs par checkbox.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectManyCheckbox<T> extends AbstractSelectMany<T> {

  private String layout;
  private Integer columns;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectManyCheckbox() {
    layout = "lineDirection";
    columns = 12;
  }

  /**
   * Cette méthode permet d'obtenir le nombre de colonnes à utiliser à l'affichage, plafonné au
   * nombre de choix afin d'éviter que chaque choix soit écrasé dans une colonne trop étroite
   * lorsqu'il y a moins de choix que {@link #columns}.
   *
   * @return nombre de colonnes à utiliser à l'affichage
   */
  public Integer getEffectiveColumns() {
    if (columns == null || Core.isCollectionEmpty(choices)) {
      return columns;
    }
    return Math.min(columns, choices.size());
  }
}
