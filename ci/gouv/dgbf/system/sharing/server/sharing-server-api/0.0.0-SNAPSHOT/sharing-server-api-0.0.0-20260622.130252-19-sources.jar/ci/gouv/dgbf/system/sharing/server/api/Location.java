package ci.gouv.dgbf.system.sharing.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette énumération représente les localisations.<br/>
 * Une localisation contient des données qui sont partageables ou des données qui peuvent être
 * destinataire de données partagées.<br/>
 * <br/>
 * Le cas spécifique est que les utilisateurs ou groupes d'utilisateurs du système de la DGBF ne
 * manipulent pas les mêmes données. Les données se trouvent dans plusieurs bases. La base qui
 * stocke la donnée à partager est une localisation. Aussi, la base qui stocke l'utilisateur ou
 * groupe d'utlisateur est une localisation.<br/>
 * <br/>
 * Le cas général est le fait qu'une donnée puisse être partagée à une autre. Chaque donnée est
 * localisée.
 *
 * @author Christian
 *
 */
@Getter
public enum Location {

  /**
   * {@link LocationCode#BUDGETARY_CLASSIFICATION}.
   */
  BUDGETARY_CLASSIFICATION(LocationCode.BUDGETARY_CLASSIFICATION, "Classification budgétaire"),

  /**
   * {@link LocationCode#FOLDER}.
   */
  FOLDER(LocationCode.FOLDER, "Dossier"),

  /**
   * {@link LocationCode#USER}.
   */
  USER(LocationCode.USER, "Utilisateur"),

  /**
   * {@link LocationCode#TASK}.
   */
  TASK(LocationCode.TASK, "Tâche"),

  /**
   * {@link LocationCode#FILE}.
   */
  FILE(LocationCode.FILE, "Fichier")
  ;

  private Location(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link Location} par code.
   *
   * @param code code
   * @return {@link Location}
   */
  public static Location getByCode(String code) {
    return Stream.of(Location.values()).filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }
}
