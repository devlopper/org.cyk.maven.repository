package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-25T15:52:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentationRequestMapperImpl implements DocumentationRequestMapper {

    @Override
    public DocumentationService.DocumentationCreateRequestDto mapCreate(DocumentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentationService.DocumentationCreateRequestDto documentationCreateRequestDto = new DocumentationService.DocumentationCreateRequestDto();

        documentationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentationCreateRequestDto.setText( arg0.getText() );
        documentationCreateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return documentationCreateRequestDto;
    }

    @Override
    public DocumentationService.DocumentationUpdateRequestDto mapUpdate(DocumentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentationService.DocumentationUpdateRequestDto documentationUpdateRequestDto = new DocumentationService.DocumentationUpdateRequestDto();

        documentationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentationUpdateRequestDto.setText( arg0.getText() );
        documentationUpdateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return documentationUpdateRequestDto;
    }
}
