package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un constructeur de la valeur de la propriété update d'une commande.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class CommandUpdatePropertyValueBuilder {

  Set<String> strings;
  Collection<AbstractWidget> widgets;

  /**
   * Cette méthode permet de construire la valeur.
   *
   * @return valeur.
   */
  public String build() {
    Set<String> set = new HashSet<>();
    Core.runIfCollectionNotEmpty(strings, () -> set.addAll(strings));
    Core.runIfCollectionNotEmpty(widgets, () -> set
        .addAll(widgets.stream().map(widget -> widget.identifier).collect(Collectors.toSet())));
    return set.stream().collect(Collectors.joining(","));
  }

  /**
   * Cette méthode permet d'obtenir un ensemble non nul.
   *
   * @return ensemble non nul
   */
  public Set<String> strings() {
    Optional.ofNullable(strings).ifPresentOrElse(set -> { // Nothing to do
    }, () -> strings = new HashSet<>());
    return strings;
  }

  /**
   * Cette méthode permet d'obtenir une collection de {@link AbstractWidget} non nulle.
   *
   * @return collection de {@link AbstractWidget} non nulle
   */
  public Collection<AbstractWidget> widgets() {
    Optional.ofNullable(widgets).ifPresentOrElse(set -> { // Nothing to do
    }, () -> widgets = new HashSet<>());
    return widgets;
  }
  
  public static CommandUpdatePropertyValueBuilder newInstance() {
    return new CommandUpdatePropertyValueBuilder();
  }
  
  /**
   * Cette méthode permet de formatter pour le pattern observer.
   *
   * @param event évènement
   * @return valeur
   */
  public static String formatObserver(String event) {
    return String.format("@obs(%s)", event);
  }
}
