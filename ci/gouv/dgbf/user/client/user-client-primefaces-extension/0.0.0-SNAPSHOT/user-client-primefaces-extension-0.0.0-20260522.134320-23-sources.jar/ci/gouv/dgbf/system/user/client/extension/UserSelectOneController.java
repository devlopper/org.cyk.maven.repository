package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link UserDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UserSelectOneController extends AbstractSelectOneIdentifiableController<
    UserDto, UserGetManyResponseDto, UserClient> {

  @Inject
  @Getter
  UserClient client;

  /**
   * Cette methode permet de construire.
   */
  protected UserSelectOneController() {
    super(UserDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
