package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.ExpenditureClient;
import ci.gouv.dgbf.system.payroll.server.api.ExpenditureDto;
import ci.gouv.dgbf.system.payroll.server.api.ExpenditureService.ExpenditureGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ExpenditureDto}.
 *
 * @author arnaud
 *
 */
@Dependent
public class ExpenditureSelectOneController extends AbstractSelectOneIdentifiableController<
    ExpenditureDto, ExpenditureGetManyResponseDto, ExpenditureClient> {

  @Getter
  @Inject
  ExpenditureClient client;

  protected ExpenditureSelectOneController() {
    super(ExpenditureDto.class, SelectItemLabelStrategy.NAME);
  }
}
