package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PartitionUnitDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionUnitSelectOneController extends
    AbstractSelectOneIdentifiableController<PartitionUnitDto, 
    PartitionUnitGetManyResponseDto, PartitionUnitClient> {

  @Getter
  @Inject
  PartitionUnitClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PartitionUnitSelectOneController() {
    super(PartitionUnitDto.class, SelectItemLabelStrategy.NAME);
  }
}
