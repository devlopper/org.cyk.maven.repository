package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un budget.
 *
 * @author Donsylla
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Année {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_YEAR)
  private Integer exerciseYear;

  /**
   * Représentation en chaine de caractères de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Code {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_CODE)
  private String localAuthorityCode;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Identifiant {@link TriennialProgramDto} d'origine.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto} d'origine.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;

  /**
   * Type du budget.
   */
  @JsonbProperty(JSON_TYPE)
  private BudgetType type;

  /**
   * Type du budget au format chaine de caractère.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Statut du budget.
   */
  @JsonbProperty(JSON_STATUS)
  private BudgetStatus status;

  /**
   * Statut du budget au format chaine de caractère.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Observation.
   */
  @JsonbProperty(JSON_OBSERVATION)
  private String observation;

  /**
   * Numéro d'approbation du budget.
   */
  @JsonbProperty(JSON_APPROVAL_NUMBER)
  private String approvalNumber;

  /**
   * Date d'approbation du budget.
   */
  @JsonbProperty(JSON_BUSINESS_APPROVAL_DATE)
  private LocalDate businessApprovalDate;

  /**
   * Identifiant du groupe de fichiers.
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Représentation en chaine de caractères du total des recettes de fonctionnement.
   */
  @JsonbProperty(JSON_TOTAL_FUNCTIONING_REVENUE_AMOUNT_AS_STRING)
  private String totalFunctioningRevenueAmountAsString;

  /**
   * Représentation en chaine de caractères du total des dépenses de fonctionnement.
   */
  @JsonbProperty(JSON_TOTAL_FUNCTIONING_EXPENDITURE_AMOUNT_AS_STRING)
  private String totalFunctioningExpenditureAmountAsString;

  /**
   * Représentation en chaine de caractères du total des recettes d'investissement.
   */
  @JsonbProperty(JSON_TOTAL_INVESTMENT_REVENUE_AMOUNT_AS_STRING)
  private String totalInvestmentRevenueAmountAsString;

  /**
   * Représentation en chaine de caractères du total des dépenses d'investissement.
   */
  @JsonbProperty(JSON_TOTAL_INVESTMENT_EXPENDITURE_AMOUNT_AS_STRING)
  private String totalInvestmentExpenditureAmountAsString;

  /**
   * Modifiable.
   */
  @JsonbProperty(JSON_UPDATABLE)
  private Boolean updatable;

  /**
   * Validable.
   */
  @JsonbProperty(JSON_VALIDABLE)
  private Boolean validable;

  /**
   * Transmissible.
   */
  @JsonbProperty(JSON_TRANSMITABLE)
  private Boolean transmitable;

  /**
   * Différable.
   */
  @JsonbProperty(JSON_DEFERRABLE)
  private Boolean deferrable;

  /**
   * Approuvable.
   */
  @JsonbProperty(JSON_APPROVABLE)
  private Boolean approvable;

  /**
   * Identifiant json de l'identifiant de cette classe.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBudget";

  /**
   * Identifiant json de la représentation en chaine de caractères de cette classe.
   */
  public static final String JSON_THIS_AS_STRING = "budgetChaine";

  /**
   * Identifiant json {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #exerciseYear}.
   */
  public static final String JSON_EXERCISE_YEAR = ExerciseDto.JSON_THIS_YEAR;

  /**
   * Identifiant json {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityCode}.
   */
  public static final String JSON_LOCAL_AUTHORITY_CODE = LocalAuthorityDto.JSON_THIS_CODE;

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING =
      TriennialProgramDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #type}.
   */
  public static final String JSON_TYPE = "type";

  /**
   * Identifiant json champ {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = "typeChaine";

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant json champ {@link #observation}.
   */
  public static final String JSON_OBSERVATION = "observation";

  /**
   * Identifiant json champ {@link #approvalNumber}.
   */
  public static final String JSON_APPROVAL_NUMBER = "numeroApprobation";

  /**
   * Identifiant json champ {@link #businessApprovalDate}.
   */
  public static final String JSON_BUSINESS_APPROVAL_DATE = "dateApprobation";

  /**
   * Identifiant json champ {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER =
      TriennialProgramDto.JSON_FILES_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link #totalFunctioningRevenueAmountAsString}.
   */
  public static final String JSON_TOTAL_FUNCTIONING_REVENUE_AMOUNT_AS_STRING =
      "totalMontantRecetteFonctionnementChaine";

  /**
   * Identifiant json champ {@link #totalFunctioningExpenditureAmountAsString}.
   */
  public static final String JSON_TOTAL_FUNCTIONING_EXPENDITURE_AMOUNT_AS_STRING =
      "totalMontantDepenseFonctionnementChaine";

  /**
   * Identifiant json champ {@link #totalInvestmentRevenueAmountAsString}.
   */
  public static final String JSON_TOTAL_INVESTMENT_REVENUE_AMOUNT_AS_STRING =
      "totalMontantRecetteInvestissementChaine";

  /**
   * Identifiant json champ {@link #totalInvestmentExpenditureAmountAsString}.
   */
  public static final String JSON_TOTAL_INVESTMENT_EXPENDITURE_AMOUNT_AS_STRING =
      "totalMontantDepenseInvestissementChaine";

  /**
   * Identifiant json champ {@link #updatable}.
   */
  public static final String JSON_UPDATABLE = "modifiable";

  /**
   * Identifiant json champ {@link #validable}.
   */
  public static final String JSON_VALIDABLE = "validable";

  /**
   * Identifiant json champ {@link #transmitable}.
   */
  public static final String JSON_TRANSMITABLE = "transmettable";

  /**
   * Identifiant json champ {@link #deferrable}.
   */
  public static final String JSON_DEFERRABLE = "differable";

  /**
   * Identifiant json champ {@link #approvable}.
   */
  public static final String JSON_APPROVABLE = "approuvable";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "budgets";
}
