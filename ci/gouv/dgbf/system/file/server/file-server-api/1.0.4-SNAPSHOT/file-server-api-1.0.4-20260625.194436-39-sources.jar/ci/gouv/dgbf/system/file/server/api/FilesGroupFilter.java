package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FilesGroupFilter extends AbstractIdentifiableFilter
    implements FilterHasStatusCode, FilterHasStatusCodes {

  private String statusCode;
  private Set<String> statusCodes;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FilesGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FilesGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
  }

}
