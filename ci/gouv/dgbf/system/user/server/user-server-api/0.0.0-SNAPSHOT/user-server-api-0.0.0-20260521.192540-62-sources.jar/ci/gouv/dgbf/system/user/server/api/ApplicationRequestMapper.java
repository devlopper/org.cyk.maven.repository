package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ApplicationDto}.
    
    @author BoobaCool
    """)
public interface ApplicationRequestMapper
    extends
    RequestMapper<ApplicationDto, ApplicationCreateRequestDto, ApplicationUpdateRequestDto> {

}
