package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente la forme du contenu d'un {@link FileDto}, déduite et jamais saisie. Elle
 * est distincte du Type de Contenu (MIME) du contenu binaire. C'est le champ que tout consommateur
 * consulte avant de lire des octets (RG_FILE_FIC_17, 18).
 *
 * @author Christian
 *
 */
@Getter
public enum ContentForm {

  /**
   * Le Fichier a un contenu binaire : le rendu se fait à partir des octets.
   */
  BINARY("BINAIRE", "Binaire"),

  /**
   * Le Fichier n'a pas de contenu binaire : son contenu est sa description, rendue par la fiche
   * descriptive.
   */
  DESCRIPTIVE("DESCRIPTIF", "Descriptif");

  private final String code;
  private final String name;

  private ContentForm(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link ContentForm} par code.
   *
   * @param code code
   * @return {@link ContentForm}
   */
  public static ContentForm getByCode(String code) {
    return Stream.of(values()).filter(form -> form.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  /**
   * Cette méthode permet de déduire la forme du contenu.
   *
   * @param hasBinaryContent le Fichier a un contenu binaire
   * @return {@link ContentForm}
   */
  public static ContentForm of(boolean hasBinaryContent) {
    return hasBinaryContent ? BINARY : DESCRIPTIVE;
  }
}
