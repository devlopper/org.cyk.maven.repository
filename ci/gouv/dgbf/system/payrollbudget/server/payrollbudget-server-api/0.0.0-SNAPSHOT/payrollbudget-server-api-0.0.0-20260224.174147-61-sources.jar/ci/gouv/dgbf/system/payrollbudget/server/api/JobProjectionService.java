package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link JobProjectionDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = JobProjectionService.PATH)
@Tag(name = "Gestion des projections d'emploi")
public interface JobProjectionService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "projections-emplois";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PROJECTION_EMPLOI";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une projection d'emploi",
      description = "Ce service permet de créer une projection d'emploi")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(JobProjectionCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface JobProjectionSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link BudgetDto}.
     *
     * @return identifiant de {@link BudgetDto}
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link BudgetDto}.
     *
     * @param budgetIdentifier identifiant de {@link BudgetDto}       
     */
    void setBudgetIdentifier(String budgetIdentifier);
    
    /**
     * Cette méthode permet d'obtenir l'identifiant de unité administrative.
     *
     * @return identifiant de unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de unité administrative.
     *
     * @param administrativeUnitIdentifier identifiant de unité administrative       
     */
    void setAdministrativeUnitIdentifier(String administrativeUnitIdentifier);
    
    /**
     * Cette méthode permet d'assigner l'identifiant de emploi.
     *
     * @param employmentIdentifier identifiant de emploi       
     */
    void setJobIdentifier(String employmentIdentifier);
    
    /**
     * Cette méthode permet d'obtenir l'identifiant de emploi.
     *
     * @return identifiant de emploi
     */
    String getJobIdentifier();
    
    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    Integer getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(Integer amount);

    /**
     * Identifiant json champ identifiant de unité administrative.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        JobProjectionDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;
    
    /**
     * Identifiant json champ identifiant de {@link BudgetDto}.
     */
    String JSON_BUDGET_IDENTIFIER =
        JobProjectionDto.JSON_BUDGET_IDENTIFIER;
    
    /**
     * Identifiant json champ identifiant de l'emploi.
     */
    String JSON_JOB_IDENTIFIER =
        JobProjectionDto.JSON_JOB_IDENTIFIER;
    
    /**
     * Identifiant json champ montant.
     */
    String JSON_AMOUNT = JobProjectionDto.JSON_AMOUNT;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class JobProjectionCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements JobProjectionSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    private String budgetIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    private String jobIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    private Integer amount;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROJECTIONS_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des projections de poste de paie")
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = JobProjectionGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class JobProjectionGetManyResponseDto
      extends AbstractGetByPageResponseDto<JobProjectionDto> {

    @JsonbProperty(JSON_DATAS)
    private List<JobProjectionDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UNE_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = JobProjectionDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = JobProjectionDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une projection de poste")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(JobProjectionUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class JobProjectionUpdateRequestDto extends ByIdentifierRequestDto
      implements JobProjectionSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    private String budgetIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    private String jobIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    private Integer amount;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link JobProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
