package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de processus.
 *
 * @author Christian
 */
public interface HasProcessCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de processus.
   *
   * @return le nombre de processus
   */
  Integer getProcessCount();

  /**
   * Cette méthode permet d'assigner le nombre de processus.
   *
   * @param processCount le nombre de processus
   */
  void setProcessCount(Integer processCount);

  /**
   * Identifiant java du nombre de processus.
   */
  String FIELD_PROCESS_COUNT = "processCount";
}
