package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de lecture de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FilesGroupReadPage extends AbstractPage {

  @Inject
  FilesGroupClient client;
  
  @Getter
  FilesGroupDto group;

  @Inject
  @Getter
  FileGroupController fileGroupController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture de groupe de fichiers";
    String identifier = getRequestParameterIdentifier();
    fileGroupController.filterController.getFilter().setGroupIdentifier(identifier);
    fileGroupController.initialize();
  }
  
  public static final String OUTCOME = "filesGroupReadPage";
}
