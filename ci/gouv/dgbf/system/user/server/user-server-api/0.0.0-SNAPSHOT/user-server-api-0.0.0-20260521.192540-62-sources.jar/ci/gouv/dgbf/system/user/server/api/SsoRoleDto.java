package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


/**
 * Cette classe représente un client SSO (Single Sign-On).
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SsoRoleDto extends AbstractIdentifiableCodableDto {


  /**
   * Client.
   */
  @JsonbProperty(value = JSON_CLIENT)
  private String client;

  /**
   * Identifiant json champ {@link #client}.
   */
  public static final String JSON_CLIENT = "client";


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRoleReference";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "roleReferenceChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "role référencé";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "roles référencés";
}