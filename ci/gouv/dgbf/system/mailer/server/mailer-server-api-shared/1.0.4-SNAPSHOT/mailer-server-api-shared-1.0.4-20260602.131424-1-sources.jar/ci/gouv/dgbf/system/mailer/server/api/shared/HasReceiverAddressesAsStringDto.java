package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères des
 * adresses des destinataires.
 *
 * @author Christian
 */
public interface HasReceiverAddressesAsStringDto extends HasReceiverAddressesAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères des adresses des destinataires.
   */
  String JSON_RECEIVER_ADDRESSES_AS_STRING = "adressesDestinatairesChaine";
}
