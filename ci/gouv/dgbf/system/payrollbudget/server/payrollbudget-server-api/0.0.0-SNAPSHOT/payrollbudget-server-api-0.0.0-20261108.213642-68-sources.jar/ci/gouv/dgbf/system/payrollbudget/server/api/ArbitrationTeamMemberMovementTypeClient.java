package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamMemberMovementTypeService.ArbitrationTeamMemberMovementTypeCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamMemberMovementTypeService.ArbitrationTeamMemberMovementTypeGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du partage des types de mouvement entre membres d'équipe.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ArbitrationTeamMemberMovementTypeClient
    extends AbstractClient<ArbitrationTeamMemberMovementTypeService>
    implements GetMany<ArbitrationTeamMemberMovementTypeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ArbitrationTeamMemberMovementTypeClient service(
      ArbitrationTeamMemberMovementTypeService service) {
    return (ArbitrationTeamMemberMovementTypeClient) super.service(service);
  }

  /**
   * Confie un type de mouvement à un membre d'équipe.
   *
   * @param request le type à confier
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(ArbitrationTeamMemberMovementTypeCreateRequestDto request) {
    return new CreateExecutor(ArbitrationTeamMemberMovementTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère du partage.
   *
   * @param request critères, projection et pagination
   * @return les types confiés correspondants
   */
  public ArbitrationTeamMemberMovementTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamMemberMovementTypeGetManyResponseDto>(
        ArbitrationTeamMemberMovementTypeGetManyResponseDto.class,
        ArbitrationTeamMemberMovementTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public ArbitrationTeamMemberMovementTypeGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Retire un type de mouvement à un membre d'équipe.
   *
   * @param request l'identifiant de l'affectation à retirer
   * @return l'identifiant retiré
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(
        ArbitrationTeamMemberMovementTypeService.DELETE_IDENTIFIER)
            .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
