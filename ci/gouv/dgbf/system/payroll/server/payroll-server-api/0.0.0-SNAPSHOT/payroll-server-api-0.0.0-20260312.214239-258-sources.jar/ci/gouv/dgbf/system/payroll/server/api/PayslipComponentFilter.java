package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsAmountEqualToZero;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsCalculationMessageBlank;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsEarning;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollComponentIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayslipIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipComponentDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayslipComponentFilter extends AbstractIdentifiableFilter
    implements FilterHasIsEarning, FilterHasIsAmountEqualToZero, FilterHasPayslipIdentifier,
    FilterHasPayrollComponentIdentifier, FilterHasIsCalculationMessageBlank {

  private String payslipIdentifier;

  private String payrollComponentIdentifier;

  private Boolean isEarning;

  private Boolean isAmountEqualToZero;

  private Boolean isCalculationMessageBlank;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipComponentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipComponentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayslipIdentifier(filter);
    updatePayrollComponentIdentifier(filter);
    updateIsEarning(filter);
    updateIsAmountEqualToZero(filter);
    updateIsCalculationMessageBlank(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayslipIdentifier(filter);
    updateFilterPayrollComponentIdentifier(filter);
    updateFilterIsEarning(filter);
    updateFilterIsAmountEqualToZero(filter);
    updateFilterIsCalculationMessageBlank(filter);
  }
}
