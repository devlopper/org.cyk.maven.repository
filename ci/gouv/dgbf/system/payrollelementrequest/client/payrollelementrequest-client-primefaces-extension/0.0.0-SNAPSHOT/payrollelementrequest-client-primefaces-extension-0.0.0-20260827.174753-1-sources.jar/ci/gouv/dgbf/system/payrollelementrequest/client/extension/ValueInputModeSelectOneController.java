package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente le contrôleur de sélection du Mode de Saisie d'un Rattachement
 * (référentiel {@code TR_MODE_SAISIE}).
 *
 * @author akm
 *
 */
@Dependent
public class ValueInputModeSelectOneController extends AbstractSelectOneController {

  protected ValueInputModeSelectOneController() {
    outputLableValue = "Mode de Saisie";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem("FAE", "FAE"), new SelectItem("AGENT", "Agent"));
  }
}
