package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputNDto extends HasRemainingAmountToInputN {

  /**
   * Identifiant json du montant restant à saisir pour l'année N.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N = "montantResteASaisirN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
