package ci.gouv.dgbf.extension.primefaces.component.layout;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Column;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.Dependent;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.FilterMeta;
import org.primefaces.model.LazyDataModel;
import org.primefaces.model.SortMeta;

/**
 * Cette classe représente le contrôleur de la disposition de liste et son détail.
 *
 * @author Christian
 */
@Getter
@Setter
@Dependent
public class ListDetailLayoutController extends AbstractController {

  private Object details;

  private Class<?> detailClass;

  private String detailValueFieldName;

  private Column column;

  private String detailPageOutcome;

  private String linkValueName;

  private Function<Object, String> getDetailLinkValueFunction;

  private Consumer<FilterDto> filterConsumer;
  
  private DataTable dataTable;
  
  /**
   * Cette méthode permet de construire.
   */
  public ListDetailLayoutController() {
    column = new Column();
    detailValueFieldName = "asString";
    getDetailLinkValueFunction = Core::getAsString;
    
    dataTable = new DataTable();
    dataTable.addStylesClasses("list-detail-datatable");
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    Core.runIfStringBlank(column.getHeaderText(), () -> column
        .setHeaderText("Autres %s".formatted(Core.getHumanReadableClassPluralName(detailClass))));

    Core.runIfStringBlank(column.getFilterPlaceholder(),
        () -> column.setFilterPlaceholder("Filtrer par %s".formatted(linkValueName)));
  }

  /**
   * Cette méthode permet d'obtenir la valeur du lien du détail.
   *
   * @param detail détail
   * @return valeur du lien du détail
   */
  public String getDetailLinkValue(Object detail) {
    return Core.applyFunction(getDetailLinkValueFunction, detail);
  }


  /**
   * Cette méthode permet d'instantier details comme {@link DetailsLazyDataModel}.
   *
   * @param <T> type
   * @param clazz classe
   * @param client client
   * @param userIdentifier identifiant du l'utilisateur
   * @param projectionNames ensemble de nom de projection
   * @return {@link DetailsLazyDataModel}
   */
  public <T> DetailsLazyDataModel<T> instantiateDetailsAsLazyDataModel(Class<T> clazz,
      Object client, String userIdentifier, Set<String> projectionNames) {
    detailClass = clazz;
    DetailsLazyDataModel<T> model = new DetailsLazyDataModel<>();
    model.client = client;
    model.userIdentifier = userIdentifier;
    model.filteredValueFieldName = detailValueFieldName;
    model.filterConsumer = this.filterConsumer;
    Optional.ofNullable(projectionNames).ifPresent(names -> model.projection.addNames(names));
    details = model;
    return model;
  }
  
  /**
   * Cette méthode permet d'instantier details comme {@link DetailsLazyDataModel}.
   *
   * @param <T> type
   * @param clazz classe
   * @param client client
   * @param userIdentifier identifiant du l'utilisateur
   * @return {@link DetailsLazyDataModel}
   */
  public <T> DetailsLazyDataModel<T> instantiateDetailsAsLazyDataModel(Class<T> clazz,
      Object client, String userIdentifier) {
    return instantiateDetailsAsLazyDataModel(clazz, client, userIdentifier, null);
  }

  /**
   * Cette classe représente la classe de base de modèle de données.
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class DetailsLazyDataModel<T> extends LazyDataModel<T> {

    Object client;
    String userIdentifier;
    String filteredValueFieldName;
    
    ProjectionDto projection;
    private Consumer<FilterDto> filterConsumer;

    public DetailsLazyDataModel() {
      projection = new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
          AbstractIdentifiableDto.JSON_AS_STRING);
    }
    
    @Override
    public int count(Map<String, FilterMeta> filterBy) {
      return getRowCount();
    }

    @SuppressWarnings("unchecked")
    @Override
    public List<T> load(int first, int pageSize, Map<String, SortMeta> sortBy,
        Map<String, FilterMeta> filterBy) {
      FilterMeta filterMeta = filterBy.get(filteredValueFieldName);
      String filterValue = filterMeta == null ? null
          : Optional.ofNullable(filterMeta.getFilterValue()).map(Object::toString).orElse(null);

      FilterDto filterDto = new FilterDto().addCriteria(SearchTextFilter.JSON_KEY, filterValue);
      Core.acceptConsumer(filterConsumer, filterDto);
      
      AbstractGetByPageResponseDto<T> response =
          (AbstractGetByPageResponseDto<T>) ((GetMany<T>) client).getMany(
              projection,
              filterDto,
              new PageDto(first, pageSize), userIdentifier, null);
      setRowCount(response.getTotal().intValue());
      return (List<T>) AbstractGetByPageResponseDto.getDatas(response);
    }
  }
}
