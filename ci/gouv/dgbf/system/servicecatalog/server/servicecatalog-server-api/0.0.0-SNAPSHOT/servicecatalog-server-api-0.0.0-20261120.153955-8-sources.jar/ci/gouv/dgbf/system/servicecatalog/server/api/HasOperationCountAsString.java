package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'opérations sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasOperationCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'opérations sous forme de chaîne.
   *
   * @return le nombre d'opérations sous forme de chaîne
   */
  String getOperationCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre d'opérations sous forme de chaîne.
   *
   * @param operationCountAsString le nombre d'opérations sous forme de chaîne
   */
  void setOperationCountAsString(String operationCountAsString);

  /**
   * Identifiant java du nombre d'opérations sous forme de chaîne.
   */
  String FIELD_OPERATION_COUNT_AS_STRING = "operationCountAsString";
}
