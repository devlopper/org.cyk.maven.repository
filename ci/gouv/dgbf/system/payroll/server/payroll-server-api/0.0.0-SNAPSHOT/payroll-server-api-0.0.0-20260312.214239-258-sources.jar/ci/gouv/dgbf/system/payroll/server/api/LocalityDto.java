package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une localité.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class LocalityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link LocalityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idLocalite";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link LocalityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "localiteChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "localite";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
