package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentGroupRequestMapperImpl implements PayrollComponentGroupRequestMapper {

    @Override
    public PayrollComponentGroupService.PayrollComponentGroupCreateRequestDto mapCreate(PayrollComponentGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentGroupService.PayrollComponentGroupCreateRequestDto payrollComponentGroupCreateRequestDto = new PayrollComponentGroupService.PayrollComponentGroupCreateRequestDto();

        payrollComponentGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentGroupCreateRequestDto.setCode( arg0.getCode() );
        payrollComponentGroupCreateRequestDto.setName( arg0.getName() );

        return payrollComponentGroupCreateRequestDto;
    }

    @Override
    public PayrollComponentGroupService.PayrollComponentGroupUpdateRequestDto mapUpdate(PayrollComponentGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentGroupService.PayrollComponentGroupUpdateRequestDto payrollComponentGroupUpdateRequestDto = new PayrollComponentGroupService.PayrollComponentGroupUpdateRequestDto();

        payrollComponentGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentGroupUpdateRequestDto.setCode( arg0.getCode() );
        payrollComponentGroupUpdateRequestDto.setName( arg0.getName() );

        return payrollComponentGroupUpdateRequestDto;
    }
}
