package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.sharing.server.api.VisibilityLevel;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link VisibilityLevel}.
 *
 * @author Christian
 *
 */
@Dependent
public class VisibilityLevelSelectOneController
    extends AbstractSelectOneEnumerationController<VisibilityLevel> {

  /**
   * Cette méthode permet de construire.
   */
  protected VisibilityLevelSelectOneController() {
    super(VisibilityLevel.values());
    outputLableValue = "Niveau de visibilité";
  }
}
