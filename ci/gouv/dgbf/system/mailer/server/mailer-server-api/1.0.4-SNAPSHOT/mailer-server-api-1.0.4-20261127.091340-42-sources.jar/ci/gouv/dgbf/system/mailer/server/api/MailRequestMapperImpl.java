package ci.gouv.dgbf.system.mailer.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MailDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T09:13:17+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.20.1 (Eclipse Adoptium)"
)
@ApplicationScoped
public class MailRequestMapperImpl implements MailRequestMapper {

    @Override
    public MailService.MailCreateRequestDto mapCreate(MailDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MailService.MailCreateRequestDto mailCreateRequestDto = new MailService.MailCreateRequestDto();

        mailCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        mailCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        mailCreateRequestDto.setSubject( arg0.getSubject() );
        mailCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        mailCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        mailCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        mailCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );

        return mailCreateRequestDto;
    }

    @Override
    public MailService.MailUpdateRequestDto mapUpdate(MailDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MailService.MailUpdateRequestDto mailUpdateRequestDto = new MailService.MailUpdateRequestDto();

        mailUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        mailUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        mailUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        mailUpdateRequestDto.setSubject( arg0.getSubject() );

        return mailUpdateRequestDto;
    }
}
