package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DeviceDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class DeviceFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link DeviceDto}.
   */
  private String name;

  /**
   * Identifiant {@link DeviceDto}.
   */
  private String brand;

  /**
   * Identifiant {@link DeviceDto}.
   */
  private String model;

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public DeviceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public  DeviceFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
    brand = getBrand(filter);
    model = getModel(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
    setBrand(filter, brand);
    setModel(filter, model);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link DeviceDto}.
   *
   * @param filter         filtre
   * @param name identifiant de {@link DeviceDto}
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link DeviceDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link DeviceDto}
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link DeviceDto}.
   *
   * @param filter         filtre
   * @param brand identifiant de {@link DeviceDto}
   */
  public static void setBrand(FilterDto filter, String brand) {
    set(filter, JSON_BRAND, f -> f.getValueAsString(),
        f -> f.setValueAsString(brand));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link DeviceDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link DeviceDto}
   */
  public static String getBrand(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_BRAND));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link DeviceDto}.
   *
   * @param filter         filtre
   * @param model identifiant de {@link DeviceDto}
   */
  public static void setModel(FilterDto filter, String model) {
    set(filter, JSON_MODEL, f -> f.getValueAsString(),
        f -> f.setValueAsString(model));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link DeviceDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link DeviceDto}
   */
  public static String getModel(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_MODEL));
  }

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = DeviceDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #brand}.
   */
  public static final String JSON_BRAND = DeviceDto.JSON_BRAND;

  
  /**
   * Identifiant json champ {@link #model}.
   */
  public static final String JSON_MODEL = DeviceDto.JSON_MODEL;




}