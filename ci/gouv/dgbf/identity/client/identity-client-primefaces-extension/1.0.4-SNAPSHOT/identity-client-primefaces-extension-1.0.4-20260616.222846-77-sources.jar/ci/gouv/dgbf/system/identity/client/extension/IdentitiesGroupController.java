package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentitiesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentitiesGroupController extends AbstractController {

  @Inject
  IdentitiesGroupClient client;

  @Inject
  IdentitiesGroupRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentitiesGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialise() {
    listController.setEntityClass(IdentitiesGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentitiesGroupService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        IdentitiesGroupDto.JSON_IDENTITIES_COUNT_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(IdentitiesGroupReadPage.OUTCOME);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      IdentitiesGroupCreateRequestDto request =
          requestMapper.mapCreate((IdentitiesGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
  }
}
