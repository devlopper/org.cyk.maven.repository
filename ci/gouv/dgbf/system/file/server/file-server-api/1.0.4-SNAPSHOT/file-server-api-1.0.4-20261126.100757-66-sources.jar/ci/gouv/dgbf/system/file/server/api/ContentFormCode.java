package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link ContentForm}.
 *
 * @author Christian
 *
 */
public class ContentFormCode {

  private ContentFormCode() {

  }

  /**
   * Binaire.
   */
  public static final String BINARY = "BINAIRE";

  /**
   * Descriptif.
   */
  public static final String DESCRIPTIVE = "DESCRIPTIF";
}
