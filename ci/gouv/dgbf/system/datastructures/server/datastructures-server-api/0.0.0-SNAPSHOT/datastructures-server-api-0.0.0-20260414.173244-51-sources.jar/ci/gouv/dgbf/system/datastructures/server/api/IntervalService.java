package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IntervalDto}.
 *
 * @author Boobacool
 */
@Path(value = IntervalService.PATH)
@Tag(name = "Gestion des intervalles")
@Consumes(MediaType.APPLICATION_JSON)
@Produces(MediaType.APPLICATION_JSON)
public interface IntervalService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "intervalles";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Boobacool
   */
  interface IntervalSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le type de valeur.
     *
     * @return le type de valeur
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner le type de valeur.
     *
     * @param valueType le type de valeur
     */
    void setValueType(ValueType valueType);
    
    /**
     * Cette méthode permet d'obtenir la valeur minimale.
     *
     * @return la valeur minimale
     */
    Integer getMinValue();

    /**
     * Cette méthode permet d'assigner la valeur minimale.
     *
     * @param minValue la valeur minimale
     */
    void setMinValue(Integer minValue);

    /**
     * Cette méthode permet d'obtenir la valeur maximale.
     *
     * @return la valeur maximale
     */
    Integer getMaxValue();

    /**
     * Cette méthode permet d'assigner la valeur maximale.
     *
     * @param maxValue la valeur maximale
     */
    void setMaxValue(Integer maxValue);

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;
   
    /**
     * {@link HasMinValueDto#JSON_MIN_VALUE}.
     */
    String JSON_MIN_VALUE = HasMinValueDto.JSON_MIN_VALUE;

    /**
     * {@link HasMaxValueDto#JSON_MAX_VALUE}.
     */
    String JSON_MAX_VALUE = HasMaxValueDto.JSON_MAX_VALUE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_INTERVALLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IntervalCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Boobacool
   */
  @Getter
  @Setter
  class IntervalCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements IntervalSaveRequestDto {

    private ValueType valueType;

    private Integer minValue;

    private Integer maxValue;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_INTERVALLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IntervalGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Boobacool
   */
  @Getter
  @Setter
  public static class IntervalGetManyResponseDto extends AbstractGetByPageResponseDto<IntervalDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IntervalDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_INTERVALLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IntervalDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_INTERVALLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IntervalDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_INTERVALLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IntervalUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class IntervalUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements IntervalSaveRequestDto {

    private ValueType valueType;

    private Integer minValue;

    private Integer maxValue;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_INTERVALLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link IntervalDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
