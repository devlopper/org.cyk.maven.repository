package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.UsersGroupClient;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService.UsersGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link UsersGroupDto}.
 *
 * @author kimou
 *
 */
@Dependent
public class UsersGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    UsersGroupDto, UsersGroupGetManyResponseDto, UsersGroupClient> {

  @Inject
  @Getter
  UsersGroupClient client;

  /**
   * Cette methode permet de construire.
   */
  protected UsersGroupSelectOneController() {
    super(UsersGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
