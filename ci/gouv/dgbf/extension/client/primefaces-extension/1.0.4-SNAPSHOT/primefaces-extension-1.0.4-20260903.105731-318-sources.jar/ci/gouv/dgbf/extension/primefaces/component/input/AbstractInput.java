package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.Ajax;
import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import ci.gouv.dgbf.extension.primefaces.component.Message;
import ci.gouv.dgbf.extension.primefaces.component.OutputLabel;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'un champ de saisie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInput<T> extends AbstractWidget {

  T value;
  Boolean required;
  Boolean disabled = false;

  Consumer<T> valueConsumer;
  Supplier<Object> objectSupplier;
  String fieldName;

  OutputLabel outputLabel;
  String icon;


  Message message;
  
  Ajax valueChangeAjax;

  protected AbstractInput() {
    /*
     * Null value not supported so instantiation needed.
     */
    valueChangeAjax();
    
    /*
     * Null value not supported so instantiation needed.
     */
    message();
  }

  /**
   * Cette méthode permet d'obtenir une valeur non nulle.
   *
   * @return valeur non nulle
   */
  public Ajax valueChangeAjax() {
    if (valueChangeAjax == null) {
      valueChangeAjax = new Ajax();
      valueChangeAjax.setDisabled(true);
    }
    return valueChangeAjax;
  }

  public AbstractInput<T> writeValue(T value) {
    this.value = value;
    return this;
  }

  public AbstractInput<T> writeValueAsObject(Object value) {
    Core.setFieldValue(this, Core.getField(AbstractInput.class, FIELD_VALUE), value);
    return this;
  }

  /**
   * Cette méthode permet d'obtenir un {@link OutputLabel} non nul.
   *
   * @return {@link OutputLabel}
   */
  public OutputLabel outputLabel() {
    if (outputLabel == null) {
      outputLabel = new OutputLabel();
      outputLabel.setForId(getIdentifier());
    }
    return outputLabel;
  }
  
  /**
   * Cette méthode permet d'obtenir un {@link Message} non nul.
   *
   * @return {@link Message}
   */
  public Message message() {
    if (message == null) {
      message = new Message();
      message.setForId(getIdentifier());
    }
    return message;
  }

  /**
   * Cette méthode permet d'ajouter des consommateurs de valeur.
   *
   * @param consumers consommateurs
   */
  @SuppressWarnings("unchecked")
  public AbstractInput<T> addValueConsumers(Consumer<T>... consumers) {
    valueConsumer = Core.combineConsumersTo(valueConsumer, consumers);
    return this;
  }

  @SuppressWarnings("unchecked")
  public AbstractInput<T> addValueConsumer(Consumer<T> consumer) {
    return addValueConsumers(consumer);
  }

  /**
   * Cette méthode permet d'assigner une valeur.
   *
   * @param value valeur
   */
  public void setValue(T value) {
    this.value = value;
    writeObjectFieldValue();
    Core.runIfNotNull(valueConsumer, () -> valueConsumer.accept(value));
  }

  boolean writeObjectFieldValue() {
    if (objectSupplier == null || Core.isStringBlank(fieldName)) {
      return false;
    }
    Object object = objectSupplier.get();
    if (Objects.isNull(object)) {
      return false;
    }
    Core.setFieldValue(object, Core.getField(object.getClass(), fieldName), value);
    return true;
  }

  public static final String FIELD_VALUE = "value";
}
