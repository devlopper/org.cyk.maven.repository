package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.RevenueService.RevenueCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.RevenueService.RevenueUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RevenueDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link RevenueDto}.

    @author Christian
               """)
public interface RevenueRequestMapper
    extends RequestMapper<RevenueDto, RevenueCreateRequestDto,
        RevenueUpdateRequestDto> {

}
