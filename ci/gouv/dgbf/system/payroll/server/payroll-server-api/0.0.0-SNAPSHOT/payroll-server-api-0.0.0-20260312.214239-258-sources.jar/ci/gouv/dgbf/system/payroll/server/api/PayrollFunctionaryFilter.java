package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollFunctionaryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayrollFunctionaryFilter extends AbstractIdentifiableFilter {

  /**
   * Matricule.
   */
  private String registrationNumber;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollFunctionaryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollFunctionaryFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    registrationNumber = getRegistrationNumber(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setRegistrationNumber(filter, registrationNumber);
  }

  /**
   * Cette méthode permet d'assigner le matricule.
   *
   * @param filter filtre
   * @param registrationNumber matricule
   */
  public static void setRegistrationNumber(FilterDto filter, String registrationNumber) {
    set(filter, JSON_REGISTRATION_NUMBER, f -> f.getValueAsString(),
        f -> f.setValueAsString(registrationNumber));
  }

  /**
   * Cette méthode permet d'obtenir le matricule.
   *
   * @param filter filtre
   * @return matricule
   */
  public static String getRegistrationNumber(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER));
  }

  /**
   * Identifiant json champ {@link PayrollFunctionaryFilter#registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER =
      PayrollFunctionaryDto.JSON_REGISTRATION_NUMBER;

}
