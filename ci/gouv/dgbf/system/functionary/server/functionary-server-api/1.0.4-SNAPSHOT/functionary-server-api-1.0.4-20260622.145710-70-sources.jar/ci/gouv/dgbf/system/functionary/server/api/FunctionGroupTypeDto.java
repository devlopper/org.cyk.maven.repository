package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de fonctions.
 *
 * @author Boobacool
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionGroupTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeGroupeFonction";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "typeGroupeFonctionChaine";


  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type groupe fonction";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types groupes fonction";
}
