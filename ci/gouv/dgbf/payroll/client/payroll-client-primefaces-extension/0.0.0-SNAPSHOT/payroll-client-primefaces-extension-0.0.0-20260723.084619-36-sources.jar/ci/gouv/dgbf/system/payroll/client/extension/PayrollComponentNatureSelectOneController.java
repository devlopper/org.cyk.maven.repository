package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentNatureClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentNatureDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentNatureService.PayrollComponentNatureGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollComponentNatureDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollComponentNatureSelectOneController 
    extends AbstractSelectOneIdentifiableController<PayrollComponentNatureDto, 
    PayrollComponentNatureGetManyResponseDto, PayrollComponentNatureClient> {

  @Getter
  @Inject
  PayrollComponentNatureClient client;

  protected PayrollComponentNatureSelectOneController() {
    super(PayrollComponentNatureDto.class, SelectItemLabelStrategy.NAME);
  }
}
