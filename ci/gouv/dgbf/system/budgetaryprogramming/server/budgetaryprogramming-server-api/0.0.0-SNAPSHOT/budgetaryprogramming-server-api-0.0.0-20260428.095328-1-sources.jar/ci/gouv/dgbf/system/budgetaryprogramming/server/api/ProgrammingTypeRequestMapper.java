package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingTypeService.ProgrammingTypeCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingTypeService.ProgrammingTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingTypeDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingTypeDto}.

    @author Christian
               """)
public interface ProgrammingTypeRequestMapper
    extends RequestMapper<ProgrammingTypeDto, ProgrammingTypeCreateRequestDto,
        ProgrammingTypeUpdateRequestDto> {

}
