package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/**
 * Cette classe met en forme une taille en octets pour l'affichage : unité lisible (o, Ko, Mo, Go,
 * base 1024), virgule décimale française, une décimale au plus au-delà du kilo-octet.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class FileSizeFormatter {

  private static final String[] UNITS = {"o", "Ko", "Mo", "Go"};

  private static final int BASE = 1024;

  /**
   * Met en forme une taille reçue déjà en chaîne (projection {@code nombreOctetsChaine} du serveur,
   * chiffres séparés par des espaces : « 114 810 »).
   *
   * @param numberOfBytesAsString taille en octets, chiffres éventuellement groupés
   * @return taille lisible, ou la chaîne reçue telle quelle si elle ne contient aucun chiffre
   */
  public String formatDigits(String numberOfBytesAsString) {
    if (numberOfBytesAsString == null) {
      return null;
    }
    String digits = numberOfBytesAsString.replaceAll("\\D", "");
    return digits.isEmpty() ? numberOfBytesAsString : format(Long.valueOf(digits));
  }

  /**
   * Met en forme une taille.
   *
   * @param numberOfBytes taille en octets
   * @return taille lisible (ex. « 112 Ko », « 1,4 Mo »), ou {@code null} si la taille est absente
   */
  public String format(Number numberOfBytes) {
    if (numberOfBytes == null) {
      return null;
    }
    double value = numberOfBytes.doubleValue();
    int unit = 0;
    while (value >= BASE && unit < UNITS.length - 1) {
      value /= BASE;
      unit++;
    }
    DecimalFormat format = new DecimalFormat(unit == 0 ? "0" : "0.#",
        DecimalFormatSymbols.getInstance(Locale.FRANCE));
    return format.format(value) + " " + UNITS[unit];
  }
}
