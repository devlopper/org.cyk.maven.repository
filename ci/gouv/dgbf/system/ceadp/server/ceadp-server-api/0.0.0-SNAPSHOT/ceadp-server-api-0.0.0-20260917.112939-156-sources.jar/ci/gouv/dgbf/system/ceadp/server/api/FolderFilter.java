package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FolderDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FolderFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link AdministrativeUnitDto}.
   */
  String administrativeUnitIdentifier;

  /**
   * Identifiant de {@link FolderTypeDto}.
   */
  String typeIdentifier;

  /**
   * Identifiant de {@link FolderPriorityDto}.
   */
  String priorityIdentifier;

  /**
   * Identifiant {@link IdentityDto}.
   */
  String identityIdentifier;

  /**
   * Nom {@link UserDto}.
   */
  String userName;

  /**
   * Code {@link FolderChart}.
   */
  String chartCode;

  /**
   * Code statut.
   */
  String statusCode;

  /**
   * Est en retard.
   */
  Boolean isLate;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FolderFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FolderFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    typeIdentifier = getTypeIdentifier(filter);
    priorityIdentifier = getPriorityIdentifier(filter);
    identityIdentifier = getIdentityIdentifier(filter);
    userName = getUserName(filter);
    chartCode = getChartCode(filter);
    statusCode = getStatusCode(filter);
    isLate = getIsLate(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
    setPriorityIdentifier(filter, priorityIdentifier);
    setIdentityIdentifier(filter, identityIdentifier);
    setUserName(filter, userName);
    setChartCode(filter, chartCode);
    setStatusCode(filter, statusCode);
    setIsLate(filter, isLate);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité administrative.
   *
   * @param filter filtre
   * @return identifiant de l'unité administrative
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'unité administrative.
   *
   * @param filter filtre
   * @param identifier identifiant de l'unité administrative
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FolderTypeDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FolderTypeDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FolderTypeDto}
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FolderPriorityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPriorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PRIORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FolderPriorityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FolderTypeDto}
   */
  public static String getPriorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PRIORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité.
   *
   * @param filter filtre
   * @return identifiant de l'identité
   */
  public static String getIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setIdentityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir le nom d'utilisateur.
   *
   * @param filter filtre
   * @return nom d'utilisateur
   */
  public static String getUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom d'utilisateur.
   *
   * @param filter filtre
   * @param userName nom d'utilisateur
   */
  public static void setUserName(FilterDto filter, String userName) {
    set(filter, JSON_USER_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'obtenir {@link FolderChartCode}.
   *
   * @param filter filtre
   * @return {@link FolderChartCode}
   */
  public static String getChartCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHART_CODE));
  }

  /**
   * Cette méthode permet d'assigner {@link FolderChartCode}.
   *
   * @param filter filtre
   * @param chartCode {@link FolderChartCode}
   */
  public static void setChartCode(FilterDto filter, String chartCode) {
    set(filter, JSON_CHART_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(chartCode));
  }
  
  /**
   * Cette méthode permet d'obtenir le code statut.
   *
   * @param filter filtre
   * @return code statut
   */
  public static String getStatusCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code statut.
   *
   * @param filter filtre
   * @param statusCode code statut
   */
  public static void setStatusCode(FilterDto filter, String statusCode) {
    set(filter, JSON_STATUS_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(statusCode));
  }

  /**
   * Cette méthode permet d'obtenir est en retard.
   *
   * @param filter filtre
   * @return est en retard
   */
  public static Boolean getIsLate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LATE));
  }

  /**
   * Cette méthode permet d'assigner est en retard.
   *
   * @param filter filtre
   * @param isLate est en retard
   */
  public static void setIsLate(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_LATE, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isLate));
  }


  /**
   * Identifiant json champ {@link FolderFilter#administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      FolderDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json champ {@link FolderFilter#typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = FolderDto.JSON_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link FolderFilter#typeIdentifier}.
   */
  public static final String JSON_PRIORITY_IDENTIFIER = FolderDto.JSON_PRIORITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link FolderFilter#identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = IdentityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #userName}.
   */
  public static final String JSON_USER_NAME = UserDto.JSON_THIS_NAME;

  /**
   * Identifiant json champ {@link #chartCode}.
   */
  public static final String JSON_CHART_CODE = "codeGraphique";
  
  /**
   * Identifiant json champ {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "codeStatut";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = FolderDto.JSON_IS_LATE;

}
