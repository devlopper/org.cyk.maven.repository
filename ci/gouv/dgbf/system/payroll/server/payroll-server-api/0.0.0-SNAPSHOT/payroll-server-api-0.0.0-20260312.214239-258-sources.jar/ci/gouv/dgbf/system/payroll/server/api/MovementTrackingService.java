package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link MovementTrackingDto}.
 *
 * @author A.K.M
 *
 */
@Path(value = MovementTrackingService.PATH)
@Tag(name = "Gestion des suivis de mouvements")
public interface MovementTrackingService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "suivis-mouvements";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author A.K.M
   *
   */
  interface MovementTrackingSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir la date d'effet.
     *
     * @return date d'effet
     */
    LocalDate getEffectDate();

    /**
     * Cette méthode permet d'assigner la date d'effet.
     *
     * @param effectDate date d'effet
     */
    void setEffectDate(LocalDate effectDate);

    /**
     * Cette méthode permet d'obtenir la date de prise en compte.
     *
     * @return date de prise en compte
     */
    LocalDate getDateTakeInCounts();

    /**
     * Cette méthode permet d'assigner la date de prise en compte.
     *
     * @param dateTakeInCounts date de prise en compte
     */
    void setDateTakeInCounts(LocalDate dateTakeInCounts);

    /**
     * Cette méthode permet d'obtenir la date d'effet.
     *
     * @return date de rappel
     */
    LocalDate getDateReminder();

    /**
     * Cette méthode permet d'assigner le statut.
     *
     * @param status statut
     */
    void setStatus(MovementStatus status);

    /**
     * Cette méthode permet d'obtenir le statut.
     *
     * @return statut
     */
    MovementStatus getStatus();

    /**
     * Cette méthode permet d'assigner la date de rappel.
     *
     * @param dateReminder date de rappel
     */
    void setDateReminder(LocalDate dateReminder);

    /**
     * {@link MovementTrackingDto#JSON_EFFECT_DATE}.
     */
    public static final String JSON_EFFECT_DATE = MovementTrackingDto.JSON_EFFECT_DATE;

    /**
     * {@link MovementTrackingDto#JSON_DATE_TAKEN_IN_COUNTS}.
     */
    public static final String JSON_DATE_TAKEN_IN_COUNTS = 
                              MovementTrackingDto.JSON_DATE_TAKEN_IN_COUNTS;

    /**
     * {@link MovementTrackingDto#JSON_DATE_REMINDER_AS_STRING}.
     */
    public static final String JSON_DATE_REMINDER_AS_STRING = 
                                  MovementTrackingDto.JSON_DATE_REMINDER_AS_STRING;

    /**
     * {@link MovementTrackingDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = 
                                  MovementTrackingDto.JSON_STATUS;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SUIVI_MOUVEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MovementTrackingCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class MovementTrackingCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements MovementTrackingSaveRequestDto {
    /**
     * {@link MovementTrackingDto#getEffectDate()}.
     */
    @JsonbProperty(JSON_EFFECT_DATE)
    private LocalDate effectDate;
    /**
     * {@link MovementTrackingDto#getDateTakeInCounts()}.
     */
    @JsonbProperty(JSON_DATE_TAKEN_IN_COUNTS)
    private LocalDate dateTakeInCounts;
    /**
     * {@link MovementTrackingDto#getDateTakeInCounts()}.
     */
    @JsonbProperty(JSON_DATE_REMINDER_AS_STRING)
    private LocalDate dateReminder;
    /**
     * {@link MovementTrackingDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private MovementStatus status;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SUIVI_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = 
                                      MovementTrackingGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  public static class MovementTrackingGetManyResponseDto extends AbstractGetByPageResponseDto<
                        MovementTrackingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MovementTrackingDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SUIVI_MOUVEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementTrackingDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SUIVI_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementTrackingDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SUIVI_MOUVEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(MovementTrackingUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class MovementTrackingUpdateRequestDto extends ByIdentifierRequestDto
      implements MovementTrackingSaveRequestDto {
    /**
     * {@link MovementTrackingDto#getEffectDate()}.
     */
    @JsonbProperty(JSON_EFFECT_DATE)
    private LocalDate effectDate;
    /**
     * {@link MovementTrackingDto#getDateTakeInCounts()}.
     */
    @JsonbProperty(JSON_DATE_TAKEN_IN_COUNTS)
    private LocalDate dateTakeInCounts;
    /**
     * {@link MovementTrackingDto#getDateTakeInCounts()}.
     */
    @JsonbProperty(JSON_DATE_REMINDER_AS_STRING)
    private LocalDate dateReminder;
    /**
     * {@link MovementTrackingDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private MovementStatus status;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SUIVI_MOUVEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link MovementTrackingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
  
  
}
