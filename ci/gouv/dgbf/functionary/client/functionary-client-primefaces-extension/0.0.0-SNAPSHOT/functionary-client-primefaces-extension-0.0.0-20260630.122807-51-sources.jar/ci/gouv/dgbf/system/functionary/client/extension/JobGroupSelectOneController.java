package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupClient;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link JobGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class JobGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    JobGroupDto, JobGroupGetManyResponseDto, JobGroupClient> {

  @Getter
  @Inject
  JobGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected JobGroupSelectOneController() {
    super(JobGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
