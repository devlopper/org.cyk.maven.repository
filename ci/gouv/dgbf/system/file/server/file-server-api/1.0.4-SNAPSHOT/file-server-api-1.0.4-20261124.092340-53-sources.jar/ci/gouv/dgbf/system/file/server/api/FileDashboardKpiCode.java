package ci.gouv.dgbf.system.file.server.api;

/**
 * Codes des indicateurs du dataset {@link FileDashboardChartCode#KPIS}, dans l'ordre
 * actionnable-en-premier de RG_FILE_UI_05 : l'indicateur qui appelle une action passe en
 * premier, l'attention baisse de gauche à droite.
 *
 * @author Christian
 *
 */
public interface FileDashboardKpiCode {

  /**
   * Demandes d'archivage en attente (statut {@code CREE}).
   */
  String PENDING_SOLICITATIONS = "DEMANDES_EN_ATTENTE";

  /**
   * Éléments éligibles à la purge, calculés et autorisés par le service métier de purge.
   */
  String PURGE_ELIGIBLE = "PURGE_ELIGIBLE";

  /**
   * Fichiers de groupe archivés (Archive applicable, {@code DATE_FIN IS NULL}).
   */
  String ARCHIVED_GROUP_FILES = "FICHIERS_GROUPE_ARCHIVES";

  /**
   * Fichiers de groupe (rattachements Fichier/Groupe de fichiers).
   */
  String GROUP_FILES = "FICHIERS_GROUPE";

  /**
   * Groupes de fichiers.
   */
  String FILE_GROUPS = "GROUPES_FICHIERS";

  /**
   * Fichiers.
   */
  String FILES = "FICHIERS";
}
