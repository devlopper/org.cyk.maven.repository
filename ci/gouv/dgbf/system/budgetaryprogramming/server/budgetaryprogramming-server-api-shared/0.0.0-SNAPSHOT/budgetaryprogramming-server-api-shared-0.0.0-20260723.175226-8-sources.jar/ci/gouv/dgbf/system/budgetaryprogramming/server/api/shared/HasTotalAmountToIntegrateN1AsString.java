package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateN1AsString {

  /**
   * Obtient le montant total à intégrer pour l'année N+1 sous forme de chaîne de caractères.
   *
   * @return le montant total à intégrer pour l'année N+1 sous forme de chaîne de caractères
   */
  String getTotalAmountToIntegrateN1AsString();

  /**
   * Définit le montant total à intégrer pour l'année N+1 sous forme de chaîne de caractères.
   *
   * @param totalAmountToIntegrateN1AsString le montant total à intégrer pour l'année N+1
   *        sous forme de chaîne de caractères
   */
  void setTotalAmountToIntegrateN1AsString(String totalAmountToIntegrateN1AsString);

  /**
   * Identifiant java du montant total à intégrer pour l'année N+1 sous forme de chaîne.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N1_AS_STRING =
      "totalAmountToIntegrateN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName