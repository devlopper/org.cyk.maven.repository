package ci.gouv.dgbf.extension.primefaces.error;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page d'erreur de code 500.
 *
 * @author Christian
 *
 */
@Named
@RequestScoped
public class Error500Page extends AbstractPage {

  public Error500Page() {
    title = "Erreur";
    contentTitle = "Erreur";
  }
  
}
