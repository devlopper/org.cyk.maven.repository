package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.IntervalService.IntervalCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.IntervalService.IntervalUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IntervalDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IntervalDto}.

    @author Christian
               """)
public interface IntervalRequestMapper
    extends RequestMapper<IntervalDto, IntervalCreateRequestDto, IntervalUpdateRequestDto> {

}
