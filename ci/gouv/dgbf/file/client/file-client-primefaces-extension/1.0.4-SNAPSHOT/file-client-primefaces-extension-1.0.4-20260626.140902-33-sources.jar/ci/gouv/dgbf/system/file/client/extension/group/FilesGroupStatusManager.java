package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.file.server.api.FilesGroupStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link FilesGroupStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class FilesGroupStatusManager extends AbstractStatusManager<FilesGroupStatus> {

  /**
   * Cette méthode permet d'instanctier.
   */
  public FilesGroupStatusManager() {
    super(FilesGroupStatus.class, e -> e.getName());
  }
}
