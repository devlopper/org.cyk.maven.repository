package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DictionaryEntryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T08:22:18+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DictionaryEntryRequestMapperImpl implements DictionaryEntryRequestMapper {

    @Override
    public DictionaryEntryService.DictionaryEntryCreateRequestDto mapCreate(DictionaryEntryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryEntryService.DictionaryEntryCreateRequestDto dictionaryEntryCreateRequestDto = new DictionaryEntryService.DictionaryEntryCreateRequestDto();

        dictionaryEntryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        dictionaryEntryCreateRequestDto.setCode( arg0.getCode() );
        dictionaryEntryCreateRequestDto.setName( arg0.getName() );
        dictionaryEntryCreateRequestDto.setDictionaryIdentifier( arg0.getDictionaryIdentifier() );
        dictionaryEntryCreateRequestDto.setValueType( arg0.getValueType() );
        dictionaryEntryCreateRequestDto.setDefaultValue( arg0.getDefaultValue() );
        dictionaryEntryCreateRequestDto.setMinOccurrences( arg0.getMinOccurrences() );
        dictionaryEntryCreateRequestDto.setMaxOccurrences( arg0.getMaxOccurrences() );
        dictionaryEntryCreateRequestDto.setOrder( arg0.getOrder() );
        dictionaryEntryCreateRequestDto.setMinLength( arg0.getMinLength() );
        dictionaryEntryCreateRequestDto.setMaxLength( arg0.getMaxLength() );
        dictionaryEntryCreateRequestDto.setMinValue( arg0.getMinValue() );
        dictionaryEntryCreateRequestDto.setMaxValue( arg0.getMaxValue() );
        dictionaryEntryCreateRequestDto.setPattern( arg0.getPattern() );
        List<String> list = arg0.getAllowedValues();
        if ( list != null ) {
            dictionaryEntryCreateRequestDto.setAllowedValues( new ArrayList<String>( list ) );
        }
        dictionaryEntryCreateRequestDto.setPrecision( arg0.getPrecision() );
        dictionaryEntryCreateRequestDto.setScale( arg0.getScale() );

        return dictionaryEntryCreateRequestDto;
    }

    @Override
    public DictionaryEntryService.DictionaryEntryUpdateRequestDto mapUpdate(DictionaryEntryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryEntryService.DictionaryEntryUpdateRequestDto dictionaryEntryUpdateRequestDto = new DictionaryEntryService.DictionaryEntryUpdateRequestDto();

        dictionaryEntryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        dictionaryEntryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        dictionaryEntryUpdateRequestDto.setCode( arg0.getCode() );
        dictionaryEntryUpdateRequestDto.setName( arg0.getName() );
        dictionaryEntryUpdateRequestDto.setDictionaryIdentifier( arg0.getDictionaryIdentifier() );
        dictionaryEntryUpdateRequestDto.setValueType( arg0.getValueType() );
        dictionaryEntryUpdateRequestDto.setDefaultValue( arg0.getDefaultValue() );
        dictionaryEntryUpdateRequestDto.setMinOccurrences( arg0.getMinOccurrences() );
        dictionaryEntryUpdateRequestDto.setMaxOccurrences( arg0.getMaxOccurrences() );
        dictionaryEntryUpdateRequestDto.setOrder( arg0.getOrder() );
        dictionaryEntryUpdateRequestDto.setMinLength( arg0.getMinLength() );
        dictionaryEntryUpdateRequestDto.setMaxLength( arg0.getMaxLength() );
        dictionaryEntryUpdateRequestDto.setMinValue( arg0.getMinValue() );
        dictionaryEntryUpdateRequestDto.setMaxValue( arg0.getMaxValue() );
        dictionaryEntryUpdateRequestDto.setPattern( arg0.getPattern() );
        List<String> list = arg0.getAllowedValues();
        if ( list != null ) {
            dictionaryEntryUpdateRequestDto.setAllowedValues( new ArrayList<String>( list ) );
        }
        dictionaryEntryUpdateRequestDto.setPrecision( arg0.getPrecision() );
        dictionaryEntryUpdateRequestDto.setScale( arg0.getScale() );

        return dictionaryEntryUpdateRequestDto;
    }
}
