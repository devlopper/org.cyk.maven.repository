package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityGroupFilterController extends AbstractFilterController<IdentityGroupFilter> {

  /**
   * Cette méthode permet d'instantier.
   */
  public IdentityGroupFilterController() {
    super(IdentityGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setIdentityIdentifier(getRequestParameter(IdentityGroupFilter.JSON_IDENTITY_IDENTIFIER));
    filter.setGroupIdentifier(getRequestParameter(IdentityGroupFilter.JSON_GROUP_IDENTIFIER));
  }
}

