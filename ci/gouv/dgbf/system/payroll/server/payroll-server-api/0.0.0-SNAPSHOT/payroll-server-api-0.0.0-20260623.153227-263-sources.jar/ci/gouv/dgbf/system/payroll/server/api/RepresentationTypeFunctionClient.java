package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationTypeFunctionService.RepresentationTypeFunctionCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationTypeFunctionService.RepresentationTypeFunctionGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationTypeFunctionService.RepresentationTypeFunctionUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un modèle de paie.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class RepresentationTypeFunctionClient extends 
    AbstractClient<RepresentationTypeFunctionService>
    implements GetByIdentifier<RepresentationTypeFunctionDto>, 
    GetMany<RepresentationTypeFunctionGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public RepresentationTypeFunctionClient service(RepresentationTypeFunctionService service) {
    return (RepresentationTypeFunctionClient) super.service(service);
  }

  /**
   * {@link RepresentationTypeFunctionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(RepresentationTypeFunctionCreateRequestDto request) {
    return new CreateExecutor(RepresentationTypeFunctionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RepresentationTypeFunctionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RepresentationTypeFunctionGetManyResponseDto>(
        RepresentationTypeFunctionGetManyResponseDto.class, 
            RepresentationTypeFunctionService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RepresentationTypeFunctionGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RepresentationTypeFunctionService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public RepresentationTypeFunctionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<RepresentationTypeFunctionDto>(RepresentationTypeFunctionDto.class,
        RepresentationTypeFunctionService.GET_ONE_IDENTIFIER).execute(() -> service()
            .getOne(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RepresentationTypeFunctionDto getOne(ProjectionDto projection, FilterDto filter, 
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link RepresentationTypeFunctionService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public RepresentationTypeFunctionDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<RepresentationTypeFunctionDto>(RepresentationTypeFunctionDto.class,
        RepresentationTypeFunctionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RepresentationTypeFunctionDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link RepresentationTypeFunctionService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(RepresentationTypeFunctionUpdateRequestDto request) {
    return new IdentifiableExecutor(RepresentationTypeFunctionService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(RepresentationTypeFunctionService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link RepresentationTypeFunctionService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
