package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sous unité administrative.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SubAdministrativeUnitDto extends AbstractIdentifiableCodableNamableAuditableDto {
  
  /**
   * Identifiant {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;
  
  /**
   * Identifiant {@link #type}.
   */
  @JsonbProperty(JSON_TYPE)
  private SubAdministrativeUnitType type;
  
  /**
   * Représentation en chaine de caractères de {@link #type}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;
  
  /**
   * Identifiant json de identifiant de {@link SubAdministrativeUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSousUniteAdministrative";

  /**
   * Identifiant json de représentation en chaine de caractères de 
   * {@link SubAdministrativeUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "sousUniteAdministrativeChaine";
  
  /**
   * Identifiant json de identifiant de {@link AdministrativeUnitDto}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = AdministrativeUnitDto
      .JSON_THIS_IDENTIFIER;
  
  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitDto}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = AdministrativeUnitDto
      .JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json de {@link #type}.
   */
  public static final String JSON_TYPE = "type";
  
  /**
   * Représentation en chaine de caractères de {@link #type}.
   */
  public static final String JSON_TYPE_AS_STRING = "typeChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "sous-unité administrative";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sous-unités administratives";
  
}
