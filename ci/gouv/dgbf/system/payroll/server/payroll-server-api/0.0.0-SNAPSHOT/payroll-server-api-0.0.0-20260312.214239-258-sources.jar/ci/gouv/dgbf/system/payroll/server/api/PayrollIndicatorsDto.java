package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette interface représente des indicateurs de {@link PayrollDto}.
 *
 * @author Christian
 */
public interface PayrollIndicatorsDto extends PayrollIndicators {

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} actifs.
   */
  String JSON_ENABLED_REMUNERABLE_COUNT_AS_STRING = "nombreRemunerableActifsChaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} non actifs.
   */
  String JSON_DISABLED_REMUNERABLE_COUNT_AS_STRING = "nombreRemunerableNonActifsChaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} créés.
   */
  String JSON_CREATED_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieCreeChaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à créer.
   */
  String JSON_CREATABLE_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieCreableChaine";
  
  /**
   * Identifiant json du nombre de
   * {@link PayslipDto} calculable.
   */
  String JSON_CALCULABLE_PAYSLIP_COUNT = "nombreBulletinPaieCalculable";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculable.
   */
  String JSON_CALCULABLE_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieCalculableChaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} non calculable.
   */
  String JSON_NON_CALCULABLE_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieNonCalculableChaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculé.
   */
  String JSON_CALCULATED_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieCalculeChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à contrôler.
   */
  String JSON_PAYSLIP_TO_CONTROL_COUNT_AS_STRING = "nombreBulletinPaieAControlerChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} contrôlé.
   */
  String JSON_PAYSLIP_CONTROLLED_COUNT_AS_STRING = "nombreBulletinPaieControleChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} accepté.
   */
  String JSON_PAYSLIP_ACCEPTED_COUNT_AS_STRING = "nombreBulletinPaieAccepteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} validé.
   */
  String JSON_PAYSLIP_VALIDATED_COUNT_AS_STRING = "nombreBulletinPaieValideChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} au contentieux.
   */
  String JSON_PAYSLIP_TO_LITIGATION_COUNT_AS_STRING = "nombreBulletinPaieAuContentieuxChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} quotité.
   */
  String JSON_PAYSLIP_QUOTA_COUNT_AS_STRING = "nombreBulletinPaieQuotiteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto}.
   */
  String JSON_PAYSLIP_COUNT_AS_STRING = "nombreBulletinPaieChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à calculer.
   */
  String JSON_PAYSLIP_TO_CALCULATE_COUNT_AS_STRING = "nombreBulletinPaieACalculerChaine";
}
