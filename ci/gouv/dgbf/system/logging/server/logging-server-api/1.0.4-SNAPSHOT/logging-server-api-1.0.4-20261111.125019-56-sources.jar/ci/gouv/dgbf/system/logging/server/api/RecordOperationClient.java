package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationService.RecordOperationCreateRequestDto;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationService.RecordOperationGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link RecordOperationService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class RecordOperationClient extends AbstractClient<RecordOperationService>
    implements GetByIdentifier<RecordOperationDto>, GetMany<RecordOperationGetManyResponseDto> {

  private static final Logger LOGGER = Logger.getLogger(RecordOperationClient.class.getName());

  @Override
  public RecordOperationClient service(RecordOperationService service) {
    return (RecordOperationClient) super.service(service);
  }

  void setProcessIdentifier(RecordOperationCreateRequestDto request) {
    if (request != null && Core.isStringBlank(request.getProcessIdentifier())) {
      request.setProcessIdentifier(callerIdentifier());
    }
  }

  /**
   * {@link RecordOperationService#create}.
   *
   * <p>Permet à un microservice DGBF d'émettre l'acte métier principal d'une interaction
   * utilisateur (RG_LOG_TRA_13). Exemple type d'utilisation :</p>
   * <pre>{@code
   * RecordOperationCreateRequestDto request = new RecordOperationCreateRequestDto();
   * request.setSource("TA_DOSSIER");
   * request.setRecord(dossierId);
   * request.setOperation("VALIDATION");
   * request.setAuditFunctionality("Gestion de la dépense");
   * request.setAuditWho(securityContext.getUserIdentifier());
   * request.setAuditSession(securityContext.getAuditSession());
   * client.create(request);
   * }</pre>
   *
   * @param request requête d'enregistrement de l'opération
   * @return réponse de création
   */
  public CreateResponseDto create(RecordOperationCreateRequestDto request) {
    CreateResponseDto response;
    if (Boolean.TRUE.equals(disabled)) {
      response = null;
      LOGGER.log(Level.CONFIG,
          "Client {0} désactivé. Impossible de créer une opération d''enregistrement.",
          serviceIdentifier());
    } else {
      setProcessIdentifier(request);
      response = new CreateExecutor(RecordOperationService.CREATE_IDENTIFIER)
          .setExceptionThrowable(Boolean.FALSE).execute(() -> service().create(request));
    }
    return response;
  }

  /**
   * {@link RecordOperationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RecordOperationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RecordOperationGetManyResponseDto>(
        RecordOperationGetManyResponseDto.class, RecordOperationService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link RecordOperationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RecordOperationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RecordOperationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public RecordOperationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<RecordOperationDto>(RecordOperationDto.class,
        RecordOperationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link RecordOperationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RecordOperationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link RecordOperationService#getByIdentifier}.
   *
   * @param request requête
   * @return opération d'enregistrement
   */
  public RecordOperationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<RecordOperationDto>(RecordOperationDto.class,
        RecordOperationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link RecordOperationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RecordOperationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

}
