package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.servlet.http.HttpSessionEvent;
import java.time.Year;

/**
 * Cette interface représente la base d'écouteur d'évènement de session web.
 *
 * @author Christian
 *
 */
public interface SharingSessionListener {

  /**
   * Cette méthode permet de mettre la ressource en session.
   *
   * @param event {@link HttpSessionEvent}
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   * @param resource {@link ResourceDto}
   */
  default void setResource(HttpSessionEvent event, ResourceType resourceType, Location location,
      ResourceDto resource) {
    SharingSessionController.setAttributeResource(event.getSession(), resourceType, location,
        resource);
  }

  /**
   * Cette méthode permet de mettre l'exercice commen étant l'année actuelle en session.
   *
   * @param event {@link HttpSessionEvent}
   */
  default void setExerciseResourceAsNowYear(HttpSessionEvent event) {
    ResourceDto resource = new ResourceDto();
    resource.setReference(String.valueOf(Year.now().getValue()));
    resource.setAsString(resource.getReference());
    setResource(event, ResourceType.EXERCISE, Location.BUDGETARY_CLASSIFICATION, resource);
  }
}
