package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentService.SupportingDocumentCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentService.SupportingDocumentGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des pièces justificatives.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupportingDocumentClient
    extends AbstractClient<SupportingDocumentService>
    implements OneRetrievable<SupportingDocumentDto>,
    GetByIdentifier<SupportingDocumentDto>,
    GetMany<SupportingDocumentGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SupportingDocumentClient service(
      SupportingDocumentService service) {
    return (SupportingDocumentClient) super.service(service);
  }

  /**
   * Dépôt d'une pièce justificative.
   *
   * @param request la pièce à rattacher
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(SupportingDocumentCreateRequestDto request) {
    return new CreateExecutor(SupportingDocumentService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des pièces.
   *
   * @param request critères, projection et pagination
   * @return les pièces correspondantes
   */
  public SupportingDocumentGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<SupportingDocumentGetManyResponseDto>(
        SupportingDocumentGetManyResponseDto.class,
        SupportingDocumentService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public SupportingDocumentGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'une pièce unique.
   *
   * @param request critères et projection
   * @return la pièce correspondante
   */
  public SupportingDocumentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupportingDocumentDto>(
        SupportingDocumentDto.class,
        SupportingDocumentService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  @Override
  public SupportingDocumentDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'une pièce par son identifiant.
   *
   * @param request identifiant et projection
   * @return la pièce correspondante
   */
  public SupportingDocumentDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupportingDocumentDto>(
        SupportingDocumentDto.class,
        SupportingDocumentService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public SupportingDocumentDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Retrait d'une pièce justificative.
   *
   * @param request l'identifiant à retirer
   * @return l'identifiant retiré
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SupportingDocumentService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
