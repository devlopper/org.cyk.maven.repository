package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un grade du FUR : pour un couple échelle / corps et grade de Solde AN
 * 2000, la catégorie et la correspondance dans CALO (emploi, grade, classe, échelon). {@code *}
 * comme échelle vaut pour tout corps ayant ce grade : la recherche prend d'abord le couple exact,
 * à défaut la ligne {@code *} du grade (RG-09 du dossier de spécifications du FUR).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurGradeDto extends AbstractIdentifiableAuditableDto {

  /**
   * Code échelle / corps du FUR (ou {@code *} pour tout corps ayant ce grade).
   */
  @JsonbProperty(JSON_SCALE_CORPS_CODE)
  private String scaleCorpsCode;

  /**
   * Code du grade Solde AN 2000.
   */
  @JsonbProperty(JSON_GRADE_CODE)
  private String gradeCode;

  /**
   * Catégorie : {@code A}, {@code B}, {@code C} ou {@code D}.
   */
  @JsonbProperty(JSON_CATEGORY_CODE)
  private String categoryCode;

  /**
   * Code de l'emploi CALO.
   */
  @JsonbProperty(JSON_CALO_JOB_CODE)
  private String caloJobCode;

  /**
   * Code du grade CALO.
   */
  @JsonbProperty(JSON_CALO_GRADE_CODE)
  private String caloGradeCode;

  /**
   * Code de la classe CALO.
   */
  @JsonbProperty(JSON_CALO_CLASS_CODE)
  private String caloClassCode;

  /**
   * Code de l'échelon CALO.
   */
  @JsonbProperty(JSON_CALO_STEP_CODE)
  private String caloStepCode;

  /**
   * Valeur de l'échelle / corps qui vaut pour tout corps ayant le grade.
   */
  public static final String ANY_SCALE_CORPS = "*";

  /**
   * Identifiant json {@link #scaleCorpsCode}.
   */
  public static final String JSON_SCALE_CORPS_CODE = "codeEchelleCorps";

  /**
   * Identifiant json {@link #gradeCode}.
   */
  public static final String JSON_GRADE_CODE = "codeGrade";

  /**
   * Identifiant json {@link #categoryCode}.
   */
  public static final String JSON_CATEGORY_CODE = "codeCategorie";

  /**
   * Identifiant json {@link #caloJobCode}.
   */
  public static final String JSON_CALO_JOB_CODE = "codeEmploiCalo";

  /**
   * Identifiant json {@link #caloGradeCode}.
   */
  public static final String JSON_CALO_GRADE_CODE = "codeGradeCalo";

  /**
   * Identifiant json {@link #caloClassCode}.
   */
  public static final String JSON_CALO_CLASS_CODE = "codeClasseCalo";

  /**
   * Identifiant json {@link #caloStepCode}.
   */
  public static final String JSON_CALO_STEP_CODE = "codeEchelonCalo";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "grade du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "grades du FUR";
}
