package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceCreateRequestDto;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceGetManyResponseDto;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollComponentCorrespondenceService}.
 *
 * @author desysoft
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollComponentCorrespondenceClient
    extends AbstractClient<PayrollComponentCorrespondenceService>
    implements GetByIdentifier<PayrollComponentCorrespondenceDto>,
               GetMany<PayrollComponentCorrespondenceGetManyResponseDto> {

  @Override
  public PayrollComponentCorrespondenceClient service(
      PayrollComponentCorrespondenceService service) {
    return (PayrollComponentCorrespondenceClient) super.service(service);
  }

  /**
   * {@link PayrollComponentCorrespondenceService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollComponentCorrespondenceCreateRequestDto request) {
    return new CreateExecutor(PayrollComponentCorrespondenceService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentCorrespondenceGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollComponentCorrespondenceGetManyResponseDto>(
        PayrollComponentCorrespondenceGetManyResponseDto.class,
        PayrollComponentCorrespondenceService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentCorrespondenceGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentCorrespondenceDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollComponentCorrespondenceDto>(
        PayrollComponentCorrespondenceDto.class,
        PayrollComponentCorrespondenceService.GET_BY_IDENTIFIER_IDENTIFIER)
          .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentCorrespondenceDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetOneExecutor<Long>(Long.class,
        PayrollComponentCorrespondenceService.GET_COUNT_IDENTIFIER)
          .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayrollComponentCorrespondenceService#getCount}.
   *
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public Long getCount(FilterDto filter, String auditWho, String auditSession) {
    GetCountRequestDto request = new GetCountRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getCount(request);
  }

  /**
   * {@link PayrollComponentCorrespondenceService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollComponentCorrespondenceUpdateRequestDto request) {
    return new GetOneExecutor<IdentifiableResponseDto>(IdentifiableResponseDto.class,
        PayrollComponentCorrespondenceService.UPDATE_IDENTIFIER)
          .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollComponentCorrespondenceService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new GetOneExecutor<IdentifiableResponseDto>(IdentifiableResponseDto.class,
        PayrollComponentCorrespondenceService.DELETE_IDENTIFIER)
          .execute(() -> service().delete(request));
  }

}
