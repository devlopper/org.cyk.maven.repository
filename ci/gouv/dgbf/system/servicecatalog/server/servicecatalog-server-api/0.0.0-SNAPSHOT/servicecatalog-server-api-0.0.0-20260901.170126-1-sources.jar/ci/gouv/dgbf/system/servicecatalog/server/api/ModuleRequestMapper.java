package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModuleService.ModuleCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModuleService.ModuleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ModuleDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ModuleDto}.

    @author Christian
               """)
public interface ModuleRequestMapper
    extends RequestMapper<ModuleDto, ModuleCreateRequestDto,
        ModuleUpdateRequestDto> {

}
