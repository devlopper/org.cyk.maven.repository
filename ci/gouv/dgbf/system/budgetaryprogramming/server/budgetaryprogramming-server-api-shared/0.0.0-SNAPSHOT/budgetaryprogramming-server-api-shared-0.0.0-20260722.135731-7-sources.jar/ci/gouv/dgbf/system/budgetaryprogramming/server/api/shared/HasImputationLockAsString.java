package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de verrou
 * d'imputation.
 *
 * @author Christian
 */
public interface HasImputationLockAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du verrou
   * d'imputation.
   *
   * @return représentation en chaine de caractères du verrou d'imputation
   */
  String getImputationLockAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du verrou
   * d'imputation.
   *
   * @param asString représentation en chaine de caractères du verrou d'imputation
   */
  void setImputationLockAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du verrou d'imputation.
   */
  String FIELD_IMPUTATION_LOCK_AS_STRING = "imputationLockAsString";
}
