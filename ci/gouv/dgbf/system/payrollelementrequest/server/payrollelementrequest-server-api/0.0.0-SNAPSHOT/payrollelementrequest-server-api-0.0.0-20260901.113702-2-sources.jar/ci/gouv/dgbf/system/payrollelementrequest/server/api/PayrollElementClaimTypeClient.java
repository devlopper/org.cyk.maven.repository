package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PayrollElementClaimTypeService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class PayrollElementClaimTypeClient extends AbstractClient<PayrollElementClaimTypeService>
    implements GetByIdentifier<PayrollElementClaimTypeDto>,
    GetMany<PayrollElementClaimTypeGetManyResponseDto> {

  @Override
  public PayrollElementClaimTypeClient service(PayrollElementClaimTypeService service) {
    return (PayrollElementClaimTypeClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeGetManyResponseDto>(
        PayrollElementClaimTypeGetManyResponseDto.class,
        PayrollElementClaimTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimTypeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimTypeGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementClaimTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollElementClaimTypeCreateRequestDto request) {
    return new CreateExecutor(PayrollElementClaimTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollElementClaimTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollElementClaimTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollElementClaimTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollElementClaimTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeDto>(PayrollElementClaimTypeDto.class,
        PayrollElementClaimTypeService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollElementClaimTypeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimTypeDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollElementClaimTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return type de réclamation
   */
  public PayrollElementClaimTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeDto>(PayrollElementClaimTypeDto.class,
        PayrollElementClaimTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollElementClaimTypeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollElementClaimTypeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
