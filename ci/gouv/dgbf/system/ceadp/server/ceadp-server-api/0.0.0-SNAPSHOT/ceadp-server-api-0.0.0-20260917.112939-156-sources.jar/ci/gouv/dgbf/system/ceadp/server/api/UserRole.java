package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // Type de dossier.

  /**
   * Gérer.
   */
  MANAGE_FOLDER_TYPE("GERER_TYPE_DOSSIER"),
  
  /**
   * Créer.
   */
  CREATE_FOLDER_TYPE("CREER_TYPE_DOSSIER"),

  /**
   * Lire.
   */
  READ_FOLDER_TYPE("LIRE_TYPE_DOSSIER"),

  /**
   * Mettre à jour.
   */
  UPDATE_FOLDER_TYPE("METTRE_A_JOUR_TYPE_DOSSIER"),

  /**
   * Supprimer.
   */
  DELETE_FOLDER_TYPE("SUPPRIMER_TYPE_DOSSIER"),

  // Type d'activité.

  /**
   * Gérer.
   */
  MANAGE_ACTIVITY_TYPE("GERER_TYPE_ACTIVITE"),
  
  /**
   * Créer.
   */
  CREATE_ACTIVITY_TYPE("CREER_TYPE_ACTIVITE"),

  /**
   * Lire.
   */
  READ_ACTIVITY_TYPE("LIRE_TYPE_ACTIVITE"),

  /**
   * Mettre à jour.
   */
  UPDATE_ACTIVITY_TYPE("METTRE_A_JOUR_TYPE_ACTIVITE"),

  /**
   * Supprimer.
   */
  DELETE_ACTIVITY_TYPE("SUPPRIMER_TYPE_ACTIVITE"),

  // Dossier.

  /**
   * Gérer.
   */
  MANAGE_FOLDER("GERER_DOSSIER"),
  
  /**
   * Créer.
   */
  CREATE_FOLDER("CREER_DOSSIER"),

  /**
   * Lire.
   */
  READ_FOLDER("LIRE_DOSSIER"),

  /**
   * Mettre à jour.
   */
  UPDATE_FOLDER("METTRE_A_JOUR_DOSSIER"),

  /**
   * Supprimer.
   */
  DELETE_FOLDER("SUPPRIMER_DOSSIER"),

  // Activité.

  /**
   * Gérer.
   */
  MANAGE_ACTIVITY("GERER_ACTIVITE"),
  
  /**
   * Créer.
   */
  CREATE_ACTIVITY("CREER_ACTIVITE"),

  /**
   * Lire.
   */
  READ_ACTIVITY("LIRE_ACTIVITE"),

  /**
   * Mettre à jour.
   */
  UPDATE_ACTIVITY("METTRE_A_JOUR_ACTIVITE"),

  /**
   * Supprimer.
   */
  DELETE_ACTIVITY("SUPPRIMER_ACTIVITE"),

  // Tâche.

  /**
   * Gérer.
   */
  MANAGE_TASK("GERER_TACHE"),
  
  /**
   * Créer.
   */
  CREATE_TASK("CREER_TACHE"),

  /**
   * Lire.
   */
  READ_TASK("LIRE_TACHE"),

  /**
   * Mettre à jour.
   */
  UPDATE_TASK("METTRE_A_JOUR_TACHE"),

  /**
   * Supprimer.
   */
  DELETE_TASK("SUPPRIMER_TACHE"),

  /**
   * Orchestrer.
   */
  ORCHESTRATE_TASK_PROCESSING("ORCHESTRER_TRAITEMENT_TACHE"),
  
  // Agent.

  /**
   * Gérer.
   */
  MANAGE_AGENT("GERER_AGENT"),
  
  /**
   * Créer.
   */
  CREATE_AGENT("CREER_AGENT"),

  /**
   * Lire.
   */
  READ_AGENT("LIRE_AGENT"),

  /**
   * Mettre à jour.
   */
  UPDATE_AGENT("METTRE_A_JOUR_AGENT"),

  /**
   * Supprimer.
   */
  DELETE_AGENT("SUPPRIMER_AGENT"),

  // Identité de groupe de dossier.

  /**
   * Gérer.
   */
  MANAGE_FOLDER_IDENTITY_GROUP("GERER_IDENTITE_GROUPE_DOSSIER"),
  
  /**
   * Créer.
   */
  CREATE_FOLDER_IDENTITY_GROUP("CREER_IDENTITE_GROUPE_DOSSIER"),

  /**
   * Lire.
   */
  READ_FOLDER_IDENTITY_GROUP("LIRE_IDENTITE_GROUPE_DOSSIER"),

  /**
   * Mettre à jour.
   */
  UPDATE_FOLDER_IDENTITY_GROUP("METTRE_A_JOUR_IDENTITE_GROUPE_DOSSIER"),

  /**
   * Supprimer.
   */
  DELETE_FOLDER_IDENTITY_GROUP("SUPPRIMER_IDENTITE_GROUPE_DOSSIER"),

  // Fichier de groupe de dossier.

  /**
   * Gérer.
   */
  MANAGE_FOLDER_FILE_GROUP("GERER_FICHIER_GROUPE_DOSSIER"),
  
  /**
   * Créer.
   */
  CREATE_FOLDER_FILE_GROUP("CREER_FICHIER_GROUPE_DOSSIER"),

  /**
   * Lire.
   */
  READ_FOLDER_FILE_GROUP("LIRE_FICHIER_GROUPE_DOSSIER"),

  /**
   * Mettre à jour.
   */
  UPDATE_FOLDER_FILE_GROUP("METTRE_A_JOUR_FICHIER_GROUPE_DOSSIER"),

  /**
   * Supprimer.
   */
  DELETE_FOLDER_FILE_GROUP("SUPPRIMER_FICHIER_GROUPE_DOSSIER"),

  // Identité de groupe d'activité.

  /**
   * Gérer.
   */
  MANAGE_ACTIVITY_IDENTITY_GROUP("GERER_IDENTITE_GROUPE_ACTIVITE"),
  
  /**
   * Créer.
   */
  CREATE_ACTIVITY_IDENTITY_GROUP("CREER_IDENTITE_GROUPE_ACTIVITE"),

  /**
   * Lire.
   */
  READ_ACTIVITY_IDENTITY_GROUP("LIRE_IDENTITE_GROUPE_ACTIVITE"),

  /**
   * Mettre à jour.
   */
  UPDATE_ACTIVITY_IDENTITY_GROUP("METTRE_A_JOUR_IDENTITE_GROUPE_ACTIVITE"),

  /**
   * Supprimer.
   */
  DELETE_ACTIVITY_IDENTITY_GROUP("SUPPRIMER_IDENTITE_GROUPE_ACTIVITE"),

  // Fichier de groupe d'activité.

  /**
   * Gérer.
   */
  MANAGE_ACTIVITY_FILE_GROUP("GERER_FICHIER_GROUPE_ACTIVITE"),
  
  /**
   * Créer.
   */
  CREATE_ACTIVITY_FILE_GROUP("CREER_FICHIER_GROUPE_ACTIVITE"),

  /**
   * Lire.
   */
  READ_ACTIVITY_FILE_GROUP("LIRE_FICHIER_GROUPE_ACTIVITE"),

  /**
   * Mettre à jour.
   */
  UPDATE_ACTIVITY_FILE_GROUP("METTRE_A_JOUR_FICHIER_GROUPE_ACTIVITE"),

  /**
   * Supprimer.
   */
  DELETE_ACTIVITY_FILE_GROUP("SUPPRIMER_FICHIER_GROUPE_ACTIVITE"),

  // Identité de groupe de tâche.

  /**
   * Gérer.
   */
  MANAGE_TASK_IDENTITY_GROUP("GERER_IDENTITE_GROUPE_TACHE"),
  
  /**
   * Créer.
   */
  CREATE_TASK_IDENTITY_GROUP("CREER_IDENTITE_GROUPE_TACHE"),

  /**
   * Lire.
   */
  READ_TASK_IDENTITY_GROUP("LIRE_IDENTITE_GROUPE_TACHE"),

  /**
   * Mettre à jour.
   */
  UPDATE_TASK_IDENTITY_GROUP("METTRE_A_JOUR_IDENTITE_GROUPE_TACHE"),

  /**
   * Supprimer.
   */
  DELETE_TASK_IDENTITY_GROUP("SUPPRIMER_IDENTITE_GROUPE_TACHE"),

  // Fichier de groupe de tâche.

  /**
   * Gérer.
   */
  MANAGE_TASK_FILE_GROUP("GERER_FICHIER_GROUPE_TACHE"),
  
  /**
   * Créer.
   */
  CREATE_TASK_FILE_GROUP("CREER_FICHIER_GROUPE_TACHE"),

  /**
   * Lire.
   */
  READ_TASK_FILE_GROUP("LIRE_FICHIER_GROUPE_TACHE"),

  /**
   * Mettre à jour.
   */
  UPDATE_TASK_FILE_GROUP("METTRE_A_JOUR_FICHIER_GROUPE_TACHE"),

  /**
   * Supprimer.
   */
  DELETE_TASK_FILE_GROUP("SUPPRIMER_FICHIER_GROUPE_TACHE"),

  /**
   * Mettre à jour gerabilité quand tache terminée.
   */
  UPDATE_FILE_MANAGEABLE_WHEN_TASK_TERMINATED("METTRE_A_JOUR_GERABILITE_FICHIER_QUAND_TERMINEE"),

  // Partage de tâche.

  /**
   * Gérer.
   */
  MANAGE_TASK_SHARING("GERER_PARTAGE_TACHE"),
  
  /**
   * Créer.
   */
  CREATE_TASK_SHARING("CREER_PARTAGE_TACHE"),

  /**
   * Lire.
   */
  READ_TASK_SHARING("LIRE_PARTAGE_TACHE"),

  /**
   * Mettre à jour.
   */
  UPDATE_TASK_SHARING("METTRE_A_JOUR_PARTAGE_TACHE"),

  /**
   * Supprimer.
   */
  DELETE_TASK_SHARING("SUPPRIMER_PARTAGE_TACHE"),

  // Unité administrative
  
  /**
   * Superviser.
   */
  SUPERVISE_ADMINISTRATIVE_UNIT("SUPERVISER_UNITE_ADMINISTRATIVE");
  
  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;

}
