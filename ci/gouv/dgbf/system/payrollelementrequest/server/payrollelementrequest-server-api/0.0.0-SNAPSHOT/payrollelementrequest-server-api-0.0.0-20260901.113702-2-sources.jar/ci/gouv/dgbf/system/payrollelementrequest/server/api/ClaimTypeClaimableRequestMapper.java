package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimTypeClaimableDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimTypeClaimableDto}.

    @author akm
               """)
public interface ClaimTypeClaimableRequestMapper extends
    RequestMapper<ClaimTypeClaimableDto, ClaimTypeClaimableCreateRequestDto,
        ClaimTypeClaimableUpdateRequestDto> {

}
