package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipTemplateComponentService.PayslipTemplateComponentCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipTemplateComponentService.PayslipTemplateComponentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipTemplateComponentDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipTemplateComponentDto}.

    @author Christian
               """)
public interface PayslipTemplateComponentRequestMapper
    extends RequestMapper<PayslipTemplateComponentDto, PayslipTemplateComponentCreateRequestDto,
        PayslipTemplateComponentUpdateRequestDto> {

}
