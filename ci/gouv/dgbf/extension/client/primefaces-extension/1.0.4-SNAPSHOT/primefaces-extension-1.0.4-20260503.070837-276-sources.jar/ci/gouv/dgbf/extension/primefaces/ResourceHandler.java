package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ConfigurationHelper;
import ci.gouv.dgbf.extension.core.FileHelper;
import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.faces.application.ViewResource;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import java.net.URL;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.omnifaces.resourcehandler.CombinedResourceHandler;

/**
 * Cette classe représente un gestionnaire de resource.
 *
 * @author Christian
 *
 */
public class ResourceHandler extends CombinedResourceHandler {
  private static final Logger LOGGER = Logger.getLogger(ResourceHandler.class.getName());

  Set<String> paths;

  @Inject
  ConfigurationHelper configurationHelper;

  @Inject
  StringHelper stringHelper;

  @Inject
  FileHelper fileHelper;
  
  public ResourceHandler(jakarta.faces.application.ResourceHandler wrapped) {
    super(wrapped);
  }

  @Override
  public ViewResource createViewResource(FacesContext context, String resourceName) {
    ViewResource viewResource = super.createViewResource(context, resourceName);
    if (viewResource != null) {
      return viewResource;
    }
    for (String path : getPaths()) {
      final URL url = getClass().getResource(fileHelper().normalize(path + resourceName));
      if (url != null) {
        viewResource = new ViewResource() {
          @Override
          public URL getURL() {
            return url;
          }
        };
        break;
      }
    }
    if (viewResource == null) {
      LOGGER.log(Level.WARNING,
          "La ressource <<{0}>> n''a pas été trouvée. chemins complémentaires : {1}",
          new Object[] {resourceName, paths});
    }
    return viewResource;
  }

  Set<String> getPaths() {
    if (paths != null) {
      return paths;
    }
    paths = new LinkedHashSet<>();
    String string = configurationHelper().getValue(String.class, PATHS_PROPERTY, null);
    if (stringHelper().isBlank(string)) {
      return paths;
    }
    paths.addAll(
        Arrays.stream(string.split(",")).map(path -> fileHelper().appendSeparator(path)).toList());
    LOGGER.log(Level.CONFIG, "Les chemins complémentaires sont : {0}",
        paths.stream().collect(Collectors.joining(",")));
    return paths;
  }

  ConfigurationHelper configurationHelper() {
    if (configurationHelper == null) {
      configurationHelper = new ConfigurationHelper();
    }
    return configurationHelper;
  }

  StringHelper stringHelper() {
    if (stringHelper == null) {
      stringHelper = new StringHelper();
    }
    return stringHelper;
  }
  
  FileHelper fileHelper() {
    if (fileHelper == null) {
      fileHelper = new FileHelper();
    }
    return fileHelper;
  }
  
  static final String PATHS_PROPERTY = "dgbf.primefaces.resources.paths";
}
