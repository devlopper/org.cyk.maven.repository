package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Interface représentant un filtre basé sur la notion de code de
 * {@link AdministrativeUnitEmployeeStatus}.
 *
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface AdministrativeUnitEmployeeStatusCodeFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir le code de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   * @return code de {@link AdministrativeUnitEmployeeStatus}
   */
  public static String get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   * @param code code de {@link AdministrativeUnitEmployeeStatus}
   */
  public static void set(FilterDto filter, String code) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = "codeChampPositionMouvement";


}

