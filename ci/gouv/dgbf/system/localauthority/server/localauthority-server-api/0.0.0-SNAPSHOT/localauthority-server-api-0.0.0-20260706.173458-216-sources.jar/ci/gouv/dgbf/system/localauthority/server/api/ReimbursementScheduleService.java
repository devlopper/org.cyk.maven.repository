package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ReimbursementScheduleDto}.
 *
 * @author Desysoft
 */
@Path(value = ReimbursementScheduleService.PATH)
@Tag(name = "Gestion des plannings de remboursements")
public interface ReimbursementScheduleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "planningremboursements";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un plannning de remboursement",
      description = "Ce service permet de créer un plannning de remboursement")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ReimbursementScheduleCreateRequestDto request);

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Desysoft
   */
  interface SaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link CommitmentDto}.
     *
     * @return identifiant {@link CommitmentDto}
     */
    String getExpenditureSettlementIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link CommitmentDto}.
     *
     * @param triennialProgramActivityIdentifier identifiant {@link CommitmentDto}
     */
    void setExpenditureSettlementIdentifier(String triennialProgramActivityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
     *
     * @return identifiant {@link TriennialProgramDto}
     */
    String getTriennialProgramIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
     *
     * @param triennialProgramIdentifier identifiant {@link TriennialProgramDto}
     */
    void setTriennialProgramIdentifier(String triennialProgramIdentifier);


    /**
     * Cette méthode permet d'obtenir le montant 1.
     *
     * @return montant 1
     */
    long getAmount1();

    /**
     * Cette méthode permet d'assigner le montant 1.
     *
     * @param amount1 montant 1
     */
    void setAmount1(long amount1);

    /**
     * Cette méthode permet d'obtenir le montant 2.
     *
     * @return montant 2
     */
    long getAmount2();

    /**
     * Cette méthode permet d'assigner le montant 2.
     *
     * @param amount2 montant 2
     */
    void setAmount2(long amount2);

    /**
     * Cette méthode permet d'obtenir le montant 3.
     *
     * @return montant 3
     */
    long getAmount3();

    /**
     * Cette méthode permet d'assigner le montant 3.
     *
     * @param amount3 montant 3
     */
    void setAmount3(long amount3);


    /**
     * Cette méthode permet d'obtenir le montant total déja remboursé.
     *
     * @return montant remboursé
     */
    long getReimbursedAmount();

    /**
     * Cette méthode permet d'assigner le le montant total déja remboursé.
     *
     * @param reimbursedAmount montant  remboursé
     */
    void setReimbursedAmount(long reimbursedAmount);


    /**
     * Identifiant champ json de {@link ReimbursementScheduleDto}.
     */
    String JSON_IDENTIFIER = ReimbursementScheduleDto.JSON_IDENTIFIER;

    /**
     * Identifiant champ json de {@link CommitmentDto}.
     */
    String JSON_COMMITMENT_IDENTIFIER =
        ReimbursementScheduleDto.JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER;


    /**
     * Identifiant champ json de {@link TriennialProgramDto}.
     */
    String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
        ReimbursementScheduleDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

    /**
     * Identifiant champ json du montant remboursé.
     */
    String JSON_AMOUNT_REIMBURSED =
        ReimbursementScheduleDto.JSON_REIMBURSED_AMOUNT;

    /**
     * Identifiant champ json du montant 1.
     */
    String JSON_AMOUNT_1 = ReimbursementScheduleDto.JSON_AMOUNT_1;

    /**
     * Identifiant champ json du montant 2.
     */
    String JSON_AMOUNT_2 = ReimbursementScheduleDto.JSON_AMOUNT_2;

    /**
     * Identifiant champ json du montant 3.
     */
    String JSON_AMOUNT_3 = ReimbursementScheduleDto.JSON_AMOUNT_3;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReimbursementScheduleCreateRequestDto extends ByIdentifierRequestDto
      implements SaveRequestDto {

    @JsonbProperty(JSON_COMMITMENT_IDENTIFIER)
    private String expenditureSettlementIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_AMOUNT_REIMBURSED)
    private long reimbursedAmount;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }


  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PLANNING_REMBOURSEMENTS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des plannings de remboursements")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = GetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  public static class GetManyResponseDto
      extends AbstractGetByPageResponseDto<ReimbursementScheduleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ReimbursementScheduleDto> datas;
  }

  /**
   * Identifiant du service d'obtention d'un plannning de remboursement.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service d'obtention d'un plannning de remboursement.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un plannning de remboursement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ReimbursementScheduleDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant d' un plannning de remboursement.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service d'obtention par identifiant d'un plannning de remboursement.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un plannning de remboursement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ReimbursementScheduleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un plannning de remboursement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ReimbursementScheduleUpdateRequestDto request);


  /**
   * Cette classe représente la requête de mise à jour d'un plannning de remboursement.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReimbursementScheduleUpdateRequestDto extends ByIdentifierRequestDto
      implements SaveRequestDto {

    @JsonbProperty(JSON_COMMITMENT_IDENTIFIER)
    private String expenditureSettlementIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_AMOUNT_REIMBURSED)
    private long reimbursedAmount;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }

  /**
   * Identifiant du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_IDENTIFIER = "MISE_A_JOUR_MONTANT_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_PATH = ReimbursementScheduleUpdateAmountRequestDto.JSON_AMOUNT;

  /**
   * Cette méthode permet de mettre à jour montant de {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_AMOUNT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_AMOUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateAmount(ReimbursementScheduleUpdateAmountRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de montant.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReimbursementScheduleUpdateAmountRequestDto extends ByIdentifierRequestDto {
    /**
     * Montant.
     */
    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    /**
     * Index.
     */
    @JsonbProperty(JSON_INDEX)
    private int index;

    /**
     * Identifiant json {@link #amount}.
     */
    public static final String JSON_AMOUNT = "montant";

    /**
     * Identifiant json {@link #index}.
     */
    public static final String JSON_INDEX = "index";
  }


  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PLANNING_REMBOURSEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ReimbursementScheduleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un plannning de remboursement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

