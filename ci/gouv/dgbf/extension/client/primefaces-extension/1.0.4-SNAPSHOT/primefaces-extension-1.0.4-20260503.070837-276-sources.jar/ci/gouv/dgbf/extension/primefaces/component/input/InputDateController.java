package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente un contrôleur de d'entrée de date.
 *
 * @author Christian
 *
 */
@Dependent
public class InputDateController extends AbstractInputController {

  /* Controls */

  protected InputLocalDate inputLocalDate;
  protected InputLocalDateTime inputLocalDateTime;

  /*------------------------------ Input Local Date ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputLocalDate}.
   *
   * @return {@link InputLocalDate}
   */
  public InputLocalDate getInputLocalDate() {
    if (!initialized) {
      Core.runIfNull(inputLocalDate, () -> inputLocalDate = instantiateInputLocalDate());
      initialized = true;
    }
    return inputLocalDate;
  }

  protected InputLocalDate instantiateInputLocalDate() {
    InputLocalDate date = new InputLocalDate();
    processInputLocalDate(date);
    processOutputLabel(date.outputLabel());
    return date;
  }

  protected void processInputLocalDate(InputLocalDate inputLocalDate) {
    processInput(inputLocalDate);
  }

  /*------------------------------ Input Local Date Time ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link InputLocalDateTime}.
   *
   * @return {@link InputLocalDateTime}
   */
  public InputLocalDateTime getInputLocalDateTime() {
    if (!initialized) {
      Core.runIfNull(inputLocalDateTime,
          () -> inputLocalDateTime = instantiateInputLocalDateTime());
      initialized = true;
    }
    return inputLocalDateTime;
  }

  protected InputLocalDateTime instantiateInputLocalDateTime() {
    InputLocalDateTime date = new InputLocalDateTime();
    processInputLocalDateTime(date);
    processOutputLabel(date.outputLabel());
    return date;
  }

  protected void processInputLocalDateTime(InputLocalDateTime inputLocalDateTime) {
    processInput(inputLocalDateTime);
  }

}
