package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ApplicationDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-19T09:49:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ApplicationRequestMapperImpl implements ApplicationRequestMapper {

    @Override
    public ApplicationService.ApplicationCreateRequestDto mapCreate(ApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ApplicationService.ApplicationCreateRequestDto applicationCreateRequestDto = new ApplicationService.ApplicationCreateRequestDto();

        applicationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        applicationCreateRequestDto.setCode( arg0.getCode() );
        applicationCreateRequestDto.setName( arg0.getName() );
        applicationCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );

        return applicationCreateRequestDto;
    }

    @Override
    public ApplicationService.ApplicationUpdateRequestDto mapUpdate(ApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ApplicationService.ApplicationUpdateRequestDto applicationUpdateRequestDto = new ApplicationService.ApplicationUpdateRequestDto();

        applicationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        applicationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        applicationUpdateRequestDto.setName( arg0.getName() );

        return applicationUpdateRequestDto;
    }
}
