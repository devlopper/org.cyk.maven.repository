package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link LessorService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class LessorClient extends AbstractClient<LessorService>
    implements GetByIdentifier<LessorDto>,
               GetMany<LessorGetManyResponseDto>,
               DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public LessorClient service(LessorService service) {
    return (LessorClient) super.service(service);
  }

  /**
   * {@link LessorService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(LessorCreateRequestDto request) {
    return new CreateExecutor(LessorService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link LessorService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public LessorGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<LessorGetManyResponseDto>(LessorGetManyResponseDto.class,
        LessorService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link LessorService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LessorGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link LessorService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public LessorDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<LessorDto>(LessorDto.class,
        LessorService.GET_ONE_IDENTIFIER)
           .execute(() -> service().getOne(request));
  }

  /**
   * {@link LessorService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public LessorDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }


  /**
   * {@link LessorService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public LessorDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<LessorDto>(LessorDto.class,
        LessorService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link LessorService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LessorDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link LessorService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(LessorUpdateRequestDto request) {
    return new IdentifiableExecutor(LessorService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link LessorService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(LessorService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link LessorService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
