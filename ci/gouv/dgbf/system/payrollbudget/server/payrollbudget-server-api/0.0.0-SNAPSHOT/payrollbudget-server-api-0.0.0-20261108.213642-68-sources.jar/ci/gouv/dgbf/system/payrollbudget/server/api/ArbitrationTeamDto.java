package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Équipe d'arbitrage : un chef, des membres, et les dossiers qu'ils instruisent.
 *
 * <p>Jusqu'ici l'arbitrage se répartissait par <em>droit</em> : qui détenait le droit de traiter
 * les mouvements projetés les traitait, dans n'importe quel dossier. À deux EPN de test cela se
 * tient ; à quatre-vingt-seize, chacun voit le travail de tous et personne ne sait ce qui lui
 * revient.</p>
 *
 * <p>L'équipe répond à cela, et à cela seulement : elle <strong>borne le périmètre</strong>. Un
 * agent ne voit que les dossiers confiés à son équipe. Elle ne change rien aux droits — ce que
 * l'agent peut faire sur une ligne reste commandé par son profil, et un chargé des mouvements
 * n'instruira jamais un transfert de solde parce qu'on l'a mis dans une équipe.</p>
 *
 * <p>Le code est unique <em>par exercice</em> : une même équipe se reconduit d'une année sur
 * l'autre avec sa composition propre, sans que l'historique de l'exercice clos ne bouge.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ArbitrationTeamDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Exercice budgétaire de l'équipe.
   */
  @JsonbProperty(JSON_EXERCISE)
  private String exercise;

  /**
   * Identifiant de connexion du chef d'équipe.
   *
   * <p>Une chaîne, et non une clé étrangère : les comptes vivent dans le service des identités,
   * pas dans cette base. C'est le même choix que pour le preneur en charge d'un dossier.</p>
   */
  @JsonbProperty(JSON_LEADER)
  private String leader;

  /**
   * Nom lisible du chef, servi par le service des identités.
   */
  @JsonbProperty(JSON_LEADER_AS_STRING)
  private String leaderAsString;

  /**
   * Nombre de membres, calculé à la lecture.
   */
  @JsonbProperty(JSON_MEMBER_COUNT)
  private Long memberCount;

  /**
   * Nombre de dossiers confiés, calculé à la lecture.
   */
  @JsonbProperty(JSON_DOSSIER_COUNT)
  private Long dossierCount;

  /**
   * Vrai tant que l'équipe travaille.
   *
   * <p>Une équipe ne se supprime pas une fois qu'elle a instruit : ses décisions portent son
   * nom. On la désactive, comme on abroge une nature de pièce sans effacer celles qu'on a fait
   * valoir.</p>
   */
  @JsonbProperty(JSON_ACTIVE)
  private Boolean active;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEquipeArbitrage";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "equipeArbitrageChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "équipe d'arbitrage";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "équipes d'arbitrage";

  /**
   * Identifiant json pour {@link #exercise}.
   */
  public static final String JSON_EXERCISE = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #leader}.
   */
  public static final String JSON_LEADER = "chefEquipe";

  /**
   * Identifiant json pour {@link #leaderAsString}.
   */
  public static final String JSON_LEADER_AS_STRING = "chefEquipeChaine";

  /**
   * Identifiant json pour {@link #memberCount}.
   */
  public static final String JSON_MEMBER_COUNT = "nombreMembres";

  /**
   * Identifiant json pour {@link #dossierCount}.
   */
  public static final String JSON_DOSSIER_COUNT = "nombreDossiers";

  /**
   * Identifiant json pour {@link #active}.
   */
  public static final String JSON_ACTIVE = "estActif";
}
