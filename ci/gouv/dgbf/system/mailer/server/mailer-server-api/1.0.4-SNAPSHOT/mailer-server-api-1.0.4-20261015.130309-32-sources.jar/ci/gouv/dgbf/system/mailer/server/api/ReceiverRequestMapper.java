package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.mailer.server.api.ReceiverService.ReceiverCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.ReceiverService.ReceiverUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ReceiverDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ReceiverDto}.

    @author Christian
               """)
public interface ReceiverRequestMapper
    extends RequestMapper<ReceiverDto, ReceiverCreateRequestDto,
        ReceiverUpdateRequestDto> {

}
