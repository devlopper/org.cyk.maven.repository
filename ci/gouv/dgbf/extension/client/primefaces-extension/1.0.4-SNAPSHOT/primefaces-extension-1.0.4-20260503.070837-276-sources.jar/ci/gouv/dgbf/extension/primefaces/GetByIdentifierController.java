package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import jakarta.enterprise.context.Dependent;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link GetByIdentifier}.
 *
 * @author Christian
 *
 */
@Dependent
public class GetByIdentifierController extends AbstractController {

  @Getter
  @Setter
  Object client;
  
  /**
   * Cette méthode permet d'obtenir par identifiant.
   *
   * @param identifier identifiant
   * @param projection projection
   * @return identifiable
   */
  public Object get(String identifier, ProjectionDto projection) {
    if (client instanceof GetByIdentifier<?> c) {
      return c.getByIdentifier(identifier, projection, userIdentifier, null);
    }
    throw new IllegalStateException("L'obtention par identifiant n'a pas été implémentée");
  }
}
