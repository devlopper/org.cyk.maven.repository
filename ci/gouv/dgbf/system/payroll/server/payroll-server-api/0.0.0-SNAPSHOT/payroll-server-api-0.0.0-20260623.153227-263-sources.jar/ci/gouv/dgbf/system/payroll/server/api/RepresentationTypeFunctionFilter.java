package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RepresentationTypeFunctionDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class RepresentationTypeFunctionFilter extends AbstractIdentifiableFilter {

  private String typeFunctionIdentifier;

  private String representationIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RepresentationTypeFunctionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RepresentationTypeFunctionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeFunctionIdentifier = getTypeFunctionIdentifier(filter);
    representationIdentifier = getRepresentationIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTypeFunctionIdentifier(filter, typeFunctionIdentifier);
    setRepresentationIdentifier(filter, representationIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type de fonction.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setTypeFunctionIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_FUNCTION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de fonction.
   *
   * @param filter filtre
   * @return identifiant du type de fonction
   */
  public static String getTypeFunctionIdentifier(FilterDto filter) {
    return get(filter, d ->
            d.getFieldValueAsStringByName(JSON_TYPE_FUNCTION_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant de la representation.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setRepresentationIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_REPRESENTATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la representation.
   *
   * @param filter filtre
   * @return identifiant de la representation
   */
  public static String getRepresentationIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_REPRESENTATION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #typeFunctionIdentifier}.
   */
  public static final String JSON_TYPE_FUNCTION_IDENTIFIER = 
      RepresentationTypeFunctionDto.JSON_TYPE_FUNCTION_IDENTIFIER;

  /**
   * Identifiant json champ {@link #representationIdentifier}.
   */
  public static final String JSON_REPRESENTATION_IDENTIFIER = 
      RepresentationTypeFunctionDto.JSON_REPRESENTATION_IDENTIFIER;
}
