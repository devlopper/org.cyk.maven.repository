package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingExpenditureActivityViewDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingExpenditureActivityViewService.PATH)
@Tag(name = "Gestion des activités de dépenses de programmation")
public interface ProgrammingExpenditureActivityViewService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites-depenses-programmations";

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingExpenditureActivityViewDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = ProgrammingExpenditureActivityViewGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs
   * {@link ProgrammingExpenditureActivityViewDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingExpenditureActivityViewGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingExpenditureActivityViewDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingExpenditureActivityViewDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingExpenditureActivityViewDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExpenditureActivityViewDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de
   * {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingExpenditureActivityViewDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingExpenditureActivityViewDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExpenditureActivityViewDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);
}
