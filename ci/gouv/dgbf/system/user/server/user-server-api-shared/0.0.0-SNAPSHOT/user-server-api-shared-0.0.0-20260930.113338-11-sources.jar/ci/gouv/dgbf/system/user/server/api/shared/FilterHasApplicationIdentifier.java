package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'application.
 *
 * @author BoobaCool
 */
public interface FilterHasApplicationIdentifier extends HasApplicationIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'application.
   *
   * @param filter {@link FilterDto}
   */
  default void updateApplicationIdentifier(FilterDto filter) {
    setApplicationIdentifier(ApplicationIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'application de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterApplicationIdentifier(FilterDto filter) {
    ApplicationIdentifierFilter.set(filter, getApplicationIdentifier());
  }

}
