package ci.gouv.dgbf.system.datastructures.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.server.service.api.filter.GroupIdentifierFilter;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ValueSourceDto}.
 *
 * @author Christian
 */
@Dependent
public class ValueSourceFilterController extends AbstractFilterController<ValueSourceFilter> {

  @Inject
  @Getter
  ValueSourceGroupSelectOneController groupSelectOneController;

  /**
   * Cette méthode permet d'instantier.
   */
  public ValueSourceFilterController() {
    super(ValueSourceFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setGroupIdentifier(getRequestParameter(GroupIdentifierFilter.JSON_KEY));

    groupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setGroupIdentifier(identifier));

  }



}
