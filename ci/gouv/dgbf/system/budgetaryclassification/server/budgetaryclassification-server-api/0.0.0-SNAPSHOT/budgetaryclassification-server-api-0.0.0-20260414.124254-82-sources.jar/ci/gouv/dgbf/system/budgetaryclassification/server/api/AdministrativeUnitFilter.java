package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Oui ou non collectivité.
   */
  Boolean isLocalAuthority;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public AdministrativeUnitFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isLocalAuthority = getIsLocalAuthority(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsLocalAuthority(filter, isLocalAuthority);
  }

  /**
   * Cette méthode permet d'assigner si oui ou non {@link AdministrativeUnitDto} est une
   * collectivité.
   *
   * @param filter filtre
   * @param value valeur
   */
  public static void setIsLocalAuthority(FilterDto filter, Boolean value) {
    set(filter, JSON_IS_LOCAL_AUTHORITY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(value));
  }

  /**
   * Cette méthode permet d'obtenir si oui ou non {@link AdministrativeUnitDto} est une
   * collectivité.
   *
   * @param filter filtre
   * @return identifiant de {@link ExerciseDto}
   */
  public static Boolean getIsLocalAuthority(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LOCAL_AUTHORITY));
  }

  /**
   * Identifiant json champ {@link AdministrativeUnitFilter#isLocalAuthority}.
   */
  public static final String JSON_IS_LOCAL_AUTHORITY =
      AdministrativeUnitDto.JSON_IS_LOCAL_AUTHORITY;
}
