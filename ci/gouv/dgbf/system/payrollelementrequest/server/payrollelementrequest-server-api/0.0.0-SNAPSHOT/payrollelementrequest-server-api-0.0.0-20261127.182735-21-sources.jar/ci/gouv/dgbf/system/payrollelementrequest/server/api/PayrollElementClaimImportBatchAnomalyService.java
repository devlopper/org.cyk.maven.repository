package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de lecture de
 * {@link PayrollElementClaimImportBatchAnomalyDto}. Lecture seule (RG_REP_SOU_13) : ni création,
 * ni mise à jour, ni suppression -- le rapport d'anomalies naît du traitement d'un fichier.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimImportBatchAnomalyService.PATH)
@Tag(name = "Consultation des anomalies de lots d'import")
public interface PayrollElementClaimImportBatchAnomalyService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "anomalies-lot-import";

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_ANOMALIE_LOT_IMPORT";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre d'anomalies de Lots d'Import, pour la pagination et
   * le décompte des onglets.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ANOMALIE_LOT_IMPORT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Identifiant du service d'extraction des anomalies d'un Lot.
   */
  String EXTRACT_IDENTIFIER = "EXTRACTION_ANOMALIES_LOT_IMPORT";

  /**
   * Chemin du service d'extraction des anomalies d'un Lot.
   */
  String EXTRACT_PATH = "extraction";

  /**
   * Cette méthode donne les anomalies d'un Lot avec les colonnes d'identification de leur ligne du
   * fichier d'origine, pour les transmettre à la Fonction publique qui corrige son fichier. Une
   * ligne qui porte plusieurs anomalies donne plusieurs rangées.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  @Path(EXTRACT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = EXTRACT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = PayrollElementClaimImportBatchAnomalyExtractionResponseDto.class))})
  Response extract(GetByIdentifierRequestDto request);

  /**
   * Cette classe représente la réponse de l'extraction des anomalies d'un Lot.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchAnomalyExtractionResponseDto extends AbstractResponseDto {

    /**
     * Anomalies du Lot, dans l'ordre du fichier.
     */
    @JsonbProperty(JSON_ROWS)
    private List<PayrollElementClaimImportBatchAnomalyExtractionRowDto> rows;

    /**
     * Identifiant json {@link #rows}.
     */
    public static final String JSON_ROWS = "rangees";
  }

  /**
   * Cette classe représente une anomalie extraite : le motif, l'état de la réclamation de la ligne
   * et les colonnes d'identification de la ligne du fichier d'origine, sans donnée personnelle.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchAnomalyExtractionRowDto {

    /**
     * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
     */
    @JsonbProperty(PayrollElementClaimImportBatchAnomalyDto.JSON_LINE_NUMBER)
    private Integer lineNumber;

    /**
     * Motif de l'anomalie.
     */
    @JsonbProperty(PayrollElementClaimImportBatchAnomalyDto.JSON_REASON)
    private String reason;

    /**
     * {@code true} si la réclamation de la ligne est déjà générée, par le traitement ou par une
     * dérogation.
     */
    @JsonbProperty(JSON_CLAIM_GENERATED)
    private Boolean claimGenerated;

    /**
     * Valeur de chaque colonne d'identification de la ligne d'origine, par nom de colonne du
     * fichier, dans l'ordre de {@link PayrollElementClaimImportBatchService#PREVIEW_COLUMNS}.
     */
    @JsonbProperty(JSON_VALUES)
    private Map<String, String> values;

    /**
     * Identifiant json {@link #claimGenerated}.
     */
    public static final String JSON_CLAIM_GENERATED = "reclamationGeneree";

    /**
     * Identifiant json {@link #values}.
     */
    public static final String JSON_VALUES = "valeurs";
  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollElementClaimImportBatchAnomalyGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollElementClaimImportBatchAnomalyDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollElementClaimImportBatchAnomalyDto> datas;
  }
}
