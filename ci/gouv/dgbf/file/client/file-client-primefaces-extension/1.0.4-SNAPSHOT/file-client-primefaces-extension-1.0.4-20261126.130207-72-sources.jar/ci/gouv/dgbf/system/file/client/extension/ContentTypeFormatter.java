package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Locale;
import java.util.Map;

/**
 * Cette classe met en forme un type de contenu (type MIME) pour l'affichage : un libellé court et
 * lisible (« PDF », « Word », « PNG »). Un type inconnu est renvoyé tel quel, pour ne jamais
 * masquer une information ; le type complet reste à afficher en infobulle.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class ContentTypeFormatter {

  private static final Map<String, String> LABELS = Map.ofEntries(
      Map.entry("application/pdf", "PDF"), Map.entry("application/msword", "Word"),
      Map.entry("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "Word"),
      Map.entry("application/vnd.ms-excel", "Excel"),
      Map.entry("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Excel"),
      Map.entry("application/vnd.ms-powerpoint", "PowerPoint"),
      Map.entry("application/vnd.openxmlformats-officedocument.presentationml.presentation",
          "PowerPoint"),
      Map.entry("application/vnd.oasis.opendocument.text", "OpenDocument texte"),
      Map.entry("application/vnd.oasis.opendocument.spreadsheet", "OpenDocument tableur"),
      Map.entry("application/zip", "ZIP"), Map.entry("application/json", "JSON"),
      Map.entry("application/xml", "XML"), Map.entry("text/xml", "XML"),
      Map.entry("text/plain", "Texte"), Map.entry("text/csv", "CSV"),
      Map.entry("text/html", "HTML"), Map.entry("image/jpeg", "JPEG"),
      Map.entry("image/png", "PNG"), Map.entry("image/gif", "GIF"),
      Map.entry("image/svg+xml", "SVG"), Map.entry("image/tiff", "TIFF"));

  /**
   * Met en forme un type de contenu.
   *
   * @param contentType type de contenu (ex. « image/png »), éventuellement avec des paramètres
   *        (« text/plain; charset=UTF-8 »)
   * @return libellé court, le type reçu tel quel s'il est inconnu, ou {@code null} s'il est absent
   */
  public String format(String contentType) {
    if (contentType == null || contentType.isBlank()) {
      return contentType;
    }
    String type = contentType.split(";", 2)[0].trim().toLowerCase(Locale.ROOT);
    return LABELS.getOrDefault(type, contentType);
  }
}
