package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateManyExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityDeclareRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityDeclareResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityImportAllRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityImportByFunctionaryRegistrationNumberRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

/**
 * Cette classe représente le client de IdentityService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class IdentityClient extends AbstractClient<IdentityService>
    implements GetByIdentifier<IdentityDto>, GetMany<IdentityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public IdentityClient service(IdentityService service) {
    return (IdentityClient) super.service(service);
  }

  /**
   * {@link IdentityService#declare}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityDeclareResponseDto declare(IdentityDeclareRequestDto request) {
    return new GetOneExecutor<IdentityDeclareResponseDto>(IdentityDeclareResponseDto.class,
        IdentityService.DECLARE_IDENTIFIER).execute(() -> service().declare(request));
  }

  /**
   * {@link IdentityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(IdentityCreateRequestDto request) {
    return new CreateExecutor(IdentityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }
  
  /**
   * {@link IdentityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentityGetManyResponseDto>(IdentityGetManyResponseDto.class,
        IdentityService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link IdentityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentityDto>(IdentityDto.class, IdentityService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public IdentityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentityDto>(IdentityDto.class,
        IdentityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentityDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentityService#getCount}.
   *
   * @param request requête
   * @return nombre {@link IdentityDto}
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(IdentityService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link IdentityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(IdentityUpdateRequestDto request) {
    return new IdentifiableExecutor(IdentityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link IdentityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link IdentityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link IdentityService#importByFunctionaryRegistrationNumber}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto importByFunctionaryRegistrationNumber(
      IdentityImportByFunctionaryRegistrationNumberRequestDto request) {
    return new CreateExecutor(IdentityService.IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_PATH)
        .execute(() -> service().importByFunctionaryRegistrationNumber(request));
  }

  /**
   * {@link IdentityService#importAll}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateManyResponseDto importAll(IdentityImportAllRequestDto request) {
    return new CreateManyExecutor(IdentityService.IMPORT_ALL_PATH)
        .setExpectedResponseStatusCode(Response.Status.OK.getStatusCode())
        .execute(() -> service().importAll(request));
  }
}
