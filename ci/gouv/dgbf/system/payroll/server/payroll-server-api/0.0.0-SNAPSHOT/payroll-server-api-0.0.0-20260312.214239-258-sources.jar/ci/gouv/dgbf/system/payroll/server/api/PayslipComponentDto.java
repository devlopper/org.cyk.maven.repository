package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCessibleAmountDto;
import ci.gouv.dgbf.extension.core.segregation.HasGrossAmountDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsCessibleAmountLessThanMaxDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEarningDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxCessibleAmountDto;
import ci.gouv.dgbf.extension.core.segregation.HasOrderNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployeeAmountAsStringDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployeeAmountCalculationMessageDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployeeAmountDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployerAmountAsStringDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployerAmountCalculationMessageDto;
import ci.gouv.dgbf.system.employee.server.api.shared.HasEmployerAmountDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link PayrollComponentDto} de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipComponentDto extends AbstractIdentifiableAuditableDto
    implements HasPayslipIdentifierDto, HasPayslipAsStringDto, HasPayrollComponentIdentifierDto,
    HasPayrollComponentAsStringDto, HasIsEarningDto, HasOrderNumberDto,
    HasEmployeeAmountDto<Integer>, HasEmployeeAmountAsStringDto,
    HasEmployeeAmountCalculationMessageDto, HasEmployerAmountDto<Integer>,
    HasEmployerAmountAsStringDto, HasEmployerAmountCalculationMessageDto,
    HasGrossAmountDto<Integer>, HasCessibleAmountDto<Integer>, HasMaxCessibleAmountDto<Integer>,
    HasIsCessibleAmountLessThanMaxDto {

  @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
  private String payslipIdentifier;

  @JsonbProperty(JSON_PAYSLIP_AS_STRING)
  private String payslipAsString;

  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  private String payrollComponentAsString;

  @JsonbProperty(JSON_IS_EARNING)
  private Boolean isEarning;

  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  @JsonbProperty(JSON_EMPLOYEE_AMOUNT)
  private Integer employeeAmount;

  @JsonbProperty(JSON_EMPLOYEE_AMOUNT_AS_STRING)
  private String employeeAmountAsString;

  @JsonbProperty(JSON_EMPLOYEE_AMOUNT_CALCULATION_MESSAGE)
  private String employeeAmountCalculationMessage;

  @JsonbProperty(JSON_EMPLOYER_AMOUNT)
  private Integer employerAmount;

  @JsonbProperty(JSON_EMPLOYER_AMOUNT_AS_STRING)
  private String employerAmountAsString;

  @JsonbProperty(JSON_EMPLOYER_AMOUNT_CALCULATION_MESSAGE)
  private String employerAmountCalculationMessage;

  @JsonbProperty(JSON_GROSS_AMOUNT)
  private Integer grossAmount;

  /* Quotité cessible */
  
  @JsonbProperty(JSON_CESSIBLE_AMOUNT)
  private Integer cessibleAmount;

  @JsonbProperty(JSON_MAX_CESSIBLE_AMOUNT)
  private Integer maxCessibleAmount;

  @JsonbProperty(JSON_IS_CESSIBLE_AMOUNT_LESS_THAN_MAX)
  private Boolean isCessibleAmountLessThanMax;
  
  /**
   * Peut être persisté.
   */
  private Boolean persist;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPosteBulletinPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "posteBulletinPaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de bulletin de paie";
}
