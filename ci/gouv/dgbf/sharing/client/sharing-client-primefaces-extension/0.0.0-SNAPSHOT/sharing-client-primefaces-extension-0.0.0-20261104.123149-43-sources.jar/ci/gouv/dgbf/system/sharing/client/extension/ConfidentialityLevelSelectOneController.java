package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.sharing.server.api.ConfidentialityLevel;
import jakarta.enterprise.context.Dependent;

/** Controleur de selection d'un niveau de confidentialite. */
@Dependent
public class ConfidentialityLevelSelectOneController
    extends AbstractSelectOneEnumerationController<ConfidentialityLevel> {
  /** Construit le controleur. */
  protected ConfidentialityLevelSelectOneController() {
    super(ConfidentialityLevel.values());
    outputLableValue = "Niveau de confidentialite";
  }
}
