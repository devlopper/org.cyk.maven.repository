package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/** Catégorie structurelle d’un événement de traçabilité. */
@Getter
public enum TraceabilityEventCategory implements CodableByStringWithGetterOnly {
  LOG(TraceabilityEventCategoryCode.LOG),
  OPERATION_ENREGISTREMENT(TraceabilityEventCategoryCode.OPERATION_ENREGISTREMENT);

  private final String code;

  /**
   * Construit une catégorie d’événement.
   *
   * @param code code stable
   */
  TraceabilityEventCategory(String code) {
    this.code = code;
  }

  /**
   * Recherche une catégorie par son code.
   *
   * @param code code à rechercher
   * @return catégorie correspondante
   */
  public static TraceabilityEventCategory getByCode(String code) {
    for (TraceabilityEventCategory value : values()) {
      if (value.code.equals(code)) {
        return value;
      }
    }
    throw new IllegalArgumentException("Code de catégorie d’événement inconnu : " + code);
  }
}

