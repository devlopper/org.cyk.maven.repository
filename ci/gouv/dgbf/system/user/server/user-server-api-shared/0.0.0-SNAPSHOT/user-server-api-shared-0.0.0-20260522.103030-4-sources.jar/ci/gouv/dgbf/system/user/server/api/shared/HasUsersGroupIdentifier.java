package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant de groupe d'utilisateurs.
 *
 * @author Christian
 */
public interface HasUsersGroupIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe d'utilisateurs.
   *
   * @return identifiant du groupe d'utilisateurs
   */
  String getUsersGroupIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe d'utilisateurs.
   *
   * @param usersGroupIdentifier identifiant du groupe d'utilisateurs
   */
  void setUsersGroupIdentifier(String usersGroupIdentifier);

  /**
   * Identifiant java de l'identifiant du groupe d'utilisateurs.
   */
  String FIELD_USERS_GROUP_IDENTIFIER = "usersGroupIdentifier";
}
