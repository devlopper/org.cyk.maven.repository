package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N est complétée, sous forme de
 * chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedNAsString {

  /**
   * Obtient l'indicateur indiquant si l'année N est complétée, sous forme de chaîne de caractères.
   *
   * @return l'indicateur indiquant si l'année N est complétée sous forme de chaîne de caractères
   */
  String getCompletedNAsString();

  /**
   * Définit l'indicateur indiquant si l'année N est complétée, sous forme de chaîne de caractères.
   *
   * @param completedNAsString indicateur indiquant si l'année N est complétée sous forme de chaîne
   *        de caractères
   */
  void setCompletedNAsString(String completedNAsString);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N est complétée, sous forme de chaîne de
   * caractères.
   */
  String FIELD_COMPLETED_N_AS_STRING = "completedNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
