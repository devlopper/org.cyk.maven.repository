package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Path(value = ApplicationService.PATH)
@Tag(name = "Gestion des applications")
public interface ApplicationService extends SpecificService {

  /**
   * Chemin de base des applications.
   */
  String PATH = "applications";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author BoobaCool
   */
  interface ApplicationSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
     *
     * @return identifiant de {@link DomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
     *
     * @param domainIdentifier identifiant de {@link DomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * {@link HasDomainIdentifierDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_APPLICATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ApplicationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class ApplicationCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ApplicationSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_APPLICATIONS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = ApplicationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class ApplicationGetManyResponseDto
      extends AbstractGetByPageResponseDto<ApplicationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ApplicationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_APPLICATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ApplicationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_APPLICATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ApplicationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_APPLICATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ApplicationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class ApplicationUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ApplicationSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_APPLICATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'attribution administrateur applicatif.
   */
  String ASSIGN_ADMINISTRATOR_IDENTIFIER = "ATTRIBUTION_ADMINISTRATEUR";

  /**
   * Chemin du service d'attribution administrateur applicatif.
   */
  String ASSIGN_ADMINISTRATOR_PATH = "attribution-administrateur";

  /**
   * Cette méthode permet d'attribuer le rôle administrateur applicatif.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ASSIGN_ADMINISTRATOR_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ASSIGN_ADMINISTRATOR_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(
          implementation = ApplicationAssignAdministratorResponseDto.class))})
  Response assignAdministrator(ApplicationAssignAdministratorRequestDto request);

  /**
   * Cette classe représente la requête d'attribution administrateur applicatif.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class ApplicationAssignAdministratorRequestDto extends ByIdentifierRequestDto {

    /**
     * Liste des identifiants des utilisateurs.
     */
    @JsonbProperty(JSON_USER_IDENTIFIERS)
    private Set<String> userIdentifiers;

    /**
     * Identifiant json {@link #userIdentifiers}.
     */
    public static final String JSON_USER_IDENTIFIERS = "idUtilisateurs";
  }

  /**
   * Cette classe représente la réponse d'attribution administrateur applicatif.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class ApplicationAssignAdministratorResponseDto extends IdentifiableResponseDto {

    /**
     * Nombre d'attributions administrateur applicatif réussies.
     */
    @JsonbProperty(JSON_ASSIGNED_ADMIN_COUNT)
    private Integer assignedAdminCount;

    /**
     * Nombre d'attributions déjà existantes.
     */
    @JsonbProperty(JSON_EXISTING_COUNT)
    private Integer existingCount;

    /**
     * Identifiant json {@link #assignedAdminCount}.
     */
    public static final String JSON_ASSIGNED_ADMIN_COUNT = "nombreAdministrateurAttribue";

    /**
     * Identifiant json {@link #existingCount}.
     */
    public static final String JSON_EXISTING_COUNT = "nombreExistant";
  }
}
