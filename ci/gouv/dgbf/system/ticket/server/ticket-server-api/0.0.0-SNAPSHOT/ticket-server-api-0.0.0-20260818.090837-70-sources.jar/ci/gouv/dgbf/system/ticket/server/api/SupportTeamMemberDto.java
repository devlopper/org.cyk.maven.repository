package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTicketCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketCountDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasProcessedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasProcessedTicketCountDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketClaimActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketClaimActionsCountDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketDissatisfactionActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketDissatisfactionActionsCountDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketResolutionActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketResolutionActionsCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente membre equipe support.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamMemberDto extends AbstractIdentifiableDto
    implements HasTicketCountDto, HasTicketCountAsStringDto, HasClaimedTicketCountDto,
    HasClaimedTicketCountAsStringDto, HasProcessedTicketCountDto,
    HasProcessedTicketCountAsStringDto, HasTicketClaimActionsCountDto,
    HasTicketClaimActionsCountAsStringDto, HasTicketResolutionActionsCountDto,
    HasTicketResolutionActionsCountAsStringDto, HasTicketDissatisfactionActionsCountDto,
    HasTicketDissatisfactionActionsCountAsStringDto, HasUserIdentifierDto {

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
  private String supportTeamIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_AS_STRING)
  private String supportTeamAsString;

  /**
   * Identifiant utilisateur .
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Nombre total de tickets.
   */
  @JsonbProperty(JSON_TICKET_COUNT)
  private Integer ticketCount;

  /**
   * Nombre total de tickets sous forme de chaîne.
   */
  @JsonbProperty(JSON_TICKET_COUNT_AS_STRING)
  private String ticketCountAsString;

  /**
   * Nombre de tickets actuellement pris en charge.
   */
  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT)
  private Integer claimedTicketCount;

  /**
   * Nombre de tickets actuellement pris en charge sous forme de chaîne.
   */
  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT_AS_STRING)
  private String claimedTicketCountAsString;

  /**
   * Nombre de tickets traités.
   */
  @JsonbProperty(JSON_PROCESSED_TICKET_COUNT)
  private Integer processedTicketCount;

  /**
   * Nombre de tickets traités sous forme de chaîne.
   */
  @JsonbProperty(JSON_PROCESSED_TICKET_COUNT_AS_STRING)
  private String processedTicketCountAsString;

  /**
   * Nombre cumulé d'actions de prise en charge de ticket.
   */
  @JsonbProperty(JSON_TICKET_CLAIM_ACTIONS_COUNT)
  private Integer ticketClaimActionsCount;

  /**
   * Nombre cumulé d'actions de prise en charge de ticket sous forme de chaîne.
   */
  @JsonbProperty(JSON_TICKET_CLAIM_ACTIONS_COUNT_AS_STRING)
  private String ticketClaimActionsCountAsString;

  /**
   * Nombre cumulé d'actions de résolution de ticket.
   */
  @JsonbProperty(JSON_TICKET_RESOLUTION_ACTIONS_COUNT)
  private Integer ticketResolutionActionsCount;

  /**
   * Nombre cumulé d'actions de résolution de ticket sous forme de chaîne.
   */
  @JsonbProperty(JSON_TICKET_RESOLUTION_ACTIONS_COUNT_AS_STRING)
  private String ticketResolutionActionsCountAsString;

  /**
   * Nombre cumulé d'insatisfactions constatées sur des tickets (indicateur qualité).
   */
  @JsonbProperty(JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT)
  private Integer ticketDissatisfactionActionsCount;

  /**
   * Nombre cumulé d'insatisfactions constatées sur des tickets sous forme de chaîne.
   */
  @JsonbProperty(JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT_AS_STRING)
  private String ticketDissatisfactionActionsCountAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMembreServiceSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "membreServiceSupportChaine";


  /**
   * Identifiant champ java {@link #supportTeamIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_IDENTIFIER =
      SupportTeamDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_AS_STRING = SupportTeamDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "membre équipe support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "membres équipes support";

}

