package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.request.AuditableRequest;
import jakarta.inject.Inject;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur d'action.
 *
 * @param <T> Type de l'entité
 * @param <C> Type du client
 * @param <R> Type de la requête
 *
 * @author Christian
 */
public abstract class AbstractIdentifiableActionController<T, C, R> extends AbstractController {

  protected Class<T> clazz;

  @Getter
  @Setter
  protected T identifiable;

  @Getter
  @Setter
  protected ListController listController;

  @Inject
  @Getter
  protected IdentifiableProcessingController processingController;

  protected AbstractIdentifiableActionController(Class<T> clazz) {
    this.clazz = clazz;
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param identifiable identifiable
   */
  public void initialize(T identifiable) {
    if (identifiable == null) {
      initializeWhenNull();
    } else {
      this.identifiable = identifiable;
      initializeWhenNotNull(identifiable);
    }
  }

  protected void initializeWhenNull() {}

  protected void initializeWhenNotNull(T identifiable) {}

  protected abstract C getClient();

  protected abstract R mapRequest(T entity);

  protected UnaryOperator<Object> function() {
    return entity -> {
      @SuppressWarnings("unchecked")
      R request = mapRequest((T) entity);
      if (entity instanceof AuditableRequest auditable) {
        auditable.setAuditWho(userIdentifier);
      }
      return processRequest(request);
    };
  }

  protected abstract Object processRequest(R request);

  protected void initializeDialog(IdentifiableProcessingController controller, String action,
      String icon, String styleClass, String formFileName, UnaryOperator<Object> function,
      Function<Object, Boolean> buttonRenderedFunction) {
    controller.setListController(listController);
    controller.prepareDialog(clazz, action, icon, function, formFileName, getClient());
    controller.submitButton().setValue(action);
    controller.submitButton().setActionFunction(i -> controller.getController().execute());
    controller.setShowDialogButtonControllerRenderedFunctionIfNull(buttonRenderedFunction);
    controller.showDialogButton().addStyleClass(styleClass);
    controller.initialize();
  }
  
  @SuppressWarnings("unchecked")
  protected T getEntity() {
    return (T) processingController.getController().getEntity();
  }
}
