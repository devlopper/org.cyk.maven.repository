package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de localité.
 *
 * @author Christian
 */
public interface HasLocalityIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de localité.
   *
   * @return identifiant de localité
   */
  String getAdministrativeUnitIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de localité.
   *
   * @param identifier identifiant de localité
   */
  void setAdministrativeUnitIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de localité.
   */
  String FIELD_LOCALITY_IDENTIFIER = "localityIdentifier";
}
