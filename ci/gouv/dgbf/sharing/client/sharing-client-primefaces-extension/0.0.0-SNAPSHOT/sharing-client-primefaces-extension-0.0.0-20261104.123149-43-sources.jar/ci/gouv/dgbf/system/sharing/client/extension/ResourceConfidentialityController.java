package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.ConfidentialityLevel;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityRequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/** Controleur CRUD de la confidentialite par ressource. */
@Dependent
public class ResourceConfidentialityController extends AbstractController {
  @Inject ResourceConfidentialityClient client;
  @Inject @Getter ListController listController;
  @Inject @Getter ResourceConfidentialityFilterController filterController;
  @Inject @Getter ResourceSelectOneController resourceSelectOneController;
  @Inject @Getter ConfidentialityLevelSelectOneController confidentialityLevelSelectOneController;
  @Inject ResourceConfidentialityRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ResourceConfidentialityDto.NAME;
  }

  /** Initialise le CRUD et la previsualisation d'impact. */
  public void initialize() {
    listController.setEntityClass(ResourceConfidentialityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ResourceConfidentialityService.PATH);
    listController.setFilterController(filterController);
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ResourceConfidentialityDto.JSON_RESOURCE_IDENTIFIER,
        ResourceConfidentialityDto.JSON_RESOURCE_AS_STRING,
        ResourceConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL,
        ResourceConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();
    listController.getCreateController().setFunction(entity -> {
      ResourceConfidentialityCreateRequestDto request =
          requestMapper.mapCreate((ResourceConfidentialityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
    listController.getUpdateController().setProjection(projection);
    listController.getUpdateController().setFunction(entity -> {
      ResourceConfidentialityUpdateRequestDto request =
          requestMapper.mapUpdate((ResourceConfidentialityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
    resourceSelectOneController.getAutoComplete().addValueConsumer(identifier ->
        listController.getCreateControllerOrUpdateControllerEntityAs(
            ResourceConfidentialityDto.class).setResourceIdentifier(identifier));
    confidentialityLevelSelectOneController.getSelectOneMenu().addValueConsumer(name ->
        listController.getCreateControllerOrUpdateControllerEntityAs(
            ResourceConfidentialityDto.class).setConfidentialityLevel(
                name == null ? null : Core.getEnumerationValueByName(ConfidentialityLevel.class,
                    name)));
  }
}
