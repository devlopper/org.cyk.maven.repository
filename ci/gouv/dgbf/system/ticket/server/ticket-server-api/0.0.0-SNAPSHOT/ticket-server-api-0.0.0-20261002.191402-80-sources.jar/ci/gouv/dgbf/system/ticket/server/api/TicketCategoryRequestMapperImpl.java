package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketCategoryDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-02T19:14:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketCategoryRequestMapperImpl implements TicketCategoryRequestMapper {

    @Override
    public TicketCategoryService.TicketCategoryCreateRequestDto mapCreate(TicketCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketCategoryService.TicketCategoryCreateRequestDto ticketCategoryCreateRequestDto = new TicketCategoryService.TicketCategoryCreateRequestDto();

        ticketCategoryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketCategoryCreateRequestDto.setCode( arg0.getCode() );
        ticketCategoryCreateRequestDto.setName( arg0.getName() );

        return ticketCategoryCreateRequestDto;
    }

    @Override
    public TicketCategoryService.TicketCategoryUpdateRequestDto mapUpdate(TicketCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketCategoryService.TicketCategoryUpdateRequestDto ticketCategoryUpdateRequestDto = new TicketCategoryService.TicketCategoryUpdateRequestDto();

        ticketCategoryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketCategoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketCategoryUpdateRequestDto.setCode( arg0.getCode() );
        ticketCategoryUpdateRequestDto.setName( arg0.getName() );

        return ticketCategoryUpdateRequestDto;
    }
}
