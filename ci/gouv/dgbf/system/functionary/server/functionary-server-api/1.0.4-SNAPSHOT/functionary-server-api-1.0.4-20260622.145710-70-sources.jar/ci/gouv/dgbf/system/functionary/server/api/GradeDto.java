package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un grade.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class GradeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGrade";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "gradeChaine";
  
  /**
   * Identifiant json {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = CategoryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = CategoryDto.JSON_THIS_AS_STRING;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "grade";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
