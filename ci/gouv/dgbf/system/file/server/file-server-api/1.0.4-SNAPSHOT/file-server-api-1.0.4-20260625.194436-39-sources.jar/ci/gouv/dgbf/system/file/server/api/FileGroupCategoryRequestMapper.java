package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryService.FileGroupCategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FileGroupCategoryDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FileGroupCategoryDto}.

    @author Christian
               """)
public interface FileGroupCategoryRequestMapper extends RequestMapper<FileGroupCategoryDto,
    FileGroupCategoryCreateRequestDto, FileGroupCategoryUpdateRequestDto> {

}
