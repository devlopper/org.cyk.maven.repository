package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupGetValueRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupGetValueResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ContextualConstantEvaluationGroupService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ContextualConstantEvaluationGroupClient
    extends AbstractClient<ContextualConstantEvaluationGroupService>
    implements GetByIdentifier<ContextualConstantEvaluationGroupDto>,
    GetMany<ContextualConstantEvaluationGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ContextualConstantEvaluationGroupClient service(
      ContextualConstantEvaluationGroupService service) {
    return (ContextualConstantEvaluationGroupClient) super.service(service);
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ContextualConstantEvaluationGroupCreateRequestDto request) {
    return new CreateExecutor(ContextualConstantEvaluationGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationGroupGetManyResponseDto>(
        ContextualConstantEvaluationGroupGetManyResponseDto.class,
        ContextualConstantEvaluationGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantEvaluationGroupGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationGroupDto>(
        ContextualConstantEvaluationGroupDto.class,
        ContextualConstantEvaluationGroupService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ContextualConstantEvaluationGroupDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ContextualConstantEvaluationGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationGroupDto>(
        ContextualConstantEvaluationGroupDto.class,
        ContextualConstantEvaluationGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantEvaluationGroupDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ContextualConstantEvaluationGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantEvaluationGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantEvaluationGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ContextualConstantEvaluationGroupService#getValue}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationGroupGetValueResponseDto getValue(
      ContextualConstantEvaluationGroupGetValueRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationGroupGetValueResponseDto>(
        ContextualConstantEvaluationGroupGetValueResponseDto.class,
        ContextualConstantEvaluationGroupService.GET_VALUE_IDENTIFIER)
            .execute(() -> service().getValue(request));
  }
}
