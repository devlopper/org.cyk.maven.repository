package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link PayrollElementClaimDto} (RG_REP_STA_01).
 *
 * @author akm
 *
 */
@Getter
public enum PayrollElementClaimStatus {

  /**
   * Créée -- brouillon librement modifiable, avant toute Soumission (RG_REP_SOU_00).
   */
  CREATED(PayrollElementClaimStatusCode.CREATED, "Créée"),

  /**
   * Soumise -- première Soumission depuis Créée, ou nouvelle Soumission depuis Différée après
   * complément du dossier (RG_REP_PEC_06).
   */
  SUBMITTED(PayrollElementClaimStatusCode.SUBMITTED, "Soumise"),

  /**
   * Prise en charge par un Agent de Traitement.
   */
  IN_CHARGE(PayrollElementClaimStatusCode.IN_CHARGE, "Prise en charge"),

  /**
   * Rejetée, par l'Agent de Traitement (RG_REP_PEC_05) ou à un palier du circuit de validation
   * (RG_REP_RVR_16), motif obligatoire ; un rejet du circuit rejette la Réclamation entière.
   */
  REJECTED(PayrollElementClaimStatusCode.REJECTED, "Rejetée"),

  /**
   * Différée par l'Agent de Traitement (RG_REP_PEC_06), en attente de complément.
   */
  DEFERRED(PayrollElementClaimStatusCode.DEFERRED, "Différée"),

  /**
   * Acceptée -- atteint immédiatement à la Décision de l'Agent de Traitement (RG_REP_STA_02/03) ;
   * la Réclamation attend alors d'être transmise pour Visa, début du circuit de validation.
   */
  ACCEPTED(PayrollElementClaimStatusCode.ACCEPTED, "Acceptée"),

  /**
   * Transmise pour Visa -- la Réclamation Acceptée est remise par l'Agent de Traitement à son
   * Responsable (RG_REP_RVR_01 étape 1), un bordereau de transmission est émis (RG_REP_RVR_17).
   */
  TRANSMITTED_TO_VISA(PayrollElementClaimStatusCode.TRANSMITTED_TO_VISA, "Transmise pour Visa"),

  /**
   * Visée par le Responsable (RG_REP_RVR_01 étape 2).
   */
  VISA_GRANTED(PayrollElementClaimStatusCode.VISA_GRANTED, "Visée"),

  /**
   * Transmise pour Contrôle -- remise du Responsable à l'Agent de Contrôle, avec bordereau
   * (RG_REP_RVR_17).
   */
  TRANSMITTED_TO_CONTROL(PayrollElementClaimStatusCode.TRANSMITTED_TO_CONTROL,
      "Transmise pour Contrôle"),

  /**
   * Contrôlée par l'Agent de Contrôle (RG_REP_RVR_01 étape 4).
   */
  CONTROLLED(PayrollElementClaimStatusCode.CONTROLLED, "Contrôlée"),

  /**
   * Transmise pour Validation -- remise de l'Agent de Contrôle au Responsable de Structure, avec
   * bordereau (RG_REP_RVR_17).
   */
  TRANSMITTED_TO_VALIDATION(PayrollElementClaimStatusCode.TRANSMITTED_TO_VALIDATION,
      "Transmise pour Validation"),

  /**
   * Validation Déléguée au Trésor par le Responsable de Structure, avec bordereau
   * (RG_REP_RVR_17).
   */
  VALIDATION_DELEGATED(PayrollElementClaimStatusCode.VALIDATION_DELEGATED,
      "Validation Déléguée"),

  /**
   * Validée -- état terminal positif du circuit : les Impacts de la Réclamation sont appliqués
   * (RG_REP_RVR_04), directement ou après la Validation du Trésor.
   */
  VALIDATED(PayrollElementClaimStatusCode.VALIDATED, "Validée");

  private PayrollElementClaimStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;
  private Set<PayrollElementClaimStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link PayrollElementClaimStatus} par code.
   *
   * @param code code
   * @return {@link PayrollElementClaimStatus}
   */
  public static PayrollElementClaimStatus getByCode(String code) {
    return Stream.of(PayrollElementClaimStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    SUBMITTED.previous = Core.getSet(List.of(CREATED, DEFERRED));
    IN_CHARGE.previous = Core.getSet(List.of(SUBMITTED));
    REJECTED.previous = Core.getSet(List.of(IN_CHARGE, TRANSMITTED_TO_VISA, TRANSMITTED_TO_CONTROL,
        TRANSMITTED_TO_VALIDATION, VALIDATION_DELEGATED));
    DEFERRED.previous = Core.getSet(List.of(IN_CHARGE));
    ACCEPTED.previous = Core.getSet(List.of(IN_CHARGE));
    TRANSMITTED_TO_VISA.previous = Core.getSet(List.of(ACCEPTED));
    VISA_GRANTED.previous = Core.getSet(List.of(TRANSMITTED_TO_VISA));
    TRANSMITTED_TO_CONTROL.previous = Core.getSet(List.of(VISA_GRANTED));
    CONTROLLED.previous = Core.getSet(List.of(TRANSMITTED_TO_CONTROL));
    TRANSMITTED_TO_VALIDATION.previous = Core.getSet(List.of(CONTROLLED));
    VALIDATION_DELEGATED.previous = Core.getSet(List.of(TRANSMITTED_TO_VALIDATION));
    VALIDATED.previous = Core.getSet(List.of(TRANSMITTED_TO_VALIDATION, VALIDATION_DELEGATED));
  }
}
