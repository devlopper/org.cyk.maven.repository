package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de prise en
 * charge de ticket (compteur d'actions, y compris les reprises d'un même ticket).
 *
 * @author Christian
 */
public interface HasTicketClaimActionsCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'actions de prise en charge de ticket.
   *
   * @return le nombre cumulé d'actions de prise en charge de ticket
   */
  Integer getTicketClaimActionsCount();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'actions de prise en charge de ticket.
   *
   * @param ticketClaimActionsCount le nombre cumulé d'actions de prise en charge de ticket
   */
  void setTicketClaimActionsCount(Integer ticketClaimActionsCount);

  /**
   * Identifiant java du nombre cumulé d'actions de prise en charge de ticket.
   */
  String FIELD_TICKET_CLAIM_ACTIONS_COUNT = "ticketClaimActionsCount";
}
