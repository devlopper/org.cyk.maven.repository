package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimDocumentRuleService.ClaimDocumentRuleCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimDocumentRuleService.ClaimDocumentRuleGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimDocumentRuleService.ClaimDocumentRuleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimDocumentRuleService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimDocumentRuleClient extends AbstractClient<ClaimDocumentRuleService>
    implements GetByIdentifier<ClaimDocumentRuleDto>,
    GetMany<ClaimDocumentRuleGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimDocumentRuleClient service(ClaimDocumentRuleService service) {
    return (ClaimDocumentRuleClient) super.service(service);
  }

  /**
   * {@link ClaimDocumentRuleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimDocumentRuleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimDocumentRuleGetManyResponseDto>(
        ClaimDocumentRuleGetManyResponseDto.class,
        ClaimDocumentRuleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimDocumentRuleService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimDocumentRuleGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimDocumentRuleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimDocumentRuleCreateRequestDto request) {
    return new CreateExecutor(ClaimDocumentRuleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimDocumentRuleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimDocumentRuleUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimDocumentRuleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimDocumentRuleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimDocumentRuleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimDocumentRuleDto>(ClaimDocumentRuleDto.class,
        ClaimDocumentRuleService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimDocumentRuleService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimDocumentRuleDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimDocumentRuleService#getByIdentifier}.
   *
   * @param request requête
   * @return dépendance entre réclamables
   */
  public ClaimDocumentRuleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimDocumentRuleDto>(ClaimDocumentRuleDto.class,
        ClaimDocumentRuleService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimDocumentRuleService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimDocumentRuleDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimDocumentRuleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimDocumentRuleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimDocumentRuleService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
