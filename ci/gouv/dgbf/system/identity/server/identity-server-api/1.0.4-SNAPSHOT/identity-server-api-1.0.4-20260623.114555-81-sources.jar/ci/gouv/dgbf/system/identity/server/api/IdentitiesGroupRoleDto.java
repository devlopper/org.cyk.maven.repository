package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rôle de groupe d'identités.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentitiesGroupRoleDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Représentation en chaine de caractères {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;


  /**
   * Identifiant {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_IDENTIFIER)
  private String roleIdentifier;

  /**
   * Représentation en chaine de caractères {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_AS_STRING)
  private String roleAsString;


  /**
   * Identifiant JSON {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = "idRole";

  /**
   * Identifiant JSON {@link #roleAsString}.
   */
  public static final String JSON_ROLE_AS_STRING = "roleChaine";

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";

  /**
   * Identifiant JSON {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rôle de groupe d'identité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "rôles de groupe d'identité";
}
