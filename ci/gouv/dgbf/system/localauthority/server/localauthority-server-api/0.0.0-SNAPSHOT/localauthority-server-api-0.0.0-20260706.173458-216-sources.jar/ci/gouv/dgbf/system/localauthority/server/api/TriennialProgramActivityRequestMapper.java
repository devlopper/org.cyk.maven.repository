package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityService.TriennialProgramActivityCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityService.TriennialProgramActivityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TriennialProgramActivityDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TriennialProgramActivityDto}.

    @author Christian
               """)
public interface TriennialProgramActivityRequestMapper
    extends RequestMapper<TriennialProgramActivityDto, TriennialProgramActivityCreateRequestDto,
        TriennialProgramActivityUpdateRequestDto> {

}
