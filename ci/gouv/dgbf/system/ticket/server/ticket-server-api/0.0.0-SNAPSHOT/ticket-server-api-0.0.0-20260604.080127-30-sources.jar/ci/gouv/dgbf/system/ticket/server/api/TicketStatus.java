package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link TicketDto}.
 *
 * @author Arnaud
 *
 */
@Getter
public enum TicketStatus {

  /**
   * {@link TicketStatusCode#CREATED}.
   */
  CREATED(TicketStatusCode.CREATED, "Créé", "Création", "Créer", "Nouveau ticket"),

  /**
   * {@link TicketStatusCode#CLAIMED}.
   */
  CLAIMED(TicketStatusCode.CLAIMED, "Pris en charge", "Prise en charge", "Prendre en charge"),

  /**
   * {@link TicketStatusCode#RESOLVED}.
   */
  RESOLVED(TicketStatusCode.RESOLVED, "Résolu", "Résolution", "Résoudre"),

  /**
   * {@link TicketStatusCode#SATISFIED}.
   */
  SATISFIED(TicketStatusCode.SATISFIED, "Satisfait", "Satisfaction", "Satisfaire",
      "Oui, je suis satisfait"),

  /**
   * {@link TicketStatusCode#DISSATISFIED}.
   */
  DISSATISFIED(TicketStatusCode.DISSATISFIED, "Non satisfait", "Insatisfaction", "Insatisfaire",
      "Non, je ne suis pas satisfait"),

  /**
   * {@link TicketStatusCode#REDIRECTED}.
   */
  REDIRECTED(TicketStatusCode.REDIRECTED, "Redirigé", "Redirection", "Rediriger",
      "Réorienter vers un nouveau domaine"),

  /**
   * {@link TicketStatusCode#ESCALATED}.
   */
  ESCALATED(TicketStatusCode.ESCALATED, "Escaladé", "Escalade", "Escalader",
      "Solliciter le niveau supérieur");


  private TicketStatus(String code, String name, String actionName, String actionVerb,
      String actionLabel) {
    this.code = code;
    this.name = name;
    this.actionName = actionName;
    this.actionVerb = actionVerb;
    this.actionLabel = actionLabel;
  }

  private TicketStatus(String code, String name, String actionName, String actionVerb) {
    this(code, name, actionName, actionVerb, actionVerb);
  }

  private String code;
  private String name;
  private String actionName;
  private String actionVerb;
  private String actionLabel;
  private Set<TicketStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link TicketStatus} par code.
   *
   * @param code code
   * @return {@link TicketStatus}
   */
  public static TicketStatus getByCode(String code) {
    return Stream.of(TicketStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }

  static {
    CREATED.previous = Collections.emptySet();
    CLAIMED.previous = Core.getSet(List.of(CREATED, DISSATISFIED, REDIRECTED, ESCALATED));
    RESOLVED.previous = Core.getSet(List.of(CLAIMED));
    SATISFIED.previous = Core.getSet(List.of(RESOLVED));
    DISSATISFIED.previous = Core.getSet(List.of(RESOLVED));
    REDIRECTED.previous =
        Core.getSet(List.of(CREATED, CLAIMED, DISSATISFIED, REDIRECTED, ESCALATED));
    ESCALATED.previous = Core.getSet(List.of(CLAIMED, ESCALATED));
  }
}
