package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/** CRUD REST de la confidentialite par type de ressource. */
@Path(ResourceTypeConfidentialityService.PATH)
public interface ResourceTypeConfidentialityService extends SpecificService {
  String PATH = "type-ressource-confidentialite";
  String CREATE_IDENTIFIER = "CREATION_TYPE_RESSOURCE_CONFIDENTIALITE";
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_RESSOURCE_CONFIDENTIALITE";
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TYPE_RESSOURCE_CONFIDENTIALITE";
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TYPE_RESSOURCE_CONFIDENTIALITE";
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TYPE_RESSOURCE_CONFIDENTIALITE";
  String DELETE_IDENTIFIER = "SUPPRESSION_TYPE_RESSOURCE_CONFIDENTIALITE";

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response create(ResourceTypeConfidentialityCreateRequestDto request);

  @POST
  @Path("obtention/plusieurs")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getMany(GetManyRequestDto request);

  @POST
  @Path("obtention/un")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getOne(GetOneRequestDto request);

  @POST
  @Path("obtention/par-identifiant")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response update(ResourceTypeConfidentialityUpdateRequestDto request);

  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response delete(DeleteOneRequestDto request);

  /** Champs communs aux requetes d'enregistrement. */
  interface SaveRequest {
    ResourceType getResourceType();

    void setResourceType(ResourceType value);

    ConfidentialityLevel getConfidentialityLevel();

    void setConfidentialityLevel(ConfidentialityLevel value);
  }

  /** Requete de creation. */
  @Getter
  @Setter
  class ResourceTypeConfidentialityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SaveRequest {
    @JsonbProperty(ResourceTypeConfidentialityDto.JSON_RESOURCE_TYPE)
    private ResourceType resourceType;
    @JsonbProperty(ResourceTypeConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL)
    private ConfidentialityLevel confidentialityLevel;
  }

  /** Requete de mise a jour. */
  @Getter
  @Setter
  class ResourceTypeConfidentialityUpdateRequestDto extends ByIdentifierRequestDto
      implements SaveRequest {
    @JsonbProperty(ResourceTypeConfidentialityDto.JSON_RESOURCE_TYPE)
    private ResourceType resourceType;
    @JsonbProperty(ResourceTypeConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL)
    private ConfidentialityLevel confidentialityLevel;
  }

  /** Reponse paginee. */
  @Getter
  @Setter
  class ResourceTypeConfidentialityGetManyResponseDto
      extends AbstractGetByPageResponseDto<ResourceTypeConfidentialityDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ResourceTypeConfidentialityDto> datas;
  }
}
