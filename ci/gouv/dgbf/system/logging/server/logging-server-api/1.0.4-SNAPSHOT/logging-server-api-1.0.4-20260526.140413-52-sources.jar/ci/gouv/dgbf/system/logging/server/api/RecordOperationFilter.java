package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasProcessIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRecordIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasSourceIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RecordOperationDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class RecordOperationFilter extends AbstractIdentifiableFilter
    implements FilterHasProcessIdentifier, FilterHasSourceIdentifier, FilterHasRecordIdentifier,
    FilterHasUserName {

  private String processIdentifier;

  private String sourceIdentifier;

  private String recordIdentifier;

  private String userName;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RecordOperationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RecordOperationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateProcessIdentifier(filter);
    updateSourceIdentifier(filter);
    updateRecordIdentifier(filter);
    updateUserName(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterProcessIdentifier(filter);
    updateFilterSourceIdentifier(filter);
    updateFilterRecordIdentifier(filter);
    updateFilterUserName(filter);
  }

}
