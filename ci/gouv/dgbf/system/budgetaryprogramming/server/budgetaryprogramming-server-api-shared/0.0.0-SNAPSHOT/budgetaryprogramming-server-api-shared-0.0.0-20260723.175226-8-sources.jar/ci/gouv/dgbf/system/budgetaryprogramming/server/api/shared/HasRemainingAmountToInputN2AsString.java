package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN2AsString {

  /**
   * Obtient le montant restant à saisir pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant restant à saisir pour l'année N+2 sous forme de chaîne de caractères
   */
  String getRemainingAmountToInputN2AsString();

  /**
   * Définit le montant restant à saisir pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToInputN2AsString le montant restant à saisir pour l'année N+2 sous
   *        forme de chaîne de caractères
   */
  void setRemainingAmountToInputN2AsString(String remainingAmountToInputN2AsString);

  /**
   * Identifiant java du montant restant à saisir pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N2_AS_STRING =
      "remainingAmountToInputN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName