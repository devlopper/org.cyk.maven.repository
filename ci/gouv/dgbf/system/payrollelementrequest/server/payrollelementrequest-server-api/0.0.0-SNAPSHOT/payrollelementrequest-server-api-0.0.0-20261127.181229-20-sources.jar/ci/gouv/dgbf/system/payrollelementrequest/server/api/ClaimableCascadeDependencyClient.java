package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyResolveChildrenRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyResolveChildrenResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableCascadeDependencyService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableCascadeDependencyClient
    extends AbstractClient<ClaimableCascadeDependencyService>
    implements GetByIdentifier<ClaimableCascadeDependencyDto>,
    GetMany<ClaimableCascadeDependencyGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimableCascadeDependencyClient service(ClaimableCascadeDependencyService service) {
    return (ClaimableCascadeDependencyClient) super.service(service);
  }

  /**
   * {@link ClaimableCascadeDependencyService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableCascadeDependencyGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeDependencyGetManyResponseDto>(
        ClaimableCascadeDependencyGetManyResponseDto.class,
        ClaimableCascadeDependencyService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableCascadeDependencyGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableCascadeDependencyService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimableCascadeDependencyCreateRequestDto request) {
    return new CreateExecutor(ClaimableCascadeDependencyService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimableCascadeDependencyUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimableCascadeDependencyService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableCascadeDependencyDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeDependencyDto>(ClaimableCascadeDependencyDto.class,
        ClaimableCascadeDependencyService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableCascadeDependencyDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimableCascadeDependencyService#getByIdentifier}.
   *
   * @param request requête
   * @return cascade de réclamable
   */
  public ClaimableCascadeDependencyDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeDependencyDto>(ClaimableCascadeDependencyDto.class,
        ClaimableCascadeDependencyService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableCascadeDependencyDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimableCascadeDependencyService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimableCascadeDependencyService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ClaimableCascadeDependencyService#resolveChildren}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableCascadeDependencyResolveChildrenResponseDto resolveChildren(
      ClaimableCascadeDependencyResolveChildrenRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeDependencyResolveChildrenResponseDto>(
        ClaimableCascadeDependencyResolveChildrenResponseDto.class,
        ClaimableCascadeDependencyService.RESOLVE_CHILDREN_IDENTIFIER)
            .execute(() -> service().resolveChildren(request));
  }

  /**
   * {@link ClaimableCascadeDependencyService#resolveChildren}.
   *
   * @param parentClaimableIdentifier identifiant du Réclamable parent qui vient de changer
   * @param parentAuthorityCode code qui fait autorité sur ce Réclamable parent, {@code null} si
   *        sa valeur a été effacée
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableCascadeDependencyResolveChildrenResponseDto resolveChildren(
      String parentClaimableIdentifier, String parentAuthorityCode, String auditWho,
      String auditSession) {
    ClaimableCascadeDependencyResolveChildrenRequestDto request =
        new ClaimableCascadeDependencyResolveChildrenRequestDto();
    request.setParentClaimableIdentifier(parentClaimableIdentifier);
    request.setParentAuthorityCode(parentAuthorityCode);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return resolveChildren(request);
  }
}
