package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.GeographicZoneService.GeographicZoneCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.GeographicZoneService.GeographicZoneUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link GeographicZoneDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link LocalityDto}.

    @author arnaud
               """)
public interface GeographicZoneRequestMapper extends RequestMapper<GeographicZoneDto,
    GeographicZoneCreateRequestDto, GeographicZoneUpdateRequestDto> {

}
