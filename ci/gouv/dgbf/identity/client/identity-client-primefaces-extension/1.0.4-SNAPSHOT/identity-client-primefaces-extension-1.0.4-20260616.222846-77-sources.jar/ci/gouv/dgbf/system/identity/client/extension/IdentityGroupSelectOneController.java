package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<IdentityGroupDto,
        IdentityGroupGetManyResponseDto, IdentityGroupClient> {

  @Inject
  @Getter
  IdentityGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected IdentityGroupSelectOneController() {
    super(IdentityGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
