package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupService.FundGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupService.FundGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FundGroupDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FundGroupDto}.

    @author akm
               """)
public interface FundGroupRequestMapper
    extends RequestMapper<FundGroupDto, 
            FundGroupCreateRequestDto, FundGroupUpdateRequestDto> {

}
