package ci.gouv.dgbf.system.identity.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'identité.
 *
 * @author Christian
 */
public interface HasIdentityIdentifierDto extends HasIdentityIdentifier {

  /**
   * Identifiant json de l'identifiant de l'identité.
   */
  String JSON_IDENTITY_IDENTIFIER = "idIdentite";
}
