package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasPartitionAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link PartitionUnitDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionUnitController extends AbstractController {

  @Inject
  PartitionUnitClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  PartitionUnitRequestMapper requestMapper;

  @Inject
  @Getter
  PartitionSelectOneController partitionSelectOneController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  PartitionUnitFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = PartitionUnitDto.NAME;
  }
  
  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(PartitionUnitDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(PartitionUnitService.PATH);
    listController.setFilterController(filterController);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            PartitionUnitDto.JSON_NAME, HasPartitionAsStringDto.JSON_PARTITION_AS_STRING));

    listController.getDataTable().getFilterButton().setRendered(true);
    
    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      PartitionUnitCreateRequestDto request = requestMapper.mapCreate((PartitionUnitDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            PartitionUnitDto.JSON_NAME, PartitionUnitDto.JSON_PARTITION_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    partitionSelectOneController.getSelectOneMenu().addValueConsumer(partitionConsumer());
    nameInputTextController.initializeName(nameConsumer());
  }

  Consumer<String> partitionConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionUnitDto.class)
        .setPartitionIdentifier(identifier);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionUnitDto.class).setName(name);
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      partitionSelectOneController.getSelectOneMenu()
          .writeValue(((PartitionUnitDto) entity).getPartitionIdentifier());
      nameInputTextController.getInputText().writeValue(((PartitionUnitDto) entity).getName());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      PartitionUnitUpdateRequestDto request = requestMapper.mapUpdate((PartitionUnitDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(partitionSelectOneController.getSelectOneMenu(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
