package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationFunctionTypeService.RepresentationFunctionTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationFunctionTypeService.RepresentationFunctionTypeGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationFunctionTypeService.RepresentationFunctionTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un modèle de paie.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class RepresentationFunctionTypeClient extends 
    AbstractClient<RepresentationFunctionTypeService>
    implements GetByIdentifier<RepresentationFunctionTypeDto>, 
    GetMany<RepresentationFunctionTypeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public RepresentationFunctionTypeClient service(RepresentationFunctionTypeService service) {
    return (RepresentationFunctionTypeClient) super.service(service);
  }

  /**
   * {@link RepresentationFunctionTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(RepresentationFunctionTypeCreateRequestDto request) {
    return new CreateExecutor(RepresentationFunctionTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RepresentationFunctionTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RepresentationFunctionTypeGetManyResponseDto>(
        RepresentationFunctionTypeGetManyResponseDto.class, 
            RepresentationFunctionTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RepresentationFunctionTypeGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RepresentationFunctionTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public RepresentationFunctionTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<RepresentationFunctionTypeDto>(RepresentationFunctionTypeDto.class,
        RepresentationFunctionTypeService.GET_ONE_IDENTIFIER).execute(() -> service()
            .getOne(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RepresentationFunctionTypeDto getOne(ProjectionDto projection, FilterDto filter, 
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link RepresentationFunctionTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public RepresentationFunctionTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<RepresentationFunctionTypeDto>(RepresentationFunctionTypeDto.class,
        RepresentationFunctionTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RepresentationFunctionTypeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link RepresentationFunctionTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(RepresentationFunctionTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(RepresentationFunctionTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(RepresentationFunctionTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link RepresentationFunctionTypeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
