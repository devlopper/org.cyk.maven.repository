package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroupfield;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneRadioBoolean;
import ci.gouv.dgbf.extension.primefaces.component.input.ValueTypeSelectOneController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldRequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldService;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldService.DocumentTypeGroupFieldCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldService.DocumentTypeGroupFieldUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DocumentTypeGroupFieldDto}.
 *
 * <p>Pas d'écran ni de menu autonome : uniquement utilisé depuis l'onglet "Champs" de la lecture
 * du {@link ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto} auquel ces champs
 * appartiennent (voir {@code DocumentTypeGroupReadFieldsPage}).
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentTypeGroupFieldController extends AbstractController {

  @Inject
  DocumentTypeGroupFieldClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  DocumentTypeGroupFieldRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  ValueTypeSelectOneController valueTypeSelectOneController;

  @Inject
  @Getter
  SelectBooleanController requiredSelectBooleanController;

  @Inject
  @Getter
  DocumentTypeGroupFieldFilterController filterController;

  /**
   * Cette méthode permet d'initialiser, une fois {@link #filterController} configuré avec
   * l'identifiant du {@link ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto}
   * dont les champs sont listés.
   */
  public void initialize() {
    name = DocumentTypeGroupFieldDto.NAME;

    listController.setEntityClass(DocumentTypeGroupFieldDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DocumentTypeGroupFieldService.PATH);
    listController.setFilterController(filterController);
    listController.getDataTable().getFilterButton().setRendered(false);

    ProjectionDto projection = new ProjectionDto();
    // JSON_VALUE_TYPE (valeur de l'énumération) est nécessaire en plus du libellé affiché : le
    // formulaire de modification relit dto.getValueType() pour pré-sélectionner le type de valeur.
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, HasCodeDto.JSON_CODE,
        HasNameDto.JSON_NAME, DocumentTypeGroupFieldDto.JSON_VALUE_TYPE,
        DocumentTypeGroupFieldDto.JSON_VALUE_TYPE_AS_STRING,
        DocumentTypeGroupFieldDto.JSON_REQUIRED);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().setFunction(createControllerFunction());

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    valueTypeSelectOneController.getSelectOneMenu().addValueConsumer(valueTypeConsumer());

    requiredSelectBooleanController.setOutputLableValue("Obligatoire");
    SelectOneRadioBoolean requiredRadio =
        requiredSelectBooleanController.getSelectOneRadioBoolean();
    requiredRadio.addTrueOrFalseChoices();
    requiredRadio.addValueConsumer(requiredConsumer());
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupFieldDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupFieldDto.class)
        .setName(name);
  }

  Consumer<String> valueTypeConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupFieldDto.class)
        .setValueType(value == null ? null : ValueType.valueOf(value));
  }

  Consumer<Boolean> requiredConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupFieldDto.class)
        .setRequired(value);
  }

  Function<Object, Object> createControllerFunction() {
    return entity -> {
      DocumentTypeGroupFieldDto dto = (DocumentTypeGroupFieldDto) entity;
      dto.setTypeGroupIdentifier(filterController.getFilter().getTypeGroupIdentifier());
      DocumentTypeGroupFieldCreateRequestDto request = requestMapper.mapCreate(dto);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      DocumentTypeGroupFieldDto dto = (DocumentTypeGroupFieldDto) entity;
      codeInputTextController.getInputText().writeValue(dto.getCode());
      nameInputTextController.getInputText().writeValue(dto.getName());
      valueTypeSelectOneController.getSelectOneMenu()
          .writeValue(dto.getValueType() == null ? null : dto.getValueType().name());
      requiredSelectBooleanController.getSelectOneRadioBoolean().writeValue(dto.getRequired());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      DocumentTypeGroupFieldDto dto = (DocumentTypeGroupFieldDto) entity;
      dto.setTypeGroupIdentifier(filterController.getFilter().getTypeGroupIdentifier());
      DocumentTypeGroupFieldUpdateRequestDto request = requestMapper.mapUpdate(dto);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return Stream
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            valueTypeSelectOneController.getSelectOneMenu(),
            requiredSelectBooleanController.getSelectOneRadioBoolean())
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
