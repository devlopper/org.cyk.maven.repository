package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Passage du {@link SupportingDocumentNatureDto} de l'écran aux requêtes du service.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-08T21:37:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupportingDocumentNatureRequestMapperImpl implements SupportingDocumentNatureRequestMapper {

    @Override
    public SupportingDocumentNatureService.SupportingDocumentNatureCreateRequestDto mapCreate(SupportingDocumentNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportingDocumentNatureService.SupportingDocumentNatureCreateRequestDto supportingDocumentNatureCreateRequestDto = new SupportingDocumentNatureService.SupportingDocumentNatureCreateRequestDto();

        supportingDocumentNatureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportingDocumentNatureCreateRequestDto.setCode( arg0.getCode() );
        supportingDocumentNatureCreateRequestDto.setName( arg0.getName() );
        supportingDocumentNatureCreateRequestDto.setElementType( arg0.getElementType() );
        supportingDocumentNatureCreateRequestDto.setMovementTypeCode( arg0.getMovementTypeCode() );
        supportingDocumentNatureCreateRequestDto.setMandatory( arg0.getMandatory() );
        supportingDocumentNatureCreateRequestDto.setActive( arg0.getActive() );

        return supportingDocumentNatureCreateRequestDto;
    }

    @Override
    public SupportingDocumentNatureService.SupportingDocumentNatureUpdateRequestDto mapUpdate(SupportingDocumentNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportingDocumentNatureService.SupportingDocumentNatureUpdateRequestDto supportingDocumentNatureUpdateRequestDto = new SupportingDocumentNatureService.SupportingDocumentNatureUpdateRequestDto();

        supportingDocumentNatureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportingDocumentNatureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportingDocumentNatureUpdateRequestDto.setCode( arg0.getCode() );
        supportingDocumentNatureUpdateRequestDto.setName( arg0.getName() );
        supportingDocumentNatureUpdateRequestDto.setElementType( arg0.getElementType() );
        supportingDocumentNatureUpdateRequestDto.setMovementTypeCode( arg0.getMovementTypeCode() );
        supportingDocumentNatureUpdateRequestDto.setMandatory( arg0.getMandatory() );
        supportingDocumentNatureUpdateRequestDto.setActive( arg0.getActive() );

        return supportingDocumentNatureUpdateRequestDto;
    }
}
