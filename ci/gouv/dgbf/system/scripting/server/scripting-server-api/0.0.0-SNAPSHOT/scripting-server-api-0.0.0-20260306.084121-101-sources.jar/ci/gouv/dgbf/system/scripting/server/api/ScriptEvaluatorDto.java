package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un évaluateur de {@link ScriptDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptEvaluatorDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nom du moteur.
   */
  @JsonbProperty(JSON_ENGINE_NAME)
  private String engineName;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEvaluateurScript";
  
  /**
   * Identifiant json du code.
   */
  public static final String JSON_THIS_CODE = "codeEvaluateurScript";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "evaluateurScriptChaine";
  
  /**
   * Identifiant json {@link #engineName}.
   */
  public static final String JSON_ENGINE_NAME = "nomMoteur";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "évaluateur de script";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "évaluateurs de script";
}
