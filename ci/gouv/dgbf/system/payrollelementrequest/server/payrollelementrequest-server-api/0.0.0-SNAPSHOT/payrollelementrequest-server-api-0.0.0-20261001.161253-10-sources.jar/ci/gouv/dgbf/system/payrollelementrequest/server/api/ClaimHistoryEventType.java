package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import lombok.Getter;

/**
 * Cette énumération représente le discriminant d'une ligne de {@link ClaimHistoryDto} (R47,
 * RG_REP_TRA_02, RG_REP_STA_04) : changement de statut, ou Suspension/Reprise orthogonale au
 * statut.
 *
 * @author akm
 *
 */
@Getter
public enum ClaimHistoryEventType {

  /**
   * Changement de statut.
   */
  STATUS_CHANGE("CHANGEMENT_STATUT", "Changement de statut"),

  /**
   * Suspension.
   */
  SUSPENSION("SUSPENSION", "Suspension"),

  /**
   * Reprise.
   */
  RESUME("REPRISE", "Reprise");

  private final String code;
  private final String name;

  ClaimHistoryEventType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link ClaimHistoryEventType} par code.
   *
   * @param code code
   * @return {@link ClaimHistoryEventType}, {@code null} si aucun ne correspond
   */
  public static ClaimHistoryEventType getByCode(String code) {
    for (ClaimHistoryEventType type : values()) {
      if (type.code.equals(code)) {
        return type;
      }
    }
    return null;
  }
}
