package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BudgetAdministrativeUnitStaffDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = BudgetAdministrativeUnitStaffService.PATH)
@Tag(name = "Gestion des effectifs d'unité administrative")
public interface BudgetAdministrativeUnitStaffService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "effectifs-unites-administratives";

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface SaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de unité administrative.
     *
     * @return identifiant de unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de unité administrative.
     *
     * @param identifier identifiant de unité administrative
     */
    void setAdministrativeUnitIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
     *
     * @return identifiant {@link BudgetDto}
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
     *
     * @param identifier identifiant {@link BudgetDto}
     */
    void setBudgetIdentifier(String identifier);
    
    /**
     * Cette méthode permet d'obtenir l'identifiant de l'emploi.
     *
     * @return identifiant de l'emploi
     */
    String getJobIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'emploi.
     *
     * @param identifier identifiant de l'emploi
     */
    void setJobIdentifier(String identifier);
    
    /**
     * Cette méthode permet d'obtenir la compétence.
     *
     * @return competence
     */
    String getCompetence();

    /**
     * Cette méthode permet d'assigner la compétence.
     *
     * @param competence la competence
     */
    void setCompetence(String competence);
    
    /**
     * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
     *
     * @return identifiant {@link BudgetDto}
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
     *
     * @param identifier identifiant {@link BudgetDto}
     */
    void setCategoryIdentifier(String identifier);
    
    /**
     * Cette méthode permet d'obtenir si l'effectif est fonctionnaire.
     *
     * @return est fonctionnaire
     */
    Boolean getIsFunctionary();

    /**
     * Cette méthode permet d'assigner l'effectif.
     *
     * @param isFunctionary est fonctionnaire
     */
    void setIsFunctionary(Boolean isFunctionary);
    
    /**
     * Cette méthode permet d'obtenir l'effectif.
     *
     * @return l'effectif
     */
    Integer getStaff();

    /**
     * Cette méthode permet d'assigner l'effectif.
     *
     * @param staff effectif
     */
    void setStaff(Integer staff);
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        BudgetAdministrativeUnitStaffDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_BUDGET_IDENTIFIER}.
     */
    String JSON_BUDGET_IDENTIFIER = BudgetAdministrativeUnitStaffDto.JSON_BUDGET_IDENTIFIER;
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_JOB_IDENTIFIER}.
     */
    String JSON_JOB_IDENTIFIER = BudgetAdministrativeUnitStaffDto.JSON_JOB_IDENTIFIER;
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_COMPETENCE}.
     */
    String JSON_COMPETENCE = BudgetAdministrativeUnitStaffDto.JSON_COMPETENCE;
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_CATEGORY_IDENTIFIER}.
     */
    String JSON_CATEGORY_IDENTIFIER = BudgetAdministrativeUnitStaffDto.JSON_CATEGORY_IDENTIFIER;
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_IS_FUNCTIONARY}.
     */
    String JSON_IS_FUNCTIONARY = BudgetAdministrativeUnitStaffDto.JSON_IS_FUNCTIONARY;
    
    /**
     * {@link BudgetAdministrativeUnitStaffDto#JSON_STAFF}.
     */
    String JSON_STAFF = BudgetAdministrativeUnitStaffDto.JSON_STAFF;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EFFECTIF_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BudgetAdministrativeUnitStaffCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class BudgetAdministrativeUnitStaffCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SaveRequestDto {
    
    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;
    
    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;
    
    @JsonbProperty(JSON_COMPETENCE)
    String competence;
    
    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    String categoryIdentifier;
    
    @JsonbProperty(JSON_IS_FUNCTIONARY)
    Boolean isFunctionary;
    
    @JsonbProperty(JSON_STAFF)
    Integer staff;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EFFECTIF_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = 
              BudgetAdministrativeUnitStaffGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class BudgetAdministrativeUnitStaffGetManyResponseDto 
          extends AbstractGetByPageResponseDto<BudgetAdministrativeUnitStaffDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BudgetAdministrativeUnitStaffDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EFFECTIF_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = 
          @Schema(implementation = BudgetAdministrativeUnitStaffDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EFFECTIF_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = 
          @Schema(implementation = BudgetAdministrativeUnitStaffDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EFFECTIF_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BudgetAdministrativeUnitStaffUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class BudgetAdministrativeUnitStaffUpdateRequestDto extends ByIdentifierRequestDto 
          implements SaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;
    
    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;
    
    @JsonbProperty(JSON_COMPETENCE)
    String competence;
    
    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    String categoryIdentifier;
    
    @JsonbProperty(JSON_IS_FUNCTIONARY)
    Boolean isFunctionary;
    
    @JsonbProperty(JSON_STAFF)
    Integer staff;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MOUVEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
