package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.BudgetActivityService.BudgetActivityCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.BudgetActivityService.BudgetActivityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BudgetActivityDto}.
 *
 * @author Donsylla
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BudgetActivityDto}.

    @author Donsylla
               """)
public interface BudgetActivityRequestMapper extends RequestMapper<BudgetActivityDto,
    BudgetActivityCreateRequestDto, BudgetActivityUpdateRequestDto> {

}
