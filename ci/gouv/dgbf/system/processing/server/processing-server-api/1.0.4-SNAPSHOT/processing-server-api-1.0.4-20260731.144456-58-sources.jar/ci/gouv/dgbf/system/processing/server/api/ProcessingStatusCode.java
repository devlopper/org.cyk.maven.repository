package ci.gouv.dgbf.system.processing.server.api;

/**
 * Cette classe représente les codes de {@link ProcessingStatus}.
 *
 * @author Christian
 *
 */
public class ProcessingStatusCode {

  private ProcessingStatusCode() {
    
  }
  
  /**
   * Créé.
   */
  public static final String CREATED = "CREE";
  
  /**
   * Démarré.
   */
  public static final String STARTED = "DEMARRE";
  
  /**
   * Arrêté.
   */
  public static final String STOPPED = "ARRETE";
  
  /**
   * Terminé.
   */
  public static final String TERMINATED = "TERMINE";
  
  /**
   * Annulé.
   */
  public static final String CANCELLED = "ANNULE";
}
