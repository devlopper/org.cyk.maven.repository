package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartDataSet;
import org.primefaces.model.charts.line.LineChartDataSet;
import org.primefaces.model.charts.line.LineChartModel;
import org.primefaces.model.charts.line.LineChartOptions;

/**
 * Cette classe représente une courbe.
 *
 * @author Christian
 *
 */
public class LineChart extends AbstractChart<LineChartModel> {

  public LineChart() {
    contentFilePath = Constant.SLASH + "extension/component/chart/line/default.xhtml";
  }

  /**
   * Cette classe représentente un constructeur de modèle.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class ModelBuilder
      extends AbstractModelBuilder<LineChartModel, LineChartOptions, LineChart> {

    @SuppressWarnings("unchecked")
    @Override
    ChartDataSet instantiateCharDataSet(ChartDataSetDto dto, int dtosCount,
        AtomicInteger dtoIndex) {
      LineChartDataSet chartDataSet = new LineChartDataSet();
      chartDataSet.setData((List<Object>) (List<?>) dto.getDatasNumbers());
      styleDataSet(chartDataSet, dtoIndex.intValue());
      return chartDataSet;
    }

    @Override
    LineChartModel instantateModel() {
      return new LineChartModel();
    }

    @Override
    void processModel(LineChartModel model, ChartData chartData) {
      model.setData(chartData);
    }

    @Override
    LineChartOptions instantateOptions() {
      return new LineChartOptions();
    }

    @Override
    void processOptions(LineChartModel model, ChartData chartData, LineChartOptions options) {
      model.setOptions(options);
    }

    void styleDataSet(LineChartDataSet chartDataSet, int index) {
      chartDataSet.setFill(false);
      chartDataSet.setBorderColor(colorPalette.getRgbAt(index));
      chartDataSet.setTension(0.1);
    }
  }

  /**
   * Cette méthode permet de créer et d'obtenir {@link Builder}.
   *
   * @return {@link Builder}
   */
  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représentente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder
      extends AbstractBuilder<LineChartModel, LineChartOptions, ModelBuilder, LineChart> {

    @Override
    protected LineChart instantiateWidget() {
      return new LineChart();
    }
  }
}
