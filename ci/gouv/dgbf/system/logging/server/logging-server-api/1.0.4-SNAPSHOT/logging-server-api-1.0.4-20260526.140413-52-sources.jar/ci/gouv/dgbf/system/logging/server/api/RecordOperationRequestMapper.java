package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RecordOperationDto}.
 *
 * @author Arnaud
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RecordOperationDto}.

    @author Arnaud
    """)
public interface RecordOperationRequestMapper extends
        RequestMapper<RecordOperationDto,
    RecordOperationService.RecordOperationCreateRequestDto, 
    RecordOperationService.RecordOperationUpdateRequestDto> {

}
