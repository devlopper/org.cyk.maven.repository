package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-11T17:30:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentGroupRequestMapperImpl implements DocumentGroupRequestMapper {

    @Override
    public DocumentGroupService.DocumentGroupCreateRequestDto mapCreate(DocumentGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentGroupService.DocumentGroupCreateRequestDto documentGroupCreateRequestDto = new DocumentGroupService.DocumentGroupCreateRequestDto();

        documentGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentGroupCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        documentGroupCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        documentGroupCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        documentGroupCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        documentGroupCreateRequestDto.setTypeGroupIdentifier( arg0.getTypeGroupIdentifier() );

        return documentGroupCreateRequestDto;
    }

    @Override
    public DocumentGroupService.DocumentGroupUpdateRequestDto mapUpdate(DocumentGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentGroupService.DocumentGroupUpdateRequestDto documentGroupUpdateRequestDto = new DocumentGroupService.DocumentGroupUpdateRequestDto();

        documentGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentGroupUpdateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        documentGroupUpdateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        documentGroupUpdateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        documentGroupUpdateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        documentGroupUpdateRequestDto.setTypeGroupIdentifier( arg0.getTypeGroupIdentifier() );

        return documentGroupUpdateRequestDto;
    }
}
