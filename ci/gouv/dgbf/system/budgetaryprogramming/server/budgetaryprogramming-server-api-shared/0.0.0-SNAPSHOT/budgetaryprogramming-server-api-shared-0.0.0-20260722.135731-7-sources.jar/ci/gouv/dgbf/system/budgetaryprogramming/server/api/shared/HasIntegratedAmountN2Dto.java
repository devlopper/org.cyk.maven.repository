package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasIntegratedAmountN2}.
 *
 * @author Christian
 */
public interface HasIntegratedAmountN2Dto extends HasIntegratedAmountN2 {

  /**
   * Identifiant json du montant intégré à l'horizon N2.
   */
  String JSON_INTEGRATED_AMOUNT_N2 = "montantIntegreN2";
}
