package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste des fichiers.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FileListPage extends AbstractPage {

  @Inject
  @Getter
  FileController controller;

  @Inject
  @Getter
  OpenFileViewerButtonController openViewerButtonController;

  @Inject
  @Getter
  FileCollectionTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste des fichiers";

    tabMenuController.initialize();
  }
  
  public static final String OUTCOME = "fileListPage";
  public static final String OUTCOME_WITHOUT_TEMPLATE = "fileListWithoutTemplatePage";
}
