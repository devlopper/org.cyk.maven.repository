package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de {@link UsersGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UsersGroupTabMenuController extends AbstractController {

  @Getter
  TabMenu menu;

  @Inject
  IconManager iconManager;

  @Getter
  UsersGroupDto usersGroup;

  /**
   * Cette méthode permet de construire.
   */
  protected UsersGroupTabMenuController() {
    menu = new TabMenu();
    menu.setMenuItemStyleClassPrefix("usersGroupDto");
    menu.getOutcomesMap().put(UserGroupListPage.class, UsersGroupReadUsersPage.OUTCOME);
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    menu.tabBuilder().menuItemValue("Utilisateurs")
        .menuItemIcon(iconManager.getUser()).type(UserGroupListPage.class)
        .addMenuItemParameter(requestParameterIdentifierName, usersGroup.getIdentifier())
        .build();
    menu.initialize();
  }

}
