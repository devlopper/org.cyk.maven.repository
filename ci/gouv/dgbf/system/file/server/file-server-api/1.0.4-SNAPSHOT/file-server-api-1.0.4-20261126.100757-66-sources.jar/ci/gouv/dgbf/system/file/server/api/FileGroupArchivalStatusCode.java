package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileGroupArchivalStatus}.
 *
 * @author Christian
 *
 */
public class FileGroupArchivalStatusCode {

  private FileGroupArchivalStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Accepté.
   */
  public static final String ACCEPTED = "ACCEPTE";

  /**
   * Refusé.
   */
  public static final String REFUSED = "REFUSE";

  /**
   * Annulé.
   */
  public static final String CANCELLED = "ANNULE";
}
