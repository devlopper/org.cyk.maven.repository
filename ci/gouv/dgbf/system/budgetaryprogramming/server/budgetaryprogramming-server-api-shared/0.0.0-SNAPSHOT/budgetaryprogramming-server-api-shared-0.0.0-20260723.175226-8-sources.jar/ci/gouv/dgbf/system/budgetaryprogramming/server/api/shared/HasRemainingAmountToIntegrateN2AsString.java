package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateN2AsString {

  /**
   * Obtient le montant restant à intégrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant restant à intégrer pour l'année N+2 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToIntegrateN2AsString();

  /**
   * Définit le montant restant à intégrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToIntegrateN2AsString le montant restant à intégrer pour l'année N+2
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToIntegrateN2AsString(String remainingAmountToIntegrateN2AsString);

  /**
   * Identifiant java du montant restant à intégrer pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INTEGRATE_N2_AS_STRING =
      "remainingAmountToIntegrateN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName