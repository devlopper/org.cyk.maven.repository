package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTabMenuController;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.system.identity.server.api.AbstractIdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;

/**
 * Cette classe représente le contrôleur de {@link TabMenu} de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityTabMenuController extends AbstractTabMenuController {

  @Inject
  IdentityClient client;

  String isRegistrationNumberGroupPublicFunctionParameterName;

  /**
   * Cette méthode permet de construire.
   */
  public IdentityTabMenuController() {
    addListPage();
    isRegistrationNumberGroupPublicFunctionParameterName =
        AbstractIdentityFilter.JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION;
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();
    IdentityFilter identityFilter = new IdentityFilter();
    identityFilter.setIsRegistrationNumberGroupPublicFunction(true);

    GetCountRequestDto getCountRequestDto = new GetCountRequestDto();
    getCountRequestDto.useFilter(identityFilter);
    getCountRequestDto.setAuditWho(userIdentifier);
    client.getCount(getCountRequestDto);

    identityFilter.setIsRegistrationNumberGroupPublicFunction(true);
    getCountRequestDto.useFilter(identityFilter);
    menu.tabBuilder().type(listPageTabMenuType).menuItemValue("Fonctionnaire")
        .menuItemIcon("pi pi-building").count(String.valueOf(client.getCount(getCountRequestDto)))
        .addMenuItemParameter(isRegistrationNumberGroupPublicFunctionParameterName,
            identityFilter.getIsRegistrationNumberGroupPublicFunction())
        .build();

    identityFilter.setIsRegistrationNumberGroupPublicFunction(false);
    getCountRequestDto.useFilter(identityFilter);
    menu.tabBuilder().type(listPageTabMenuType).menuItemValue("Non Fonctionnaire")
        .menuItemIcon("pi pi-user").count(String.valueOf(client.getCount(getCountRequestDto)))
        .addMenuItemParameter(isRegistrationNumberGroupPublicFunctionParameterName,
            identityFilter.getIsRegistrationNumberGroupPublicFunction())
        .build();

    identityFilter.setIsRegistrationNumberGroupPublicFunction(null);
    getCountRequestDto.useFilter(identityFilter);
    menu.tabBuilder().type(listPageTabMenuType).menuItemValue("Tout").menuItemIcon("pi pi-users")
        .count(String.valueOf(client.getCount(getCountRequestDto)))
        .addMenuItemParameter(isRegistrationNumberGroupPublicFunctionParameterName,
            identityFilter.getIsRegistrationNumberGroupPublicFunction())
        .build();
  }

}
