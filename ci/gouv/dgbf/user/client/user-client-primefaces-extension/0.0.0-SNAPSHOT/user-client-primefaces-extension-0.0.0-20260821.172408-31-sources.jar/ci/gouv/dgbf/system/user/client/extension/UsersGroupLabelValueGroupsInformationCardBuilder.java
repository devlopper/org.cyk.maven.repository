package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Builder de carte d'information ({@link LabelValueGroupsInformationCard}) pour les données
 * affichées côté IHM des {@link UsersGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class UsersGroupLabelValueGroupsInformationCardBuilder {

  IconManager iconManager;

  String code;

  String name;

  String module;

  /**
   * Cette méthode permet de construire.
   *
   * @param iconManager {@link IconManager}
   */
  public UsersGroupLabelValueGroupsInformationCardBuilder(IconManager iconManager) {
    this.iconManager = iconManager;
  }

  /**
   * Cette méthode permet de construire.
   *
   * @return {@link LabelValueGroupsInformationCard}
   */
  public LabelValueGroupsInformationCard build() {
    LabelValueGroupsInformationCard card = new LabelValueGroupsInformationCard();
    card.getHeaderText().setValue("Propriétés");
    LabelValueGroupsInformationCard.Group group = card.group();

    group.add("Code", code).add("Libellé", name).add("Module", module);

    return card;
  }
}
