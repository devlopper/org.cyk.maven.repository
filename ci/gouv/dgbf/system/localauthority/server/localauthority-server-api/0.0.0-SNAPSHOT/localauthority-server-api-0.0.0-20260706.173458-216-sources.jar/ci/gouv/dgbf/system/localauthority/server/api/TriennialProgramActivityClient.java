package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityService.TriennialProgramActivityCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityService.TriennialProgramActivityGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityService.TriennialProgramActivityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TriennialProgramActivityService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TriennialProgramActivityClient extends AbstractClient<TriennialProgramActivityService>
    implements GetByIdentifier<TriennialProgramActivityDto>,
    GetMany<TriennialProgramActivityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public TriennialProgramActivityClient service(TriennialProgramActivityService service) {
    return (TriennialProgramActivityClient) super.service(service);
  }

  /**
   * {@link TriennialProgramActivityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(TriennialProgramActivityCreateRequestDto request) {
    return new CreateExecutor(TriennialProgramActivityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TriennialProgramActivityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramActivityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TriennialProgramActivityGetManyResponseDto>(
        TriennialProgramActivityGetManyResponseDto.class,
        TriennialProgramActivityService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link TriennialProgramActivityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TriennialProgramActivityGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TriennialProgramActivityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramActivityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TriennialProgramActivityDto>(TriennialProgramActivityDto.class,
        TriennialProgramActivityService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link TriennialProgramActivityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TriennialProgramActivityDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TriennialProgramActivityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public TriennialProgramActivityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TriennialProgramActivityDto>(TriennialProgramActivityDto.class,
        TriennialProgramActivityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TriennialProgramActivityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TriennialProgramActivityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TriennialProgramActivityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(TriennialProgramActivityUpdateRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramActivityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TriennialProgramActivityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramActivityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link TriennialProgramActivityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
