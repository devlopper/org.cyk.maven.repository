package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityAsStringDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un consentement d'identité à une version de politique.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityPolicyConsentDto extends AbstractIdentifiableAuditableDto
    implements HasIdentityIdentifierDto, HasIdentityAsStringDto,
    HasStatusDto<IdentityPolicyConsentStatus>, HasStatusAsStringDto {

  @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;

  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;

  /**
   * Identifiant de la version de politique.
   */
  @JsonbProperty(JSON_POLICY_VERSION_IDENTIFIER)
  private String policyVersionIdentifier;

  /**
   * Représentation en chaine de caractères de la version de politique.
   */
  @JsonbProperty(JSON_POLICY_VERSION_AS_STRING)
  private String policyVersionAsString;

  @JsonbProperty(JSON_STATUS)
  private IdentityPolicyConsentStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant json pour {@link #policyVersionIdentifier}.
   */
  public static final String JSON_POLICY_VERSION_IDENTIFIER = "idVersionPolitique";

  /**
   * Identifiant json pour {@link #policyVersionAsString}.
   */
  public static final String JSON_POLICY_VERSION_AS_STRING = "versionPolitiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "consentement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "consentements";
}
