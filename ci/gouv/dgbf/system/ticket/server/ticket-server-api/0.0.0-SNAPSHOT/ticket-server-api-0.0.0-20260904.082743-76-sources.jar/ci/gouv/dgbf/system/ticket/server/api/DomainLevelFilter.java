package ci.gouv.dgbf.system.ticket.server.api;


import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasSupportTeamIdentifier;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUsersGroupIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DomainLevelDto}.
 *
 * @author kimou
 *
 */
@Getter
@Setter
public class DomainLevelFilter extends AbstractIdentifiableFilter
    implements FilterHasSupportTeamIdentifier, FilterHasUsersGroupIdentifier {

  private String supportTeamIdentifier;

  /**
   * Ancien identifiant du groupe d'utilisateurs, avant TCH_TK_556.
   *
   * @deprecated remplacé par {@link #supportTeamIdentifier}. Conservé pour ne pas casser la
   *             compilation de ticket-server-impl-quarkus/ticket-client-quarkus-primefaces tant
   *             qu'ils ne sont pas migrés.
   */
  @Deprecated
  private String usersGroupIdentifier;

  /**
   * Cette méthode permet de construire.
   *
   * @param dto {@link FilterDto}
   */
  public DomainLevelFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet de construire.
   */
  public DomainLevelFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateSupportTeamIdentifier(filter);
    updateUsersGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterSupportTeamIdentifier(filter);
    updateUsersGroupIdentifier(filter);
  }

}

