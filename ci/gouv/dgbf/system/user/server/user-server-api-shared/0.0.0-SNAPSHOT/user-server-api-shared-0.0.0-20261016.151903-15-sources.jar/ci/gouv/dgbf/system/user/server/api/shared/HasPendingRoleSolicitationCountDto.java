package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de demandes de rôle en attente.
 *
 * @author Christian Yao Komenan
 */
public interface HasPendingRoleSolicitationCountDto extends HasPendingRoleSolicitationCount {

  /**
   * Identifiant json du nombre de demandes de rôle en attente.
   */
  String JSON_PENDING_ROLE_SOLICITATION_COUNT = "nombreDemandesRoleEnAttente";
}
