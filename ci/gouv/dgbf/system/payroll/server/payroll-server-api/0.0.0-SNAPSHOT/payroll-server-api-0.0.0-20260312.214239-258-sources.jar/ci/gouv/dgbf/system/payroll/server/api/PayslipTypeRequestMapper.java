package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipTypeService.PayslipTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipTypeService.PayslipTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipTypeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipTypeDto}.

    @author Christian
               """)
public interface PayslipTypeRequestMapper extends RequestMapper<PayslipTypeDto,
    PayslipTypeCreateRequestDto, PayslipTypeUpdateRequestDto> {

}
