package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;
import java.util.List;

/**
 * Cette interface représente une classe qui a des adresses de destinataire.
 *
 * @author Christian
 */
public interface HasReceiverAddresses extends HasField {

  /**
   * Cette méthode permet d'obtenir les adresses des destinataires.
   *
   * @return les adresses des destinataires
   */
  List<String> getReceiverAddresses();

  /**
   * Cette méthode permet d'assigner l'adresse du destinataire.
   *
   * @param receiverAddresses les adresses des destinataires
   */
  void setReceiverAddress(List<String> receiverAddresses);

  /**
   * Identifiant java des adresses des destinataires.
   */
  String FIELD_RECEIVER_ADDRESSES = "receiverAddresses";
}
