package ci.gouv.dgbf.system.user.server.api;

import java.util.Set;

/**
 * Cette classe regroupe les codes des Rôles réservés (RG_UTI_ROL_07) : rôles d'administration
 * liés à un objet, créés par le système. {@link #DOMAIN_ADMINISTRATOR} est porté par
 * l'Application spéciale d'un Domaine ; les trois autres par chaque Application métier. Partagés
 * par le serveur et le frontal, qui en déduisent les Droits ({@link UserRole}, RG_UTI_ROL_16).
 *
 * @author Christian Yao Komenan
 */
public final class ReservedRole {

  /**
   * Code du Rôle réservé de l'Administrateur de Domaine.
   */
  public static final String DOMAIN_ADMINISTRATOR = "ADMINISTRATEUR_DOMAINE";

  /**
   * Code du Rôle réservé de l'Administrateur Applicatif.
   */
  public static final String APPLICATION_ADMINISTRATOR = "ADMINISTRATEUR_APPLICATIF";

  /**
   * Code du Rôle réservé de l'Administrateur Technique.
   */
  public static final String TECHNICAL_ADMINISTRATOR = "ADMINISTRATEUR_TECHNIQUE";

  /**
   * Code du Rôle réservé de l'Administrateur Fonctionnel.
   */
  public static final String FUNCTIONAL_ADMINISTRATOR = "ADMINISTRATEUR_FONCTIONNEL";

  /**
   * Codes de tous les Rôles réservés : ils se désignent et ne s'attribuent jamais par
   * l'attribution générique ni par une demande de rôle (RG_UTI_ROL_17).
   */
  public static final Set<String> CODES = Set.of(DOMAIN_ADMINISTRATOR, APPLICATION_ADMINISTRATOR,
      TECHNICAL_ADMINISTRATOR, FUNCTIONAL_ADMINISTRATOR);

  private ReservedRole() {}
}
