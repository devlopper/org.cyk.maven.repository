package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToArbitrateNDto extends HasTotalAmountToArbitrateN {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N = "montantTotalAArbitrerN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
