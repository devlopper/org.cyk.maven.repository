package ci.gouv.dgbf.extension.primefaces.crud;

import jakarta.enterprise.context.Dependent;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de création.
 *
 * @author Christian
 *
 */
@Dependent
public class CreateController extends AbstractCreateController<Object, Object> {

  @Getter
  @Setter
  Function<Object, Object> function;

  public CreateController() {
    super(null);
  }

  @SuppressWarnings("unchecked")
  public void setEntityClass(Class<?> entityClass) {
    this.entityClass = (Class<Object>) entityClass;
  }

  /**
   * Cette méthode permet d'instancier une entité.
   */
  public void instantiateEntity() {
    validateEntityClass();
    entity = classHelper.instantiate(entityClass, null, null);
    consumeEntity();
  }
  
  @Override
  protected Object doExecute() {
    validateFunction();
    return function.apply(entity);
  }

  void validateFunction() {
    if (function == null) {
      throw new IllegalStateException("La fonction de création ne doit pas être nulle");
    }
  }
  
  @Override
  protected String buildNotificationMessage(Object response) {
    return "creation";
  }  
}
