package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTypedTabMenuController;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de lecture de {@link IdentityDto}.
 *
 * @author Christian
 */
@Dependent
public class IdentityReadTabMenuController
    extends AbstractTypedTabMenuController<IdentityDto, IconManager> {

  @Inject
  @Getter
  IconManager iconManager;

  /**
   * Cette méthode permet de construire.
   */
  public IdentityReadTabMenuController() {
    super(IdentityDto.class);
    addPage(IdentityReadIndexPage.class, IdentityReadIndexPage.OUTCOME);
    addPage(IdentityReadEmailAddressesPage.class, IdentityReadEmailAddressesPage.OUTCOME);
    addPage(IdentityReadPolicyConsentsPage.class, IdentityReadPolicyConsentsPage.OUTCOME);
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();

    menu.tabBuilder().menuItemValue(IdentityEmailAddressDto.NAME)
        .type(IdentityReadEmailAddressesPage.class).menuItemIcon("pi pi-envelope")
        .addMenuItemParameter(requestParameterIdentifierName, instance.getIdentifier()).build();

    menu.tabBuilder().menuItemValue(IdentityPolicyConsentDto.NAME)
        .type(IdentityReadPolicyConsentsPage.class).menuItemIcon("pi pi-check-square")
        .addMenuItemParameter(requestParameterIdentifierName, instance.getIdentifier()).build();
  }
}
