package ci.gouv.dgbf.system.user.client.extension;


import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page des rôles de l'utilisateur connecté.
 *
 * @author BoobaCool
 */
@Named
@ViewScoped
public class UserProfileReadRolesPage extends AbstractUserProfileReadDatasPage {


  @Inject
  @Getter
  RoleController roleController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    // Filtrer les rôles assignés à l'utilisateur connecté
    roleController.getFilterController().getFilter()
        .setAssignedUserIdentifier(user.getIdentifier());
    roleController.initialize();
  }

  public static final String OUTCOME = "userProfileReadRolesPage";
}

