package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine fonctionnel.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionalDomainDto extends AbstractIdentifiableCodableNamableAuditableDto {

  public static final String JSON_THIS_IDENTIFIER = "idDomaineFonctionnel";
  public static final String JSON_THIS_AS_STRING = "domaineFonctionnelChaine";

  public static final String NAME = "domaine fonctionnel";
  public static final String PLURAL_NAME = "domaines fonctionnels";
}
