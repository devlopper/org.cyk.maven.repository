package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitService.BudgetSpecializationUnitCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitService.BudgetSpecializationUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BudgetSpecializationUnitDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BudgetSpecializationUnitDto}.

    @author Arnaud
               """)
public interface BudgetSpecializationUnitRequestMapper extends
    RequestMapper<BudgetSpecializationUnitDto, BudgetSpecializationUnitCreateRequestDto,
    BudgetSpecializationUnitUpdateRequestDto> {

}
