package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsYearDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants de {@link ProgrammingDto}.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractProgrammingAmountsContainerDto
    extends AbstractGroupedAmountsContainerDto implements HasProgrammingIdentifierDto,
    HasProgrammingAsStringDto, HasExerciseAsStringDto, HasExerciseAsYearDto {

  // Programming

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  protected String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  protected String programmingAsString;

  // Exercise

  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  protected String exerciseAsString;

  @JsonbProperty(JSON_EXERCISE_YEAR)
  protected Integer exerciseYear;
}
