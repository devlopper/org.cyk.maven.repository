package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les actions du Lot d'Import de réclamations (RG_REP_SOU_12) : la
 * consultation des Lots, et la simulation, qui lit un fichier FUR déposé et rend son rapport sans
 * rien écrire. Le Lot n'a aucun
 * statut propre (RG_REP_SOU_14) : il n'est créé qu'au traitement.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimImportBatchService.PATH)
@Tag(name = "Lots d'import de réclamations")
public interface PayrollElementClaimImportBatchService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "lots-import";

  /**
   * Identifiant json champ {@code fileName}.
   */
  String JSON_FILE_NAME = "fichier";

  /**
   * Identifiant json champ {@code content}.
   */
  String JSON_CONTENT = "contenu";

  /**
   * Identifiant json champ {@code motive}.
   */
  String JSON_MOTIVE = "motifDerogation";

  /**
   * Identifiant json champ {@code typeCodes}.
   */
  String JSON_TYPE_CODES = "codesTypes";

  /**
   * Identifiant json champ {@code registerOnly}.
   */
  String JSON_REGISTER_ONLY = "enregistrementSeul";

  /**
   * Identifiant json champ {@code exercise}.
   */
  String JSON_EXERCISE = "exercice";

  /**
   * Identifiant json champ {@code periods}.
   */
  String JSON_PERIODS = "periodes";

  /**
   * Identifiant json champ {@code periodIdentifier}.
   */
  String JSON_PERIOD_IDENTIFIER = "idPeriode";

  /**
   * Identifiant json champ {@code batchCount}.
   */
  String JSON_BATCH_COUNT = "nombreLots";

  /**
   * Identifiant json champ {@code initialCount}.
   */
  String JSON_INITIAL_COUNT = "nombreInitiaux";

  /**
   * Identifiant json champ {@code additiveCount}.
   */
  String JSON_ADDITIVE_COUNT = "nombreAdditifs";

  /**
   * Identifiant json champ {@code correctiveCount}.
   */
  String JSON_CORRECTIVE_COUNT = "nombreCorrectifs";

  /**
   * Identifiant json champ {@code toGenerateCount}.
   */
  String JSON_TO_GENERATE_COUNT = "nombreReclamationsAGenerer";

  /**
   * Identifiant json champ {@code state}.
   */
  String JSON_PERIOD_STATE = "etat";

  /**
   * Identifiant json champ {@code types}.
   */
  String JSON_PERIOD_TYPES = "types";

  /**
   * Identifiant json champ {@code furType}.
   */
  String JSON_PERIOD_TYPE_FUR = "typeFur";

  /**
   * État d'une période qui n'a aucun Lot traité, aucune ligne ni anomalie.
   */
  String PERIOD_STATE_EMPTY = "VIDE";

  /**
   * État d'une période qui a au moins un Lot traité mais aucune ligne ni anomalie -- ses lignes
   * n'ont jamais été reversées dans {@code TA_LIGNE_FUR} (incident ou Lot antérieur à ce
   * mécanisme).
   */
  String PERIOD_STATE_NOT_CONSOLIDATED = "NON_CONSOLIDE";

  /**
   * État d'une période qui a des anomalies ouvertes.
   */
  String PERIOD_STATE_ANOMALIES = "ANOMALIES";

  /**
   * État d'une période dont des lignes attendent leur réclamation.
   */
  String PERIOD_STATE_TO_GENERATE = "A_GENERER";

  /**
   * État d'une période dont toutes les réclamations sont générées.
   */
  String PERIOD_STATE_GENERATED = "GENERE";

  /**
   * Identifiant json champ {@code lineCount}.
   */
  String JSON_LINE_COUNT = "nombreLignes";

  /**
   * Identifiant json champ {@code pieceCounts}.
   */
  String JSON_PIECE_COUNTS = "repartitionPieces";

  /**
   * Identifiant json champ {@code mergedCount}.
   */
  String JSON_MERGED_COUNT = "nombrePiecesFusionnees";

  /**
   * Identifiant json champ {@code ignoredCount}.
   */
  String JSON_IGNORED_COUNT = "nombreLignesIgnorees";

  /**
   * Identifiant json champ {@code notGeneratedCount}.
   */
  String JSON_NOT_GENERATED_COUNT = "nombreLignesNonGenerees";

  /**
   * Identifiant json champ {@code claimCount}.
   */
  String JSON_CLAIM_COUNT = "nombreReclamations";

  /**
   * Identifiant json champ {@code typeCounts}.
   */
  String JSON_TYPE_COUNTS = "repartitionTypes";

  /**
   * Identifiant json champ {@code newAgentCount}.
   */
  String JSON_NEW_AGENT_COUNT = "nombreNouveauxAgents";

  /**
   * Identifiant json champ {@code causeCounts}.
   */
  String JSON_CAUSE_COUNTS = "repartitionCauses";

  /**
   * Identifiant json champ {@code uncategorizedCount}.
   */
  String JSON_UNCATEGORIZED_COUNT = "nombreLignesSansCategorie";

  /**
   * Identifiant json champ {@code situationCount}.
   */
  String JSON_SITUATION_COUNT = "nombreLignesSituationAgent";

  /**
   * Identifiant json champ {@code cause}.
   */
  String JSON_CAUSE = "cause";

  /**
   * Identifiant json champ {@code toProcessCount}.
   */
  String JSON_TO_PROCESS_COUNT = "nombreLignesATraiter";

  /**
   * Identifiant json champ {@code anomalyCount}.
   */
  String JSON_ANOMALY_COUNT = "nombreAnomalies";

  /**
   * Identifiant json champ {@code anomalies}.
   */
  String JSON_ANOMALIES = "anomalies";

  /**
   * Identifiant json champ {@code causeDetails}.
   */
  String JSON_CAUSE_DETAILS = "detailsCauses";

  /**
   * Identifiant json champ {@code items}.
   */
  String JSON_ITEMS = "elements";

  /**
   * Identifiant json champ {@code itemCount}.
   */
  String JSON_ITEM_COUNT = "nombreElements";

  /**
   * Identifiant json champ {@code label}.
   */
  String JSON_LABEL = "libelle";

  /**
   * Colonnes de l'aperçu d'une ligne du fichier, dans l'ordre d'affichage : celles qui
   * l'identifient, sans donnée personnelle.
   */
  List<String> PREVIEW_COLUMNS = List.of("CODE_PIECE", "CODE_DOCUMENT", "MATRICULE",
      "CODE_ORGANISME", "CODE_ECHELLE_CORPS", "CODE_GRADE", "CODE_LIEU_AFFECTATION",
      "DATE_EFFET_SITUATION_ADM");

  /**
   * Début du sujet d'une anomalie qui désigne une ligne du fichier, suivi de son numéro.
   */
  String SUBJECT_LINE = "Ligne ";

  /**
   * Identifiant json champ {@code subject}.
   */
  String JSON_SUBJECT = "concerne";

  /**
   * Identifiant json champ {@code missingColumns}.
   */
  String JSON_MISSING_COLUMNS = "colonnesAbsentes";

  /**
   * Identifiant json champ {@code column}.
   */
  String JSON_COLUMN = "colonne";

  /**
   * Identifiant json champ {@code setAside}.
   */
  String JSON_SET_ASIDE = "ligneEcartee";

  /**
   * Identifiant json champ {@code lines}.
   */
  String JSON_LINES = "lignes";

  /**
   * Identifiant json champ {@code values}.
   */
  String JSON_VALUES = "valeurs";

  /**
   * Identifiant json champ {@code lineNumber}.
   */
  String JSON_PREVIEW_LINE_NUMBER = "numeroLigne";

  /**
   * Identifiant json champ {@code missingRules}.
   */
  String JSON_MISSING_RULES = "reglesManquantes";

  /**
   * Identifiant json champ {@code pieceCode}.
   */
  String JSON_PIECE_CODE = "codePiece";

  /**
   * Identifiant json champ {@code documentPrefix}.
   */
  String JSON_DOCUMENT_PREFIX = "prefixeDocument";

  /**
   * Identifiant json champ {@code lineNumber}.
   */
  String JSON_LINE_NUMBER = "numeroLigne";

  /**
   * Identifiant json champ {@code reason}.
   */
  String JSON_REASON = "motif";

  /**
   * Identifiant du service de Simulation.
   */
  String SIMULATE_IDENTIFIER = "SIMULATION_LOT_IMPORT";

  /**
   * Chemin du service de Simulation.
   */
  String SIMULATE_PATH = "simulation";

  /**
   * Cette méthode simule le traitement d'un fichier FUR : elle le lit, rapproche les pièces 1090 et
   * 1091 et consigne les lignes inexploitables, sans rien écrire.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SIMULATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SIMULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchSimulationResponseDto.class))})
  Response simulate(PayrollElementClaimImportBatchSimulationRequestDto request);

  /**
   * Identifiant json champ {@code importBatchIdentifier}.
   */
  String JSON_IMPORT_BATCH_IDENTIFIER = "idLotImport";

  /**
   * Identifiant json champ {@code generatedCount}.
   */
  String JSON_GENERATED_COUNT = "nombreReclamationsGenerees";

  /**
   * Identifiant json champ {@code pendingNewAgentCount}.
   */
  String JSON_PENDING_NEW_AGENT_COUNT = "nombreNouveauxAgentsEnAttente";

  /**
   * Identifiant json champ {@code createdAgentCount}.
   */
  String JSON_CREATED_AGENT_COUNT = "nombreAgentsCrees";

  /**
   * Identifiant json champ {@code createAgents}.
   */
  String JSON_CREATE_AGENTS = "creerAgents";

  /**
   * Identifiant json champ {@code plannedCount}.
   */
  String JSON_PLANNED_COUNT = "nombreReclamationsPrevues";

  /**
   * Identifiant json champ {@code processedCount}.
   */
  String JSON_PROCESSED_COUNT = "nombreLignesTraitees";

  /**
   * Identifiant json champ {@code finished}.
   */
  String JSON_FINISHED = "termine";

  /**
   * Identifiant du service de Génération.
   */
  String GENERATE_IDENTIFIER = "GENERATION_LOT_IMPORT";

  /**
   * Chemin du service de Génération.
   */
  String GENERATE_PATH = "generation";

  /**
   * Cette méthode traite un fichier FUR : elle crée le Lot d'Import, y consigne les anomalies de
   * lecture, puis lance en arrière-plan la génération à l'état Créée des réclamations des agents
   * déjà connus (RG_REP_SOU_12 à RG_REP_SOU_14). Elle répond sans attendre la fin : l'avancement
   * se lit avec {@link #progress}.
   *
   * @param request requête, la même que celle de la simulation
   * @return réponse
   */
  @Path(GENERATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GENERATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response generate(PayrollElementClaimImportBatchSimulationRequestDto request);

  /**
   * Identifiant du service de Génération des réclamations des agents créés.
   */
  String COMPLETE_NEW_AGENTS_IDENTIFIER = "GENERATION_AGENTS_CREES_LOT_IMPORT";

  /**
   * Chemin du service de Génération des réclamations des agents créés.
   */
  String COMPLETE_NEW_AGENTS_PATH = "generation/agents";

  /**
   * Cette méthode lance en arrière-plan la génération des réclamations des agents que le Lot a
   * créés en paie et dont la réclamation n'a pas pu l'être, faute de les trouver encore parmi les
   * fonctionnaires. Un agent toujours introuvable reste en attente. Elle répond sans attendre la
   * fin : l'avancement se lit avec {@link #progress}.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  @Path(COMPLETE_NEW_AGENTS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = COMPLETE_NEW_AGENTS_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response completeNewAgents(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de Dépôt.
   */
  String DEPOSIT_IDENTIFIER = "DEPOT_LOT_IMPORT";

  /**
   * Chemin du service de Dépôt.
   */
  String DEPOSIT_PATH = "depot";

  /**
   * Cette méthode conserve un fichier FUR dans un Lot déposé, sans générer aucune réclamation. La
   * conservation des lignes se poursuit après la réponse : son avancement se lit avec
   * {@link #progress}. Un fichier illisible est refusé sans créer de Lot.
   *
   * @param request requête portant le fichier, sa période, son type et sa nature
   * @return réponse portant l'identifiant du Lot créé
   */
  @Path(DEPOSIT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DEPOSIT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response deposit(PayrollElementClaimImportBatchSimulationRequestDto request);

  /**
   * Identifiant du service de Simulation d'un Lot.
   */
  String SIMULATE_BATCH_IDENTIFIER = "SIMULATION_LOT_IMPORT_DEPOSE";

  /**
   * Chemin du service de Simulation d'un Lot.
   */
  String SIMULATE_BATCH_PATH = "simulation-lot";

  /**
   * Cette méthode simule le traitement d'un Lot déposé à partir de ses lignes conservées. Les
   * réclamations déjà générées par un traitement précédent n'y sont plus comptées.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  @Path(SIMULATE_BATCH_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SIMULATE_BATCH_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchSimulationResponseDto.class))})
  Response simulateBatch(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de génération des réclamations d'une période.
   */
  String GENERATE_PERIOD_IDENTIFIER = "GENERATION_PERIODE_FUR";

  /**
   * Chemin du service de génération des réclamations d'une période.
   */
  String GENERATE_PERIOD_PATH = "generation-periode";

  /**
   * Cette méthode lance la génération des réclamations des lignes consolidées d'une période, d'un
   * type de FUR ou de tous : chaque réclamation est rattachée au Lot qui a apporté sa ligne, et la
   * ligne de la période garde la réclamation ou le motif de son refus. Les agents des nouvelles
   * lignes d'agent sont créés en paie si la requête le demande. La génération se déroule
   * en arrière-plan ; son avancement se lit avec le service d'avancement, sous l'identifiant que
   * la réponse donne.
   *
   * @param request requête portant la période et, facultativement, le type de FUR
   * @return avancement de départ ; une période sans ligne, ou déjà en cours de génération, est
   *         refusée avec un message
   */
  @Path(GENERATE_PERIOD_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GENERATE_PERIOD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response generatePeriod(PayrollElementClaimImportBatchControlPeriodRequestDto request);

  /**
   * Identifiant du service de contrôle d'une période.
   */
  String CONTROL_PERIOD_IDENTIFIER = "CONTROLE_PERIODE_FUR";

  /**
   * Chemin du service de contrôle d'une période.
   */
  String CONTROL_PERIOD_PATH = "controle-periode";

  /**
   * Cette méthode contrôle les lignes consolidées d'une période, d'un type de FUR ou de tous : les
   * contrôles du fichier sont rejoués sur la table de la période, et le rapport a la forme de
   * celui d'une simulation. Les réclamations déjà générées n'y sont plus comptées.
   *
   * @param request requête portant la période et, facultativement, le type de FUR
   * @return réponse ; une période sans ligne est refusée avec un message
   */
  @Path(CONTROL_PERIOD_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONTROL_PERIOD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchSimulationResponseDto.class))})
  Response controlPeriod(PayrollElementClaimImportBatchControlPeriodRequestDto request);

  /**
   * Identifiant du service d'inscription des lignes consolidées d'une période.
   */
  String REGISTER_PERIOD_IDENTIFIER = "INSCRIPTION_PERIODE_FUR";

  /**
   * Chemin du service d'inscription des lignes consolidées d'une période.
   */
  String REGISTER_PERIOD_PATH = "inscription-periode";

  /**
   * Cette méthode rejoue les contrôles d'une période, d'un type de FUR ou de tous, et inscrit
   * leur résultat sur la table de la période, sans générer aucune réclamation : une ligne déjà
   * écartée dont la cause a depuis été corrigée (code ou référentiel) retrouve un motif à jour,
   * sans intervention manuelle. Une ligne déjà porteuse d'une réclamation n'est jamais touchée.
   * L'inscription se déroule en arrière-plan ; son avancement se lit avec le service
   * d'avancement, sous l'identifiant que la réponse donne.
   *
   * @param request requête portant la période et, facultativement, le type de FUR
   * @return avancement de départ ; une période sans ligne, ou déjà en cours d'inscription, est
   *         refusée avec un message
   */
  @Path(REGISTER_PERIOD_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REGISTER_PERIOD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response registerPeriod(PayrollElementClaimImportBatchControlPeriodRequestDto request);

  /**
   * Identifiant du service de résumé des périodes.
   */
  String PERIOD_SUMMARIES_IDENTIFIER = "RESUME_PERIODES_FUR";

  /**
   * Chemin du service de résumé des périodes.
   */
  String PERIOD_SUMMARIES_PATH = "resume-periodes";

  /**
   * Cette méthode résume les périodes du FUR : pour chacune, les Lots qui l'ont alimentée, ses
   * lignes consolidées, ses anomalies ouvertes, ses réclamations et son état, calculés à la
   * lecture.
   *
   * @param request requête, avec l'exercice à lire ou tous les exercices
   * @return réponse portant le résumé de chaque période, de la plus récente à la plus ancienne
   */
  @Path(PERIOD_SUMMARIES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = PERIOD_SUMMARIES_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchPeriodSummariesResponseDto.class))})
  Response periodSummaries(PayrollElementClaimImportBatchPeriodSummariesRequestDto request);

  /**
   * Identifiant du service de suppression d'une période.
   */
  String DELETE_PERIOD_IDENTIFIER = "SUPPRESSION_PERIODE_FUR";

  /**
   * Chemin du service de suppression d'une période.
   */
  String DELETE_PERIOD_PATH = "suppression-periode";

  /**
   * Cette méthode supprime une période du FUR, à condition qu'elle soit réellement vide : aucun
   * Lot, de quelque nature ou état que ce soit, et aucune ligne consolidée ne doit lui être
   * rattaché. Sinon, la suppression est refusée avec un message explicite.
   *
   * @param request requête portant la période
   * @return réponse ; {@code message} absent si la période a été supprimée, motif du refus sinon
   */
  @Path(DELETE_PERIOD_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_PERIOD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchDeletePeriodResponseDto.class))})
  Response deletePeriod(PayrollElementClaimImportBatchDeletePeriodRequestDto request);

  /**
   * Identifiant du service de Génération d'un Lot.
   */
  String GENERATE_BATCH_IDENTIFIER = "GENERATION_LOT_IMPORT_DEPOSE";

  /**
   * Chemin du service de Génération d'un Lot.
   */
  String GENERATE_BATCH_PATH = "generation-lot";

  /**
   * Cette méthode lance en arrière-plan la génération des réclamations d'un Lot déposé, pour tous
   * ses types ou seulement pour ceux demandés. Les réclamations déjà générées ne le sont pas de
   * nouveau : les types restants se traitent par un lancement ultérieur. L'avancement se lit avec
   * {@link #progress}.
   *
   * @param request requête portant le Lot et les types à traiter
   * @return réponse
   */
  @Path(GENERATE_BATCH_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GENERATE_BATCH_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response generateBatch(PayrollElementClaimImportBatchGenerateBatchRequestDto request);

  /**
   * Identifiant du service de Dérogation.
   */
  String FORCE_IDENTIFIER = "DEROGATION_LIGNE_LOT_IMPORT";

  /**
   * Chemin du service de Dérogation.
   */
  String FORCE_PATH = "derogation";

  /**
   * Cette méthode force la génération de la réclamation d'une ligne que les règles de contrôle
   * (ancienneté d'un avancement, nomination qui répète le grade, information redondante) ont
   * écartée. Le motif de la dérogation et son auteur sont consignés sur la ligne. La génération
   * est immédiate.
   *
   * @param request requête portant le Lot, le numéro de ligne et le motif de la dérogation
   * @return réponse
   */
  @Path(FORCE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = FORCE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response force(PayrollElementClaimImportBatchForceRequestDto request);

  /**
   * Identifiant du service d'avancement de la génération.
   */
  String PROGRESS_IDENTIFIER = "AVANCEMENT_LOT_IMPORT";

  /**
   * Chemin du service d'avancement de la génération.
   */
  String PROGRESS_PATH = "avancement";

  /**
   * Cette méthode donne l'avancement de la génération d'un Lot : le traitement d'un fichier se
   * poursuit après la réponse de {@link #generate}.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  @Path(PROGRESS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = PROGRESS_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchGenerationResponseDto.class))})
  Response progress(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_LOT_IMPORT";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre de Lots d'Import, pour la pagination et le décompte
   * des onglets.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_LOT_IMPORT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollElementClaimImportBatchDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollElementClaimImportBatchGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollElementClaimImportBatchDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollElementClaimImportBatchDto> datas;
  }

  /**
   * Identifiant du service d'obtention d'un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_LOT_IMPORT";

  /**
   * Chemin du service d'obtention d'un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un {@link PayrollElementClaimImportBatchDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant d'un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_LOT_IMPORT";

  /**
   * Chemin du service d'obtention par identifiant d'un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant un {@link PayrollElementClaimImportBatchDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimImportBatchDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette classe représente la requête de simulation : le fichier déposé.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Nom du fichier déposé.
     */
    @NotEmpty
    @JsonbProperty(JSON_FILE_NAME)
    private String fileName;

    /**
     * Contenu du fichier déposé, encodé en base 64.
     */
    @NotEmpty
    @JsonbProperty(JSON_CONTENT)
    private String content;

    /**
     * Période du FUR : un jour du mois que le fichier concerne. Obligatoire pour la génération.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_PERIOD)
    private LocalDate period;

    /**
     * Type de FUR, c'est-à-dire sa source : fonction publique, police, etc. Obligatoire pour la
     * génération.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_FUR_TYPE)
    private String furType;

    /**
     * Nature du fichier, {@link PayrollElementClaimImportBatchDto#NATURE_INITIAL} à défaut.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_NATURE)
    private String nature;

    /**
     * Identifiant du Lot que ce fichier complète ou corrige.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_PARENT_IDENTIFIER)
    private String parentIdentifier;
  }

  /**
   * Cette classe représente la requête de génération d'un Lot déposé.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchGenerateBatchRequestDto
      extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant du Lot d'Import.
     */
    @NotEmpty
    @JsonbProperty(PayrollElementClaimImportBatchAnomalyDto.JSON_IMPORT_BATCH_IDENTIFIER)
    private String importBatchIdentifier;

    /**
     * Codes des types de réclamation à traiter, tous les types si la liste est vide.
     */
    @JsonbProperty(JSON_TYPE_CODES)
    private List<String> typeCodes;

    /**
     * {@code true} pour inscrire les lignes du Lot dans la période sans générer de réclamation :
     * ce que font un additif et un fichier de corrections.
     */
    @JsonbProperty(JSON_REGISTER_ONLY)
    private Boolean registerOnly;
  }

  /**
   * Cette classe représente la requête de dérogation sur une ligne d'un Lot.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchForceRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant du Lot d'Import.
     */
    @NotEmpty
    @JsonbProperty(PayrollElementClaimImportBatchAnomalyDto.JSON_IMPORT_BATCH_IDENTIFIER)
    private String importBatchIdentifier;

    /**
     * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
     */
    @NotNull
    @JsonbProperty(PayrollElementClaimImportBatchAnomalyDto.JSON_LINE_NUMBER)
    private Integer lineNumber;

    /**
     * Motif de la dérogation.
     */
    @NotEmpty
    @JsonbProperty(JSON_MOTIVE)
    private String motive;
  }

  /**
   * Cette classe représente la réponse d'une simulation : le rapport de lecture du fichier.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationResponseDto extends AbstractResponseDto {

    /**
     * Nom du fichier lu.
     */
    @JsonbProperty(JSON_FILE_NAME)
    private String fileName;

    /**
     * Nombre de lignes lues.
     */
    @JsonbProperty(JSON_LINE_COUNT)
    private Integer lineCount;

    /**
     * Nombre de lignes de chaque code pièce.
     */
    @JsonbProperty(JSON_PIECE_COUNTS)
    private Map<String, Integer> pieceCounts;

    /**
     * Nombre de pièces 1091 fusionnées dans une pièce 1090.
     */
    @JsonbProperty(JSON_MERGED_COUNT)
    private Integer mergedCount;

    /**
     * Nombre de lignes laissées de côté, car portant au moins une anomalie.
     */
    @JsonbProperty(JSON_IGNORED_COUNT)
    private Integer ignoredCount;

    /**
     * Nombre de lignes à traiter, après fusion et mise de côté des lignes en anomalie.
     */
    @JsonbProperty(JSON_TO_PROCESS_COUNT)
    private Integer toProcessCount;

    /**
     * Nombre de lignes à traiter qui n'ont aucune règle de type : elles ne génèrent pas de
     * réclamation.
     */
    @JsonbProperty(JSON_NOT_GENERATED_COUNT)
    private Integer notGeneratedCount;

    /**
     * Nombre de réclamations à générer.
     */
    @JsonbProperty(JSON_CLAIM_COUNT)
    private Integer claimCount;

    /**
     * Nombre de réclamations à générer pour chaque code de type.
     */
    @JsonbProperty(JSON_TYPE_COUNTS)
    private Map<String, Integer> typeCounts;

    /**
     * Nombre de nouveaux agents à créer.
     */
    @JsonbProperty(JSON_NEW_AGENT_COUNT)
    private Integer newAgentCount;

    /**
     * Nombre de lignes concernées par chaque cause d'anomalie.
     */
    @JsonbProperty(JSON_CAUSE_COUNTS)
    private Map<String, Integer> causeCounts;

    /**
     * Nombre de réclamations à générer dont le grade n'est pas dans le référentiel, donc sans
     * catégorie.
     */
    @JsonbProperty(JSON_UNCATEGORIZED_COUNT)
    private Integer uncategorizedCount;

    /**
     * Nombre de pièces 1192 à générer dont le lieu d'affectation n'est pas dans le fichier et a
     * été lu dans la situation actuelle de l'agent.
     */
    @JsonbProperty(JSON_SITUATION_COUNT)
    private Integer situationCount;

    /**
     * Nombre total d'anomalies consignées.
     */
    @JsonbProperty(JSON_ANOMALY_COUNT)
    private Integer anomalyCount;

    /**
     * Premières anomalies consignées, dans l'ordre du fichier ; le nombre total est porté par
     * {@code anomalyCount}.
     */
    @JsonbProperty(JSON_ANOMALIES)
    private List<PayrollElementClaimImportBatchSimulationAnomalyDto> anomalies;

    /**
     * Règles « code document vers type » qui manquent, une par pièce et préfixe de document.
     */
    @JsonbProperty(JSON_MISSING_RULES)
    private List<PayrollElementClaimImportBatchSimulationMissingRuleDto> missingRules;

    /**
     * Pour chaque cause d'anomalie, les éléments concernés : organismes, localités, Types ou
     * lignes.
     */
    @JsonbProperty(JSON_CAUSE_DETAILS)
    private List<PayrollElementClaimImportBatchSimulationCauseDto> causeDetails;
  }

  /**
   * Cette classe représente une anomalie consignée par la simulation : une ligne du fichier et le
   * motif pour lequel elle est laissée de côté.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationAnomalyDto {

    /**
     * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
     */
    @JsonbProperty(JSON_LINE_NUMBER)
    private Integer lineNumber;

    /**
     * Cause de l'anomalie.
     */
    @JsonbProperty(JSON_CAUSE)
    private String cause;

    /**
     * Motif.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;
  }

  /**
   * Cette classe représente la réponse d'une génération : le Lot créé et ce qu'il contient.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchGenerationResponseDto extends AbstractResponseDto {

    /**
     * Identifiant du Lot d'Import créé.
     */
    @JsonbProperty(JSON_IMPORT_BATCH_IDENTIFIER)
    private String importBatchIdentifier;

    /**
     * Nom du fichier traité.
     */
    @JsonbProperty(JSON_FILE_NAME)
    private String fileName;

    /**
     * Nombre de réclamations générées.
     */
    @JsonbProperty(JSON_GENERATED_COUNT)
    private Integer generatedCount;

    /**
     * Nombre de lignes consignées en anomalie, à la lecture comme à la génération.
     */
    @JsonbProperty(JSON_ANOMALY_COUNT)
    private Integer anomalyCount;

    /**
     * Nombre de lignes non traitées par cette génération, par cause d'anomalie.
     */
    @JsonbProperty(JSON_CAUSE_COUNTS)
    private Map<String, Integer> anomalyCauseCounts;

    /**
     * Nombre de réclamations de nouveaux agents, non générées tant que la création des agents
     * n'est pas faite.
     */
    @JsonbProperty(JSON_PENDING_NEW_AGENT_COUNT)
    private Integer pendingNewAgentCount;

    /**
     * Nombre d'agents créés en paie par ce traitement.
     */
    @JsonbProperty(JSON_CREATED_AGENT_COUNT)
    private Integer createdAgentCount;

    /**
     * Nombre de réclamations que le traitement doit générer.
     */
    @JsonbProperty(JSON_PLANNED_COUNT)
    private Integer plannedCount;

    /**
     * Nombre de lignes déjà traitées parmi celles qui doivent donner une réclamation.
     */
    @JsonbProperty(JSON_PROCESSED_COUNT)
    private Integer processedCount;

    /**
     * Vrai quand le traitement du fichier est terminé.
     */
    @JsonbProperty(JSON_FINISHED)
    private Boolean finished;
  }

  /**
   * Cette classe représente une règle « code document vers type » qui manque : des lignes du
   * fichier n'ont aucun type, faute d'une règle pour leur pièce et leur code document.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationMissingRuleDto {

    /**
     * Code de la pièce.
     */
    @JsonbProperty(JSON_PIECE_CODE)
    private String pieceCode;

    /**
     * Préfixe de code document proposé, {@code *} pour tous les documents de la pièce.
     */
    @JsonbProperty(JSON_DOCUMENT_PREFIX)
    private String documentPrefix;

    /**
     * Nombre de lignes concernées.
     */
    @JsonbProperty(JSON_LINE_COUNT)
    private Integer lineCount;
  }

  /**
   * Cette classe représente les éléments concernés par une cause d'anomalie, du plus touché au
   * moins touché.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationCauseDto {

    /**
     * Cause de l'anomalie.
     */
    @JsonbProperty(JSON_CAUSE)
    private String cause;

    /**
     * Colonne du fichier que la cause met en cause, absente si elle n'en désigne pas une seule.
     */
    @JsonbProperty(JSON_COLUMN)
    private String column;

    /**
     * {@code true} si la cause écarte la ligne de la version finale, {@code false} si la ligne est
     * conservée sans réclamation (complétable, par exemple par une règle de type ou une
     * dérogation).
     */
    @JsonbProperty(JSON_SET_ASIDE)
    private Boolean setAside;

    /**
     * Nombre d'éléments concernés, au-delà de ceux listés.
     */
    @JsonbProperty(JSON_ITEM_COUNT)
    private Integer itemCount;

    /**
     * Premiers éléments concernés.
     */
    @JsonbProperty(JSON_ITEMS)
    private List<PayrollElementClaimImportBatchSimulationCauseItemDto> items;
  }

  /**
   * Cette classe représente un élément concerné par une cause d'anomalie.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationCauseItemDto {

    /**
     * Ce qui est concerné : un code organisme, une localité, un Type, un matricule ou une ligne.
     */
    @JsonbProperty(JSON_LABEL)
    private String label;

    /**
     * Nombre de lignes concernées.
     */
    @JsonbProperty(JSON_LINE_COUNT)
    private Integer lineCount;

    /**
     * Aperçu des premières lignes concernées.
     */
    @JsonbProperty(JSON_LINES)
    private List<PayrollElementClaimImportBatchSimulationLineDto> lines;
  }

  /**
   * Cette classe représente l'aperçu d'une ligne du fichier : son numéro et les colonnes qui
   * l'identifient, dans l'ordre d'affichage.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchSimulationLineDto {

    /**
     * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
     */
    @JsonbProperty(JSON_PREVIEW_LINE_NUMBER)
    private Integer lineNumber;

    /**
     * Valeur de chaque colonne d'aperçu, par nom de colonne du fichier.
     */
    @JsonbProperty(JSON_VALUES)
    private Map<String, String> values;

    /**
     * Colonnes dont la donnée est obligatoire pour le type de la ligne et absente de la ligne,
     * vide si la ligne n'en manque aucune.
     */
    @JsonbProperty(JSON_MISSING_COLUMNS)
    private List<String> missingColumns;

    /**
     * Ce que l'anomalie de la ligne concerne : le code du Type, l'organisme ou la localité ;
     * absent si elle ne concerne que la ligne.
     */
    @JsonbProperty(JSON_SUBJECT)
    private String subject;
  }

  /**
   * Cette classe représente la requête de contrôle d'une période.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchControlPeriodRequestDto
      extends AbstractAuditedRequestJsonDto {

    /**
     * Premier jour du mois de la période.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_PERIOD)
    private LocalDate period;

    /**
     * Type de FUR dont les lignes sont contrôlées, tous les types de la période si absent.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_FUR_TYPE)
    private String furType;

    /**
     * {@code true} pour que la génération crée aussi en paie les agents des nouvelles lignes
     * d'agent (pièce 1090) que ce module ne connaît pas ; sinon, ces lignes restent à générer.
     */
    @JsonbProperty(JSON_CREATE_AGENTS)
    private Boolean createAgents;
  }

  /**
   * Cette classe représente la requête de résumé des périodes.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchPeriodSummariesRequestDto
      extends AbstractAuditedRequestJsonDto {

    /**
     * Exercice à lire, tous les exercices si absent.
     */
    @JsonbProperty(JSON_EXERCISE)
    private Integer exercise;
  }

  /**
   * Cette classe représente la réponse du résumé des périodes.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchPeriodSummariesResponseDto extends AbstractResponseDto {

    /**
     * Résumé de chaque période, de la plus récente à la plus ancienne.
     */
    @JsonbProperty(JSON_PERIODS)
    private List<PayrollElementClaimImportBatchPeriodSummaryDto> periods;
  }

  /**
   * Cette classe représente la requête de suppression d'une période.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchDeletePeriodRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Premier jour du mois de la période.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_PERIOD)
    private LocalDate period;
  }

  /**
   * Cette classe représente la réponse de suppression d'une période.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchDeletePeriodResponseDto extends AbstractResponseDto {
  }

  /**
   * Cette classe représente le résumé d'une période du FUR, tous types de FUR confondus.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchPeriodSummaryDto {

    /**
     * Identifiant de la période.
     */
    @JsonbProperty(JSON_PERIOD_IDENTIFIER)
    private String identifier;

    /**
     * Premier jour du mois de la période.
     */
    @JsonbProperty(PayrollElementClaimImportBatchDto.JSON_PERIOD)
    private LocalDate period;

    /**
     * Nombre de Lots qui ont alimenté la période.
     */
    @JsonbProperty(JSON_BATCH_COUNT)
    private Integer batchCount;

    /**
     * Nombre de fichiers initiaux.
     */
    @JsonbProperty(JSON_INITIAL_COUNT)
    private Integer initialCount;

    /**
     * Nombre d'additifs.
     */
    @JsonbProperty(JSON_ADDITIVE_COUNT)
    private Integer additiveCount;

    /**
     * Nombre de fichiers de corrections.
     */
    @JsonbProperty(JSON_CORRECTIVE_COUNT)
    private Integer correctiveCount;

    /**
     * Nombre de lignes consolidées de la période.
     */
    @JsonbProperty(JSON_LINE_COUNT)
    private Integer lineCount;

    /**
     * Nombre d'anomalies signalées de la période encore d'actualité : une rangée par cause
     * signalée, sauf celles dont la clé (pièce, matricule, document) a depuis obtenu, sur une
     * autre occurrence, une réclamation ou une réclamation à générer.
     */
    @JsonbProperty(JSON_ANOMALY_COUNT)
    private Integer anomalyCount;

    /**
     * Nombre de réclamations générées.
     */
    @JsonbProperty(JSON_CLAIM_COUNT)
    private Integer claimCount;

    /**
     * Nombre de lignes qui attendent leur réclamation.
     */
    @JsonbProperty(JSON_TO_GENERATE_COUNT)
    private Integer toGenerateCount;

    /**
     * État de la période, déduit de ses lignes : {@link #PERIOD_STATE_EMPTY},
     * {@link #PERIOD_STATE_NOT_CONSOLIDATED}, {@link #PERIOD_STATE_ANOMALIES},
     * {@link #PERIOD_STATE_TO_GENERATE} ou {@link #PERIOD_STATE_GENERATED}.
     */
    @JsonbProperty(JSON_PERIOD_STATE)
    private String state;

    /**
     * Situation de chaque type de FUR de la période, dont les lignes sont enregistrées ou dont une
     * anomalie reste ouverte : le premier fichier d'un type est initial, les suivants sont des
     * additifs ou des correctifs.
     */
    @JsonbProperty(JSON_PERIOD_TYPES)
    private List<PayrollElementClaimImportBatchPeriodTypeSummaryDto> types;
  }

  /**
   * Cette classe représente la situation d'un type de FUR dans une période, calculée à la lecture.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchPeriodTypeSummaryDto {

    /**
     * Type de FUR, c'est-à-dire sa source.
     */
    @JsonbProperty(JSON_PERIOD_TYPE_FUR)
    private String furType;

    /**
     * Nombre de lignes consolidées du type.
     */
    @JsonbProperty(JSON_LINE_COUNT)
    private Integer lineCount;

    /**
     * Nombre de lignes du type dont la réclamation est générée.
     */
    @JsonbProperty(JSON_CLAIM_COUNT)
    private Integer claimCount;

    /**
     * Nombre de lignes du type qui attendent leur réclamation.
     */
    @JsonbProperty(JSON_TO_GENERATE_COUNT)
    private Integer toGenerateCount;

    /**
     * Nombre d'anomalies signalées du type encore d'actualité, au même sens que
     * {@link PayrollElementClaimImportBatchPeriodSummaryDto#anomalyCount}.
     */
    @JsonbProperty(JSON_ANOMALY_COUNT)
    private Integer anomalyCount;

    /**
     * État du type : {@link #PERIOD_STATE_EMPTY}, {@link #PERIOD_STATE_NOT_CONSOLIDATED},
     * {@link #PERIOD_STATE_ANOMALIES}, {@link #PERIOD_STATE_TO_GENERATE} ou
     * {@link #PERIOD_STATE_GENERATED}.
     */
    @JsonbProperty(JSON_PERIOD_STATE)
    private String state;
  }
}
