package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un emploi.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class JobDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link JobDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEmploi";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link JobDto}.
   */
  public static final String JSON_THIS_AS_STRING = "emploiChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "emploi";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
