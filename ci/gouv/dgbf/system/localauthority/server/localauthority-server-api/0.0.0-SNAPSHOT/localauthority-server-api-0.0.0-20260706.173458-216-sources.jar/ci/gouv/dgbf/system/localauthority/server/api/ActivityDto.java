package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une activité.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ActivityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Identifiant de {@link  ActionDto}.
   */
  @JsonbProperty(JSON_ACTION_IDENTIFIER)
  private String actionIdentifier;

  /**
   * Represente en chaine de caractères de {@link  ActionDto}.
   */
  @JsonbProperty(JSON_ACTION_AS_STRING)
  private String actionAsString;

  /**
   * Identifiant de {@link  ExpenditureActivityDto}.
   */
  @JsonbProperty(JSON_BUDGETARY_ACTIVITY_IDENTIFIER)
  private String budgetaryActivityIdentifier;

  /**
   * Represente en chaine de caractères de {@link  ExpenditureActivityDto}.
   */
  @JsonbProperty(JSON_BUDGETARY_ACTIVITY_AS_STRING)
  private String budgetaryActivityAsString;

  /**
   * Identifiant {@link ActivityCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  /**
   * Représentation en chaine de caractères {@link ActivityCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  /**
   * Catégorie.
   */
  private ActivityCategory categoryEnum;

  /**
   * Identifiant {@link FunctionalAccountDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
  private String functionalAccountIdentifier;

  /**
   * Représentation en chaine de caractères {@link FunctionalAccountDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_AS_STRING)
  private String functionalAccountAsString;

  /**
   * Identifiant nature de dépense.
   */
  @JsonbProperty(JSON_NATURE_IDENTIFIER)
  private String natureIdentifier;

  /**
   * Représentation en chaine de caractères de la nature de dépense.
   */
  @JsonbProperty(JSON_NATURE_AS_STRING)
  private String natureAsString;

  /**
   * Identifiant {@link BeneficiaryDto}.
   */
  @JsonbProperty(JSON_BENEFICIARY_IDENTIFIER)
  private String beneficiaryIdentifier;

  /**
   * Représentation en chaine de caractères {@link BeneficiaryDto}.
   */
  @JsonbProperty(JSON_BENEFICIARY_AS_STRING)
  private String beneficiaryAsString;


  /**
   * Priorité.
   */
  @JsonbProperty(JSON_PRIORITY)
  private Integer priority;

  /**
   * Représentation en chaine de caractères de la priorité.
   */
  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Long amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;


  /**
   * Montant exécuté.
   */
  @JsonbProperty(JSON_EXECUTED_AMOUNT)
  private Long executedAmount;

  /**
   * Représentation en chaine de caractères du montant exécuté.
   */
  @JsonbProperty(JSON_EXECUTED_AMOUNT_AS_STRING)
  private String executedAmountAsString;

  /**
   * Description de l'activité.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Justification de l'activité.
   */
  @JsonbProperty(JSON_JUSTIFICATION)
  private String justification;

  /**
   * Identifiant de l'activité à laquelle on fait référence.
   */
  @JsonbProperty(JSON_REFERENCED_ACTIVITY_IDENTIFIER)
  private String referencedActivityIdentifier;


  /**
   * Représentation en chaine de caractère de la l'activité de référence.
   */
  @JsonbProperty(JSON_REFERENCED_ACTIVITY_AS_STRING)
  private String referencedActivityAsString;


  /**
   * Référence au PND.
   */
  @JsonbProperty(JSON_PND_REFERENCE)
  private String pndReference;

  /**
   * Référence eventuelle.
   */
  @JsonbProperty(JSON_EVENTUAL_REFERENCE)
  private String eventualReference;


  @JsonbProperty(JSON_DURATION)
  private String duration;

  @JsonbProperty(JSON_EXPECTED_IMPACT)
  private String expectedImpact;

  @JsonbProperty(JSON_OBSERVATION)
  private String observation;

  /**
   * Retenue de garantie.
   */
  @JsonbProperty(JSON_GUARANTEE_RETENTION)
  private Long guaranteeRetention;


  /**
   * Montant de la retenue de garantie.
   */
  @JsonbProperty(JSON_GUARANTEE_RETENTION_TO_AMOUNT)
  private Long guaranteeRetentionToAmount;


  /**
   * Montant de la retenue de garantie en chaine.
   */
  @JsonbProperty(JSON_GUARANTEE_RETENTION_TO_AMOUNT_AS_STRING)
  private String guaranteeRetentionToAmountAsString;


  /**
   * Représentation en chaine de caractères de la retenue de garantie.
   */
  @JsonbProperty(JSON_GUARANTEE_RETENTION_AS_STRING)
  private String guaranteeRetentionAsString;


  /**
   * Budget de prise en charge avant report.
   */
  @JsonbProperty(JSON_YEAR_BUDGET_BEFORE_CARRYOVER)
  private Integer yearBudgetBeforeCarryover;

  /**
   * Année prévisionnelle de mandatement.
   */
  @JsonbProperty(JSON_PLANNED_PAYMENT_YEAR)
  private Integer plannedPaymentYear;

  /**
   * Nombre d’occurance.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING)
  private String triennialProgramCountAsString;


  /**
   * Programme triennal de référence.
   */
  @JsonbProperty(JSON_REFERENCE_TRIENNIAL_PROGRAM)
  private String referenceTriennialProgram;


  /**
   * Représentation en chaine du programme triennal de référence.
   */
  @JsonbProperty(JSON_REFERENCE_TRIENNIAL_PROGRAM_AS_STRING)
  private String referenceTriennialProgramAsString;


  /**
   * Exercice du programme triennal de référence.
   */
  @JsonbProperty(JSON_REFERENCE_TRIENNIAL_PROGRAM_EXERCICE_YEAR)
  private String referenceTriennialProgramExerciceYear;

  /**
   * Identifiant de {@link ExpertiseDomainDto}.
   */
  @JsonbProperty(JSON_EXPERTISE_DOMAIN_IDENTIFIER)
  private String expertiseDomainIdentifier;


  /**
   * Représentation en chaine de caractère de {@link ExpertiseDomainDto}.
   */
  @JsonbProperty(JSON_EXPERTISE_DOMAIN_AS_STRING)
  private String expertiseDomainAsString;

  /**
   * Indique si l'activité est modifiable.
   */
  @JsonbProperty(JSON_UPDATABLE)
  private Boolean updatable;


  /**
   * Identifiant json de identifiant de {@link ActivityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idActivite";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ActivityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "activiteChaine";

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * identifiant json {@link #actionIdentifier}.
   */
  public static final String JSON_ACTION_IDENTIFIER = "idAction";

  /**
   * identifiant json {@link #actionAsString}.
   */
  public static final String JSON_ACTION_AS_STRING = "actionChaine";

  /**
   * identifiant json {@link #budgetaryActivityIdentifier}.
   */
  public static final String JSON_BUDGETARY_ACTIVITY_IDENTIFIER = "idActiviteBudgetaire";

  /**
   * identifiant json {@link #budgetaryActivityAsString}.
   */
  public static final String JSON_BUDGETARY_ACTIVITY_AS_STRING = "activiteBudgetaireChaine";

  /**
   * Identifiant json {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = "idCategorie";

  /**
   * Identifiant json {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = "categorieChaine";

  /**
   * Identifiant json {@link ActivityCategory}.
   */
  public static final String JSON_CATEGORY = "categorie";

  /**
   * Identifiant json {@link #functionalAccountIdentifier}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER = "idCompteFonctionnel";

  /**
   * Identifiant json {@link #functionalAccountAsString}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_AS_STRING = "compteFonctionnelChaine";

  /**
   * Identifiant json {@link #natureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER = "idNature";

  /**
   * Identifiant json {@link #natureAsString}.
   */
  public static final String JSON_NATURE_AS_STRING = "natureChaine";

  /**
   * Identifiant json {@link #beneficiaryIdentifier}.
   */
  public static final String JSON_BENEFICIARY_IDENTIFIER = BeneficiaryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #beneficiaryAsString}.
   */
  public static final String JSON_BENEFICIARY_AS_STRING = BeneficiaryDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #priority}.
   */
  public static final String JSON_PRIORITY = "priorite";

  /**
   * Identifiant json {@link #priorityAsString}.
   */
  public static final String JSON_PRIORITY_AS_STRING = "prioriteChaine";

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";


  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_EXECUTED_AMOUNT = "montantExecute";

  /**
   * Identifiant json {@link #triennialProgramCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING = "nombreProgrammeTriennal";


  /**
   * Identifiant json {@link #referenceTriennialProgram}.
   */
  public static final String JSON_REFERENCE_TRIENNIAL_PROGRAM = "programmeTriennalDeReference";

  /**
   * Identifiant json {@link #referenceTriennialProgramAsString}.
   */
  public static final String JSON_REFERENCE_TRIENNIAL_PROGRAM_AS_STRING =
      "programmeTriennalDeReferenceChaine";


  /**
   * Identifiant json {@link #referenceTriennialProgramExerciceYear}.
   */
  public static final String JSON_REFERENCE_TRIENNIAL_PROGRAM_EXERCICE_YEAR =
      "exerciceProgrammeTriennalDeReference";

  /**
   * Identifiant json {@link #expertiseDomainIdentifier}.
   */
  public static final String JSON_EXPERTISE_DOMAIN_IDENTIFIER =
      ExpertiseDomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #expertiseDomainAsString}.
   */
  public static final String JSON_EXPERTISE_DOMAIN_AS_STRING =
      ExpertiseDomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_EXECUTED_AMOUNT_AS_STRING = "montantExecuteChaine";

  /**
   * Identifiant json {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json {@link #justification}.
   */
  public static final String JSON_JUSTIFICATION = "justification";


  /**
   * Identifiant json de l'activité de référence {@link #referencedActivityIdentifier}.
   */
  public static final String JSON_REFERENCED_ACTIVITY_IDENTIFIER = "identifiantActiviteDeReference";

  /**
   * Identifiant json de l'activité de référence {@link #referencedActivityAsString}.
   */
  public static final String JSON_REFERENCED_ACTIVITY_AS_STRING = "ActiviteDeReferenceChaine";


  /**
   * Identifiant json de la référence au PND {@link #pndReference}.
   */
  public static final String JSON_PND_REFERENCE = "referencePND";

  /**
   * Identifiant json de la référence eventuelle {@link #eventualReference}.
   */
  public static final String JSON_EVENTUAL_REFERENCE = "referenceEventuelle";

  /**
   * Identifiant json de la durée {@link #duration}.
   */
  public static final String JSON_DURATION = "durée";


  /**
   * Identifiant json de l'impact attendu {@link #expectedImpact}.
   */
  public static final String JSON_EXPECTED_IMPACT = "impactAttendu";


  /**
   * Identifiant json de la durée {@link #observation}.
   */
  public static final String JSON_OBSERVATION = "observations";


  /**
   * Identifiant json {@link #guaranteeRetention}.
   */
  public static final String JSON_GUARANTEE_RETENTION = "retenueGarantie";


  /**
   * Identifiant json {@link #guaranteeRetentionToAmount}.
   */
  public static final String JSON_GUARANTEE_RETENTION_TO_AMOUNT = "retenueGarantieEnMontant";

  /**
   * Identifiant json {@link #guaranteeRetentionToAmountAsString}.
   */
  public static final String JSON_GUARANTEE_RETENTION_TO_AMOUNT_AS_STRING =
      "retenueGarantieEnMontantChaine";


  /**
   * Identifiant json {@link #guaranteeRetentionAsString}.
   */
  public static final String JSON_GUARANTEE_RETENTION_AS_STRING = "retenueGarantieChaine";

  /**
   * Identifiant json {@link #yearBudgetBeforeCarryover}.
   */
  public static final String JSON_YEAR_BUDGET_BEFORE_CARRYOVER =
      "anneeBudgetPriseEnChargeAvantReport";


  /**
   * Identifiant json {@link #plannedPaymentYear}.
   */
  public static final String JSON_PLANNED_PAYMENT_YEAR = "anneePrevisionnelPaiement";


  /**
   * Identifiant json {@link #updatable}.
   */
  public static final String JSON_UPDATABLE = "modifiable";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "activité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
