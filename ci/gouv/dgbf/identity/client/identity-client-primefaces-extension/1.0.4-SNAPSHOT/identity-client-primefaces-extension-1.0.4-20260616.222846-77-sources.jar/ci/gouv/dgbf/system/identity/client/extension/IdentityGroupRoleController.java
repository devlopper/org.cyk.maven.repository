package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleService;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleService.IdentityGroupRoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleService.IdentityGroupRoleUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentityGroupRoleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityGroupRoleController extends AbstractController {

  @Inject
  IdentityGroupRoleClient client;

  @Inject
  IdentityGroupRoleRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentityGroupSelectOneController identityGroupSelectOneController;

  @Inject
  @Getter
  RoleSelectOneController roleSelectOneController;

  @Inject
  @Getter
  IdentityGroupRoleFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentityGroupRoleDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(IdentityGroupRoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentityGroupRoleService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getIdentityGroupIdentifier(),
        IdentityGroupRoleDto.JSON_IDENTITY_GROUP_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getRoleIdentifier(),
        IdentityGroupRoleDto.JSON_ROLE_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    /* Creation */

    listController.getCreateController().addEntityConsumer(entity -> {
      ((IdentityGroupRoleDto) entity)
          .setIdentityGroupIdentifier(filterController.getFilter().getIdentityGroupIdentifier());
      ((IdentityGroupRoleDto) entity)
          .setRoleIdentifier(filterController.getFilter().getRoleIdentifier());
    });
    listController.getCreateController().setFunction(entity -> {
      IdentityGroupRoleCreateRequestDto request =
          requestMapper.mapCreate((IdentityGroupRoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });


    /* Update */

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            IdentityGroupRoleDto.JSON_IDENTITY_GROUP_IDENTIFIER,
            IdentityGroupRoleDto.JSON_ROLE_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(entity -> {
      identityGroupSelectOneController.getSelectOneMenu()
          .writeValue(((IdentityGroupRoleDto) entity).getIdentityGroupIdentifier());

      roleSelectOneController.getSelectOneMenu()
          .writeValue(((IdentityGroupRoleDto) entity).getRoleIdentifier());
    });

    listController.getUpdateController().setFunction(entity -> {
      IdentityGroupRoleUpdateRequestDto request =
          requestMapper.mapUpdate((IdentityGroupRoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */

    identityGroupSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, IdentityGroupRoleDto.JSON_IDENTITY_GROUP_AS_STRING);


    identityGroupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityGroupRoleDto.class)
            .setIdentityGroupIdentifier(identifier));

    roleSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(listController,
        IdentityGroupRoleDto.JSON_ROLE_AS_STRING);

    roleSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityGroupRoleDto.class)
            .setRoleIdentifier(identifier));
  }
}
