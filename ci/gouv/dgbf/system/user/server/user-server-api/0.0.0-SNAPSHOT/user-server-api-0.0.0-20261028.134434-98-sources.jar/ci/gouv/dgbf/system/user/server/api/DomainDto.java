package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasAdministratorCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasAdministratorCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasApplicationCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasApplicationCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DomainDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasApplicationCountDto, HasApplicationCountAsStringDto, HasUserCountDto,
    HasUserCountAsStringDto, HasRoleCountDto, HasRoleCountAsStringDto, HasAdministratorCountDto,
    HasAdministratorCountAsStringDto {

  /**
   * Nombre d'Applications, sans l'Application spéciale du module (RU_UTI_027).
   */
  @JsonbProperty(JSON_APPLICATION_COUNT)
  private Integer applicationCount;

  /**
   * Représentation en chaîne de caractères de {@link #applicationCount}.
   */
  @JsonbProperty(JSON_APPLICATION_COUNT_AS_STRING)
  private String applicationCountAsString;

  /**
   * Nombre d'Utilisateurs du Domaine (RU_UTI_027).
   */
  @JsonbProperty(JSON_USER_COUNT)
  private Integer userCount;

  /**
   * Représentation en chaîne de caractères de {@link #userCount}.
   */
  @JsonbProperty(JSON_USER_COUNT_AS_STRING)
  private String userCountAsString;

  /**
   * Nombre de Rôles métier des Applications du Domaine, sans les Rôles réservés (RU_UTI_027).
   */
  @JsonbProperty(JSON_ROLE_COUNT)
  private Integer roleCount;

  /**
   * Représentation en chaîne de caractères de {@link #roleCount}.
   */
  @JsonbProperty(JSON_ROLE_COUNT_AS_STRING)
  private String roleCountAsString;

  /**
   * Nombre d'administrateurs du Domaine : détenteurs du Rôle ADMINISTRATEUR_DOMAINE (RU_UTI_027).
   */
  @JsonbProperty(JSON_ADMINISTRATOR_COUNT)
  private Integer administratorCount;

  /**
   * Représentation en chaîne de caractères de {@link #administratorCount}.
   */
  @JsonbProperty(JSON_ADMINISTRATOR_COUNT_AS_STRING)
  private String administratorCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDomaine";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "domaineChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "domaine";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

  /**
   * Code du Domaine réservé {@code master} (RG_UTI_DOM_03) : il porte l'administrateur de
   * plus haut niveau et n'est pas ouvert au public.
   */
  public static final String CODE_MASTER = "master";
}
