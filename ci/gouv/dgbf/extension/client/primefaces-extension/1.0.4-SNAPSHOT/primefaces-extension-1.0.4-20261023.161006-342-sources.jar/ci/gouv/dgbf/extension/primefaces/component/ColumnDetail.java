package ci.gouv.dgbf.extension.primefaces.component;

import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une information secondaire affichée sous l'identité d'une ligne (voir
 * {@link Column#initializeAsIdentity()}). Sans {@link #valueFunction}, la valeur est celle du champ
 * {@link #fieldName} de l'enregistrement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ColumnDetail {

  String fieldName;
  /** Faux lorsque l'information n'est pas disponible (par exemple champ non projeté). */
  boolean rendered = true;
  String icon;
  String title;
  Function<Object, Object> valueFunction;
}
