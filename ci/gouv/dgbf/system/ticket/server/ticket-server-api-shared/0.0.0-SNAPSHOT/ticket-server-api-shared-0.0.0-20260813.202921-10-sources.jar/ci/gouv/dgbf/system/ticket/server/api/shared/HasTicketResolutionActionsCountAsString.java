package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de résolution
 * de ticket sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketResolutionActionsCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'actions de résolution de ticket sous forme
   * de chaîne.
   *
   * @return le nombre cumulé d'actions de résolution de ticket sous forme de chaîne
   */
  String getTicketResolutionActionsCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'actions de résolution de ticket sous
   * forme de chaîne.
   *
   * @param ticketResolutionActionsCountAsString le nombre cumulé d'actions de résolution de
   *                                              ticket sous forme de chaîne
   */
  void setTicketResolutionActionsCountAsString(String ticketResolutionActionsCountAsString);

  /**
   * Identifiant java du nombre cumulé d'actions de résolution de ticket sous forme de chaîne.
   */
  String FIELD_TICKET_RESOLUTION_ACTIONS_COUNT_AS_STRING =
      "ticketResolutionActionsCountAsString";
}
