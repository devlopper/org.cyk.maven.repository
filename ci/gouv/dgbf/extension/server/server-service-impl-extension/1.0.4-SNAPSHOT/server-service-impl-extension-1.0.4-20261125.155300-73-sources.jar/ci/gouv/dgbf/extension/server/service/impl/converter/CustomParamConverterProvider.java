package ci.gouv.dgbf.extension.server.service.impl.converter;

import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.inject.Inject;
import jakarta.ws.rs.ext.ParamConverter;
import jakarta.ws.rs.ext.Provider;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;
import java.time.LocalDate;

/**
 * Cette classe représente un fournisseur de convertisseur de type.
 *
 * @author Christian
 *
 */
@Provider
public class CustomParamConverterProvider implements jakarta.ws.rs.ext.ParamConverterProvider {

  @Inject
  StringHelper stringHelper;

  StringHelper stringHelper() {
    if (stringHelper == null) {
      stringHelper = new StringHelper();
    }
    return stringHelper;
  }

  @SuppressWarnings("unchecked")
  @Override
  public <T> ParamConverter<T> getConverter(Class<T> rawType, Type type, Annotation[] annotations) {
    if (LocalDate.class.equals(rawType)) {
      return (ParamConverter<T>) new LocalDateParamConverter(getLocalDatePattern(annotations),
          stringHelper());
    }
    return null;
  }

  String getLocalDatePattern(Annotation[] annotations) {
    if (annotations == null) {
      return ci.gouv.dgbf.extension.server.service.api.converter.LocalDate.PATTERN;
    }
    for (Annotation annotation : annotations) {
      if (annotation instanceof ci.gouv.dgbf.extension.server.service.api.converter.LocalDate l) {
        return l.pattern();
      }
    }
    return ci.gouv.dgbf.extension.server.service.api.converter.LocalDate.PATTERN;
  }
}
