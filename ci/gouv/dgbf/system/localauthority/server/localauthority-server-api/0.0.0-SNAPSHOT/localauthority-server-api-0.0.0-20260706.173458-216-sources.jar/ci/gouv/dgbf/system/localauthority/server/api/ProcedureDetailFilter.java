package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProcedureDetailDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ProcedureDetailFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ProcedureDto}.
   */
  String procedureIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ProcedureDetailFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ProcedureDetailFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    procedureIdentifier = getProcedureIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setProcedureIdentifier(filter, procedureIdentifier);

  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ProcedureDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ProcedureDto}
   */
  public static String getProcedureIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCEDURE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ProcedureDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link ProcedureDto}
   */
  public static void setProcedureIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PROCEDURE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }


  /**
   * Identifiant json champ {@link #procedureIdentifier}.
   */
  public static final String JSON_PROCEDURE_IDENTIFIER =
      ProcedureDetailDto.JSON_PROCEDURE_IDENTIFIER;
}
