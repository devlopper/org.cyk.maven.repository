package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ExpertiseDomainService.ExpertiseDomainCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpertiseDomainService.ExpertiseDomainGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpertiseDomainService.ExpertiseDomainUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ExpertiseDomainService}.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ExpertiseDomainClient extends AbstractClient<ExpertiseDomainService>
    implements GetByIdentifier<ExpertiseDomainDto>,
    GetMany<ExpertiseDomainGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ExpertiseDomainClient service(ExpertiseDomainService service) {
    return (ExpertiseDomainClient) super.service(service);
  }

  /**
   * {@link ExpertiseDomainService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ExpertiseDomainCreateRequestDto request) {
    return new CreateExecutor(ExpertiseDomainService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ExpertiseDomainService#create}.
   *
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    ExpertiseDomainCreateRequestDto request = new ExpertiseDomainCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link ExpertiseDomainService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpertiseDomainGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ExpertiseDomainGetManyResponseDto>(
        ExpertiseDomainGetManyResponseDto.class,
        ExpertiseDomainService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ExpertiseDomainService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpertiseDomainGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ExpertiseDomainService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpertiseDomainDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ExpertiseDomainDto>(ExpertiseDomainDto.class,
        ExpertiseDomainService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ExpertiseDomainService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpertiseDomainDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ExpertiseDomainService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ExpertiseDomainDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ExpertiseDomainDto>(ExpertiseDomainDto.class,
        ExpertiseDomainService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ExpertiseDomainService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpertiseDomainDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ExpertiseDomainService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ExpertiseDomainUpdateRequestDto request) {
    return new IdentifiableExecutor(ExpertiseDomainService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ExpertiseDomainService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    ExpertiseDomainUpdateRequestDto request = new ExpertiseDomainUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link ExpertiseDomainService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ExpertiseDomainService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ExpertiseDomainService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

