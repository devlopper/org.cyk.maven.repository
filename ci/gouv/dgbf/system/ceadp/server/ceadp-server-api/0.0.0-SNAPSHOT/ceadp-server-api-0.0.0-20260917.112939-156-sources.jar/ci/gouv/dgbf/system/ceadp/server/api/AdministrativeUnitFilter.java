package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitFilter extends AbstractIdentifiableFilter {

  /**
   * Nombre de {@link FolderDto} plus grand que zéro.
   */
  Boolean isFolderCountGreaterThanZero;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public AdministrativeUnitFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isFolderCountGreaterThanZero = getIsFolderCountGreaterThanZero(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsFolderCountGreaterThanZero(filter, isFolderCountGreaterThanZero);
  }

  /**
   * Cette méthode permet d'obtenir est nombre de {@link FolderDto} plus grand que zéro.
   *
   * @param filter filtre
   * @return est nombre de {@link FolderDto} plus grand que zéro
   */
  public static Boolean getIsFolderCountGreaterThanZero(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO));
  }

  /**
   * Cette méthode permet d'assigner est nombre de {@link FolderDto} plus grand que zéro.
   *
   * @param filter filtre
   * @param isLate est nombre de {@link FolderDto} plus grand que zéro
   */
  public static void setIsFolderCountGreaterThanZero(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO, f -> f.getValueAsString(),
        f -> f.setValueAsBoolean(isLate));
  }

  /**
   * Identifiant json champ {@link #isFolderCountGreaterThanZero}.
   */
  public static final String JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO = "nombreDossierSuperieurZero";
}

