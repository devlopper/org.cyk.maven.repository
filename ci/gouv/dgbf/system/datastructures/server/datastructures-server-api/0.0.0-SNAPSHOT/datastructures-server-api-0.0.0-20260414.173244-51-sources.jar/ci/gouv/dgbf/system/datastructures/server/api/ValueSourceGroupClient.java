package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupGetValuesCountResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupGetValuesRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupGetValuesResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ValueSourceGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ValueSourceGroupClient extends AbstractClient<ValueSourceGroupService>
    implements GetByIdentifier<ValueSourceGroupDto>, GetMany<ValueSourceGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ValueSourceGroupClient service(ValueSourceGroupService service) {
    return (ValueSourceGroupClient) super.service(service);
  }

  /**
   * {@link ValueSourceGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ValueSourceGroupCreateRequestDto request) {
    return new CreateExecutor(ValueSourceGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ValueSourceGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ValueSourceGroupGetManyResponseDto>(
        ValueSourceGroupGetManyResponseDto.class, ValueSourceGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ValueSourceGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSourceGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ValueSourceGroupService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGroupGetValuesResponseDto getValues(
      ValueSourceGroupGetValuesRequestDto request) {
    return new GetOneExecutor<ValueSourceGroupGetValuesResponseDto>(
        ValueSourceGroupGetValuesResponseDto.class, ValueSourceGroupService.GET_VALUES_IDENTIFIER)
            .execute(() -> service().getValues(request));
  }

  /**
   * {@link ValueSourceGroupService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGroupGetValuesCountResponseDto getValuesCount(ByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSourceGroupGetValuesCountResponseDto>(
        ValueSourceGroupGetValuesCountResponseDto.class,
        ValueSourceGroupService.GET_VALUES_COUNT_IDENTIFIER)
            .execute(() -> service().getValuesCount(request));
  }

  /**
   * {@link ValueSourceGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ValueSourceGroupDto>(ValueSourceGroupDto.class,
        ValueSourceGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ValueSourceGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ValueSourceGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ValueSourceGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ValueSourceGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSourceGroupDto>(ValueSourceGroupDto.class,
        ValueSourceGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ValueSourceGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSourceGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ValueSourceGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ValueSourceGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ValueSourceGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ValueSourceGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ValueSourceGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ValueSourceGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
