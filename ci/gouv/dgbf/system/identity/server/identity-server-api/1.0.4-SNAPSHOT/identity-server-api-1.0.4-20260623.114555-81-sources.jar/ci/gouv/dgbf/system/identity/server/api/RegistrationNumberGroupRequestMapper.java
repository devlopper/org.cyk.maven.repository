package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RegistrationNumberGroupDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RegistrationNumberGroupDto}.

    @author Christian
               """)
public interface RegistrationNumberGroupRequestMapper
    extends RequestMapper<RegistrationNumberGroupDto, 
            RegistrationNumberGroupCreateRequestDto, 
            RegistrationNumberGroupUpdateRequestDto> {
                
}
