package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DomainDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class ApplicationFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Nom.
   */
  private String name;

  /**
   * Identifiant du domaine.
   */
  private String domainIdentifier;

  /**
   * Nom d'utilisateur.
   */
  private String userName;

  /**
   * Nom d'utilisateur dont le role est l'un des rôles réservés d'administration d'Application
   * (Applicatif, Technique ou Fonctionnel).
   */
  private String administratorUserName;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ApplicationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ApplicationFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
    userName = getUserName(filter);
    domainIdentifier = getDomainIdentifier(filter);
    administratorUserName = getAdministratorUserName(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
    setUserName(filter, userName);
    setDomainIdentifier(filter, domainIdentifier);
    setAdministratorUserName(filter, administratorUserName);

  }

  /**
   * Cette méthode permet d'assigner le libelle du application.
   *
   * @param filter filtre
   * @param name   libelle du application
   */

  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir libelle de l'application  assignés.
   *
   * @param filter filtre
   * @return identifiant libelle
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du domaine.
   *
   * @param filter           filtre
   * @param domainIdentifier identifiant du domaine
   */
  public static void setDomainIdentifier(FilterDto filter, String domainIdentifier) {
    set(filter, JSON_DOMAIN_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(domainIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du domaine assigné.
   *
   * @param filter filtre
   * @return identifiant du domaine
   */
  public static String getDomainIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_DOMAIN_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir le nom d'utilisateur.
   *
   * @param filter filtre
   * @return nom d'utilisateur
   */
  public static String getUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom d'utilisateur.
   *
   * @param filter   filtre
   * @param userName nom d'utilisateur
   */
  public static void setUserName(FilterDto filter, String userName) {
    set(filter, JSON_USER_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'assigner le nom d'utilisateur dont le role est l'un des rôles réservés
   * d'administration d'Application.
   *
   * @param filter               filtre
   * @param administratorUserName nom d'utilisateur dont le role est administrateur
   */
  public static void setAdministratorUserName(FilterDto filter, String administratorUserName) {
    set(filter, JSON_ADMINISTRATOR_USER_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(administratorUserName));
  }

  /**
   * Cette méthode permet d'obtenir le nom d'utilisateur dont le role est l'un des rôles réservés
   * d'administration d'Application.
   *
   * @param filter filtre
   * @return nom d'utilisateur dont le role est administrateur
   */
  public static String getAdministratorUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATOR_USER_NAME));
  }

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME =
      ApplicationDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = ApplicationDto.JSON_DOMAIN_IDENTIFIER;

  /**
   * Identifiant json champ {@link #userName}.
   */
  public static final String JSON_USER_NAME = "nomUtilisateur";

  /**
   * Identifiant json champ {@link #administratorUserName}.
   */
  public static final String JSON_ADMINISTRATOR_USER_NAME = "nomUtilisateurAdministrateur";

}
