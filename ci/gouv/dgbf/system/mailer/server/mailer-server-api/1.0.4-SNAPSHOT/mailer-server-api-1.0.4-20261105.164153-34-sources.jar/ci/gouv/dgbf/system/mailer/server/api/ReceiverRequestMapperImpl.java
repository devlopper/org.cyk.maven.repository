package ci.gouv.dgbf.system.mailer.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ReceiverDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T16:42:07+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ReceiverRequestMapperImpl implements ReceiverRequestMapper {

    @Override
    public ReceiverService.ReceiverCreateRequestDto mapCreate(ReceiverDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReceiverService.ReceiverCreateRequestDto receiverCreateRequestDto = new ReceiverService.ReceiverCreateRequestDto();

        receiverCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        receiverCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        receiverCreateRequestDto.setMailIdentifier( arg0.getMailIdentifier() );
        receiverCreateRequestDto.setAddress( arg0.getAddress() );

        return receiverCreateRequestDto;
    }

    @Override
    public ReceiverService.ReceiverUpdateRequestDto mapUpdate(ReceiverDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReceiverService.ReceiverUpdateRequestDto receiverUpdateRequestDto = new ReceiverService.ReceiverUpdateRequestDto();

        receiverUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        receiverUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        receiverUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        receiverUpdateRequestDto.setMailIdentifier( arg0.getMailIdentifier() );
        receiverUpdateRequestDto.setAddress( arg0.getAddress() );

        return receiverUpdateRequestDto;
    }
}
