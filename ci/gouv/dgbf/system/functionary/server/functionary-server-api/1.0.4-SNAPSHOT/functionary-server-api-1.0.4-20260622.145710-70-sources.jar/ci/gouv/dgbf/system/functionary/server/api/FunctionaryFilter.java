package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FunctionaryFilter extends AbstractIdentifiableFilter {

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  String emailAddress;

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  String lastNames;

  /**
   * Nom et prénoms.
   */
  @JsonbProperty(value = JSON_FIRST_NAME_AND_LAST_NAMES)
  String firstNameAndLastNames;

  /**
   * Identifiant du genre.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  String genderIdentifier;

  /**
   * Date de naissance.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE)
  LocalDate birthDate;

  /**
   * Date de première prise de service.
   */
  @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE)
  LocalDate firstServiceStartDate;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public FunctionaryFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public FunctionaryFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    emailAddress = getEmailAddress(filter);
    registrationNumber = getRegistrationNumber(filter);
    firstName = getFirstName(filter);
    lastNames = getLastNames(filter);
    firstNameAndLastNames = getFirstNameAndLastNames(filter);
    birthDate = getBirthDate(filter);
    firstServiceStartDate = getFirstServiceStartDate(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setEmailAddress(filter, emailAddress);
    setRegistrationNumber(filter, registrationNumber);
    setFirstName(filter, firstName);
    setLastNames(filter, lastNames);
    setFirstNameAndLastNames(filter, firstNameAndLastNames);
    setBirthDate(filter, birthDate);
    setFirstServiceStartDate(filter, firstServiceStartDate);
  }

  /**
   * Cette méthode permet d'assigner {@link #emailAddress}.
   *
   * @param filter filtre
   * @param emailAddress {@link #emailAddress}
   */
  public static void setEmailAddress(FilterDto filter, String emailAddress) {
    set(filter, JSON_EMAIL_ADDRESS, f -> f.getValueAsString(),
        f -> f.setValueAsString(emailAddress));
  }

  /**
   * Cette méthode permet d'obtenir {@link #emailAddress}.
   *
   * @param filter filtre
   * @return {@link #emailAddress}
   */
  public static String getEmailAddress(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EMAIL_ADDRESS));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumber}.
   *
   * @param filter filtre
   * @param registrationNumber {@link #registrationNumber}
   */
  public static void setRegistrationNumber(FilterDto filter, String registrationNumber) {
    set(filter, JSON_REGISTRATION_NUMBER, f -> f.getValueAsString(),
        f -> f.setValueAsString(registrationNumber));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumber}.
   *
   * @param filter filtre
   * @return {@link #registrationNumber}
   */
  public static String getRegistrationNumber(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param firstName nom
   */
  public static void setFirstName(FilterDto filter, String firstName) {
    set(filter, JSON_FIRST_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(firstName));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getFirstName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FIRST_NAME));
  }

  /**
   * Cette méthode permet d'assigner les prénoms.
   *
   * @param filter filtre
   * @param lastNames prénoms
   */
  public static void setLastNames(FilterDto filter, String lastNames) {
    set(filter, JSON_LAST_NAMES, f -> f.getValueAsString(), f -> f.setValueAsString(lastNames));
  }

  /**
   * Cette méthode permet d'obtenir les prénoms.
   *
   * @param filter filtre
   * @return prénoms
   */
  public static String getLastNames(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LAST_NAMES));
  }

  /**
   * Cette méthode permet d'assigner le nom et prénoms.
   *
   * @param filter filtre
   * @param firstName nom et prénoms
   */
  public static void setFirstNameAndLastNames(FilterDto filter, String firstName) {
    set(filter, JSON_FIRST_NAME_AND_LAST_NAMES, f -> f.getValueAsString(),
        f -> f.setValueAsString(firstName));
  }

  /**
   * Cette méthode permet d'obtenir le nom et prénoms.
   *
   * @param filter filtre
   * @return nom et prénoms
   */
  public static String getFirstNameAndLastNames(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FIRST_NAME_AND_LAST_NAMES));
  }

  /**
   * Cette méthode permet d'assigner la date de naissance.
   *
   * @param filter filtre
   * @param birthDate date de naissance
   */
  public static void setBirthDate(FilterDto filter, LocalDate birthDate) {
    set(filter, JSON_BIRTH_DATE, f -> f.getValueAsDate(), f -> f.setValueAsDate(birthDate));
  }

  /**
   * Cette méthode permet d'obtenir la date de naissance.
   *
   * @param filter filtre
   * @return date de naissance
   */
  public static LocalDate getBirthDate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsDateByName(JSON_BIRTH_DATE));
  }

  /**
   * Cette méthode permet d'assigner la date de première prise de service.
   *
   * @param filter filtre
   * @param firstServiceStartDate date de première prise de service
   */
  public static void setFirstServiceStartDate(FilterDto filter, LocalDate firstServiceStartDate) {
    set(filter, JSON_FIRST_SERVICE_START_DATE, f -> f.getValueAsDate(),
        f -> f.setValueAsDate(firstServiceStartDate));
  }

  /**
   * Cette méthode permet d'obtenir la date de première prise de service.
   *
   * @param filter filtre
   * @return date de première prise de service
   */
  public static LocalDate getFirstServiceStartDate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsDateByName(JSON_FIRST_SERVICE_START_DATE));
  }

  /**
   * Identifiant json du {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = FunctionaryDto.JSON_EMAIL_ADDRESS;

  /**
   * Identifiant json du {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = FunctionaryDto.JSON_REGISTRATION_NUMBER;

  /**
   * Identifiant json du {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = FunctionaryDto.JSON_FIRST_NAME;

  /**
   * Identifiant json du {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = FunctionaryDto.JSON_LAST_NAMES;

  /**
   * Identifiant json du {@link #firstNameAndLastNames}.
   */
  public static final String JSON_FIRST_NAME_AND_LAST_NAMES =
      FunctionaryDto.JSON_FIRST_NAME_AND_LAST_NAMES;

  /**
   * Identifiant json du {@link #genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = FunctionaryDto.JSON_GENDER_IDENTIFIER;

  /**
   * Identifiant json du {@link #birthDate}.
   */
  public static final String JSON_BIRTH_DATE = FunctionaryDto.JSON_BIRTH_DATE;

  /**
   * Identifiant json du {@link #firstServiceStartDate}.
   */
  public static final String JSON_FIRST_SERVICE_START_DATE =
      FunctionaryDto.JSON_FIRST_SERVICE_START_DATE;
}

