package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire de couleurs.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class FileColorManager {

  String filesGroupStatusCreated;
  String filesGroupStatusCreatedLight;

  String filesGroupStatusConfirmed;
  String filesGroupStatusConfirmedLight;
  
  String filesGroupToProcess;
  String filesGroupToProcessLight;
  
  /**
   * Cette méthode permet d'instancier.
   */
  public FileColorManager() {

    // Créé
    filesGroupStatusCreated = "#4F46E5";
    filesGroupStatusCreatedLight = "#E0E7FF";

    // Confirmé
    filesGroupStatusConfirmed = "#0D9488";
    filesGroupStatusConfirmedLight = "#CCFBF1";

    // À confirmer
    filesGroupToProcess = "#4F46E5";
    filesGroupToProcessLight = "#E0E7FF";
  }
}
