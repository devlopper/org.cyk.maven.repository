package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N.
 *
 * @author Christian
 */
public interface HasRemainingAmountToInputN {

  /**
   * Obtient le montant restant à saisir pour l'année N.
   *
   * @return le montant restant à saisir pour l'année N, {@code null} si aucun plafond n'est défini
   *         pour l'année N
   */
  Long getRemainingAmountToInputN();

  /**
   * Définit le montant restant à saisir pour l'année N.
   *
   * @param remainingAmountToInputN le montant restant à saisir pour l'année N
   */
  void setRemainingAmountToInputN(Long remainingAmountToInputN);
  
  /**
   * Identifiant java du montant restant à saisir pour l'année N.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N = "remainingAmountToInputN";
}
