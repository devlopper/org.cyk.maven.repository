package ci.gouv.dgbf.system.employee.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link EmployeeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class EmployeeFilter extends AbstractIdentifiableFilter {

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  String emailAddress;

  /**
   * Numéro matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  String registrationNumber;

  /**
   * Identifiant groupe de matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
  String registrationNumberGroupIdentifier;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  String lastNames;

  /**
   * Identifiant genre.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  String genderIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    emailAddress = getEmailAddress(filter);
    registrationNumber = getRegistrationNumber(filter);
    registrationNumberGroupIdentifier = getRegistrationNumberGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setEmailAddress(filter, emailAddress);
    setRegistrationNumber(filter, registrationNumber);
    setRegistrationNumberGroupIdentifier(filter, registrationNumberGroupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #emailAddress}.
   *
   * @param filter filtre
   * @param emailAddress {@link #emailAddress}
   */
  public static void setEmailAddress(FilterDto filter, String emailAddress) {
    set(filter, JSON_EMAIL_ADDRESS, f -> f.getValueAsString(), f -> f.setValueAsString(
        emailAddress));
  }

  /**
   * Cette méthode permet d'obtenir {@link #emailAddress}.
   *
   * @param filter filtre
   * @return {@link #emailAddress}
   */
  public static String getEmailAddress(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EMAIL_ADDRESS));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumber}.
   *
   * @param filter filtre
   * @param registrationNumber {@link #registrationNumber}
   */
  public static void setRegistrationNumber(FilterDto filter, String registrationNumber) {
    set(filter, JSON_REGISTRATION_NUMBER, f -> f.getValueAsString(), f -> f.setValueAsString(
        registrationNumber));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumber}.
   *
   * @param filter filtre
   * @return {@link #registrationNumber}
   */
  public static String getRegistrationNumber(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumberGroupIdentifier}.
   *
   * @param filter filtre
   * @param registrationNumberGroupIdentifier {@link #registrationNumberGroupIdentifier}
   */
  public static void setRegistrationNumberGroupIdentifier(FilterDto filter,
      String registrationNumberGroupIdentifier) {
    set(filter, JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER, f -> f.getValueAsString(), f -> f
        .setValueAsString(registrationNumberGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumberGroupIdentifier}.
   *
   * @param filter filtre
   * @return {@link #registrationNumberGroupIdentifier}
   */
  public static String getRegistrationNumberGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(
        JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER));
  }

  /**
   * {@link EmployeeFilter#emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = EmployeeDto.JSON_EMAIL_ADDRESS;
  /**
   * {@link EmployeeFilter#registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = EmployeeDto.JSON_REGISTRATION_NUMBER;
  /**
   * {@link EmployeeFilter#registrationNumberGroupIdentifier}.
   */
  public static final String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER =
      EmployeeDto.JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER;
  /**
   * {@link EmployeeFilter#firstName}.
   */
  public static final String JSON_FIRST_NAME = EmployeeDto.JSON_FIRST_NAME;
  /**
   * {@link EmployeeFilter#lastNames}.
   */
  public static final String JSON_LAST_NAMES = EmployeeDto.JSON_LAST_NAMES;
  /**
   * {@link EmployeeFilter#genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = EmployeeDto.JSON_GENDER_IDENTIFIER;
}

