package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+2.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN2Dto extends HasRemainingAmountToInputN2 {

  /**
   * Identifiant json du montant restant à saisir pour l'année N+2.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N2 = "montantResteASaisirN2";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName