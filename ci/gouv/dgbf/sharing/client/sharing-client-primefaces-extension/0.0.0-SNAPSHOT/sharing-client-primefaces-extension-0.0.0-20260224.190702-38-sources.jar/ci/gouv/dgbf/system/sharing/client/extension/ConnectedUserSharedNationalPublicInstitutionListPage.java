package ci.gouv.dgbf.system.sharing.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des unités administratives partagées de l'utilisateur
 * connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedNationalPublicInstitutionListPage
    extends AbstractConnectedUserSharedAdministrativeUnitListPage {

  @Override
  String resourceName() {
    return "Établissements Publics Nationaux (EPN) partagés";
  }

  @Override
  protected void prepareFilterController() {
    super.prepareFilterController();
    controller.getFilterController().getFilter().setIsNationalPublicInstitution(true);
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "connectedUserSharedNationalPublicInstitutionListPage";

  static final String PATH = "/private/resource/connecteduser/nationalpublicinstitutions.xhtml";
}
