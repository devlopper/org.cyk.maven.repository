package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PayrollPeriodGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PeriodGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollPeriodGroupDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollPeriodGroupDto}.

    @author arnaud
               """)
public interface PayrollPeriodGroupRequestMapper extends RequestMapper<PayrollPeriodGroupDto,
    PayrollPeriodGroupCreateRequestDto, PeriodGroupUpdateRequestDto> {

}
