package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des envois de mails.
 *
 * @author Christian
 *
 */
@Path(SendService.PATH)
@Tag(name = "Gestion des envois de mails")
public interface SendService extends SpecificService {

  String PATH = "envois";

  String CREATE_IDENTIFIER = "CREATION_ENVOI_MAIL";

  String CREATE_PATH = "";

  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création envoi de mail",
      description = "Ce service permet de créer un envoi de mail")
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.APPLICATION_JSON,
      schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SendCreateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(
      value = {SendCreateRequestDto.FIELD_MAIL_IDENTIFIER, AbstractRequestDto.FIELD_AUDIT_WHO})
  @ToString
  class SendCreateRequestDto extends AbstractAuditedRequestJsonDto {

    @NotNull
    @JsonbProperty(value = JSON_MAIL_IDENTIFIER)
    private String mailIdentifier;

    public static final String FIELD_MAIL_IDENTIFIER = "mailIdentifier";

    public static final String JSON_MAIL_IDENTIFIER = SendDto.JSON_MAIL_IDENTIFIER;
  }

  String PROCESS_IDENTIFIER = "TRAITEMENT_ENVOI_MAIL";

  String PROCESS_PATH = "traitement";

  @Path(PROCESS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = PROCESS_IDENTIFIER, summary = "Traitement envoi de mail",
      description = "Ce service permet de traiter un envoi de mail")
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.APPLICATION_JSON,
      schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response process(ByIdentifierRequestDto request);

  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ENVOI_MAIL";

  String GET_MANY_PATH = "obtention/plusieurs";

  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des envois de mails")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<SendDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SendDto> datas;
  }

  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ENVOI_MAIL";

  String GET_ONE_PATH = "obtention/un";

  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un envoi de mail")
  Response getOne(GetOneRequestDto request);

  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ENVOI_MAIL";

  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet de d'obtenir par identifiant un envoi de mail")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  String DELETE_IDENTIFIER = "SUPPRESSION_ENVOI_MAIL";

  String DELETE_PATH = "";

  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un envoi de mail")
  Response delete(DeleteOneRequestDto request);
}
