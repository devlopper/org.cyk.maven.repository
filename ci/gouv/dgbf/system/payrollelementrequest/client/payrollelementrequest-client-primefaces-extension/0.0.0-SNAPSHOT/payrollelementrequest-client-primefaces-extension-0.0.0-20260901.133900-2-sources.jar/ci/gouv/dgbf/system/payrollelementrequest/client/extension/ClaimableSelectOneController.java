package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableService.ClaimableGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection d'un {@link ClaimableDto} -- résolu via
 * {@code TA_RECLAMABLE} (RG_REP_CIB_07), sans appel synchrone au module {@code payroll}.
 * L'appelant doit filtrer par nature via {@link #setFilter(FilterDto)} (ex.
 * {@link ClaimableFilter#setNature(FilterDto, String)}), ce contrôleur étant générique aux deux
 * natures (Élément de Paie/Constante de Paie, RG_REP_EFF_02).
 *
 * @author akm
 *
 */
@Dependent
public class ClaimableSelectOneController extends AbstractSelectOneIdentifiableController<
    ClaimableDto, ClaimableGetManyResponseDto, ClaimableClient> {

  @Getter
  @Inject
  ClaimableClient client;

  protected ClaimableSelectOneController() {
    super(ClaimableDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
