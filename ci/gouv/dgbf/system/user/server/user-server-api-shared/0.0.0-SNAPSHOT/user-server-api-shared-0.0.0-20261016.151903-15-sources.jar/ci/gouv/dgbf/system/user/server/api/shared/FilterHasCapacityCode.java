package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par code de capacité.
 *
 * @author koffi
 */
public interface FilterHasCapacityCode extends HasCapacityCode {

  /**
   * Cette méthode permet de mettre à jour le code de la capacité.
   *
   * @param filter {@link FilterDto}
   */
  default void updateCapacityCode(FilterDto filter) {
    setCapacityCode(CapacityCodeFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour le code de la capacité de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterCapacityCode(FilterDto filter) {
    CapacityCodeFilter.set(filter, getCapacityCode());
  }

}
