package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une période du FUR : un mois, tous types de FUR confondus. Les chiffres
 * ({@link #lineCount}, {@link #claimCount}, {@link #toGenerateCount}, {@link #anomalyCount},
 * {@link #initialCount}, {@link #additiveCount}, {@link #correctiveCount}) ne sont jamais
 * persistés : ils sont calculés par la requête quand la projection le demande.
 * {@link #anomalyCount} ne compte que les lignes déjà consolidées ({@code TA_LIGNE_FUR}) qui
 * portent une anomalie -- contrairement au résumé détaillé par type de FUR, il ne compte pas les
 * lignes écartées avant consolidation.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurPeriodDto extends AbstractIdentifiableAuditableDto {

  /**
   * Premier jour du mois de la période.
   */
  @JsonbProperty(JSON_PERIOD)
  private LocalDate period;

  /**
   * Nombre de Lots initiaux déposés pour la période.
   */
  @JsonbProperty(JSON_INITIAL_COUNT)
  private Long initialCount;

  /**
   * Nombre de Lots additifs déposés pour la période.
   */
  @JsonbProperty(JSON_ADDITIVE_COUNT)
  private Long additiveCount;

  /**
   * Nombre de Lots correctifs déposés pour la période.
   */
  @JsonbProperty(JSON_CORRECTIVE_COUNT)
  private Long correctiveCount;

  /**
   * Nombre de lignes consolidées de la période, tous types de FUR confondus.
   */
  @JsonbProperty(JSON_LINE_COUNT)
  private Long lineCount;

  /**
   * Nombre de lignes consolidées ayant déjà généré une réclamation.
   */
  @JsonbProperty(JSON_CLAIM_COUNT)
  private Long claimCount;

  /**
   * Nombre de lignes consolidées restant à générer.
   */
  @JsonbProperty(JSON_TO_GENERATE_COUNT)
  private Long toGenerateCount;

  /**
   * Nombre de lignes consolidées en anomalie, non générées.
   */
  @JsonbProperty(JSON_ANOMALY_COUNT)
  private Long anomalyCount;

  /**
   * Identifiant json {@link #period}.
   */
  public static final String JSON_PERIOD = PayrollElementClaimImportBatchDto.JSON_PERIOD;

  /**
   * Identifiant json {@link #initialCount}.
   */
  public static final String JSON_INITIAL_COUNT = "nombreInitial";

  /**
   * Identifiant json {@link #additiveCount}.
   */
  public static final String JSON_ADDITIVE_COUNT = "nombreAdditif";

  /**
   * Identifiant json {@link #correctiveCount}.
   */
  public static final String JSON_CORRECTIVE_COUNT = "nombreCorrectif";

  /**
   * Identifiant json {@link #lineCount}.
   */
  public static final String JSON_LINE_COUNT = "nombreLigne";

  /**
   * Identifiant json {@link #claimCount}.
   */
  public static final String JSON_CLAIM_COUNT = "nombreReclamation";

  /**
   * Identifiant json {@link #toGenerateCount}.
   */
  public static final String JSON_TO_GENERATE_COUNT = "nombreAGenerer";

  /**
   * Identifiant json {@link #anomalyCount}.
   */
  public static final String JSON_ANOMALY_COUNT = "nombreAnomalie";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "période du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "périodes du FUR";
}
