package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de rôles métier sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasRoleCountAsStringDto extends HasRoleCountAsString {

  /**
   * Identifiant json du nombre de rôles métier sous forme de chaîne.
   */
  String JSON_ROLE_COUNT_AS_STRING = "nombreRolesChaine";
}
