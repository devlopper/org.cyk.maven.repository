package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurPeriodLineService.FurPeriodLineGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client de {@link FurPeriodLineService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FurPeriodLineClient extends AbstractClient<FurPeriodLineService>
    implements GetMany<FurPeriodLineGetManyResponseDto> {

  @Override
  public FurPeriodLineClient service(FurPeriodLineService service) {
    return (FurPeriodLineClient) super.service(service);
  }

  /**
   * {@link FurPeriodLineService#getCount}.
   *
   * @param request requête
   * @return nombre
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(FurPeriodLineService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link FurPeriodLineService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FurPeriodLineGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FurPeriodLineGetManyResponseDto>(
        FurPeriodLineGetManyResponseDto.class, FurPeriodLineService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link FurPeriodLineService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FurPeriodLineGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }
}
