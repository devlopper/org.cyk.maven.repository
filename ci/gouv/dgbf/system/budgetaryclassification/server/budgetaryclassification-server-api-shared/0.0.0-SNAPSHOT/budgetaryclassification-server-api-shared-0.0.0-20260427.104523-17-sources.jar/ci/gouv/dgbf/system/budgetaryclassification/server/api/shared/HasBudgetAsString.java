package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de budget.
 *
 * @author Christian
 */
public interface HasBudgetAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de budget.
   *
   * @return représentation en chaine de caractères de budget
   */
  String getBudgetAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de budget.
   *
   * @param asString représentation en chaine de caractères de budget
   */
  void setBudgetAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de budget.
   */
  String FIELD_BUDGET_AS_STRING = "budgetAsString";
}
