package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link PayrollElementClaimTypeDto}.
 * Pas de service de suppression (spec-api.md §3.3) : un catalogue déjà exploitable ne se
 * supprime jamais, seule une modification (verrouillée par RG_REP_SOU_10) est possible.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimTypeService.PATH)
@Tag(name = "Gestion des types de réclamation")
public interface PayrollElementClaimTypeService extends Service {

  /**
   * Chemin de base.
   */
  String PATH = "types-reclamation";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface PayrollElementClaimTypeSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollElementClaimTypeGroupDto}.
     *
     * @return l'identifiant de {@link PayrollElementClaimTypeGroupDto}
     */
    String getClaimTypeGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollElementClaimTypeGroupDto}.
     *
     * @param claimTypeGroupIdentifier l'identifiant de {@link PayrollElementClaimTypeGroupDto}
     */
    void setClaimTypeGroupIdentifier(String claimTypeGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir le rôle de traitement.
     *
     * @return le rôle de traitement
     */
    String getRoleTraitement();

    /**
     * Cette méthode permet d'assigner le rôle de traitement.
     *
     * @param roleTraitement le rôle de traitement
     */
    void setRoleTraitement(String roleTraitement);

    /**
     * Cette méthode permet d'obtenir si ce Type est transmissible au Trésor.
     *
     * @return vrai si ce Type est transmissible au Trésor
     */
    Boolean getTreasuryTransmittable();

    /**
     * Cette méthode permet d'assigner si ce Type est transmissible au Trésor.
     *
     * @param treasuryTransmittable vrai si ce Type est transmissible au Trésor
     */
    void setTreasuryTransmittable(Boolean treasuryTransmittable);

    /**
     * Cette méthode permet d'obtenir si le dépôt par le FAE est autorisé.
     *
     * @return vrai si le dépôt par le FAE est autorisé
     */
    Boolean getFunctionaryDepositAuthorized();

    /**
     * Cette méthode permet d'assigner si le dépôt par le FAE est autorisé.
     *
     * @param functionaryDepositAuthorized vrai si le dépôt par le FAE est autorisé
     */
    void setFunctionaryDepositAuthorized(Boolean functionaryDepositAuthorized);

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe de types de document attendus.
     *
     * @return l'identifiant du groupe de types de document attendus
     */
    String getExpectedDocumentTypesGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe de types de document attendus.
     *
     * @param expectedDocumentTypesGroupIdentifier l'identifiant du groupe de types de document
     *        attendus
     */
    void setExpectedDocumentTypesGroupIdentifier(String expectedDocumentTypesGroupIdentifier);

    /**
     * {@link PayrollElementClaimTypeDto#JSON_CLAIM_TYPE_GROUP_IDENTIFIER}.
     */
    String JSON_CLAIM_TYPE_GROUP_IDENTIFIER =
        PayrollElementClaimTypeDto.JSON_CLAIM_TYPE_GROUP_IDENTIFIER;

    /**
     * {@link PayrollElementClaimTypeDto#JSON_ROLE_TRAITEMENT}.
     */
    String JSON_ROLE_TRAITEMENT = PayrollElementClaimTypeDto.JSON_ROLE_TRAITEMENT;

    /**
     * {@link PayrollElementClaimTypeDto#JSON_TREASURY_TRANSMITTABLE}.
     */
    String JSON_TREASURY_TRANSMITTABLE = PayrollElementClaimTypeDto.JSON_TREASURY_TRANSMITTABLE;

    /**
     * {@link PayrollElementClaimTypeDto#JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED}.
     */
    String JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED =
        PayrollElementClaimTypeDto.JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED;

    /**
     * {@link PayrollElementClaimTypeDto#JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER}.
     */
    String JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER =
        PayrollElementClaimTypeDto.JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TYPE_RECLAMATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollElementClaimTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollElementClaimTypeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimTypeCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayrollElementClaimTypeSaveRequestDto {

    @JsonbProperty(JSON_CLAIM_TYPE_GROUP_IDENTIFIER)
    private String claimTypeGroupIdentifier;

    @JsonbProperty(JSON_ROLE_TRAITEMENT)
    private String roleTraitement;

    @JsonbProperty(JSON_TREASURY_TRANSMITTABLE)
    private Boolean treasuryTransmittable;

    @JsonbProperty(JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED)
    private Boolean functionaryDepositAuthorized;

    @JsonbProperty(JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER)
    private String expectedDocumentTypesGroupIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_RECLAMATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollElementClaimTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollElementClaimTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollElementClaimTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TYPE_RECLAMATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TYPE_RECLAMATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PayrollElementClaimTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollElementClaimTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TYPE_RECLAMATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollElementClaimTypeDto}. Refusée par la
   * couche métier tant qu'un Traitement issu d'une réclamation de ce Type est encore en circuit
   * (RG_REP_SOU_10) -- pas une contrainte portée par ce contrat.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollElementClaimTypeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimTypeUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayrollElementClaimTypeSaveRequestDto {

    @JsonbProperty(JSON_CLAIM_TYPE_GROUP_IDENTIFIER)
    private String claimTypeGroupIdentifier;

    @JsonbProperty(JSON_ROLE_TRAITEMENT)
    private String roleTraitement;

    @JsonbProperty(JSON_TREASURY_TRANSMITTABLE)
    private Boolean treasuryTransmittable;

    @JsonbProperty(JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED)
    private Boolean functionaryDepositAuthorized;

    @JsonbProperty(JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER)
    private String expectedDocumentTypesGroupIdentifier;
  }
}
