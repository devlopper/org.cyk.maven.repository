package ci.gouv.dgbf.system.file.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FilesGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-24T13:42:31+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FilesGroupRequestMapperImpl implements FilesGroupRequestMapper {

    @Override
    public FilesGroupService.FilesGroupCreateRequestDto mapCreate(FilesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FilesGroupService.FilesGroupCreateRequestDto filesGroupCreateRequestDto = new FilesGroupService.FilesGroupCreateRequestDto();

        filesGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        filesGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );

        return filesGroupCreateRequestDto;
    }

    @Override
    public FilesGroupService.FilesGroupUpdateRequestDto mapUpdate(FilesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FilesGroupService.FilesGroupUpdateRequestDto filesGroupUpdateRequestDto = new FilesGroupService.FilesGroupUpdateRequestDto();

        filesGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        filesGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        filesGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );

        return filesGroupUpdateRequestDto;
    }
}
