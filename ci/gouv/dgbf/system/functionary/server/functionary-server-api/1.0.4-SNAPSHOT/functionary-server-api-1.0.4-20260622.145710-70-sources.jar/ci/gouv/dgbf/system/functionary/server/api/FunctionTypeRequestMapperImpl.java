package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionTypeDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FunctionTypeRequestMapperImpl implements FunctionTypeRequestMapper {

    @Override
    public FunctionTypeService.FunctionTypeCreateRequestDto mapCreate(FunctionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionTypeService.FunctionTypeCreateRequestDto functionTypeCreateRequestDto = new FunctionTypeService.FunctionTypeCreateRequestDto();

        functionTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionTypeCreateRequestDto.setCode( arg0.getCode() );
        functionTypeCreateRequestDto.setName( arg0.getName() );

        return functionTypeCreateRequestDto;
    }

    @Override
    public FunctionTypeService.FunctionTypeUpdateRequestDto mapUpdate(FunctionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionTypeService.FunctionTypeUpdateRequestDto functionTypeUpdateRequestDto = new FunctionTypeService.FunctionTypeUpdateRequestDto();

        functionTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionTypeUpdateRequestDto.setCode( arg0.getCode() );
        functionTypeUpdateRequestDto.setName( arg0.getName() );

        return functionTypeUpdateRequestDto;
    }
}
