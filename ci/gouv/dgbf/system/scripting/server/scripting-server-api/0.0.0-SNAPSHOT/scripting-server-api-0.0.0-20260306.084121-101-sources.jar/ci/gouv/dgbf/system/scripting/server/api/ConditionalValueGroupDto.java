package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueRetrievalStrategy;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueRetrievalStrategyAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueRetrievalStrategyDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de valeur conditionnée.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ConditionalValueGroupDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasValueTypeDto, HasValueTypeAsStringDto,
    HasValueRetrievalStrategyDto, HasValueRetrievalStrategyAsStringDto, HasDefaultValueDto<String>,
    HasValuesCountAsStringDto, HasValuesMapDto<String, Object> {

  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  @JsonbProperty(JSON_VALUE_RETRIEVAL_STRATEGY)
  private ValueRetrievalStrategy valueRetrievalStrategy;

  @JsonbProperty(JSON_VALUE_RETRIEVAL_STRATEGY_AS_STRING)
  private String valueRetrievalStrategyAsString;

  @JsonbProperty(JSON_DEFAULT_VALUE)
  private String defaultValue;

  @JsonbProperty(JSON_VALUES_COUNT_AS_STRING)
  private String valuesCountAsString;

  private Map<String, Object> valuesMap;
  
  /**
   * Valeur de filtre.
   */
  private String filterValue;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeValeurConditionnee";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeValeurConditionneeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de valeur conditionée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de valeur conditionée";
}
