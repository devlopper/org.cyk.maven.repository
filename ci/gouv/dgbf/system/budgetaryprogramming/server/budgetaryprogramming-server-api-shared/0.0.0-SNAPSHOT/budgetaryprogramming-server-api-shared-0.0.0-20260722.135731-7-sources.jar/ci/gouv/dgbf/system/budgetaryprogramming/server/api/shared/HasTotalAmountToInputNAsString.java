package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputNAsString {

  /**
   * Obtient le montant total à saisir pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant total à saisir pour l'année N sous forme de chaîne de caractères,
   *         {@code null} si aucun plafond n'est défini
   */
  String getTotalAmountToInputNAsString();

  /**
   * Définit le montant total à saisir pour l'année N, sous forme de chaîne de caractères.
   *
   * @param totalAmountToInputNAsString le montant total à saisir pour l'année N sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToInputNAsString(String totalAmountToInputNAsString);

  /**
   * Identifiant java du montant total à saisir pour l'année N, sous forme de chaîne de caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N_AS_STRING = "totalAmountToInputNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
