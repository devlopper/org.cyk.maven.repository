package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une instance d'Élément de Paie (RG_REP_CIB_07), synchronisée depuis le
 * module {@code payroll}, rattachée à son {@link ClaimableDto} {@code ELEMENT_PAIE} parent.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableInstanceDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant du {@link ClaimableDto} {@code ELEMENT_PAIE} dont cette instance dépend.
   */
  @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
  private String claimableIdentifier;

  /**
   * Identifiant, module payroll, de l'instance d'Élément de Paie synchronisée.
   */
  @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
  private String payrollIdentifier;

  /**
   * Date de la dernière synchronisation.
   */
  @JsonbProperty(JSON_SYNCHRONIZATION_DATE)
  private String synchronizationDate;

  /**
   * Identifiant json {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json {@link #payrollIdentifier}.
   */
  public static final String JSON_PAYROLL_IDENTIFIER = "idPayroll";

  /**
   * Identifiant json {@link #synchronizationDate}.
   */
  public static final String JSON_SYNCHRONIZATION_DATE = "dateSynchronisation";

  /**
   * Identifiant json de identifiant de {@link ClaimableInstanceDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamableInstance";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimableInstanceDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamableInstanceChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "instance de réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "instances de réclamable";
}
