package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeGroupDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-11T09:13:15+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementClaimTypeGroupRequestMapperImpl implements PayrollElementClaimTypeGroupRequestMapper {

    @Override
    public PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupCreateRequestDto mapCreate(PayrollElementClaimTypeGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupCreateRequestDto payrollElementClaimTypeGroupCreateRequestDto = new PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupCreateRequestDto();

        payrollElementClaimTypeGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeGroupCreateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeGroupCreateRequestDto.setName( arg0.getName() );

        return payrollElementClaimTypeGroupCreateRequestDto;
    }

    @Override
    public PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupUpdateRequestDto mapUpdate(PayrollElementClaimTypeGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupUpdateRequestDto payrollElementClaimTypeGroupUpdateRequestDto = new PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupUpdateRequestDto();

        payrollElementClaimTypeGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementClaimTypeGroupUpdateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeGroupUpdateRequestDto.setName( arg0.getName() );

        return payrollElementClaimTypeGroupUpdateRequestDto;
    }
}
