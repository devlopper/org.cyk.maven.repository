package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant validé pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountN2AsStringDto extends HasValidatedAmountN2AsString {

  /**
   * Identifiant json du montant validé pour l'année N+2.
   */
  String JSON_VALIDATED_AMOUNT_N2_AS_STRING = "montantValideN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName