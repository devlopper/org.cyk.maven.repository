package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Date;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un modèle de détail de procédure.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcedureDetailModelDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant de {@link ProcedureModelDto}.
   */
  @JsonbProperty(JSON_PROCEDURE_MODEL_IDENTIFIER)
  private String procedureModelIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ProcedureModelDto}.
   */
  @JsonbProperty(JSON_PROCEDURE_MODEL_AS_STRING)
  private String procedureModelAsString;

  /**
   * Ordre.
   */
  @JsonbProperty(JSON_ORDER)
  private Integer order;

  /**
   * Représentation en chaine de caractères d'order.
   */
  @JsonbProperty(JSON_ORDER_AS_STRING)
  private String orderAsString;

  /**
   * Ordre.
   */
  @JsonbProperty(JSON_DETAIL_DATE)
  private Date  detailDate;

  /**
   * Représentation en chaine de caractères de detailDate.
   */
  @JsonbProperty(JSON_DETAIL_DATE_AS_STRING)
  private String detailDateAsString;

  /**
   * Identitiant json {@link ProcedureDetailModelDto#procedureModelIdentifier}.
   */
  public static final String JSON_PROCEDURE_MODEL_IDENTIFIER = "idProcedureModele";

  /**
   * Identitiant json {@link ProcedureDetailModelDto#procedureModelAsString}.
   */
  public static final String JSON_PROCEDURE_MODEL_AS_STRING = "procedureModeleChaine";

  /**
   * Identifiant json {@link ProcedureDetailModelDto#order}.
   */
  public static final String JSON_ORDER = "order";


  /**
   * Identifiant json {@link ProcedureDetailModelDto#orderAsString}.
   */
  public static final String JSON_ORDER_AS_STRING = "orderChaine";

  /**
   * Identifiant json {@link ProcedureDetailModelDto#detailDate}.
   */
  public static final String JSON_DETAIL_DATE = "detailDate";


  /**
   * Identifiant json {@link ProcedureDetailModelDto#detailDateAsString}.
   */
  public static final String JSON_DETAIL_DATE_AS_STRING  = "detailDateChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "modele de detail de procedure";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modeles de detail de procedure";
}

