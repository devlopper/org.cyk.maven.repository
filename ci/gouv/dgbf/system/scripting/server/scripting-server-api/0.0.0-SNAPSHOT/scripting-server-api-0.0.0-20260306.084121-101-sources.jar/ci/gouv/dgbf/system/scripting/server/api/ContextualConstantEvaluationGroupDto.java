package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe d'évaluation des constantes contextuelles.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ContextualConstantEvaluationGroupDto extends AbstractIdentifiableNamableAuditableDto {


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idContextualConstantEvaluationGroup";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "contextualConstantEvaluationGroupChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe d'évaluation des constantes contextuelles";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes d'évaluation des constantes contextuelles";

}
