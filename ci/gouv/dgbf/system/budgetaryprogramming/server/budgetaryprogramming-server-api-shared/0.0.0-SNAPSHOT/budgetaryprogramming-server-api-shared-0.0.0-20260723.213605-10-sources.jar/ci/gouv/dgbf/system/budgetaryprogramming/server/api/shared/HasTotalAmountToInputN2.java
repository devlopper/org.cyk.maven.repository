package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToInputN2 {

  /**
   * Obtient le montant total à saisir pour l'année N+2.
   *
   * @return le montant total à saisir pour l'année N+2
   */
  Long getTotalAmountToInputN2();

  /**
   * Définit le montant total à saisir pour l'année N+2.
   *
   * @param totalAmountToInputN2 le montant total à saisir pour l'année N+2
   */
  void setTotalAmountToInputN2(Long totalAmountToInputN2);

  /**
   * Identifiant java du montant total à saisir pour l'année N+2.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N2 = "totalAmountToInputN2";
}