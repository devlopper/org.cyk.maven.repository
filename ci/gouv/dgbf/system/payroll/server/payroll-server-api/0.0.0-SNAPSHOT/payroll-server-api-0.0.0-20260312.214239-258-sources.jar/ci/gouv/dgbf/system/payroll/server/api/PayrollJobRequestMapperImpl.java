package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollJobDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-12T21:43:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollJobRequestMapperImpl implements PayrollJobRequestMapper {

    @Override
    public PayrollJobService.PayrollJobCreateRequestDto mapCreate(PayrollJobDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobService.PayrollJobCreateRequestDto payrollJobCreateRequestDto = new PayrollJobService.PayrollJobCreateRequestDto();

        payrollJobCreateRequestDto.setName( arg0.getName() );
        payrollJobCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        payrollJobCreateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );

        return payrollJobCreateRequestDto;
    }

    @Override
    public PayrollJobService.PayrollJobUpdateRequestDto mapUpdate(PayrollJobDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobService.PayrollJobUpdateRequestDto payrollJobUpdateRequestDto = new PayrollJobService.PayrollJobUpdateRequestDto();

        payrollJobUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollJobUpdateRequestDto.setName( arg0.getName() );
        payrollJobUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        payrollJobUpdateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );

        return payrollJobUpdateRequestDto;
    }
}
