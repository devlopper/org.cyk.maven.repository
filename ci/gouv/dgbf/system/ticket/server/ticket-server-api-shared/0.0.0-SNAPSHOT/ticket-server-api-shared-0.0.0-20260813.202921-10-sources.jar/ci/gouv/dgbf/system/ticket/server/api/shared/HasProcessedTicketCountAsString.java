package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets traités sous forme
 * de chaîne.
 *
 * @author Christian
 */
public interface HasProcessedTicketCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de tickets traités sous forme de chaîne.
   *
   * @return le nombre de tickets traités sous forme de chaîne
   */
  String getProcessedTicketCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre de tickets traités sous forme de chaîne.
   *
   * @param processedTicketCountAsString le nombre de tickets traités sous forme de chaîne
   */
  void setProcessedTicketCountAsString(String processedTicketCountAsString);

  /**
   * Identifiant java du nombre de tickets traités sous forme de chaîne.
   */
  String FIELD_PROCESSED_TICKET_COUNT_AS_STRING = "processedTicketCountAsString";
}
