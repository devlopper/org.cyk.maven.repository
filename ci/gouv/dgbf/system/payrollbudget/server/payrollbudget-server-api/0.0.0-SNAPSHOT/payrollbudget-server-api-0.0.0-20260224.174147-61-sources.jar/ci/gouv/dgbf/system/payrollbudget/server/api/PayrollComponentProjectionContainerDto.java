package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * {@link PayrollComponentProjectionContainer}.
 */
public interface PayrollComponentProjectionContainerDto
    extends PayrollComponentProjectionContainer {

  /**
   * Identifiant json du montant de référence.
   */
  String JSON_REFERENCE_AMOUNT = "montantReference";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du montant de référence.
   */
  String JSON_REFERENCE_AMOUNT_AS_STRING = "montantReferenceChaine";
  
  /**
   * Identifiant json du montant.
   */
  String JSON_AMOUNT = "montant";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du montant.
   */
  String JSON_AMOUNT_AS_STRING = "montantChaine";
  
  /**
   * Identifiant json de la variance du montant.
   */
  String JSON_AMOUNT_VARIANCE = "varianceMontant";
  
  /**
   * Identifiant json de la représentation en chaine de caractères de la variance du montant.
   */
  String JSON_AMOUNT_VARIANCE_AS_STRING = "varianceMontantChaine";
}
