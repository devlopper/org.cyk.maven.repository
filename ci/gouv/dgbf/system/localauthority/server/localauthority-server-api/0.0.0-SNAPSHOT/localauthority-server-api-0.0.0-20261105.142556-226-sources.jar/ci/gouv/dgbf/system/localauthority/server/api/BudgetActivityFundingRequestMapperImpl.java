package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetActivityFundingDto}.
*
* @author Donsylla
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T14:26:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetActivityFundingRequestMapperImpl implements BudgetActivityFundingRequestMapper {

    @Override
    public BudgetActivityFundingService.BudgetActivityFundingCreateRequestDto mapCreate(BudgetActivityFundingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetActivityFundingService.BudgetActivityFundingCreateRequestDto budgetActivityFundingCreateRequestDto = new BudgetActivityFundingService.BudgetActivityFundingCreateRequestDto();

        budgetActivityFundingCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetActivityFundingCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetActivityFundingCreateRequestDto.setBudgetActivityIdentifier( arg0.getBudgetActivityIdentifier() );
        budgetActivityFundingCreateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        budgetActivityFundingCreateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        budgetActivityFundingCreateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );
        budgetActivityFundingCreateRequestDto.setAmount( arg0.getAmount() );
        budgetActivityFundingCreateRequestDto.setComment( arg0.getComment() );

        return budgetActivityFundingCreateRequestDto;
    }

    @Override
    public BudgetActivityFundingService.BudgetActivityFundingUpdateRequestDto mapUpdate(BudgetActivityFundingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetActivityFundingService.BudgetActivityFundingUpdateRequestDto budgetActivityFundingUpdateRequestDto = new BudgetActivityFundingService.BudgetActivityFundingUpdateRequestDto();

        budgetActivityFundingUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetActivityFundingUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetActivityFundingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetActivityFundingUpdateRequestDto.setBudgetActivityIdentifier( arg0.getBudgetActivityIdentifier() );
        budgetActivityFundingUpdateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        budgetActivityFundingUpdateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        budgetActivityFundingUpdateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );
        budgetActivityFundingUpdateRequestDto.setAmount( arg0.getAmount() );
        budgetActivityFundingUpdateRequestDto.setComment( arg0.getComment() );

        return budgetActivityFundingUpdateRequestDto;
    }
}
