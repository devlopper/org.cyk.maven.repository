package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileService;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe sert la fiche descriptive (PDF) d'un Fichier qui a un Exemplaire physique, pour
 * l'action « Imprimer / télécharger la fiche » (RG_FILE_FIC_18, spec-api § 9.6) : affichée dans
 * le navigateur, d'où elle s'imprime ou s'enregistre. L'acteur de l'audit est l'utilisateur
 * connecté, jamais un paramètre de l'adresse.
 *
 * @author Christian
 *
 */
@WebServlet(FileDescriptiveSheetServlet.URL_PATTERN)
public class FileDescriptiveSheetServlet extends HttpServlet {
  private static final long serialVersionUID = 1L;
  private static final Logger LOGGER =
      Logger.getLogger(FileDescriptiveSheetServlet.class.getName());

  /**
   * Chemin du servlet, relatif à la racine de l'application.
   */
  public static final String URL_PATTERN = "/fichedescriptive";

  /**
   * Nom de fichier servi : fixe, jamais le Nom saisi (en-tête HTTP).
   */
  static final String FILE_NAME = "fiche-descriptive.pdf";

  @Inject
  transient FileClient client;

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    String identifier = request.getParameter(ByIdentifierRequestDto.JSON_IDENTIFIER);
    if (identifier == null || identifier.isBlank()) {
      response.sendError(HttpServletResponse.SC_BAD_REQUEST,
          "L'identifiant du fichier est obligatoire");
      return;
    }
    byte[] pdf;
    try {
      pdf = client.getDescriptiveSheet(identifier, request.getRemoteUser(), null);
    } catch (Exception exception) {
      LOGGER.log(Level.SEVERE, "Fiche descriptive non obtenue. {0}", exception.getMessage());
      response.sendError(HttpServletResponse.SC_CONFLICT, exception.getMessage());
      return;
    }
    response.setContentType(FileService.DESCRIPTIVE_SHEET_MEDIA_TYPE);
    response.setHeader("Content-Disposition", "inline; filename=\"" + FILE_NAME + "\"");
    response.setContentLength(pdf.length);
    response.getOutputStream().write(pdf);
  }
}
