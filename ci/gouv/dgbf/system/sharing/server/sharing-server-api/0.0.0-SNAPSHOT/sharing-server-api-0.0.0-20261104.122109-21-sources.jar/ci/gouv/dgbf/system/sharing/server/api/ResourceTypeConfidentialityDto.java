package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/** Confidentialité par défaut d'un type de ressource. */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceTypeConfidentialityDto extends AbstractIdentifiableAuditableDto {

  @JsonbProperty(JSON_RESOURCE_TYPE)
  private ResourceType resourceType;

  @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL)
  private ConfidentialityLevel confidentialityLevel;

  @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL_AS_STRING)
  private String confidentialityLevelAsString;

  public static final String JSON_RESOURCE_TYPE = "typeRessource";
  public static final String JSON_CONFIDENTIALITY_LEVEL = "niveauConfidentialite";
  public static final String JSON_CONFIDENTIALITY_LEVEL_AS_STRING = "niveauConfidentialiteChaine";
  public static final String NAME = "niveau de confidentialite par type de ressource";
  public static final String PLURAL_NAME = "niveaux de confidentialite par type de ressource";
}
