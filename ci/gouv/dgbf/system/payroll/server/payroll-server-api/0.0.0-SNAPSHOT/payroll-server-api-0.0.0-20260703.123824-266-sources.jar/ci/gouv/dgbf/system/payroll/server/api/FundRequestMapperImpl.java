package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FundDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:38:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FundRequestMapperImpl implements FundRequestMapper {

    @Override
    public FundService.FundCreateRequestDto mapCreate(FundDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundService.FundCreateRequestDto fundCreateRequestDto = new FundService.FundCreateRequestDto();

        fundCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundCreateRequestDto.setCode( arg0.getCode() );
        fundCreateRequestDto.setName( arg0.getName() );
        fundCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );

        return fundCreateRequestDto;
    }

    @Override
    public FundService.FundUpdateRequestDto mapUpdate(FundDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundService.FundUpdateRequestDto fundUpdateRequestDto = new FundService.FundUpdateRequestDto();

        fundUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fundUpdateRequestDto.setCode( arg0.getCode() );
        fundUpdateRequestDto.setName( arg0.getName() );
        fundUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );

        return fundUpdateRequestDto;
    }
}
