package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets actuellement pris
 * en charge (statut PRIS_EN_CHARGE, en cours de traitement).
 *
 * @author Christian
 */
public interface HasClaimedTicketCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de tickets actuellement pris en charge.
   *
   * @return le nombre de tickets actuellement pris en charge
   */
  Integer getClaimedTicketCount();

  /**
   * Cette méthode permet d'assigner le nombre de tickets actuellement pris en charge.
   *
   * @param claimedTicketCount le nombre de tickets actuellement pris en charge
   */
  void setClaimedTicketCount(Integer claimedTicketCount);

  /**
   * Identifiant java du nombre de tickets actuellement pris en charge.
   */
  String FIELD_CLAIMED_TICKET_COUNT = "claimedTicketCount";
}
