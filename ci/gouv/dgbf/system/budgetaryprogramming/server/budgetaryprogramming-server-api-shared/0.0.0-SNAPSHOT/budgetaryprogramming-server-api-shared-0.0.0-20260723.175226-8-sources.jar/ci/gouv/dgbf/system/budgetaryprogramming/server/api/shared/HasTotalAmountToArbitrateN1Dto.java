package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN1Dto extends HasTotalAmountToArbitrateN1 {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N+1.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N1 = "montantTotalAArbitrerN1";
}
