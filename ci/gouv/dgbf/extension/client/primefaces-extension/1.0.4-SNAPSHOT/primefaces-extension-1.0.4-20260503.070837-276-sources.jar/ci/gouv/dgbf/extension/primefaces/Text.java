package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un texte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Text {

  String value;

  String severity;
  
  Boolean rounded;
  
  String icon;
  
  Style style;

  Text marker;

  RenderComponentType renderComponentType;

  Style style() {
    if (style == null) {
      style = new Style();
    }
    return style;
  }

  /**
   * {@link Style#getClassesAsString(Style)}.
   *
   * @return classes du style
   */
  public String getStyleClass() {
    return Style.getClassesAsString(style);
  }

  /**
   * Cette méthode permet d'assigner la classe du style.
   *
   * @param styleClass classe du style.
   */
  public void setStyleClass(String styleClass) {
    style().setClasses(styleClass);
  }

  /**
   * Énumération des types possibles de composants pour le rendu de texte dans l'interface
   * utilisateur JSF.
   * <p>
   * Cette énumération définit les différentes variantes de composants pouvant être utilisées pour
   * afficher du texte, telles que {@code h:outputText} ou {@code p:tag}, permettant une sélection
   * typée du composant de rendu.
   * </p>
   * <p>
   * L'utilisation de cette énumération permet de centraliser et clarifier les options de rendu dans
   * le bean géré, améliorant ainsi la maintenabilité et réduisant les erreurs liées aux littéraux
   * de chaîne.
   * </p>
   *
   * @author Christian
   */
  public enum RenderComponentType {
    /**
     * Rendre le texte en utilisant le composant standard JSF {@code h:outputText}.
     */
    TEXT,

    /**
     * Rendre le texte en utilisant le composant {@code p:tag} d'une bibliothèque de composants (par
     * exemple PrimeFaces).
     */
    TAG
  }

  /**
   * Cette méthode d'obtenir une nouvelle instance de {@link Builder}.
   *
   * @return {@link Builder}.
   */
  public static Builder newBuilder() {
    return new Builder();
  }
  
  /**
   * Cette classe représente un constructeur de {@link LabelValue}.
   *
   * @author Christian
   *
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {
    String value;
    String severity;
    Boolean rounded;
    String icon;
    String style;
    String styleClass;

    String markerValue;
    String markerStyle;
    String markerStyleClass;

    RenderComponentType renderComponentType;

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Text}
     */
    public Text build() {
      Text text = instantiate(value, style, styleClass);
      text.severity = severity;
      text.rounded = rounded;
      text.icon = icon;
      text.marker = instantiate(markerValue, markerStyle, markerStyleClass);
      text.renderComponentType =
          Core.getOrDefaultIfNull(renderComponentType, RenderComponentType.TEXT);
      return text;
    }

    /**
     * Cette méthode permet d'instantier.
     *
     * @param value valeur
     * @param style style
     * @param styleClass classe style
     * @return {@link Text}
     */
    public static Text instantiate(String value, String style, String styleClass) {
      Text text = new Text();
      text.value = value;
      text.style = Style.Builder.instantiate(style, styleClass).build();
      return text;
    }
    
    /**
     * Cette méthode d'obtenir une nouvelle instance.
     *
     * @return {@link Builder}.
     */
    public static Builder newInstance() {
      return new Builder();
    }
  }
}
