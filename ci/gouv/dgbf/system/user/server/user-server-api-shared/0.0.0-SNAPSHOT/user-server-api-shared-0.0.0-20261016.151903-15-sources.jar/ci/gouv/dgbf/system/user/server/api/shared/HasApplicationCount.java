package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'applications.
 *
 * @author Christian Yao Komenan
 */
public interface HasApplicationCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'applications.
   *
   * @return le nombre d'applications
   */
  Integer getApplicationCount();

  /**
   * Cette méthode permet d'assigner le nombre d'applications.
   *
   * @param applicationCount le nombre d'applications
   */
  void setApplicationCount(Integer applicationCount);

  /**
   * Identifiant java du nombre d'applications.
   */
  String FIELD_APPLICATION_COUNT = "applicationCount";
}
