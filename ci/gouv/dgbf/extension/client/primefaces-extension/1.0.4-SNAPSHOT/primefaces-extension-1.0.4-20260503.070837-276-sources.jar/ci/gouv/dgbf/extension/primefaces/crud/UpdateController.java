package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import jakarta.enterprise.context.Dependent;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de mise à jour.
 *
 * @author Christian
 *
 */
@Dependent
public class UpdateController extends AbstractUpdateController<Object, Object> {

  @Getter
  @Setter
  ProjectionDto projection;
  
  @Getter
  @Setter
  Function<Object, Object> function;

  /**
   * Cette méthode permet d'obtenir une projection non nulle.
   *
   * @return projection
   */
  public ProjectionDto projection() {
    if (projection == null) {
      projection = new ProjectionDto();
    }
    return projection;
  }
  
  @Override
  protected Object doExecute() {
    validateFunction();
    return function.apply(entity);
  }

  void validateFunction() {
    if (function == null) {
      throw new IllegalStateException("La fonction de mise à jour ne doit pas être nulle");
    }
  }
  
  @Override
  protected String buildNotificationMessage(Object response) {
    return "modification";
  }
}
