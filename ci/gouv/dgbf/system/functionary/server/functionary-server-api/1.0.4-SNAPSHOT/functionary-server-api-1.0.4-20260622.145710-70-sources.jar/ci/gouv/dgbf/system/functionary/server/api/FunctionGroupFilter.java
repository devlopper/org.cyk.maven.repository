package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class FunctionGroupFilter extends AbstractIdentifiableFilter {
  /**
   * Identifiant de {@link FunctionGroupTypeDto}.
   */
  @JsonbProperty(value = JSON_TYPE_IDENTIFIER)
  String typeIdentifier;


  /**
   * Cette méthode permet d'instancier un objet.
   */
  public FunctionGroupFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public FunctionGroupFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeIdentifier = getTypeIdentifier(filter);

  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTypeIdentifier(filter, typeIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #typeIdentifier}.
   *
   * @param filter filtre
   * @param typeIdentifier {@link #typeIdentifier}
   */
  public static void setTypeIdentifier(FilterDto filter, String typeIdentifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
              f -> f.setValueAsString(typeIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #typeIdentifier}.
   *
   * @param filter filtre
   * @return {@link #typeIdentifier}
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d
      .getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Identifiant json du {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
      FunctionGroupDto.JSON_TYPE_IDENTIFIER;
}
