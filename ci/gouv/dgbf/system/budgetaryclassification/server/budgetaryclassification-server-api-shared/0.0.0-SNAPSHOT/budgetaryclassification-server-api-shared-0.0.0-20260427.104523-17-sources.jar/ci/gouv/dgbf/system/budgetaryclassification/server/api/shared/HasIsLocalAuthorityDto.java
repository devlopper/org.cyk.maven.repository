package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de est collectivité.
 *
 * @author Christian
 */
public interface HasIsLocalAuthorityDto extends HasIsLocalAuthority {

  /**
   * Identifiant json de est collectivité.
   */
  String JSON_IS_LOCAL_AUTHORITY = "estCollectivite";
}
