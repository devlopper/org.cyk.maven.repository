package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de la catégorie de budget.
 *
 * @author Arnaud
 */
public interface HasBudgetCategoryIdentifierDto
       extends HasBudgetCategoryIdentifier {

  /**
   * Identifiant json de l'identifiant de la catégorie de budget.
   */
  String JSON_BUDGET_CATEGORY_IDENTIFIER = "idCategorieBudget";
}