package ci.gouv.dgbf.system.servicecatalog.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link OperationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-01T17:01:40+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class OperationRequestMapperImpl implements OperationRequestMapper {

    @Override
    public OperationService.OperationCreateRequestDto mapCreate(OperationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        OperationService.OperationCreateRequestDto operationCreateRequestDto = new OperationService.OperationCreateRequestDto();

        operationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        operationCreateRequestDto.setCode( arg0.getCode() );
        operationCreateRequestDto.setName( arg0.getName() );
        operationCreateRequestDto.setDescription( arg0.getDescription() );
        operationCreateRequestDto.setExecutionPath( arg0.getExecutionPath() );
        operationCreateRequestDto.setHttpMethod( arg0.getHttpMethod() );
        operationCreateRequestDto.setUseCaseReference( arg0.getUseCaseReference() );
        operationCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );

        return operationCreateRequestDto;
    }

    @Override
    public OperationService.OperationUpdateRequestDto mapUpdate(OperationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        OperationService.OperationUpdateRequestDto operationUpdateRequestDto = new OperationService.OperationUpdateRequestDto();

        operationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        operationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        operationUpdateRequestDto.setCode( arg0.getCode() );
        operationUpdateRequestDto.setName( arg0.getName() );
        operationUpdateRequestDto.setDescription( arg0.getDescription() );
        operationUpdateRequestDto.setExecutionPath( arg0.getExecutionPath() );
        operationUpdateRequestDto.setHttpMethod( arg0.getHttpMethod() );
        operationUpdateRequestDto.setUseCaseReference( arg0.getUseCaseReference() );
        operationUpdateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );

        return operationUpdateRequestDto;
    }
}
