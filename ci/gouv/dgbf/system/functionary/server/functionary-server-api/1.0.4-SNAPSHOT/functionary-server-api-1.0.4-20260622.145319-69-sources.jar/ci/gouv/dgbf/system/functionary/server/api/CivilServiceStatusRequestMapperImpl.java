package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link CivilServiceStatusDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class CivilServiceStatusRequestMapperImpl implements CivilServiceStatusRequestMapper {

    @Override
    public CivilServiceStatusService.CivilServiceStatusCreateRequestDto mapCreate(CivilServiceStatusDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CivilServiceStatusService.CivilServiceStatusCreateRequestDto civilServiceStatusCreateRequestDto = new CivilServiceStatusService.CivilServiceStatusCreateRequestDto();

        civilServiceStatusCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        civilServiceStatusCreateRequestDto.setCode( arg0.getCode() );
        civilServiceStatusCreateRequestDto.setName( arg0.getName() );

        return civilServiceStatusCreateRequestDto;
    }

    @Override
    public CivilServiceStatusService.CivilServiceStatusUpdateRequestDto mapUpdate(CivilServiceStatusDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CivilServiceStatusService.CivilServiceStatusUpdateRequestDto civilServiceStatusUpdateRequestDto = new CivilServiceStatusService.CivilServiceStatusUpdateRequestDto();

        civilServiceStatusUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        civilServiceStatusUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        civilServiceStatusUpdateRequestDto.setCode( arg0.getCode() );
        civilServiceStatusUpdateRequestDto.setName( arg0.getName() );

        return civilServiceStatusUpdateRequestDto;
    }
}
