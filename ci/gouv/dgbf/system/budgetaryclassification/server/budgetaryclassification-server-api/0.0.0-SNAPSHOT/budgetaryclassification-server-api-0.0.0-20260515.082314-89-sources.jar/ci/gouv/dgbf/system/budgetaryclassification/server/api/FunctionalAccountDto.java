package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un compte fonctionnel.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionalAccountDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link FunctionalAccountDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCompteFonctionnel";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FunctionalAccountDto}.
   */
  public static final String JSON_THIS_AS_STRING = "compteFonctionnelChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "compte fonctionnel";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "comptes fonctionnels";
}
