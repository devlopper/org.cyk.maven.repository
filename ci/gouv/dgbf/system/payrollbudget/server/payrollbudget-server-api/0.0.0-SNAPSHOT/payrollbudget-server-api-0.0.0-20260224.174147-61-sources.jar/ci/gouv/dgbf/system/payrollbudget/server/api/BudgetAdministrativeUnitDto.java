package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasSectionAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une unité administrative de {@link BudgetDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetAdministrativeUnitDto extends AbstractIdentifiableDto
    implements HasExerciseIdentifierDto, HasExerciseAsStringDto, HasBudgetIdentifierDto,
    HasAdministrativeUnitIdentifierDto, HasAdministrativeUnitAsStringDto, HasSectionAsStringDto,
    HasBudgetAsStringDto, EmployeeContainerDto, PayrollComponentProjectionContainerDto {

  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  String exerciseIdentifier;

  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  String exerciseAsString;

  /**
   * Identifiant de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  String administrativeUnitAsString;

  /**
   * Représentation en chaine de caractères de section.
   */
  @JsonbProperty(JSON_SECTION_AS_STRING)
  String sectionAsString;

  /**
   * Nombre d'employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT)
  Integer employeeCount;
  
  /**
   * Représentation en chaine de caractères du nombre de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT_AS_STRING)
  String employeeCountAsString;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @Transient
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Représentation en chaine de caractères de la variance du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVarianceAsString;
  
  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   */
  @JsonbProperty(JSON_INCOMING_EMPLOYEE_COUNT_AS_STRING)
  String incomingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   */
  @JsonbProperty(JSON_OUTGOING_EMPLOYEE_COUNT_AS_STRING)
  String outgoingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé ayant {@link MovementDto} ayant
   * {@link MovementTypeDto} avec {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CHANGE_EMPLOYEE_COUNT_AS_STRING)
  String administrativeUnitChangeEmployeeCountAsString;

  /**
   * Identifiant json de identifiant de {@link BudgetAdministrativeUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUniteAdministrativeBudget";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link BudgetAdministrativeUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "uniteAdministrativeBudgetChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "unité administrative de budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "unités administrative de budget";
}
