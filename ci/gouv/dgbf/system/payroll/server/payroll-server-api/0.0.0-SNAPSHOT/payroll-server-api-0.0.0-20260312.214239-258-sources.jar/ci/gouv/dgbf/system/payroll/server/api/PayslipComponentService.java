package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayslipComponentDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = PayslipComponentService.PATH)
@Tag(name = "Gestion des postes de bulletin de paie")
public interface PayslipComponentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "postes-bulletins-paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface PayslipComponentSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipDto}.
     *
     * @return identifiant {@link PayslipDto}
     */
    String getPayslipIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipDto}.
     *
     * @param identifier identifiant {@link PayslipDto}
     */
    void setPayslipIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollComponentDto}.
     *
     * @return identifiant {@link PayrollComponentDto}
     */
    String getPayrollComponentIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollComponentDto}.
     *
     * @param identifier identifiant {@link PayrollComponentDto}
     */
    void setPayrollComponentIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir le numéro d'ordre.
     *
     * @return numéro d'ordre
     */
    Integer getOrderNumber();

    /**
     * Cette méthode permet d'assigner le numéro d'ordre.
     *
     * @param orderdNumber numéro d'ordre
     */
    void setOrderNumber(Integer orderdNumber);

    /**
     * {@link PayslipComponentDto#JSON_PAYSLIP_IDENTIFIER}.
     */
    public static final String JSON_PAYSLIP_IDENTIFIER =
        HasPayslipIdentifierDto.JSON_PAYSLIP_IDENTIFIER;

    /**
     * {@link PayslipComponentDto#JSON_PAYROLL_COMPONENT_IDENTIFIER}.
     */
    public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
        HasPayrollComponentIdentifierDto.JSON_PAYROLL_COMPONENT_IDENTIFIER;

    /**
     * {@link PayslipComponentDto#JSON_EMPLOYER_AMOUNT}.
     */
    public static final String JSON_ORDER_NUMBER = PayslipComponentDto.JSON_ORDER_NUMBER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayslipComponentCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipComponentCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayslipComponentSaveRequestDto {
    /**
     * Identifiant de {@link PayslipDto}.
     */
    @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
    String payslipIdentifier;
    /**
     * Identifiant de {@link PayrollComponentDto}.
     */
    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    String payrollComponentIdentifier;
    /**
     * Numéro d'ordre.
     */
    @JsonbProperty(JSON_ORDER_NUMBER)
    Integer orderNumber;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipComponentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class PayslipComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayslipComponentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayslipComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipComponentDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayslipComponentUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipComponentUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayslipComponentSaveRequestDto {
    /**
     * Identifiant de {@link PayslipDto}.
     */
    @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
    String payslipIdentifier;
    /**
     * Identifiant de {@link PayrollComponentDto}.
     */
    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    String payrollComponentIdentifier;
    /**
     * Numéro d'ordre.
     */
    @JsonbProperty(JSON_ORDER_NUMBER)
    Integer orderNumber;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de calcul des montants.
   */
  String COMPUTE_AMOUNTS_IDENTIFIER = "CALCUL_MONTANTS_POSTE_BULLETIN_PAIE";

  /**
   * Chemin du service de calcul des montants.
   */
  String COMPUTE_AMOUNTS_PATH = "calcul-montants";

  /**
   * Cette méthode permet de calculer les montants {@link PayslipComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(COMPUTE_AMOUNTS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = COMPUTE_AMOUNTS_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response computeAmounts(PayslipComponentComputeAmountsRequestDto request);

  /**
   * Cette classe représente la requête de calcul de montants.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipComponentComputeAmountsRequestDto extends ByIdentifierRequestDto {
    
    /**
     * Le résultat du calcul doit être persisté.
     */
    @JsonbProperty(JSON_PERSIST)
    private Boolean persist;
    
    /**
     * {@link #persist}.
     */
    public static final String JSON_PERSIST = "persister";
  }
}
