package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReimbursementScheduleDto}.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class ReimbursementScheduleFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;

  /**
   * Identifiant {@link ExpenditureSettlementDto}.
   */
  String expenditureSettlementIdentifier;


  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ReimbursementScheduleFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ReimbursementScheduleFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
    expenditureSettlementIdentifier = getExpenditureSettlementIdentifier(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
    setExpenditureSettlementIdentifier(filter, expenditureSettlementIdentifier);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_LOCALAUTHORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCALAUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ExpenditureSettlementDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ExpenditureSettlementDto}
   */
  public static String getExpenditureSettlementIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ExpenditureSettlementDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link ExpenditureSettlementDto}
   */
  public static void setExpenditureSettlementIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      ReimbursementScheduleDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

  /**
   * Identifiant json champ {@link #expenditureSettlementIdentifier}.
   */
  public static final String JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER =
      ReimbursementScheduleDto.JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER;


  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCALAUTHORITY_IDENTIFIER =
      ReimbursementScheduleDto.JSON_LOCALAUTHORITY_IDENTIFIER;

}

