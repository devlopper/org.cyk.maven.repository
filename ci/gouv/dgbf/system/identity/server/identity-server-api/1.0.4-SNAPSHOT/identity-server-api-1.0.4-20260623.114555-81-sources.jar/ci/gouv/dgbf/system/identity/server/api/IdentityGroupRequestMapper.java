package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRolesRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentityGroupDto}.

    @author Christian
               """)
public interface IdentityGroupRequestMapper extends
    RequestMapper<IdentityGroupDto, IdentityGroupCreateRequestDto, IdentityGroupUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper.
   *
   * @param identityGroup {@link IdentityGroupDto}.
   * @return {@link IdentityGroupUpdateRolesRequestDto}
   */
  IdentityGroupUpdateRolesRequestDto mapUpdateRoles(IdentityGroupDto identityGroup);

}
