package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementPositionFieldService.MovementPositionFieldCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementPositionFieldService.MovementPositionFieldUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MovementPositionFieldDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link MovementPositionFieldDto}.

    @author Christian
               """)
public interface MovementPositionFieldRequestMapper extends RequestMapper<MovementPositionFieldDto,
    MovementPositionFieldCreateRequestDto, MovementPositionFieldUpdateRequestDto> {

}
