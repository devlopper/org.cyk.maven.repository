package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollComponentCategoryDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollComponentCategorySelectOneController 
    extends AbstractSelectOneIdentifiableController<PayrollComponentCategoryDto, 
    PayrollComponentCategoryGetManyResponseDto, PayrollComponentCategoryClient> {

  @Getter
  @Inject
  PayrollComponentCategoryClient client;

  protected PayrollComponentCategorySelectOneController() {
    super(PayrollComponentCategoryDto.class, SelectItemLabelStrategy.NAME);
  }
}
