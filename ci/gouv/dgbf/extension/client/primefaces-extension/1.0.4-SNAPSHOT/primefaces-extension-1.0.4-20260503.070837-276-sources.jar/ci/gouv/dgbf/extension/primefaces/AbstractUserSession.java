package ci.gouv.dgbf.extension.primefaces;

import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente la base des utilisateurs.
 *
 * @author Christian
 *
 */
public abstract class AbstractUserSession implements UserSession {

  @Getter
  protected User user;

  @PostConstruct
  void postConstruct() {
    initializeUser();
    deriveUserNullValues();
  }

  void deriveUserNullValues() {
    if (user.getNames() == null) {
      user.setNames(user.getIdentifier());
    }
  }

  protected void initializeUser() {
    user = new User();
    user.setIdentifier(getUserIdentifier());
    Set<String> roles = new LinkedHashSet<>(getUserRoles());
    roles.removeAll(List.of("offline_access", "uma_authorization"));
    user.setRoles(roles);
    Logger.getLogger(getClass().getName()).log(Level.INFO, "Utilisateur initialisé. {0}|Roles:{1}",
        new Object[] {user.getIdentifier(),
            user.getRoles().stream().collect(Collectors.joining(","))});
  }

  public String getUserIdentifier() {
    User u = getUser();
    return u == null ? null : u.getIdentifier();
  }

  protected abstract Set<String> getUserRoles();

  protected abstract String getOidcAuthServerUrl();

  /**
   * Cette méthode permet de déconnecter l'utilisateur.
   *
   * @return navigation
   */
  public String logout() {
    HttpServletRequest request =
        (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    HttpServletResponse response =
        (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
    try {
      logout(request);
      deleteCookies(request, response);
      gotoIndexPage(request);
    } catch (Exception exception) {
      throw new LogoutException(exception);
    }
    return null;
  }

  void logout(HttpServletRequest request) throws ServletException {
    request.getSession().invalidate();
    request.logout();
  }

  void deleteCookies(HttpServletRequest request, HttpServletResponse response) {
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
      for (Cookie cookie : cookies) {
        cookie.setMaxAge(0);
        cookie.setPath("/"); // Assurez-vous que le chemin du cookie correspond au chemin d'origine
        response.addCookie(cookie);
      }
    }
  }

  void gotoIndexPage(HttpServletRequest request) throws IOException {
    FacesContext.getCurrentInstance().getExternalContext()
        .redirect(getOidcAuthServerUrl() + String.format(
            "/protocol/openid-connect/logout?redirect_uri=%s://%s:%s/%s", request.getScheme(),
            request.getServerName(), request.getServerPort(), request.getContextPath()));
  }
}
