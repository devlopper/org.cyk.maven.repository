package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.segregation.HasCapacityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCapacityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.AutoCompleteString;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController.FormLayout;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupClient;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupRequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserGroupService;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link UserGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class UserGroupController extends AbstractController {

  @Inject
  UserGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  UserGroupFilterController filterController;

  @Inject
  UserGroupRequestMapper requestMapper;

  @Inject
  @Getter
  UsersGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  UserSelectOneController userSelectOneController;

  @Inject
  @Getter
  UserCapacitySelectOneController capacitySelectOneController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = UserGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(UserGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(UserGroupService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
        HasUserAsStringDto.JSON_USER_AS_STRING, HasCapacityAsStringDto.JSON_CAPACITY_AS_STRING);

    projection.addNamesIfStringBlank(filterController.getFilter().getGroupIdentifier(),
        HasGroupAsStringDto.JSON_GROUP_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.setFormLayout(FormLayout.STACKED);
    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());

    listController.getCreateController().setFunction(entity -> {
      UserGroupCreateRequestDto request = requestMapper.mapCreate((UserGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
            HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER, HasUserIdentifierDto.JSON_USER_IDENTIFIER,
            HasCapacityIdentifierDto.JSON_CAPACITY_IDENTIFIER,
            HasGroupAsStringDto.JSON_GROUP_AS_STRING, HasUserAsStringDto.JSON_USER_AS_STRING,
            HasCapacityAsStringDto.JSON_CAPACITY_AS_STRING));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    groupSelectOneController
        .setRenderable(StringCore.isBlank(filterController.getFilter().getGroupIdentifier()));
    groupSelectOneController.getAutoComplete().setRequired(true);
    groupSelectOneController.getAutoComplete().addValueConsumer(groupIdentifierConsumer());

    userSelectOneController.getAutoComplete().setRequired(true);
    userSelectOneController.getAutoComplete().addValueConsumer(userIdentifierConsumer());

    capacitySelectOneController.getAutoComplete().addValueConsumer(capacityIdentifierConsumer());
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
      ((UserGroupDto) entity).setGroupIdentifier(filterController.getFilter().getGroupIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      UserGroupDto userGroup = (UserGroupDto) entity;
      writeSelection(groupSelectOneController.getAutoComplete(), userGroup.getGroupIdentifier(),
          userGroup.getGroupAsString());
      writeSelection(userSelectOneController.getAutoComplete(), userGroup.getUserIdentifier(),
          userGroup.getUserAsString());
      writeSelection(capacitySelectOneController.getAutoComplete(),
          userGroup.getCapacityIdentifier(), userGroup.getCapacityAsString());
    };
  }

  private static void writeSelection(AutoCompleteString autoComplete, String identifier,
      String label) {
    if (identifier == null) {
      autoComplete.writeValueAsObject(null);
    } else {
      autoComplete.writeValue(identifier, label == null ? identifier : label);
    }
  }

  Consumer<String> groupIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setGroupIdentifier(identifier);
  }

  Consumer<String> userIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setUserIdentifier(identifier);
  }

  Consumer<String> capacityIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setCapacityIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      UserGroupUpdateRequestDto request = requestMapper.mapUpdate((UserGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }
}
