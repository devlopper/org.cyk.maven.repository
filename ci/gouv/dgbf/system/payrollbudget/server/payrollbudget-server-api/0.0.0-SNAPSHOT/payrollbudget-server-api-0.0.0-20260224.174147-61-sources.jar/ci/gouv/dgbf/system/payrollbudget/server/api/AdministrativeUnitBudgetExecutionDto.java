package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de mouvement {@link AdministrativeUnitBudgetExecutionDto}.
 *
 * @author parfait
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AdministrativeUnitBudgetExecutionDto extends AbstractIdentifiableDto 
        implements AdministrativeUnitBudgetExecutionContainerDto {

  /**
   * Identifiant de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING)
  String budgetAdministrativeUnitAsString;
  
  /**
   * Identifiant de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_BUDGET_EXERCISE_IDENTIFIER)
  String budgetExerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto} de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_EXERCISE_AS_STRING)
  String budgetExerciseAsString;
  
  /**
   * Représentation de l'activité du poste de dépense en chaine de caractères.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  String activityAsString;

  /**
   * Représentation de la nature économique du poste de dépense en chaine de caractères.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  String economicNatureAsString;
  
  /**
   * Représentation en chaine de caractères du montant mandaté.
   */
  @JsonbProperty(JSON_MANDATE_AMOUNT_AS_STRING)
  String mandateAmountAsString;
  
  /**
   * Représentation en chaine de caractères du montant mandaté précédent.
   */
  @JsonbProperty(JSON_MANDATE_AMOUNT_PRECEDENT_AS_STRING)
  String mandateAmountPrecedentAsString;
  
  /**
   * Représentation en chaine de caractères du budget initial.
   */
  @JsonbProperty(JSON_INITIAL_BUDGET_AS_STRING)
  String initialBudgetAsString;
  
  /**
   * Représentation en chaine de caractères du budget initial précédent.
   */
  @JsonbProperty(JSON_INITIAL_BUDGET_PRECEDENT_AS_STRING)
  String initialBudgetPrecedentAsString;
  
  /**
   * Représentation en chaine de caractères du budget actuel.
   */
  @JsonbProperty(JSON_ACTUAL_BUDGET_AS_STRING)
  String actualBudgetAsString;
  
  /**
   * Représentation en chaine de caractères du budget actuel précédent.
   */
  @JsonbProperty(JSON_ACTUAL_BUDGET_PRECEDENT_AS_STRING)
  String actualBudgetPrecedentAsString;
  
  /**
   * Représentation en chaine de caractères du reste du budget exécuté.
   */
  @JsonbProperty(JSON_REMAINING_EXECUTED_BUDGET_AS_STRING)
  String remainingExecutedBudgetAsString;
  
  /**
   * Représentation en chaine de caractères du reste du budget précédent exécuté.
   */
  @JsonbProperty(JSON_REMAINING_EXECUTED_BUDGET_PRECEDENT_AS_STRING)
  String remainingExecutedBudgetPrecedentAsString;
  
  /**
   * Montant de référence.
   */
  @JsonbProperty(JSON_REFERENCE_AMOUNT)
  Long referenceAmount;
  
  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;

  /**
   * Variation du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE)
  Long amountVariation;
  
  /**
   * Représentation en chaine de caractères de la variation du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVariationAsString;
  
  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  Long amount;
  
  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;
  
  /**
   * Identifiant json {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER = 
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant json {@link #budgetAdministrativeUnitAsString}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING = 
      BudgetAdministrativeUnitDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json {@link #budgetExerciseIdentifier}.
   */
  public static final String JSON_BUDGET_EXERCISE_IDENTIFIER = 
      ExerciseDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant json {@link #budgetExerciseAsString}.
   */
  public static final String JSON_BUDGET_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = "activiteChaine";

  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#economicNatureAsString}.
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING =
      "natureEconomiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "budget d'exécution d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "budgets d'exécution d'unité administrative";
}
