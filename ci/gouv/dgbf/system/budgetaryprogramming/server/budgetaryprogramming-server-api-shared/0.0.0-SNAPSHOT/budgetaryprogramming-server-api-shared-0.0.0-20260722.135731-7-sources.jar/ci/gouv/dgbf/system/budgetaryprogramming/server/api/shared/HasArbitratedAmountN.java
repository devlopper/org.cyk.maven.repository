package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant arbitré à l'horizon N.
 *
 * @author Christian
 */
public interface HasArbitratedAmountN extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant arbitré à l'horizon N.
   *
   * @return le montant arbitré à l'horizon N
   */
  Long getArbitratedAmountN();

  /**
   * Cette méthode permet d'assigner le montant arbitré à l'horizon N.
   *
   * @param amount le montant arbitré à l'horizon N
   */
  void setArbitratedAmountN(Long amount);

  /**
   * Identifiant java du montant arbitré à l'horizon N.
   */
  String FIELD_ARBITRATED_AMOUNT_N = "arbitratedAmountN";
}
