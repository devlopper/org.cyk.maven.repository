package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les processus.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ProcessFilter extends AbstractIdentifiableFilter {

  private String moduleIdentifier;
  private ProcessNature nature;
  private Boolean visible;
  private Boolean publicAccess;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ProcessFilter() {}

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ProcessFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    moduleIdentifier = getModuleIdentifier(filter);
    nature = getNature(filter);
    visible = getVisible(filter);
    publicAccess = getPublicAccess(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setModuleIdentifier(filter, moduleIdentifier);
    setNature(filter, nature);
    setVisible(filter, visible);
    setPublicAccess(filter, publicAccess);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du module.
   *
   * @param filter filtre
   * @param moduleIdentifier identifiant du module
   */
  public static void setModuleIdentifier(FilterDto filter, String moduleIdentifier) {
    set(filter, HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(moduleIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du module.
   *
   * @param filter filtre
   * @return identifiant du module
   */
  public static String getModuleIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner la nature.
   *
   * @param filter filtre
   * @param nature nature
   */
  public static void setNature(FilterDto filter, ProcessNature nature) {
    set(filter, ProcessDto.JSON_NATURE, f -> f.getValueAsString(),
        f -> f.setValueAsString(nature == null ? null : nature.getCode()));
  }

  /**
   * Cette méthode permet d'obtenir la nature.
   *
   * @param filter filtre
   * @return nature
   */
  public static ProcessNature getNature(FilterDto filter) {
    String code = get(filter, d -> d.getFieldValueAsStringByName(ProcessDto.JSON_NATURE));
    return code == null || code.isBlank() ? null : ProcessNature.getByCode(code);
  }

  /**
   * Cette méthode permet d'assigner la visibilité.
   *
   * @param filter filtre
   * @param visible visibilité
   */
  public static void setVisible(FilterDto filter, Boolean visible) {
    set(filter, HasVisibleDto.JSON_VISIBLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(visible));
  }

  /**
   * Cette méthode permet d'obtenir la visibilité.
   *
   * @param filter filtre
   * @return visibilité
   */
  public static Boolean getVisible(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(HasVisibleDto.JSON_VISIBLE));
  }

  /**
   * Cette méthode permet d'assigner l'accès public.
   *
   * @param filter filtre
   * @param publicAccess accès public
   */
  public static void setPublicAccess(FilterDto filter, Boolean publicAccess) {
    set(filter, ProcessDto.JSON_PUBLIC_ACCESS, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(publicAccess));
  }

  /**
   * Cette méthode permet d'obtenir l'accès public.
   *
   * @param filter filtre
   * @return accès public
   */
  public static Boolean getPublicAccess(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(ProcessDto.JSON_PUBLIC_ACCESS));
  }
}
