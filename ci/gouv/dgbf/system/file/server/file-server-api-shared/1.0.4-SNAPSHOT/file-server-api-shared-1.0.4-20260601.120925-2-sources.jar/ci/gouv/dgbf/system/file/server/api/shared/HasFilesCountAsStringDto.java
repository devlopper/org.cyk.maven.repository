package ci.gouv.dgbf.system.file.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de nombre de fichiers.
 *
 * @author Christian
 */
public interface HasFilesCountAsStringDto extends HasFilesCountAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de fichiers.
   */
  String JSON_FILES_COUNT_AS_STRING = "nombreFichiersChaine";
}
