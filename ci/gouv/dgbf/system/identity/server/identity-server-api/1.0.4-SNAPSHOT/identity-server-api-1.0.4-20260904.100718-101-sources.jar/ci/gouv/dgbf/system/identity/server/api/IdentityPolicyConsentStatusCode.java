package ci.gouv.dgbf.system.identity.server.api;

/**
 * Cette classe représente les codes de {@link IdentityPolicyConsentStatus}.
 *
 * @author Desysoft
 *
 */
public class IdentityPolicyConsentStatusCode {

  private IdentityPolicyConsentStatusCode() {

  }

  /**
   * Accepté.
   */
  public static final String ACCEPTED = "ACCEPTE";

  /**
   * Refusé.
   */
  public static final String REFUSED = "REFUSE";

  /**
   * Périmé.
   */
  public static final String EXPIRED = "PERIME";
}
