package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SectionUnitService}.
 *
 * @author stephane
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SectionUnitClient extends AbstractClient<SectionUnitService>
    implements GetByIdentifier<SectionUnitDto>, GetMany<SectionUnitGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SectionUnitClient service(SectionUnitService service) {
    return (SectionUnitClient) super.service(service);
  }

  /**
   * {@link SectionUnitService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SectionUnitCreateRequestDto request) {
    return new CreateExecutor(SectionUnitService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SectionUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SectionUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SectionUnitGetManyResponseDto>(SectionUnitGetManyResponseDto.class,
        SectionUnitService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SectionUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SectionUnitGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SectionUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SectionUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SectionUnitDto>(SectionUnitDto.class,
        SectionUnitService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SectionUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SectionUnitDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SectionUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SectionUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SectionUnitDto>(SectionUnitDto.class,
        SectionUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SectionUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SectionUnitDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SectionUnitService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SectionUnitUpdateRequestDto request) {
    return new IdentifiableExecutor(SectionUnitService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SectionUnitService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SectionUnitService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SectionUnitService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
