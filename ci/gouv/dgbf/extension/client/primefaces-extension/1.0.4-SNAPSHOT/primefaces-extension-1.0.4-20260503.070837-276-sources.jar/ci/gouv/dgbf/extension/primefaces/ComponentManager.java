package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ArrayHelper;
import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import ci.gouv.dgbf.extension.primefaces.segregation.Componentable;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le gestionnaire de composant.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ComponentManager {
  private static final Logger LOGGER = Logger.getLogger(ComponentManager.class.getName());

  @Inject
  ArrayHelper arrayHelper;

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet de mettre à jour des {@link Componentable}.
   *
   * @param expressions expressions
   */
  public void updateByExpressions(Set<String> expressions) {
    if (Core.isCollectionNotEmpty(expressions)) {
      PrimeFaces.current().ajax().update(expressions);
    }
  }

  /**
   * Cette méthode permet de mettre à jour des {@link Componentable}.
   *
   * @param expressions expressions
   */
  public void updateByExpressions(String... expressions) {
    if (!Core.isArrayEmpty(expressions)) {
      PrimeFaces.current().ajax().update(expressions);
    }
  }

  /**
   * Cette méthode permet de mettre à jour des {@link Componentable}.
   *
   * @param componentables collection de {@link Componentable}
   */
  public void update(Collection<Componentable> componentables) {
    Core.runIfCollectionNotEmpty(componentables,
        () -> updateByExpressions(computeCompleteIdentifiers(componentables)));
  }

  /**
   * Cette méthode permet de mettre à jour des composants.
   *
   * @param componentables composants
   */
  public void update(Componentable... componentables) {
    if (!Core.isArrayEmpty(componentables)) {
      updateByExpressions(computeCompleteIdentifiers(componentables));
    }
  }

  Set<String> computeCompleteIdentifiers(Collection<Componentable> componentables) {
    return Optional.ofNullable(componentables).orElse(Collections.emptyList()).stream()
        .map(this::computeCompleteIdentifier).collect(Collectors.toSet());
  }

  Set<String> computeCompleteIdentifiers(Componentable... componentables) {
    return Optional.ofNullable(componentables)
        .map(array -> computeCompleteIdentifiers(Arrays.asList(array)))
        .orElse(Collections.emptySet());
  }

  String computeCompleteIdentifier(Componentable componentable) {
    if (stringHelper.isNotBlank(componentable.getCompleteIdentifier())) {
      return componentable.getCompleteIdentifier();
    }
    if (componentable instanceof IdentifiableByString i
        && stringHelper.isNotBlank(i.getIdentifier())) {
      if (componentable.getForm() == null) {
        return i.getIdentifier();
      } else {
        return computeCompleteIdentifier(i.getIdentifier(),
            componentable.getForm().getIdentifier());
      }
    }
    LOGGER.log(Level.WARNING, "Le composant {0} n'a pas d'identifiants définis", componentable);
    return Constant.EMPTY_STRING;
  }

  String computeCompleteIdentifier(String identifier, String formIdentifier) {
    if (stringHelper.isBlank(identifier)) {
      return Constant.EMPTY_STRING;
    }
    if (stringHelper.isBlank(formIdentifier)) {
      return identifier;
    }
    return String.format(":%s:%s", formIdentifier, identifier);
  }
}
