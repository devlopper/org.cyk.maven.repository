package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link DeviceApplicationService}.
 *
 * @author Aranud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class DeviceApplicationClient extends AbstractClient<DeviceApplicationService>
    implements GetByIdentifier<DeviceApplicationDto>, GetMany<DeviceApplicationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public DeviceApplicationClient service(DeviceApplicationService service) {
    return (DeviceApplicationClient) super.service(service);
  }

  /**
   * {@link DeviceApplicationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(DeviceApplicationCreateRequestDto request) {
    return new CreateExecutor(DeviceApplicationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }
  
  /**
   * {@link DeviceApplicationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public DeviceApplicationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<DeviceApplicationGetManyResponseDto>(
        DeviceApplicationGetManyResponseDto.class,
        DeviceApplicationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link DeviceApplicationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DeviceApplicationGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link DeviceApplicationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public DeviceApplicationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<DeviceApplicationDto>(DeviceApplicationDto.class, 
        DeviceApplicationService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link DeviceApplicationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DeviceApplicationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link DeviceApplicationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public DeviceApplicationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<DeviceApplicationDto>(DeviceApplicationDto.class,
        DeviceApplicationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link DeviceApplicationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DeviceApplicationDto getByIdentifier(String identifier, 
        ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link DeviceApplicationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(DeviceApplicationUpdateRequestDto request) {
    return new IdentifiableExecutor(DeviceApplicationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link DeviceApplicationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(DeviceApplicationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link DeviceApplicationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
