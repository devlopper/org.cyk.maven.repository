package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestMultipartDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.annotations.providers.multipart.PartType;

/**
 * Cette interface représente les services de gestion des mails.
 *
 * @author Christian
 *
 */
@Path(MailService.PATH)
@Tag(name = "Gestion des mails")
public interface MailService extends SpecificService {

  String PATH = "mails";

  String CREATE_IDENTIFIER = "CREATION_MAIL";

  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créér.
   *
   * @param request {@link MailCreateRequestDto}.
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création de mail",
      description = "Ce service permet de créer un mail")
  @APIResponse(responseCode = "201", content = {@Content(mediaType = MediaType.APPLICATION_JSON,
      schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MailCreateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {MailCreateRequestDto.FIELD_SUBJECT, MailCreateRequestDto.FIELD_BODY,
      AbstractRequestDto.FIELD_AUDIT_WHO})
  class MailCreateRequestDto extends AbstractAuditedRequestJsonDto {

    @JsonbProperty(value = JSON_SUBJECT)
    private String subject;

    @JsonbProperty(value = JSON_BODY)
    private String body;

    public static final String FIELD_SUBJECT = "subject";
    public static final String FIELD_BODY = "body";

    public static final String JSON_SUBJECT = MailDto.JSON_SUBJECT;
    public static final String JSON_BODY = MailDto.JSON_BODY;
  }

  String SEND_IDENTIFIER = "ENVOI_MAIL";

  String SEND_PATH = "envoi";

  /**
   * Cette méthode permet d'envoyer.
   *
   * @param request {@link MailSendRequestDto}.
   * @return réponse
   */
  @Path(SEND_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SEND_IDENTIFIER, summary = "Envoi de mail",
      description = "Ce service permet d'envoyer un mail")
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.APPLICATION_JSON,
      schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response send(MailSendRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête d'envoi de mail.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {MailSendRequestDto.FIELD_SUBJECT, MailSendRequestDto.FIELD_BODY,
      MailSendRequestDto.FIELD_RECEIVER_ADDRESS, MailSendRequestDto.FIELD_ATTACHMENT_NAME,
      MailSendRequestDto.FIELD_ATTACHMENT_BYTES, AbstractRequestDto.FIELD_AUDIT_WHO})
  class MailSendRequestDto extends AbstractAuditedRequestMultipartDto {

    @NotNull
    @JsonbProperty(value = JSON_SUBJECT)
    @FormParam(value = JSON_SUBJECT)
    @PartType(MediaType.TEXT_PLAIN)
    private String subject;

    @NotNull
    @JsonbProperty(value = JSON_BODY)
    @FormParam(value = JSON_BODY)
    @PartType(MediaType.TEXT_PLAIN)
    private String body;

    @NotNull
    @JsonbProperty(value = JSON_RECEIVER_ADDRESS)
    @FormParam(value = JSON_RECEIVER_ADDRESS)
    @PartType(MediaType.TEXT_PLAIN)
    private String receiverAddress;

    @JsonbProperty(value = JSON_ATTACHMENT_NAME)
    @FormParam(value = JSON_ATTACHMENT_NAME)
    @PartType(MediaType.TEXT_PLAIN)
    private String attachmentName;

    @JsonbProperty(value = JSON_ATTACHMENT_BYTES)
    @FormParam(value = JSON_ATTACHMENT_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    private byte[] attachmentBytes;

    public static final String FIELD_SUBJECT = "subject";
    public static final String FIELD_BODY = "body";
    public static final String FIELD_RECEIVER_ADDRESS = "receiverAddress";
    public static final String FIELD_ATTACHMENT_NAME = "attachmentName";
    public static final String FIELD_ATTACHMENT_BYTES = "attachmentBytes";

    public static final String JSON_SUBJECT = MailDto.JSON_SUBJECT;
    public static final String JSON_BODY = MailDto.JSON_BODY;
    public static final String JSON_RECEIVER_ADDRESS = "adresseDestinataire";
    public static final String JSON_ATTACHMENT_NAME = "nomFichierJoint";
    public static final String JSON_ATTACHMENT_BYTES = "octetsFichierJoint";
  }

  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MAIL";

  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request {@link GetManyRequestDto}.
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des mails")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<MailDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MailDto> datas;
  }

  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MAIL";

  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request {@link GetOneRequestDto}.
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER, description = "Ce service permet d'obtenir un mail")
  Response getOne(GetOneRequestDto request);

  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MAIL";

  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant.
   *
   * @param request {@link GetByIdentifierRequestDto}.
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet de d'obtenir par identifiant un mail")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MAIL";

  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request {@link MailUpdateRequestDto}.
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un mail")
  Response update(MailUpdateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {MailUpdateRequestDto.FIELD_SUBJECT, MailUpdateRequestDto.FIELD_BODY,
      AbstractRequestDto.FIELD_AUDIT_WHO})
  class MailUpdateRequestDto extends ByIdentifierRequestDto {

    @JsonbProperty(value = JSON_SUBJECT)
    private String subject;

    @JsonbProperty(value = JSON_BODY)
    private String body;

    public static final String FIELD_SUBJECT = "subject";
    public static final String FIELD_BODY = "body";

    public static final String JSON_SUBJECT = MailDto.JSON_SUBJECT;
    public static final String JSON_BODY = MailDto.JSON_BODY;
  }

  String DELETE_IDENTIFIER = "SUPPRESSION_MAIL";

  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request {@link DeleteOneRequestDto}.
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un mail")
  Response delete(DeleteOneRequestDto request);
}
