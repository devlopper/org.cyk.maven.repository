package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de {@link IdentityPolicyConsentDto}, en self-service (mes
 * consentements) ou en back-office (consultation de tous les consentements) selon le mode
 * calculé par {@link IdentityPolicyConsentController}.
 *
 * @author desysoft
 *
 */
@Named
@ViewScoped
public class IdentityPolicyConsentListPage extends AbstractPage {

  @Inject
  @Getter
  IdentityPolicyConsentController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    controller.initialize();
    contentTitle = controller.getName();
  }

  public static final String OUTCOME = "myPolicyConsentsListPage";
}
