package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une unité de section budgetaire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetarySectionUnitDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link BudgetarySectionUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUniteSectionBudgetaire";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link BudgetarySectionUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "uniteSectionBudgetaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "organisme";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
