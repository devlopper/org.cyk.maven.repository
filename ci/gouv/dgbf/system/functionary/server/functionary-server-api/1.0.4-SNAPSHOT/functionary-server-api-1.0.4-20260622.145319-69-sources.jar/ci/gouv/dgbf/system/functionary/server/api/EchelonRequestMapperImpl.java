package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link EchelonDto}.
*
* @author AKM
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class EchelonRequestMapperImpl implements EchelonRequestMapper {

    @Override
    public EchelonService.EchelonCreateRequestDto mapCreate(EchelonDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        EchelonService.EchelonCreateRequestDto echelonCreateRequestDto = new EchelonService.EchelonCreateRequestDto();

        echelonCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        echelonCreateRequestDto.setCode( arg0.getCode() );
        echelonCreateRequestDto.setName( arg0.getName() );
        echelonCreateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return echelonCreateRequestDto;
    }

    @Override
    public EchelonService.EchelonUpdateRequestDto mapUpdate(EchelonDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        EchelonService.EchelonUpdateRequestDto echelonUpdateRequestDto = new EchelonService.EchelonUpdateRequestDto();

        echelonUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        echelonUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        echelonUpdateRequestDto.setCode( arg0.getCode() );
        echelonUpdateRequestDto.setName( arg0.getName() );
        echelonUpdateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return echelonUpdateRequestDto;
    }
}
