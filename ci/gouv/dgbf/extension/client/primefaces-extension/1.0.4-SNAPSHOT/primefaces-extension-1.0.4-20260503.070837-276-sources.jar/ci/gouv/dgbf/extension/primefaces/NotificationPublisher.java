package ci.gouv.dgbf.extension.primefaces;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Event;
import jakarta.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente un publicateur d'évènement.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class NotificationPublisher {
  private static final Logger LOGGER = Logger.getLogger(NotificationPublisher.class.getName());
  
  @Inject
  Event<Notification> event;
  
  /**
   * Cette méthode permet de publier un message.
   *
   * @param channel chaine
   * @param message message
   * 
   */
  public void publish(String channel, String message) {
    Notification e = new Notification();
    e.setMessage(message);
    e.setChannel(channel);
    event.fire(e);
    String log = e.toString();
    LOGGER.log(Level.FINEST, log);
  }
}
