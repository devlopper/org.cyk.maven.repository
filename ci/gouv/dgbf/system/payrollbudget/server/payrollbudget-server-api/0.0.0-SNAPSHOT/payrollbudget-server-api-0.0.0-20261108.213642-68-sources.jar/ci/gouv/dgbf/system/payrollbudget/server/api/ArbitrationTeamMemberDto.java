package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Membre d'une équipe d'arbitrage : un agent, et le rôle sous lequel il y figure.
 *
 * <p><strong>Le rôle ne donne aucun droit.</strong> Il dit sous quel titre l'agent a été inscrit
 * dans l'équipe — chargé des mouvements, des mesures ponctuelles, des transferts — et sert à
 * lire la composition d'un coup d'œil. Ce que l'agent peut réellement instruire reste commandé
 * par son profil Keycloak, et par lui seul.</p>
 *
 * <p>Le faire décider des droits aurait été tentant : on aurait composé les équipes sans
 * toucher à Keycloak. Mais deux sources de vérité pour une même question finissent toujours par
 * se contredire, et la question « cet agent peut-il instruire cette ligne ? » se pose déjà
 * partout ailleurs à partir du jeton. Le rôle reste donc une mention.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ArbitrationTeamMemberDto extends AbstractIdentifiableDto {

  /**
   * Équipe dont l'agent est membre.
   */
  @JsonbProperty(JSON_TEAM_IDENTIFIER)
  private String teamIdentifier;

  /**
   * Libellé de l'équipe, alimenté par jointure.
   */
  @JsonbProperty(JSON_TEAM_AS_STRING)
  private String teamAsString;

  /**
   * Identifiant de connexion de l'agent.
   */
  @JsonbProperty(JSON_USER)
  private String user;

  /**
   * Nom lisible de l'agent, servi par le service des identités.
   */
  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Titre sous lequel l'agent figure dans l'équipe. Mention, non pas droit.
   */
  @JsonbProperty(JSON_ROLE)
  private String role;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMembreEquipe";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "membreEquipeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "membre d'équipe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "membres d'équipe";

  /**
   * Identifiant json pour {@link #teamIdentifier}.
   */
  public static final String JSON_TEAM_IDENTIFIER = ArbitrationTeamDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #teamAsString}.
   */
  public static final String JSON_TEAM_AS_STRING = ArbitrationTeamDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #user}.
   */
  public static final String JSON_USER = "utilisateur";

  /**
   * Identifiant json pour {@link #userAsString}.
   */
  public static final String JSON_USER_AS_STRING = "utilisateurChaine";

  /**
   * Identifiant json pour {@link #role}.
   */
  public static final String JSON_ROLE = "role";
}
