package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link GenderDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link GenderDto}.

    @author Christian
               """)
public interface GenderRequestMapper
    extends RequestMapper<GenderDto, GenderCreateRequestDto, GenderUpdateRequestDto> {

}
