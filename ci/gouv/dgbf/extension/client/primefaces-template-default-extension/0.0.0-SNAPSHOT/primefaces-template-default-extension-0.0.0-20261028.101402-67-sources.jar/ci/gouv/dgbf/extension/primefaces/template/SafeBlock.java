package ci.gouv.dgbf.extension.primefaces.template;

import jakarta.faces.component.FacesComponent;
import jakarta.faces.component.UIComponent;
import jakarta.faces.component.UIComponentBase;
import jakarta.faces.context.FacesContext;
import jakarta.faces.context.ResponseWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.util.List;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente une zone protégée du gabarit : si le rendu d'un de ses enfants échoue,
 * la zone disparaît et le reste de la page s'affiche.
 *
 * <p>Le rendu des enfants est capturé en mémoire puis recopié dans la réponse seulement s'il a
 * réussi ({@code ResponseWriter} ne sait pas revenir en arrière). L'erreur est journalisée avec une
 * référence : sans cela, une zone cassée disparaîtrait sans bruit.
 *
 * <p>Seules les erreurs du rendu sont retenues ; celles de la construction de la vue (expressions
 * évaluées au montage) n'atteignent pas cette zone.
 *
 * @author Christian
 */
@FacesComponent(value = SafeBlock.COMPONENT_TYPE, createTag = true, tagName = "safe",
    namespace = SafeBlock.NAMESPACE)
public class SafeBlock extends UIComponentBase {
  public static final String COMPONENT_TYPE =
      "ci.gouv.dgbf.extension.primefaces.template.SafeBlock";
  public static final String NAMESPACE = "https://dgbf.ci/faces/template";
  public static final String FAMILY = "ci.gouv.dgbf.extension.primefaces.template";

  private static final Logger LOGGER = Logger.getLogger(SafeBlock.class.getName());

  @Override
  public String getFamily() {
    return FAMILY;
  }

  @Override
  public boolean getRendersChildren() {
    return true;
  }

  @Override
  public void encodeChildren(FacesContext context) throws IOException {
    renderOrDrop(context, getChildren(), getId());
  }

  /**
   * Cette méthode rend les enfants en mémoire, puis les recopie dans la réponse s'ils ont tous
   * réussi ; sinon, elle les retire de la page et journalise l'erreur.
   *
   * @param context le contexte Faces
   * @param children les composants à rendre
   * @param id l'identifiant de la zone, pour le journal
   * @throws IOException si la réponse est inutilisable
   */
  static void renderOrDrop(FacesContext context, List<UIComponent> children, String id)
      throws IOException {
    ResponseWriter original = context.getResponseWriter();
    StringWriter captured = new StringWriter();
    ResponseWriter capturing = original.cloneWithWriter(captured);
    context.setResponseWriter(capturing);
    try {
      for (UIComponent child : children) {
        child.encodeAll(context);
      }
      capturing.flush();
    } catch (IOException | RuntimeException failure) {
      LOGGER.log(Level.SEVERE, String.format("[%s] Zone %s retirée de la page : son rendu a échoué",
          UUID.randomUUID(), id), failure);
      return;
    } finally {
      context.setResponseWriter(original);
    }
    original.write(captured.toString());
  }
}
