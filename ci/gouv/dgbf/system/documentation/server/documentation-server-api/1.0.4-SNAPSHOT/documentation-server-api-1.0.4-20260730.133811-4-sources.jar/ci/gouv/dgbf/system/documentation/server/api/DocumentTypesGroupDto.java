package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de types de document.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentTypesGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeTypesDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeTypesDocumentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de types de document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de types de document";
}
