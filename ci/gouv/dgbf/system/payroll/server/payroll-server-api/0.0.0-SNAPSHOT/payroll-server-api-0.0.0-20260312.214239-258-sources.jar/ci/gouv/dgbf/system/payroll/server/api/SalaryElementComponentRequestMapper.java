package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementComponentService.SalaryElementComponentCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementComponentService.SalaryElementComponentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SalaryElementComponentDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SalaryElementComponentDto}.

    @author akm
               """)
public interface SalaryElementComponentRequestMapper
    extends RequestMapper<SalaryElementComponentDto, SalaryElementComponentCreateRequestDto,
        SalaryElementComponentUpdateRequestDto> {

}
