package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette classe représente les codes de {@link ActivityChart}.
 *
 * @author Christian
 *
 */
public class ActivityChartCode {

  private ActivityChartCode() {
    
  }
  
  /**
   * Compte des statuts de {@link ActivityDto}.
   */
  public static final String ACTIVITY_STATUS_COUNTS = "COMPTE_STATUT_ACTIVITE";
  
  /**
   * Compte des statuts de {@link TaskDto}.
   */
  public static final String TASK_STATUS_COUNTS = "COMPTE_STATUT_TACHE";
}
