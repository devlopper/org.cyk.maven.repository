package ci.gouv.dgbf.system.identity.client.extension.identity;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityService;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de succès de {@link IdentityService#DECLARE_IDENTIFIER}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityDeclareSuccessPage extends AbstractPage {
  
  @Getter
  String emailAddress;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Déclaration d'identité réussie";
    
    emailAddress = getRequestParameter(EmailAddressFilter.JSON_KEY);
  
    
  }
  
  public static final String OUTCOME = "identityDeclareSuccessPage";
}
