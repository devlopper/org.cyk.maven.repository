package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevelCode;
import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de {@link LogLevelCode}.
 *
 * @author Christian
 */
public interface HasLevelCode extends HasField {

  /**
   * Cette méthode permet d'obtenir {@link LogLevelCode}.
   *
   * @return {@link LogLevelCode}
   */
  String getLevelCode();
  
  /**
   * Cette méthode permet d'assigner {@link LogLevelCode}.
   *
   * @param levelCode {@link LogLevelCode}
   */
  void setLevelCode(String levelCode);
  
  /**
   * Identifiant java de {@link LogLevelCode}.
   */
  String FIELD_LEVEL_CODE = "levelCode";
}
