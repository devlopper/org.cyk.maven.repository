package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.ProcessResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une paie.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements PayslipContainerDto, PayrollIndicatorsDto {

  /**
   * Identifiant {@link PayrollPeriodGroupDto}.
   */
  @JsonbProperty(JSON_PERIOD_GROUP_IDENTIFIER)
  private String periodGroupIdentifier;

  /**
   * Représentation en chaine de caractères {@link PayrollPeriodGroupDto}.
   */
  @JsonbProperty(JSON_PERIOD_GROUP_AS_STRING)
  private String periodGroupAsString;


  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Année {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_YEAR)
  private Integer exerciseYear;

  /**
   * Représentation en chaine de caractères {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant {@link PayrollTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères {@link PayrollTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Date de début.
   */
  @JsonbProperty(JSON_START_DATE)
  private LocalDate startDate;

  /**
   * Représentation en chaine de caractères de {@link #startDate}.
   */
  @JsonbProperty(JSON_START_DATE_AS_STRING)
  private String startDateAsString;

  /**
   * Date de fin.
   */
  @JsonbProperty(JSON_END_DATE)
  private LocalDate endDate;

  /**
   * Représentation en chaine de caractères de {@link #endDate}.
   */
  @JsonbProperty(JSON_END_DATE_AS_STRING)
  private String endDateAsString;

  /**
   * Représentation en chaine de caractères de la période.
   */
  @JsonbProperty(JSON_PERIOD_AS_STRING)
  private String periodAsString;

  /**
   * {@link PayrollStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private PayrollStatus status;

  /**
   * Représentation en chaine de caractères de {@link PayrollStatus}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant du traitement.
   */
  @JsonbProperty(JSON_PROCESSING_IDENTIFIER)
  private String processingIdentifier;

  /*-- Début définition des montants --*/

  /**
   * Représentation en chaine de caractères du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_AS_STRING)
  private String grossAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant brut.
   */
  @JsonbProperty(JSON_PREVIOUS_GROSS_AMOUNT_AS_STRING)
  private String previousGrossAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_VARIATION_AS_STRING)
  private String grossAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant brut imposable.
   */
  @JsonbProperty(JSON_TAXABLE_GROSS_AMOUNT_AS_STRING)
  private String taxableGrossAmountAsString;

  /**
   * Représentation en chaine de caractères du montant brut imposable précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_TAXABLE_GROSS_AMOUNT_AS_STRING)
  private String previousTaxableGrossAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant brut imposable.
   */
  @JsonbProperty(JSON_TAXABLE_GROSS_AMOUNT_VARIATION_AS_STRING)
  private String taxableGrossAmountVariationAsString;

  /**
   * Représentation en chaine de caractères des éléments non soumis.
   */
  @JsonbProperty(JSON_NON_TAXABLE_AMOUNT_AS_STRING)
  private String nonTaxableAmountAsString;

  /**
   * Représentation en chaine de caractères des éléments non soumis précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_NON_TAXABLE_AMOUNT_AS_STRING)
  private String previousNonTaxableAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation des éléments non soumis.
   */
  @JsonbProperty(JSON_NON_TAXABLE_AMOUNT_VARIATION_AS_STRING)
  private String nonTaxableAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant des retenues.
   */
  @JsonbProperty(JSON_DEDUCTIONS_AMOUNT_AS_STRING)
  private String deductionsAmountAsString;

  /**
   * Représentation en chaine de caractères du montant des retenues précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_DEDUCTIONS_AMOUNT_AS_STRING)
  private String previousDeductionsAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant des retenues.
   */
  @JsonbProperty(JSON_DEDUCTIONS_AMOUNT_VARIATION_AS_STRING)
  private String deductionsAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant net.
   */
  @JsonbProperty(JSON_NET_AMOUNT_AS_STRING)
  private String netAmountAsString;

  /**
   * Représentation en chaine de caractères du montant net précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_NET_AMOUNT_AS_STRING)
  private String previousNetAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant net.
   */
  @JsonbProperty(JSON_NET_AMOUNT_VARIATION_AS_STRING)
  private String netAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_AMOUNT_AS_STRING)
  private String employerAmountAsString;

  /**
   * Représentation en chaine de caractères du montant employeur précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_EMPLOYER_AMOUNT_AS_STRING)
  private String previousEmployerAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_AMOUNT_VARIATION_AS_STRING)
  private String employerAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant initialisé.
   */
  @JsonbProperty(JSON_INITIALIZED_AMOUNT_AS_STRING)
  private String initializedAmountAsString;

  /**
   * Représentation en chaine de caractères du montant controlé.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_AS_STRING)
  private String controledAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation controlée.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_VARIATION_AS_STRING)
  private String controledAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant ajusté.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_AS_STRING)
  private String ajustedAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation ajustée.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_VARIATION_AS_STRING)
  private String ajustedAmountVariationAsString;

  /*-- Fin définition des montants --*/

  /**
   * Initialisable.
   */
  @JsonbProperty(JSON_INITIALIZABLE)
  private Boolean initializable;

  /**
   * Initialisation en cours.
   */
  @JsonbProperty(JSON_INITIALIZATION_RUNNING)
  private Boolean initializationRunning;

  /**
   * Initialisation reprenable à partir d'un point.
   */
  @JsonbProperty(JSON_INITIALIZATION_RESUMABLE_FROM_CHECKPOINT)
  private Boolean initializationResumableFromCheckpoint;

  /**
   * Transmettable pour contrôle.
   */
  @JsonbProperty(JSON_TRANSMITTABLE_FOR_CONTROL)
  private Boolean transmittableForControl;

  /**
   * Contrôlable.
   */
  @JsonbProperty(JSON_CONTROLLABLE)
  private Boolean controllable;

  /**
   * Transmettable pour arbitrage.
   */
  @JsonbProperty(JSON_TRANSMITTABLE_FOR_ARBITRATION)
  private Boolean transmittableForArbitration;

  /**
   * Arbitrable.
   */
  @JsonbProperty(JSON_ARBITRABLE)
  private Boolean arbitrable;

  /**
   * Clôturable.
   */
  @JsonbProperty(JSON_CLOSABLE)
  private Boolean closable;

  /* Indicators */

  @JsonbProperty(JSON_ENABLED_REMUNERABLE_COUNT_AS_STRING)
  private String enabledRemunerableCountAsString;

  @JsonbProperty(JSON_DISABLED_REMUNERABLE_COUNT_AS_STRING)
  private String disabledRemunerableCountAsString;

  @JsonbProperty(JSON_CREATED_PAYSLIP_COUNT_AS_STRING)
  private String createdPayslipCountAsString;

  @JsonbProperty(JSON_CREATABLE_PAYSLIP_COUNT_AS_STRING)
  private String creatablePayslipCountAsString;

  @JsonbProperty(JSON_CALCULABLE_PAYSLIP_COUNT)
  private Integer calculablePayslipCount;

  @JsonbProperty(JSON_CALCULABLE_PAYSLIP_COUNT_AS_STRING)
  private String calculablePayslipCountAsString;

  @JsonbProperty(JSON_NON_CALCULABLE_PAYSLIP_COUNT_AS_STRING)
  private String nonCalculablePayslipCountAsString;

  @JsonbProperty(JSON_CALCULATED_PAYSLIP_COUNT_AS_STRING)
  private String calculatedPayslipCountAsString;

  // Counts

  @JsonbProperty(JSON_MOVEMENT_COUNT_AS_STRING)
  private String movementCountAsString;

  @JsonbProperty(JSON_MOVEMENT_DEFERRED_PROPOSED_COUNT_AS_STRING)
  private String movementDeferredProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_DEFERRED_COUNT_AS_STRING)
  private String movementDeferredCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTION_PROPOSED_COUNT_AS_STRING)
  private String movementRejectionProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTED_COUNT_AS_STRING)
  private String movementRejectedCountAsString;
  
  @JsonbProperty(JSON_CONSTANT_COUNT_AS_STRING)
  private String constantCountAsString;

  @JsonbProperty(JSON_COMPONENT_COUNT_AS_STRING)
  private String componentCountAsString;

  @JsonbProperty(JSON_EARNING_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String earningComponentHavingNonZeroAmountCountAsString;

  @JsonbProperty(JSON_DEDUCTION_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String deductionComponentHavingNonZeroAmountCountAsString;

  @JsonbProperty(JSON_COMPONENT_HAVING_NON_BLANK_MESSAGE_COUNT_AS_STRING)
  private String componentHavingNonBlankMessageCountAsString;

  @JsonbProperty(JSON_PAYSLIP_TO_CONTROL_COUNT_AS_STRING)
  private String payslipToControlCountAsString;

  @JsonbProperty(JSON_PAYSLIP_CONTROLLED_COUNT_AS_STRING)
  private String payslipControlledCountAsString;

  @JsonbProperty(JSON_PAYSLIP_VALIDATED_COUNT_AS_STRING)
  private String payslipValidatedCountAsString;

  @JsonbProperty(JSON_PAYSLIP_ACCEPTED_COUNT_AS_STRING)
  private String payslipAcceptedCountAsString;

  @JsonbProperty(JSON_PAYSLIP_TO_LITIGATION_COUNT_AS_STRING)
  private String payslipToLitigationCountAsString;

  @JsonbProperty(JSON_PAYSLIP_QUOTA_COUNT_AS_STRING)
  private String payslipQuotaCountAsString;

  @JsonbProperty(JSON_PAYSLIP_COUNT_AS_STRING)
  private String payslipCountAsString;

  @JsonbProperty(JSON_PAYSLIP_TO_CALCULATE_COUNT_AS_STRING)
  private String payslipToCalculateCountAsString;

  /**
   * Cette méthode permet d'initialiser à partir d'une réponse.
   *
   * @param response résponse
   */
  public void initialize(ProcessResponseDto response) {
    status = response.getStatus();
    statusAsString = response.getStatus().getName();
    initializable = response.getInitializable();
    transmittableForControl = response.getTransmittableForControl();
    controllable = response.getControllable();
    transmittableForArbitration = response.getTransmittableForArbitration();
    arbitrable = response.getArbitrable();
    closable = response.getClosable();
  }

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "paieChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à contrôler.
   */
  public static final String JSON_PAYSLIP_TO_CONTROL_COUNT_AS_STRING =
      "nombreBulletinPaieAControlerChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} contrôlé.
   */
  public static final String JSON_PAYSLIP_CONTROLLED_COUNT_AS_STRING =
      "nombreBulletinPaieControleChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} accepté.
   */
  public static final String JSON_PAYSLIP_ACCEPTEDED_COUNT_AS_STRING =
      "nombreBulletinPaieAccepteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} accepté.
   */
  public static final String JSON_PAYSLIP_VALIDATED_COUNT_AS_STRING =
      "nombreBulletinPaieValideChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} accepté.
   */
  public static final String JSON_PAYSLIP_TO_LITIGATION_COUNT_AS_STRING =
      "nombreBulletinPaieAuContentieuxChaine";

  /**
   * Identifiant json champ {@link #periodGroupIdentifier}.
   */
  public static final String JSON_PERIOD_GROUP_IDENTIFIER =
      PayrollPeriodGroupDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #periodGroupAsString}.
   */
  public static final String JSON_PERIOD_GROUP_AS_STRING =
      PayrollPeriodGroupDto.JSON_THIS_AS_STRING;
  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #exerciseYear}.
   */
  public static final String JSON_EXERCISE_YEAR = ExerciseDto.JSON_THIS_YEAR;

  /**
   * Identifiant json champ {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
      PayrollTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING =
      PayrollTypeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #startDate}.
   */
  public static final String JSON_START_DATE = "dateDebut";

  /**
   * Identifiant json champ {@link #startDateAsString}.
   */
  public static final String JSON_START_DATE_AS_STRING = "dateDebutChaine";

  /**
   * Identifiant json champ {@link #endDate}.
   */
  public static final String JSON_END_DATE = "dateFin";

  /**
   * Identifiant json champ {@link #endDateAsString}.
   */
  public static final String JSON_END_DATE_AS_STRING = "dateFinChaine";

  /**
   * Identifiant json champ {@link #periodAsString}.
   */
  public static final String JSON_PERIOD_AS_STRING = "periodChaine";

  /**
   * Identifiant json champ {@link #processingIdentifier}.
   */
  public static final String JSON_PROCESSING_IDENTIFIER = "idTraitement";

  /**
   * Identifiant json champ {@link #initializable}.
   */
  public static final String JSON_INITIALIZABLE = "initialisable";

  /**
   * Identifiant json champ {@link #initializationRunning}.
   */
  public static final String JSON_INITIALIZATION_RUNNING = "initialisationEnCours";

  /**
   * Identifiant json champ {@link #initializationResumableFromCheckpoint}.
   */
  public static final String JSON_INITIALIZATION_RESUMABLE_FROM_CHECKPOINT =
      "initialisationReprenable";

  /**
   * Identifiant json champ {@link #transmittableForControl}.
   */
  public static final String JSON_TRANSMITTABLE_FOR_CONTROL = "transmettablePourControle";

  /**
   * Identifiant json champ {@link #controllable}.
   */
  public static final String JSON_CONTROLLABLE = "controlable";

  /**
   * Identifiant json champ {@link #transmittableForArbitration}.
   */
  public static final String JSON_TRANSMITTABLE_FOR_ARBITRATION = "transmettablePourArbitrage";

  /**
   * Identifiant json champ {@link #arbitrable}.
   */
  public static final String JSON_ARBITRABLE = "arbitrable";

  /**
   * Identifiant json champ {@link #closable}.
   */
  public static final String JSON_CLOSABLE = "cloturable";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "paies";
}
