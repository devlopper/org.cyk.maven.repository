package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassService.GradeClassCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassService.GradeClassUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link GradeClassDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link GradeClassDto}.

    @author Stéphane
               """)
public interface GradeClassRequestMapper
    extends RequestMapper<GradeClassDto, GradeClassCreateRequestDto, GradeClassUpdateRequestDto> {

}
