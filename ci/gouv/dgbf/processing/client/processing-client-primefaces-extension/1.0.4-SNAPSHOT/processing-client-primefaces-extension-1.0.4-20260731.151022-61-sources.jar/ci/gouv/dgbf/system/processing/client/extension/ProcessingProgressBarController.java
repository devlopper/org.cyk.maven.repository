package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingClient;
import ci.gouv.dgbf.system.processing.server.api.ProcessingDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de la bar de progression de {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingProgressBarController extends AbstractController {

  @Inject
  ProcessingClient client;

  @Getter
  @Setter
  String identifier;

  @Getter
  @Setter
  ProcessingDto processing;

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    if (processing != null) {
      identifier = processing.getIdentifier();
      return;
    }
    if (Core.isStringBlank(identifier)) {
      return;
    }
    processing = client.getByIdentifier(identifier,
        new ProjectionDto().addNames(ProcessingDto.JSON_DESCRIPTIVE,
            ProcessingDto.JSON_TOTAL_WORK_VOLUME_AS_STRING,
            ProcessingDto.JSON_COMPLETED_WORK_VOLUME_AS_STRING,
            ProcessingDto.JSON_WORK_COMPLETION_RATE, ProcessingDto.JSON_IS_WORK_COMPLETED,
            ProcessingDto.JSON_START_DATE_AS_STRING),
        userIdentifier, null);

  }

  /**
   * Cette méthode permet d'obtenir le template du libellé.
   *
   * @return template du libellé
   */
  public String getLabelTemplate() {
    return "%s".formatted(processing.getWorkCompletionRate()) + "%";
  }

  /**
   * Cette méthode permet de récuperer les données du serveur.
   */
  public void poll() {
    if (Core.isStringBlank(identifier)) {
      return;
    }
    ProcessingDto dto = client.getByIdentifier(identifier,
        new ProjectionDto().addNames(ProcessingDto.JSON_COMPLETED_WORK_VOLUME_AS_STRING,
            ProcessingDto.JSON_WORK_COMPLETION_RATE, ProcessingDto.JSON_IS_WORK_COMPLETED),
        userIdentifier, null);
    processing.setCompletedWorkVolumeAsString(dto.getCompletedWorkVolumeAsString());
    processing.setWorkCompletionRate(dto.getWorkCompletionRate());
    processing.setIsWorkCompleted(dto.getIsWorkCompleted());
  }
}
