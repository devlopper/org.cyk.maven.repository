package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MovementDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:38:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MovementRequestMapperImpl implements MovementRequestMapper {

    @Override
    public MovementService.MovementCreateRequestDto mapCreate(MovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementService.MovementCreateRequestDto movementCreateRequestDto = new MovementService.MovementCreateRequestDto();

        movementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementCreateRequestDto.setRemunerableIdentifier( arg0.getRemunerableIdentifier() );
        movementCreateRequestDto.setPayrollElementInstanceIdentifier( arg0.getPayrollElementInstanceIdentifier() );
        movementCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        movementCreateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );
        movementCreateRequestDto.setApplicationDate( arg0.getApplicationDate() );

        return movementCreateRequestDto;
    }

    @Override
    public MovementService.MovementUpdateRequestDto mapUpdate(MovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementService.MovementUpdateRequestDto movementUpdateRequestDto = new MovementService.MovementUpdateRequestDto();

        movementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        movementUpdateRequestDto.setRemunerableIdentifier( arg0.getRemunerableIdentifier() );
        movementUpdateRequestDto.setPayrollElementInstanceIdentifier( arg0.getPayrollElementInstanceIdentifier() );
        movementUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        movementUpdateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );
        movementUpdateRequestDto.setApplicationDate( arg0.getApplicationDate() );

        return movementUpdateRequestDto;
    }
}
