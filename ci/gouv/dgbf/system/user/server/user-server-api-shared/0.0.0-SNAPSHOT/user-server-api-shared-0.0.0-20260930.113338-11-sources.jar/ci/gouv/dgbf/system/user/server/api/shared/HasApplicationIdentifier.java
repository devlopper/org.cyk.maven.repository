package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'application.
 *
 * @author BoobaCool
 */
public interface HasApplicationIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'application.
   *
   * @return identifiant de l'application
   */
  String getApplicationIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'application.
   *
   * @param applicationIdentifier identifiant de l'application
   */
  void setApplicationIdentifier(String applicationIdentifier);

  /**
   * Identifiant java de l'identifiant de l'application.
   */
  String FIELD_APPLICATION_IDENTIFIER = "applicationIdentifier";
}
