package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityGroupRoleDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T17:06:38+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityGroupRoleRequestMapperImpl implements IdentityGroupRoleRequestMapper {

    @Override
    public IdentityGroupRoleService.IdentityGroupRoleCreateRequestDto mapCreate(IdentityGroupRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityGroupRoleService.IdentityGroupRoleCreateRequestDto identityGroupRoleCreateRequestDto = new IdentityGroupRoleService.IdentityGroupRoleCreateRequestDto();

        identityGroupRoleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityGroupRoleCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityGroupRoleCreateRequestDto.setIdentityGroupIdentifier( arg0.getIdentityGroupIdentifier() );
        identityGroupRoleCreateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return identityGroupRoleCreateRequestDto;
    }

    @Override
    public IdentityGroupRoleService.IdentityGroupRoleUpdateRequestDto mapUpdate(IdentityGroupRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityGroupRoleService.IdentityGroupRoleUpdateRequestDto identityGroupRoleUpdateRequestDto = new IdentityGroupRoleService.IdentityGroupRoleUpdateRequestDto();

        identityGroupRoleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityGroupRoleUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityGroupRoleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identityGroupRoleUpdateRequestDto.setIdentityGroupIdentifier( arg0.getIdentityGroupIdentifier() );
        identityGroupRoleUpdateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return identityGroupRoleUpdateRequestDto;
    }
}
