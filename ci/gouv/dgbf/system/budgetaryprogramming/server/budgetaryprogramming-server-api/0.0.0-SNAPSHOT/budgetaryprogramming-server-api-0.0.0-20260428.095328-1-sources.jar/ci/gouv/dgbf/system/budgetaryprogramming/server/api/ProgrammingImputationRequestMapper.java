package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingImputationService.ProgrammingImputationCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingImputationService.ProgrammingImputationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingImputationDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingImputationDto}.

    @author Christian
               """)
public interface ProgrammingImputationRequestMapper
    extends RequestMapper<ProgrammingImputationDto, ProgrammingImputationCreateRequestDto,
        ProgrammingImputationUpdateRequestDto> {

}
