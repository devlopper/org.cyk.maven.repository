package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BeneficiaryDto}.
 *
 * @author Desysoft
 */
@Path(value = BeneficiaryService.PATH)
@Tag(name = "Gestion des bénéficiaires")
public interface BeneficiaryService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "beneficiaires";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_BENEFICIAIRE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un bénéficiaire",
      description = "Ce service permet de créer un bénéficiaire")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BeneficiaryCreateRequestDto request);


  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Desysoft
   */
  interface SaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le relevé d'identité bancaire (RIB).
     *
     * @return bankAccountDetails
     */
    String getBankAccountDetails();


    /**
     * Cette méthode permet d'assigner le relevé d'identité bancaire (RIB).
     *
     * @param bankAccountDetails relevé d'identité bancaire (RIB)
     */
    void setBankAccountDetails(String bankAccountDetails);


    /**
     * Cette méthode permet d'obtenir le document justificatif.
     *
     * @return supportingDocument
     */
    String getSupportingDocument();


    /**
     * Cette méthode permet d'assigner le document justificatif.
     *
     * @param supportingDocument document justificatif
     */
    void setSupportingDocument(String supportingDocument);



    /**
     * Cette méthode permet d'obtenir le type de personne juridique.
     *
     * @return personType
     */
    PersonType getPersonType();


    /**
     * Cette méthode permet d'assigner le type de personne juridique.
     *
     * @param personType type de personne juridique
     */
    void setPersonType(PersonType personType);


    /**
     * Cette méthode permet d'obtenir l'identitant de {@link LocalAuthorityDto}.
     *
     * @return identifiant de {@link LocalAuthorityDto}
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
     *
     * @param identifier identifiant de {@link LocalAuthorityDto}
     */
    void setLocalAuthorityIdentifier(String identifier);


    /**
     * Identifiant champ json du titre.
     */
    String JSON_BANK_ACCOUNT_DETAILS = BeneficiaryDto.JSON_BANK_ACCOUNT_DETAILS;


    /**
     * Identifiant json du document justificatif.
     */
    String JSON_SUPPORTING_DOCUMENT = BeneficiaryDto.JSON_SUPPORTING_DOCUMENT;

    /**
     * Identifiant json du type de personne juridique.
     */
    String JSON_PERSON_TYPE = BeneficiaryDto.JSON_PERSON_TYPE;


    /**
     * Identifiant json du champ de l'identitant de {@link LocalAuthorityDto}.
     */
    String JSON_LOCAL_AUTHORITY_IDENTIFIER =
        ActivityDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;
  }


  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {AbstractCodableCreateRequestJsonDto.FIELD_CODE,
      AbstractCodableNamableCreateRequestJsonDto.FIELD_NAME, AbstractRequestDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION})
  class BeneficiaryCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SaveRequestDto {

    @JsonbProperty(JSON_BANK_ACCOUNT_DETAILS)
    private String bankAccountDetails;


    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUPPORTING_DOCUMENT)
    private String supportingDocument;

    @JsonbProperty(JSON_PERSON_TYPE)
    private PersonType personType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_BENEFICIAIRES";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des bénéficiaires")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BeneficiaryGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class BeneficiaryGetManyResponseDto extends AbstractGetByPageResponseDto<BeneficiaryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BeneficiaryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_BENEFICIAIRE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un bénéficiaire")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BeneficiaryDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_BENEFICIAIRE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un bénéficiaire")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BeneficiaryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_BENEFICIAIRE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un bénéficiaire")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BeneficiaryUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {ByIdentifierRequestDto.FIELD_IDENTIFIER,
      AbstractCodableNamableUpdateRequestJsonDto.FIELD_CODE,
      AbstractCodableNamableUpdateRequestJsonDto.FIELD_NAME, AbstractRequestDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION})
  class BeneficiaryUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SaveRequestDto {
    @JsonbProperty(JSON_BANK_ACCOUNT_DETAILS)
    private String bankAccountDetails;


    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUPPORTING_DOCUMENT)
    private String supportingDocument;

    @JsonbProperty(JSON_PERSON_TYPE)
    private PersonType personType;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_BENEFICIAIRE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link BeneficiaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un bénéficiaire")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

