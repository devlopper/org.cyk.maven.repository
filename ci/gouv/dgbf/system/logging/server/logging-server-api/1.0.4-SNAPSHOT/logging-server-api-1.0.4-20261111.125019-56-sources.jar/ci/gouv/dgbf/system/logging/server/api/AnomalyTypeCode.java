package ci.gouv.dgbf.system.logging.server.api;

/**
 * Codes stables des types d'anomalie inter-modules.
 */
public interface AnomalyTypeCode {

  /**
   * Écart sur les données civiles.
   */
  String ECART_DONNEES_CIVILES = "ECART_DONNEES_CIVILES";

  /**
   * Matricule inconnu dans le référentiel RH.
   */
  String MATRICULE_INCONNU = "MATRICULE_INCONNU";

  /**
   * Adresse email déjà liée à une identité active.
   */
  String EMAIL_DEJA_ENREGISTRE = "EMAIL_DEJA_ENREGISTRE";
}

