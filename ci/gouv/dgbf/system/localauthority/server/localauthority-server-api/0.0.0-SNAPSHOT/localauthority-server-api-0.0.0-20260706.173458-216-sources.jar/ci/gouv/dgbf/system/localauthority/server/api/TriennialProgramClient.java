package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramReturnRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramStatusUpdateResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TriennialProgramService}.
 *
 * @author Christian
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TriennialProgramClient extends AbstractClient<TriennialProgramService>
    implements GetByIdentifier<TriennialProgramDto>, GetMany<TriennialProgramGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetChart<GetChartResponseDto> {

  @Override
  public TriennialProgramClient service(TriennialProgramService service) {
    return (TriennialProgramClient) super.service(service);
  }

  /**
   * {@link TriennialProgramService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(TriennialProgramCreateRequestDto request) {
    return new CreateExecutor(TriennialProgramService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TriennialProgramService#transmit}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramStatusUpdateResponseDto transmit(ByIdentifierRequestDto request) {
    return new TriennialProgramStatusUpdateExecutor(TriennialProgramService.TRANSMIT_IDENTIFIER)
        .execute(() -> service().transmit(request));
  }

  /**
   * {@link TriennialProgramService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramStatusUpdateResponseDto accept(ByIdentifierRequestDto request) {
    return new TriennialProgramStatusUpdateExecutor(TriennialProgramService.ACCEPT_IDENTIFIER)
        .execute(() -> service().accept(request));
  }

  /**
   * {@link TriennialProgramService#approve}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramStatusUpdateResponseDto approve(
      TriennialProgramService.TriennialProgramApprovalRequestDto request) {
    return new TriennialProgramStatusUpdateExecutor(TriennialProgramService.APPROVE_IDENTIFIER)
        .execute(() -> service().approve(request));
  }

  /**
   * {@link TriennialProgramService#returnBack}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramStatusUpdateResponseDto returnBack(
      TriennialProgramReturnRequestDto request) {
    return new TriennialProgramStatusUpdateExecutor(TriennialProgramService.RETURN_IDENTIFIER)
        .execute(() -> service().returnBack(request));
  }

  /**
   * {@link TriennialProgramService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TriennialProgramGetManyResponseDto>(
        TriennialProgramGetManyResponseDto.class, TriennialProgramService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link TriennialProgramService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TriennialProgramGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TriennialProgramService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TriennialProgramDto>(TriennialProgramDto.class,
        TriennialProgramService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link TriennialProgramService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TriennialProgramDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TriennialProgramService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public TriennialProgramDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TriennialProgramDto>(TriennialProgramDto.class,
        TriennialProgramService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TriennialProgramService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TriennialProgramDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TriennialProgramService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(TriennialProgramUpdateRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TriennialProgramService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link TriennialProgramService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link TriennialProgramService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        TriennialProgramService.GET_CHART_IDENTIFIER).execute(() -> service().getChart(request));
  }

  /**
   * {@link TriennialProgramService#getChart}.
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditWho, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getChart(request);
  }

  /**
   * {@link TriennialProgramService#initialize}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto initialize(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramService.INITIALIZATION_IDENTIFIER)
        .execute(() -> service().initialize(request));
  }

  /**
   * Cette classe représente un exécuteur de mise à jour du statut .
   *
   * @author Christian
   *
   */
  public class TriennialProgramStatusUpdateExecutor
      extends Executor<TriennialProgramStatusUpdateResponseDto> {

    /**
     * Cette méthode permet d'instancier.
     *
     * @param identifier identifiant
     */
    public TriennialProgramStatusUpdateExecutor(String identifier) {
      super(TriennialProgramStatusUpdateResponseDto.class, identifier);
    }
  }
}
