package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette classe représente les codes de {@link PayslipStatus}.
 *
 * @author Christian
 *
 */
public class PayslipStatusCode {

  private PayslipStatusCode() {
    
  }
  
  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Initialisée.
   */
  public static final String INITIALIZED = "INITIALISE";
  
  /**
   * Transmis pour Controle.
   */
  public static final String TRANSMITTED_FOR_CONTROL = "TRANSMIS_POUR_CONTROLE";
  
  /**
   * Controlée.
   */
  public static final String CONTROLLED = "CONTROLE";
  
  /**
   * Acceptée.
   */
  public static final String ACCEPTED = "ACCEPTE";
  
  /**
   * Validée.
   */
  public static final String VALIDATED = "VALIDE";
  
  /**
   * Recalculée.
   */
  public static final String RECALCULATED = "RECALCULE";
  
  /**
   * Transmis pour arbitrage.
   */
  public static final String TRANSMITTED_FOR_ARBITRATION = "TRANSMIS_POUR_ARBITRAGE";
  
  /**
   * Arbitrée.
   */
  public static final String ARBITRATED = "ARBITRE";
  
  /**
   * Clôturée.
   */
  public static final String CLOSED = "CLOTURE";
}
