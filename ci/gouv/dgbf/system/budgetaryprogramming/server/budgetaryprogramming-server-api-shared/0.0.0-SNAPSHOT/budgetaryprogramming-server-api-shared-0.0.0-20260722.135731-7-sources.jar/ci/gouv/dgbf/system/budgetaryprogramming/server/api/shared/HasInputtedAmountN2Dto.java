package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasInputtedAmountN2}.
 *
 * @author Christian
 */
public interface HasInputtedAmountN2Dto extends HasInputtedAmountN2 {

  /**
   * Identifiant json du montant saisi à l'horizon N2.
   */
  String JSON_INPUTTED_AMOUNT_N2 = "montantSaisiN2";
}
