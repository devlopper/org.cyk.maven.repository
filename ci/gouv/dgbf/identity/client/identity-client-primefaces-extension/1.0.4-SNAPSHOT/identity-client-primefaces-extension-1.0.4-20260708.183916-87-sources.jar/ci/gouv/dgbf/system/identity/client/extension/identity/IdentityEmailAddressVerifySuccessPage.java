package ci.gouv.dgbf.system.identity.client.extension.identity;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de succès de {@link IdentityEmailAddressVerifyPage}.
 *
 * @author Christian
 *
 */
@Named
@RequestScoped
public class IdentityEmailAddressVerifySuccessPage extends AbstractPage {

  @Getter
  String emailAddress;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Succès de vérification de l'adresse email";

    emailAddress = getRequestParameter(EmailAddressFilter.JSON_KEY);
  }
  
  public static final String OUTCOME = "identityEmailAddressVerifySuccessPage";
}
