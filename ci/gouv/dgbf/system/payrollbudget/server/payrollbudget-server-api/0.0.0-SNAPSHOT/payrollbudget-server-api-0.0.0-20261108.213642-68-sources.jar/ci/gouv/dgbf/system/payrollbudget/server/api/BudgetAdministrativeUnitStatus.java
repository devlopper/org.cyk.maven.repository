package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Statut de Dossier : le cycle de vie d'une unité administrative de budget.
 *
 * <p>Le cycle est <strong>linéaire et sans retour</strong> — {@code Créé} → {@code Transmis} →
 * {@code Réceptionné} → {@code Traité} → {@code Validé} → {@code Consolidé} — et l'énumération le
 * dit elle-même : chaque valeur connaît son unique successeur, et le dernier n'en a pas. Décrire
 * l'enchaînement ici plutôt que dans le service évite qu'une transition illégitime devienne
 * possible par simple oubli d'un contrôle.</p>
 *
 * <p><strong>Le Dossier n'est plus un simple conteneur.</strong> Il l'était : il acheminait les
 * lignes sans les instruire, et toute la décision vivait dans le Statut de Ligne d'Arbitrage.
 * Désormais son statut <em>ouvre les étapes</em> que ses lignes peuvent franchir — une ligne ne
 * se valide pas avant que le traitement du dossier ne soit validé, elle ne se consolide pas avant
 * que le dossier ne le soit. {@link ArbitrationStatusCoupling} porte cette subordination.</p>
 *
 * <p>Qui avance le dossier : <strong>le chef d'équipe</strong>, et lui seul. Les agents
 * instruisent les lignes ; le chef constate qu'une étape est achevée et ouvre la suivante. C'est
 * ce qui donne au dossier ses trois nouvelles bornes — {@link #PROCESSED}, {@link #VALIDATED}, et
 * {@link #CONSOLIDATED} qui clôt tout.</p>
 *
 * <p>⚠️ Le modèle ne prévoit <strong>aucun chemin d'exception</strong> : un dossier transmis par
 * erreur ne peut être ni rappelé par l'EPN, ni refusé par la DCB. C'est l'observation O1 du
 * document source, non tranchée à ce jour. Le jour où elle le sera, c'est ici que l'ajout se
 * fera.</p>
 *
 * <p>Source : diagrammes d'états du 27/08/2026, chapitre 3 et annexe 6.1.</p>
 *
 * @author Christian
 *
 */
@Getter
public enum BudgetAdministrativeUnitStatus {

  /**
   * Créé — le dossier est ouvert, son contenu peut encore être complété.
   */
  CREATED(BudgetAdministrativeUnitStatusCode.CREATED, "Créé"),

  /**
   * Transmis — le dossier a quitté l'EPN, son contenu est figé (RG_PRB_ARB_05).
   *
   * <p><strong>Transition passive.</strong> Aucun service de ce module ne porte le passage de
   * {@link #CREATED} à {@link #TRANSMITTED} : il se fait du côté de l'EPN, à l'expression des
   * besoins, et le dossier arrive ici déjà transmis. C'est la seule transition du cycle qui
   * n'ait pas d'action correspondante, et ce n'est pas un oubli.</p>
   */
  TRANSMITTED(BudgetAdministrativeUnitStatusCode.TRANSMITTED, "Transmis"),

  /**
   * Réceptionné — la DCB instruit. L'étape de <strong>traitement</strong> est ouverte.
   *
   * <p>La réception fait suivre le contenu au contenant : les lignes transmises deviennent
   * réceptionnées du même geste. C'est dans cette étape que l'agent vérifie les pièces jointes
   * puis traite la ligne — la vérification d'admissibilité n'est plus une étape séparée du
   * circuit, elle est devenue le préalable que l'agent s'impose avant de décider.</p>
   */
  RECEIVED(BudgetAdministrativeUnitStatusCode.RECEIVED, "Réceptionné"),

  /**
   * Traité — le chef d'équipe a validé le traitement. L'étape de <strong>validation</strong>
   * est ouverte.
   *
   * <p>Ce statut ne décide de rien sur les lignes : il <em>constate</em> que leur traitement est
   * achevé, et c'est ce constat qui autorise leur validation une à une. Le chef ne peut le poser
   * qu'une fois chaque ligne traitée — sans quoi il fermerait une étape que des lignes n'ont pas
   * franchie, et celles-ci resteraient en arrière sans que rien ne le signale.</p>
   */
  PROCESSED(BudgetAdministrativeUnitStatusCode.PROCESSED, "Traité"),

  /**
   * Validé — le chef d'équipe a validé le dossier. L'étape de <strong>consolidation</strong>
   * est ouverte.
   *
   * <p>C'est le geste qui envoie le dossier et ses lignes à la consolidation. Même règle que
   * ci-dessus : il suppose chaque ligne validée.</p>
   */
  VALIDATED(BudgetAdministrativeUnitStatusCode.VALIDATED, "Validé"),

  /**
   * Consolidé — l'arbitrage est clos. Terminal, et fermant.
   *
   * <p>Ce statut ne se contente pas d'achèver le cycle du dossier : il <strong>ferme celui de
   * ses lignes</strong>. Plus aucune transition n'est acceptée sur elles, pas même la
   * retransmission d'une ligne différée pour correction — la boucle de reprise
   * (RG_PRB_ARB_19) s'arrête ici. Un dossier consolidé dont le contenu continuerait de bouger
   * ne serait plus la masse salariale qu'on a arrêtée.</p>
   *
   * <p>C'est la <strong>consolidation finale</strong>, posée par le chef d'équipe une fois
   * chaque ligne consolidée : elle constitue la masse salariale de l'EPN.</p>
   */
  CONSOLIDATED(BudgetAdministrativeUnitStatusCode.CONSOLIDATED, "Consolidé")

  ;

  private BudgetAdministrativeUnitStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;

  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Retourne le statut portant le code donné.
   *
   * @param code code recherché
   * @return le statut correspondant
   * @throws IllegalArgumentException si aucun statut ne porte ce code
   */
  public static BudgetAdministrativeUnitStatus getByCode(String code) {
    return Stream.of(BudgetAdministrativeUnitStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code « %s » inconnu".formatted(code)));
  }

  /**
   * Le cycle, écrit plutôt que déduit de l'ordre de déclaration.
   *
   * <p>L'ordre des constantes suffisait, et c'est précisément ce qui posait problème :
   * insérer un statut — l'état « retourné » que l'observation O1 laisse ouvert — aurait
   * déplacé en silence tout ce qui suit, et avec lui le successeur de chaque étape et les
   * comparaisons d'avancement. Écrite, la liste rend l'insertion visible : on la relit, ou
   * rien ne bouge.</p>
   *
   * <p>La contrepartie est qu'un statut ajouté à l'énumération et oublié de cette liste
   * aurait un rang de moins un. Aucune garde ne le rattrape ici — une garde que rien ne peut
   * atteindre ne se teste pas, et du code qu'aucun test ne traverse ne protège personne. C'est
   * {@code rank_isDefinedForEveryStatus} qui tient cette promesse, et qui tombe si on l'oublie.</p>
   */
  private static final List<BudgetAdministrativeUnitStatus> CYCLE =
      List.of(CREATED, TRANSMITTED, RECEIVED, PROCESSED, VALIDATED, CONSOLIDATED);

  /**
   * Retourne le rang de ce statut dans le cycle.
   *
   * <p>Le rang remplace {@code ordinal()} partout où l'on compare un avancement : il dit la
   * place dans le cycle, non la place dans la déclaration.</p>
   *
   * @return le rang, zéro pour le premier état
   */
  public int rank() {
    return CYCLE.indexOf(this);
  }

  /**
   * Retourne l'unique successeur de ce statut.
   *
   * @return le statut suivant, ou vide si celui-ci est terminal
   */
  public Optional<BudgetAdministrativeUnitStatus> getNext() {
    int next = rank() + 1;
    return next < CYCLE.size() ? Optional.of(CYCLE.get(next)) : Optional.empty();
  }

  /**
   * Indique si le cycle de vie s'achève sur ce statut.
   *
   * @return vrai si aucune transition n'en part
   */
  public boolean isTerminal() {
    return getNext().isEmpty();
  }

  /**
   * Indique si la transition vers le statut donné est autorisée.
   *
   * <p>Seul le passage au successeur immédiat l'est. Ni saut d'étape, ni retour en arrière, ni
   * transition vers soi-même.</p>
   *
   * @param target statut visé
   * @return vrai si la transition est permise
   */
  public boolean canTransitionTo(BudgetAdministrativeUnitStatus target) {
    return getNext().filter(next -> next == target).isPresent();
  }
}
