package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.primefaces.component.layout.ListDetailLayoutController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base de page de liste de données de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
public abstract class AbstractDocumentGroupReadDatasPage extends AbstractPage {

  @Inject
  DocumentGroupClient client;

  @Getter
  DocumentGroupDto instance;

  @Getter
  LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  @Getter
  DocumentGroupTabMenuController tabMenuController;

  @Inject
  DocumentationIconManager iconManager;

  @Inject
  @Getter
  ListDetailLayoutController listDetailLayoutController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture " + DocumentGroupDto.NAME;
    instance = client.getByIdentifier(getRequestParameterIdentifier(),
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER,
            HasSourceIdentifierDto.JSON_SOURCE_IDENTIFIER,
            HasRecordIdentifierDto.JSON_RECORD_IDENTIFIER,
            HasOperationIdentifierDto.JSON_OPERATION_IDENTIFIER,
            HasTypeGroupAsStringDto.JSON_TYPE_GROUP_AS_STRING),
        userIdentifier, null);

    buildLabelValueGroupsInformationCard();

    tabMenuController.setInstance(instance);
    tabMenuController.initialize();

    listDetailLayoutController.instantiateDetailsAsLazyDataModel(DocumentGroupDto.class, client,
        userIdentifier);

    listDetailLayoutController.initialize();
  }

  void buildLabelValueGroupsInformationCard() {
    DocumentGroupLabelValueGroupsInformationCardBuilder builder =
        new DocumentGroupLabelValueGroupsInformationCardBuilder(iconManager);
    builder.process(instance.getProcessIdentifier());
    builder.source(instance.getSourceIdentifier());
    builder.record(instance.getRecordIdentifier());
    builder.operation(instance.getOperationIdentifier());
    builder.typeGroup(instance.getTypeGroupAsString());
    labelValueGroupsInformationCard = builder.build();
  }

  void configureDataTable(DataTable dataTable) {
    dataTable.setHeaderRendered(false);
    dataTable.getFilterButton().setRendered(false);
    dataTable.getExportButton().setRendered(false);
  }
}
