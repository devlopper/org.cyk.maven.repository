package ci.gouv.dgbf.extension.primefaces.component.output;

import ci.gouv.dgbf.extension.primefaces.Text;
import ci.gouv.dgbf.extension.primefaces.Text.RenderComponentType;

/**
 * Cette classe représente la représentation visuelle unique d'une information sous forme de
 * pastille ({@code p:tag}) : libellé, icône et sévérité sont définis à un seul endroit, puis
 * réutilisés partout où l'information apparaît (colonne de liste, carte de synthèse, onglet...).
 * <p>
 * Le rendu passe par le fragment {@code /extension/component/text/default.xhtml}. Une valeur nulle
 * donne un texte nul, que ce fragment n'affiche pas.
 * </p>
 *
 * @param <T> type de la valeur représentée
 * @author Christian
 */
public abstract class AbstractTagRepresentation<T> {

  /**
   * Cette méthode permet d'obtenir la représentation d'une valeur.
   *
   * @param value valeur
   * @return {@link Text} à rendre en pastille, ou null si la valeur est nulle
   */
  public Text get(T value) {
    if (value == null) {
      return null;
    }
    return Text.newBuilder().value(getLabel(value)).icon(getIcon(value))
        .severity(getSeverity(value)).renderComponentType(RenderComponentType.TAG).build();
  }

  /**
   * Cette méthode permet d'obtenir le libellé d'une valeur non nulle.
   *
   * @param value valeur
   * @return libellé, par défaut {@link String#valueOf(Object)}
   */
  protected String getLabel(T value) {
    return String.valueOf(value);
  }

  /**
   * Cette méthode permet d'obtenir l'icône d'une valeur non nulle.
   *
   * @param value valeur
   * @return classes de l'icône (ex. {@code pi pi-star})
   */
  protected abstract String getIcon(T value);

  /**
   * Cette méthode permet d'obtenir la sévérité d'une valeur non nulle.
   *
   * @param value valeur
   * @return sévérité PrimeFaces (success, info, warning, danger, secondary...), par défaut null
   */
  protected String getSeverity(T value) {
    return null;
  }
}
