package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Arnaud
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {


  /**
   * La prise en charge du ticket.
   */
  CLAIM_TICKET("PRENDRE_EN_CHARGE_TICKET"),

  /**
   * La resolution du ticket.
   */
  RESOLVE_TICKET("RESOUDRE_TICKET"),

  /**
   * L'escalade du ticket.
   */
  ESCALATE_TICKET("ESCALADER_TICKET"),

  /**
   * La redirection du ticket.
   */
  REDIRECT_TICKET("REDIRIGER_TICKET");

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;

}
