package ci.gouv.dgbf.system.sharing.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des unités administratives partagées de l'utilisateur
 * connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedLocalAuthorityListPage
    extends AbstractConnectedUserSharedAdministrativeUnitListPage {

  
  @Override
  protected String resourceTypeName() {
    return "collectivités partagées";
  }

  @Override
  protected void prepareFilterController() {
    super.prepareFilterController();
    controller.getFilterController().getFilter().setIsLocalAuthority(true);
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "connectedUserSharedLocalAuthorityListPage";

  static final String PATH = "/private/resource/connecteduser/localauthorities.xhtml";
}
