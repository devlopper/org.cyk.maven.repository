package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de lecture de
 * {@link PayrollElementClaimImportBatchLineDto}. Lecture seule : les lignes naissent du traitement
 * d'un fichier. Le récapitulatif d'un Lot compte ses lignes.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimImportBatchLineService.PATH)
@Tag(name = "Consultation des lignes de lots d'import")
public interface PayrollElementClaimImportBatchLineService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "lignes-lot-import";

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_LIGNE_LOT_IMPORT";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre de lignes de Lots d'Import.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_LIGNE_LOT_IMPORT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Identifiant du service de récapitulatif d'un Lot.
   */
  String SUMMARY_IDENTIFIER = "RECAPITULATIF_LIGNES_LOT_IMPORT";

  /**
   * Chemin du service de récapitulatif d'un Lot.
   */
  String SUMMARY_PATH = "recapitulatif";

  /**
   * Cette méthode donne le récapitulatif statistique des lignes d'un Lot : leur nombre par
   * version, les réclamations générées, les lignes sans réclamation, les dérogations, les
   * anomalies et la répartition des lignes finales par pièce.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  @Path(SUMMARY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SUMMARY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollElementClaimImportBatchLineSummaryResponseDto.class))})
  Response summary(GetByIdentifierRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollElementClaimImportBatchLineGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollElementClaimImportBatchLineDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollElementClaimImportBatchLineDto> datas;
  }

  /**
   * Cette classe représente la réponse du récapitulatif des lignes d'un Lot.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimImportBatchLineSummaryResponseDto extends AbstractResponseDto {

    /**
     * Nombre de lignes du fichier d'origine.
     */
    @JsonbProperty(JSON_ORIGIN_COUNT)
    private Long originCount;

    /**
     * Nombre de lignes de la version finale.
     */
    @JsonbProperty(JSON_FINAL_COUNT)
    private Long finalCount;

    /**
     * Nombre de lignes finales qui ont produit une réclamation.
     */
    @JsonbProperty(JSON_CLAIM_COUNT)
    private Long claimCount;

    /**
     * Nombre de lignes finales qui n'ont produit aucune réclamation.
     */
    @JsonbProperty(JSON_WITHOUT_CLAIM_COUNT)
    private Long withoutClaimCount;

    /**
     * Nombre de lignes finales dont la réclamation a été forcée par une dérogation.
     */
    @JsonbProperty(JSON_FORCED_COUNT)
    private Long forcedCount;

    /**
     * Nombre d'anomalies consignées pour le Lot.
     */
    @JsonbProperty(JSON_ANOMALY_COUNT)
    private Long anomalyCount;

    /**
     * Nombre de lignes finales de chaque code pièce.
     */
    @JsonbProperty(JSON_PIECE_COUNTS)
    private Map<String, Long> pieceCounts;

    /**
     * Identifiant json {@link #originCount}.
     */
    public static final String JSON_ORIGIN_COUNT = "nombreOrigine";

    /**
     * Identifiant json {@link #finalCount}.
     */
    public static final String JSON_FINAL_COUNT = "nombreFinale";

    /**
     * Identifiant json {@link #claimCount}.
     */
    public static final String JSON_CLAIM_COUNT = "nombreReclamations";

    /**
     * Identifiant json {@link #withoutClaimCount}.
     */
    public static final String JSON_WITHOUT_CLAIM_COUNT = "nombreSansReclamation";

    /**
     * Identifiant json {@link #forcedCount}.
     */
    public static final String JSON_FORCED_COUNT = "nombreForcees";

    /**
     * Identifiant json {@link #anomalyCount}.
     */
    public static final String JSON_ANOMALY_COUNT = "nombreAnomalies";

    /**
     * Identifiant json {@link #pieceCounts}.
     */
    public static final String JSON_PIECE_COUNTS = "nombresParPiece";
  }
}
