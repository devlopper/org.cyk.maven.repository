package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DomainLevelDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-04T08:01:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DomainLevelRequestMapperImpl implements DomainLevelRequestMapper {

    @Override
    public DomainLevelService.DomainLevelCreateRequestDto mapCreate(DomainLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DomainLevelService.DomainLevelCreateRequestDto domainLevelCreateRequestDto = new DomainLevelService.DomainLevelCreateRequestDto();

        domainLevelCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        domainLevelCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        domainLevelCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        domainLevelCreateRequestDto.setLevelIdentifier( arg0.getLevelIdentifier() );
        domainLevelCreateRequestDto.setUsersGroupIdentifier( arg0.getUsersGroupIdentifier() );

        return domainLevelCreateRequestDto;
    }

    @Override
    public DomainLevelService.DomainLevelUpdateRequestDto mapUpdate(DomainLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DomainLevelService.DomainLevelUpdateRequestDto domainLevelUpdateRequestDto = new DomainLevelService.DomainLevelUpdateRequestDto();

        domainLevelUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        domainLevelUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        domainLevelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        domainLevelUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        domainLevelUpdateRequestDto.setLevelIdentifier( arg0.getLevelIdentifier() );
        domainLevelUpdateRequestDto.setUsersGroupIdentifier( arg0.getUsersGroupIdentifier() );

        return domainLevelUpdateRequestDto;
    }
}
