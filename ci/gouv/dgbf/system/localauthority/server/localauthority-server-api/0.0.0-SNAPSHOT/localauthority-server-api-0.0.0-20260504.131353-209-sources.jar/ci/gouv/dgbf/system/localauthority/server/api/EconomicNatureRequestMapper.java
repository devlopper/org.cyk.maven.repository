package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.EconomicNatureService.EconomicNatureCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.EconomicNatureService.EconomicNatureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link EconomicNatureDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link EconomicNatureDto}.

    @author Christian
               """)
public interface EconomicNatureRequestMapper extends RequestMapper<EconomicNatureDto,
    EconomicNatureCreateRequestDto, EconomicNatureUpdateRequestDto> {

}
