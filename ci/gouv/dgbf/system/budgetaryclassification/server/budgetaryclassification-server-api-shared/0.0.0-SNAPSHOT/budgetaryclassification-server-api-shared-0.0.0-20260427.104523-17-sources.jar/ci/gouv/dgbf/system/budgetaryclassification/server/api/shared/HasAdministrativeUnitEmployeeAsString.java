package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'employé
 * d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'employé de
   * l'unité administrative.
   *
   * @return représentation en chaine de caractères de l'employé de l'unité administrative
   */
  String getAdministrativeUnitEmployeeAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'employé de
   * l'unité administrative.
   *
   * @param asString représentation en chaine de caractères de l'employé de l'unité administrative
   */
  void setAdministrativeUnitEmployeeAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'employé de l'unité
   * administrative.
   */
  String FIELD_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING = "administrativeUnitEmployeeAsString";
}
