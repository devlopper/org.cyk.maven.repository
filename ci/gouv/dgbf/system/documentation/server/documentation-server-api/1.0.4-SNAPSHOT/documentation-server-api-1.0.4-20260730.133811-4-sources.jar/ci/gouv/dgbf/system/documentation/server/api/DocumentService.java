package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DocumentDto}.
 *
 * @author Christian
 */
@Path(value = DocumentService.PATH)
@Tag(name = "Gestion des Documents")
public interface DocumentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "documents";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface DocumentSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant du type de document.
     *
     * @return identifiant du type de document
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du type de document.
     *
     * @param typeIdentifier identifiant du type de document
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant du groupe de document.
     *
     * @return identifiant du groupe de document
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du groupe de document.
     *
     * @param groupIdentifier identifiant du groupe de document
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant du fichier.
     *
     * @return identifiant du fichier
     */
    String getFileIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du fichier.
     *
     * @param fileIdentifier identifiant du fichier
     */
    void setFileIdentifier(String fileIdentifier);

    /**
     * {@link DocumentDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = DocumentDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link DocumentDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = DocumentDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link DocumentDto#JSON_FILE_IDENTIFIER}.
     */
    String JSON_FILE_IDENTIFIER = DocumentDto.JSON_FILE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link DocumentDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_DOCUMENT";

  /**
   * Chemin du service de création unitaire de {@link DocumentDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DocumentCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link DocumentDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DocumentSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link DocumentDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DOCUMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link DocumentDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link DocumentDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class DocumentGetManyResponseDto
      extends AbstractGetByPageResponseDto<DocumentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DocumentDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link DocumentDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_DOCUMENT";

  /**
   * Chemin du service d'obtention unitaire de {@link DocumentDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link DocumentDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DOCUMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link DocumentDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link DocumentDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DOCUMENT";

  /**
   * Chemin du service de mise à jour unitaire de {@link DocumentDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  Response update(DocumentUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link DocumentDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DocumentSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link DocumentDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DOCUMENT";

  /**
   * Chemin du service de suppression unitaire de {@link DocumentDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link DocumentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  Response delete(DeleteOneRequestDto request);
}
