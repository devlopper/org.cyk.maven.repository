package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Statut de Ligne d'Arbitrage : quinze états et les seules transitions permises entre eux.
 *
 * <p>La matrice de l'annexe 6.3 du document du 27/08/2026 est portée ici, et non dans le service
 * qui l'applique. Un modèle d'états dont les chemins autorisés sont décrits ailleurs finit
 * toujours par diverger de son implémentation ; les mettre au même endroit rend la divergence
 * impossible. La garde métier n'a plus qu'à interroger {@link #canTransitionTo}.</p>
 *
 * <p>Cinq traits distinguent ce cycle de celui du Dossier :</p>
 * <ul>
 *   <li><strong>deux origines exclusives</strong> — création courante ou initialisation
 *       (RG_PRB_ARB_15) ;</li>
 *   <li><strong>un visa non bloquant</strong> — visé ou non visé mènent également à la
 *       transmission, le visa qualifie sans arrêter (RG_PRB_ARB_16) ;</li>
 *   <li><strong>une boucle de report</strong> — {@link #DEFERRED} renvoie la ligne en
 *       arrière, vers l'EPN (RG_PRB_ARB_19) ;</li>
 *   <li><strong>deux issues terminales seulement</strong> — le rejet de traitement et la
 *       consolidation. « Non consolidé » n'en est pas une : une ligne écartée de la masse
 *       salariale, faute d'enveloppe le plus souvent, peut y être ramenée plus tard. Le modèle
 *       d'états du 27/08/2026 laissait la question ouverte (point O7) ; elle est tranchée.</li>
 *   <li><strong>une étape qui n'appartient pas à la ligne</strong> — le passage à la
 *       validation, puis à la consolidation, est ouvert par le chef d'équipe sur le
 *       <em>dossier</em>. La ligne ne se le donne pas à elle-même.</li>
 * </ul>
 *
 * <p>Deux boucles de retour, donc, et elles ne disent pas la même chose. {@link #DEFERRED}
 * renvoie la ligne à l'EPN pour qu'il la corrige ; {@link #NOT_CONSOLIDATED} la garde telle
 * quelle, hors du cumul, en attendant que l'exercice puisse la porter. La première met en cause
 * la demande, la seconde les moyens.</p>
 *
 * <p>L'aiguillage qui suit la réception dépend de la <strong>nature</strong> de la ligne, et pas
 * seulement de son état : une ligne d'initialisation se consolide directement (RG_PRB_ARB_17),
 * toute autre se traite ou se diffère (RG_PRB_ARB_18). C'est un ou-exclusif, et
 * {@link #canTransitionTo(ArbitrationMovementStatus, String)} le porte.</p>
 *
 * <p><strong>Ce que la révision du 05/10/2026 a changé.</strong> Trois choses, et la matrice
 * ci-dessous les porte :</p>
 * <ul>
 *   <li><strong>l'admission n'est plus une étape</strong> — la vérification des pièces jointes
 *       est devenue le préalable que s'impose l'agent qui traite, non le geste séparé d'un
 *       chargé de contrôle. {@link #RECEIVED} mène donc droit au traitement. Plus personne ne
 *       <em>admet</em> une ligne reçue. {@link #ADMITTED} n'a pas disparu pour autant : c'est
 *       désormais le statut de naissance de l'ajout DCB, que {@link #getInitialStatuses()}
 *       déclare. {@link #SENT}, lui, n'est plus produit nulle part, mais reste déclaré : la
 *       base en porte, et un état qu'on retire d'une énumération est un état que la lecture
 *       fait échouer ;</li>
 *   <li><strong>la validation s'ajoute</strong> — {@link #VALIDATED} s'intercale entre le
 *       traitement et la consolidation ;</li>
 *   <li><strong>les étapes sont subordonnées au dossier</strong> — une ligne ne franchit une
 *       étape que si son dossier l'a ouverte. La matrice dit ce qui est concevable,
 *       {@link ArbitrationStatusCoupling} dit ce qui est permis <em>ici et maintenant</em>.</li>
 * </ul>
 *
 * <p>Cette condition vit ici, avec la matrice, et non dans le service qui l'applique : l'écran en
 * a besoin autant que la garde, pour n'offrir que les actions praticables. La loger d'un seul
 * côté aurait conduit à l'écrire deux fois.</p>
 *
 * @author Christian
 *
 */
@Getter
public enum ArbitrationMovementStatus {

  /**
   * Créé — ligne de gestion courante en cours de saisie. Origine n°1.
   */
  CREATED(ArbitrationMovementStatusCode.CREATED, "Créé"),

  /**
   * Initialisé — ligne de reprise des soldes. Origine n°2.
   */
  INITIALIZED(ArbitrationMovementStatusCode.INITIALIZED, "Initialisé"),

  /**
   * Visé — le contrôleur a visé la ligne.
   */
  ENDORSED(ArbitrationMovementStatusCode.ENDORSED, "Visé"),

  /**
   * Non visé — sans visa, requis ou non délivré.
   */
  NOT_ENDORSED(ArbitrationMovementStatusCode.NOT_ENDORSED, "Non visé"),

  /**
   * Transmis — pivot du cycle, atteint depuis le visa comme depuis un report.
   */
  TRANSMITTED(ArbitrationMovementStatusCode.TRANSMITTED, "Transmis"),

  /**
   * Réceptionné — pris en charge ; déclenche l'aiguillage.
   */
  RECEIVED(ArbitrationMovementStatusCode.RECEIVED, "Réceptionné"),

  /**
   * Admis — retenu pour traitement.
   */
  ADMITTED(ArbitrationMovementStatusCode.ADMITTED, "Admis"),

  /**
   * Différé — traitement reporté, en attente de la levée d'un blocage.
   *
   * <p>Deux sorties, et elles ne se confondent pas : l'EPN qui retransmet ramène la ligne
   * à {@link #TRANSMITTED}, tandis que la DCB qui constate elle-même l'arrivée de ce qui
   * manquait la porte à {@link #DEFERRED_SATISFIED}.</p>
   *
   * <p>Ce n'est pas le seul retour en arrière du cycle : le chef d'équipe renvoie au
   * traitement depuis {@link #PROCESSING_ACCEPTED}, et {@link #NOT_CONSOLIDATED} se
   * rattrape en {@link #CONSOLIDATED} tant que le dossier n'est pas clos.</p>
   */
  DEFERRED(ArbitrationMovementStatusCode.DEFERRED, "Différé"),

  /**
   * Différé satisfait — blocage levé, en attente de traitement.
   */
  DEFERRED_SATISFIED(ArbitrationMovementStatusCode.DEFERRED_SATISFIED, "Différé satisfait"),

  /**
   * Envoyé — en cours de traitement par le service exécutant.
   */
  SENT(ArbitrationMovementStatusCode.SENT, "Envoyé"),

  /**
   * Traitement accepté — en attente de validation.
   */
  PROCESSING_ACCEPTED(ArbitrationMovementStatusCode.PROCESSING_ACCEPTED, "Traitement accepté"),

  /**
   * Traitement rejeté — terminal et définitif.
   */
  PROCESSING_REJECTED(ArbitrationMovementStatusCode.PROCESSING_REJECTED, "Traitement rejeté"),

  /**
   * Validé — la ligne a franchi l'étape de validation.
   *
   * <p>Étape ajoutée le 05/10/2026, et elle n'est pas un doublon du traitement. Le traitement
   * dit ce que la DCB retient d'une demande ; la validation dit que ce qui a été retenu est
   * tenu pour bon. Deux gestes, deux acteurs, deux dates — et c'est bien ce que le métier
   * décrit : les lignes sont traitées, le chef clôt le traitement, puis les lignes sont
   * validées une à une avant que le chef n'envoie le dossier en consolidation.</p>
   *
   * <p>Elle n'est atteignable que dans un dossier au statut {@code Traité} :
   * {@link ArbitrationStatusCoupling} le garantit.</p>
   */
  VALIDATED(ArbitrationMovementStatusCode.VALIDATED, "Validé"),

  /**
   * Consolidé — intégré aux données consolidées. Terminal.
   */
  CONSOLIDATED(ArbitrationMovementStatusCode.CONSOLIDATED, "Consolidé"),

  /**
   * Non consolidé — arbitré favorablement, mais écarté de la masse salariale de l'exercice.
   *
   * <p>Non terminal : la matrice le ramène à {@link #CONSOLIDATED}, car ce qui est écarté
   * n'est pas rejeté.</p>
   *
   * <p><strong>Mais la clôture du dossier le fige.</strong> Une ligne écartée ne retient pas la
   * consolidation du dossier, et un dossier consolidé ne laisse plus rien bouger : passée cette
   * borne, la reprise n'est plus possible. La fenêtre est donc réelle mais bornée, et l'écran ne
   * doit pas se fier au seul statut — c'est
   * {@link #canTransitionTo(ArbitrationMovementStatus, String, BudgetAdministrativeUnitStatus)}
   * qui sait, lui, dans quel dossier la ligne se trouve.</p>
   */
  NOT_CONSOLIDATED(ArbitrationMovementStatusCode.NOT_CONSOLIDATED, "Non consolidé")

  ;

  private ArbitrationMovementStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;

  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Retourne le statut portant le code donné.
   *
   * @param code code recherché
   * @return le statut correspondant
   * @throws IllegalArgumentException si aucun statut ne porte ce code
   */
  public static ArbitrationMovementStatus getByCode(String code) {
    return Stream.of(ArbitrationMovementStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code « %s » inconnu".formatted(code)));
  }

  /**
   * La matrice de l'annexe 6.3, transcrite telle quelle.
   *
   * <p><strong>Écart assumé à R44a</strong>, qui prévoit un ensemble {@code previous} par
   * constante, rempli dans un bloc {@code static}. Une table des <em>suivants</em> se lit
   * dans le sens du document source, où chaque état liste ses suites ; l'inverser
   * obligerait à relire la matrice à l'envers pour la vérifier. Les garde-fous attendus
   * sont tenus autrement : {@code allowedTargets_matchTheSpecificationMatrix} fige la
   * table ligne par ligne.</p>
   *
   * <p>Une table plutôt qu'un {@code switch} : le compilateur ajoute à tout {@code switch}
   * d'énumération une branche par défaut inatteignable, que nul test ne peut couvrir. Une table
   * n'a pas de branche, et se lit comme la matrice du document.</p>
   *
   * <p>Les états absents de cette table sont terminaux : ne rien déclarer <em>est</em> la
   * déclaration qu'aucune transition n'en part.</p>
   */
  private static final Map<ArbitrationMovementStatus, Set<ArbitrationMovementStatus>> TRANSITIONS =
      Map.ofEntries(
          Map.entry(CREATED, Set.of(ENDORSED, NOT_ENDORSED)),
          Map.entry(INITIALIZED, Set.of(ENDORSED, NOT_ENDORSED)),
          Map.entry(ENDORSED, Set.of(TRANSMITTED)),
          Map.entry(NOT_ENDORSED, Set.of(TRANSMITTED)),
          Map.entry(TRANSMITTED, Set.of(RECEIVED)),
          // Consolidation directe reservee aux lignes d'Initialisation (RG_PRB_ARB_17). Les
          // autres vont droit au traitement : l'admission n'est plus une etape du circuit.
          Map.entry(RECEIVED,
              Set.of(CONSOLIDATED, PROCESSING_ACCEPTED, PROCESSING_REJECTED, DEFERRED)),
          Map.entry(DEFERRED, Set.of(TRANSMITTED, DEFERRED_SATISFIED)),
          Map.entry(DEFERRED_SATISFIED, Set.of(PROCESSING_ACCEPTED, PROCESSING_REJECTED)),
          // ADMIS reste produit, mais par l'ajout DCB et non plus par une etape d'admission.
          // ENVOYE, lui, n'est plus produit : la base en porte, et ces lignes-la doivent
          // pouvoir finir leur course. Les deux menent donc au traitement.
          Map.entry(ADMITTED, Set.of(PROCESSING_ACCEPTED, PROCESSING_REJECTED)),
          Map.entry(SENT, Set.of(PROCESSING_ACCEPTED, PROCESSING_REJECTED)),
          // LE RETOUR AU TRAITEMENT, ouvert au chef d'equipe le 12/10/2026. Il vient
          // confirmer ou rejeter le travail de son equipe : confirmer menait a VALIDE, rejeter
          // ne menait nulle part, et son desaccord n'avait aucune forme. La ligne revient donc
          // a RECEPTIONNE, ou l'agent la reprend.
          //
          // SEULE L'ACCEPTATION REVIENT. Le rejet prononce au traitement est definitif, et cette
          // regle n'est pas revue ici : TRAITEMENT_REJETE reste terminal, ne retient aucune
          // fermeture, et la consolidation ne l'attend pas. La rendre reversible toucherait aux
          // trois a la fois.
          Map.entry(PROCESSING_ACCEPTED, Set.of(VALIDATED, RECEIVED)),
          Map.entry(VALIDATED, Set.of(CONSOLIDATED, NOT_CONSOLIDATED)),
          // La mise a l'ecart n'est pas un rejet : ce qui est ecarte peut revenir.
          Map.entry(NOT_CONSOLIDATED, Set.of(CONSOLIDATED)));

  /**
   * Retourne les états atteignables depuis celui-ci — la matrice de l'annexe 6.3.
   *
   * <p>Toute transition absente de cet ensemble doit être refusée par le système.</p>
   *
   * @return les états cibles autorisés, vide si l'état est terminal
   */
  public Set<ArbitrationMovementStatus> getAllowedTargets() {
    return TRANSITIONS.getOrDefault(this, Set.of());
  }

  /**
   * Indique si la transition vers le statut donné figure dans la matrice.
   *
   * @param target statut visé
   * @return vrai si la transition est permise
   */
  public boolean canTransitionTo(ArbitrationMovementStatus target) {
    return getAllowedTargets().contains(target);
  }

  /**
   * Indique si la transition est permise pour une ligne de la nature donnée.
   *
   * <p>Au-delà de la matrice, l'aiguillage qui suit la réception est un ou-exclusif :
   * l'initialisation va droit à la consolidation, tout le reste va au traitement ou au
   * report. Une ligne d'initialisation ne peut donc pas être traitée, ni une prime
   * consolidée sans traitement.</p>
   *
   * @param target statut visé
   * @param natureCode nature du mouvement
   * @return vrai si la transition est permise
   */
  public boolean canTransitionTo(ArbitrationMovementStatus target, String natureCode) {
    if (!canTransitionTo(target)) {
      return false;
    }
    if (this != RECEIVED) {
      return true;
    }
    boolean initialising = ArbitrationMovementDto.NATURE_INITIALIZATION.equals(natureCode);
    return target == CONSOLIDATED ? initialising : !initialising;
  }

  /**
   * Indique si la transition est permise ici et maintenant : matrice, nature, et dossier.
   *
   * <p>C'est l'unique point d'entrée que la garde métier a besoin de connaître. Les trois
   * conditions s'y empilent dans l'ordre où elles se démentent le plus vite : la matrice dit ce
   * qui est concevable, la nature dit ce qui convient à cette ligne-là, le statut du dossier dit
   * ce qui est ouvert à cet instant.</p>
   *
   * <p>La troisième est la plus récente et la moins intuitive : une transition peut être
   * parfaitement légitime et pourtant refusée, parce que le chef d'équipe n'a pas encore ouvert
   * l'étape. Le message d'erreur doit le dire, sans quoi l'agent croit à une anomalie.</p>
   *
   * @param target statut visé
   * @param natureCode nature du mouvement
   * @param dossierStatus statut du dossier qui contient la ligne
   * @return vrai si la transition est permise
   */
  public boolean canTransitionTo(ArbitrationMovementStatus target, String natureCode,
      BudgetAdministrativeUnitStatus dossierStatus) {
    return canTransitionTo(target, natureCode)
        && ArbitrationStatusCoupling.isStageOpen(target, dossierStatus, natureCode);
  }

  /**
   * Indique si le cycle de vie s'achève sur ce statut.
   *
   * @return vrai si aucune transition n'en part
   */
  public boolean isTerminal() {
    return getAllowedTargets().isEmpty();
  }

  /**
   * Retourne les origines d'une ligne.
   *
   * <p>Deux viennent de l'EPN et sont celles de RG_PRB_ARB_15 : la saisie courante
   * ({@link #CREATED}) et la reprise des soldes ({@link #INITIALIZED}).</p>
   *
   * <p>La troisième, {@link #ADMITTED}, est l'élément que la DCB ajoute <em>au cours du
   * traitement</em> (CU03-RG02, CU04-RG02, CU05-RG02). Le modèle d'états du 27/08/2026 ne la
   * nommait pas — il décrivait le parcours de ce qui vient de l'EPN, et rien d'autre. Elle est
   * ajoutée ici plutôt que contournée à l'endroit de la création : une origine qu'on
   * n'écrit nulle part est une origine que la garde ne sait pas contrôler.</p>
   *
   * <p>Elle naît admise, et non décidée : la DCB ne l'ajoute qu'en ayant sous les yeux ce qui
   * la justifie, mais elle reste à instruire comme les autres. Lui faire reparcourir le visa, la
   * transmission et la réception rejouerait une histoire qui n'a pas eu lieu ; lui accorder
   * d'emblée une acceptation la ferait entrer dans la masse salariale sans qu'aucune décision
   * ne porte de nom ni de date.</p>
   *
   * @return les statuts par lesquels une ligne entre dans le cycle
   */
  public static Set<ArbitrationMovementStatus> getInitialStatuses() {
    return Set.of(CREATED, INITIALIZED, ADMITTED);
  }

  /**
   * Retourne les états dont aucune transition ne part.
   *
   * <p>La terminalité se lit <strong>sur le statut seul</strong>, hors de tout dossier. Un
   * {@link #NOT_CONSOLIDATED} n'y figure donc pas, même si la clôture de son dossier le fige
   * en pratique. Un écran qui propose des actions ne doit pas s'arrêter là : seul
   * {@link #canTransitionTo(ArbitrationMovementStatus, String, BudgetAdministrativeUnitStatus)}
   * tient compte de l'état du dossier.</p>
   *
   * @return les statuts terminaux
   */
  public static Set<ArbitrationMovementStatus> getTerminalStatuses() {
    return Stream.of(values()).filter(ArbitrationMovementStatus::isTerminal)
        .collect(Collectors.toUnmodifiableSet());
  }
}
