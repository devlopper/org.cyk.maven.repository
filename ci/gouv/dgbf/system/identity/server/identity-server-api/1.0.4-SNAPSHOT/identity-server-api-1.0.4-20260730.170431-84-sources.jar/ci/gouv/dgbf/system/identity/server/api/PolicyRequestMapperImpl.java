package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PolicyDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T17:04:56+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PolicyRequestMapperImpl implements PolicyRequestMapper {

    @Override
    public PolicyService.PolicyCreateRequestDto mapCreate(PolicyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyService.PolicyCreateRequestDto policyCreateRequestDto = new PolicyService.PolicyCreateRequestDto();

        policyCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyCreateRequestDto.setCode( arg0.getCode() );
        policyCreateRequestDto.setName( arg0.getName() );
        policyCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return policyCreateRequestDto;
    }

    @Override
    public PolicyService.PolicyUpdateRequestDto mapUpdate(PolicyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyService.PolicyUpdateRequestDto policyUpdateRequestDto = new PolicyService.PolicyUpdateRequestDto();

        policyUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        policyUpdateRequestDto.setCode( arg0.getCode() );
        policyUpdateRequestDto.setName( arg0.getName() );
        policyUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return policyUpdateRequestDto;
    }
}
