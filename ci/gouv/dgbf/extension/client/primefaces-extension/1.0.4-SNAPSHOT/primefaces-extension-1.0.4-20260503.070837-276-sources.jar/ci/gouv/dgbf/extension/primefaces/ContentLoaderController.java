package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.primefaces.component.OutputPanel;
import jakarta.enterprise.context.Dependent;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de chargeur de contenu.
 */
@Dependent
public class ContentLoaderController {

  @Getter
  @Setter
  ContentLoader loader;
  
  @Getter
  @Setter
  OutputPanel outputPanel;
  
  public ContentLoaderController() {
    outputPanel = new OutputPanel();
  }
  
  /**
   * Cette méthode permet d'obtenir {@link ContentLoader} non null.
   *
   * @return {@link ContentLoader} non null
   */
  public ContentLoader loader() {
    if (loader == null) {
      loader = new ContentLoader();
    }
    return loader;
  }
}
