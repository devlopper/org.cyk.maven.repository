package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UserRoleDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link UserRoleDto}.

    @author BoobaCool
    """)
public interface UserRoleRequestMapper extends RequestMapper<UserRoleDto,
    UserRoleService.UserRoleCreateRequestDto, UserRoleService.UserRoleUpdateRequestDto> {

}
