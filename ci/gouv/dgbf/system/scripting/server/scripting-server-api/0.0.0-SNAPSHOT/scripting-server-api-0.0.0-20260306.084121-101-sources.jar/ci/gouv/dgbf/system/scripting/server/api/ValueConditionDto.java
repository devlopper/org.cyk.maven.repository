package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ComparisonOperator;
import ci.gouv.dgbf.extension.core.segregation.HasComparisonOperatorAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasComparisonOperatorDto;
import ci.gouv.dgbf.extension.core.segregation.HasConditionalValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasConditionalValueIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueMapKeyDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesSeparatorDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une condition de valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueConditionDto extends AbstractIdentifiableAuditableDto
    implements HasValueSelectorIdentifierDto, HasValueSelectorAsStringDto,
    HasValueMapKeyDto<String>, HasConditionalValueIdentifierDto, HasConditionalValueAsStringDto,
    HasComparisonOperatorDto, HasComparisonOperatorAsStringDto, HasStringValueDto,
    HasValuesSeparatorDto, HasValuesMapDto<String, Object> {

  @JsonbProperty(JSON_CONDITIONAL_VALUE_IDENTIFIER)
  private String conditionalValueIdentifier;

  @JsonbProperty(JSON_CONDITIONAL_VALUE_AS_STRING)
  private String conditionalValueAsString;

  @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
  private String valueSelectorIdentifier;

  @JsonbProperty(JSON_VALUE_SELECTOR_AS_STRING)
  private String valueSelectorAsString;

  @JsonbProperty(JSON_VALUE_MAP_KEY)
  private String valueMapKey;

  @JsonbProperty(JSON_VALUES_SEPARATOR)
  private String valuesSeparator;

  @JsonbProperty(JSON_COMPARISON_OPERATOR)
  private ComparisonOperator comparisonOperator;

  @JsonbProperty(JSON_COMPARISON_OPERATOR_AS_STRING)
  private String comparisonOperatorAsString;

  @JsonbProperty(JSON_VALUE)
  private String value;

  private Map<String, Object> valuesMap;

  /**
   * Valeur de l'attribut de filtre du sélecteur de valeur.
   */
  private String valueSelectorFilterAttributeValue;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idConditionValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "conditionValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "condition valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "conditions valeur";
}
