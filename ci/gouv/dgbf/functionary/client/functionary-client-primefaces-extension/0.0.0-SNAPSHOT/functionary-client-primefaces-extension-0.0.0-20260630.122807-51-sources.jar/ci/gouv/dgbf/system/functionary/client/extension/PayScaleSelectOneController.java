package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleClient;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleDto;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService.PayScaleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayScaleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class PayScaleSelectOneController extends AbstractSelectOneIdentifiableController<
    PayScaleDto, PayScaleGetManyResponseDto, PayScaleClient> {

  @Getter
  @Inject
  PayScaleClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PayScaleSelectOneController() {
    super(PayScaleDto.class, SelectItemLabelStrategy.NAME);
  }
}
