package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le pourcentage de progression de la saisie pour
 * l'année N, sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputProgressPercentageNAsStringDto
    extends HasInputProgressPercentageNAsString {

  /**
   * Identifiant json du pourcentage de progression de la saisie pour l'année N, sous forme de
   * chaîne de caractères.
   */
  String JSON_INPUT_PROGRESS_PERCENTAGE_N_AS_STRING =
      "pourcentageProgressionSaisieNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName