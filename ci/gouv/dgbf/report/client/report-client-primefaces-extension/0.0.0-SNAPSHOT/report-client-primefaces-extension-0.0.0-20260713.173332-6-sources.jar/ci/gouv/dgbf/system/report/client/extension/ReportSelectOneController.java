package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.report.server.api.ReportClient;
import ci.gouv.dgbf.system.report.server.api.ReportDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ReportDto}.
 *
 * @author Desysoft
 */
@Dependent
public class ReportSelectOneController
    extends AbstractSelectOneIdentifiableController<ReportDto,
    ReportGetManyResponseDto, ReportClient> {

  @Getter
  @Inject
  ReportClient client;

  public ReportSelectOneController() {
    super(ReportDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}

