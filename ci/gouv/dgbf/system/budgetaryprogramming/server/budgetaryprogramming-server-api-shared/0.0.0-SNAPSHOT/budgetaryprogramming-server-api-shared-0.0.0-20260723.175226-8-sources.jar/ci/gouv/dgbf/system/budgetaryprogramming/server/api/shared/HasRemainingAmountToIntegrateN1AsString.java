package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateN1AsString {

  /**
   * Obtient le montant restant à intégrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant restant à intégrer pour l'année N+1 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToIntegrateN1AsString();

  /**
   * Définit le montant restant à intégrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToIntegrateN1AsString le montant restant à intégrer pour l'année N+1
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToIntegrateN1AsString(String remainingAmountToIntegrateN1AsString);

  /**
   * Identifiant java du montant restant à intégrer pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INTEGRATE_N1_AS_STRING =
      "remainingAmountToIntegrateN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName