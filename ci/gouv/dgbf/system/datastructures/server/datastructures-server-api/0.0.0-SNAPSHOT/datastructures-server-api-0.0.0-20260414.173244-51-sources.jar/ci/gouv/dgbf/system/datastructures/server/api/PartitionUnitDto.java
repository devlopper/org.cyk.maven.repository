package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasPartitionAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPartitionIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une unité de partition.
 *
 * @author Arnaud
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PartitionUnitDto extends AbstractIdentifiableNamableAuditableDto
    implements HasPartitionIdentifierDto, HasPartitionAsStringDto {

  @JsonbProperty(JSON_PARTITION_IDENTIFIER)
  private String partitionIdentifier;

  @JsonbProperty(JSON_PARTITION_AS_STRING)
  private String partitionAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUnitePartition";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "unitePartitionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "unité de partition";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "unités de partition";

}
