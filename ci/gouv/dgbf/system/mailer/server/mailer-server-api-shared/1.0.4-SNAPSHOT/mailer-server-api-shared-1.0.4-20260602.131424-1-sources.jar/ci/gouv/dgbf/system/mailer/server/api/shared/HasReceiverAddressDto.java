package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a une adresse de destinataire.
 *
 * @author Christian
 */
public interface HasReceiverAddressDto extends HasReceiverAddress {

  /**
   * Identifiant json de l'adresse du destinataire.
   */
  String JSON_RECEIVER_ADDRESS = "adresseDestinataire";
}
