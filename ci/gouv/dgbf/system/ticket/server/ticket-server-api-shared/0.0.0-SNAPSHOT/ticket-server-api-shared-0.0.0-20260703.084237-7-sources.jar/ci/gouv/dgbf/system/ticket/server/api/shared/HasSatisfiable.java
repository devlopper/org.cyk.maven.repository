package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être satisfait.
 *
 * @author Christian
 */
public interface HasSatisfiable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être satisfait.
   *
   * @return peut être satisfait
   */
  Boolean getSatisfiable();

  /**
   * Cette méthode permet d'assigner peut être satisfait.
   *
   * @param satisfiable peut être satisfait
   */
  void setSatisfiable(Boolean satisfiable);

  /**
   * Identifiant java de peut être satisfait.
   */
  String FIELD_SATISFIABLE = "satisfiable";
}