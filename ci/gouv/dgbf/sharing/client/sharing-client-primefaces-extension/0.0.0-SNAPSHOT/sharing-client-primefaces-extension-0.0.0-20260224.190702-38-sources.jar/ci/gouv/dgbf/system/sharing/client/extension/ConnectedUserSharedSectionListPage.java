package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des sections partagées de l'utilisateur connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedSectionListPage
    extends AbstractConnectedUserSharedResourceListPage {

  @Override
  String resourceName() {
    return "sections";
  }

  @Override
  ResourceType resourceType() {
    return ResourceType.SECTION;
  }

  @Override
  Location resourceLocation() {
    return Location.BUDGETARY_CLASSIFICATION;
  }

  static final String OUTCOME = "connectedUserSharedSectionListPage";
}
