package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link AdministrativeUnitPunctualMeasureDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et
    {@link AdministrativeUnitPunctualMeasureDto}.

    @author Christian
               """)
public interface AdministrativeUnitPunctualMeasureRequestMapper
    extends RequestMapper<AdministrativeUnitPunctualMeasureDto,
        AdministrativeUnitPunctualMeasureCreateRequestDto,
        AdministrativeUnitPunctualMeasureUpdateRequestDto> {

}
