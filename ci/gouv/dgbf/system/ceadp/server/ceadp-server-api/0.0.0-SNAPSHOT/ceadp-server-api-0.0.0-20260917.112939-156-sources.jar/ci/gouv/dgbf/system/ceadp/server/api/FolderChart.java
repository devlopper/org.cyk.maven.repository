package ci.gouv.dgbf.system.ceadp.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques de {@link FolderDto}.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum FolderChart {

  /**
   * Compte des statuts des {@link ActivityDto}.
   */
  ACTIVITY_STATUS_COUNTS(FolderChartCode.ACTIVITY_STATUS_COUNTS,
      "Nombre %s par %s".formatted(ActivityDto.PLURAL_NAME, FolderDto.NAME)),

  /**
   * Compte des statuts des {@link TaskDto}.
   */
  TASK_STATUS_COUNTS(FolderChartCode.TASK_STATUS_COUNTS,
      "Nombre %s par %s".formatted(TaskDto.PLURAL_NAME, FolderDto.NAME)),

  /**
   * Compte du nombre d'activités en retard.
   */
  ACTIVITY_LATE_COUNT(FolderChartCode.ACTIVITY_LATE_COUNT,
       "Nombre %s en retard par %s".formatted(ActivityDto.PLURAL_NAME, FolderDto.NAME));

  /**
   * Code.
   */
  String code;

  String name;

  /**
   * Cette méthode permet d'obtenir {@link FolderChart} par code.
   *
   * @param code code
   * @return statut
   */
  public static FolderChart getByCode(String code) {
    return Stream.of(FolderChart.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElse(null);
  }
}
