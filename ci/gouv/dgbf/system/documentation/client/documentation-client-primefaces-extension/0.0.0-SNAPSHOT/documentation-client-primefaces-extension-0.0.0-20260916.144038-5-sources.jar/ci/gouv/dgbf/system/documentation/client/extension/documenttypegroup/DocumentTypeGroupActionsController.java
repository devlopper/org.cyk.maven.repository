package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.AbstractIdentifiableActionsController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente un contrôleur des actions de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class DocumentTypeGroupActionsController extends
    AbstractIdentifiableActionsController<DocumentTypeGroupDto, DocumentTypeGroupClient> {

  @Inject
  @Getter
  DocumentTypeGroupClient client;

  @Override
  public void initializeWhenNotNull(DocumentTypeGroupDto identifiable) {
    // TODO: Auto-generated method stub
  }
}
