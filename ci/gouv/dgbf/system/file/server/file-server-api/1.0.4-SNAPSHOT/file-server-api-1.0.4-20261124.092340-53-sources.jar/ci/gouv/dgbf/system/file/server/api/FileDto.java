package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasContentTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasHashDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNumberOfBytesAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasNumberOfBytesDto;
import ci.gouv.dgbf.extension.core.segregation.HasOwnerAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasOwnerIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasPrimitiveBytesArrayDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fichier.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileDto extends AbstractIdentifiableNamableAuditableDto
    implements HasContentTypeDto, HasPrimitiveBytesArrayDto, HasNumberOfBytesDto<Integer>,
    HasNumberOfBytesAsStringDto, HasOwnerIdentifierDto, HasOwnerAsStringDto,
    HasModuleIdentifierDto, HasHashDto,
    HasGroupIdentifierDto, HasStatusDto<FileStatus>, HasStatusAsStringDto, HasConfirmableDto,
    HasPlannedPurgeDateDto<LocalDateTime>, HasPlannedPurgeDateAsStringDto {

  @JsonbProperty(value = JSON_CONTENT_TYPE)
  private String contentType;

  @JsonbProperty(value = JSON_BYTES)
  private byte[] bytes;

  @JsonbProperty(value = JSON_NUMBER_OF_BYTES)
  private Integer numberOfBytes;

  @JsonbProperty(value = JSON_NUMBER_OF_BYTES_AS_STRING)
  private String numberOfBytesAsString;

  @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
  private String ownerIdentifier;

  @JsonbProperty(value = JSON_OWNER_AS_STRING)
  private String ownerAsString;

  /**
   * Identifiant du module propriétaire (transitoire, coexiste avec {@link #ownerIdentifier}, cf.
   * file-conception-spec-kit TCH_FILE_551).
   */
  @JsonbProperty(value = JSON_MODULE_IDENTIFIER)
  private String moduleIdentifier;

  @JsonbProperty(value = JSON_HASH)
  private String hash;

  @JsonbProperty(value = JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(value = JSON_STATUS)
  private FileStatus status;

  @JsonbProperty(value = JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(value = JSON_CONFIRMABLE)
  private Boolean confirmable;

  @JsonbProperty(value = JSON_PLANNED_PURGE_DATE)
  private LocalDateTime plannedPurgeDate;

  @JsonbProperty(value = JSON_PLANNED_PURGE_DATE_AS_STRING)
  private String plannedPurgeDateAsString;

  /**
   * Forme du contenu, déduite : le champ à consulter avant de lire des octets (RG_FILE_FIC_18).
   */
  @JsonbProperty(value = JSON_CONTENT_FORM)
  private ContentForm contentForm;

  @JsonbProperty(value = JSON_CONTENT_FORM_AS_STRING)
  private String contentFormAsString;

  /**
   * Nature du support, déduite des exemplaires présents (RG_FILE_FIC_17).
   */
  @JsonbProperty(value = JSON_MEDIUM_NATURE)
  private MediumNature mediumNature;

  @JsonbProperty(value = JSON_MEDIUM_NATURE_AS_STRING)
  private String mediumNatureAsString;

  /**
   * Support d'origine, fixé à la création, jamais {@link MediumNature#HYBRID} (RG_FILE_FIC_17,
   * DEC_FILE_02 D15).
   */
  @JsonbProperty(value = JSON_ORIGINAL_MEDIUM)
  private MediumNature originalMedium;

  @JsonbProperty(value = JSON_ORIGINAL_MEDIUM_AS_STRING)
  private String originalMediumAsString;

  /**
   * Description, facultative : texte libre qui présente le document (ex-Résumé, DEC_FILE_02 D10).
   */
  @JsonbProperty(value = JSON_DESCRIPTION)
  private String description;

  /**
   * Date de production, facultative, distincte de la date de dépôt.
   */
  @JsonbProperty(value = JSON_PRODUCTION_DATE)
  private LocalDate productionDate;

  @JsonbProperty(value = JSON_PRODUCTION_DATE_AS_STRING)
  private String productionDateAsString;

  /**
   * Identifiant JSON {@link #contentForm}.
   */
  public static final String JSON_CONTENT_FORM = "formeContenu";

  /**
   * Identifiant JSON {@link #contentFormAsString}.
   */
  public static final String JSON_CONTENT_FORM_AS_STRING = "formeContenuChaine";

  /**
   * Identifiant JSON {@link #mediumNature}.
   */
  public static final String JSON_MEDIUM_NATURE = "natureSupport";

  /**
   * Identifiant JSON {@link #mediumNatureAsString}.
   */
  public static final String JSON_MEDIUM_NATURE_AS_STRING = "natureSupportChaine";

  /**
   * Identifiant JSON {@link #originalMedium}.
   */
  public static final String JSON_ORIGINAL_MEDIUM = "supportOrigine";

  /**
   * Identifiant JSON {@link #originalMediumAsString}.
   */
  public static final String JSON_ORIGINAL_MEDIUM_AS_STRING = "supportOrigineChaine";

  /**
   * Identifiant JSON {@link #description} ({@code resume} jusqu'au 2026-11-21, DEC_FILE_02 D10).
   */
  public static final String JSON_DESCRIPTION = HasDescriptionDto.JSON_DESCRIPTION;

  /**
   * Identifiant JSON {@link #productionDate}.
   */
  public static final String JSON_PRODUCTION_DATE = "dateProduction";

  /**
   * Identifiant JSON {@link #productionDateAsString}.
   */
  public static final String JSON_PRODUCTION_DATE_AS_STRING = "dateProductionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fichier";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
