package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-28T22:17:42+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketRequestMapperImpl implements TicketRequestMapper {

    @Override
    public TicketService.TicketCreateRequestDto mapCreate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketCreateRequestDto ticketCreateRequestDto = new TicketService.TicketCreateRequestDto();

        ticketCreateRequestDto.setCode( arg0.getCode() );
        ticketCreateRequestDto.setName( arg0.getName() );
        ticketCreateRequestDto.setDescription( arg0.getDescription() );
        ticketCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        ticketCreateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketCreateRequestDto;
    }

    @Override
    public TicketService.TicketUpdateRequestDto mapUpdate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketUpdateRequestDto ticketUpdateRequestDto = new TicketService.TicketUpdateRequestDto();

        ticketUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketUpdateRequestDto.setDescription( arg0.getDescription() );
        ticketUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        ticketUpdateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketUpdateRequestDto;
    }

    @Override
    public TicketService.TicketTakeInChargeRequestDto mapTakeInChargeRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketTakeInChargeRequestDto ticketTakeInChargeRequestDto = new TicketService.TicketTakeInChargeRequestDto();

        ticketTakeInChargeRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketTakeInChargeRequestDto.setUserIdentifier( ticket.getUserIdentifier() );
        ticketTakeInChargeRequestDto.setCategoryIdentifier( ticket.getCategoryIdentifier() );
        ticketTakeInChargeRequestDto.setPriorityIdentifier( ticket.getPriorityIdentifier() );

        return ticketTakeInChargeRequestDto;
    }

    @Override
    public TicketService.TicketResolveRequestDto mapResolveRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketResolveRequestDto ticketResolveRequestDto = new TicketService.TicketResolveRequestDto();

        ticketResolveRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketResolveRequestDto.setDiagnostic( ticket.getDiagnostic() );
        ticketResolveRequestDto.setSolution( ticket.getSolution() );

        return ticketResolveRequestDto;
    }

    @Override
    public TicketService.TicketSatisfyRequestDto mapSatisfyRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketSatisfyRequestDto ticketSatisfyRequestDto = new TicketService.TicketSatisfyRequestDto();

        ticketSatisfyRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketSatisfyRequestDto.setDiagnostic( ticket.getDiagnostic() );
        ticketSatisfyRequestDto.setSolution( ticket.getSolution() );

        return ticketSatisfyRequestDto;
    }

    @Override
    public TicketService.TicketUnsatisfyRequestDto mapUnsatisfyRequest(TicketDto ticket) {
        if ( ticket == null ) {
            return null;
        }

        TicketService.TicketUnsatisfyRequestDto ticketUnsatisfyRequestDto = new TicketService.TicketUnsatisfyRequestDto();

        ticketUnsatisfyRequestDto.setIdentifier( ticket.getIdentifier() );
        ticketUnsatisfyRequestDto.setDiagnostic( ticket.getDiagnostic() );
        ticketUnsatisfyRequestDto.setSolution( ticket.getSolution() );

        return ticketUnsatisfyRequestDto;
    }
}
