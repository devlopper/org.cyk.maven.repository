package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nom complet de bénéficiaire, saisi
 * librement lorsque le bénéficiaire n'est pas une identité connue.
 *
 * @author Christian
 */
public interface HasBeneficiaryFullNameDto extends HasBeneficiaryFullName {

  /**
   * Identifiant json du nom complet du bénéficiaire.
   */
  String JSON_BENEFICIARY_FULL_NAME = "nomCompletBeneficiaire";
}
