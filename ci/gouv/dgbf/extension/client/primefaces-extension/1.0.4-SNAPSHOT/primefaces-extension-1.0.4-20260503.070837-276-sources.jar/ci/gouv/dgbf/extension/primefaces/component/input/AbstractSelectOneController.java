package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente un contrôleur d'un sélecteur d'un élément.
 *
 * @author Christian
 *
 */
public abstract class AbstractSelectOneController extends AbstractSelectController {

  /* Controls */

  protected SelectOneMenuString selectOneMenu;
  protected SelectOneRadioString selectOneRadio;
  protected AutoCompleteString autoComplete;
  protected AutoCompleteItem autoCompleteItem;

  /*------------------------------ Select one menu ------------------------------*/

  /**
   * Cette méthode permet d'obtenir selectOneMenu.
   *
   * @return selectOneMenu
   */
  public SelectOneMenuString getSelectOneMenu() {
    if (!initialized) {
      Core.runIfNull(selectOneMenu, () -> selectOneMenu = instantiateSelectOneMenu());
      initialized = true;
    }
    return selectOneMenu;
  }

  protected SelectOneMenuString instantiateSelectOneMenu() {
    SelectOneMenuString selector = new SelectOneMenuString();
    processSelectOneMenu(selector);
    processOutputLabel(selector.outputLabel());
    computeSelectOneMenuChoices(selector);
    return selector;
  }

  protected void computeSelectOneMenuChoices(SelectOneMenuString selector) {
    computeSelectOneChoices(selector);
  }

  /**
   * Cette méthode permet de calculer les choix du selectOneMenu.
   */
  public void computeSelectOneMenuChoices() {
    computeSelectOneMenuChoices(selectOneMenu);
  }

  protected void processSelectOneMenu(SelectOneMenuString selectOneMenu) {
    processInput(selectOneMenu);
  }

  /*------------------------------ Select one radio ------------------------------*/

  /**
   * Cette méthode permet d'obtenir selectRadio.
   *
   * @return selectRadio
   */
  public SelectOneRadioString getSelectOneRadio() {
    if (!initialized) {
      Core.runIfNull(selectOneRadio, () -> selectOneRadio = instantiateSelectOneRadio());
      initialized = true;
    }
    return selectOneRadio;
  }

  protected SelectOneRadioString instantiateSelectOneRadio() {
    SelectOneRadioString selector = new SelectOneRadioString();
    processSelectOneRadio(selector);
    processOutputLabel(selector.outputLabel());
    computeSelectOneRadioChoices(selector);
    return selector;
  }

  protected void computeSelectOneRadioChoices(SelectOneRadioString selector) {
    computeSelectOneChoices(selector);
  }

  /**
   * Cette méthode permet de calculer les choix du selectOneRadio.
   */
  public void computeSelectOneRadioChoices() {
    computeSelectOneRadioChoices(selectOneRadio);
  }
  
  /*------------------------------ Autocomplete ------------------------------*/

  /**
   * Cette méthode permet d'obtenir autoComplete.
   *
   * @return autoComplete
   */
  public AutoCompleteString getAutoComplete() {
    if (!initialized) {
      Core.runIfNull(autoComplete, () -> autoComplete = instantiateAutoComplete());
      initialized = true;
    }
    return autoComplete;
  }
  
  /**
   * Cette méthode permet d'utiliser l'autoComplete.
   */
  public void useAutoComplete() {
    getAutoComplete();
  }

  protected AutoCompleteString instantiateAutoComplete() {
    AutoCompleteString selector = new AutoCompleteString(scriptManager);
    processAutoComplete(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processAutoComplete(AutoCompleteString autoComplete) {
    processInput(autoComplete);
  }
  
  /*------------------------------ AutocompleteItem ------------------------------*/

  /**
   * Cette méthode permet d'obtenir autoCompleteItem.
   *
   * @return autoCompleteItem
   */
  public AutoCompleteItem getAutoCompleteItem() {
    if (!initialized) {
      Core.runIfNull(autoCompleteItem, () -> autoCompleteItem = instantiateAutoCompleteItem());
      initialized = true;
    }
    return autoCompleteItem;
  }
  
  /**
   * Cette méthode permet d'utiliser l'autoComplete.
   */
  public void useAutoCompleteItem() {
    getAutoCompleteItem();
  }

  protected AutoCompleteItem instantiateAutoCompleteItem() {
    AutoCompleteItem selector = new AutoCompleteItem(scriptManager);
    processAutoCompleteItem(selector);
    processOutputLabel(selector.outputLabel());
    return selector;
  }

  protected void processAutoCompleteItem(AutoCompleteItem autoCompleteItem) {
    processInput(autoCompleteItem);
  }
  
  /* */
  
  void computeSelectOneChoices(AbstractSelectOne<?> selector) {
    selector.setChoices(null);
    List<SelectItem> selectItems = computeSelectItems();
    addNullChoice(selector);
    selector.addChoices(selectItems);
  }
  
  void addNullChoice(AbstractSelectOne<?> selector) {
    if (nullChoicable) {
      selector.addNullChoice();
    }
  }
}
