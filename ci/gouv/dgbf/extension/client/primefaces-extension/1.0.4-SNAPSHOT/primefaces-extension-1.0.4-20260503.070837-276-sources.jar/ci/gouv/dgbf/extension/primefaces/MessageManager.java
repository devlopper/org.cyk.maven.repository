package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.server.service.api.response.AbstractIdentifiableResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le gestionnaire de message.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Named
public class MessageManager {

  @Getter
  @Setter
  String growlContainerIdentifier;

  @Getter
  @Setter
  String growlIdentifier;
  
  @Getter
  @Setter
  String growlForClientIdentifier;
  
  /**
   * Cette méthode représente le constructeur par défaut.
   */
  public MessageManager() {
    growlContainerIdentifier = "growlContainerIdentifier";
    growlIdentifier = "globalGrowl";
    growlForClientIdentifier = "growlForClientIdentifier";
  }

  public void addMessage(String clientId, FacesMessage message) {
    FacesContext.getCurrentInstance().addMessage(clientId, message);
  }

  public void addGrowlMessage(FacesMessage message) {
    addMessage(growlForClientIdentifier, message);
  }

  /**
   * Cette méthode permet d'ajouter un message à partir d'une réponse.
   *
   * @param response réponse obtnue du serveur.
   */
  public void addGrowlMessageFromResponse(Object response) {
    if (response instanceof AbstractIdentifiableResponseDto dto) {
      addGrowlMessage(new FacesMessage(FacesMessage.SEVERITY_INFO, dto.getMessage(), null));
    }
  }
  
  public void showMessage(FacesMessage message) {
    PrimeFaces.current().dialog().showMessageDynamic(message);
  }
}
