package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFrontEndBaseUriDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasBeneficiaryAdditionalInformationDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasBeneficiaryFullNameDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasBeneficiaryIdentityIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasReporterIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DeclarationDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = DeclarationService.PATH)
@Tag(name = "Gestion des déclarations")
public interface DeclarationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "declarations";


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface DeclarationSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link TicketDto}.
     *
     * @return identifiant de {@link TicketDto}
     */
    String getTicketIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link TicketDto}.
     *
     * @param ticketIdentifier identifiant de {@link TicketDto}
     */
    void setTicketIdentifier(String ticketIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité du declarant.
     *
     * @return identifiant de l'utilisateur
     */
    String getReporterIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité du declarant.
     *
     * @param reporterIdentityIdentifier identifiant de l'identité du declarant
     */
    void setReporterIdentityIdentifier(String reporterIdentityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité du bénéficiaire.
     *
     * @return identifiant de l'identité du bénéficiaire
     */
    String getBeneficiaryIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité du bénéficiaire.
     *
     * @param beneficiaryIdentityIdentifier identifiant de l'identité du bénéficiaire
     */
    void setBeneficiaryIdentityIdentifier(String beneficiaryIdentityIdentifier);

    /**
     * Cette méthode permet d'obtenir le nom complet du bénéficiaire.
     *
     * @return nom complet du bénéficiaire
     */
    String getBeneficiaryFullName();

    /**
     * Cette méthode permet d'assigner le nom complet du bénéficiaire.
     *
     * @param beneficiaryFullName nom complet du bénéficiaire
     */
    void setBeneficiaryFullName(String beneficiaryFullName);

    /**
     * Cette méthode permet d'obtenir les informations complémentaires sur le bénéficiaire.
     *
     * @return informations complémentaires sur le bénéficiaire
     */
    String getBeneficiaryAdditionalInformation();

    /**
     * Cette méthode permet d'assigner les informations complémentaires sur le bénéficiaire.
     *
     * @param beneficiaryAdditionalInformation informations complémentaires sur le bénéficiaire
     */
    void setBeneficiaryAdditionalInformation(String beneficiaryAdditionalInformation);


    /**
     * Identifiant json identifiant de {@link TicketDto}.
     */
    String JSON_TICKET_IDENTIFIER = TicketDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link DeclarationDto}.
     */
    String JSON_REPORTER_IDENTITY_IDENTIFIER = DeclarationDto.JSON_REPORTER_IDENTITY_IDENTIFIER;

    /**
     * Identifiant json de l'identifiant de l'identité du bénéficiaire.
     */
    String JSON_BENEFICIARY_IDENTITY_IDENTIFIER =
        DeclarationDto.JSON_BENEFICIARY_IDENTITY_IDENTIFIER;

    /**
     * Identifiant json du nom complet du bénéficiaire.
     */
    String JSON_BENEFICIARY_FULL_NAME = DeclarationDto.JSON_BENEFICIARY_FULL_NAME;

    /**
     * Identifiant json des informations complémentaires sur le bénéficiaire.
     */
    String JSON_BENEFICIARY_ADDITIONAL_INFORMATION =
        DeclarationDto.JSON_BENEFICIARY_ADDITIONAL_INFORMATION;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_DECLARATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DeclarationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeclarationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements DeclarationSaveRequestDto {
    @JsonbProperty(DeclarationSaveRequestDto.JSON_TICKET_IDENTIFIER)
    private String ticketIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_IDENTITY_IDENTIFIER)
    private String beneficiaryIdentityIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_FULL_NAME)
    private String beneficiaryFullName;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_ADDITIONAL_INFORMATION)
    private String beneficiaryAdditionalInformation;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DECLARATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeclarationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class DeclarationGetManyResponseDto
      extends AbstractGetByPageResponseDto<DeclarationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DeclarationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DECLARATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeclarationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DECLARATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeclarationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DECLARATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DeclarationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeclarationUpdateRequestDto extends ByIdentifierRequestDto
      implements DeclarationSaveRequestDto {
    @JsonbProperty(DeclarationSaveRequestDto.JSON_TICKET_IDENTIFIER)
    private String ticketIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_IDENTITY_IDENTIFIER)
    private String beneficiaryIdentityIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_FULL_NAME)
    private String beneficiaryFullName;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_BENEFICIARY_ADDITIONAL_INFORMATION)
    private String beneficiaryAdditionalInformation;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DECLARATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);


  /**
   * Identifiant du service de création d'incident.
   */
  String CREATE_INCIDENT_IDENTIFIER = "CREATION_INCIDENT_DECLARATION";

  /**
   * Chemin du service de création d'un incident.
   */
  String CREATE_INCIDENT_PATH = "creation-incident";

  /**
   * Cette méthode permet de créer un incident.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_INCIDENT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_INCIDENT_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response createIncident(DeclarationCreateIncidentRequestDto request);

  /**
   * Cette classe représente la requête de création d'incident.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class DeclarationCreateIncidentRequestDto extends AbstractAuditedRequestJsonDto
      implements HasDomainIdentifierDto, HasNameDto, HasDescriptionDto, HasFilesGroupIdentifierDto,
      HasReporterIdentityIdentifierDto, HasFrontEndBaseUriDto, HasBeneficiaryIdentityIdentifierDto,
      HasBeneficiaryFullNameDto, HasBeneficiaryAdditionalInformationDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;

    @JsonbProperty(JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;

    @JsonbProperty(JSON_BENEFICIARY_IDENTITY_IDENTIFIER)
    private String beneficiaryIdentityIdentifier;

    @JsonbProperty(JSON_BENEFICIARY_FULL_NAME)
    private String beneficiaryFullName;

    @JsonbProperty(JSON_BENEFICIARY_ADDITIONAL_INFORMATION)
    private String beneficiaryAdditionalInformation;
  }
}
