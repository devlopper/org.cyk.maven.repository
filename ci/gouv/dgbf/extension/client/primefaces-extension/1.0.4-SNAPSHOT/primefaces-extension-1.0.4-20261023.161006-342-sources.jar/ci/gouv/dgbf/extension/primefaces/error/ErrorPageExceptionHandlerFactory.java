package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.faces.context.ExceptionHandler;
import jakarta.faces.context.ExceptionHandlerFactory;

/**
 * Cette classe fournit {@link ErrorPageExceptionHandler}.
 *
 * @author Christian
 */
public class ErrorPageExceptionHandlerFactory extends ExceptionHandlerFactory {

  /**
   * Ce constructeur enveloppe la fabrique suivante.
   *
   * @param wrapped fabrique enveloppée
   */
  public ErrorPageExceptionHandlerFactory(ExceptionHandlerFactory wrapped) {
    super(wrapped);
  }

  @Override
  public ExceptionHandler getExceptionHandler() {
    return new ErrorPageExceptionHandler(getWrapped().getExceptionHandler());
  }
}
