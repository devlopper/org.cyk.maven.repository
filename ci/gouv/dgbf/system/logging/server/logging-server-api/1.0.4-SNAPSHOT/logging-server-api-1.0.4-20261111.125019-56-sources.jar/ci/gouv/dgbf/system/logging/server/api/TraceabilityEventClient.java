package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventService.TraceabilityEventGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/** Client du service de lecture transverse des événements de traçabilité. */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TraceabilityEventClient extends AbstractClient<TraceabilityEventService>
    implements GetByIdentifier<TraceabilityEventDto>,
    GetMany<TraceabilityEventGetManyResponseDto>,
    GetChart<GetChartResponseDto> {

  /**
   * Associe le service distant au client.
   *
   * @param service service distant
   * @return ce client
   */
  @Override
  public TraceabilityEventClient service(TraceabilityEventService service) {
    return (TraceabilityEventClient) super.service(service);
  }

  /**
   * Obtient une page d’événements.
   *
   * @param request requête
   * @return réponse paginée
   */
  public TraceabilityEventGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TraceabilityEventGetManyResponseDto>(
        TraceabilityEventGetManyResponseDto.class,
        TraceabilityEventService.GET_MANY_IDENTIFIER).execute(
            () -> service().getMany(request));
  }

  /**
   * Obtient une page avec les paramètres standards.
   *
   * @param projection projection
   * @param filter filtre
   * @param page pagination
   * @param auditActor acteur
   * @param auditSession session
   * @return réponse paginée
   */
  @Override
  public TraceabilityEventGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditActor, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditActor);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Obtient un événement par requête.
   *
   * @param request requête
   * @return événement
   */
  public TraceabilityEventDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TraceabilityEventDto>(TraceabilityEventDto.class,
        TraceabilityEventService.GET_BY_IDENTIFIER_IDENTIFIER).execute(
            () -> service().getByIdentifier(request));
  }

  /**
   * Obtient un événement avec les paramètres standards.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditActor acteur
   * @param auditSession session
   * @return événement
   */
  @Override
  public TraceabilityEventDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditActor, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditActor);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Obtient un graphique d’événements.
   *
   * @param request requête
   * @return graphique
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        TraceabilityEventService.GET_CHART_IDENTIFIER).execute(
            () -> service().getChart(request));
  }

  /**
   * Obtient un graphique avec les paramètres standards.
   *
   * @param filter filtre
   * @param auditActor acteur
   * @param auditSession session
   * @return graphique
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditActor, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditActor);
    request.setAuditSession(auditSession);
    return getChart(request);
  }

}
