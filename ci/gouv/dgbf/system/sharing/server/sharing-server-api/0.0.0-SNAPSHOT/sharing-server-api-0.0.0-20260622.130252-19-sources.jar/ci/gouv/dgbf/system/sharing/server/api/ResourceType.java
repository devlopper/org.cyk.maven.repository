package ci.gouv.dgbf.system.sharing.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum ResourceType {

  /**
   * {@link ResourceTypeCode#EXERCISE}.
   */
  EXERCISE(ResourceTypeCode.EXERCISE, "Exercice"),
  
  /**
   * {@link ResourceTypeCode#SECTION}.
   */
  SECTION(ResourceTypeCode.SECTION, "Section"),
  
  /**
   * {@link ResourceTypeCode#ADMINISTRATIVE_UNIT}.
   */
  ADMINISTRATIVE_UNIT(ResourceTypeCode.ADMINISTRATIVE_UNIT, "Unité administrative"),
  
  /**
   * {@link ResourceTypeCode#BUDGET_SPECIALIZATION_UNIT}.
   */
  BUDGET_SPECIALIZATION_UNIT(ResourceTypeCode.BUDGET_SPECIALIZATION_UNIT,
      "Unité de spécialisation du budget"),
  /**
   * {@link ResourceTypeCode#ACTION}.
   */
  ACTION(ResourceTypeCode.ACTION, "Action"),
  
  /**
   * {@link ResourceTypeCode#ACTIVITY}.
   */
  ACTIVITY(ResourceTypeCode.ACTIVITY, "Activité"),
  
  /**
   * {@link ResourceTypeCode#FOLDER}.
   */
  FOLDER(ResourceTypeCode.FOLDER, "Dossier"),
  
  /**
   * {@link ResourceTypeCode#TASK}.
   */
  TASK(ResourceTypeCode.TASK, "Tâche"),

  /**
   * {@link ResourceTypeCode#FILE}.
   */
  FILE(ResourceTypeCode.FILE, "Fichier"),
  /**
   * {@link ResourceTypeCode#FILE_GROUP}.
   */
  FILE_GROUP(ResourceTypeCode.FILE_GROUP, "Fichier de groupe")

  ;

  private ResourceType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link ResourceType} par code.
   *
   * @param code code
   * @return {@link ResourceType}
   */
  public static ResourceType getByCode(String code) {
    return Stream.of(ResourceType.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }
}
