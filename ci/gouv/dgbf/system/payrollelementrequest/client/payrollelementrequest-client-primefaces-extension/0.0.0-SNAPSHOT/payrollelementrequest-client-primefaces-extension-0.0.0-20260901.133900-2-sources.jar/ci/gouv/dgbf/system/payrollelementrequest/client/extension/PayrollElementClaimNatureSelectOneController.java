package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente le contrôleur de sélection de la nature d'une Réclamation
 * (référentiel {@code TR_NATURE_RECLAMATION}) -- simple discriminant classificatoire, sans effet
 * sur son traitement.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementClaimNatureSelectOneController extends AbstractSelectOneController {

  protected PayrollElementClaimNatureSelectOneController() {
    outputLableValue = "Nature";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem(PayrollElementClaimDto.NATURE_ORDINARY, "Ordinaire"),
        new SelectItem(PayrollElementClaimDto.NATURE_LITIGATION, "Contentieux"));
  }

  /**
   * Cette méthode permet d'obtenir le libellé correspondant à une valeur.
   *
   * @param value valeur
   * @return libellé, ou la valeur elle-même si aucune correspondance
   */
  public String labelOf(String value) {
    return computeSelectItemsWhenChoicable().stream()
        .filter(item -> Objects.equals(item.getValue(), value)).map(SelectItem::getLabel)
        .findFirst().orElse(value);
  }
}
