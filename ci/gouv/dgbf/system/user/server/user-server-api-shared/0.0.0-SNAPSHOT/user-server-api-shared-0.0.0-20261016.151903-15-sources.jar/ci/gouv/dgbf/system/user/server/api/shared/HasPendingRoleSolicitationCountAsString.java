package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de demandes de rôle en attente
 * sous forme de chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasPendingRoleSolicitationCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de demandes de rôle en attente sous forme de chaîne.
   *
   * @return le nombre de demandes de rôle en attente sous forme de chaîne
   */
  String getPendingRoleSolicitationCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre de demandes de rôle en attente sous forme de chaîne.
   *
   * @param pendingRoleSolicitationCountAsString le nombre de demandes de rôle en attente sous
   *     forme de chaîne
   */
  void setPendingRoleSolicitationCountAsString(String pendingRoleSolicitationCountAsString);

  /**
   * Identifiant java du nombre de demandes de rôle en attente sous forme de chaîne.
   */
  String FIELD_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING = "pendingRoleSolicitationCountAsString";
}
