package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.OwnerService.OwnerCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.OwnerService.OwnerGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.OwnerService.OwnerUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service OwnerService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class OwnerClient extends AbstractClient<OwnerService> implements GetByIdentifier<OwnerDto>,
    GetMany<OwnerGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {
  private static final Logger LOGGER = Logger.getLogger(OwnerClient.class.getName());

  String ownerIdentifier;

  String ownerIdentifierConfigurationPropertyName() {
    return buildConfigurationPropertyName("owner");
  }

  String ownerIdentifier() {
    if (ownerIdentifier == null) {
      ownerIdentifier = configurationHelper().getValue(String.class,
          ownerIdentifierConfigurationPropertyName(), null);
      LOGGER.log(Level.CONFIG, "Propriétaire des fichiers initialisé : {0}", ownerIdentifier);
    }
    return ownerIdentifier;
  }

  @Override
  public OwnerClient service(OwnerService service) {
    return (OwnerClient) super.service(service);
  }

  /**
   * {@link OwnerService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(OwnerCreateRequestDto request) {
    return new CreateExecutor(OwnerService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link OwnerService#create}.
   *
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    OwnerCreateRequestDto request = new OwnerCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link OwnerService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public OwnerGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<OwnerGetManyResponseDto>(OwnerGetManyResponseDto.class,
        OwnerService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link OwnerService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public OwnerGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link OwnerService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public OwnerDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<OwnerDto>(OwnerDto.class, OwnerService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link OwnerService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public OwnerDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link OwnerService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public OwnerDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<OwnerDto>(OwnerDto.class, OwnerService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link OwnerService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public OwnerDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link OwnerService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(OwnerUpdateRequestDto request) {
    return new IdentifiableExecutor(OwnerService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link OwnerService#update}.
   *
   * @param identifier identifiant
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    OwnerUpdateRequestDto request = new OwnerUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link OwnerService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(OwnerService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link OwnerService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * Cette méthode permet d'initialiser le propriétaire.
   *
   * @param name nom du propriétaire
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return vrai si initialisé sinon faux
   */
  public boolean initialise(String name, String auditWho, String auditSession) {
    String code = ownerIdentifier();
    if (stringHelper().isBlank(code)) {
      throw new IllegalArgumentException(
          String.format("Le code propriétaire doit être configuré avec la propriété %s",
              ownerIdentifierConfigurationPropertyName()));
    }
    FilterDto filter = new FilterDto();
    filter.addCriteria("code", code);
    if (getOne(null, filter, auditWho, auditSession) != null) {
      return false;
    }
    create(code, name, auditWho, auditSession);
    return true;
  }
}
