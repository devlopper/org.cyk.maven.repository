package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les actions du circuit de validation d'une Réclamation Acceptée
 * (RG_REP_RVR_01), toutes portées par la Réclamation entière et jamais par une de ses Revues
 * (RG_REP_RVR_15) : chaque action change le statut de chaque Réclamation sélectionnée et celui de
 * toutes ses Revues dans la même transaction, tout ou rien -- la sélection envoyée par le client
 * n'est jamais une preuve d'autorisation. Les trois transmissions (Contrôle, Validation, Trésor)
 * émettent chacune un bordereau (RG_REP_RVR_17). La transmission pour Visa reste portée par
 * {@link ClaimedValueReviewService#transmitToVisa}.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimCircuitService.PATH)
@Tag(name = "Circuit de validation des réclamations")
public interface PayrollElementClaimCircuitService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "circuit-reclamations";

  /**
   * Identifiant json champ {@code claimIdentifiers}.
   */
  String JSON_CLAIM_IDENTIFIERS = "reclamations";

  /**
   * Identifiant json champ {@code motif}.
   */
  String JSON_MOTIF = "motif";

  /**
   * Identifiant json champ {@code processedCount}.
   */
  String JSON_PROCESSED_COUNT = "nombreTraitees";

  /**
   * Identifiant json champ {@code slipIdentifier}.
   */
  String JSON_SLIP_IDENTIFIER = "bordereau";

  /**
   * Identifiant json champ {@code slipNumber}.
   */
  String JSON_SLIP_NUMBER = "numeroBordereau";

  /**
   * Identifiant json champ {@code processedClaimIdentifiers}.
   */
  String JSON_PROCESSED_CLAIM_IDENTIFIERS = "reclamationsTraitees";

  /**
   * Identifiant du service de Octroi du Visa.
   */
  String GRANT_VISA_IDENTIFIER = "OCTROI_VISA_RECLAMATION";

  /**
   * Chemin du service de Octroi du Visa.
   */
  String GRANT_VISA_PATH = "octroi-visa";

  /**
   * Cette méthode octroie le Visa à des Réclamations Transmises pour Visa -- décision du
   * Responsable (RG_REP_RVR_01 étape 2).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GRANT_VISA_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GRANT_VISA_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response grantVisa(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Transmission pour Contrôle.
   */
  String TRANSMIT_TO_CONTROL_IDENTIFIER = "TRANSMISSION_CONTROLE_RECLAMATION";

  /**
   * Chemin du service de Transmission pour Contrôle.
   */
  String TRANSMIT_TO_CONTROL_PATH = "transmission-controle";

  /**
   * Cette méthode transmet pour Contrôle des Réclamations Visées, du Responsable à l'Agent de
   * Contrôle (RG_REP_RVR_01 étape 3) ; un bordereau de transmission pour Contrôle est émis
   * (RG_REP_RVR_17).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_CONTROL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response transmitToControl(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Contrôle.
   */
  String CONTROL_IDENTIFIER = "CONTROLE_RECLAMATION";

  /**
   * Chemin du service de Contrôle.
   */
  String CONTROL_PATH = "controle";

  /**
   * Cette méthode valide le Contrôle de Réclamations Transmises pour Contrôle -- décision de
   * l'Agent de Contrôle (RG_REP_RVR_01 étape 4).
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONTROL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response control(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Transmission pour Validation.
   */
  String TRANSMIT_TO_VALIDATION_IDENTIFIER = "TRANSMISSION_VALIDATION_RECLAMATION";

  /**
   * Chemin du service de Transmission pour Validation.
   */
  String TRANSMIT_TO_VALIDATION_PATH = "transmission-validation";

  /**
   * Cette méthode transmet pour Validation des Réclamations Contrôlées, de l'Agent de Contrôle au
   * Responsable de Structure (RG_REP_RVR_01 étape 5) ; un bordereau de transmission pour Validation
   * est émis (RG_REP_RVR_17).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_VALIDATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_VALIDATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response transmitToValidation(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Validation.
   */
  String VALIDATE_IDENTIFIER = "VALIDATION_RECLAMATION";

  /**
   * Chemin du service de Validation.
   */
  String VALIDATE_PATH = "validation";

  /**
   * Cette méthode valide des Réclamations Transmises pour Validation -- décision du Responsable de
   * Structure ; leurs Impacts sont appliqués par le module {@code payroll}, tout ou rien
   * (RG_REP_RVR_04).
   *
   * @param request requête
   * @return réponse
   */
  @Path(VALIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = VALIDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response validate(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Délégation de la Validation au Trésor.
   */
  String DELEGATE_TO_TREASURY_IDENTIFIER = "DELEGATION_TRESOR_RECLAMATION";

  /**
   * Chemin du service de Délégation de la Validation au Trésor.
   */
  String DELEGATE_TO_TREASURY_PATH = "delegation-tresor";

  /**
   * Cette méthode délègue au Trésor la Validation de Réclamations Transmises pour Validation, quand
   * leur Type le permet (RG_REP_SOU_08) ; un bordereau de transmission au Trésor est émis
   * (RG_REP_RVR_17).
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELEGATE_TO_TREASURY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELEGATE_TO_TREASURY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response delegateToTreasury(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Validation par le Trésor.
   */
  String TREASURY_VALIDATE_IDENTIFIER = "VALIDATION_TRESOR_RECLAMATION";

  /**
   * Chemin du service de Validation par le Trésor.
   */
  String TREASURY_VALIDATE_PATH = "validation-tresor";

  /**
   * Cette méthode valide des Réclamations à Validation Déléguée -- décision de l'Agent Trésor ;
   * leurs Impacts sont appliqués, tout ou rien (RG_REP_RVR_04).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TREASURY_VALIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TREASURY_VALIDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response treasuryValidate(PayrollElementClaimCircuitRequestDto request);

  /**
   * Identifiant du service de Rejet.
   */
  String REJECT_IDENTIFIER = "REJET_RECLAMATION";

  /**
   * Chemin du service de Rejet.
   */
  String REJECT_PATH = "rejet";

  /**
   * Cette méthode rejette des Réclamations à tout palier du circuit (RG_REP_RVR_16) -- motif
   * obligatoire (RG_REP_RVR_03).
   *
   * @param request requête
   * @return réponse
   */
  @Path(REJECT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REJECT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimCircuitResponseDto.class))})
  Response reject(PayrollElementClaimCircuitRequestDto request);

  /**
   * Cette classe représente la requête d'une action du circuit : les Réclamations sélectionnées
   * (et, pour le Rejet, le motif).
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimCircuitRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiants des Réclamations sélectionnées -- jamais vide.
     */
    @NotEmpty
    @JsonbProperty(JSON_CLAIM_IDENTIFIERS)
    private Set<String> claimIdentifiers;

    /**
     * Motif, obligatoire pour le Rejet (RG_REP_RVR_03) et ignoré par les autres actions.
     */
    @JsonbProperty(JSON_MOTIF)
    private String motif;
  }

  /**
   * Cette classe représente la réponse d'une action du circuit.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimCircuitResponseDto extends AbstractResponseDto {

    /**
     * Nombre de Réclamations traitées.
     */
    @JsonbProperty(JSON_PROCESSED_COUNT)
    private Integer processedCount;

    /**
     * Identifiant du bordereau émis par une transmission (RG_REP_RVR_17), {@code null} pour les
     * autres actions.
     */
    @JsonbProperty(JSON_SLIP_IDENTIFIER)
    private String slipIdentifier;

    /**
     * Numéro du bordereau émis par une transmission (RG_REP_RVR_17), {@code null} pour les autres
     * actions.
     */
    @JsonbProperty(JSON_SLIP_NUMBER)
    private String slipNumber;

    /**
     * Identifiants des Réclamations traitées, donc portées par le bordereau d'une transmission.
     */
    @JsonbProperty(JSON_PROCESSED_CLAIM_IDENTIFIERS)
    private Set<String> processedClaimIdentifiers;
  }
}
