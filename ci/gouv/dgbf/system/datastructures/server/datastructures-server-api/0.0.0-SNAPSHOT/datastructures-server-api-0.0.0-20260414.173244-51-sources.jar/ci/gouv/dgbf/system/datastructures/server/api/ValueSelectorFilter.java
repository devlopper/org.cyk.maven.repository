package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasSourceIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ValueSelectorDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ValueSelectorFilter extends AbstractIdentifiableCodableFilter
    implements FilterHasSourceIdentifier {

  private String sourceIdentifier;

  private String data;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ValueSelectorFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ValueSelectorFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateSourceIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterSourceIdentifier(filter);
  }

}
