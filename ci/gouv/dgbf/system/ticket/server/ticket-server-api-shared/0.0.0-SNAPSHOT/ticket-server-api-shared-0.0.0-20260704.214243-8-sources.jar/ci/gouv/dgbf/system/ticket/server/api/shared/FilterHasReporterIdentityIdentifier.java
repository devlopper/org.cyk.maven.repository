package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'identité de déclarant.
 *
 * @author Christian
 */
public interface FilterHasReporterIdentityIdentifier extends HasReporterIdentityIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'identité du déclarant.
   *
   * @param filter {@link FilterDto}
   */
  default void updateReporterIdentityIdentifier(FilterDto filter) {
    setReporterIdentityIdentifier(ReporterIdentityIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'identité du déclarant de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterReporterIdentityIdentifier(FilterDto filter) {
    ReporterIdentityIdentifierFilter.set(filter, getReporterIdentityIdentifier());
  }

}
