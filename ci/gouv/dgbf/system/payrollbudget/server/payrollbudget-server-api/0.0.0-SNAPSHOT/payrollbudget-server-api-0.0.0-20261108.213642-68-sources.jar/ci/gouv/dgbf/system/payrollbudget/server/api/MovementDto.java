package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un mouvement de {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  private String budgetAsString;

  /**
   * Identifiant {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Identifiant {@link AdministrativeUnitEmployeeDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
  private String administrativeUnitEmployeeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitEmployeeDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING)
  private String administrativeUnitEmployeeAsString;

  /**
   * Représentation en chaine de caractères de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_AS_STRING)
  private String employeeAsString;

  /**
   * Identifiant {@link MovementTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link MovementTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Date d'effet.
   */
  @JsonbProperty(JSON_EFFECTIVE_DATE)
  private LocalDate effectiveDate;

  /**
   * Représentation en chaine de caractères de la date d'effet.
   */
  @JsonbProperty(JSON_EFFECTIVE_DATE_AS_STRING)
  private String effectiveDateAsString;

  /**
   * Représentation en chaine de caractères de l'ensemble de {@link PositionField}.
   */
  @JsonbProperty(JSON_POSITION_FIELDS_AS_STRING)
  private String positionFieldsAsString;

  /**
   * Nouvel emploi occupé après la mesure.
   */
  @JsonbProperty(JSON_NEW_JOB)
  private String newJob;

  /**
   * Nouvelle catégorie.
   */
  @JsonbProperty(JSON_NEW_CATEGORY)
  private String newCategory;

  /**
   * Nouveau grade.
   */
  @JsonbProperty(JSON_NEW_GRADE)
  private String newGrade;

  /**
   * Nouvelle classe.
   */
  @JsonbProperty(JSON_NEW_CLASSIFICATION)
  private String newClassification;

  /**
   * Nouvel échelon.
   */
  @JsonbProperty(JSON_NEW_STEP)
  private String newStep;

  /**
   * Nouvel indice. C'est lui qui, multiplié par la valeur du point, fait le montant.
   */
  @JsonbProperty(JSON_NEW_INDEX)
  private Integer newIndex;

  /**
   * Indice dont l'agent partait.
   */
  @JsonbProperty(JSON_ENTRY_INDEX)
  private Integer entryIndex;

  /**
   * Référence de l'acte qui fonde la mesure.
   */
  @JsonbProperty(JSON_ACT_REFERENCE)
  private String actReference;

  /**
   * Motif de la mesure.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Statut du mouvement.
   */
  @JsonbProperty(JSON_STATUS)
  private String status;

  /**
   * Date à laquelle la mesure est appliquée en paie.
   */
  @JsonbProperty(JSON_APPLICATION_DATE)
  private LocalDate applicationDate;

  /**
   * Représentation en chaine de caractères de la date d'application.
   */
  @JsonbProperty(JSON_APPLICATION_DATE_AS_STRING)
  private String applicationDateAsString;

  /**
   * Identifiant json de identifiant de {@link MovementDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementDto}.
   */
  public static final String JSON_THIS_AS_STRING = "mouvementChaine";

  /**
   * Identifiant json {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_ADMINISTRATIVE_UNIT_AS_STRING;

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER =
      AdministrativeUnitEmployeeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING =
      AdministrativeUnitEmployeeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #employeeAsString}.
   */
  public static final String JSON_EMPLOYEE_AS_STRING =
      AdministrativeUnitEmployeeDto.JSON_EMPLOYEE_AS_STRING;

  /**
   * Identifiant json de {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = MovementTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = MovementTypeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #effectiveDate}.
   */
  public static final String JSON_EFFECTIVE_DATE = "dateEffet";

  /**
   * Identifiant json de {@link #effectiveDateAsString}.
   */
  public static final String JSON_EFFECTIVE_DATE_AS_STRING = "dateEffetChaine";

  /**
   * Identifiant json de {@link #positionFieldsAsString}.
   */
  public static final String JSON_POSITION_FIELDS_AS_STRING = "champsPositionChaine";

  /**
   * Identifiant json de {@link #newJob}.
   */
  public static final String JSON_NEW_JOB = "nouvelEmploi";

  /**
   * Identifiant json de {@link #newCategory}.
   */
  public static final String JSON_NEW_CATEGORY = "nouvelleCategorie";

  /**
   * Identifiant json de {@link #newGrade}.
   */
  public static final String JSON_NEW_GRADE = "nouveauGrade";

  /**
   * Identifiant json de {@link #newClassification}.
   */
  public static final String JSON_NEW_CLASSIFICATION = "nouvelleClasse";

  /**
   * Identifiant json de {@link #newStep}.
   */
  public static final String JSON_NEW_STEP = "nouvelEchelon";

  /**
   * Identifiant json de {@link #newIndex}.
   */
  public static final String JSON_NEW_INDEX = "nouvelIndice";

  /**
   * Identifiant json de {@link #entryIndex}.
   */
  public static final String JSON_ENTRY_INDEX = "indiceEntree";

  /**
   * Identifiant json de {@link #actReference}.
   */
  public static final String JSON_ACT_REFERENCE = "referenceActe";

  /**
   * Identifiant json de {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json de {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json de {@link #applicationDate}.
   */
  public static final String JSON_APPLICATION_DATE = "dateApplication";

  /**
   * Identifiant json de {@link #applicationDateAsString}.
   */
  public static final String JSON_APPLICATION_DATE_AS_STRING = "dateApplicationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
