package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'administrateurs sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasAdministratorCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'administrateurs sous forme de chaîne.
   *
   * @return le nombre d'administrateurs sous forme de chaîne
   */
  String getAdministratorCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre d'administrateurs sous forme de chaîne.
   *
   * @param administratorCountAsString le nombre d'administrateurs sous forme de chaîne
   */
  void setAdministratorCountAsString(String administratorCountAsString);

  /**
   * Identifiant java du nombre d'administrateurs sous forme de chaîne.
   */
  String FIELD_ADMINISTRATOR_COUNT_AS_STRING = "administratorCountAsString";
}
