package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasFullNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController.Viewer;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.client.extension.IdentitySelectOneController;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignSystemAdministratorRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserRequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserService;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateAccountRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link UserDto}.
 *
 * @author Christian
 */
@Dependent
public class UserController extends AbstractController {

  @Inject
  UserClient client;

  @Inject
  UserRequestMapper requestMapper;

  @Inject
  @Getter
  DomainSelectOneController domainSelectOneController;

  @Inject
  @Getter
  IdentitySelectOneController identitySelectOneController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  UserFilterController filterController;

  @Inject
  @Getter
  IdentifiableProcessingController createAccountProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController assignRolesProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController revokeRolesProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController assignSystemAdministratorProcessingController;

  @Inject
  @Getter
  UserSelectManyController userSelectManyController;

  @Inject
  RoleClient roleClient;


  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = UserDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(UserDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(UserService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(HasIdentifierDto.JSON_IDENTIFIER, HasNameDto.JSON_NAME,
        UserDto.JSON_ACCOUNT_EXISTS, HasFullNameDto.JSON_FULL_NAME,
        HasEmailAddressDto.JSON_EMAIL_ADDRESS);

    projection.addNamesIfStringBlank(filterController.getFilter().getDomainIdentifier(),
        HasDomainAsStringDto.JSON_DOMAIN_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(5);

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());

    listController.getCreateController().setFunction(entity -> {
      UserCreateRequestDto request = requestMapper.mapCreate((UserDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
            UserDto.JSON_DOMAIN_IDENTIFIER, UserDto.JSON_IDENTITY_IDENTIFIER,
            UserDto.JSON_IDENTITY_AS_STRING, AbstractIdentifiableNamableDto.JSON_NAME));

    listController.getUpdateController().addEntityConsumer(updateControllerConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    domainSelectOneController
        .setRenderable(StringCore.isBlank(filterController.getFilter().getDomainIdentifier()));
    domainSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(UserDto.class)
            .setDomainIdentifier(identifier));

    identitySelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(UserDto.class)
            .setIdentityIdentifier(identifier));

    nameInputTextController.setOutputLableValue("Nom");
    nameInputTextController.getInputText().addValueConsumer(name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserDto.class).setName(name));

    /* Create account */
    // createAccountProcessingController.setName("Créer compte");
    createAccountProcessingController.setListController(listController);
    createAccountProcessingController.setViewer(Viewer.NONE);
    createAccountProcessingController.prepareConfirmation("Créer compte", "pi pi-lock");
    createAccountProcessingController.setListController(listController);
    DataTable.RecordComponentController submitButtonController =
        new DataTable.RecordComponentController();
    submitButtonController
        .setRenderedFunction(user -> Core.isNotTrue(((UserDto) user).getAccountExists()));
    createAccountProcessingController.setSubmitButtonController(submitButtonController);
    createAccountProcessingController.initialize();
    createAccountProcessingController.getController().setFunction(createAccountFunction());

    /* Add Role */
    assignRolesProcessingController.setListController(listController);
    assignRolesProcessingController.setViewer(Viewer.DIALOG);
    assignRolesProcessingController.prepareDialog(UserDto.class, "Assigner un rôle", "pi pi-users",
        assignRolesFunction(), "assignRolesForm", client);
    assignRolesProcessingController.addShowDialogConsumer(loadAvailableRolesForAssignment());
    assignRolesProcessingController.initialize();

    /* Revoke Role */
    revokeRolesProcessingController.setListController(listController);
    revokeRolesProcessingController.setViewer(Viewer.DIALOG);
    revokeRolesProcessingController.prepareDialog(UserDto.class, "Revoquer des rôles",
        "pi pi-user-minus", revokeRolesFunction(), "revokeRolesForm", client);
    revokeRolesProcessingController.addShowDialogConsumer(loadAssignedRoles());
    revokeRolesProcessingController.initialize();

    roleSelectManyController.setOutputLableValue("Rôles à assigner");
    roleSelectManyController.getSelectManyCheckbox().setRequired(true);
    roleSelectManyController.setChoicable(true);
    roleSelectManyController.getSelectManyCheckbox().setLayout("responsive");
    roleSelectManyController.getSelectManyCheckbox().setColumns(3);

    initializeAssignSystemAdministratorProcessingController();

  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> ((UserDto) entity)
        .setDomainIdentifier(filterController.getFilter().getDomainIdentifier());
  }

  Consumer<Object> updateControllerConsumer() {
    return entity -> {
      domainSelectOneController.getSelectOneMenu()
          .writeValue(((UserDto) entity).getDomainIdentifier());
      identitySelectOneController.getAutoComplete()
          .writeValueAsObject(((UserDto) entity).getIdentityIdentifier());
      nameInputTextController.getInputText().writeValue(((UserDto) entity).getName());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      UserUpdateRequestDto request = requestMapper.mapUpdate((UserDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  Function<Object, Object> createAccountFunction() {
    return identifier -> {
      UserCreateAccountRequestDto request = new UserCreateAccountRequestDto();
      request.setIdentifier((String) identifier);
      request.setAuditWho(userIdentifier);
      return client.createAccount(request);
    };
  }

  UnaryOperator<Object> assignRolesFunction() {
    return identifier -> {
      UserService.UserAssignRolesRequestDto request = new UserService.UserAssignRolesRequestDto();
      request.setIdentifier(((UserDto) identifier).getIdentifier());
      request.setRoleIdentifiers(
          new HashSet<>(roleSelectManyController.getSelectManyCheckbox().getValue()));
      request.setAuditWho(userIdentifier);
      return client.assignRoles(request);
    };
  }

  UnaryOperator<Object> revokeRolesFunction() {
    return identifier -> {
      UserService.UserRevokeRolesRequestDto request = new UserService.UserRevokeRolesRequestDto();
      request.setIdentifier(((UserDto) identifier).getIdentifier());
      request.setRoleIdentifiers(
          new HashSet<>(roleSelectManyController.getSelectManyCheckbox().getValue()));
      request.setAuditWho(userIdentifier);
      return client.revokeRoles(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(domainSelectOneController.getSelectOneMenu(),
            identitySelectOneController.getAutoComplete(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }

  /**
   * Charge les rôles disponibles pour l'assignation (non encore assignés à l'utilisateur).
   */
  public Consumer<String> loadAvailableRolesForAssignment() {
    return identifier -> {
      RoleFilter filter = new RoleFilter();
      filter.setUnassignedUserIdentifier(identifier);
      roleSelectManyController.setFilter(filter.toDto());
      roleSelectManyController.computeSelectManyCheckboxChoices();
    };
  }

  /**
   * Charge les rôles déjà assignés à l'utilisateur (pour la révocation).
   */
  public Consumer<String> loadAssignedRoles() {
    return identifier -> {
      RoleFilter filter = new RoleFilter();
      filter.setAssignedUserIdentifier(identifier);
      roleSelectManyController.setFilter(filter.toDto());
      roleSelectManyController.computeSelectManyCheckboxChoices();
    };
  }


  /**
   * Cette méthode permet de préparer la sélection multiple.
   *
   * @param controller controller
   * @param client client
   * @param userIdentifier user
   */

  public static void prepareSelectManyController(UserSelectManyController controller,
      UserClient client, String userIdentifier) {
    controller.getAutoComplete().setMultiple(true);
    controller.getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(complete(client, query, userIdentifier)));
  }

  /**
   * Cette fonction permet de filtrer la liste des utilisateurs.
   *
   * @param client client
   * @param query query
   * @param userIdentifier user
   * @return list of users
   */
  static List<UserDto> complete(UserClient client, String query, String userIdentifier) {
    GetManyRequestDto request = new GetManyRequestDto();
    UserFilter filter = new UserFilter();
    filter.setNameContains(query);
    request.useFilter(filter);
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME);
    request.setAuditWho(userIdentifier);
    UserService.UserGetManyResponseDto response = client.getMany(request);
    return UserService.UserGetManyResponseDto.getDatas(UserDto.class, response);
  }


  /**
   * Cette méthode permet de créer le bouton Assigner compte Admin.
   */
  void initializeAssignSystemAdministratorProcessingController() {
    assignSystemAdministratorProcessingController.setListController(listController);
    assignSystemAdministratorProcessingController.setViewer(Viewer.NONE);
    assignSystemAdministratorProcessingController.prepareConfirmation("Assigner compte Admin",
        "pi pi-shield");
    assignSystemAdministratorProcessingController.initialize();
    assignSystemAdministratorProcessingController.getController()
        .setFunction(assignSystemAdministratorFunction());
  }

  /**
   * Cette fonction permet d'assigner le rôle administrateur système.
   *
   * @return la fonction permet d'assigner
   */
  UnaryOperator<Object> assignSystemAdministratorFunction() {
    return identifier -> {
      RoleAssignSystemAdministratorRequestDto request =
          new RoleAssignSystemAdministratorRequestDto();
      Set<String> listIdentiants = new HashSet<>();
      listIdentiants.add((String) identifier);
      request.setUserIdentifiers(listIdentiants);
      return roleClient.assignSystemAdministrator(request);
    };
  }

}
