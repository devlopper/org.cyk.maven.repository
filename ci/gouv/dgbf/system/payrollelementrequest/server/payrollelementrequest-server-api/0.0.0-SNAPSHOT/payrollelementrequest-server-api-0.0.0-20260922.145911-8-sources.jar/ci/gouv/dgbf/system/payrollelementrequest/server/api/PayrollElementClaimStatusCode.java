package ci.gouv.dgbf.system.payrollelementrequest.server.api;

/**
 * Cette classe représente les codes de {@link PayrollElementClaimStatus}.
 *
 * @author akm
 *
 */
public class PayrollElementClaimStatusCode {

  private PayrollElementClaimStatusCode() {

  }

  /**
   * Créée.
   */
  public static final String CREATED = "CREEE";

  /**
   * Soumise.
   */
  public static final String SUBMITTED = "SOUMISE";

  /**
   * Prise en charge.
   */
  public static final String IN_CHARGE = "PRISE_EN_CHARGE";

  /**
   * Rejetée.
   */
  public static final String REJECTED = "REJETEE";

  /**
   * Différée.
   */
  public static final String DEFERRED = "DIFFEREE";

  /**
   * Acceptée.
   */
  public static final String ACCEPTED = "ACCEPTEE";
}
