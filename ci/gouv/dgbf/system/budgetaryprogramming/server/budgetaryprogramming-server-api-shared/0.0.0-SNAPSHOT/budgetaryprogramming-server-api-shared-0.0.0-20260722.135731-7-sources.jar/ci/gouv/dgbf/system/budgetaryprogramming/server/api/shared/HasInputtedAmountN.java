package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N.
 *
 * @author Christian
 */
public interface HasInputtedAmountN extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant saisi à l'horizon N.
   *
   * @return le montant saisi à l'horizon N
   */
  Long getInputtedAmountN();

  /**
   * Cette méthode permet d'assigner le montant saisi à l'horizon N.
   *
   * @param amount le montant saisi à l'horizon N
   */
  void setInputtedAmountN(Long amount);

  /**
   * Identifiant java du montant saisi à l'horizon N.
   */
  String FIELD_INPUTTED_AMOUNT_N = "inputtedAmountN";
}
