package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de dépense.
 *
 * @author Christian
 */
public interface HasExpenditureAsStringDto extends HasExpenditureAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la dépense.
   */
  String JSON_EXPENDITURE_AS_STRING = "depenseChaine";
}
