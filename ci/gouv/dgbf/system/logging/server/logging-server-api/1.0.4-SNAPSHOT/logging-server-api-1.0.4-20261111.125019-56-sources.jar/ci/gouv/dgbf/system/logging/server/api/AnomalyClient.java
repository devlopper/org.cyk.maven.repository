package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.logging.server.api.AnomalyService.AnomalyCreateRequestDto;
import ci.gouv.dgbf.system.logging.server.api.AnomalyService.AnomalyGetManyResponseDto;
import ci.gouv.dgbf.system.logging.server.api.AnomalyService.AnomalyTreatRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente le client d'appel de {@link AnomalyService}.
 */
@ApplicationScoped
public class AnomalyClient extends AbstractClient<AnomalyService>
    implements GetByIdentifier<AnomalyDto>, GetMany<AnomalyGetManyResponseDto> {

  private static final Logger LOGGER = Logger.getLogger(AnomalyClient.class.getName());

  @Override
  public AnomalyClient service(AnomalyService service) {
    return (AnomalyClient) super.service(service);
  }

  void setModule(AnomalyCreateRequestDto request) {
    if (request != null && Core.isStringBlank(request.getModule())) {
      request.setModule(callerIdentifier());
    }
  }

  /**
   * Crée une anomalie (RG_LOG_ANO_06 : non-impactant, absorbe les erreurs).
   *
   * @param request requête de création
   * @return réponse ou null si désactivé/échec
   */
  public CreateResponseDto create(AnomalyCreateRequestDto request) {
    if (request == null) {
      return null;
    }
    CreateResponseDto response;
    if (Boolean.TRUE.equals(disabled)) {
      response = null;
      LOGGER.log(Level.WARNING, "Client {0} désactivé. Impossible de créer anomalie.",
          serviceIdentifier());
    } else {
      setModule(request);
      response = new CreateExecutor(AnomalyService.CREATE_IDENTIFIER)
          .setExceptionThrowable(Boolean.FALSE).execute(() -> service().create(request));
      if (response != null) {
        LOGGER.log(Level.FINER, "Une anomalie a été créée. Type={0}, Module={1}",
            new Object[] {request.getType(), request.getModule()});
      }
    }
    return response;
  }

  /**
   * Méthode utilitaire de création d'anomalie pour les modules appelants.
   *
   * @param type type d'anomalie
   * @param module module émetteur
   * @param context contexte JSON
   * @param auditWho identifiant de l'auteur
   * @param auditSession identifiant de session
   * @return réponse ou null
   */
  public CreateResponseDto createAnomaly(AnomalyType type, String module, String context,
      String auditWho, String auditSession) {
    AnomalyCreateRequestDto request = new AnomalyCreateRequestDto();
    request.setType(type);
    request.setModule(module);
    request.setContext(context);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * Obtient plusieurs anomalies.
   *
   * @param request requête
   * @return réponse paginée
   */
  public AnomalyGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AnomalyGetManyResponseDto>(AnomalyGetManyResponseDto.class,
        AnomalyService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * Obtient plusieurs anomalies avec projection, filtre et pagination.
   *
   * @param projection projection
   * @param filter filtre
   * @param page pagination
   * @param auditWho acteur
   * @param auditSession session
   * @return réponse paginée
   */
  @Override
  public AnomalyGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Obtient plusieurs anomalies avec projection, filtre et pagination (sans session).
   *
   * @param projection projection
   * @param filter filtre
   * @param page pagination
   * @param auditWho acteur
   * @return réponse paginée
   */
  public AnomalyGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho) {
    return getMany(projection, filter, page, auditWho, null);
  }

  /**
   * Obtient une anomalie selon requête.
   *
   * @param request requête
   * @return anomalie
   */
  public AnomalyDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AnomalyDto>(AnomalyDto.class, AnomalyService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * Obtient une anomalie par projection, filtre et session.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho acteur
   * @param auditSession session
   * @return anomalie
   */
  public AnomalyDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Obtient une anomalie par projection et filtre.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho acteur
   * @return anomalie
   */
  public AnomalyDto getOne(ProjectionDto projection, FilterDto filter, String auditWho) {
    return getOne(projection, filter, auditWho, null);
  }

  /**
   * Obtient une anomalie par requête d'identifiant.
   *
   * @param request requête
   * @return anomalie
   */
  public AnomalyDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AnomalyDto>(AnomalyDto.class,
        AnomalyService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * Obtient une anomalie par son identifiant.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho acteur
   * @param auditSession session
   * @return anomalie
   */
  @Override
  public AnomalyDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Obtient une anomalie par son identifiant (sans session).
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho acteur
   * @return anomalie
   */
  public AnomalyDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho) {
    return getByIdentifier(identifier, projection, auditWho, null);
  }

  /**
   * Traite une anomalie.
   *
   * @param request requête
   * @return réponse identifiable
   */
  public IdentifiableResponseDto treat(AnomalyTreatRequestDto request) {
    return new IdentifiableExecutor(AnomalyService.TREAT_IDENTIFIER)
        .execute(() -> service().treat(request));
  }

  /**
   * Traite une anomalie par identifiant et commentaire.
   *
   * @param identifier identifiant
   * @param treatmentComment commentaire de décision
   * @param auditWho acteur
   * @return réponse identifiable
   */
  public IdentifiableResponseDto treat(String identifier, String treatmentComment,
      String auditWho) {
    AnomalyTreatRequestDto request = new AnomalyTreatRequestDto();
    request.setIdentifier(identifier);
    request.setTreatmentComment(treatmentComment);
    request.setAuditWho(auditWho);
    return treat(request);
  }
}

