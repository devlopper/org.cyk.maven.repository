package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    DocumentGroupDto, DocumentGroupGetManyResponseDto, DocumentGroupClient> {

  @Inject
  @Getter
  DocumentGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected DocumentGroupSelectOneController() {
    super(DocumentGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
