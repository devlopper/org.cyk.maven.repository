package ci.gouv.dgbf.extension.primefaces;

/**
 * Cette exception représente une excetion de déconnexion.
 *
 * @author Christian
 *
 */
public class LogoutException extends RuntimeException {

  public LogoutException(Throwable cause) {
    super(cause);
  }  
}
