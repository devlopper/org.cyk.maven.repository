package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasValidatedAmountN2}.
 *
 * @author Christian
 */
public interface HasValidatedAmountN2Dto extends HasValidatedAmountN2 {

  /**
   * Identifiant json du montant validé à l'horizon N2.
   */
  String JSON_VALIDATED_AMOUNT_N2 = "montantValideN2";
}
