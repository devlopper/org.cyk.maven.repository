package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasSuspendedDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@code ClaimedValueReview} (Revue de
 * Valeur Réclamée) -- n'étend pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais
 * {@link SpecificService}, entité sans code ni nom propres, jamais exposée en lecture/écriture
 * générique (RU_REP_007, création interne seule). Seules les actions du circuit de validation
 * (RG_REP_RVR_01/02/10) sont exposées ici, chacune toujours déclenchée par un acteur humain,
 * jamais automatique (RG_REP_RVR_02) : transmission groupée pour Visa par l'Agent de Traitement,
 * puis, Revue par Revue, octroi du Visa par le Responsable, transmission pour Contrôle,
 * validation du Contrôle par le Contrôleur, transmission pour Validation, délégation au Trésor
 * par le Responsable de Structure, et rejet par l'un des 4 rôles décisionnaires (RG_REP_RVR_10),
 * motif obligatoire (RG_REP_RVR_03).
 *
 * @author akm
 *
 */
@Path(ClaimedValueReviewService.PATH)
@Tag(name = "Gestion des revues de valeur réclamée")
public interface ClaimedValueReviewService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "revues-valeur-reclamee";

  /**
   * Identifiant du service de Transmission pour Visa (RG_REP_RVR_01).
   */
  String TRANSMIT_TO_VISA_IDENTIFIER = "TRANSMISSION_VISA_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Transmission pour Visa.
   */
  String TRANSMIT_TO_VISA_PATH = "transmission-visa";

  /**
   * Cette méthode permet de transmettre pour Visa, en une seule fois, toutes les Revues de
   * Valeur Réclamée encore à l'état Générée issues des réclamations sélectionnées par l'Agent de
   * Traitement demandeur (RG_REP_PEC_02) -- action manuelle et groupée par réclamation, jamais
   * ligne par ligne au niveau d'une Revue individuelle (l'Agent choisit quelles réclamations
   * transmettre, jamais quelle Revue parmi celles d'une même réclamation, RG_REP_RVR_02). Chaque
   * réclamation sélectionnée est revalidée côté serveur comme appartenant bien à l'acteur
   * demandeur -- la sélection envoyée par le client n'est jamais une preuve d'autorisation.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_VISA_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_VISA_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewTransmitToVisaResponseDto.class))})
  Response transmitToVisa(ClaimedValueReviewTransmitToVisaRequestDto request);

  /**
   * Cette classe représente la requête de Transmission pour Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToVisaRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiants des réclamations sélectionnées par l'Agent (portefeuille, "Transmettre la
     * sélection") -- jamais vide (FA1).
     */
    @NotEmpty
    @JsonbProperty(JSON_CLAIM_IDENTIFIERS)
    private Set<String> claimIdentifiers;
  }

  /**
   * Cette classe représente la réponse de Transmission pour Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToVisaResponseDto extends AbstractResponseDto {

    @JsonbProperty(JSON_TRANSMITTED_COUNT)
    private Integer transmittedCount;
  }

  /**
   * Identifiant json champ {@code transmittedCount}.
   */
  String JSON_TRANSMITTED_COUNT = "nombreTransmises";

  /**
   * Identifiant json champ {@code claimIdentifiers}.
   */
  String JSON_CLAIM_IDENTIFIERS = ClaimedValueReviewFilter.JSON_CLAIM_IDENTIFIERS;

  /**
   * Identifiant du service d'Octroi de Visa (RG_REP_RVR_01 étape 2, décision du Responsable).
   */
  String GRANT_VISA_IDENTIFIER = "OCTROI_VISA_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service d'Octroi de Visa.
   */
  String GRANT_VISA_PATH = "octroi-visa";

  /**
   * Cette méthode permet d'octroyer le Visa à une Revue de Valeur Réclamée individuelle
   * (RG_REP_RVR_01 étape 2) -- décision du Responsable, jamais automatique (RG_REP_RVR_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GRANT_VISA_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GRANT_VISA_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewGrantVisaResponseDto.class))})
  Response grantVisa(ClaimedValueReviewGrantVisaRequestDto request);

  /**
   * Cette classe représente la requête d'Octroi de Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewGrantVisaRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse d'Octroi de Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewGrantVisaResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Transmission pour Contrôle (RG_REP_RVR_01 étape 3, depuis Visée).
   */
  String TRANSMIT_TO_CONTROL_IDENTIFIER = "TRANSMISSION_CONTROLE_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Transmission pour Contrôle.
   */
  String TRANSMIT_TO_CONTROL_PATH = "transmission-controle";

  /**
   * Cette méthode permet de transmettre pour Contrôle une Revue de Valeur Réclamée individuelle
   * Visée (RG_REP_RVR_01 étape 3) -- action manuelle et distincte de l'Octroi de Visa, jamais
   * automatique (RG_REP_RVR_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_CONTROL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewTransmitToControlResponseDto.class))})
  Response transmitToControl(ClaimedValueReviewTransmitToControlRequestDto request);

  /**
   * Cette classe représente la requête de Transmission pour Contrôle.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToControlRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Transmission pour Contrôle.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToControlResponseDto
      extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Transmission pour Validation (RG_REP_RVR_01 étape 4, depuis
   * Contrôlée).
   */
  String TRANSMIT_TO_VALIDATION_IDENTIFIER = "TRANSMISSION_VALIDATION_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Transmission pour Validation.
   */
  String TRANSMIT_TO_VALIDATION_PATH = "transmission-validation";

  /**
   * Cette méthode permet de transmettre pour Validation une Revue de Valeur Réclamée
   * individuelle Contrôlée (RG_REP_RVR_01 étape 4) -- action manuelle et distincte de la
   * décision du Contrôleur, jamais automatique (RG_REP_RVR_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_VALIDATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_VALIDATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = ClaimedValueReviewTransmitToValidationResponseDto.class))})
  Response transmitToValidation(ClaimedValueReviewTransmitToValidationRequestDto request);

  /**
   * Cette classe représente la requête de Transmission pour Validation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToValidationRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Transmission pour Validation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToValidationResponseDto
      extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Délégation au Trésor (RG_REP_RVR_01 étape 4, RG_REP_SOU_08).
   */
  String DELEGATE_TO_TREASURY_IDENTIFIER = "DELEGATION_TRESOR_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Délégation au Trésor.
   */
  String DELEGATE_TO_TREASURY_PATH = "delegation-tresor";

  /**
   * Cette méthode permet de déléguer à l'Agent Trésor la décision d'une Revue de Valeur
   * Réclamée individuelle Transmise pour Validation (RG_REP_RVR_01 étape 4) -- décision du
   * Responsable de Structure, seulement possible si le Type de Réclamation est Transmissible au
   * Trésor (RG_REP_SOU_08), jamais automatique (RG_REP_RVR_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELEGATE_TO_TREASURY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELEGATE_TO_TREASURY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = ClaimedValueReviewDelegateToTreasuryResponseDto.class))})
  Response delegateToTreasury(ClaimedValueReviewDelegateToTreasuryRequestDto request);

  /**
   * Cette classe représente la requête de Délégation au Trésor.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewDelegateToTreasuryRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Délégation au Trésor.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewDelegateToTreasuryResponseDto
      extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Validation du Contrôle (RG_REP_RVR_01 étape 3, décision du
   * Contrôleur).
   */
  String VALIDATE_CONTROL_IDENTIFIER = "VALIDATION_CONTROLE_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Validation du Contrôle.
   */
  String VALIDATE_CONTROL_PATH = "validation-controle";

  /**
   * Cette méthode permet de valider le Contrôle d'une Revue de Valeur Réclamée individuelle
   * Transmise pour Contrôle (RG_REP_RVR_01 étape 3) -- décision du Contrôleur, jamais
   * automatique (RG_REP_RVR_02) ; ne déclenche pas l'Impact synchrone (RG_REP_RVR_04, réservé à
   * la Validation par le Responsable de Structure ou l'Agent Trésor).
   *
   * @param request requête
   * @return réponse
   */
  @Path(VALIDATE_CONTROL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = VALIDATE_CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewValidateControlResponseDto.class))})
  Response validateControl(ClaimedValueReviewValidateControlRequestDto request);

  /**
   * Cette classe représente la requête de Validation du Contrôle.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateControlRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Validation du Contrôle.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateControlResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Rejet (RG_REP_RVR_01/03).
   */
  String REJECT_IDENTIFIER = "REJET_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Rejet.
   */
  String REJECT_PATH = "rejet";

  /**
   * Cette méthode permet de rejeter une Revue de Valeur Réclamée individuelle, quel que soit le
   * palier où elle se trouve (RG_REP_RVR_01) -- terminal, unique quel que soit ce palier, motif
   * obligatoire (RG_REP_RVR_03) ; n'invalide ni la réclamation ni la Valeur Réclamée qu'elle
   * portait (RG_REP_RVR_07).
   *
   * @param request requête
   * @return réponse
   */
  @Path(REJECT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REJECT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewRejectResponseDto.class))})
  Response reject(ClaimedValueReviewRejectRequestDto request);

  /**
   * Cette classe représente la requête de Rejet.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewRejectRequestDto extends ByIdentifierRequestDto {

    @NotNull
    @JsonbProperty(JSON_MOTIF)
    private String motif;
  }

  /**
   * Cette classe représente la réponse de Rejet.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewRejectResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant json champ {@code motif}.
   */
  String JSON_MOTIF = "motif";

  /**
   * Identifiant du service de Validation directe (RG_REP_RVR_01 étape 5, depuis Transmise pour
   * Validation).
   */
  String VALIDATE_IDENTIFIER = "VALIDATION_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Validation directe.
   */
  String VALIDATE_PATH = "validation";

  /**
   * Cette méthode permet de valider directement une Revue de Valeur Réclamée individuelle
   * Transmise pour Validation (RG_REP_RVR_01 étape 5) -- décision du Responsable de Structure,
   * jamais automatique (RG_REP_RVR_02) ; déclenche l'Impact synchrone sur le module {@code
   * payroll}/{@code scripting} (RG_REP_RVR_04, Zone IMP) : aucun changement de statut si cet
   * Impact échoue.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VALIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = VALIDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimedValueReviewValidateResponseDto.class))})
  Response validate(ClaimedValueReviewValidateRequestDto request);

  /**
   * Cette classe représente la requête de Validation directe.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateRequestDto extends ByIdentifierRequestDto {
  }

  /**
   * Cette classe représente la réponse de Validation directe.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateResponseDto extends ProcessResponseDto {

    @JsonbProperty(JSON_IMPACT_IDENTIFIER)
    private String impactIdentifier;
  }

  /**
   * Identifiant du service de Validation par l'Agent Trésor (RG_REP_RVR_01 étape 5, depuis
   * Validation Déléguée).
   */
  String TREASURY_VALIDATE_IDENTIFIER = "VALIDATION_TRESOR_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Validation par l'Agent Trésor.
   */
  String TREASURY_VALIDATE_PATH = "validation-tresor";

  /**
   * Cette méthode permet de valider, par l'Agent Trésor, une Revue de Valeur Réclamée
   * individuelle en Validation Déléguée (RG_REP_RVR_01 étape 5) -- possible uniquement après
   * délégation par le Responsable de Structure (RG_REP_RVR_10), jamais automatique
   * (RG_REP_RVR_02) ; déclenche le même Impact synchrone que la Validation directe (RG_REP_RVR_04,
   * Zone IMP).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TREASURY_VALIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TREASURY_VALIDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = ClaimedValueReviewTreasuryValidateResponseDto.class))})
  Response treasuryValidate(ClaimedValueReviewTreasuryValidateRequestDto request);

  /**
   * Cette classe représente la requête de Validation par l'Agent Trésor.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTreasuryValidateRequestDto extends ByIdentifierRequestDto {
  }

  /**
   * Cette classe représente la réponse de Validation par l'Agent Trésor.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTreasuryValidateResponseDto extends ProcessResponseDto {

    @JsonbProperty(JSON_IMPACT_IDENTIFIER)
    private String impactIdentifier;
  }

  /**
   * Identifiant du service de Validation directe par lot.
   */
  String VALIDATE_MANY_IDENTIFIER = "VALIDATION_LOT_REVUES_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Validation directe par lot.
   */
  String VALIDATE_MANY_PATH = "validation-lot";

  /**
   * Cette méthode permet de valider directement, en une seule fois, plusieurs Revues de Valeur
   * Réclamée Transmises pour Validation (RG_REP_RVR_01 étape 5) : leurs Impacts sont appliqués par
   * {@code payroll} en une seule transaction, si l'un d'eux est refusé aucune Revue n'est
   * validée.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VALIDATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = VALIDATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimedValueReviewValidateManyResponseDto.class))})
  Response validateMany(ClaimedValueReviewValidateManyRequestDto request);

  /**
   * Cette classe représente la requête de Validation par lot (directe ou par l'Agent Trésor).
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateManyRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiants des Revues à valider -- jamais vide.
     */
    @NotEmpty
    @JsonbProperty(JSON_IDENTIFIERS)
    private Set<String> identifiers;
  }

  /**
   * Cette classe représente la réponse de Validation par lot.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewValidateManyResponseDto extends IdentifiableResponseDto {

    @JsonbProperty(JSON_VALIDATED_COUNT)
    private Integer validatedCount;
  }

  /**
   * Identifiant du service de Validation par lot par l'Agent Trésor.
   */
  String TREASURY_VALIDATE_MANY_IDENTIFIER = "VALIDATION_TRESOR_LOT_REVUES_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Validation par lot par l'Agent Trésor.
   */
  String TREASURY_VALIDATE_MANY_PATH = "validation-tresor-lot";

  /**
   * Cette méthode permet de valider, par l'Agent Trésor et en une seule fois, plusieurs Revues de
   * Valeur Réclamée en Validation Déléguée (RG_REP_RVR_10), avec la même atomicité que la
   * Validation directe par lot.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TREASURY_VALIDATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TREASURY_VALIDATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimedValueReviewValidateManyResponseDto.class))})
  Response treasuryValidateMany(ClaimedValueReviewValidateManyRequestDto request);

  /**
   * Identifiant json champ {@code identifiers}.
   */
  String JSON_IDENTIFIERS = "identifiants";

  /**
   * Identifiant json champ {@code validatedCount}.
   */
  String JSON_VALIDATED_COUNT = "nombreValidees";

  /**
   * Identifiant json champ {@link ClaimedValueReviewDto#impactIdentifier}.
   */
  String JSON_IMPACT_IDENTIFIER = ClaimedValueReviewDto.JSON_IMPACT_IDENTIFIER;

  /**
   * Identifiant du service d'obtention de plusieurs (RU_REP_015, portefeuille de l'Agent par
   * statut et par rôle).
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs, filtrables par
   * {@link ClaimedValueReviewFilter#JSON_STATUS}/{@link ClaimedValueReviewFilter
   * #JSON_PROCESSING_AGENT_IDENTIFIER} (RU_REP_015).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de
   * plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimedValueReviewDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimedValueReviewDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimedValueReviewDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimedValueReviewDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre (RU_REP_015, décompte par onglet du circuit de
   * validation).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Cette classe représente la réponse commune aux actions du circuit de la Revue de Valeur
   * Réclamée exposées ci-dessus -- porte le statut courant atteint à l'issue de l'action.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<ClaimedValueReviewStatus>, HasStatusAsStringDto,
      HasSuspendedDto {

    @JsonbProperty(JSON_STATUS)
    private ClaimedValueReviewStatus status;

    @JsonbProperty(JSON_STATUS_AS_STRING)
    private String statusAsString;

    @JsonbProperty(JSON_SUSPENDED)
    private Boolean suspended;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut courant et de
     * l'indicateur de suspension (R47, RG_REP_RVR_13).
     *
     * @param status statut courant
     * @param suspended indicateur de suspension
     */
    public void initialize(ClaimedValueReviewStatus status, Boolean suspended) {
      initialize(status);
      this.suspended = suspended;
    }

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut courant.
     *
     * @param status statut courant
     */
    public void initialize(ClaimedValueReviewStatus status) {
      this.status = status;
      this.statusAsString = status == null ? null : status.getName();
    }
  }

  /**
   * Identifiant du service de Suspension (RG_REP_RVR_13).
   */
  String SUSPEND_IDENTIFIER = "SUSPENSION_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Suspension.
   */
  String SUSPEND_PATH = "suspension";

  /**
   * Cette méthode permet de suspendre une Revue de Valeur Réclamée (RG_REP_RVR_13) -- geste
   * réversible qui gèle toute action supplémentaire sans changer le statut ; motif obligatoire,
   * réservé à l'Administrateur REP.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SUSPEND_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SUSPEND_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewSuspendResponseDto.class))})
  Response suspend(ClaimedValueReviewSuspendRequestDto request);

  /**
   * Cette classe représente la requête de Suspension.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewSuspendRequestDto extends ByIdentifierRequestDto {

    @NotNull
    @JsonbProperty(JSON_MOTIF)
    private String motif;
  }

  /**
   * Cette classe représente la réponse de Suspension.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewSuspendResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Reprise (RG_REP_RVR_13).
   */
  String RESUME_IDENTIFIER = "REPRISE_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Reprise.
   */
  String RESUME_PATH = "reprise";

  /**
   * Cette méthode permet de reprendre une Revue de Valeur Réclamée suspendue (RG_REP_RVR_13) --
   * la restitue exactement dans l'état où elle a été gelée.
   *
   * @param request requête
   * @return réponse
   */
  @Path(RESUME_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = RESUME_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewResumeResponseDto.class))})
  Response resume(ClaimedValueReviewResumeRequestDto request);

  /**
   * Cette classe représente la requête de Reprise.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewResumeRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Reprise.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewResumeResponseDto extends ProcessResponseDto {

  }
}
