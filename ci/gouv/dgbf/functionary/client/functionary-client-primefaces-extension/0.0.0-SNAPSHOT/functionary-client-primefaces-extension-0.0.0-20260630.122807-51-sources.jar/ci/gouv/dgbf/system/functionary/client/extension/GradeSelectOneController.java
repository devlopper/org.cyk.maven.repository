package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.GradeClient;
import ci.gouv.dgbf.system.functionary.server.api.GradeDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeService.GradeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link GradeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class GradeSelectOneController extends AbstractSelectOneIdentifiableController<
    GradeDto, GradeGetManyResponseDto, GradeClient> {

  @Getter
  @Inject
  GradeClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected GradeSelectOneController() {
    super(GradeDto.class, SelectItemLabelStrategy.NAME);
  }
}
