package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 */
@Dependent
public class DictionaryEntryFilterController
    extends AbstractFilterController<DictionaryEntryFilter> {

  @Inject
  @Getter
  DictionarySelectOneController dictionarySelectOneController;

  public DictionaryEntryFilterController() {
    super(DictionaryEntryFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setDictionaryIdentifier(
        getRequestParameter(DictionaryEntryDto.JSON_DICTIONARY_IDENTIFIER));


    dictionarySelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setDictionaryIdentifier(identifier));
  }
}

