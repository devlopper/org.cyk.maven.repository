package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RoleTabMenuController extends AbstractController {

  @Getter
  TabMenu menu;

  @Inject
  IconManager iconManager;

  @Getter
  RoleDto role;

  String isToBeControlledInPriorityParameterName;

  String statusParameterName;

  /**
   * Cette méthode permet de construire.
   */
  protected RoleTabMenuController() {
    menu = new TabMenu();
    menu.setMenuItemStyleClassPrefix("roleDto");
    menu.getOutcomesMap().put(UserRoleListPage.class, RoleReadUsersPage.OUTCOME);
    // Onglet Demandes (RU_UTI_027) : page du client, désignée par son identifiant de navigation
    menu.getOutcomesMap().put(RoleSolicitationDto.class, "roleReadRoleSolicitationsPage");

  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    menu.tabBuilder().menuItemValue("Utilisateur")
        .menuItemIcon(iconManager.getUser()).type(UserRoleListPage.class)
        .addMenuItemParameter(requestParameterIdentifierName, role.getIdentifier())
        .build();
    menu.tabBuilder().menuItemValue("Demandes")
        .menuItemIcon(iconManager.getRoleSolicitation()).type(RoleSolicitationDto.class)
        .addMenuItemParameter(requestParameterIdentifierName, role.getIdentifier())
        .build();
    menu.initialize();
  }

}
