package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une projection d'emploi.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class JobProjectionDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  private String budgetAsString;

  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Identifiant {@link JobDto}.
   */
  @JsonbProperty(JSON_JOB_IDENTIFIER)
  private String jobIdentifier;

  /**
   * Représentation en chaine de caractères de l'emploi.
   */
  @JsonbProperty(JSON_JOB_AS_STRING)
  String jobAsString;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Integer amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;

  /**
   * Identifiant json champ {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  @Deprecated(forRemoval = true)
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Identifiant json {@link #jobIdentifier}.
   */
  public static final String JSON_JOB_IDENTIFIER = "idEmploi";

  /**
   * Identifiant json champ {@link #jobAsString}.
   */
  public static final String JSON_JOB_AS_STRING = "emploiChaine";

  /**
   * Identifiant json champ {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json champ {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "projection d'emploi";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "projections d'emploi";
}
