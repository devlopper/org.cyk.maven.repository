package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques de {@link AdministrativeUnitEmployeeCategoryDto}.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum AdministrativeUnitEmployeeCategoryChart {

  /**
   * Compte d'employé.
   */
  EMPLOYEE_COUNT(AdministrativeUnitEmployeeCategoryChartCode.EMPLOYEE_COUNT,
      "Éffectif du personnel par catégorie"),

  /**
   * Montant d'employé.
   */
  EMPLOYEE_AMOUNT(AdministrativeUnitEmployeeCategoryChartCode.EMPLOYEE_AMOUNT,
      "Montant du personnel par catégorie"),

  /**
   * Situation du personnel.
   */
  EMPLOYEE_SITUATION(AdministrativeUnitEmployeeCategoryChartCode.EMPLOYEE_SITUATION,
      "Situation du personnel par catégorie")

  ;

  /**
   * Code.
   */
  String code;

  String name;

  /**
   * Cette méthode permet d'obtenir {@link AdministrativeUnitEmployeeCategoryChart} par code.
   *
   * @param code code
   * @return {@link AdministrativeUnitEmployeeCategoryChart}
   */
  public static AdministrativeUnitEmployeeCategoryChart getByCode(String code) {
    return Stream.of(AdministrativeUnitEmployeeCategoryChart.values())
        .filter(chart -> chart.getCode().equals(code)).findFirst().orElse(null);
  }
}
