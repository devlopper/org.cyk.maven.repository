package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un exercice.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExerciseDto extends AbstractIdentifiableCodableNamableDto
    implements PayslipContainerDto {

  @JsonbProperty(JSON_YEAR)
  private Integer year;

  /**
   * Représentation en chaine de caractères du statut.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /*-- Début définition des montants --*/

  /**
   * Représentation en chaine de caractères du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_AS_STRING)
  private String grossAmountAsString;

  /**
   * Représentation en chaine de caractères du montant brut imposable.
   */
  @JsonbProperty(JSON_TAXABLE_GROSS_AMOUNT_AS_STRING)
  private String taxableGrossAmountAsString;

  /**
   * Représentation en chaine de caractères des éléments non soumis.
   */
  @JsonbProperty(JSON_NON_TAXABLE_AMOUNT_AS_STRING)
  private String nonTaxableAmountAsString;

  /**
   * Représentation en chaine de caractères du montant des retenues.
   */
  @JsonbProperty(JSON_DEDUCTIONS_AMOUNT_AS_STRING)
  private String deductionsAmountAsString;

  /**
   * Représentation en chaine de caractères du montant net.
   */
  @JsonbProperty(JSON_NET_AMOUNT_AS_STRING)
  private String netAmountAsString;

  /**
   * Représentation en chaine de caractères du montant employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_AMOUNT_AS_STRING)
  private String employerAmountAsString;

  /**
   * Représentation en chaine de caractères du montant initialisé.
   */
  @JsonbProperty(JSON_INITIALIZED_AMOUNT_AS_STRING)
  private String initializedAmountAsString;

  /**
   * Représentation en chaine de caractères du montant controlé.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_AS_STRING)
  private String controledAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation controlée.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_VARIATION_AS_STRING)
  private String controledAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant ajusté.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_AS_STRING)
  private String ajustedAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation ajustée.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_VARIATION_AS_STRING)
  private String ajustedAmountVariationAsString;

  /*-- Fin définition des montants --*/

  // Counts

  @JsonbProperty(JSON_MOVEMENT_COUNT_AS_STRING)
  private String movementCountAsString;

  @JsonbProperty(JSON_MOVEMENT_DEFERRED_PROPOSED_COUNT_AS_STRING)
  private String movementDeferredProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_DEFERRED_COUNT_AS_STRING)
  private String movementDeferredCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTION_PROPOSED_COUNT_AS_STRING)
  private String movementRejectionProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTED_COUNT_AS_STRING)
  private String movementRejectedCountAsString;
  
  @JsonbProperty(JSON_CONSTANT_COUNT_AS_STRING)
  private String constantCountAsString;

  @JsonbProperty(JSON_COMPONENT_COUNT_AS_STRING)
  private String componentCountAsString;

  @JsonbProperty(JSON_EARNING_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String earningComponentHavingNonZeroAmountCountAsString;

  @JsonbProperty(JSON_DEDUCTION_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String deductionComponentHavingNonZeroAmountCountAsString;

  @JsonbProperty(JSON_COMPONENT_HAVING_NON_BLANK_MESSAGE_COUNT_AS_STRING)
  private String componentHavingNonBlankMessageCountAsString;

  /**
   * Identifiant json de identifiant de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idExercice";

  /**
   * Identifiant json de année de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_YEAR = "anneeExercice";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_AS_STRING = "exerciceChaine";

  /**
   * Identifiant json {@link #year}.
   */
  public static final String JSON_YEAR = "annee";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exercice";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
