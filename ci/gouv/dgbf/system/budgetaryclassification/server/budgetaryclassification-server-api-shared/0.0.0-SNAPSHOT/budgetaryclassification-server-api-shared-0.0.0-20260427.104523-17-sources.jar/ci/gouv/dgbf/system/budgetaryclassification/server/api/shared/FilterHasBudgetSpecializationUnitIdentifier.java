package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de l'unité de
 * spécialisation du budget.
 *
 * @author Arnaud
 */
public interface FilterHasBudgetSpecializationUnitIdentifier
    extends HasBudgetSpecializationUnitIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant section.
   *
   * @param filter {@link FilterDto}
   */
  default void updateBudgetSpecializationUnitIdentifier(FilterDto filter) {
    setBudgetSpecializationUnitIdentifier(BudgetSpecializationUnitIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant section de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterBudgetSpecializationUnitIdentifier(FilterDto filter) {
    BudgetSpecializationUnitIdentifierFilter.set(filter, getBudgetSpecializationUnitIdentifier());
  }

}
