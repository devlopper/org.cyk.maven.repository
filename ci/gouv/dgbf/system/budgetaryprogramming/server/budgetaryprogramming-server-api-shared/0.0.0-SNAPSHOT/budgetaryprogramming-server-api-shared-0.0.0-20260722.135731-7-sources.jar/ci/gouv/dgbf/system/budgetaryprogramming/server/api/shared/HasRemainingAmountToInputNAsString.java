package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputNAsString {

  /**
   * Obtient le montant restant à saisir pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant restant à saisir pour l'année N sous forme de chaîne de caractères,
   *         {@code null} si aucun plafond n'est défini pour l'année N
   */
  String getRemainingAmountToInputNAsString();

  /**
   * Définit le montant restant à saisir pour l'année N, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToInputNAsString le montant restant à saisir pour l'année N sous forme de
   *        chaîne de caractères
   */
  void setRemainingAmountToInputNAsString(String remainingAmountToInputNAsString);

  /**
   * Identifiant java du montant restant à saisir pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N_AS_STRING = "remainingAmountToInputNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
