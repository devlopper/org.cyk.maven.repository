package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link IdentitiesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentitiesGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<IdentitiesGroupDto,
        IdentitiesGroupGetManyResponseDto, IdentitiesGroupClient> {

  @Inject
  @Getter
  IdentitiesGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected IdentitiesGroupSelectOneController() {
    super(IdentitiesGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
