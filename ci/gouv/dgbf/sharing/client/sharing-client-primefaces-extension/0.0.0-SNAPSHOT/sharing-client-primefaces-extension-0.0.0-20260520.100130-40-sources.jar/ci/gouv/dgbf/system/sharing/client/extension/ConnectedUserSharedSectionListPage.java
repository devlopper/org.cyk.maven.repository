package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste des sections partagées de l'utilisateur connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserSharedSectionListPage
    extends AbstractConnectedUserSharedResourceListPage {

  /**
   * Cette méthode permet de construire.
   */
  public ConnectedUserSharedSectionListPage() {
    super(Location.BUDGETARY_CLASSIFICATION, ResourceType.SECTION);
  }

  @Override
  protected String resourceTypeName() {
    return "sections";
  }

  static final String OUTCOME = "connectedUserSharedSectionListPage";
}
