package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.FundClient;
import ci.gouv.dgbf.system.payroll.server.api.FundDto;
import ci.gouv.dgbf.system.payroll.server.api.FundService.FundGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FundDto}.
 *
 * @author akm
 *
 */
@Dependent
public class FundSelectOneController extends AbstractSelectOneIdentifiableController<
    FundDto, FundGetManyResponseDto, FundClient> {

  @Getter
  @Inject
  FundClient client;

  protected FundSelectOneController() {
    super(FundDto.class, SelectItemLabelStrategy.NAME);
  }
}
