package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion d'identifiant d'identité de déclarant.
 *
 * @author Christian
 */
public interface HasReporterIdentityIdentifierDto extends HasReporterIdentityIdentifier {

  /**
   * Identifiant json de l'identifiant de l'identité du déclarant.
   */
  String JSON_REPORTER_IDENTITY_IDENTIFIER = "idIdentiteDeclarant";
}
