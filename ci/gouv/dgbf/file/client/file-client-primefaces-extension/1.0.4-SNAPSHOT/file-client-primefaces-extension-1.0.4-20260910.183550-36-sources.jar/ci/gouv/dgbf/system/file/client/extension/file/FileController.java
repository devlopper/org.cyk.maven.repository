package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService;
import ci.gouv.dgbf.system.file.server.api.FileService.FileConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.UnaryOperator;
import lombok.Getter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileController extends AbstractController {

  @Inject
  FileClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileRequestMapper requestMapper;

  @Inject
  @Getter
  OwnerSelectOneController ownerSelectOneController;

  @Inject
  @Getter
  FileFilterController filterController;

  /**
   * Contrôleur du bouton de Confirmation (RG_FILE_FIC_09), affiché dans la colonne Action de la
   * liste au même titre que les boutons Consulter/Mettre à jour/Supprimer (mécanisme établi,
   * voir {@code PayrollElementClaimController} du module {@code payrollelementrequest}).
   */
  @Inject
  @Getter
  IdentifiableProcessingController confirmProcessingController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Fichiers";

    listController.setEntityClass(FileDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileService.PATH);
    listController.setFilterController(filterController);
    listController.setDataTableContentFileName("columnsDetails.xhtml");

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileDto.JSON_OWNER_IDENTIFIER,
        FileDto.JSON_OWNER_AS_STRING, FileDto.JSON_NAME, FileDto.JSON_CONTENT_TYPE,
        FileDto.JSON_NUMBER_OF_BYTES_AS_STRING, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(4);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();

    initializeConfirmProcessing();

    listController.getCreateController().setFunction(entity -> {
      FileCreateRequestDto request = new FileCreateRequestDto();
      request.setOwnerIdentifier(((FileDto) entity).getOwnerIdentifier());
      request.setName(((FileDto) entity).getName());
      request.setBytes(((FileDto) entity).getBytes());
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(3);
    listController.getShowUpdateDialogButton().setRendered(false);

    ownerSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(FileDto.class)
            .setOwnerIdentifier(identifier));
  }

  /**
   * Cette méthode permet de réagir au téléchargement d'un fichier.
   *
   * @param event évènement
   */
  public void handleFileUpload(FileUploadEvent event) {
    ((FileDto) listController.getCreateController().getEntity())
        .setName(event.getFile().getFileName());
    ((FileDto) listController.getCreateController().getEntity())
        .setBytes(event.getFile().getContent());
  }

  /**
   * Cette méthode permet de savoir si un Fichier peut être confirmé dans l'état où il se trouve
   * (RG_FILE_FIC_09) : encore "Créé" (provisoire), jamais une fois "Confirmé" (RG_FILE_FIC_08,
   * statut terminal).
   *
   * @param file fichier
   * @return {@code true} si le fichier peut être confirmé
   */
  public boolean confirmable(FileDto file) {
    return FileStatus.CREATED.equals(file.getStatus());
  }

  /**
   * Cette méthode permet d'initialiser {@link #confirmProcessingController}, affiché dans la
   * colonne Action de la liste (RG_FILE_FIC_09), selon le mécanisme déjà établi pour ce type de
   * bouton d'action de statut (cf. {@code PayrollElementClaimController} du module
   * {@code payrollelementrequest}).
   */
  void initializeConfirmProcessing() {
    confirmProcessingController.setListController(listController);
    confirmProcessingController.prepareConfirmation(FileDto.class, "Confirmer", "pi pi-thumbs-up",
        confirmFunction());
    confirmProcessingController
        .setSubmitButtonControllerRenderedFunction(entity -> confirmable((FileDto) entity));
    confirmProcessingController.submitButton().addStyleClass("ui-button-success");
    confirmProcessingController.initialize();
  }

  /**
   * Cette méthode permet de confirmer un Fichier par son identifiant (RG_FILE_FIC_09).
   *
   * @return fonction de confirmation
   */
  UnaryOperator<Object> confirmFunction() {
    return identifier -> {
      FileConfirmRequestDto request = new FileConfirmRequestDto();
      request.setIdentifier((String) identifier);
      request.setAuditWho(userIdentifier);
      return client.confirm(request);
    };
  }
}
