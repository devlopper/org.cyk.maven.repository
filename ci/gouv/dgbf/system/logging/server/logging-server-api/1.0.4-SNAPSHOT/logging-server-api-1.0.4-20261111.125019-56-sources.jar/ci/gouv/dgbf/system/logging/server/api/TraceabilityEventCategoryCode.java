package ci.gouv.dgbf.system.logging.server.api;

/** Codes stables des catégories d’événement de traçabilité. */
public interface TraceabilityEventCategoryCode {

  String LOG = "LOG";

  String OPERATION_ENREGISTREMENT = "OPERATION_ENREGISTREMENT";
}

