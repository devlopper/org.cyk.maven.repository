package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN1AsStringDto extends HasTotalAmountToInputN1AsString {

  /**
   * Identifiant json du montant total à saisir pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N1_AS_STRING = "montantTotalASaisirN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName