package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.DomainService.DomainCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.DomainService.DomainUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DomainDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DomainDto}.

    @author Christian
               """)
public interface DomainRequestMapper
    extends RequestMapper<DomainDto, DomainCreateRequestDto, DomainUpdateRequestDto> {

}
