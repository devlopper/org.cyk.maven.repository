package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueSourceDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueSourceRequestMapperImpl implements ValueSourceRequestMapper {

    @Override
    public ValueSourceService.ValueSourceCreateRequestDto mapCreate(ValueSourceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSourceService.ValueSourceCreateRequestDto valueSourceCreateRequestDto = new ValueSourceService.ValueSourceCreateRequestDto();

        valueSourceCreateRequestDto.setCode( arg0.getCode() );
        valueSourceCreateRequestDto.setName( arg0.getName() );
        valueSourceCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        valueSourceCreateRequestDto.setAttributeName( arg0.getAttributeName() );
        valueSourceCreateRequestDto.setValueType( arg0.getValueType() );

        return valueSourceCreateRequestDto;
    }

    @Override
    public ValueSourceService.ValueSourceUpdateRequestDto mapUpdate(ValueSourceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSourceService.ValueSourceUpdateRequestDto valueSourceUpdateRequestDto = new ValueSourceService.ValueSourceUpdateRequestDto();

        valueSourceUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueSourceUpdateRequestDto.setCode( arg0.getCode() );
        valueSourceUpdateRequestDto.setName( arg0.getName() );
        valueSourceUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        valueSourceUpdateRequestDto.setAttributeName( arg0.getAttributeName() );
        valueSourceUpdateRequestDto.setValueType( arg0.getValueType() );

        return valueSourceUpdateRequestDto;
    }
}
