package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente la capacité à indiquer si l'année N+1 est complétée.
 *
 * @author Christian
 */
public interface HasCompletedN1 extends HasField {

  /**
   * Obtient l'indicateur indiquant si l'année N+1 est complétée.
   *
   * @return {@code true} si l'année N+1 est complétée, sinon {@code false}
   */
  Boolean getCompletedN1();

  /**
   * Définit l'indicateur indiquant si l'année N+1 est complétée.
   *
   * @param completedN1 indicateur indiquant si l'année N+1 est complétée
   */
  void setCompletedN1(Boolean completedN1);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N+1 est complétée.
   */
  String FIELD_COMPLETED_N1 = "completedN1";
}