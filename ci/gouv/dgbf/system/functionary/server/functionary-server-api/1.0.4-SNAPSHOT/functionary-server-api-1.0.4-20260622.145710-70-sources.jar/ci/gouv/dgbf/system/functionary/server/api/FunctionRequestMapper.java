package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.FunctionService.FunctionCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionService.FunctionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionDto}.
 *
 * @author A.K.M
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionDto}.

    @author AKM
               """)
public interface FunctionRequestMapper
    extends RequestMapper<FunctionDto, 
            FunctionCreateRequestDto, FunctionUpdateRequestDto> {

}
