package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.DomainClient;
import ci.gouv.dgbf.system.datastructures.server.api.DomainDto;
import ci.gouv.dgbf.system.datastructures.server.api.DomainRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService.DomainCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService.DomainUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DomainDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class DomainController extends AbstractController {

  @Inject
  DomainClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  DomainRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DomainDto.NAME;

    listController.setEntityClass(DomainDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DomainService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      DomainCreateRequestDto request =
          requestMapper.mapCreate((DomainDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText()
          .writeValue(((DomainDto) entity).getCode());
      nameInputTextController.getInputText()
          .writeValue(((DomainDto) entity).getName());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DomainDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DomainDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      DomainUpdateRequestDto request =
          requestMapper.mapUpdate((DomainDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
