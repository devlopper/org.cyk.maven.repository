package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente l'attribution d'un rôle à un utilisateur.
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserRoleDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Identifiant de {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_IDENTIFIER)
  private String roleIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_AS_STRING)
  private String roleAsString;

  /**
   * Code du Rôle : signale un Rôle réservé sur la fiche Utilisateur (RU_UTI_027).
   */
  @JsonbProperty(JSON_ROLE_CODE)
  private String roleCode;

  /**
   * Libellé de l'Application du Rôle : regroupe les Rôles par Application (RU_UTI_027).
   */
  @JsonbProperty(JSON_APPLICATION_AS_STRING)
  private String applicationAsString;

  /**
   * Code de l'Application du Rôle : décide des boutons de la ligne (Droits par Application).
   */
  @JsonbProperty(JSON_APPLICATION_CODE)
  private String applicationCode;

  /**
   * Code du Domaine de l'Application du Rôle : décide des boutons de la ligne.
   */
  @JsonbProperty(JSON_DOMAIN_CODE)
  private String domainCode;

  /**
   * Identifiant json {@link #applicationCode}.
   */
  public static final String JSON_APPLICATION_CODE = "codeApplication";

  /**
   * Identifiant json {@link #domainCode}.
   */
  public static final String JSON_DOMAIN_CODE = ApplicationDto.JSON_DOMAIN_CODE;

  /**
   * Identifiant json {@link #roleCode}.
   */
  public static final String JSON_ROLE_CODE = "codeRole";

  /**
   * Identifiant json {@link #applicationAsString}.
   */
  public static final String JSON_APPLICATION_AS_STRING = ApplicationDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRoleUtilisateur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "roleUtilisateurChaine";

  /**
   * Identifiant champ java {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #userAsString}.
   */
  public static final String JSON_USER_AS_STRING = UserDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = RoleDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #roleAsString}.
   */
  public static final String JSON_ROLE_AS_STRING = RoleDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "role utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "roles utilisateurs";
}
