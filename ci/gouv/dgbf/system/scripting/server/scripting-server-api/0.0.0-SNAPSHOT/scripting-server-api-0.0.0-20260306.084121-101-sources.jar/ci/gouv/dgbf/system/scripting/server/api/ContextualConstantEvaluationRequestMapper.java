package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ContextualConstantEvaluationDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ContextualConstantEvaluationDto}.

    @author Arnaud
               """)
public interface ContextualConstantEvaluationRequestMapper 
     extends RequestMapper<ContextualConstantEvaluationDto,
    ContextualConstantEvaluationCreateRequestDto, 
    ContextualConstantEvaluationUpdateRequestDto> {
}
