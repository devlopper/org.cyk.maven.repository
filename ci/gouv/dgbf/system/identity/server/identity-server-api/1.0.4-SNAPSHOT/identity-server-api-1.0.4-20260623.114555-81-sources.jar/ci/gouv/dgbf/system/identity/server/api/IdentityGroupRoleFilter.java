package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityGroupRoleDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityGroupRoleFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link IdentityGroupDto}.
   */
  String identityGroupIdentifier;

  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  String groupIdentifier;

  /**
   * Identifiant {@link RoleDto}.
   */
  String roleIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    identityGroupIdentifier = getIdentityGroupIdentifier(filter);
    roleIdentifier = getRoleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIdentityGroupIdentifier(filter, identityGroupIdentifier);
    setRoleIdentifier(filter, roleIdentifier);
  }

  /**
   * Cette méthode permet d'assigner identifiant {@link IdentityGroupDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link IdentityGroupDto}
   */
  public static void setIdentityGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IDENTITY_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link IdentityGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link IdentityGroupDto}
   */
  public static String getIdentityGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner identifiant {@link RoleDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link RoleDto}
   */
  public static void setRoleIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ROLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link RoleDto}.
   *
   * @param filter filtre
   * @return identifiant {@link RoleDto}
   */
  public static String getRoleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ROLE_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #identityGroupIdentifier}.
   */
  public static final String JSON_IDENTITY_GROUP_IDENTIFIER =
      IdentityGroupRoleDto.JSON_IDENTITY_GROUP_IDENTIFIER;
  
  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = IdentityGroupRoleDto.JSON_GROUP_IDENTIFIER;
  
  /**
   * Identifiant JSON {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = IdentityGroupRoleDto.JSON_ROLE_IDENTIFIER;
}
