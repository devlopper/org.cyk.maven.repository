package ci.gouv.dgbf.extension.primefaces.page;

/** Comportement de la page lorsque sa ressource n'est pas disponible. */
public enum IdentifiablePageMode {
  LEGACY,
  DISPLAY_STATE
}
