package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetService.BudgetCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetService.BudgetUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BudgetDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BudgetDto}.

    @author Christian
               """)
public interface BudgetRequestMapper
    extends RequestMapper<BudgetDto, BudgetCreateRequestDto, BudgetUpdateRequestDto> {

}
