package ci.gouv.dgbf.extension.primefaces.component.output;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la pastille de la visibilité (concept transverse {@code HasVisible} de
 * core-extension) : « Visible » (œil, succès) ou « Masqué » (œil barré, secondaire). Utilisée par
 * le fragment {@code /extension/component/output/visible/default.xhtml}.
 *
 * @author Christian
 */
@ApplicationScoped
@Named("visibleRepresentation")
public class VisibleRepresentation extends BooleanTagRepresentation {

  public static final String TRUE_LABEL = "Visible";
  public static final String FALSE_LABEL = "Masqué";

  /**
   * Constructeur.
   */
  public VisibleRepresentation() {
    super(TRUE_LABEL, FALSE_LABEL, "pi pi-eye", "pi pi-eye-slash", "success", "secondary");
  }
}
