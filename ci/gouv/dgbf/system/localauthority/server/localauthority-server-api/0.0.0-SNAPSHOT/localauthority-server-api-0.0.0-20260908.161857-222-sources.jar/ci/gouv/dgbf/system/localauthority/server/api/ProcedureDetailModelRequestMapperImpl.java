package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcedureDetailModelDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-08T16:19:40+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcedureDetailModelRequestMapperImpl implements ProcedureDetailModelRequestMapper {

    @Override
    public ProcedureDetailModelService.ProcedureDetailModelCreateRequestDto mapCreate(ProcedureDetailModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureDetailModelService.ProcedureDetailModelCreateRequestDto procedureDetailModelCreateRequestDto = new ProcedureDetailModelService.ProcedureDetailModelCreateRequestDto();

        procedureDetailModelCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureDetailModelCreateRequestDto.setName( arg0.getName() );
        procedureDetailModelCreateRequestDto.setProcedureModelIdentifier( arg0.getProcedureModelIdentifier() );
        procedureDetailModelCreateRequestDto.setOrder( arg0.getOrder() );
        procedureDetailModelCreateRequestDto.setDetailDate( arg0.getDetailDate() );

        return procedureDetailModelCreateRequestDto;
    }

    @Override
    public ProcedureDetailModelService.ProcedureDetailModelUpdateRequestDto mapUpdate(ProcedureDetailModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureDetailModelService.ProcedureDetailModelUpdateRequestDto procedureDetailModelUpdateRequestDto = new ProcedureDetailModelService.ProcedureDetailModelUpdateRequestDto();

        procedureDetailModelUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureDetailModelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        procedureDetailModelUpdateRequestDto.setName( arg0.getName() );
        procedureDetailModelUpdateRequestDto.setProcedureModelIdentifier( arg0.getProcedureModelIdentifier() );
        procedureDetailModelUpdateRequestDto.setOrder( arg0.getOrder() );
        procedureDetailModelUpdateRequestDto.setDetailDate( arg0.getDetailDate() );

        return procedureDetailModelUpdateRequestDto;
    }
}
