package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListRecordProcessingController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRolesRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RoleDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Optional;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityGroupController extends AbstractController {

  @Inject
  IdentityGroupClient client;

  @Inject
  IdentityGroupRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentitySelectOneController identitySelectOneController;

  @Inject
  @Getter
  IdentitiesGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  RoleSelectOneController roleSelectOneController;

  @Inject
  @Getter
  IdentityGroupFilterController filterController;

  /* Roles */

  @Inject
  @Getter
  ListRecordProcessingController updateRolesController;

  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentityGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(IdentityGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentityGroupService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getIdentityIdentifier(),
        IdentityGroupDto.JSON_IDENTITY_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getGroupIdentifier(),
        IdentityGroupDto.JSON_GROUP_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        IdentityGroupDto.JSON_ROLES_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(IdentityGroupReadPage.OUTCOME);

    listController.initialize();

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(3);

    /* Creation */

    listController.getCreateController().addEntityConsumer(entity -> {
      identitySelectOneController.getAutoComplete().setRendered(true);
      identitySelectOneController.getAutoComplete().writeValue(null);
      roleSelectOneController.getSelectOneMenu().writeValue(null);
      
      ((IdentityGroupDto) entity)
          .setIdentityIdentifier(filterController.getFilter().getIdentityIdentifier());
      ((IdentityGroupDto) entity)
          .setGroupIdentifier(filterController.getFilter().getGroupIdentifier());
    });
    listController.getCreateController().setFunction(entity -> {
      IdentityGroupCreateRequestDto request = requestMapper.mapCreate((IdentityGroupDto) entity);
      request.setUpdateRolesIdentifiers(true);
      request.setAuditWho(userIdentifier);
      return client.create(request);      
    });

    /* Update */

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            IdentityGroupDto.JSON_IDENTITY_IDENTIFIER, IdentityGroupDto.JSON_GROUP_IDENTIFIER,
            IdentityGroupDto.JSON_ROLES_IDENTIFIERS));

    listController.getUpdateController().addEntityConsumer(entity -> {
      identitySelectOneController.getAutoComplete().setRendered(false);

      roleSelectOneController.getSelectOneMenu().writeValue(
          Core.getFirstFromCollection(((IdentityGroupDto) entity).getRolesIdentifiers()));
    });

    listController.getUpdateController().setFunction(entity -> {
      IdentityGroupUpdateRequestDto request = requestMapper.mapUpdate((IdentityGroupDto) entity);
      request.setUpdateRolesIdentifiers(true);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */
    
    identitySelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, IdentityGroupDto.JSON_IDENTITY_AS_STRING);
    identitySelectOneController.filter().addCriteria(IdentityFilter.JSON_EXCLUDED_GROUP_IDENTIFIER,
        filterController.getFilter().getGroupIdentifier());

    identitySelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityGroupDto.class)
            .setIdentityIdentifier(identifier));

    groupSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, IdentityGroupDto.JSON_GROUP_AS_STRING);

    groupSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityGroupDto.class)
            .setGroupIdentifier(identifier));

    roleSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityGroupDto.class)
            .setRolesIdentifiers(Core.getSetFromNonBlankStringOrNull(identifier)));

    /* Update roles */

    updateRolesController.initialize(listController, RoleDto.PLURAL_NAME, "updateRolesForm");
    updateRolesController.getController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, IdentityGroupDto.JSON_ROLES_IDENTIFIERS));
    updateRolesController.getController()
        .addEntityConsumer(entity -> Core.runIfNotNull(
            ((IdentityGroupDto) entity).getRolesIdentifiers(),
            () -> roleSelectManyController.getSelectManyCheckbox()
                .writeValue(new ArrayList<>(((IdentityGroupDto) entity).getRolesIdentifiers()))));
    updateRolesController.getController().setFunction(entity -> {
      IdentityGroupUpdateRolesRequestDto request =
          requestMapper.mapUpdateRoles((IdentityGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.updateRoles(request);
    });

    roleSelectManyController.getSelectManyCheckbox().addValueConsumer(
        identifiers -> ((IdentityGroupDto) updateRolesController.getController().getEntity())
            .setRolesIdentifiers(Optional.ofNullable(identifiers)
                .map(list -> new LinkedHashSet<>(list)).orElse(null)));
  }
}
