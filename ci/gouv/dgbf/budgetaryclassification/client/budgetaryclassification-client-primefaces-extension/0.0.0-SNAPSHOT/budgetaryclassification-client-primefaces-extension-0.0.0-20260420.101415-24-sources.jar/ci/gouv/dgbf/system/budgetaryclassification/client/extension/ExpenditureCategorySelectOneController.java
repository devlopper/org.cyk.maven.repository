package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureCategoryClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureCategoryDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureCategoryService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ExpenditureCategoryDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ExpenditureCategorySelectOneController extends AbstractSelectOneIdentifiableController<
    ExpenditureCategoryDto, GetManyResponseDto, ExpenditureCategoryClient> {

  @Inject
  @Getter
  ExpenditureCategoryClient client;

  protected ExpenditureCategorySelectOneController() {
    super(ExpenditureCategoryDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
