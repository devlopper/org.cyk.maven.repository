package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasValueIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptContextGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ScriptContextGroupFilter extends AbstractIdentifiableCodableFilter
    implements FilterHasValueIdentifier {

  /**
   * Identifiant {@link ConditionalValueDto}.
   */
  private String valueIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptContextGroupFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ScriptContextGroupFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateValueIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterValueIdentifier(filter);
  }

}
