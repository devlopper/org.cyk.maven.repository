package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ActivityNatureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-03T19:56:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ActivityNatureRequestMapperImpl implements ActivityNatureRequestMapper {

    @Override
    public ActivityNatureService.ActivityNatureCreateRequestDto mapCreate(ActivityNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityNatureService.ActivityNatureCreateRequestDto activityNatureCreateRequestDto = new ActivityNatureService.ActivityNatureCreateRequestDto();

        activityNatureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityNatureCreateRequestDto.setCode( arg0.getCode() );
        activityNatureCreateRequestDto.setName( arg0.getName() );

        return activityNatureCreateRequestDto;
    }

    @Override
    public ActivityNatureService.ActivityNatureUpdateRequestDto mapUpdate(ActivityNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityNatureService.ActivityNatureUpdateRequestDto activityNatureUpdateRequestDto = new ActivityNatureService.ActivityNatureUpdateRequestDto();

        activityNatureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityNatureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        activityNatureUpdateRequestDto.setCode( arg0.getCode() );
        activityNatureUpdateRequestDto.setName( arg0.getName() );

        return activityNatureUpdateRequestDto;
    }
}
