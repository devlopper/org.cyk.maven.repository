package ci.gouv.dgbf.system.ticket.server.api;

/**
 * Cette classe représente les codes de {@link TicketStatus}.
 *
 * @author Arnaud
 *
 */
public class TicketStatusCode {

  private TicketStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Pris en charge.
   */
  public static final String CLAIMED = "PRIS_EN_CHARGE";

  /**
   * Résolu.
   */
  public static final String RESOLVED = "RESOLU";

  /**
   * Satisfait.
   */
  public static final String SATISFIED = "SATISFAIT";

  /**
   * Insatisfait.
   */
  public static final String DISSATISFIED = "INSATISFAIT";
  
  /**
   * Redirigé.
   */
  public static final String REDIRECTED = "REDIRIGE";
  
  /**
   * Escaladé.
   */
  public static final String ESCALATED = "ESCALADE";
}
