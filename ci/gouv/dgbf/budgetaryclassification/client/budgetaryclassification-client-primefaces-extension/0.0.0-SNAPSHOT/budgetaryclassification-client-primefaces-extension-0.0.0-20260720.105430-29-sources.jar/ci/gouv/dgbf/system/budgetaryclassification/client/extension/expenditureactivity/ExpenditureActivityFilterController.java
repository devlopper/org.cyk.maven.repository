package ci.gouv.dgbf.system.budgetaryclassification.client.extension.expenditureactivity;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.FilterSearchTextController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ExpenditureActivityDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ExpenditureActivityFilterController
    extends AbstractFilterController<ExpenditureActivityFilter> {

  @Inject
  @Getter
  FilterSearchTextController searchTextController;

  /**
   * Cette méthode permet de construire.
   */
  public ExpenditureActivityFilterController() {
    super(ExpenditureActivityFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    searchTextController.initialize(filter);
  }
}
