package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum PayslipStatus {

  /**
   * {@link PayslipStatusCode#CREATED}.
   */
  CREATED(PayslipStatusCode.CREATED, "Créé", "Création"),

  /**
   * {@link PayslipStatusCode#INITIALIZED}.
   */
  INITIALIZED(PayslipStatusCode.INITIALIZED, "Initialisé", "Initialisation"),

  /**
   * {@link PayslipStatusCode#TRANSMITTED_FOR_CONTROL}.
   */
  TRANSMITTED_FOR_CONTROL(PayslipStatusCode.TRANSMITTED_FOR_CONTROL, "Transmis pour contrôle",
      "Transmission pour contrôle"),

  /**
   * {@link PayslipStatusCode#CONTROLLED}.
   */
  CONTROLLED(PayslipStatusCode.CONTROLLED, "Controlé", "Contrôle"),

  /**
   * {@link PayslipStatusCode#ACCEPTED}.
   */
  ACCEPTED(PayslipStatusCode.ACCEPTED, "Accepté", "Acceptation"),

  /**
   * {@link PayslipStatusCode#VALIDATED}.
   */
  VALIDATED(PayslipStatusCode.VALIDATED, "Validé", "Validation"),

  /**
   * {@link PayslipStatusCode#RECALCULATED}.
   */
  RECALCULATED(PayslipStatusCode.RECALCULATED, "Recalculé", "Recalcul"),

  /**
   * {@link PayslipStatusCode#TRANSMITTED_FOR_ARBITRATION}.
   */
  TRANSMITTED_FOR_ARBITRATION(PayrollStatusCode.TRANSMITTED_FOR_ARBITRATION,
      "Transmis pour arbitrage", "Transmission pour arbitrage"),

  /**
   * {@link PayslipStatusCode#ARBITRATED}.
   */
  ARBITRATED(PayslipStatusCode.ARBITRATED, "Arbitré", "Arbitrage"),

  /**
   * {@link PayslipStatusCode#CLOSED}.
   */
  CLOSED(PayslipStatusCode.CLOSED, "Clôturé", "Clôture")

  ;

  private PayslipStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<PayslipStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le statut par code.
   *
   * @param code code
   * @return statut
   */
  public static PayslipStatus getByCode(String code) {
    return Stream.of(PayslipStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    INITIALIZED.previous = Core.getSet(List.of(CREATED));
    TRANSMITTED_FOR_CONTROL.previous = Core.getSet(List.of(INITIALIZED));
    CONTROLLED.previous = Core.getSet(List.of(TRANSMITTED_FOR_CONTROL));
    ACCEPTED.previous = Core.getSet(List.of(CONTROLLED));
    RECALCULATED.previous = Core.getSet(List.of(ACCEPTED, RECALCULATED));
    VALIDATED.previous = Core.getSet(List.of(ACCEPTED, RECALCULATED));
    TRANSMITTED_FOR_ARBITRATION.previous = Core.getSet(List.of(VALIDATED));
    ARBITRATED.previous = Core.getSet(List.of(TRANSMITTED_FOR_ARBITRATION));
    CLOSED.previous = Core.getSet(List.of(ARBITRATED));
  }
}
