package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * de groupe d'utilisateurs.
 *
 * @author Christian
 */
public interface HasUsersGroupAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du groupe
   * d'utilisateurs.
   *
   * @return identifiant du groupe d'utilisateurs
   */
  String getUsersGroupAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du groupe
   * d'utilisateurs.
   *
   * @param usersGroupAsString identifiant du groupe d'utilisateurs
   */
  void setUsersGroupAsString(String usersGroupAsString);

  /**
   * Identifiant java de représentation en chaine de caractères du groupe d'utilisateurs.
   */
  String FIELD_USERS_GROUP_AS_STRING = "usersGroupAsString";
}
