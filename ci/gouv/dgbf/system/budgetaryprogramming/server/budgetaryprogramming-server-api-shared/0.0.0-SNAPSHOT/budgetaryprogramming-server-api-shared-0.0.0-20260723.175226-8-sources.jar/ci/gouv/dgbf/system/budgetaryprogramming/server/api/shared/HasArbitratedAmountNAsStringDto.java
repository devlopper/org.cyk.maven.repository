package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de montant arbitré à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountNAsStringDto extends HasArbitratedAmountNAsString {

  /**
   * Identifiant json du montant arbitré à l'horizon N, sous forme de chaîne de caractères.
   */
  String JSON_ARBITRATED_AMOUNT_N_AS_STRING = "montantArbitreNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
