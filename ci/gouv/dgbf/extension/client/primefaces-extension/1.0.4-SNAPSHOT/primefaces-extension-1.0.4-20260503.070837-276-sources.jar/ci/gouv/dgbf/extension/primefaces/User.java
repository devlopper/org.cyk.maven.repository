package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un utilisateur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class User {

  /**
   * identifiant d'authentification.
   */
  private String identifier;

  /**
   * Nom de la personne.
   */
  private String firstName;

  /**
   * Prénoms de la personne.
   */
  private String lastNames;

  /**
   * Nom et prénoms de la peronne.
   */
  private String names;

  /**
   * Role de la personne.
   */
  private Set<String> roles;

  Boolean roleVerificationIgnored;

  String computeRoleAsString(Object object) {
    if (object instanceof String string) {
      return string;
    }
    if (object instanceof CodableByStringWithGetterOnly codable) {
      return codable.getCode();
    }
    return null;
  }

  /**
   * Cette méthode permet de savoir si l'utilisateur a un rôle donné.
   *
   * @param role rôle
   * @return vrai si l'utilisateur à le rôle donné sinon faux
   */
  public boolean hasRole(Object role) {
    if (isRoleVerificationIgnored()) {
      return true;
    }
    String roleAsString = computeRoleAsString(role);
    return Optional.ofNullable(roles).orElse(Collections.emptySet()).contains(roleAsString);
  }

  public static boolean hasRole(User user, Object role) {
    return user != null && user.hasRole(role);
  }

  /**
   * Cette méthode permet de savoir si l'utilisateur a au moins un des rôles donnés.
   *
   * @param roles rôles
   * @return vrai si l'utilisateur a au moins un des rôles donnés
   */
  public boolean hasAtLeastOneOfRoles(Collection<Object> roles) {
    if (isRoleVerificationIgnored()) {
      return true;
    }
    if (Core.isCollectionEmpty(roles)) {
      return false;
    }
    Set<String> rolesAsStrings =
        roles.stream().map(this::computeRoleAsString).collect(Collectors.toSet());
    rolesAsStrings.retainAll(Optional.ofNullable(this.roles).orElse(Collections.emptySet()));
    return !rolesAsStrings.isEmpty();
  }

  public static boolean hasAtLeastOneOfRoles(User user, Collection<Object> roles) {
    return user != null && user.hasAtLeastOneOfRoles(roles);
  }

  public static boolean hasAtLeastOneOfRoles(User user, Object[] roles) {
    return hasAtLeastOneOfRoles(user,
        List.of(Optional.ofNullable(roles).orElse(Constant.EMPTY_OBJECT_ARRAY)));
  }

  boolean isRoleVerificationIgnored() {
    if (roleVerificationIgnored == null) {
      roleVerificationIgnored =
          compteRoleVerificationIgnored(System.getProperty(ROLE_VERIFICATION_IGNORED));
    }
    return roleVerificationIgnored;
  }

  boolean compteRoleVerificationIgnored(String value) {
    return !Core.isStringBlank(value) && Boolean.parseBoolean(value);
  }

  private static final String ROLE_VERIFICATION_IGNORED = "roleVerificationIgnored";
}
