package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN2 {

  /**
   * Obtient le montant total à valider pour l'année N+2.
   *
   * @return le montant total à valider pour l'année N+2
   */
  Long getTotalAmountToValidateN2();

  /**
   * Définit le montant total à valider pour l'année N+2.
   *
   * @param totalAmountToValidateN2 le montant total à valider pour l'année N+2
   */
  void setTotalAmountToValidateN2(Long totalAmountToValidateN2);

  /**
   * Identifiant java du montant total à valider pour l'année N+2.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N2 = "totalAmountToValidateN2";
}