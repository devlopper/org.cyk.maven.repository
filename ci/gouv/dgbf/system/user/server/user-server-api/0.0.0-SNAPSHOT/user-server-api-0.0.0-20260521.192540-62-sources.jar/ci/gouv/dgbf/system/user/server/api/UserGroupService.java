package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link UserGroupDto}.
 *
 * @author kimou
 *
 */
@Path(value = UserGroupService.PATH)
@Tag(name = "Gestion des utilisateurs de groupes")
public interface UserGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "utilisateurs-groupes";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface UserGroupSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link UsersGroupDto}.
     *
     * @return identifiant de {@link UsersGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link UsersGroupDto}.
     *
     * @param groupIdentifier identifiant de {@link UsersGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link UserDto}.
     *
     * @return identifiant de {@link UserDto}
     */
    String getUserIdentifier();


    /**
     * Cette méthode permet d'assigner l'identifiant de {@link UserDto}.
     *
     * @param userIdentifier identifiant de {@link UserDto}
     */
    void setUserIdentifier(String userIdentifier);


    /**
     * Identifiant json identifiant de {@link UsersGroupDto}.
     */
    String JSON_GROUP_IDENTIFIER = UsersGroupDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link UserDto}.
     */
    String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  }


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(UserGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
    class UserGroupCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements UserGroupSaveRequestDto {

    @JsonbProperty(UserGroupSaveRequestDto.JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(UserGroupSaveRequestDto.JSON_USER_IDENTIFIER)
    private String userIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class UserGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<UserGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<UserGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(UserGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class UserGroupUpdateRequestDto extends ByIdentifierRequestDto
      implements UserGroupSaveRequestDto {

    @JsonbProperty(UserGroupSaveRequestDto.JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(UserGroupSaveRequestDto.JSON_USER_IDENTIFIER)
    private String userIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link UserGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
