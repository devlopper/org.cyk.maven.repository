package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+2.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN2Dto extends HasTotalAmountToInputN2 {

  /**
   * Identifiant json du montant total à saisir pour l'année N+2.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N2 = "montantTotalASaisirN2";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName