package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN2 {

  /**
   * Obtient le montant total à arbitrer pour l'année N+2.
   *
   * @return le montant total à arbitrer pour l'année N+2
   */
  Long getTotalAmountToArbitrateN2();

  /**
   * Définit le montant total à arbitrer pour l'année N+2.
   *
   * @param totalAmountToArbitrateN2 le montant total à arbitrer pour l'année N+2
   */
  void setTotalAmountToArbitrateN2(Long totalAmountToArbitrateN2);

  /**
   * Identifiant java du montant total à arbitrer pour l'année N+2.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N2 = "totalAmountToArbitrateN2";
}