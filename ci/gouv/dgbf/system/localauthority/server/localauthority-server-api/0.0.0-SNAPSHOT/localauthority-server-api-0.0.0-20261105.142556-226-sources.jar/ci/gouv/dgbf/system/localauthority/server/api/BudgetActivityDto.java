package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une activité de {@link BudgetDto}.
 *
 * @author Donsylla
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetActivityDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  private String budgetAsString;

  /**
   * Identifiant {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /**
   * Code {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_CODE)
  private String activityCode;

  /**
   * Représentation en chaine de caractères de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Libellé {@link ActivityDto} (saisie).
   */
  @JsonbProperty(JSON_NAME)
  private String name;

  /**
   * Identifiant de l'action de {@link ActivityDto} (saisie).
   */
  @JsonbProperty(JSON_ACTION_IDENTIFIER)
  private String actionIdentifier;

  /**
   * Identifiant du compte fonctionnel de {@link ActivityDto} (saisie).
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
  private String functionalAccountIdentifier;

  /**
   * Représentation en chaine de caractères (code - libellé) du compte fonctionnel de
   * {@link ActivityDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_AS_STRING)
  private String functionalAccountAsString;

  /**
   * Identifiant de la nature de {@link ActivityDto} (saisie).
   */
  @JsonbProperty(JSON_NATURE_IDENTIFIER)
  private String natureIdentifier;

  /**
   * Représentation en chaine de caractères du total des montants des financements.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT_AS_STRING)
  private String totalFundingAmountAsString;

  /**
   * Identifiant json de l'identifiant de cette classe.
   */
  public static final String JSON_THIS_IDENTIFIER = "idActiviteBudget";

  /**
   * Identifiant json de la représentation en chaine de caractères de cette classe.
   */
  public static final String JSON_THIS_AS_STRING = "activiteBudgetChaine";

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #activityCode}.
   */
  public static final String JSON_ACTIVITY_CODE = TriennialProgramActivityDto.JSON_ACTIVITY_CODE;

  /**
   * Identifiant json {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = ActivityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableCodableNamableDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #actionIdentifier}.
   */
  public static final String JSON_ACTION_IDENTIFIER = ActivityDto.JSON_ACTION_IDENTIFIER;

  /**
   * Identifiant json champ {@link #functionalAccountIdentifier}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER =
      ActivityDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #functionalAccountAsString}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_AS_STRING =
      TriennialProgramActivityDto.JSON_FUNCTIONAL_ACCOUNT_AS_STRING;

  /**
   * Identifiant json champ {@link #natureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER = ActivityDto.JSON_NATURE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #totalFundingAmountAsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT_AS_STRING =
      TriennialProgramActivityDto.JSON_TOTAL_FUNDING_AMOUNT_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "activité de budget";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "activités de budgets";
}
