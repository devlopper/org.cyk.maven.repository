package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette interface représente un conteneur d'employé.
 */
public interface EmployeeContainer {

  /**
   * Cette méthode permet d'obtenir le nombre d'employé.
   *
   * @return nombre d'employé
   */
  Integer getEmployeeCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre d'employé.
   *
   * @return représentation en chaine de caractères du nombre d'employé
   */
  String getEmployeeCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre d'employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   *
   * @return représentation en chaine de caractères du nombre d'employé
   *         {@link AdministrativeUnitEmployeeStatus#INCOMING}
   */
  String getIncomingEmployeeCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre d'employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   *
   * @return représentation en chaine de caractères du nombre d'employé
   *         {@link AdministrativeUnitEmployeeStatus#OUTGOING}
   */
  String getOutgoingEmployeeCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre d'employé
   * ayant {@link MovementDto} ayant {@link MovementTypeDto} avec
   * {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   *
   * @return représentation en chaine de caractères du nombre d'employé ayant {@link MovementDto}
   *         ayant {@link MovementTypeDto} avec {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  String getAdministrativeUnitChangeEmployeeCountAsString();

  /**
   * Identifiant java du nombre d'employé.
   */
  String FIELD_EMPLOYEE_COUNT = "employeeCount";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'employé.
   */
  String FIELD_EMPLOYEE_COUNT_AS_STRING = "employeeCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   */
  String FIELD_INCOMING_EMPLOYEE_COUNT_AS_STRING = "incomingEmployeeCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   */
  String FIELD_OUTGOING_EMPLOYEE_COUNT_AS_STRING = "outgoingEmployeeCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'employé ayant
   * {@link MovementDto} ayant {@link MovementTypeDto} avec
   * {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  String FIELD_ADMINISTRATIVE_UNIT_CHANGE_EMPLOYEE_COUNT_AS_STRING =
      "administrativeUnitChangeEmployeeCountAsString";
}
