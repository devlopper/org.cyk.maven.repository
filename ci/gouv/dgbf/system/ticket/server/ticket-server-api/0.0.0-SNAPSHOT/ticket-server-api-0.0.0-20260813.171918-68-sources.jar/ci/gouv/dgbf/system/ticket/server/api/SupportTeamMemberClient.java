package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamMemberService.SupportTeamMemberGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SupportTeamMemberService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupportTeamMemberClient extends AbstractClient<SupportTeamMemberService>
    implements GetByIdentifier<SupportTeamMemberDto>,
               GetMany<SupportTeamMemberGetManyResponseDto> {

  @Override
  public SupportTeamMemberClient service(SupportTeamMemberService service) {
    return (SupportTeamMemberClient) super.service(service);
  }

  /**
   * {@link SupportTeamMemberService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamMemberGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SupportTeamMemberGetManyResponseDto>(
      SupportTeamMemberGetManyResponseDto.class,
        SupportTeamMemberService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SupportTeamMemberService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamMemberGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SupportTeamMemberService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamMemberDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupportTeamMemberDto>(SupportTeamMemberDto.class,
        SupportTeamMemberService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SupportTeamMemberService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SupportTeamMemberDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SupportTeamMemberService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SupportTeamMemberDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupportTeamMemberDto>(SupportTeamMemberDto.class,
        SupportTeamMemberService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SupportTeamMemberService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamMemberDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
