package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipTypeRequestMapperImpl implements PayslipTypeRequestMapper {

    @Override
    public PayslipTypeService.PayslipTypeCreateRequestDto mapCreate(PayslipTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTypeService.PayslipTypeCreateRequestDto payslipTypeCreateRequestDto = new PayslipTypeService.PayslipTypeCreateRequestDto();

        payslipTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTypeCreateRequestDto.setCode( arg0.getCode() );
        payslipTypeCreateRequestDto.setName( arg0.getName() );
        payslipTypeCreateRequestDto.setIsSecondary( arg0.getIsSecondary() );
        payslipTypeCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipTypeCreateRequestDto;
    }

    @Override
    public PayslipTypeService.PayslipTypeUpdateRequestDto mapUpdate(PayslipTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTypeService.PayslipTypeUpdateRequestDto payslipTypeUpdateRequestDto = new PayslipTypeService.PayslipTypeUpdateRequestDto();

        payslipTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipTypeUpdateRequestDto.setCode( arg0.getCode() );
        payslipTypeUpdateRequestDto.setName( arg0.getName() );
        payslipTypeUpdateRequestDto.setIsSecondary( arg0.getIsSecondary() );
        payslipTypeUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipTypeUpdateRequestDto;
    }
}
