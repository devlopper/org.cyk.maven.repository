package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de verrou d'imputation.
 *
 * @author Christian
 */
public interface HasImputationLockAsStringDto extends HasImputationLockAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du verrou d'imputation.
   */
  String JSON_IMPUTATION_LOCK_AS_STRING = "verrouImputationChaine";
}
