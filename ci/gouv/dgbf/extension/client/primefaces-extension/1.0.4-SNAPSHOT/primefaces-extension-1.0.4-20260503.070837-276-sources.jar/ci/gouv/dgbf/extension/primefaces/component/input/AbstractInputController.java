package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import ci.gouv.dgbf.extension.primefaces.component.OutputLabel;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import jakarta.inject.Inject;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur d'entrée.
 *
 * @author Christian
 *
 */
public abstract class AbstractInputController extends AbstractController {

  /* Controls */

  @Getter
  @Setter
  protected String outputLableValue;
  
  @Getter
  @Setter
  protected Supplier<Boolean> renderedSupplier;

  @Getter
  @Setter
  protected boolean renderable;

  @Getter
  @Setter
  protected boolean initializable;

  @Getter
  @Setter
  protected boolean initialized;
  
  @Inject
  ScriptManager scriptManager;
  
  protected AbstractInputController() {
    renderable = true;
    initializable = true;
  }

  /**
   * Cette méthode permet de définir la visibilité.
   *
   * @param visibility visibilité
   */
  public void visible(boolean visibility) {
    if (visibility) {
      renderable = true;
      initializable = true;
    } else {
      renderable = false;
      initializable = false;
    }
  }

  /**
   * Cette méthode permet de définir la visibilité lorsque la projection est présente.
   *
   * @param listController contrôleur de liste
   * @param name nom de la projection
   */
  public void visibleWhenListControllerReadControllerHasProjectionName(
      ListController listController, String name) {
    visible(listController.getReadController().hasProjectionName(name));
  }
  
  /* -------------------------------------------------------------------------------------------- */
  
  
  /*  */

  boolean rendered() {
    return Core.getSupplierValue(renderedSupplier, renderable);
  }

  protected void processInput(AbstractWidget input) {
    input.setRendered(rendered());
  }

  protected void processOutputLabel(OutputLabel outputLabel) {
    outputLabel.setValue(outputLableValue);
  }
}
