package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IntervalDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-27T13:33:51+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IntervalRequestMapperImpl implements IntervalRequestMapper {

    @Override
    public IntervalService.IntervalCreateRequestDto mapCreate(IntervalDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IntervalService.IntervalCreateRequestDto intervalCreateRequestDto = new IntervalService.IntervalCreateRequestDto();

        intervalCreateRequestDto.setCode( arg0.getCode() );
        intervalCreateRequestDto.setName( arg0.getName() );
        intervalCreateRequestDto.setValueType( arg0.getValueType() );
        intervalCreateRequestDto.setMinValue( arg0.getMinValue() );
        intervalCreateRequestDto.setMaxValue( arg0.getMaxValue() );

        return intervalCreateRequestDto;
    }

    @Override
    public IntervalService.IntervalUpdateRequestDto mapUpdate(IntervalDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IntervalService.IntervalUpdateRequestDto intervalUpdateRequestDto = new IntervalService.IntervalUpdateRequestDto();

        intervalUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        intervalUpdateRequestDto.setCode( arg0.getCode() );
        intervalUpdateRequestDto.setName( arg0.getName() );
        intervalUpdateRequestDto.setValueType( arg0.getValueType() );
        intervalUpdateRequestDto.setMinValue( arg0.getMinValue() );
        intervalUpdateRequestDto.setMaxValue( arg0.getMaxValue() );

        return intervalUpdateRequestDto;
    }
}
