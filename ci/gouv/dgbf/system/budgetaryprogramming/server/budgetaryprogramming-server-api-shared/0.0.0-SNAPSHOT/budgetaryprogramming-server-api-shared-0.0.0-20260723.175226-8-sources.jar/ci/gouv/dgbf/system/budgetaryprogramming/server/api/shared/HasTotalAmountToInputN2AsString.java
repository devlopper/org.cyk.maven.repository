package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN2AsString {

  /**
   * Obtient le montant total à saisir pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant total à saisir pour l'année N+2 sous forme de chaîne de caractères
   */
  String getTotalAmountToInputN2AsString();

  /**
   * Définit le montant total à saisir pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param totalAmountToInputN2AsString le montant total à saisir pour l'année N+2 sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToInputN2AsString(String totalAmountToInputN2AsString);

  /**
   * Identifiant java du montant total à saisir pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N2_AS_STRING = "totalAmountToInputN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName