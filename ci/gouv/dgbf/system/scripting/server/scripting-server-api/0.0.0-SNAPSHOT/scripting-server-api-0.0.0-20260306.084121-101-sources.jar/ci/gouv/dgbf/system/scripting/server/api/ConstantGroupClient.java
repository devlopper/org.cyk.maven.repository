package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupEvaluateContextualConstantsRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupEvaluateContextualConstantsResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupEvaluateManyContextualConstantsRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupEvaluateManyContextualConstantsResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ConstantGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ConstantGroupClient extends AbstractClient<ConstantGroupService>
    implements GetByIdentifier<ConstantGroupDto>, GetMany<ConstantGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ConstantGroupClient service(ConstantGroupService service) {
    return (ConstantGroupClient) super.service(service);
  }

  /**
   * {@link ConstantGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ConstantGroupCreateRequestDto request) {
    return new CreateExecutor(ConstantGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ConstantGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<>(ConstantGroupGetManyResponseDto.class,
        ConstantGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ConstantGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConstantGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ConstantGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<>(ConstantGroupDto.class, ConstantGroupService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ConstantGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ConstantGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ConstantGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ConstantGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<>(ConstantGroupDto.class,
        ConstantGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ConstantGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConstantGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ConstantGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ConstantGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ConstantGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ConstantGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ConstantGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ConstantGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ConstantGroupService#evaluateContextualConstants}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantGroupEvaluateContextualConstantsResponseDto evaluateContextualConstants(
      ConstantGroupEvaluateContextualConstantsRequestDto request) {
    return new GetOneExecutor<>(ConstantGroupEvaluateContextualConstantsResponseDto.class,
        ConstantGroupService.EVALUATE_CONTEXTUAL_CONSTANTS_IDENTIFIER)
            .execute(() -> service().evaluateContextualConstants(request));
  }
  
  /**
   * {@link ConstantGroupService#evaluateManyContextualConstants}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantGroupEvaluateManyContextualConstantsResponseDto evaluateManyContextualConstants(
      ConstantGroupEvaluateManyContextualConstantsRequestDto request) {
    return new GetOneExecutor<>(ConstantGroupEvaluateManyContextualConstantsResponseDto.class,
        ConstantGroupService.EVALUATE_MANY_CONTEXTUAL_CONSTANTS_IDENTIFIER)
            .execute(() -> service().evaluateManyContextualConstants(request));
  }
}
