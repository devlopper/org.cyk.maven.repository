package ci.gouv.dgbf.extension.primefaces.page;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Modèle de présentation stable, détenu par le bean de page. */
public final class IdentifiableResolution implements Serializable {
  private static final long serialVersionUID = 1L;
  private IdentifiableResolutionStatus status = IdentifiableResolutionStatus.INITIAL;
  private IdentifiableResolutionStatus presentationStatus = IdentifiableResolutionStatus.INITIAL;
  private String message;
  private String title;
  private String resourceName;
  private final List<IdentifiablePageNavigation> navigations = new ArrayList<>();

  public IdentifiableResolutionStatus getStatus() {
    return status;
  }

  public String getMessage() {
    return message;
  }

  public String getTitle() {
    return title;
  }

  /** Titre contextualisé facultatif ; null conserve le titre générique de la vue. */
  public void setTitle(String title) {
    this.title = title;
  }

  /** Libellé métier affiché en surtitre ; null lorsque seul le libellé générique existe. */
  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public IdentifiableResolutionStatus getPresentationStatus() {
    return presentationStatus;
  }

  public boolean isAvailable() {
    return status == IdentifiableResolutionStatus.AVAILABLE;
  }

  public boolean isLoading() {
    return status == IdentifiableResolutionStatus.LOADING;
  }

  /** Indique si la page doit afficher le panneau de message et de navigation. */
  public boolean isUnavailable() {
    return status == IdentifiableResolutionStatus.MISSING_IDENTIFIER
        || status == IdentifiableResolutionStatus.NO_RESOURCE_AVAILABLE
        || status == IdentifiableResolutionStatus.NOT_FOUND
        || status == IdentifiableResolutionStatus.ACCESS_DENIED
        || status == IdentifiableResolutionStatus.ERROR;
  }

  public List<IdentifiablePageNavigation> getNavigations() {
    return List.copyOf(navigations);
  }

  public IdentifiableResolution addNavigation(IdentifiablePageNavigation navigation) {
    navigations.add(Objects.requireNonNull(navigation));
    return this;
  }

  public void update(IdentifiableResolutionStatus status, String message) {
    update(status, message, false);
  }

  /** Sépare la cause interne de sa présentation publique lorsque l'accès doit être masqué. */
  public void update(IdentifiableResolutionStatus status, String message,
      boolean hideAccessDenied) {
    this.status = Objects.requireNonNull(status);
    presentationStatus = hideAccessDenied && status == IdentifiableResolutionStatus.ACCESS_DENIED
        ? IdentifiableResolutionStatus.NOT_FOUND : status;
    this.message = message;
    title = null;
  }

  /** Vérifie la présence d'une issue de navigation avant la résolution. */
  public void validate() {
    if (navigations.isEmpty()) {
      throw new IllegalStateException("Au moins une navigation de page de ressource est requise");
    }
  }
}
