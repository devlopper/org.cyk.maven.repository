package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingExpenditureDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingExpenditureService.PATH)
@Tag(name = "Gestion des Dépenses de Programmation")
public interface ProgrammingExpenditureService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "depensesProgrammation";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingExpenditureSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de la programmation.
     *
     * @return identifiant de la programmation
     */
    String getProgrammingIdentifier();

    /**
     * Définit l'identifiant de la programmation.
     *
     * @param programmingIdentifier l'identifiant de la programmation
     */
    void setProgrammingIdentifier(String programmingIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la dépense.
     *
     * @return identifiant de la dépense
     */
    String getExpenditureIdentifier();

    /**
     * Définit l'identifiant de la dépense.
     *
     * @param expenditureIdentifier l'identifiant de la dépense
     */
    void setExpenditureIdentifier(String expenditureIdentifier);

    /**
     * Identifiant de la programmation.
     */
    String JSON_PROGRAMMING_IDENTIFIER = ProgrammingExpenditureDto.JSON_PROGRAMMING_IDENTIFIER;

    /**
     * Identifiant de la dépense.
     */
    String JSON_EXPENDITURE_IDENTIFIER = ProgrammingExpenditureDto.JSON_EXPENDITURE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingExpenditureDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingExpenditureDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingExpenditureCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingExpenditureCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingExpenditureSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_EXPENDITURE_IDENTIFIER)
    private String expenditureIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingExpenditureDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingExpenditureDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExpenditureGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingExpenditureGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingExpenditureDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingExpenditureDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingExpenditureDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingExpenditureDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExpenditureDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingExpenditureDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingExpenditureDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExpenditureDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingExpenditureDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingExpenditureDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingExpenditureUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de 
   * {@link ProgrammingExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingExpenditureUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingExpenditureSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_EXPENDITURE_IDENTIFIER)
    private String expenditureIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingExpenditureDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DEPENSE_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingExpenditureDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
