package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FundGroupDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FundGroupFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du type groupe de caisse.
   */
  String typeIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FundGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FundGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeIdentifier = getTypeIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTypeIdentifier(filter, typeIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type groupe de caisse.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type groupe de caisse.
   *
   * @param filter filtre
   * @return identifiant du type groupe de caisse
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link FundGroupFilter#typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
          FundGroupDto.JSON_TYPE_IDENTIFIER;

}
