package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N.
 *
 * @author Christian
 */
public interface HasRemainingAmountToValidateN {

  /**
   * Obtient le montant restant à valider pour l'année N.
   *
   * @return le montant restant à valider pour l'année N
   *         pour l'année N
   */
  Long getRemainingAmountToValidateN();

  /**
   * Définit le montant restant à valider pour l'année N.
   *
   * @param remainingAmountToValidateN le montant restant à valider pour l'année N
   */
  void setRemainingAmountToValidateN(Long remainingAmountToValidateN);
  
  /**
   * Identifiant java du montant restant à valider pour l'année N.
   */
  String FIELD_REMAINING_AMOUNT_TO_VALIDATE_N = "remainingAmountToValidateN";
}
