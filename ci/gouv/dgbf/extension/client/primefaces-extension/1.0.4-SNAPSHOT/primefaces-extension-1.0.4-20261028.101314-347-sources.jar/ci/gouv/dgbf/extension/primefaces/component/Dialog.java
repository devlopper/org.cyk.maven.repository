package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un dialogue.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Dialog extends AbstractWidget {

  String header;
  Integer width;
  Integer height;
  Boolean closeOnEscape;
  String onShow;
  String onHide;

  /**
   * Cette méthode prépare un dialogue qui porte un formulaire empilé
   * ({@code /extension/form/stacked/default.xhtml}). Idempotente : sans effet si le dialogue est
   * déjà préparé.
   *
   * @param dialog dialogue
   */
  public static void configureForStackedForm(Dialog dialog) {
    String current = dialog.getStyleClass();
    if (current != null && current.contains("dgbf-form-dialog")) {
      return;
    }
    dialog.setStyleClass(current == null || current.isBlank() ? "dgbf-form-dialog"
        : current + " dgbf-form-dialog");
    dialog.setCloseOnEscape(false);
    dialog.setOnShow("DgbfForms.open('" + dialog.getWidgetVar() + "')");
    dialog.setOnHide("DgbfForms.closed('" + dialog.getWidgetVar() + "')");
  }
}
