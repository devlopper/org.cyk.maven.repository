package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UserGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link UserGroupDto}.

    @author Arnaud
               """)
public interface UserGroupRequestMapper
    extends RequestMapper<UserGroupDto, UserGroupCreateRequestDto, UserGroupUpdateRequestDto> {

}
