package ci.gouv.dgbf.system.user.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page des applications que l'utilisateur connecté administre
 * (Administrateur Applicatif, Technique ou Fonctionnel), dans son profil.
 *
 * @author Christian Yao Komenan
 */
@Named
@ViewScoped
public class UserProfileReadAdministeredApplicationsPage extends AbstractUserProfileReadDatasPage {

  @Inject
  @Getter
  ApplicationController applicationController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    if (user == null) {
      return;
    }
    applicationController.getFilterController().getFilter()
        .setAdministratorUserName(userIdentifier);
    applicationController.getFilterController().getFilter()
        .setDomainIdentifier(user.getDomainIdentifier());
    applicationController.setProfileView(true);
    // Alimente aussi les badges "Mes rôles" sur chaque ligne.
    applicationController.getFilterController().getFilter().setUserName(userIdentifier);
    applicationController.initialize();
  }

  public static final String OUTCOME = "userProfileReadAdministeredApplicationsPage";
}
