/*
 * Indicateur d'attente non bloquant de la charte (constitution-ui.md, paragraphe 3.5), niveau 1.
 *
 * Barre discrete en haut de page, affichee seulement si une requete Ajax dure plus de SHOW_DELAY ms,
 * et maintenue au moins MIN_VISIBLE ms une fois apparue (pas de clignotement). Rien n'est bloque.
 * Le texte d'etat est annonce aux lecteurs d'ecran par une zone role="status".
 * Le niveau 2 (bouton occupe) est natif dans PrimeFaces 13 (classe ui-state-loading) ; la charte
 * n'en ajuste que le rendu (workInProgress.css).
 *
 * Branche par p:ajaxStatus (extension/workInProgress/nonBlocking.xhtml) : start() et stop().
 *
 * Niveau 3 (blocage d'une zone), sur declaration explicite : un bouton portant la classe dgbf-blocking
 * bloque sa zone (le formulaire le plus proche, ou toute la page avec dgbf-blocking-page) pendant sa
 * requete. Le marqueur est une simple classe : sans la charte ce fichier n'est pas charge et la classe
 * n'a aucun effet (l'ancienne fenetre modale bloque alors tout l'ecran).
 *  - la zone devient inerte (clavier et souris) et aria-busy des le depart de la requete ;
 *  - le voile et le libelle n'apparaissent qu'apres SHOW_DELAY et restent au moins MIN_VISIBLE ;
 *  - le libelle est celui du bouton (titre, sinon texte), annonce par la zone role="status" ;
 *  - au-dela de LONG_WAIT, un message d'attente prolongee s'ajoute au libelle ;
 *  - a la fin de la requete (succes, erreur de validation ou erreur reseau), la zone est liberee et le focus
 *    rendu au bouton ; la zone est retrouvee par son identifiant si une mise a jour l'a remplacee.
 * Source de la requete : PrimeFaces.ajax.Utils.getSourceId, evenements pfAjaxSend et pfAjaxComplete (PrimeFaces 13).
 */
var DgbfWorkInProgress = (function () {
  var SHOW_DELAY = 300;
  var MIN_VISIBLE = 400;
  // Texte annonce aux lecteurs d'ecran (libelle d'interface, en francais).
  var STATUS_TEXT = 'Chargement…';
  // Niveau 3.
  var BLOCK_CLASS = 'dgbf-blocking';
  var BLOCK_PAGE_CLASS = 'dgbf-blocking-page';
  var LONG_WAIT = 10000;
  var BLOCK_SUFFIX = ' en cours…';
  var BLOCK_DEFAULT_TEXT = 'Traitement en cours…';
  var LONG_WAIT_TEXT = 'Cela prend plus de temps que prévu, merci de patienter.';
  var blocks = [];
  var blockText = null;

  var pending = 0;
  var showTimer = null;
  var hideTimer = null;
  var shownAt = 0;

  function toggle(active) {
    var bar = document.getElementById('dgbf-work-in-progress');
    if (bar) {
      bar.classList.toggle('dgbf-work-in-progress-active', active);
    }
    var status = document.getElementById('dgbf-work-in-progress-status');
    if (status) {
      status.textContent = active ? (blockText || STATUS_TEXT) : '';
    }
  }

  function show() {
    showTimer = null;
    shownAt = Date.now();
    toggle(true);
  }

  function hide() {
    hideTimer = null;
    shownAt = 0;
    toggle(false);
  }

  function start() {
    pending++;
    if (hideTimer) {
      // Une nouvelle requete arrive pendant le maintien minimal : la barre reste affichee.
      clearTimeout(hideTimer);
      hideTimer = null;
      return;
    }
    if (!shownAt && !showTimer) {
      showTimer = setTimeout(show, SHOW_DELAY);
    }
  }

  function stop() {
    pending = Math.max(0, pending - 1);
    if (pending > 0) {
      return;
    }
    if (showTimer) {
      // Requete plus rapide que le delai : rien n'a ete montre, rien a masquer.
      clearTimeout(showTimer);
      showTimer = null;
      return;
    }
    if (shownAt) {
      hideTimer = setTimeout(hide, Math.max(0, MIN_VISIBLE - (Date.now() - shownAt)));
    }
  }

  /* ---- Niveau 3 : blocage d'une zone ---- */

  function pageElements() {
    var items = [];
    for (var i = 0; i < document.body.children.length; i++) {
      var child = document.body.children[i];
      if (/^(SCRIPT|STYLE|LINK)$/.test(child.tagName) || /^dgbf-work-in-progress/.test(child.id || '')
          || /dgbf-block-veil/.test(child.className)) {
        continue;
      }
      items.push(child);
    }
    return items;
  }

  function setInert(block, inert) {
    block.targets.forEach(function (target) {
      if (inert) {
        target.setAttribute('inert', '');
        target.setAttribute('aria-busy', 'true');
      } else {
        target.removeAttribute('inert');
        target.removeAttribute('aria-busy');
      }
    });
  }

  function placeVeil(block) {
    if (!block.veil) {
      return;
    }
    var left = 0, top = 0, right = window.innerWidth, bottom = window.innerHeight;
    if (block.zone) {
      var zone = document.getElementById(block.zoneId) || block.zone;
      var rect = zone.getBoundingClientRect();
      left = Math.max(left, rect.left);
      top = Math.max(top, rect.top);
      right = Math.min(right, rect.right);
      bottom = Math.min(bottom, rect.bottom);
    }
    block.veil.style.left = left + 'px';
    block.veil.style.top = top + 'px';
    block.veil.style.width = Math.max(0, right - left) + 'px';
    block.veil.style.height = Math.max(0, bottom - top) + 'px';
  }

  function showVeil(block) {
    block.showTimer = null;
    block.shownAt = Date.now();
    var veil = document.createElement('div');
    veil.className = 'dgbf-block-veil';
    veil.setAttribute('aria-hidden', 'true');
    veil.innerHTML = '<div class="dgbf-block-veil-card"><span class="dgbf-block-veil-text"></span>'
        + '<span class="dgbf-block-veil-bar"></span></div>';
    veil.querySelector('.dgbf-block-veil-text').textContent = block.text;
    document.body.appendChild(veil);
    block.veil = veil;
    block.onMove = function () { placeVeil(block); };
    window.addEventListener('scroll', block.onMove, true);
    window.addEventListener('resize', block.onMove);
    placeVeil(block);
    blockText = block.text;
    toggle(true);
    block.longTimer = setTimeout(function () {
      block.longTimer = null;
      if (block.veil) {
        blockText = block.text + ' ' + LONG_WAIT_TEXT;
        block.veil.querySelector('.dgbf-block-veil-text').textContent = blockText;
        toggle(true);
        placeVeil(block);
      }
    }, LONG_WAIT - SHOW_DELAY);
  }

  function release(block) {
    if (block.released) {
      return;
    }
    block.released = true;
    if (block.longTimer) {
      clearTimeout(block.longTimer);
    }
    if (block.veil) {
      window.removeEventListener('scroll', block.onMove, true);
      window.removeEventListener('resize', block.onMove);
      block.veil.parentNode.removeChild(block.veil);
      block.veil = null;
    }
    // La zone a pu etre remplacee par une mise a jour : on la retrouve par son identifiant.
    if (block.zoneId) {
      var current = document.getElementById(block.zoneId);
      if (current && block.targets.indexOf(current) < 0) {
        block.targets.push(current);
      }
    }
    setInert(block, false);
    blocks.splice(blocks.indexOf(block), 1);
    if (!blocks.length) {
      blockText = null;
      if (!showTimer && !shownAt) {
        toggle(false);
      }
    }
    restoreFocus(block.sourceId, 10);
  }

  // PrimeFaces reactive le bouton apres l'evenement de fin : on reessaie brievement jusqu'a ce qu'il accepte le focus.
  function restoreFocus(sourceId, attempts) {
    var button = sourceId && document.getElementById(sourceId);
    var current = document.activeElement;
    if (!button || (current && current !== document.body)) {
      return;
    }
    button.focus();
    if (document.activeElement !== button && attempts > 0) {
      setTimeout(function () { restoreFocus(sourceId, attempts - 1); }, 50);
    }
  }

  function onSend(settings) {
    var sourceId = window.PrimeFaces && PrimeFaces.ajax.Utils.getSourceId(settings);
    var source = sourceId && document.getElementById(sourceId);
    var marker = source && source.closest('.' + BLOCK_CLASS);
    if (!marker) {
      return;
    }
    var zone = marker.classList.contains(BLOCK_PAGE_CLASS) ? null : marker.closest('form');
    var label = (marker.getAttribute('title') || marker.textContent || '').replace(/\s+/g, ' ').trim();
    var block = {
      settings: settings, sourceId: sourceId, zone: zone, zoneId: zone && zone.id,
      targets: zone ? [zone] : pageElements(),
      text: label ? label + BLOCK_SUFFIX : BLOCK_DEFAULT_TEXT,
      shownAt: 0, released: false
    };
    blocks.push(block);
    setInert(block, true);
    block.showTimer = setTimeout(function () { showVeil(block); }, SHOW_DELAY);
  }

  function onComplete(settings) {
    var block = null;
    for (var i = 0; i < blocks.length; i++) {
      if (blocks[i].settings === settings) {
        block = blocks[i];
        break;
      }
    }
    if (!block) {
      return;
    }
    if (block.showTimer) {
      // Requete plus rapide que le delai : aucun voile n'a ete montre.
      clearTimeout(block.showTimer);
      block.showTimer = null;
      release(block);
      return;
    }
    setTimeout(function () { release(block); }, Math.max(0, MIN_VISIBLE - (Date.now() - block.shownAt)));
  }

  if (window.jQuery) {
    jQuery(document)
      .on('pfAjaxSend', function (event, xhr, settings) { onSend(settings); })
      .on('pfAjaxComplete', function (event, xhr, settings) { onComplete(settings); });
  }

  return { start: start, stop: stop };
})();
