package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une source de financement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FundingSourceDto extends AbstractIdentifiableCodableNamableAuditableDto {
  
  /**
   * Identifiant json de identifiant de {@link FundingSourceDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSourceFinancement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FundingSourceDto}.
   */
  public static final String JSON_THIS_AS_STRING = "sourceFinancementChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "source de financement";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sources de financement";
}
