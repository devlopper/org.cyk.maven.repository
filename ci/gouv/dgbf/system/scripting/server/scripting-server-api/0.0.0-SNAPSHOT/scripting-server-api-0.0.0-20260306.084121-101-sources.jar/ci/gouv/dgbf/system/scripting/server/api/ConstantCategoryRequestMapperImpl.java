package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ConstantCategoryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ConstantCategoryRequestMapperImpl implements ConstantCategoryRequestMapper {

    @Override
    public ConstantCategoryService.ConstantCategoryCreateRequestDto mapCreate(ConstantCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantCategoryService.ConstantCategoryCreateRequestDto constantCategoryCreateRequestDto = new ConstantCategoryService.ConstantCategoryCreateRequestDto();

        constantCategoryCreateRequestDto.setCode( arg0.getCode() );
        constantCategoryCreateRequestDto.setName( arg0.getName() );
        constantCategoryCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        constantCategoryCreateRequestDto.setDefaultConstantIdentifier( arg0.getDefaultConstantIdentifier() );

        return constantCategoryCreateRequestDto;
    }

    @Override
    public ConstantCategoryService.ConstantCategoryUpdateRequestDto mapUpdate(ConstantCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantCategoryService.ConstantCategoryUpdateRequestDto constantCategoryUpdateRequestDto = new ConstantCategoryService.ConstantCategoryUpdateRequestDto();

        constantCategoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        constantCategoryUpdateRequestDto.setCode( arg0.getCode() );
        constantCategoryUpdateRequestDto.setName( arg0.getName() );
        constantCategoryUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        constantCategoryUpdateRequestDto.setDefaultConstantIdentifier( arg0.getDefaultConstantIdentifier() );

        return constantCategoryUpdateRequestDto;
    }
}
