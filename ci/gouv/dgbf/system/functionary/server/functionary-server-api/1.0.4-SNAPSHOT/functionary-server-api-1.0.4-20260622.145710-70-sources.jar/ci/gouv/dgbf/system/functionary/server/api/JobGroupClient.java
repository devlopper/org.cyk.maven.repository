package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupGetManyResponseDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link JobGroupService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class JobGroupClient extends AbstractClient<JobGroupService>
    implements GetByIdentifier<JobGroupDto>, GetMany<JobGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public JobGroupClient service(JobGroupService service) {
    return (JobGroupClient) super.service(service);
  }

  /**
   * {@link JobGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(JobGroupCreateRequestDto request) {
    return new CreateExecutor(JobGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link JobGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public JobGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<JobGroupGetManyResponseDto>(JobGroupGetManyResponseDto.class,
        JobGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }


  /**
   * {@link JobGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public JobGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link JobGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public JobGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<JobGroupDto>(JobGroupDto.class,
        JobGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link JobGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public JobGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link JobGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public JobGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<JobGroupDto>(JobGroupDto.class,
        JobGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link JobGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public JobGroupDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link JobGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(JobGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(JobGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link JobGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(JobGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link JobGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
