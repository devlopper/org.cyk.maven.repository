package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToInputN1 {

  /**
   * Obtient le montant total à saisir pour l'année N+1.
   *
   * @return le montant total à saisir pour l'année N+1
   */
  Long getTotalAmountToInputN1();

  /**
   * Définit le montant total à saisir pour l'année N+1.
   *
   * @param totalAmountToInputN1 le montant total à saisir pour l'année N+1
   */
  void setTotalAmountToInputN1(Long totalAmountToInputN1);

  /**
   * Identifiant java du montant total à saisir pour l'année N+1.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N1 = "totalAmountToInputN1";
}