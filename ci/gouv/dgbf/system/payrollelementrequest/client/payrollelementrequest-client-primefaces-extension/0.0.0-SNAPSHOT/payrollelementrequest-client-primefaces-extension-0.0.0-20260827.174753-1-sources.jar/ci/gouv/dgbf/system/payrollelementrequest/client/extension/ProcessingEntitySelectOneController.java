package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ProcessingEntityDto}.
 *
 * @author akm
 *
 */
@Dependent
public class ProcessingEntitySelectOneController extends AbstractSelectOneIdentifiableController<
    ProcessingEntityDto, ProcessingEntityGetManyResponseDto, ProcessingEntityClient> {

  @Getter
  @Inject
  ProcessingEntityClient client;

  protected ProcessingEntitySelectOneController() {
    super(ProcessingEntityDto.class, SelectItemLabelStrategy.NAME);
  }
}
