package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BeneficiaryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-15T08:26:02+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BeneficiaryRequestMapperImpl implements BeneficiaryRequestMapper {

    @Override
    public BeneficiaryService.BeneficiaryCreateRequestDto mapCreate(BeneficiaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BeneficiaryService.BeneficiaryCreateRequestDto beneficiaryCreateRequestDto = new BeneficiaryService.BeneficiaryCreateRequestDto();

        beneficiaryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        beneficiaryCreateRequestDto.setCode( arg0.getCode() );
        beneficiaryCreateRequestDto.setName( arg0.getName() );
        beneficiaryCreateRequestDto.setBankAccountDetails( arg0.getBankAccountDetails() );
        beneficiaryCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        beneficiaryCreateRequestDto.setSupportingDocument( arg0.getSupportingDocument() );
        beneficiaryCreateRequestDto.setPersonType( arg0.getPersonType() );

        return beneficiaryCreateRequestDto;
    }

    @Override
    public BeneficiaryService.BeneficiaryUpdateRequestDto mapUpdate(BeneficiaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BeneficiaryService.BeneficiaryUpdateRequestDto beneficiaryUpdateRequestDto = new BeneficiaryService.BeneficiaryUpdateRequestDto();

        beneficiaryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        beneficiaryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        beneficiaryUpdateRequestDto.setCode( arg0.getCode() );
        beneficiaryUpdateRequestDto.setName( arg0.getName() );
        beneficiaryUpdateRequestDto.setBankAccountDetails( arg0.getBankAccountDetails() );
        beneficiaryUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        beneficiaryUpdateRequestDto.setSupportingDocument( arg0.getSupportingDocument() );
        beneficiaryUpdateRequestDto.setPersonType( arg0.getPersonType() );

        return beneficiaryUpdateRequestDto;
    }
}
