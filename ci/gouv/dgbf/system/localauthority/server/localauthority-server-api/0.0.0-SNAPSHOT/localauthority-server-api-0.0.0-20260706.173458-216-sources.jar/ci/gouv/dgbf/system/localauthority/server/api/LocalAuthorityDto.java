package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une unité administrative.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class LocalAuthorityDto extends AbstractIdentifiableCodableNamableDto {

  @JsonbProperty(JSON_CREATABLE_TRIENNIAL_PROGRAM_EXERCISE_IDENTIFIER)
  private String creatableTriennialProgramExerciseIdentifier;

  @JsonbProperty(JSON_CREATABLE_TRIENNIAL_PROGRAM_EXERCISE_YEAR)
  private Integer creatableTriennialProgramExerciseYear;

  /**
   * Identifiant json de identifiant de {@link LocalAuthorityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCollectivite";

  /**
   * Identifiant json de code de {@link LocalAuthorityDto}.
   */
  public static final String JSON_THIS_CODE = "codeCollectivite";
  
  /**
   * Identifiant json de représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "collectiviteChaine";

  /**
   * Identifiant json de {@link #creatableTriennialProgramExerciseIdentifier}.
   */
  public static final String JSON_CREATABLE_TRIENNIAL_PROGRAM_EXERCISE_IDENTIFIER =
      "idExerciceProgrammeTriennalCreable";

  /**
   * Identifiant json de {@link #creatableTriennialProgramExerciseYear}.
   */
  public static final String JSON_CREATABLE_TRIENNIAL_PROGRAM_EXERCISE_YEAR =
      "anneeExerciceProgrammeTriennalCreable";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "collectivité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
