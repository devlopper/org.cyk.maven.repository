package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N.
 *
 * @author Christian
 */
public interface HasTotalAmountToIntegrateN {

  /**
   * Obtient le montant total à intégrer pour l'année N.
   *
   * @return le montant total à intégrer pour l'année N
   */
  Long getTotalAmountToIntegrateN();

  /**
   * Définit le montant total à intégrer pour l'année N.
   *
   * @param totalAmountToIntegrateN le montant total à intégrer pour l'année N
   */
  void setTotalAmountToIntegrateN(Long totalAmountToIntegrateN);

  /**
   * Identifiant java du montant total à intégrer pour l'année N.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N = "totalAmountToIntegrateN";
}