package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rôle.
 *
 * @author Arnaud
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RoleDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasUserCountDto, HasUserCountAsStringDto, HasPendingRoleSolicitationCountDto,
    HasPendingRoleSolicitationCountAsStringDto {

  /**
   * Nombre d'Utilisateurs détenant le Rôle (RU_UTI_027).
   */
  @JsonbProperty(JSON_USER_COUNT)
  private Integer userCount;

  /**
   * Représentation en chaîne de caractères de {@link #userCount}.
   */
  @JsonbProperty(JSON_USER_COUNT_AS_STRING)
  private String userCountAsString;

  /**
   * Nombre de demandes en attente (statut Créée) sur le Rôle (RU_UTI_027).
   */
  @JsonbProperty(JSON_PENDING_ROLE_SOLICITATION_COUNT)
  private Integer pendingRoleSolicitationCount;

  /**
   * Représentation en chaîne de caractères de {@link #pendingRoleSolicitationCount}.
   */
  @JsonbProperty(JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING)
  private String pendingRoleSolicitationCountAsString;


  @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
  private String applicationIdentifier;

  @JsonbProperty(JSON_APPLICATION_AS_STRING)
  private String applicationAsString;

  /**
   * Code de l'Application du Rôle : décide des boutons de la ligne (Droits par Application).
   */
  @JsonbProperty(JSON_APPLICATION_CODE)
  private String applicationCode;

  /**
   * Code du Domaine de l'Application du Rôle : décide des boutons de la ligne.
   */
  @JsonbProperty(JSON_DOMAIN_CODE)
  private String domainCode;

  /**
   * Description.
   */
  @JsonbProperty(value = JSON_DESCRIPTION)
  private String description;

  /**
   * Nature du Rôle (RG_UTI_ROL_18) : applicatif ou métier.
   */
  @JsonbProperty(JSON_NATURE)
  private RoleNature nature;

  /**
   * Indicateur Oui/Non (Demandable) : le Rôle peut être sélectionné dans une Demande de rôle
   * (RG_UTI_ROL_20). Toujours Faux pour un Rôle réservé.
   */
  @JsonbProperty(JSON_REQUESTABLE)
  private Boolean requestable;

  /**
   * Identifiants des Rôles composants, si ce Rôle est de Nature métier (RG_UTI_ROL_19).
   * Renseigné seulement par une projection qui le demande (absent des lignes de liste).
   */
  @JsonbProperty(JSON_COMPONENT_IDENTIFIERS)
  private List<String> componentIdentifiers;

  /**
   * Libellés des Rôles composants, dans le même ordre que {@link #componentIdentifiers}.
   */
  @JsonbProperty(JSON_COMPONENT_NAMES)
  private List<String> componentNames;

  /**
   * Cette méthode permet d'obtenir {@link #componentNames} concaténés pour l'affichage en
   * liste.
   *
   * @return libellés des composants concaténés, chaîne vide si aucun
   */
  public String getComponentNamesAsString() {
    return componentNames == null ? "" : String.join(", ", componentNames);
  }

  /**
   * Identifiant de l'utilisateur pour les rôles NON assignés à cet utilisateur.
   * Utilisé pour obtenir les rôles disponibles pour attribution.
   */
  @JsonbProperty(value = JSON_UNASSIGNED_USER_IDENTIFIER)
  private String unassignedUserIdentifier;

  /**
   * Identifiant de l'utilisateur pour les rôles assignés à cet utilisateur.
   * Utilisé pour obtenir les rôles actuels de l'utilisateur.
   */
  @JsonbProperty(value = JSON_ASSIGNED_USER_IDENTIFIER)
  private String assignedUserIdentifier;

  /**
   * Identifiant json champ {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #requestable} (Demandable, terme métier français).
   */
  public static final String JSON_REQUESTABLE = "demandable";

  /**
   * Identifiant json {@link #componentIdentifiers}.
   */
  public static final String JSON_COMPONENT_IDENTIFIERS = "idComposants";

  /**
   * Identifiant json {@link #componentNames}.
   */
  public static final String JSON_COMPONENT_NAMES = "nomsComposants";

  /**
   * Identifiant json {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = ApplicationDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #applicationAsString}.
   */
  public static final String JSON_APPLICATION_AS_STRING = ApplicationDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #applicationCode}.
   */
  public static final String JSON_APPLICATION_CODE = "codeApplication";

  /**
   * Identifiant json {@link #domainCode}.
   */
  public static final String JSON_DOMAIN_CODE = ApplicationDto.JSON_DOMAIN_CODE;

  /**
   * Identifiant json {@link #unassignedUserIdentifier}.
   */
  public static final String JSON_UNASSIGNED_USER_IDENTIFIER = "idUtilisateurNonAssigne";

  /**
   * Identifiant json {@link #assignedUserIdentifier}.
   */
  public static final String JSON_ASSIGNED_USER_IDENTIFIER = "idUtilisateurAssigne";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRole";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "roleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "role";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
