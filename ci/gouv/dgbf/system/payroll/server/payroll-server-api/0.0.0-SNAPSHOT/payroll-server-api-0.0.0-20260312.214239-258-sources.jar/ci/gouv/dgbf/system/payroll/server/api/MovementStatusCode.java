package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette classe représente les codes de {@link MovementStatus}.
 *
 * @author stephane
 *
 */
public class MovementStatusCode {

  private MovementStatusCode() {

  }

  /**
   * Projeté.
   */
  public static final String PROJECTED = "PROJETE";

  /**
   * Activé.
   */
  public static final String ACTIVATED = "ACTIVE";

  /**
   * Proposé.
   */
  public static final String SUGGESTED = "PROPOSE";

  /**
   * Refusé.
   */
  public static final String REFUSED = "REFUSE";

  /**
   * Clôturée.
   */
  public static final String CLOSED = "CLOTUREE";
}
