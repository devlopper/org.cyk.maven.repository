package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un équipement.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DeviceDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Marque.
   */
  @JsonbProperty(value = JSON_BRAND)
  private String brand;

  /**
   * Identifiant json champ {@link #brand}.
   */
  public static final String JSON_BRAND = "brand";

  /**
   * Modèle.
   */
  @JsonbProperty(value = JSON_MODEL)
  private String model;

  /**
   * Identifiant json champ {@link #model}.
   */
  public static final String JSON_MODEL = "model";

  /**
   * Système d'exploitation.
   */
  @JsonbProperty(value = JSON_OPERATING_SYSTEM)
  private String operatingSystem;

  /**
   * Identifiant json champ {@link #operatingSystem}.
   */
  public static final String JSON_OPERATING_SYSTEM = "operatingSystem";

  /**
   * Imei.
   */
  @JsonbProperty(value = JSON_IMEI)
  private String imei;

  /**
   * Identifiant json champ {@link #imei}.
   */
  public static final String JSON_IMEI = "imei";


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEquipement";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "equipementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "equipement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
