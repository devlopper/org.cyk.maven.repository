package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un statut de la fonction publique.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class CivilServiceStatusDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Représentation en chaine de caractères du nombre de {@link CategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_COUNT_AS_STRING)
  private String categoryCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de {@link GradeClassDto}.
   */
  @JsonbProperty(JSON_GRADE_CLASS_COUNT_AS_STRING)
  private String gradeClassCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de {@link EchelonDto}.
   */
  @JsonbProperty(JSON_ECHELON_COUNT_AS_STRING)
  private String echelonCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de {@link PayScaleDto}.
   */
  @JsonbProperty(JSON_PAYSCALE_COUNT_AS_STRING)
  private String payScaleCountAsString;

  /**
   * Identifiant JSON de {@link #categoryCountAsString}.
   */
  public static final String JSON_CATEGORY_COUNT_AS_STRING = "nombreCategorieChaine";

  /**
   * Identifiant JSON de {@link #gradeClassCountAsString}.
   */
  public static final String JSON_GRADE_CLASS_COUNT_AS_STRING = "nombreClasseChaine";

  /**
   * Identifiant JSON de {@link #echelonCountAsString}.
   */
  public static final String JSON_ECHELON_COUNT_AS_STRING = "nombreEchelonChaine";

  /**
   * Identifiant JSON de {@link #payScaleCountAsString}.
   */
  public static final String JSON_PAYSCALE_COUNT_AS_STRING = "nombreGrilleIndiciaireChaine";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idStatutFonctionPublique";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "statutFonctionPubliqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "Statut de la fonction publique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "Statuts de la fonction publique";
  
}
