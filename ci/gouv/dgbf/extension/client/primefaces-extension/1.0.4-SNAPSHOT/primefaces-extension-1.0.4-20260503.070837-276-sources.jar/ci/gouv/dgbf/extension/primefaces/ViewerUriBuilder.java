package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ConfigurationHelper;
import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.core.UriBuilder;
import ci.gouv.dgbf.extension.core.UriQueryBuilder;
import ci.gouv.dgbf.extension.environment.Environment;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import java.net.URI;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un constructeur d'URI de visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerUriBuilder {
  private static final Logger LOGGER = Logger.getLogger(ViewerUriBuilder.class.getName());

  String host;

  Integer port;

  String path;

  String file;

  @Inject
  StringHelper stringHelper;

  @Inject
  ConfigurationHelper configurationHelper;

  @Getter
  @Setter
  String customisableParameterName = "personnalisable";

  @Getter
  @Setter
  String servletPath = "viewer";

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param identifier identifiant
   */
  public void initialize(String identifier) {
    host = configurationHelper.getValue(String.class,
        buildConfigurationPropertyName(identifier, "host"), Environment.getCurrent().getHost());
    port = configurationHelper.getValue(Integer.class,
        buildConfigurationPropertyName(identifier, "port"), Environment.getCurrent().getPort());
    FacesContext facesContext = FacesContext.getCurrentInstance();
    path = configurationHelper.getValue(String.class,
        buildConfigurationPropertyName(identifier, "path"),
        facesContext.getExternalContext().getRequestContextPath());
    file = configurationHelper.getValue(String.class,
        buildConfigurationPropertyName(identifier, "file"), "visualisateur.xhtml");
  }

  /**
   * Cette méthode permet de construire l'URI du visualisateur.
   *
   * @return URI
   */
  public URI build(Parameters parameters) {
    validate(parameters);
    UriBuilder uriBuilder = new UriBuilder();
    uriBuilder.host(host).port(port);
    uriBuilder.pathBuilder().list().add(path);
    uriBuilder.queryBuilder(parameters.queryBuilder);
    uriBuilder.queryBuilder().map().add(AbstractRequestDto.JSON_AUDIT_WHO, parameters.auditWho);
    uriBuilder.queryBuilder().map().add(AbstractAuditedRequestJsonDto.JSON_AUDIT_SESSION,
        parameters.auditSession);
    customise(parameters, uriBuilder);
    URI uri = uriBuilder.build();
    LOGGER.log(Level.FINER, "Uri du visualisateur construit. {0}", uri);
    return uri;
  }

  void validate(Parameters parameters) {
    if (parameters == null) {
      throw new IllegalArgumentException("Les paramètres sont obligatoires");
    }
  }
  
  void customise(Parameters parameters, UriBuilder uriBuilder) {
    if (parameters.customisable) {
      uriBuilder.pathBuilder().list().add(file);
      uriBuilder.queryBuilder().map().add(customisableParameterName, Boolean.TRUE.toString());
    } else {
      uriBuilder.pathBuilder().list().add(servletPath);
    }
  }

  static String buildConfigurationPropertyName(String identifier, String value) {
    return String.format("%s.%s", String.format("dgbf.system.%s.viewer", identifier), value);
  }

  /**
   * Cette classe représente les paramètres.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Parameters {

    UriQueryBuilder queryBuilder = new UriQueryBuilder();

    String auditWho;

    String auditSession;

    boolean customisable;
  }
}
