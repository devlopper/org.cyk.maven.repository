package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasFunctionaryRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FurPeriodLineDto}. Implémente
 * {@link FilterHasFunctionaryRegistrationNumber} pour une recherche par matricule.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FurPeriodLineFilter extends AbstractIdentifiableFilter
    implements FilterHasFunctionaryRegistrationNumber {

  /**
   * Matricule.
   */
  String functionaryRegistrationNumber;

  /**
   * Premier jour du mois de la période.
   */
  LocalDate period;

  /**
   * Type de FUR, {@code null} pour tous.
   */
  String furType;

  /**
   * Code pièce, {@code null} pour tous.
   */
  String piece;

  /**
   * Statut de traitement de la ligne ({@link #STATUS_GENERATED}, {@link #STATUS_TO_GENERATE} ou
   * {@link #STATUS_BLOCKED}), {@code null} pour toutes.
   */
  String generationStatus;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FurPeriodLineFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FurPeriodLineFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    period = getPeriod(filter);
    furType = getFurType(filter);
    piece = getPiece(filter);
    generationStatus = getGenerationStatus(filter);
    updateFunctionaryRegistrationNumber(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setPeriod(filter, period);
    setFurType(filter, furType);
    setPiece(filter, piece);
    setGenerationStatus(filter, generationStatus);
    updateFilterFunctionaryRegistrationNumber(filter);
  }

  /**
   * Cette méthode permet d'assigner la période.
   *
   * @param filter filtre
   * @param period premier jour du mois de la période
   */
  public static void setPeriod(FilterDto filter, LocalDate period) {
    set(filter, JSON_PERIOD, f -> f.getValueAsDate(), f -> f.setValueAsDate(period));
  }

  /**
   * Cette méthode permet d'obtenir la période.
   *
   * @param filter filtre
   * @return premier jour du mois de la période
   */
  public static LocalDate getPeriod(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsDateByName(JSON_PERIOD));
  }

  /**
   * Cette méthode permet d'assigner le type de FUR.
   *
   * @param filter filtre
   * @param furType type de FUR
   */
  public static void setFurType(FilterDto filter, String furType) {
    set(filter, JSON_FUR_TYPE, f -> f.getValueAsString(), f -> f.setValueAsString(furType));
  }

  /**
   * Cette méthode permet d'obtenir le type de FUR.
   *
   * @param filter filtre
   * @return type de FUR
   */
  public static String getFurType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUR_TYPE));
  }

  /**
   * Cette méthode permet d'assigner le code pièce.
   *
   * @param filter filtre
   * @param piece code pièce
   */
  public static void setPiece(FilterDto filter, String piece) {
    set(filter, JSON_PIECE, f -> f.getValueAsString(), f -> f.setValueAsString(piece));
  }

  /**
   * Cette méthode permet d'obtenir le code pièce.
   *
   * @param filter filtre
   * @return code pièce
   */
  public static String getPiece(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PIECE));
  }

  /**
   * Cette méthode permet d'assigner le statut de traitement.
   *
   * @param filter filtre
   * @param generationStatus statut de traitement
   */
  public static void setGenerationStatus(FilterDto filter, String generationStatus) {
    set(filter, JSON_GENERATION_STATUS, f -> f.getValueAsString(),
        f -> f.setValueAsString(generationStatus));
  }

  /**
   * Cette méthode permet d'obtenir le statut de traitement.
   *
   * @param filter filtre
   * @return statut de traitement
   */
  public static String getGenerationStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GENERATION_STATUS));
  }

  /**
   * Identifiant json champ {@link #period}.
   */
  public static final String JSON_PERIOD = FurPeriodLineDto.JSON_PERIOD;

  /**
   * Identifiant json champ {@link #furType}.
   */
  public static final String JSON_FUR_TYPE = FurPeriodLineDto.JSON_FUR_TYPE;

  /**
   * Identifiant json champ {@link #piece}.
   */
  public static final String JSON_PIECE = FurPeriodLineDto.JSON_PIECE;

  /**
   * Identifiant json champ {@link #generationStatus}.
   */
  public static final String JSON_GENERATION_STATUS = "statutGeneration";

  /**
   * Valeur {@link #generationStatus} des lignes ayant produit une réclamation.
   */
  public static final String STATUS_GENERATED = "GENEREE";

  /**
   * Valeur {@link #generationStatus} des lignes sans réclamation, en attente normale de
   * traitement (aucun problème).
   */
  public static final String STATUS_TO_GENERATE = "A_GENERER";

  /**
   * Valeur {@link #generationStatus} des lignes sans réclamation réellement bloquées par un
   * conflit métier.
   */
  public static final String STATUS_BLOCKED = "EN_ERREUR";
}
