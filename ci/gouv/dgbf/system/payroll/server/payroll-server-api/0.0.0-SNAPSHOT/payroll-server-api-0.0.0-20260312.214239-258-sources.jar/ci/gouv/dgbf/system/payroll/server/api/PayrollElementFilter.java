package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de la source de valeur.
   */
  String valueSourceIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    valueSourceIdentifier = getValueSourceIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setValueSourceIdentifier(filter, valueSourceIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la source de valeur.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setValueSourceIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_VALUE_SOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la source de valeur.
   *
   * @param filter filtre
   * @return identifiant de la source de valeur
   */
  public static String getValueSourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_VALUE_SOURCE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link PayrollElementFilter#valueSourceIdentifier}.
   */
  public static final String JSON_VALUE_SOURCE_IDENTIFIER =
          PayrollElementDto.JSON_VALUE_SOURCE_IDENTIFIER;

}
