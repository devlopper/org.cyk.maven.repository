package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEnabledDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTemplateIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTypeIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RemunerableDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = RemunerableService.PATH)
@Tag(name = "Gestion des rémunérables")
public interface RemunerableService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "remunerables";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface RemunerableSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionaryDto}.
     *
     * @return identifiant {@link FunctionaryDto}
     */
    String getFunctionaryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionaryDto}.
     *
     * @param identifier identifiant {@link FunctionaryDto}
     */
    void setFunctionaryIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipTypeDto}.
     *
     * @return identifiant {@link PayslipTypeDto}
     */
    String getPayslipTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipTypeDto}.
     *
     * @param identifier identifiant {@link PayslipTypeDto}
     */
    void setPayslipTypeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipTemplateDto}.
     *
     * @return identifiant {@link PayslipTemplateDto}
     */
    String getPayslipTemplateIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipTemplateDto}.
     *
     * @param identifier identifiant {@link PayslipTemplateDto}
     */
    void setPayslipTemplateIdentifier(String identifier);

    /**
     * Cette méthode permet d'obténir vrai si c'est activé sinon faux.
     *
     * @return vrai si c'est activé sinon faux
     */
    Boolean getIsEnabled();

    /**
     * Cette méthode permet d'assigner vrai si c'est activé sinon faux.
     *
     * @param isEnabled vrai si c'est activé sinon faux
     */
    void setIsEnabled(Boolean isEnabled);


    /**
     * {@link HasFunctionaryIdentifierDto#JSON_FUNCTIONARY_IDENTIFIER}.
     */
    public static final String JSON_FUNCTIONARY_IDENTIFIER =
        HasFunctionaryIdentifierDto.JSON_FUNCTIONARY_IDENTIFIER;

    /**
     * {@link HasPayslipTypeIdentifierDto#JSON_PAYSLIP_TYPE_IDENTIFIER}.
     */
    public static final String JSON_PAYSLIP_TYPE_IDENTIFIER =
        HasPayslipTypeIdentifierDto.JSON_PAYSLIP_TYPE_IDENTIFIER;

    /**
     * {@link HasPayslipTemplateIdentifierDto#JSON_PAYSLIP_TEMPLATE_IDENTIFIER}.
     */
    public static final String JSON_PAYSLIP_TEMPLATE_IDENTIFIER =
        HasPayslipTemplateIdentifierDto.JSON_PAYSLIP_TEMPLATE_IDENTIFIER;

    /**
     * {@link HasIsEnabledDto#JSON_IS_ENABLED}.
     */
    public static final String JSON_IS_ENABLED = HasIsEnabledDto.JSON_IS_ENABLED;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_REMUNERABLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RemunerableCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class RemunerableCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements RemunerableSaveRequestDto {

    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    private String functionaryIdentifier;

    @JsonbProperty(JSON_PAYSLIP_TYPE_IDENTIFIER)
    private String payslipTypeIdentifier;
    
    @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
    private String payslipTemplateIdentifier;

    @JsonbProperty(JSON_IS_ENABLED)
    private Boolean isEnabled;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REMUNERABLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RemunerableGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class RemunerableGetManyResponseDto
      extends AbstractGetByPageResponseDto<RemunerableDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RemunerableDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_REMUNERABLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RemunerableDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REMUNERABLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RemunerableDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_REMUNERABLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RemunerableUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class RemunerableUpdateRequestDto extends ByIdentifierRequestDto
      implements RemunerableSaveRequestDto {

    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    private String functionaryIdentifier;

    @JsonbProperty(JSON_PAYSLIP_TYPE_IDENTIFIER)
    private String payslipTypeIdentifier;
    
    @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
    private String payslipTemplateIdentifier;

    @JsonbProperty(JSON_IS_ENABLED)
    private Boolean isEnabled;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_REMUNERABLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link RemunerableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
