package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ExpectedEffectService.ExpectedEffectCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ExpectedEffectService.ExpectedEffectGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ExpectedEffectService.ExpectedEffectUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ExpectedEffectService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ExpectedEffectClient extends AbstractClient<ExpectedEffectService>
    implements GetByIdentifier<ExpectedEffectDto>, GetMany<ExpectedEffectGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ExpectedEffectClient service(ExpectedEffectService service) {
    return (ExpectedEffectClient) super.service(service);
  }

  /**
   * {@link ExpectedEffectService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpectedEffectGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ExpectedEffectGetManyResponseDto>(
        ExpectedEffectGetManyResponseDto.class, ExpectedEffectService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ExpectedEffectService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpectedEffectGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ExpectedEffectService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ExpectedEffectCreateRequestDto request) {
    return new CreateExecutor(ExpectedEffectService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ExpectedEffectService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ExpectedEffectUpdateRequestDto request) {
    return new IdentifiableExecutor(ExpectedEffectService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ExpectedEffectService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ExpectedEffectDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ExpectedEffectDto>(ExpectedEffectDto.class,
        ExpectedEffectService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ExpectedEffectService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ExpectedEffectDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ExpectedEffectService#getByIdentifier}.
   *
   * @param request requête
   * @return effet attendu
   */
  public ExpectedEffectDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ExpectedEffectDto>(ExpectedEffectDto.class,
        ExpectedEffectService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ExpectedEffectService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpectedEffectDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ExpectedEffectService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ExpectedEffectService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ExpectedEffectService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
