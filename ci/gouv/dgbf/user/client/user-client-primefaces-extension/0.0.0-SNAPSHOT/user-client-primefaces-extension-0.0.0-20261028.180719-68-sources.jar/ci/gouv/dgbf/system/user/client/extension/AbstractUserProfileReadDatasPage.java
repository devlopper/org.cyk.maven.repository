package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.AbstractFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.ApplicationClient;
import ci.gouv.dgbf.system.user.server.api.ApplicationFilter;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages du profil de l'utilisateur connecté.
 *
 * @author BoobaCool
 */
public abstract class AbstractUserProfileReadDatasPage extends AbstractPage {

  @Inject
  UserClient client;

  @Getter
  UserDto user;

  @Inject
  ApplicationClient applicationClient;

  @Inject
  RoleClient roleClient;

  @Getter
  Long applicationCount;

  @Getter
  Long roleCount;

  @Getter
  Long administeredApplicationCount;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Mon profil";

    GetOneRequestDto request = new GetOneRequestDto();
    UserFilter filter = new UserFilter();
    filter.setName(userIdentifier);
    request.useFilter(filter);
    request.projection().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING,
        UserDto.JSON_DOMAIN_AS_STRING,
        UserDto.JSON_ACCOUNT_EXISTS);
    request.setAuditWho(userIdentifier);
    user = client.getOne(request);
    if (user == null) {
      return;
    }

    ApplicationFilter applications = new ApplicationFilter();
    applications.setUserName(user.getName());
    applicationCount = readTotal(applicationClient, applications);

    RoleFilter roles = new RoleFilter();
    roles.setAssignedUserIdentifier(user.getIdentifier());
    roleCount = readTotal(roleClient, roles);

    ApplicationFilter administeredApplications = new ApplicationFilter();
    administeredApplications.setAdministratorUserName(userIdentifier);
    administeredApplications.setUserName(userIdentifier);
    administeredApplicationCount = readTotal(applicationClient, administeredApplications);
  }

  private Long readTotal(GetMany<? extends AbstractGetByPageResponseDto<?>> reader,
      AbstractFilter filter) {
    // Le total est indépendant de la pagination ; une seule clé est chargée par liste.
    AbstractGetByPageResponseDto<?> response = reader.getMany(
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER), filter.toDto(),
        new PageDto(0, 1), userIdentifier, null);
    return response == null ? null : response.getTotal();
  }
}
