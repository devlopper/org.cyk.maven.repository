package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Path(value = ResourceVisibilityLevelService.PATH)
@Tag(name = "Gestion des niveaux de visibilité par défaut des ressources")
public interface ResourceVisibilityLevelService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "ressource-niveau-visibilite";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ResourceVisibilityLevelSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ResourceDto}.
     *
     * @return identifiant de {@link ResourceDto}
     */
    String getResourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ResourceDto}.
     *
     * @param resourceIdentifier identifiant de {@link ResourceDto}
     */
    void setResourceIdentifier(String resourceIdentifier);

    /**
     * Cette méthode permet d'obtenir le {@link VisibilityLevel} par défaut.
     *
     * @return {@link VisibilityLevel}
     */
    VisibilityLevel getVisibilityLevel();

    /**
     * Cette méthode permet d'assigner le {@link VisibilityLevel} par défaut.
     *
     * @param visibilityLevel {@link VisibilityLevel}
     */
    void setVisibilityLevel(VisibilityLevel visibilityLevel);

    /**
     * Identifiant json champ identifiant de {@link ResourceDto}.
     */
    String JSON_RESOURCE_IDENTIFIER = ResourceVisibilityLevelDto.JSON_RESOURCE_IDENTIFIER;

    /**
     * Identifiant json champ {@link VisibilityLevel}.
     */
    String JSON_VISIBILITY_LEVEL = ResourceVisibilityLevelDto.JSON_VISIBILITY_LEVEL;
  }

  /**
   * Cette méthode permet de créer {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'un niveau de visibilité de ressource",
      description = "Ce service permet de définir le niveau de visibilité par défaut "
          + "d'une ressource")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ResourceVisibilityLevelCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ResourceVisibilityLevelCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ResourceVisibilityLevelSaveRequestDto {

    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;

    @JsonbProperty(JSON_VISIBILITY_LEVEL)
    private VisibilityLevel visibilityLevel;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des niveaux de visibilité de ressource")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ResourceVisibilityLevelGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ResourceVisibilityLevelGetManyResponseDto
      extends AbstractGetByPageResponseDto<ResourceVisibilityLevelDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ResourceVisibilityLevelDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un niveau de visibilité de ressource")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ResourceVisibilityLevelDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un niveau de visibilité "
          + "de ressource")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ResourceVisibilityLevelDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un niveau de visibilité de ressource")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ResourceVisibilityLevelUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ResourceVisibilityLevelUpdateRequestDto extends ByIdentifierRequestDto
      implements ResourceVisibilityLevelSaveRequestDto {

    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;

    @JsonbProperty(JSON_VISIBILITY_LEVEL)
    private VisibilityLevel visibilityLevel;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_RESSOURCE_NIVEAU_VISIBILITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ResourceVisibilityLevelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un niveau de visibilité de ressource")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
