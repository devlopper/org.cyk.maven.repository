package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link AccountDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-22T12:57:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class AccountRequestMapperImpl implements AccountRequestMapper {

    @Override
    public AccountService.AccountCreateRequestDto mapCreate(AccountDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AccountService.AccountCreateRequestDto accountCreateRequestDto = new AccountService.AccountCreateRequestDto();

        accountCreateRequestDto.setName( arg0.getName() );
        accountCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        accountCreateRequestDto.setPass( arg0.getPass() );

        return accountCreateRequestDto;
    }

    @Override
    public AccountService.AccountUpdateRequestDto mapUpdate(AccountDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AccountService.AccountUpdateRequestDto accountUpdateRequestDto = new AccountService.AccountUpdateRequestDto();

        accountUpdateRequestDto.setIdentifier( arg0.getIdentifier() );

        return accountUpdateRequestDto;
    }
}
