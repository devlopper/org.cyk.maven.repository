package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TaskDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TaskFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link AdministrativeUnitDto}.
   */
  String administrativeUnitIdentifier;
  
  /**
   * Identifiant de l'unité administrative d'exécution.
   */
  String executionAdministrativeUnitIdentifier;

  /**
   * Identifiant de {@link FolderDto}.
   */
  String folderIdentifier;

  /**
   * Identifiant de {@link ActivityDto}.
   */
  String activityIdentifier;

  /**
   * Identifiant de l'identité.
   */
  String identityIdentifier;

  /**
   * Code du statut du processus.
   */
  String processingStatusCode;

  /**
   * Est en retard.
   */
  Boolean isLate;

  /**
   * Nom d'utilisateur.
   */
  String userName;

  /**
   * Identifiant de l'exercice.
   */
  String exerciseIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TaskFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TaskFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    executionAdministrativeUnitIdentifier = getExecutionAdministrativeUnitIdentifier(filter);
    folderIdentifier = getFolderIdentifier(filter);
    activityIdentifier = getActivityIdentifier(filter);
    identityIdentifier = getIdentityIdentifier(filter);
    processingStatusCode = getProcessingStatusCode(filter);
    isLate = getIsLate(filter);
    userName = getUserName(filter);
    exerciseIdentifier = getExerciseIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setExecutionAdministrativeUnitIdentifier(filter, executionAdministrativeUnitIdentifier);
    setFolderIdentifier(filter, folderIdentifier);
    setActivityIdentifier(filter, activityIdentifier);
    setIdentityIdentifier(filter, identityIdentifier);
    setProcessingStatusCode(filter, processingStatusCode);
    setIsLate(filter, isLate);
    setUserName(filter, userName);
    setExerciseIdentifier(filter, exerciseIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'unité administrative d'exécution.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setExecutionAdministrativeUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité administrative d'exécution.
   *
   * @param filter filtre
   * @return identifiant de l'unité administrative d'exécution
   */
  public static String getExecutionAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FolderDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFolderIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FOLDER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FolderDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FolderDto}
   */
  public static String getFolderIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FOLDER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ActivityDto}
   */
  public static String getActivityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité.
   *
   * @param filter filtre
   * @return identifiant de l'identité
   */
  public static String getIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setIdentityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir le code du statut du processus.
   *
   * @param filter filtre
   * @return le code du statut du processus
   */
  public static String getProcessingStatusCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESSING_STATUS_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code du statut du processus.
   *
   * @param filter filtre
   * @param processingStatusCode le code du statut du processus
   */
  public static void setProcessingStatusCode(FilterDto filter, String processingStatusCode) {
    set(filter, JSON_PROCESSING_STATUS_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(processingStatusCode));
  }

  /**
   * Cette méthode permet d'obtenir est en retard.
   *
   * @param filter filtre
   * @return est en retard
   */
  public static Boolean getIsLate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LATE));
  }

  /**
   * Cette méthode permet d'assigner est en retard.
   *
   * @param filter filtre
   * @param isLate est en retard
   */
  public static void setIsLate(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_LATE, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isLate));
  }

  /**
   * Cette méthode permet d'obtenir le nom d'utilisateur.
   *
   * @param filter filtre
   * @return nom d'utilisateur
   */
  public static String getUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom d'utilisateur.
   *
   * @param filter filtre
   * @param userName nom d'utilisateur
   */
  public static void setUserName(FilterDto filter, String userName) {
    set(filter, JSON_USER_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'exercice.
   *
   * @param filter filtre
   * @return identifiant de l'exercice
   */
  public static String getExerciseIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'exercice.
   *
   * @param filter filtre
   * @param exerciseIdentifier identifiant de l'exercice
   */
  public static void setExerciseIdentifier(FilterDto filter, String exerciseIdentifier) {
    set(filter, JSON_EXERCISE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(exerciseIdentifier));
  }

  /**
   * Identifiant json champ {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      TaskDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #executionAdministrativeUnitIdentifier}.
   */
  public static final String JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER =
      TaskDto.JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #folderIdentifier}.
   */
  public static final String JSON_FOLDER_IDENTIFIER = TaskDto.JSON_FOLDER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = TaskDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #processingStatusCode}.
   */
  public static final String JSON_PROCESSING_STATUS_CODE = TaskDto.JSON_PROCESSING_STATUS_CODE;

  /**
   * Identifiant json champ {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = TaskDto.JSON_IS_LATE;

  /**
   * Identifiant json champ {@link #userName}.
   */
  public static final String JSON_USER_NAME = "nomUtilisateur";

  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = "idExercice";
}
