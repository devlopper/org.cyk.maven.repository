package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link ActivityDto}.
 *
 * @author Christian
 *
 */
public interface ActivityContainerable {

  /*------------------------------- Status Start -----------------------------------*/

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} créé.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} créé
   */
  String getCreatedActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto} démarré.
   *
   * @return nombre {@link ActivityDto} démarré
   */
  Integer getStartedActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} démarré.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} démarré
   */
  String getStartedActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} suspendu.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} suspendu
   */
  String getSuspendedActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} arrêté.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} arrêté
   */
  String getStoppedActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto} réalisé.
   *
   * @return nombre {@link ActivityDto} réalisé
   */
  Integer getRealizedActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} réalisé.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} réalisé
   */
  String getRealizedActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto} en retard.
   *
   * @return nombre {@link ActivityDto} en retard
   */
  Integer getLateActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} en retard.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} en retard
   */
  String getLateActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} non retard.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} non retard
   */
  String getNotLateActivityCountAsString();

  /*------------------------------- Status End -----------------------------------*/

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto}.
   *
   * @return nombre {@link ActivityDto}
   */
  Integer getActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto}.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto}
   */
  String getActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto} en attente de démarrage.
   *
   * @return nombre {@link ActivityDto} en attente de démarrage
   */
  Integer getPendingStartActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} en attente de démarrage.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} en attente de
   *         démarrage
   */
  String getPendingStartActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link ActivityDto} effectuée.
   *
   * @return nombre {@link ActivityDto} effectuée
   */
  Integer getDoneActivityCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} effectuée.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} effectuée
   */
  String getDoneActivityCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link ActivityDto} pas effectuée.
   *
   * @return représentation en chaine de caractères du nombre {@link ActivityDto} pas effectuée
   */
  String getNotDoneActivityCountAsString();

  /**
   * Identifiant java du nombre d'activité.
   */
  String FIELD_ACTIVITY_COUNT = "activityCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité.
   */
  String FIELD_ACTIVITY_COUNT_AS_STRING = "activityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité créée.
   */
  String FIELD_CREATED_ACTIVITY_COUNT_AS_STRING = "createdActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité suspendue.
   */
  String FIELD_SUSPENDED_ACTIVITY_COUNT_AS_STRING = "suspendedActivityCountAsString";

  /**
   * Identifiant java du nombre d'activité démarrée.
   */
  String FIELD_STARTED_ACTIVITY_COUNT = "startedActivityCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité démarrée.
   */
  String FIELD_STARTED_ACTIVITY_COUNT_AS_STRING = "startedActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité arrêtée.
   */
  String FIELD_STOPPED_ACTIVITY_COUNT_AS_STRING = "stoppedActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité réalisée.
   */
  String FIELD_REALIZED_ACTIVITY_COUNT_AS_STRING = "realizedActivityCountAsString";

  /**
   * Identifiant java du nombre d'activité.
   */
  String FIELD_LATE_ACTIVITY_COUNT = "lateActivityCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité en retard.
   */
  String FIELD_LATE_ACTIVITY_COUNT_AS_STRING = "lateActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité non en
   * retard.
   */
  String FIELD_NOT_LATE_ACTIVITY_COUNT_AS_STRING = "notLateActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité non fini.
   */
  String FIELD_NOT_DONE_ACTIVITY_COUNT_AS_STRING = "notDoneActivityCountAsString";

  /**
   * Identifiant java du nombre d'activité fini.
   */
  String FIELD_DONE_ACTIVITY_COUNT = "doneActivityCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité fini.
   */
  String FIELD_DONE_ACTIVITY_COUNT_AS_STRING = "doneActivityCountAsString";

  /**
   * Identifiant java du nombre d'activité en attente de démarrage.
   */
  String FIELD_PENDING_START_ACTIVITY_COUNT = "pendingStartActivityCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre d'activité en attente
   * de démarrage.
   */
  String FIELD_PENDING_START_ACTIVITY_COUNT_AS_STRING = "pendingStartActivityCountAsString";
}
