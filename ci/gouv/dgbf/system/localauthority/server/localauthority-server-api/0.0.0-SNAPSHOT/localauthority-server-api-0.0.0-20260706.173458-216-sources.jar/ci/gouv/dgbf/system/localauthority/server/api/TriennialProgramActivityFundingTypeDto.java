package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un moyen de financement d'une activité de programmme triennal.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TriennialProgramActivityFundingTypeDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
  private String fundingTypeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_AS_STRING)
  private String fundingTypeAsString;

  /**
   * Identifiant {@link TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
  private String triennialProgramActivityIdentifier;


  /**
   * Représentation en chaine de caractères de TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING)
  private String triennialProgramActivityAsString;

  /**
   * Identifiant de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;

  /**
   * Identifiant de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1)
  private Long amount1;

  /**
   * Représentation en chaine de caractères de Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1_AS_STRING)
  private String amount1AsString;

  /**
   * Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2)
  private Long amount2;

  /**
   * Représentation en chaine de caractères de Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2_AS_STRING)
  private String amount2AsString;

  /**
   * Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3)
  private Long amount3;

  /**
   * Représentation en chaine de caractères de Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3_AS_STRING)
  private String amount3AsString;

  /**
   * Représentation en chaine de caractères du montant de l'activité.
   */
  @JsonbProperty(JSON_ACTIVITY_AMOUNT_AS_STRING)
  private String activityAmountAsString;

  /**
   * Montant modifiable.
   */
  @JsonbProperty(JSON_AMOUNTS_INPUTABLE)
  private Boolean amountsInputable;

  /**
   * Catégorie d'activité.
   */
  @JsonbProperty(JSON_ACTIVITY_CATEGORY)
  private ActivityCategory activityCategory;


  /**
   * Identifiant json {@link #fundingTypeIdentifier}.
   */
  public static final String JSON_FUNDING_TYPE_IDENTIFIER = "idTypeFinancement";

  /**
   * Identifiant json {@link #fundingTypeAsString}.
   */
  public static final String JSON_FUNDING_TYPE_AS_STRING = "typeFinancementChaine";

  /**
   * Identifiant json {@link #triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
      "identifiantActiviteProgrammeTriennal";

  /**
   * Identifiant json {@link #triennialProgramActivityAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING =
      "activiteProgrammeTriennalChaine";


  /**
   * Identifiant json {@link #amount1}.
   */
  public static final String JSON_AMOUNT_1 = "montant1";

  /**
   * Identifiant json {@link #amount1AsString}.
   */
  public static final String JSON_AMOUNT_1_AS_STRING = "montant1Chaine";

  /**
   * Identifiant json {@link #amount2}.
   */
  public static final String JSON_AMOUNT_2 = "montant2";

  /**
   * Identifiant json {@link #amount2AsString}.
   */
  public static final String JSON_AMOUNT_2_AS_STRING = "montant2Chaine";

  /**
   * Identifiant json {@link #amount3}.
   */
  public static final String JSON_AMOUNT_3 = "montant3";

  /**
   * Identifiant json {@link #amount3AsString}.
   */
  public static final String JSON_AMOUNT_3_AS_STRING = "montant3Chaine";

  /**
   * Identifiant json {@link #activityAmountAsString}.
   */
  public static final String JSON_ACTIVITY_AMOUNT_AS_STRING = "montantActiviteChaine";

  /**
   * Identifiant json {@link #amountsInputable}.
   */
  public static final String JSON_AMOUNTS_INPUTABLE = "montantsModifiable";

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING =
      TriennialProgramDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = ActivityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = "categorieActivite";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type financement activité programme triennal";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types financement par activité programme triennal";
}
