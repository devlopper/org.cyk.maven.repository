package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RevenueDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-29T07:43:11+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RevenueRequestMapperImpl implements RevenueRequestMapper {

    @Override
    public RevenueService.RevenueCreateRequestDto mapCreate(RevenueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RevenueService.RevenueCreateRequestDto revenueCreateRequestDto = new RevenueService.RevenueCreateRequestDto();

        revenueCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        revenueCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        revenueCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        revenueCreateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        revenueCreateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        revenueCreateRequestDto.setFundingSourceIdentifier( arg0.getFundingSourceIdentifier() );
        revenueCreateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );

        return revenueCreateRequestDto;
    }

    @Override
    public RevenueService.RevenueUpdateRequestDto mapUpdate(RevenueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RevenueService.RevenueUpdateRequestDto revenueUpdateRequestDto = new RevenueService.RevenueUpdateRequestDto();

        revenueUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        revenueUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        revenueUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        revenueUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        revenueUpdateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        revenueUpdateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        revenueUpdateRequestDto.setFundingSourceIdentifier( arg0.getFundingSourceIdentifier() );
        revenueUpdateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );

        return revenueUpdateRequestDto;
    }
}
