package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.ModulesGroupCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.ModulesGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ModulesGroupDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ModulesGroupDto}.

    @author Christian
               """)
public interface ModulesGroupRequestMapper
    extends RequestMapper<ModulesGroupDto, ModulesGroupCreateRequestDto,
        ModulesGroupUpdateRequestDto> {

}
