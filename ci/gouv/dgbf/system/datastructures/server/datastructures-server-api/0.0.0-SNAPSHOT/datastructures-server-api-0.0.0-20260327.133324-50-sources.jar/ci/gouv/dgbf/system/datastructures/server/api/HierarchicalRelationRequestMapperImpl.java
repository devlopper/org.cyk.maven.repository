package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link HierarchicalRelationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-27T13:33:50+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class HierarchicalRelationRequestMapperImpl implements HierarchicalRelationRequestMapper {

    @Override
    public HierarchicalRelationService.HierarchicalRelationCreateRequestDto mapCreate(HierarchicalRelationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        HierarchicalRelationService.HierarchicalRelationCreateRequestDto hierarchicalRelationCreateRequestDto = new HierarchicalRelationService.HierarchicalRelationCreateRequestDto();

        hierarchicalRelationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        hierarchicalRelationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        hierarchicalRelationCreateRequestDto.setHierarchyIdentifier( arg0.getHierarchyIdentifier() );
        hierarchicalRelationCreateRequestDto.setParentIdentifier( arg0.getParentIdentifier() );
        hierarchicalRelationCreateRequestDto.setChildIdentifier( arg0.getChildIdentifier() );

        return hierarchicalRelationCreateRequestDto;
    }

    @Override
    public HierarchicalRelationService.HierarchicalRelationUpdateRequestDto mapUpdate(HierarchicalRelationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        HierarchicalRelationService.HierarchicalRelationUpdateRequestDto hierarchicalRelationUpdateRequestDto = new HierarchicalRelationService.HierarchicalRelationUpdateRequestDto();

        hierarchicalRelationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        hierarchicalRelationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        hierarchicalRelationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        hierarchicalRelationUpdateRequestDto.setHierarchyIdentifier( arg0.getHierarchyIdentifier() );
        hierarchicalRelationUpdateRequestDto.setParentIdentifier( arg0.getParentIdentifier() );
        hierarchicalRelationUpdateRequestDto.setChildIdentifier( arg0.getChildIdentifier() );

        return hierarchicalRelationUpdateRequestDto;
    }
}
