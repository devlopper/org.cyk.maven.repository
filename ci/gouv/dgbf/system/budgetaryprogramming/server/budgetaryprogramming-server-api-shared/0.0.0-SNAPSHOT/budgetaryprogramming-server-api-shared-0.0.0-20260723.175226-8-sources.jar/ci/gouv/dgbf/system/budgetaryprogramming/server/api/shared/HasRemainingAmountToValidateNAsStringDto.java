package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateNAsStringDto
    extends HasRemainingAmountToValidateNAsString {

  /**
   * Identifiant json du montant restant à saisir pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_VALIDATE_N_AS_STRING = "montantResteAValiderNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
