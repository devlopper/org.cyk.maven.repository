package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de est EPN.
 *
 * @author Christian
 */
public interface HasIsNationalPublicInstitution extends HasField {

  /**
   * Cette méthode permet d'obtenir est EPN.
   *
   * @return est EPN
   */
  Boolean getIsNationalPublicInstitution();

  /**
   * Cette méthode permet d'assigner est EPN.
   *
   * @param isNationalPublicInstitution est EPN
   */
  void setIsNationalPublicInstitution(Boolean isNationalPublicInstitution);

  /**
   * Identifiant java de est EPN.
   */
  String FIELD_IS_NATIONAL_PUBLIC_INSTITUTION = "isNationalPublicInstitution";
}
