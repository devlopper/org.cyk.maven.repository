package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'intervalle de période.
 *
 * @author Christian
 */
public interface HasPeriodIntervalAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'intervalle de
   * période.
   *
   * @return représentation en chaine de caractères de l'intervalle de période
   */
  String getPeriodIntervalAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'intervalle de
   * période.
   *
   * @param asString représentation en chaine de caractères de l'intervalle de période
   */
  void setPeriodIntervalAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'intervalle de période.
   */
  String FIELD_PERIOD_INTERVAL_AS_STRING = "periodIntervalAsString";
}
