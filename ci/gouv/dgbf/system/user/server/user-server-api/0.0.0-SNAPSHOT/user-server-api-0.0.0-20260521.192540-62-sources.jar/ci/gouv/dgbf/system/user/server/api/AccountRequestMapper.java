package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link AccountDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link AccountDto}.

    @author Christian
               """)
public interface AccountRequestMapper
    extends RequestMapper<AccountDto, AccountCreateRequestDto, AccountUpdateRequestDto> {

}
