package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de lecture des {@link IdentityPolicyConsentDto} d'une identité.
 *
 * @author Christian
 */
@Named
@ViewScoped
public class IdentityReadPolicyConsentsPage extends AbstractIdentityReadPolicyConsentsPage {

  public static final String OUTCOME = "identityReadPolicyConsentsPage";
}
