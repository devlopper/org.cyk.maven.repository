package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentCategoryService.PayrollComponentCategoryUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollComponentCategoryService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollComponentCategoryClient extends AbstractClient<PayrollComponentCategoryService>
    implements GetByIdentifier<PayrollComponentCategoryDto>, 
               GetMany<PayrollComponentCategoryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollComponentCategoryClient service(PayrollComponentCategoryService service) {
    return (PayrollComponentCategoryClient) super.service(service);
  }

  /**
   * {@link PayrollComponentCategoryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollComponentCategoryCreateRequestDto request) {
    return new CreateExecutor(PayrollComponentCategoryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollComponentCategoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentCategoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollComponentCategoryGetManyResponseDto>(
        PayrollComponentCategoryGetManyResponseDto.class,
        PayrollComponentCategoryService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }


  /**
   * {@link PayrollComponentCategoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public PayrollComponentCategoryGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollComponentCategoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentCategoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollComponentCategoryDto>(PayrollComponentCategoryDto.class,
        PayrollComponentCategoryService.GET_ONE_IDENTIFIER)
          .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollComponentCategoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollComponentCategoryDto getOne(ProjectionDto projection, 
          FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollComponentCategoryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollComponentCategoryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollComponentCategoryDto>(PayrollComponentCategoryDto.class,
        PayrollComponentCategoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollComponentCategoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentCategoryDto getByIdentifier(String identifier, 
             ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollComponentCategoryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollComponentCategoryUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentCategoryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollComponentCategoryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentCategoryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollComponentCategoryService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
