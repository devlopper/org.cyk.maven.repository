package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link TaskDto}.
 *
 * @author Christian
 *
 */
public interface TaskContainerable {

  /*------------------------------- Status Start -----------------------------------*/

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} créé.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} créé
   */
  String getCreatedTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link TaskDto} démarré.
   *
   * @return nombre {@link TaskDto} démarré
   */
  Integer getStartedTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} démarré.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} démarré
   */
  String getStartedTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} suspendu.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} suspendu
   */
  String getSuspendedTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} arrêté.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} arrêté
   */
  String getStoppedTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link TaskDto} réalisé.
   *
   * @return nombre {@link TaskDto} réalisé
   */
  Integer getRealizedTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} réalisé.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} réalisé
   */
  String getRealizedTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre {@link TaskDto} en retard.
   *
   * @return nombre {@link TaskDto} en retard
   */
  Integer getLateTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} en retard.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} en retard
   */
  String getLateTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link TaskDto} non retard.
   *
   * @return représentation en chaine de caractères du nombre {@link TaskDto} non retard
   */
  String getNotLateTaskCountAsString();

  /*------------------------------- Status End -----------------------------------*/

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la date de début au
   * plus tôt de {@link TaskDto}.
   *
   * @return représentation en chaine de caractères du nombre de la date de début au plus tôt de
   *         {@link TaskDto}
   */
  String getTaskEarliestFromDateAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la date de fin au
   * plus tard de {@link TaskDto}.
   *
   * @return représentation en chaine de caractères du nombre de {@link TaskDto}
   */
  String getTaskLatestToDateAsString();

  /**
   * Cette méthode permet d'obtenir le nombre de {@link TaskDto}.
   *
   * @return nombre de {@link TaskDto}
   */
  Integer getTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link TaskDto}.
   *
   * @return représentation en chaine de caractères du nombre de {@link TaskDto}
   */
  String getTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre de {@link TaskDto} effectuée.
   *
   * @return nombre de {@link TaskDto} effectuée
   */
  Integer getDoneTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link TaskDto} effectuée.
   *
   * @return représentation en chaine de caractères du nombre de {@link TaskDto} effectuée
   */
  String getDoneTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link TaskDto} pas effectuée.
   *
   * @return représentation en chaine de caractères du nombre de {@link TaskDto} pas effectuée
   */
  String getNotDoneTaskCountAsString();

  /**
   * Cette méthode permet d'obtenir le nombre de {@link TaskDto} en attente de démarrage.
   *
   * @return nombre de {@link TaskDto} en attente de démarrage
   */
  Integer getPendingStartTaskCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link TaskDto} en attente de démarrage.
   *
   * @return représentation en chaine de caractères du nombre de {@link TaskDto} en attente de
   *         démarrage
   */
  String getPendingStartTaskCountAsString();

  /* Task */

  /**
   * Identifiant java du nombre de {@link TaskDto}.
   */
  String FIELD_TASK_COUNT = "taskCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}.
   */
  String FIELD_TASK_COUNT_AS_STRING = "taskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * créée.
   */
  String FIELD_CREATED_TASK_COUNT_AS_STRING = "createdTaskCountAsString";

  /**
   * Identifiant java du nombre de {@link TaskDto} déamarrée.
   */
  String FIELD_STARTED_TASK_COUNT = "startedTaskCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * déamarrée.
   */
  String FIELD_STARTED_TASK_COUNT_AS_STRING = "startedTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * suspendue.
   */
  String FIELD_SUSPENDED_TASK_COUNT_AS_STRING = "suspendedTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * arrêtée.
   */
  String FIELD_STOPPED_TASK_COUNT_AS_STRING = "stoppedTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * réalisée.
   */
  String FIELD_REALIZED_TASK_COUNT_AS_STRING = "realizedTaskCountAsString";

  /**
   * Identifiant java du nombre de {@link TaskDto} en retard.
   */
  String FIELD_LATE_TASK_COUNT = "lateTaskCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto} en
   * retard.
   */
  String FIELD_LATE_TASK_COUNT_AS_STRING = "lateTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto} non
   * en retard.
   */
  String FIELD_NOT_LATE_TASK_COUNT_AS_STRING = "notLateTaskCountAsString";

  /**
   * Identifiant java du nombre de {@link TaskDto} fini.
   */
  String FIELD_DONE_TASK_COUNT = "doneTaskCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto}
   * fini.
   */
  String FIELD_DONE_TASK_COUNT_AS_STRING = "doneTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto} non
   * fini.
   */
  String FIELD_NOT_DONE_TASK_COUNT_AS_STRING = "notDoneTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link TaskDto} en
   * attente de démarrage.
   */
  String FIELD_PENDING_START_TASK_COUNT_AS_STRING = "pendingStartTaskCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères de la date de début au plus tôt.
   */
  String FIELD_TASK_EARLIEST_FROM_DATE_AS_STRING = "taskEarliestFromDateAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères de la date de fin au plus tard.
   */
  String FIELD_TASK_LATEST_TO_DATE_AS_STRING = "taskLatestToDateAsString";
}
