package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de base de {@link AbstractExpenditureOrResourceItemDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractExpenditureOrResourceItemFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link ExerciseDto}.
   */
  String exerciseIdentifier;

  /**
   * Code de {@link ExerciseDto}.
   */
  String exerciseCode;

  /**
   * Identifiant de {@link EconomicNatureDto}.
   */
  String economicNatureIdentifier;

  /**
   * Code de {@link EconomicNatureDto}.
   */
  String economicNatureCode;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractExpenditureOrResourceItemFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  protected AbstractExpenditureOrResourceItemFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    exerciseIdentifier = getExerciseIdentifier(filter);
    exerciseCode = getExerciseCode(filter);
    economicNatureIdentifier = getEconomicNatureIdentifier(filter);
    economicNatureCode = getEconomicNatureCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setExerciseIdentifier(filter, exerciseIdentifier);
    setExerciseCode(filter, exerciseCode);
    setEconomicNatureIdentifier(filter, economicNatureIdentifier);
    setEconomicNatureCode(filter, economicNatureCode);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setExerciseIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXERCISE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ExerciseDto}
   */
  public static String getExerciseIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setExerciseCode(FilterDto filter, String code) {
    set(filter, JSON_EXERCISE_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return code de {@link ExerciseDto}
   */
  public static String getExerciseCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_CODE));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setEconomicNatureIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ECONOMIC_NATURE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link EconomicNatureDto}
   */
  public static String getEconomicNatureIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ECONOMIC_NATURE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setEconomicNatureCode(FilterDto filter, String code) {
    set(filter, JSON_ECONOMIC_NATURE_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @return code de {@link EconomicNatureDto}
   */
  public static String getEconomicNatureCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ECONOMIC_NATURE_CODE));
  }

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemFilter#exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER =
      AbstractExpenditureOrResourceItemDto.JSON_EXERCISE_IDENTIFIER;

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemFilter#exerciseCode}.
   */
  public static final String JSON_EXERCISE_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_EXERCISE_CODE;

  /**
   * Identifiant json champ identifiant de l'activité.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ code de l'activité.
   */
  public static final String JSON_ACTIVITY_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_CODE;

  /**
   * Identifiant json champ code de l'activité et de la nature économique.
   */
  public static final String JSON_ACTIVITY_AND_ECONOMIC_NATURE_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_AND_ECONOMIC_NATURE_CODE;

  /**
   * Identifiant json champ
   * {@link AbstractExpenditureOrResourceItemFilter#economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER =
      AbstractExpenditureOrResourceItemDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemFilter#economicNatureCode}.
   */
  public static final String JSON_ECONOMIC_NATURE_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_ECONOMIC_NATURE_CODE;

}
