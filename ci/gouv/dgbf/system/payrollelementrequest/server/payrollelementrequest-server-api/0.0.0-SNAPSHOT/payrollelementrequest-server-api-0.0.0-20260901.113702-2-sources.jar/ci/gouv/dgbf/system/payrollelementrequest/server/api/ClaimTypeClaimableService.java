package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link ClaimTypeClaimableDto}. N'étend pas
 * {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link ClaimTypeClaimableDto} n'a ni code ni nom propres.
 *
 * @author akm
 *
 */
@Path(ClaimTypeClaimableService.PATH)
@Tag(name = "Gestion des rattachements")
public interface ClaimTypeClaimableService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "rattachements";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface ClaimTypeClaimableSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollElementClaimTypeDto}.
     *
     * @return l'identifiant de {@link PayrollElementClaimTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollElementClaimTypeDto}.
     *
     * @param typeIdentifier l'identifiant de {@link PayrollElementClaimTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir la nature de l'objet ciblé.
     *
     * @return la nature de l'objet ciblé
     */
    String getNature();

    /**
     * Cette méthode permet d'assigner la nature de l'objet ciblé.
     *
     * @param nature la nature de l'objet ciblé
     */
    void setNature(String nature);

    /**
     * Cette méthode permet d'obtenir l'identifiant du Réclamable ciblé.
     *
     * @return l'identifiant du Réclamable ciblé
     */
    String getClaimableIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du Réclamable ciblé.
     *
     * @param claimableIdentifier l'identifiant du Réclamable ciblé
     */
    void setClaimableIdentifier(String claimableIdentifier);

    /**
     * Cette méthode permet d'obtenir le Mode de Saisie.
     *
     * @return le Mode de Saisie
     */
    String getValueInputMode();

    /**
     * Cette méthode permet d'assigner le Mode de Saisie.
     *
     * @param valueInputMode le Mode de Saisie
     */
    void setValueInputMode(String valueInputMode);

    /**
     * Cette méthode permet d'obtenir l'ordre d'affichage.
     *
     * @return l'ordre d'affichage
     */
    Integer getRank();

    /**
     * Cette méthode permet d'assigner l'ordre d'affichage.
     *
     * @param rank l'ordre d'affichage
     */
    void setRank(Integer rank);

    /**
     * {@link ClaimTypeClaimableDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = ClaimTypeClaimableDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link ClaimTypeClaimableDto#JSON_NATURE}.
     */
    String JSON_NATURE = ClaimTypeClaimableDto.JSON_NATURE;

    /**
     * {@link ClaimTypeClaimableDto#JSON_CLAIMABLE_IDENTIFIER}.
     */
    String JSON_CLAIMABLE_IDENTIFIER = ClaimTypeClaimableDto.JSON_CLAIMABLE_IDENTIFIER;

    /**
     * {@link ClaimTypeClaimableDto#JSON_VALUE_INPUT_MODE}.
     */
    String JSON_VALUE_INPUT_MODE = ClaimTypeClaimableDto.JSON_VALUE_INPUT_MODE;

    /**
     * {@link ClaimTypeClaimableDto#JSON_RANK}.
     */
    String JSON_RANK = ClaimTypeClaimableDto.JSON_RANK;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RATTACHEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ClaimTypeClaimableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ClaimTypeClaimableCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimTypeClaimableCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ClaimTypeClaimableSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
    private String claimableIdentifier;

    @JsonbProperty(JSON_VALUE_INPUT_MODE)
    private String valueInputMode;

    @JsonbProperty(JSON_RANK)
    private Integer rank;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RATTACHEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimTypeClaimableGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimTypeClaimableDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimTypeClaimableDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RATTACHEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RATTACHEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimTypeClaimableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimTypeClaimableDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RATTACHEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ClaimTypeClaimableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ClaimTypeClaimableUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimTypeClaimableUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ClaimTypeClaimableSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
    private String claimableIdentifier;

    @JsonbProperty(JSON_VALUE_INPUT_MODE)
    private String valueInputMode;

    @JsonbProperty(JSON_RANK)
    private Integer rank;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_RATTACHEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ClaimTypeClaimableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
