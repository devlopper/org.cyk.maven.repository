package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateN2AsStringDto
    extends HasRemainingAmountToValidateN2AsString {

  /**
   * Identifiant json du montant restant à valider pour l'année N+2,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_VALIDATE_N2_AS_STRING =
      "montantResteAValiderN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName