package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;

/**
 * Cette classe représente la base de page de liste d'unités administratives partagées de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public abstract class AbstractConnectedUserSharedAdministrativeUnitListPage
    extends AbstractConnectedUserSharedResourceListPage {

  /**
   * Cette méthode permet de construire.
   */
  protected AbstractConnectedUserSharedAdministrativeUnitListPage() {
    super(Location.BUDGETARY_CLASSIFICATION, ResourceType.ADMINISTRATIVE_UNIT);
    selectOneControllerFilterConsumer =
        SharingSessionController.ADMINISTRATIVE_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER;
  }

  @Override
  protected String resourceTypeName() {
    return "unités administratives partagées";
  }
}
