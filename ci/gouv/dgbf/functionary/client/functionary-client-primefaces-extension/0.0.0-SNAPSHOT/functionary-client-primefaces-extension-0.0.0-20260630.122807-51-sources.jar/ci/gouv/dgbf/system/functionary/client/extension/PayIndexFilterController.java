package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link PayIndexDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class PayIndexFilterController extends AbstractFilterController<PayIndexFilter> {

  @Inject
  @Getter
  GradeSelectOneController gradeSelectOneController;

  @Inject
  @Getter
  GradeClassSelectOneController gradeClassSelectOneController;

  @Inject
  @Getter
  EchelonSelectOneController echelonSelectOneController;

  @Inject
  @Getter
  PayScaleSelectOneController payScaleSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public PayIndexFilterController() {
    super(PayIndexFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setGradeIdentifier(getRequestParameter(PayIndexFilter.JSON_GRADE_IDENTIFIER));
    filter.setGradeClassIdentifier(getRequestParameter(PayIndexFilter
        .JSON_GRADE_CLASS_IDENTIFIER));
    filter.setSearchText(getRequestParameter(SearchTextFilter.JSON_KEY));

    gradeSelectOneController.getSelectOneMenu()
        .addValueConsumer(gradeIdentifier -> filter.setGradeIdentifier(gradeIdentifier));

    gradeClassSelectOneController.getSelectOneMenu()
        .addValueConsumer(gradeClassIdentifier -> filter.setGradeClassIdentifier(
              gradeClassIdentifier));

    echelonSelectOneController.getSelectOneMenu()
        .addValueConsumer(echelonIdentifier -> filter.setEchelonIdentifier(
              echelonIdentifier));

    payScaleSelectOneController.getSelectOneMenu()
        .addValueConsumer(payScaleIdentifier -> filter.setPayScaleIdentifier(
              payScaleIdentifier));
  }
}
