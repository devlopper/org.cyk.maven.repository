package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un engagement.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class CommitmentDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Code {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_CODE)
  private String localAuthorityCode;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Identifiant de {@link SupplierDto}.
   */
  @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
  private String supplierIdentifier;

  /**
   * Représentation en chaine de caractères de {@link SupplierDto}.
   */
  @JsonbProperty(JSON_SUPPLIER_AS_STRING)
  private String supplierAsString;

  /**
   * Identitiant json {@link SupplierDto#identifier}.
   */
  public static final String JSON_SUPPLIER_IDENTIFIER = "idFournisseur";

  /**
   * Identitiant json {@link SupplierDto#asString}.
   */
  public static final String JSON_SUPPLIER_AS_STRING = "fournisseurChaine";


  /**
   * Objet de l'engagement.
   */
  @JsonbProperty(JSON_SUBJECT)
  private String subject;

  /**
   * Référence de l'engagement.
   */
  @JsonbProperty(JSON_COMMITMENT_REFERENCE)
  private String commitmentReference;

  /**
   * Numéro facture decompte.
   */
  @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
  private String invoiceReferenceNumber;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Long amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityCode}.
   */
  public static final String JSON_LOCAL_AUTHORITY_CODE = LocalAuthorityDto.JSON_THIS_CODE;


  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";


  /**
   * Identifiant json {@link #subject}.
   */
  public static final String JSON_SUBJECT = "objet";


  /**
   * Identifiant json {@link #commitmentReference}.
   */
  public static final String JSON_COMMITMENT_REFERENCE = "referenceEngagement";

  /**
   * Identifiant json {@link #invoiceReferenceNumber}.
   */
  public static final String JSON_INVOICE_REFERENCE_NUMBER = "numeroFactureDecompte";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "engagement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
