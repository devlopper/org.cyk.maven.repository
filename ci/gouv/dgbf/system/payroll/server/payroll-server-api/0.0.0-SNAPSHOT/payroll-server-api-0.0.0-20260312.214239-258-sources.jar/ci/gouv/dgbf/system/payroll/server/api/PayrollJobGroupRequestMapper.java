package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollJobGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollJobGroupDto}.

    @author Arnaud
               """)
public interface PayrollJobGroupRequestMapper
    extends RequestMapper<PayrollJobGroupDto, 
            PayrollJobGroupCreateRequestDto, PayrollJobGroupUpdateRequestDto> {

}
