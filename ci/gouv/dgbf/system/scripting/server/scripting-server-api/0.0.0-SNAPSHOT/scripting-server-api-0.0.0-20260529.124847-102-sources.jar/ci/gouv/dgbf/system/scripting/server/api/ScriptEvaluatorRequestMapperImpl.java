package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptEvaluatorDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptEvaluatorRequestMapperImpl implements ScriptEvaluatorRequestMapper {

    @Override
    public ScriptEvaluatorService.ScriptEvaluatorCreateRequestDto mapCreate(ScriptEvaluatorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptEvaluatorService.ScriptEvaluatorCreateRequestDto scriptEvaluatorCreateRequestDto = new ScriptEvaluatorService.ScriptEvaluatorCreateRequestDto();

        scriptEvaluatorCreateRequestDto.setCode( arg0.getCode() );
        scriptEvaluatorCreateRequestDto.setName( arg0.getName() );
        scriptEvaluatorCreateRequestDto.setEngineName( arg0.getEngineName() );

        return scriptEvaluatorCreateRequestDto;
    }

    @Override
    public ScriptEvaluatorService.ScriptEvaluatorUpdateRequestDto mapUpdate(ScriptEvaluatorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptEvaluatorService.ScriptEvaluatorUpdateRequestDto scriptEvaluatorUpdateRequestDto = new ScriptEvaluatorService.ScriptEvaluatorUpdateRequestDto();

        scriptEvaluatorUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptEvaluatorUpdateRequestDto.setCode( arg0.getCode() );
        scriptEvaluatorUpdateRequestDto.setName( arg0.getName() );
        scriptEvaluatorUpdateRequestDto.setEngineName( arg0.getEngineName() );

        return scriptEvaluatorUpdateRequestDto;
    }
}
