package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant intégré à l'horizon N.
 *
 * @author Christian
 */
public interface HasIntegratedAmountN extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant intégré à l'horizon N.
   *
   * @return le montant intégré à l'horizon N
   */
  Long getIntegratedAmountN();

  /**
   * Cette méthode permet d'assigner le montant intégré à l'horizon N.
   *
   * @param amount le montant intégré à l'horizon N
   */
  void setIntegratedAmountN(Long amount);

  /**
   * Identifiant java du montant intégré à l'horizon N.
   */
  String FIELD_INTEGRATED_AMOUNT_N = "integratedAmountN";
}
