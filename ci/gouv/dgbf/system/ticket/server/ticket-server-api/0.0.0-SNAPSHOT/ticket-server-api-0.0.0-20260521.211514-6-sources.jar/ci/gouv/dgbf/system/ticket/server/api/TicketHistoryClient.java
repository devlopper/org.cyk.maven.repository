package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.TicketHistoryService.TicketHistoryGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TicketHistoryService}.
 *
 * @author kimou
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TicketHistoryClient extends AbstractClient<TicketHistoryService>
    implements GetByIdentifier<TicketHistoryDto>,
               GetMany<TicketHistoryGetManyResponseDto> {

  @Override
  public TicketHistoryClient service(TicketHistoryService service) {
    return (TicketHistoryClient) super.service(service);
  }


  /**
   * {@link TicketHistoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketHistoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TicketHistoryGetManyResponseDto>(
            TicketHistoryGetManyResponseDto.class,
        TicketHistoryService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link TicketHistoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TicketHistoryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TicketHistoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketHistoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TicketHistoryDto>(TicketHistoryDto.class,
        TicketHistoryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link TicketHistoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TicketHistoryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TicketHistoryService#getByIdentifier}.
   *
   * @param request requête
   * @return historique ticket
   */
  public TicketHistoryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TicketHistoryDto>(TicketHistoryDto.class,
        TicketHistoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TicketHistoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TicketHistoryDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
