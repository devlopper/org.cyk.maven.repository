package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PayrollElementClaimTypeGroupService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class PayrollElementClaimTypeGroupClient
    extends AbstractClient<PayrollElementClaimTypeGroupService>
    implements GetByIdentifier<PayrollElementClaimTypeGroupDto>,
    GetMany<PayrollElementClaimTypeGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollElementClaimTypeGroupClient service(PayrollElementClaimTypeGroupService service) {
    return (PayrollElementClaimTypeGroupClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimTypeGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeGroupGetManyResponseDto>(
        PayrollElementClaimTypeGroupGetManyResponseDto.class,
        PayrollElementClaimTypeGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimTypeGroupGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollElementClaimTypeGroupCreateRequestDto request) {
    return new CreateExecutor(PayrollElementClaimTypeGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollElementClaimTypeGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollElementClaimTypeGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimTypeGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeGroupDto>(
        PayrollElementClaimTypeGroupDto.class,
        PayrollElementClaimTypeGroupService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimTypeGroupDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe de type de réclamation
   */
  public PayrollElementClaimTypeGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimTypeGroupDto>(
        PayrollElementClaimTypeGroupDto.class,
        PayrollElementClaimTypeGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollElementClaimTypeGroupDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollElementClaimTypeGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollElementClaimTypeGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
