package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeMouvementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de mouvement";
}
