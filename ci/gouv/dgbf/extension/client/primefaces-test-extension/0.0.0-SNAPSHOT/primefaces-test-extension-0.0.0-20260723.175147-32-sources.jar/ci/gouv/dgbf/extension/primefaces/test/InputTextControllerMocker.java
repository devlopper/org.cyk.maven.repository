package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.input.InputText;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextarea;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link InputTextControllerMocker}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class InputTextControllerMocker {

  InputText inputText;

  InputTextarea inputTextarea;
  
  /**
   * Cette méthode permet d'instancier.
   *
   */
  public InputTextControllerMocker() {
    inputText = new InputText();
    inputTextarea = new InputTextarea();
  }

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link InputTextController}
   */
  public InputTextController mock() {
    InputTextController controller = Mockito.mock(InputTextController.class);
    Mockito.when(controller.getInputText()).thenReturn(inputText);
    Mockito.when(controller.getInputTextarea()).thenReturn(inputTextarea);
    return controller;
  }

}
