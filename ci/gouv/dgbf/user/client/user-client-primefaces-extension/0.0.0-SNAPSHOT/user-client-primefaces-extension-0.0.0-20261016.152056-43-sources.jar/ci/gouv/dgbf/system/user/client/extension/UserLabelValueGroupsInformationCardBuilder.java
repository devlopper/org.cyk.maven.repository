package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le constructeur de la carte d'information
 * {@link LabelValueGroupsInformationCard}.
 *
 * @author BoobaCool
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class UserLabelValueGroupsInformationCardBuilder {

  IconManager iconManager;

  /**
   * Nom de l'utilisateur.
   */
  String name;

  /**
   * Représentation en chaine de caractères de l'identité de l'utilisateur.
   */
  String identity;

  /**
   * Représentation en chaine de caractères du domaine de l'utilisateur.
   */
  String domain;

  /**
   * Cette méthode permet d'instancier le constructeur de la carte.
   *
   * @param iconManager {@link IconManager}
   */
  public UserLabelValueGroupsInformationCardBuilder(IconManager iconManager) {
    this.iconManager = iconManager;
  }

  /**
   * Cette méthode permet de construire la carte « Propriétés » avec le nom, l'identité et le
   * domaine de l'utilisateur.
   *
   * @return {@link LabelValueGroupsInformationCard}
   */
  public LabelValueGroupsInformationCard build() {
    LabelValueGroupsInformationCard card = new LabelValueGroupsInformationCard();
    card.getHeaderText().setValue("Propriétés");
    LabelValueGroupsInformationCard.Group group = card.group();

    group.add("Nom", name).add("Identité", identity).add("Domaine", domain);

    return card;
  }
}
