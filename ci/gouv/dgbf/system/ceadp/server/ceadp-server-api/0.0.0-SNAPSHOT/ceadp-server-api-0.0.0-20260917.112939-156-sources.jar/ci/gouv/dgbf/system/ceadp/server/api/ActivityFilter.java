package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ActivityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de l'unité administrative.
   */
  String administrativeUnitIdentifier;

  /**
   * Identifiant de {@link ActivityTypeDto}.
   */
  String typeIdentifier;

  /**
   * Identifiant de {@link FolderDto}.
   */
  String folderIdentifier;

  /**
   * Identifiant de l'identité.
   */
  String identityIdentifier;

  /**
   * Nom d'utilisateur.
   */
  String userName;

  /**
   * Est en retard.
   */
  Boolean isLate;

  /**
   * Code {@link FolderChart}.
   */
  String chartCode;
  
  /**
   * Code statut.
   */
  String statusCode;
  
  /**
   * Identifiant de l'exercice.
   */
  String exerciseIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ActivityFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeIdentifier = getTypeIdentifier(filter);
    folderIdentifier = getFolderIdentifier(filter);
    identityIdentifier = getIdentityIdentifier(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    isLate = getIsLate(filter);
    userName = getUserName(filter);
    chartCode = getChartCode(filter);
    statusCode = getStatusCode(filter);
    exerciseIdentifier = getExerciseIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
    setFolderIdentifier(filter, folderIdentifier);
    setIdentityIdentifier(filter, identityIdentifier);
    setIsLate(filter, isLate);
    setUserName(filter, userName);
    setChartCode(filter, chartCode);
    setStatusCode(filter, statusCode);
    setExerciseIdentifier(filter, exerciseIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @param identifier identifiant de {@link AdministrativeUnitDto}
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ActivityTypeDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityTypeDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ActivityTypeDto}
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FolderDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFolderIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FOLDER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FolderDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FolderDto}
   */
  public static String getFolderIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FOLDER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité.
   *
   * @param filter filtre
   * @return identifiant de l'identité
   */
  public static String getIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setIdentityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }
  
  /**
   * Cette méthode permet d'obtenir est en retard.
   *
   * @param filter filtre
   * @return est en retard
   */
  public static Boolean getIsLate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LATE));
  }

  /**
   * Cette méthode permet d'assigner est en retard.
   *
   * @param filter filtre
   * @param isLate est en retard
   */
  public static void setIsLate(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_LATE, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isLate));
  }
  
  /**
   * Cette méthode permet d'obtenir le nom d'utilisateur.
   *
   * @param filter filtre
   * @return nom d'utilisateur
   */
  public static String getUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom d'utilisateur.
   *
   * @param filter filtre
   * @param userName nom d'utilisateur
   */
  public static void setUserName(FilterDto filter, String userName) {
    set(filter, JSON_USER_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'obtenir {@link ActivityChartCode}.
   *
   * @param filter filtre
   * @return {@link ActivityChartCode}
   */
  public static String getChartCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHART_CODE));
  }

  /**
   * Cette méthode permet d'assigner {@link ActivityChartCode}.
   *
   * @param filter filtre
   * @param chartCode {@link ActivityChartCode}
   */
  public static void setChartCode(FilterDto filter, String chartCode) {
    set(filter, JSON_CHART_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(chartCode));
  }
  
  /**
   * Cette méthode permet d'obtenir le code statut.
   *
   * @param filter filtre
   * @return code statut
   */
  public static String getStatusCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code statut.
   *
   * @param filter filtre
   * @param statusCode code statut
   */
  public static void setStatusCode(FilterDto filter, String statusCode) {
    set(filter, JSON_STATUS_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(statusCode));
  }
  
  /**
   * Cette méthode permet d'obtenir l'identifiant de l'exercice.
   *
   * @param filter filtre
   * @return identifiant de l'exercice
   */
  public static String getExerciseIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'exercice.
   *
   * @param filter filtre
   * @param exerciseIdentifier identifiant de l'exercice
   */
  public static void setExerciseIdentifier(FilterDto filter, String exerciseIdentifier) {
    set(filter, JSON_EXERCISE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(exerciseIdentifier));
  }
  
  /**
   * Identifiant json champ {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      ActivityDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json champ {@link ActivityFilter#folderIdentifier}.
   */
  public static final String JSON_FOLDER_IDENTIFIER = ActivityDto.JSON_FOLDER_IDENTIFIER;

  /**
   * Identifiant json champ {@link ActivityFilter#typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = ActivityDto.JSON_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link ActivityFilter#identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";
  
  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = ActivityDto.JSON_IS_LATE;
  
  /**
   * Identifiant json champ {@link #userName}.
   */
  public static final String JSON_USER_NAME = "nomUtilisateur";
  
  /**
   * Identifiant json champ {@link #chartCode}.
   */
  public static final String JSON_CHART_CODE = "codeGraphique";
  
  /**
   * Identifiant json champ {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "codeStatut";
  
  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = "idExercice";
}
