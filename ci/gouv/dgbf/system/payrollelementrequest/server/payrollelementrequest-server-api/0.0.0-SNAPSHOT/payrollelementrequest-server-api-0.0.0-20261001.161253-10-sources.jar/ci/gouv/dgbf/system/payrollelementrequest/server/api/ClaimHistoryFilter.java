package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimHistoryDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimHistoryFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de la réclamation.
   */
  String claimIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimHistoryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimHistoryFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    claimIdentifier = getClaimIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setClaimIdentifier(filter, claimIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la réclamation.
   *
   * @param filter filtre
   * @param claimIdentifier identifiant de la réclamation
   */
  public static void setClaimIdentifier(FilterDto filter, String claimIdentifier) {
    set(filter, JSON_CLAIM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(claimIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la réclamation.
   *
   * @param filter filtre
   * @return identifiant de la réclamation
   */
  public static String getClaimIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CLAIM_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #claimIdentifier}.
   */
  public static final String JSON_CLAIM_IDENTIFIER = ClaimHistoryDto.JSON_CLAIM_IDENTIFIER;
}
