package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasIsActivatedDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Réclamable : un input du calcul de paie (Élément de Paie ou
 * Constante de Paie) synchronisé depuis le module {@code payroll} (RG_REP_CIB_07).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableDto extends AbstractIdentifiableCodableNamableDto
    implements HasIsActivatedDto {

  /**
   * Nature du Réclamable ({@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE}).
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant, module payroll, de l'Élément de Paie ou de la Constante de Paie synchronisé(e).
   */
  @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
  private String payrollIdentifier;

  /**
   * Indique si le Réclamable existe encore dans le module payroll : un Réclamable disparu de
   * payroll est désactivé, jamais supprimé, et n'est plus proposé pour paramétrer un Type de
   * Réclamation.
   */
  @JsonbProperty(JSON_IS_ACTIVATED)
  private Boolean isActivated;

  /**
   * Indique si la valeur réclamée est une donnée du Fonctionnaire commune à tous ses rémunérables
   * (RG_REP_CIB_14) : son Impact s'applique alors à chacun d'eux (RG_REP_IMP_07).
   */
  @JsonbProperty(JSON_TRANSVERSAL)
  private Boolean transversal;

  /**
   * Date de la dernière synchronisation.
   */
  @JsonbProperty(JSON_SYNCHRONIZATION_DATE)
  private String synchronizationDate;

  /**
   * Raison de l'état du Réclamable : {@code PAYROLL} désactivé car disparu de payroll,
   * {@code MANUELLE} désactivé par un administrateur, {@code REACTIVEE} réactivé par un
   * administrateur alors qu'il a disparu de payroll ; {@code null} sinon.
   */
  @JsonbProperty(JSON_DEACTIVATION_REASON)
  private String deactivationReason;

  /**
   * Nombre de Types de Réclamation qui ciblent ce Réclamable, renseigné seulement quand la
   * projection le demande.
   */
  @JsonbProperty(JSON_CLAIM_TYPE_COUNT)
  private Long claimTypeCount;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #payrollIdentifier}.
   */
  public static final String JSON_PAYROLL_IDENTIFIER = "idPayroll";

  /**
   * Identifiant json {@link #transversal}.
   */
  public static final String JSON_TRANSVERSAL = "transversal";

  /**
   * Raison : désactivé car disparu de payroll.
   */
  public static final String REASON_PAYROLL = "PAYROLL";

  /**
   * Raison : désactivé par un administrateur.
   */
  public static final String REASON_MANUAL = "MANUELLE";

  /**
   * Raison : réactivé par un administrateur alors que disparu de payroll.
   */
  public static final String REASON_REACTIVATED = "REACTIVEE";

  /**
   * Identifiant json {@link #deactivationReason}.
   */
  public static final String JSON_DEACTIVATION_REASON = "motifDesactivation";

  /**
   * Identifiant json {@link #claimTypeCount}.
   */
  public static final String JSON_CLAIM_TYPE_COUNT = "nombreTypes";

  /**
   * Identifiant json {@link #synchronizationDate}.
   */
  public static final String JSON_SYNCHRONIZATION_DATE = "dateSynchronisation";

  /**
   * Identifiant json de identifiant de {@link ClaimableDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimableDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamableChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "réclamables";
}
