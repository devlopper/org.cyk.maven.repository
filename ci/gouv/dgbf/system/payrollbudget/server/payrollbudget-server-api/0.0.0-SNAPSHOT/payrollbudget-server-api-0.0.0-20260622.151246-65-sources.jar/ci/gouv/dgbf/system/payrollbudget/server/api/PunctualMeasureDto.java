package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une mesure ponctuelle.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PunctualMeasureDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Indicateur d'activité.
   */
  @JsonbProperty(JSON_IS_ACTIVE)
  private Boolean isActive;

  /**
   * Identifiant json de l'identifiant de {@link PunctualMeasureDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMesurePonctuelle";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PunctualMeasureDto}.
   */
  public static final String JSON_THIS_AS_STRING = "mesurePonctuelleChaine";

  /**
   * Identifiant json de {@link #isActive}.
   */
  public static final String JSON_IS_ACTIVE = "estActif";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mesure ponctuelle";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "mesures ponctuelles";
}
