package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'utilisateur.
 *
 * @author Christian
 */
public interface HasUserAsStringDto extends HasUserAsString {

  /**
   * Identifiant json de représentation en chaine de caractères de l'utilisateur.
   */
  String JSON_USER_AS_STRING = "utilisateurChaine";
}
