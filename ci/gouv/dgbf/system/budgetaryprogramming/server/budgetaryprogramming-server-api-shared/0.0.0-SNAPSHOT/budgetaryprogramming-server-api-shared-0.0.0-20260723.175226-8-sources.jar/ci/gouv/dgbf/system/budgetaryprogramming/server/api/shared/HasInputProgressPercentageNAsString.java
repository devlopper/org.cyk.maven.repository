package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le pourcentage de progression de la saisie pour
 * l'année N, sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputProgressPercentageNAsString {

  /**
   * Obtient le pourcentage de progression de la saisie pour l'année N, sous forme de chaîne de
   * caractères.
   *
   * @return le pourcentage de progression de la saisie pour l'année N sous forme de chaîne de
   *         caractères
   */
  String getInputProgressPercentageNAsString();

  /**
   * Définit le pourcentage de progression de la saisie pour l'année N, sous forme de chaîne de
   * caractères.
   *
   * @param inputProgressPercentageNAsString le pourcentage de progression de la saisie pour
   *        l'année N sous forme de chaîne de caractères
   */
  void setInputProgressPercentageNAsString(String inputProgressPercentageNAsString);

  /**
   * Identifiant java du pourcentage de progression de la saisie pour l'année N, sous forme de
   * chaîne de caractères.
   */
  String FIELD_INPUT_PROGRESS_PERCENTAGE_N_AS_STRING =
      "inputProgressPercentageNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName