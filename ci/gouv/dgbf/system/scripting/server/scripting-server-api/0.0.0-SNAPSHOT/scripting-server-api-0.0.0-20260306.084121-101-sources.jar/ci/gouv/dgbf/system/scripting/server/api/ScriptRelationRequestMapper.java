package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptRelationService.ScriptRelationCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptRelationService.ScriptRelationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptRelationDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptRelationDto}.

    @author Christian
               """)
public interface ScriptRelationRequestMapper extends RequestMapper<ScriptRelationDto,
    ScriptRelationCreateRequestDto, ScriptRelationUpdateRequestDto> {

}
