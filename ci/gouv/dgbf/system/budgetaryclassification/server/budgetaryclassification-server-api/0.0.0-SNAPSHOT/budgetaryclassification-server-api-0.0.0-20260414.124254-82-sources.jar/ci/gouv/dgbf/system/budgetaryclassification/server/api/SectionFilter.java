package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SectionDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class SectionFilter extends AbstractIdentifiableFilter
    implements FilterHasAdministrativeUnitIdentifier {

  String administrativeUnitIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
  }

}
