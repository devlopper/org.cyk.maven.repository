package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente une identification.
 *
 * @author Christian
 *
 */
public interface IdentificationDto extends Identification {
  
  /**
   * Identifiant json {@link #getRegistrationNumber()}.
   */
  String JSON_REGISTRATION_NUMBER = "matricule";
  
  /**
   * Identifiant json {@link #getEmailAddress()}.
   */
  String JSON_EMAIL_ADDRESS = "adresseEmail";
  
  /**
   * Identifiant json {@link #getFirstNameAndLastNames()}.
   */
  String JSON_FIRST_NAME_AND_LAST_NAMES = "nomEtPrenoms";
}
