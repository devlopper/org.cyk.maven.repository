package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasValidatedAmountN}.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountNDto extends HasValidatedAmountN {

  /**
   * Identifiant json du montant validé à l'horizon N.
   */
  String JSON_VALIDATED_AMOUNT_N = "montantValideN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
