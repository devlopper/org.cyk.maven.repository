package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeService.DocumentTypeCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeService.DocumentTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentTypeDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentTypeDto}.

    @author Christian
               """)
public interface DocumentTypeRequestMapper
    extends RequestMapper<DocumentTypeDto, DocumentTypeCreateRequestDto,
        DocumentTypeUpdateRequestDto> {

}
