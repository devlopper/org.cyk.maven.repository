package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingService.ProgrammingCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingService.ProgrammingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingDto}.

    @author Christian
               """)
public interface ProgrammingRequestMapper
    extends RequestMapper<ProgrammingDto, ProgrammingCreateRequestDto,
        ProgrammingUpdateRequestDto> {

}
