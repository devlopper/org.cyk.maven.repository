package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ConditionalValueGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ConditionalValueGroupFilter extends AbstractIdentifiableCodableFilter {
  
}
