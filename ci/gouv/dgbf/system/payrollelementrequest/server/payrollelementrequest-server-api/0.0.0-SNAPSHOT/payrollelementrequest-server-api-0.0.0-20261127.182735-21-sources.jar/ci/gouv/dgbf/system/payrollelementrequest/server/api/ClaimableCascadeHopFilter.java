package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableCascadeHopDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableCascadeHopFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de la cascade à laquelle les sauts recherchés appartiennent.
   */
  String cascadeDependencyIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableCascadeHopFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableCascadeHopFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    cascadeDependencyIdentifier = getCascadeDependencyIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setCascadeDependencyIdentifier(filter, cascadeDependencyIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la cascade.
   *
   * @param filter filtre
   * @param cascadeDependencyIdentifier identifiant de la cascade
   */
  public static void setCascadeDependencyIdentifier(FilterDto filter,
      String cascadeDependencyIdentifier) {
    set(filter, JSON_CASCADE_DEPENDENCY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(cascadeDependencyIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la cascade.
   *
   * @param filter filtre
   * @return identifiant de la cascade
   */
  public static String getCascadeDependencyIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CASCADE_DEPENDENCY_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #cascadeDependencyIdentifier}.
   */
  public static final String JSON_CASCADE_DEPENDENCY_IDENTIFIER =
      ClaimableCascadeHopDto.JSON_CASCADE_DEPENDENCY_IDENTIFIER;
}
