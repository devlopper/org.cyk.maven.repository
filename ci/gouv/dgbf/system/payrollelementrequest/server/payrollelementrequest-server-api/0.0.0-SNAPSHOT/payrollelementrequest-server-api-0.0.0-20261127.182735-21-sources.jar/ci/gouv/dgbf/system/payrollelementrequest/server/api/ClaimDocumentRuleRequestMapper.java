package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimDocumentRuleService.ClaimDocumentRuleCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimDocumentRuleService.ClaimDocumentRuleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimDocumentRuleDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimDocumentRuleDto}.

    @author akm
               """)
public interface ClaimDocumentRuleRequestMapper extends
    RequestMapper<ClaimDocumentRuleDto, ClaimDocumentRuleCreateRequestDto,
        ClaimDocumentRuleUpdateRequestDto> {

}
