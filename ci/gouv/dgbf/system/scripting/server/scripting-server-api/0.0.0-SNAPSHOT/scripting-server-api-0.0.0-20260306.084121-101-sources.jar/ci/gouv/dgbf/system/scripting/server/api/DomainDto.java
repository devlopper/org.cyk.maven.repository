package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueReferenceTableFilterColumnNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueReferenceTableNameDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DomainDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasValueReferenceTableNameDto, HasValueReferenceTableFilterColumnNameDto {

  @JsonbProperty(JSON_VALUE_REFERENCE_TABLE_NAME)
  private String valueReferenceTableName;

  @JsonbProperty(JSON_VALUE_REFERENCE_TABLE_FILTER_COLUMN_NAME)
  private String valueReferenceTableFilterColumnName;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDomaine";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "domaineChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "domaine";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
