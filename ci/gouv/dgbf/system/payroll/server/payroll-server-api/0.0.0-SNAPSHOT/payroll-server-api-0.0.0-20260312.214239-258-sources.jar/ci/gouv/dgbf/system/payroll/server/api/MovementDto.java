package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasRemunerableAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementInstanceAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementInstanceIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un mouvement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementDto extends AbstractMovementDto
    implements HasRemunerableIdentifierDto, HasRemunerableAsStringDto,
    HasPayrollElementInstanceIdentifierDto, HasPayrollElementInstanceAsStringDto,
    HasPayrollElementAsStringDto, HasTypeIdentifierDto, HasTypeAsStringDto {

  @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
  private String remunerableIdentifier;

  @JsonbProperty(JSON_REMUNERABLE_AS_STRING)
  private String remunerableAsString;

  @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER)
  private String payrollElementInstanceIdentifier;

  @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_AS_STRING)
  private String payrollElementInstanceAsString;

  @JsonbProperty(JSON_PAYROLL_ELEMENT_AS_STRING)
  private String payrollElementAsString;

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  @JsonbProperty(JSON_STATUS)
  private MovementStatus status;

  /**
   * Identifiant json de identifiant de {@link MovementDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementDto}.
   */
  public static final String JSON_THIS_AS_STRING = "mouvementChaine";

  /**
   * Identifiant json de {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
