package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ModuleDto}.
 *
 * @author Christian
 */
@Path(value = ModuleService.PATH)
@Tag(name = "Gestion des Modules")
public interface ModuleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "modules";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ModuleSaveRequestDto extends HasDescriptionDto, HasVisibleDto {

    /**
     * Cette méthode permet d'obtenir la classification stratégique du module.
     *
     * @return classification stratégique du module
     */
    StrategicClassification getStrategicClassification();

    /**
     * Cette méthode permet d'assigner la classification stratégique du module.
     *
     * @param strategicClassification classification stratégique du module
     */
    void setStrategicClassification(StrategicClassification strategicClassification);

    /**
     * {@link ModuleDto#JSON_STRATEGIC_CLASSIFICATION}.
     */
    String JSON_STRATEGIC_CLASSIFICATION = ModuleDto.JSON_STRATEGIC_CLASSIFICATION;
  }

  /**
   * Identifiant du service de création unitaire de {@link ModuleDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_MODULE";

  /**
   * Chemin du service de création unitaire de {@link ModuleDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ModuleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ModuleDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModuleCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ModuleSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_STRATEGIC_CLASSIFICATION)
    private StrategicClassification strategicClassification;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ModuleDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MODULE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ModuleDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModuleGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ModuleDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ModuleGetManyResponseDto
      extends AbstractGetByPageResponseDto<ModuleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ModuleDto> datas;
  }

  /**
   * Identifiant du service d'obtention du compte de {@link ModuleDto}.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_MODULE";

  /**
   * Chemin du service d'obtention de compte de {@link ModuleDto}.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le compte de {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention unitaire de {@link ModuleDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_MODULE";

  /**
   * Chemin du service d'obtention unitaire de {@link ModuleDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModuleDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ModuleDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MODULE";

  /**
   * Chemin du service d'obtention par identifiant de {@link ModuleDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModuleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ModuleDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MODULE";

  /**
   * Chemin du service de mise à jour unitaire de {@link ModuleDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ModuleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ModuleDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModuleUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ModuleSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_STRATEGIC_CLASSIFICATION)
    private StrategicClassification strategicClassification;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ModuleDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MODULE";

  /**
   * Chemin du service de suppression unitaire de {@link ModuleDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ModuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
