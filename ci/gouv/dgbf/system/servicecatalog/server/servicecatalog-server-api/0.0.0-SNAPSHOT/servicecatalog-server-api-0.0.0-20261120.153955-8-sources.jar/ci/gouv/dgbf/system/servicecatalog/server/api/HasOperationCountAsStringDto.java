package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette interface représente une classe avec une notion de nombre d'opérations sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasOperationCountAsStringDto extends HasOperationCountAsString {

  /**
   * Identifiant json du nombre d'opérations sous forme de chaîne.
   */
  String JSON_OPERATION_COUNT_AS_STRING = "nombreOperationsChaine";
}
