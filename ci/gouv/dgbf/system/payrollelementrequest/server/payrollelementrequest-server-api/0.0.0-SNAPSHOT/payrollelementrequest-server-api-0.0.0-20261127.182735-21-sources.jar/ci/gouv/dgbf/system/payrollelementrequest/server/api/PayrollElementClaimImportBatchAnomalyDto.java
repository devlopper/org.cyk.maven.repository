package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Collection;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une anomalie d'un Lot d'Import (RG_REP_SOU_13) : une ligne du fichier
 * qui n'a généré aucune réclamation, et le motif. Lecture seule : le rapport naît du traitement
 * du fichier.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimImportBatchAnomalyDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant du Lot d'Import.
   */
  @JsonbProperty(JSON_IMPORT_BATCH_IDENTIFIER)
  private String importBatchIdentifier;

  /**
   * Numéro de la ligne dans le fichier, l'en-tête étant la ligne 1.
   */
  @JsonbProperty(JSON_LINE_NUMBER)
  private Integer lineNumber;

  /**
   * Motif de l'anomalie.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Code de la cause de l'anomalie, défini par le référentiel des causes d'anomalie du FUR.
   */
  @JsonbProperty(JSON_CAUSE)
  private String cause;

  /**
   * Nombre de réclamations générées à partir de la ligne, par le traitement ou par une dérogation :
   * une ligne dont la réclamation est générée n'est plus à forcer.
   */
  @JsonbProperty(JSON_GENERATED_CLAIM_COUNT)
  private Long generatedClaimCount;

  /**
   * Identifiant json {@link #generatedClaimCount}.
   */
  public static final String JSON_GENERATED_CLAIM_COUNT = "nombreReclamationsGenerees";

  /**
   * Identifiant json {@link #importBatchIdentifier}.
   */
  public static final String JSON_IMPORT_BATCH_IDENTIFIER = "idLotImport";

  /**
   * Identifiant json {@link #lineNumber}.
   */
  public static final String JSON_LINE_NUMBER = "numeroLigne";

  /**
   * Identifiant json {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json {@link #cause}.
   */
  public static final String JSON_CAUSE = "cause";

  /**
   * Cette méthode permet de savoir si la cause d'une ligne autorise une dérogation : elle doit
   * figurer parmi celles que le paramétrage rend forçables.
   *
   * @param cause code de la cause de la ligne, {@code null} si elle n'est pas connue
   * @param forceableCauses codes des causes forçables
   * @return {@code true} si la ligne peut être forcée
   */
  public static boolean isForceable(String cause, Collection<String> forceableCauses) {
    return cause != null && forceableCauses.contains(cause);
  }

  /**
   * Code de la cause d'un avancement de date d'effet trop ancienne.
   */
  public static final String CAUSE_ADVANCEMENT_TOO_OLD = "ADVANCEMENT_TOO_OLD";

  /**
   * Code de la cause d'une nomination qui répète le grade actuel de l'agent.
   */
  public static final String CAUSE_GRADE_REPEATED = "GRADE_REPEATED";

  /**
   * Code de la cause d'une information identique à celle du FUR du mois précédent.
   */
  public static final String CAUSE_REDUNDANT = "REDUNDANT";

  /**
   * Code de la cause d'une donnée obligatoire absente.
   */
  public static final String CAUSE_REQUIRED_DATA_MISSING = "REQUIRED_DATA_MISSING";

  /**
   * Préfixe du motif d'un avancement de date d'effet trop ancienne.
   */
  public static final String REASON_ADVANCEMENT_TOO_OLD =
      "Date d'effet de l'avancement antérieure de plus de ";

  /**
   * Préfixe du motif d'une nomination qui répète le grade actuel de l'agent.
   */
  public static final String REASON_GRADE_REPEATED =
      "Nomination qui répète le grade actuel de l'agent";

  /**
   * Préfixe du motif d'une information identique à celle du FUR du mois précédent.
   */
  public static final String REASON_REDUNDANT = "Information déjà présente dans le FUR du mois";

  /**
   * Préfixe du motif d'une donnée obligatoire absente, suivi des colonnes concernées.
   */
  public static final String REASON_REQUIRED_DATA_MISSING = "Donnée obligatoire absente : ";

  /**
   * Codes des causes d'un contrôle de gestion, dont le paramétrage peut rendre la ligne forçable.
   */
  public static final Set<String> MANAGEMENT_CAUSES = Set.of(CAUSE_ADVANCEMENT_TOO_OLD,
      CAUSE_GRADE_REPEATED, CAUSE_REDUNDANT, CAUSE_REQUIRED_DATA_MISSING);

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "anomalie de lot d'import";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "anomalies de lot d'import";
}
