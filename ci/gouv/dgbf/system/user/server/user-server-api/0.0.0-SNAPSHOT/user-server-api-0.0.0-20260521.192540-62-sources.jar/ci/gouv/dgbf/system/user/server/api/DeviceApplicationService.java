package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;


/**
 * Cette interface représente les services de {@link DeviceDto}.
 *
 * @author Christian
 *
 */
@Path(value = DeviceApplicationService.PATH)
@Tag(name = "Gestion des équipements et des applications")
public interface DeviceApplicationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "equipments-application";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface DeviceApplicationSaveRequestDto {

    /**
     * Cette méthode me permet d'obtenir l'identifiant de {@link DeviceDto}.
     *
     * @return identifiant de {@link DeviceDto}
     */
    String getDeviceIdentifier();

    /**
     * Cette méthode me permet d'assigner l'identifiant de {@link DeviceDto}.
     *
     * @param identifier identifiant de {@link DeviceDto}
     */
    void setDeviceIdentifier(String identifier);

    /**
     * Cette méthode me permet d'obtenir l'identifiant de {@link ApplicationDto}.
     *
     * @return identifiant de {@link ApplicationDto}
     */
    String getApplicationIdentifier();

    /**
     * Cette méthode me permet d'assigner l'identifiant de {@link ApplicationDto}.
     *
     * @param identifier identifiant de {@link ApplicationDto}
     */
    void setApplicationIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir le matricule.
     *
     * @return le matricule
     */
    String getRegistrationNumber();

    /**
     * Cette méthode permet d'assigner le matricule.
     *
     * @param registrationNumber le matricule
     */
    void setRegistrationNumber(String registrationNumber);

    /**
     * Cette méthode permet d'obtenir l'email.
     *
     * @return l'email
     */
    String getEmail();

    /**
     * Cette méthode permet d'assigner l'email.
     *
     * @param email l'email
     */
    void setEmail(String email);

    /**
     * Cette méthode permet d'obtenir le numéro de téléphone.
     *
     * @return le numéro de téléphone
     */
    String getPhoneNumber();

    /**
     * Cette méthode permet d'assigner le numéro de téléphone.
     *
     * @param phoneNumber le numéro de téléphone
     */
    void setPhoneNumber(String phoneNumber);

    /**
     * Identifiant json de {@link DeviceDto}.
     */
    String JSON_DEVICE_IDENTIFIER = DeviceApplicationDto.JSON_DEVICE_IDENTIFIER;

    /**
     * Identifiant json de {@link ApplicationDto}.
     */
    String JSON_APPLICATION_IDENTIFIER = DeviceApplicationDto.JSON_APPLICATION_IDENTIFIER;
    
    /**
     * {@link DeviceApplicationDto#JSON_REGISTRATION_NUMBER}.
     */
    String JSON_REGISTRATION_NUMBER = DeviceApplicationDto.JSON_REGISTRATION_NUMBER;
    
    /**
     * {@link DeviceApplicationDto#JSON_EMAIL}.
     */
    String JSON_EMAIL = DeviceApplicationDto.JSON_EMAIL;
    
    /**
     * {@link DeviceApplicationDto#JSON_PHONE_NUMBER}.
     */
    String JSON_PHONE_NUMBER = DeviceApplicationDto.JSON_PHONE_NUMBER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DeviceApplicationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeviceApplicationCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DeviceApplicationSaveRequestDto {
    @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
    private String applicationIdentifier;

    @JsonbProperty(JSON_DEVICE_IDENTIFIER)
    private String deviceIdentifier;


    @JsonbProperty(JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

    @JsonbProperty(JSON_EMAIL)
    private String email;

    @JsonbProperty(JSON_PHONE_NUMBER)
    private String phoneNumber;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = 
          DeviceApplicationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  public static class DeviceApplicationGetManyResponseDto 
         extends AbstractGetByPageResponseDto<DeviceApplicationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DeviceApplicationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeviceApplicationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeviceApplicationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DeviceApplicationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class DeviceApplicationUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DeviceApplicationSaveRequestDto {

    @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
    private String applicationIdentifier;

    @JsonbProperty(JSON_DEVICE_IDENTIFIER)
    private String deviceIdentifier;

    @JsonbProperty(JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

    @JsonbProperty(JSON_EMAIL)
    private String email;

    @JsonbProperty(JSON_PHONE_NUMBER)
    private String phoneNumber;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UN_EQUIPEMENT_APPLICATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DeviceApplicationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
