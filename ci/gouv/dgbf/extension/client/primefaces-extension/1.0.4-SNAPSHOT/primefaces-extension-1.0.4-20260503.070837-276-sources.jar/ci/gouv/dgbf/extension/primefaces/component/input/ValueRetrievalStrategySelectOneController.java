package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.enumeration.ValueRetrievalStrategy;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueRetrievalStrategy}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueRetrievalStrategySelectOneController
    extends AbstractSelectOneEnumerationController<ValueRetrievalStrategy> {

  protected ValueRetrievalStrategySelectOneController() {
    super(ValueRetrievalStrategy.values());
    outputLableValue = "Stratégie de récupération de valeur";
  }

  @Override
  protected String computeSelectItemLabel(ValueRetrievalStrategy valueRetrievalStrategy) {
    return valueRetrievalStrategy.getName();
  }
}
