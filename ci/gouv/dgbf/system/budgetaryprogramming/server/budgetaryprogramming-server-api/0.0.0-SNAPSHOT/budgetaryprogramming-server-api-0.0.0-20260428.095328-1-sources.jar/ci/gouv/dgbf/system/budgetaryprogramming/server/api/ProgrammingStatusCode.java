package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

/**
 * Cette classe représente les codes de {@link ProgrammingStatus}.
 *
 * @author Christian
 *
 */
public class ProgrammingStatusCode {

  private ProgrammingStatusCode() {
    
  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";
  
  /**
   * Initialisé.
   */
  public static final String INPUTTED = "SAISI";
    
  /**
   * Transmis pour arbitrage.
   */
  public static final String TRANSMITTED_FOR_ARBITRATION = "TRANSMIS_POUR_ARBITRAGE";
  
  /**
   * Arbitré.
   */
  public static final String ARBITRATED = "ARBITRE";
  
  /**
   * Transmis pour validation.
   */
  public static final String TRANSMITTED_FOR_VALIDATION = "TRANSMIS_POUR_VALIDATION";
  
  /**
   * Arbitré.
   */
  public static final String VALIDATED = "VALIDE";
  
  /**
   * Transmis pour intégration.
   */
  public static final String TRANSMITTED_FOR_INTEGRATION = "TRANSMIS_POUR_INTEGRATION";
  
  /**
   * Intégré.
   */
  public static final String INTEGRATED = "INTEGRE";
}
