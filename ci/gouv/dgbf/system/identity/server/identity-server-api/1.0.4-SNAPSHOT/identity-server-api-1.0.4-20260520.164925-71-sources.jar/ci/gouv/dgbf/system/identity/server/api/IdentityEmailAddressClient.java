package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link IdentityEmailAddressService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class IdentityEmailAddressClient extends AbstractClient<IdentityEmailAddressService>
    implements GetMany<IdentityEmailAddressGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetByIdentifier<IdentityEmailAddressDto> {

  @Override
  public IdentityEmailAddressClient service(IdentityEmailAddressService service) {
    return (IdentityEmailAddressClient) super.service(service);
  }

  /**
   * {@link IdentityEmailAddressService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(IdentityEmailAddressCreateRequestDto request) {
    return new CreateExecutor(IdentityEmailAddressService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link IdentityEmailAddressService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityEmailAddressGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentityEmailAddressGetManyResponseDto>(
        IdentityEmailAddressGetManyResponseDto.class,
        IdentityEmailAddressService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link IdentityEmailAddressService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityEmailAddressGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentityEmailAddressService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityEmailAddressDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentityEmailAddressDto>(IdentityEmailAddressDto.class,
        IdentityEmailAddressService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentityEmailAddressService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityEmailAddressDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentityEmailAddressService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public IdentityEmailAddressDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentityEmailAddressDto>(IdentityEmailAddressDto.class,
        IdentityEmailAddressService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentityEmailAddressService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentityEmailAddressDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentityEmailAddressService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(IdentityEmailAddressUpdateRequestDto request) {
    return new IdentifiableExecutor(IdentityEmailAddressService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link IdentityEmailAddressService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentityEmailAddressService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer une identité de groupe.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
