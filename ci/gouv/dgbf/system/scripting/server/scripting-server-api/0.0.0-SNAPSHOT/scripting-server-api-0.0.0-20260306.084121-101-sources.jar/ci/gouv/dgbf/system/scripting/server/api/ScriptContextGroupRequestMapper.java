package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextGroupService.ScriptContextGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextGroupService.ScriptContextGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptContextGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptContextGroupDto}.

    @author Christian
               """)
public interface ScriptContextGroupRequestMapper extends RequestMapper<ScriptContextGroupDto,
    ScriptContextGroupCreateRequestDto, ScriptContextGroupUpdateRequestDto> {
}
