package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ImputationLockService.ImputationLockCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ImputationLockService.ImputationLockUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ImputationLockDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ImputationLockDto}.

    @author Christian
               """)
public interface ImputationLockRequestMapper
    extends RequestMapper<ImputationLockDto, ImputationLockCreateRequestDto,
        ImputationLockUpdateRequestDto> {

}
