package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingCreateRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingProcessRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingUpdateCompletedWorkVolumeRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ProcessingDto}.

    @author Christian
               """)
public interface ProcessingRequestMapper
    extends RequestMapper<ProcessingDto, ProcessingCreateRequestDto, ProcessingUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper.
   *
   * @param processing {@link ProcessingDto}
   * @return {@link ProcessingProcessRequestDto}
   */
  ProcessingProcessRequestDto mapProcess(ProcessingDto processing);

  /**
   * Cette méthode permet de mapper.
   *
   * @param processing {@link ProcessingDto}
   * @return {@link ProcessingUpdateCompletedWorkVolumeRequestDto}
   */
  ProcessingUpdateCompletedWorkVolumeRequestDto mapUpdateCompletedWorkVolume(
      ProcessingDto processing);
}
