package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link FolderDto}.
 *
 * @author Christian
 *
 */
public interface FolderContainerable {

  /**
   * Cette méthode permet d'obtenir le nombre {@link FolderDto}.
   *
   * @return nombre {@link FolderDto}
   */
  Integer getFolderCount();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre
   * {@link FolderDto}.
   *
   * @return représentation en chaine de caractères du nombre {@link FolderDto}
   */
  String getFolderCountAsString();

  /**
   * Identifiant java du nombre de {@link FolderDto}.
   */
  public static final String FIELD_FOLDER_COUNT = "folderCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link FolderDto}.
   */
  public static final String FIELD_FOLDER_COUNT_AS_STRING = "folderCountAsString";
}
