package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de {@link LogLevel} en chaine de
 * caractères.
 *
 * @author Christian
 */
public interface HasLevelAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir {@link LogLevel} en chaine de caractères.
   *
   * @return {@link LogLevel} en chaine de caractères
   */
  String getLevelAsString();

  /**
   * Cette méthode permet d'assigner {@link LogLevel} en chaine de caractères.
   *
   * @param logLevelAsString {@link LogLevel} en chaine de caractères
   */
  void setLevelAsString(String logLevelAsString);

  /**
   * Identifiant java de {@link LogLevel} en chaine de caractères.
   */
  String FIELD_LEVEL_AS_STRING = "levelAsString";
}
