package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de localité.
 *
 * @author Christian
 */
public interface HasLocalityIdentifierDto extends HasLocalityIdentifier {

  /**
   * Identifiant json de l'identifiant de localité.
   */
  String JSON_LOCALITY_IDENTIFIER = "idLocalite";
}