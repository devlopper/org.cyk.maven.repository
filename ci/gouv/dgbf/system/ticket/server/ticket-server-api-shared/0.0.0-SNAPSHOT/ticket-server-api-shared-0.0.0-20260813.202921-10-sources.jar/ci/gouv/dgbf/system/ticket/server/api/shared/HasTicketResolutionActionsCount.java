package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de résolution
 * de ticket (compteur d'actions, y compris les reprises d'un même ticket).
 *
 * @author Christian
 */
public interface HasTicketResolutionActionsCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'actions de résolution de ticket.
   *
   * @return le nombre cumulé d'actions de résolution de ticket
   */
  Integer getTicketResolutionActionsCount();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'actions de résolution de ticket.
   *
   * @param ticketResolutionActionsCount le nombre cumulé d'actions de résolution de ticket
   */
  void setTicketResolutionActionsCount(Integer ticketResolutionActionsCount);

  /**
   * Identifiant java du nombre cumulé d'actions de résolution de ticket.
   */
  String FIELD_TICKET_RESOLUTION_ACTIONS_COUNT = "ticketResolutionActionsCount";
}
