package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-01T17:58:42+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentRequestMapperImpl implements DocumentRequestMapper {

    @Override
    public DocumentService.DocumentCreateRequestDto mapCreate(DocumentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentService.DocumentCreateRequestDto documentCreateRequestDto = new DocumentService.DocumentCreateRequestDto();

        documentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        documentCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        documentCreateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        List<DocumentFieldValueDto> list = arg0.getFieldValues();
        if ( list != null ) {
            documentCreateRequestDto.setFieldValues( new ArrayList<DocumentFieldValueDto>( list ) );
        }

        return documentCreateRequestDto;
    }

    @Override
    public DocumentService.DocumentUpdateRequestDto mapUpdate(DocumentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentService.DocumentUpdateRequestDto documentUpdateRequestDto = new DocumentService.DocumentUpdateRequestDto();

        documentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        documentUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        documentUpdateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        List<DocumentFieldValueDto> list = arg0.getFieldValues();
        if ( list != null ) {
            documentUpdateRequestDto.setFieldValues( new ArrayList<DocumentFieldValueDto>( list ) );
        }

        return documentUpdateRequestDto;
    }
}
