package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un planning de remboursement.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReimbursementScheduleDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link CommitmentDto}.
   */
  @JsonbProperty(JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER)
  private String expenditureSettlementIdentifier;

  /**
   * Représentation en chaine de caractères de {@link CommitmentDto}.
   */
  @JsonbProperty(JSON_EXPENDITURE_SETTLEMENT_AS_STRING)
  private String expenditureSettlementAsString;


  /**
   * Identifiant de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;



  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCALAUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCALAUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Montant initial de la créance (montant de la dette à l'origine).
   */
  @JsonbProperty(JSON_PRINCIPAL_AMOUNT)
  private Long principalAmount;

  /**
   * Représentation en chaîne de caractères du montant initial de la créance.
   */
  @JsonbProperty(JSON_PRINCIPAL_AMOUNT_AS_STRING)
  private String principalAmountAsString;


  /**
   * Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1)
  private Long amount1;

  /**
   * Représentation en chaine de caractères de Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1_AS_STRING)
  private String amount1AsString;

  /**
   * Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2)
  private Long amount2;

  /**
   * Représentation en chaine de caractères de Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2_AS_STRING)
  private String amount2AsString;

  /**
   * Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3)
  private Long amount3;


  /**
   * Représentation en chaine de caractères de Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3_AS_STRING)
  private String amount3AsString;


  /**
   * montant total déja remboursé.
   */
  @JsonbProperty(JSON_REIMBURSED_AMOUNT)
  private Long reimbursedAmount;

  /**
   * Représentation en chaine de caractères de Remboursement precedent.
   */
  @JsonbProperty(JSON_REIMBURSED_AMOUNT_AS_STRING)
  private String reimbursedAmountAsString;


  /**
   * Montant restant à rembourser.
   */
  @JsonbProperty(JSON_OUTSTANDING_AMOUNT)
  private Long outstandingAmount;

  /**
   * Représentation en chaine de caractères du montant restant à rembourser.
   */
  @JsonbProperty(JSON_OUTSTANDING_AMOUNT_AS_STRING)
  private String outstandingAmountAsString;

  /**
   * Montant modifiable.
   */
  @JsonbProperty(JSON_AMOUNTS_INPUTABLE)
  private Boolean amountsInputable;


  /**
   * Objet de la liquidation concernée.
   */
  @JsonbProperty(JSON_SUBJECT)
  private String subject;

  /**
   * Fournisseur de la liquidation concernée.
   */
  @JsonbProperty(JSON_SUPPLIER_AS_STRING)
  private String supplierAsString;

  /**
   * Référence de la liquidation concernée.
   */
  @JsonbProperty(JSON_COMMITMENT_REFERENCE)
  private String commitmentReference;

  /**
   * Numéro facture decompte de la liquidation concernée.
   */
  @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
  private String invoiceReferenceNumber;

  /**
   * Identifiant json {@link #expenditureSettlementIdentifier}.
   */
  public static final String JSON_EXPENDITURE_SETTLEMENT_IDENTIFIER = "idLiquidation";

  /**
   * Identifiant json {@link #expenditureSettlementAsString}.
   */
  public static final String JSON_EXPENDITURE_SETTLEMENT_AS_STRING = "liquidationChaine";


  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #amount1}.
   */
  public static final String JSON_AMOUNT_1 = "montant1";

  /**
   * Identifiant json {@link #amount1AsString}.
   */
  public static final String JSON_AMOUNT_1_AS_STRING = "montant1Chaine";

  /**
   * Identifiant json {@link #amount2}.
   */
  public static final String JSON_AMOUNT_2 = "montant2";

  /**
   * Identifiant json {@link #amount2AsString}.
   */
  public static final String JSON_AMOUNT_2_AS_STRING = "montant2Chaine";

  /**
   * Identifiant json {@link #reimbursedAmount}.
   */
  public static final String JSON_REIMBURSED_AMOUNT = "montantRembourse";


  /**
   * Identifiant json {@link #reimbursedAmountAsString}.
   */
  public static final String JSON_REIMBURSED_AMOUNT_AS_STRING = "montantRembourseChaine";


  /**
   * Identifiant json {@link #outstandingAmount}.
   */
  public static final String JSON_OUTSTANDING_AMOUNT = "montantRestantARembourser";

  /**
   * Identifiant json {@link #outstandingAmountAsString}.
   */
  public static final String JSON_OUTSTANDING_AMOUNT_AS_STRING = "montantRestantARembourserChaine";


  /**
   * Identifiant json {@link #principalAmount}.
   */
  public static final String JSON_PRINCIPAL_AMOUNT = "montantInitialCreance";

  /**
   * Identifiant json {@link #principalAmountAsString}.
   */
  public static final String JSON_PRINCIPAL_AMOUNT_AS_STRING = "montantInitialCreanceChaine";

  /**
   * Identifiant json {@link #amountsInputable}.
   */
  public static final String JSON_AMOUNTS_INPUTABLE = "montantsModifiable";


  /**
   * Identifiant json {@link #amount3}.
   */
  public static final String JSON_AMOUNT_3 = "montant3";


  /**
   * Identifiant json {@link #amount3AsString}.
   */
  public static final String JSON_AMOUNT_3_AS_STRING = "montant3Chaine";

  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING =
      TriennialProgramDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCALAUTHORITY_IDENTIFIER = "identifiantCollectivite";

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCALAUTHORITY_AS_STRING =
      LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #subject}.
   */
  public static final String JSON_SUBJECT = "objet";


  /**
   * Identifiant json {@link #commitmentReference}.
   */
  public static final String JSON_COMMITMENT_REFERENCE = "referenceEngagement";


  /**
   * Identifiant json {@link #invoiceReferenceNumber}.
   */
  public static final String JSON_INVOICE_REFERENCE_NUMBER = "numeroFactureDecompte";


  /**
   * Représentation en chaine de caractères du fournisseur .
   */
  public static final String JSON_SUPPLIER_AS_STRING = "fournisseurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "planning de remboursement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "plannings de remboursement";
}

