package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService.DomainCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService.DomainUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DomainDto}.
 *
 * @author Boobacool
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DomainDto}.

    @author Boobacool
               """)
public interface DomainRequestMapper
    extends RequestMapper<DomainDto, DomainCreateRequestDto, DomainUpdateRequestDto> {

}
