package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'intervalle de période..
 *
 * @author Christian
 */
public interface FilterHasPeriodIntervalIdentifier extends HasPeriodIntervalIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'intervalle de la période.
   *
   * @param filter {@link FilterDto}
   */
  default void updatePeriodIntervalIdentifier(FilterDto filter) {
    setPeriodIntervalIdentifier(PeriodIntervalIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'intervalle de la période de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterPeriodIntervalIdentifier(FilterDto filter) {
    PeriodIntervalIdentifierFilter.set(filter, getPeriodIntervalIdentifier());
  }

}
