package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimHistoryService.ClaimHistoryGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimHistoryService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimHistoryClient extends AbstractClient<ClaimHistoryService>
    implements GetMany<ClaimHistoryGetManyResponseDto> {

  @Override
  public ClaimHistoryClient service(ClaimHistoryService service) {
    return (ClaimHistoryClient) super.service(service);
  }

  /**
   * {@link ClaimHistoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimHistoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimHistoryGetManyResponseDto>(ClaimHistoryGetManyResponseDto.class,
        ClaimHistoryService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimHistoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimHistoryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }
}
