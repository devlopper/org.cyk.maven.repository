package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationClient;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationDto;
import ci.gouv.dgbf.system.user.server.api.DeviceApplicationService.DeviceApplicationGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DeviceApplicationDto}.
 *
 * @author BoobaCool
 *
 */
@Dependent
public class DeviceApplicationSelectOneController extends AbstractSelectOneIdentifiableController<
    DeviceApplicationDto, DeviceApplicationGetManyResponseDto, DeviceApplicationClient> {

  @Getter
  @Inject
  DeviceApplicationClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected DeviceApplicationSelectOneController() {
    super(DeviceApplicationDto.class, SelectItemLabelStrategy.NAME);
  }
}
