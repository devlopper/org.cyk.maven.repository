package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.mailer.server.api.SendService.GetManyResponseDto;
import ci.gouv.dgbf.system.mailer.server.api.SendService.SendCreateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client du service SendService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SendClient extends AbstractClient<SendService> implements GetByIdentifier<SendDto>,
    GetMany<GetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SendClient service(SendService service) {
    return (SendClient) super.service(service);
  }

  /**
   * {@link SendService#create(SendCreateRequestDto)}.
   *
   * @param request {@link SendCreateRequestDto}
   * @return réponse
   */
  public CreateResponseDto create(SendCreateRequestDto request) {
    return new CreateExecutor(SendService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Cette méthode permet de créer un envoi de mail.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String mailIdentifier, String auditWho,
      String auditSession) {
    SendCreateRequestDto request = new SendCreateRequestDto();
    request.setMailIdentifier(mailIdentifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }
  
  /**
   * {@link SendService#process(ByIdentifierRequestDto)}.
   *
   * @param request {@link ByIdentifierRequestDto}
   * @return réponse
   */
  public IdentifiableResponseDto process(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(SendService.PROCESS_IDENTIFIER)
        .execute(() -> service().process(request));
  }

  /**
   * Cette méthode permet de traiter un envoi de mail.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto process(String identifier, String auditWho,
      String auditSession) {
    ByIdentifierRequestDto request = new ByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return process(request);
  }

  /**
   * {@link SendService#getMany(GetManyRequestDto)}.
   *
   * @param request {@link GetManyRequestDto}
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        SendService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * Cette méthode permet d'obtenir des envois de mails.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SendService#getOne(GetOneRequestDto)}.
   *
   * @param request {@link GetOneRequestDto}
   * @return réponse
   */
  public SendDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SendDto>(SendDto.class, SendService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * Cette méthode permet d'obtenir un envoi de mail.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SendDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SendService#getByIdentifier(GetByIdentifierRequestDto)}.
   *
   * @param request {@link GetByIdentifierRequestDto}
   * @return réponse
   */
  public SendDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SendDto>(SendDto.class, SendService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * Cette méthode permet d'obtenir par identifiant un envoi de mail.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SendDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SendService#delete(DeleteOneRequestDto)}.
   *
   * @param request {@link DeleteOneRequestDto}
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SendService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un envoi de mail.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
