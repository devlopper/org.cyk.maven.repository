package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page d'index de lecture de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class DocumentTypeGroupReadIndexPage extends AbstractDocumentTypeGroupReadDatasPage {

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "documentTypeGroupReadIndexPage";
}
