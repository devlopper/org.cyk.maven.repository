package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.faces.model.SelectItem;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente la base d'une sélection.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelect<T> extends AbstractInput<T> {

  List<SelectItem> choices;

  ChoiceBuilder choiceBuilder;

  /**
   * Cette méthode permet d'obtenir la liste non nulle des choix.
   *
   * @return liste non nulle des choix
   */
  public List<SelectItem> choices() {
    if (choices == null) {
      choices = new ArrayList<>();
    }
    return choices;
  }

  /**
   * Cette méthode permet d'ajouter des choix.
   *
   * @param choices choix
   * @return this
   */
  public AbstractSelect<T> addChoices(List<SelectItem> choices) {
    Core.runIfCollectionNotEmpty(choices, () -> choices().addAll(choices));
    return this;
  }
  
  /**
   * Cette méthode permet d'obtenir un choix par valeur.
   *
   * @param value valeur
   * @return choix
   */
  public SelectItem getChoiceByValue(Object value) {
    if (Core.isCollectionEmpty(choices)) {
      return null;
    }
    for (SelectItem choice : choices) {
      if (Objects.equals(value, choice.getValue())) {
        return choice;
      }
    }
    return null;
  }

  public ChoiceBuilder choiceBuilder() {
    choiceBuilder = new ChoiceBuilder();
    return choiceBuilder;
  }

  @Getter
  @Setter
  @Accessors(fluent = true)
  class ChoiceBuilder {
    String label;
    Object value;

    /**
     * Cette méthode permet de construite un choix.
     */
    public void build() {
      Core.runIfStringNotBlank(label, () -> choices().add(new SelectItem(value, label)));
    }
  }
}
