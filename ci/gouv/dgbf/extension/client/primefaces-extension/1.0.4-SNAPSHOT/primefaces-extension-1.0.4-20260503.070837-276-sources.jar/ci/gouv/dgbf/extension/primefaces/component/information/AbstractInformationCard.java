package ci.gouv.dgbf.extension.primefaces.component.information;

import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base des cartes d'information.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInformationCard extends AbstractWidget {

}
