package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTabMenuController;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de collection de {@link FileDto},
 * un onglet par module auquel au moins un fichier est rattaché (TCH_FILE_554).
 *
 * @author Christian
 */
@Dependent
public class FileCollectionTabMenuController extends AbstractTabMenuController {

  @Inject
  FileClient client;

  @Getter
  String moduleIdentifierParameterName;

  /**
   * Cette méthode permet de construire.
   */
  public FileCollectionTabMenuController() {
    menu.setMenuItemStyleClassPrefix("file");
    addPage(FileListPage.class, FileListPage.OUTCOME);
    moduleIdentifierParameterName = FileFilter.JSON_MODULE_IDENTIFIER;
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();

    menu.tabBuilder().menuItemValue("Tout").type(FileListPage.class).count(count(null)).build();

    addMenuTabsFromModules();
  }

  String count(String moduleIdentifier) {
    GetCountRequestDto countRequest = new GetCountRequestDto();
    if (moduleIdentifier != null) {
      FileFilter filter = new FileFilter();
      filter.setModuleIdentifier(moduleIdentifier);
      countRequest.useFilter(filter);
    }
    countRequest.setAuditWho(userIdentifier);
    Long count = client.getCount(countRequest);
    return String.valueOf(count);
  }

  void addMenuTabsFromModules() {
    modulesIdentifiers().forEach(this::addMenuTabFromModule);
  }

  List<String> modulesIdentifiers() {
    return Optional.ofNullable(client.getModulesIdentifiers(userIdentifier, null))
        .orElse(Collections.emptyList());
  }

  void addMenuTabFromModule(String moduleIdentifier) {
    menu.tabBuilder().menuItemValue(moduleIdentifier).type(FileListPage.class)
        .count(count(moduleIdentifier))
        .addMenuItemParameter(moduleIdentifierParameterName, moduleIdentifier).build();
  }
}
