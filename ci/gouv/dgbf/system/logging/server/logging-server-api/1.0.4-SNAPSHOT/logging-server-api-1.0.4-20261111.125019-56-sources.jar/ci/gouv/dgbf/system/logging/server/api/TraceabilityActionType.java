package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/** Type d’action fonctionnelle portée par un événement de traçabilité. */
@Getter
public enum TraceabilityActionType implements CodableByStringWithGetterOnly {
  LECTURE(TraceabilityActionTypeCode.LECTURE),
  CREATION(TraceabilityActionTypeCode.CREATION),
  MODIFICATION(TraceabilityActionTypeCode.MODIFICATION),
  SUPPRESSION(TraceabilityActionTypeCode.SUPPRESSION),
  EXECUTION(TraceabilityActionTypeCode.EXECUTION),
  ENVOI(TraceabilityActionTypeCode.ENVOI),
  AUTRE(TraceabilityActionTypeCode.AUTRE);

  private final String code;

  /**
   * Construit un type d’action.
   *
   * @param code code stable
   */
  TraceabilityActionType(String code) {
    this.code = code;
  }

  /**
   * Recherche un type par son code.
   *
   * @param code code à rechercher
   * @return type correspondant
   */
  public static TraceabilityActionType getByCode(String code) {
    for (TraceabilityActionType value : values()) {
      if (value.code.equals(code)) {
        return value;
      }
    }
    throw new IllegalArgumentException("Code de type d’action inconnu : " + code);
  }
}
