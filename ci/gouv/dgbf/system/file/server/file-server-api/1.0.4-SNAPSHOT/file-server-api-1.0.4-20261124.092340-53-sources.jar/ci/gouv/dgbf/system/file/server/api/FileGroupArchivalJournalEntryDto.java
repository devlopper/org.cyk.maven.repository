package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entrée en lecture du journal des événements d'Archivage d'un
 * fichier de groupe.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileGroupArchivalJournalEntryDto extends AbstractIdentifiableDto {

  public static final String NAME = "entrée du journal d'archivage de fichier de groupe";
  public static final String PLURAL_NAME = NAME + "s";

  @JsonbProperty(JSON_ORDER)
  private Long order;

  @JsonbProperty(JSON_EVENT_DATE)
  private LocalDateTime eventDate;

  @JsonbProperty(JSON_EVENT_TYPE)
  private FileGroupArchivalJournalEventType eventType;

  @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
  private String fileGroupIdentifier;

  @JsonbProperty(JSON_REQUEST_IDENTIFIER)
  private String requestIdentifier;

  @JsonbProperty(JSON_ARCHIVE_IDENTIFIER)
  private String archiveIdentifier;

  @JsonbProperty(JSON_ACTOR_IDENTIFIER)
  private String actorIdentifier;

  @JsonbProperty(JSON_FIELD_KIND)
  private FileGroupArchivalJournalFieldKind fieldKind;

  @JsonbProperty(JSON_OLD_VALUE)
  private String oldValue;

  @JsonbProperty(JSON_VALUE)
  private String value;

  @JsonbProperty(JSON_JUSTIFICATION)
  private String justification;

  public static final String JSON_ORDER = "ordre";
  public static final String JSON_EVENT_DATE = "dateEvenement";
  public static final String JSON_EVENT_TYPE = "typeEvenement";
  public static final String JSON_FILE_GROUP_IDENTIFIER = "identifiantFichierGroupe";
  public static final String JSON_REQUEST_IDENTIFIER = "identifiantDemande";
  public static final String JSON_ARCHIVE_IDENTIFIER = "identifiantArchive";
  public static final String JSON_ACTOR_IDENTIFIER = "identifiantActeur";
  public static final String JSON_FIELD_KIND = "champConcerne";
  public static final String JSON_OLD_VALUE = "ancienneValeur";
  public static final String JSON_VALUE = "valeur";
  public static final String JSON_JUSTIFICATION = "justification";
}
