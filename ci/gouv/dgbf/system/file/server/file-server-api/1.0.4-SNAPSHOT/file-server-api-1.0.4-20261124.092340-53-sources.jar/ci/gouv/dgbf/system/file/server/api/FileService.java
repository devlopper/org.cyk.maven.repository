package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasConfirmedDto;
import ci.gouv.dgbf.extension.core.segregation.HasContentTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasPrimitiveBytesArrayDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestMultipartDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.annotations.providers.multipart.PartType;

/**
 * Cette interface représente un service de gestion de fichier.<br/>
 * Elle définit les méthodes pour créer des fichiers, obtenir les octets d'un fichier.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FileService.PATH)
@Tag(name = "Gestion des fichiers")
public interface FileService {

  /**
   * Chemin du service de gestion de fichier.
   */
  String PATH = "fichiers";

  /**
   * Cette classe représente l'objet de transfert de donnée de base des requêtes au format multipart
   * liée au propriétaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  abstract class AbstractOwnerRequestMultipartDto extends AbstractAuditedRequestMultipartDto {

    /**
     * Identifiant {@link OwnerDto} — optionnel depuis que {@code moduleIdentifier} existe
     * (TCH_FILE_553/554) : repli utilisé uniquement si le module n'est pas fourni.
     */
    @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
    @FormParam(value = JSON_OWNER_IDENTIFIER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_OWNER_IDENTIFIER,
        description = "l'identifiant du propriétaire du fichier", example = "application01")
    private String ownerIdentifier;

    /**
     * Identifiant JSON {@link #ownerIdentifier}.
     */
    public static final String JSON_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER;
  }

  /**
   * Cette classe représente l'objet de transfert de donnée de base des requêtes au format json liée
   * au propriétaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  abstract class AbstractOwnerRequestJsonDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant {@link OwnerDto} — optionnel depuis que {@code moduleIdentifier} existe
     * (TCH_FILE_553/554/577) : repli utilisé uniquement si le module n'est pas fourni.
     */
    @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
    @Parameter(name = JSON_OWNER_IDENTIFIER,
        description = "l'identifiant du propriétaire du fichier", example = "application01")
    private String ownerIdentifier;

    /**
     * Identifiant JSON {@link #ownerIdentifier}.
     */
    public static final String JSON_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FICHIER";

  /**
   * Chemin du service de création de fichier.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un fichier.
   *
   * @param request la requête de crétation de fichier
   * @return la réponse de création de fichier
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un fichier",
      description = "Ce service permet de créer un fichier")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileCreateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée de la requête de création d'un fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileCreateRequestDto extends AbstractOwnerRequestMultipartDto
      implements HasNameDto, HasContentTypeDto, HasPrimitiveBytesArrayDto, HasConfirmedDto,
      HasModuleIdentifierDto {

    /**
     * Nom.
     */
    @NotNull
    @JsonbProperty(JSON_NAME)
    @FormParam(value = JSON_NAME)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_NAME, description = "le nom du fichier", example = "fichier01.txt")
    private String name;

    /**
     * Type de contenu.
     */
    @JsonbProperty(JSON_CONTENT_TYPE)
    @FormParam(value = JSON_CONTENT_TYPE)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONTENT_TYPE,
        description = "le type de contenu du fichier. Il doit respecter le format MIME",
        example = "text/plain")
    private String contentType;

    /**
     * Octets du contenu binaire. Facultatifs depuis DEC_FILE_01 (TCH_FILE_610) : un Fichier
     * physique n'en a pas, mais il est alors créé avec son Exemplaire physique ({@link #holder}).
     * Fournis, ils ne sont jamais vides (RG_FILE_FIC_02).
     */
    @JsonbProperty(value = JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    @Parameter(name = JSON_BYTES, description = "les données binaires du fichier ; absentes pour "
        + "un fichier physique, qui est alors créé avec son exemplaire physique")
    private byte[] bytes;

    /**
     * Description, facultative.
     */
    @JsonbProperty(value = JSON_DESCRIPTION)
    @FormParam(value = JSON_DESCRIPTION)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_DESCRIPTION, description = "la description du fichier (2000 caractères "
        + "au plus)")
    private String description;

    /**
     * Date de production, facultative, au format ISO {@code AAAA-MM-JJ}.
     */
    @JsonbProperty(value = JSON_PRODUCTION_DATE)
    @FormParam(value = JSON_PRODUCTION_DATE)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_PRODUCTION_DATE,
        description = "la date de production, au format AAAA-MM-JJ", example = "2026-11-18")
    private String productionDate;

    /**
     * Code du support d'origine ({@link MediumNature}, jamais hybride) : obligatoire seulement si
     * le contenu binaire et l'Exemplaire physique sont fournis ensemble ; sinon déduit
     * (RG_FILE_FIC_17, DEC_FILE_02 D15).
     */
    @JsonbProperty(value = JSON_ORIGINAL_MEDIUM)
    @FormParam(value = JSON_ORIGINAL_MEDIUM)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_ORIGINAL_MEDIUM, description = "le support d'origine (NUMERIQUE ou "
        + "PHYSIQUE), obligatoire si les octets et l'exemplaire physique sont fournis ensemble",
        example = "PHYSIQUE")
    private String originalMedium;

    /**
     * Détenteur de l'Exemplaire physique : le fournir crée l'Exemplaire physique
     * (RG_FILE_FIC_19).
     */
    @JsonbProperty(value = JSON_HOLDER)
    @FormParam(value = JSON_HOLDER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_HOLDER, description = "qui détient le papier ; le fournir crée "
        + "l'exemplaire physique", example = "Service courrier")
    private String holder;

    /**
     * Contenant de l'Exemplaire physique, facultatif ; retiré à la reprise dans datastructures
     * (DEC_FILE_02 D16, TCH_FILE_644).
     */
    @Deprecated
    @JsonbProperty(value = JSON_CONTAINER)
    @FormParam(value = JSON_CONTAINER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONTAINER, description = "le contenant du papier (boîte, chemise)")
    private String container;

    /**
     * Importance matérielle de l'Exemplaire physique, facultative ; retirée à la reprise dans
     * datastructures (DEC_FILE_02 D16, TCH_FILE_644).
     */
    @Deprecated
    @JsonbProperty(value = JSON_PHYSICAL_EXTENT)
    @FormParam(value = JSON_PHYSICAL_EXTENT)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_PHYSICAL_EXTENT, description = "l'importance matérielle du papier",
        example = "12 feuillets")
    private String physicalExtent;

    /**
     * État matériel de l'Exemplaire physique, facultatif ; retiré à la reprise dans datastructures
     * (DEC_FILE_02 D16, TCH_FILE_644).
     */
    @Deprecated
    @JsonbProperty(value = JSON_PHYSICAL_CONDITION)
    @FormParam(value = JSON_PHYSICAL_CONDITION)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_PHYSICAL_CONDITION, description = "l'état matériel du papier")
    private String physicalCondition;

    @JsonbProperty(value = JSON_CONFIRMED)
    @FormParam(value = JSON_CONFIRMED)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONFIRMED,
        description = "si non fourni, le fichier est créé directement confirmé")
    private Boolean confirmed;

    /**
     * Identifiant du module propriétaire (optionnel, transitoire — coexiste avec
     * {@link #getOwnerIdentifier()} ; à défaut, déduit du Propriétaire, cf.
     * file-conception-spec-kit TCH_FILE_550).
     */
    @JsonbProperty(value = JSON_MODULE_IDENTIFIER)
    @FormParam(value = JSON_MODULE_IDENTIFIER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_MODULE_IDENTIFIER,
        description = "l'identifiant du module propriétaire du fichier ; à défaut, déduit du "
            + "Propriétaire", example = "fichier")
    private String moduleIdentifier;

    /**
     * Identifiant JSON {@link #name}.
     */
    public static final String JSON_NAME = HasNameDto.JSON_NAME;

    /**
     * Identifiant JSON {@link #contentType}.
     */
    public static final String JSON_CONTENT_TYPE = HasContentTypeDto.JSON_CONTENT_TYPE;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = HasPrimitiveBytesArrayDto.JSON_BYTES;

    /**
     * Identifiant JSON {@link #moduleIdentifier}.
     */
    public static final String JSON_MODULE_IDENTIFIER =
        HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER;

    /**
     * Identifiant JSON {@link #description}.
     */
    public static final String JSON_DESCRIPTION = FileDto.JSON_DESCRIPTION;

    /**
     * Identifiant JSON {@link #productionDate}.
     */
    public static final String JSON_PRODUCTION_DATE = FileDto.JSON_PRODUCTION_DATE;

    /**
     * Identifiant JSON {@link #originalMedium}.
     */
    public static final String JSON_ORIGINAL_MEDIUM = FileDto.JSON_ORIGINAL_MEDIUM;

    /**
     * Identifiant JSON {@link #holder}.
     */
    public static final String JSON_HOLDER = PhysicalItemDto.JSON_HOLDER;

    /**
     * Identifiant JSON {@link #container}.
     */
    @Deprecated
    public static final String JSON_CONTAINER = PhysicalItemDto.JSON_CONTAINER;

    /**
     * Identifiant JSON {@link #physicalExtent}.
     */
    @Deprecated
    public static final String JSON_PHYSICAL_EXTENT = PhysicalItemDto.JSON_PHYSICAL_EXTENT;

    /**
     * Identifiant JSON {@link #physicalCondition}.
     */
    @Deprecated
    public static final String JSON_PHYSICAL_CONDITION = PhysicalItemDto.JSON_PHYSICAL_CONDITION;
  }

  /**
   * Identifiant du service d'obtention de l'Exemplaire physique d'un fichier.
   */
  String GET_PHYSICAL_ITEM_IDENTIFIER = "OBTENTION_EXEMPLAIRE_PHYSIQUE_FICHIER";

  /**
   * Chemin du service d'obtention de l'Exemplaire physique d'un fichier.
   */
  String GET_PHYSICAL_ITEM_PATH = "exemplaire-physique";

  /**
   * Cette méthode permet d'obtenir l'Exemplaire physique d'un fichier (RG_FILE_FIC_19) : réponse
   * 404 explicite si le fichier n'en a pas.
   *
   * @param request la requête, portant l'identifiant du fichier
   * @return l'Exemplaire physique ({@link PhysicalItemDto})
   */
  @Path(GET_PHYSICAL_ITEM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_PHYSICAL_ITEM_IDENTIFIER,
      summary = "Obtention de l'exemplaire physique d'un fichier",
      description = "Ce service permet d'obtenir l'exemplaire physique (détenteur, localisation, "
          + "contenant, importance et état matériels) d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhysicalItemDto.class))})
  Response getPhysicalItem(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de la fiche descriptive d'un fichier.
   */
  String GET_DESCRIPTIVE_SHEET_IDENTIFIER = "OBTENTION_FICHE_DESCRIPTIVE_FICHIER";

  /**
   * Chemin du service d'obtention de la fiche descriptive d'un fichier.
   */
  String GET_DESCRIPTIVE_SHEET_PATH = "fiche-descriptive";

  /**
   * Type de contenu de la fiche descriptive.
   */
  String DESCRIPTIVE_SHEET_MEDIA_TYPE = "application/pdf";

  /**
   * Mention obligatoire de toute fiche descriptive, à l'écran comme dans le PDF (RG_FILE_FIC_18) :
   * définie une seule fois pour le client et le serveur.
   */
  String DESCRIPTIVE_SHEET_MANDATORY_NOTICE =
      "Fiche descriptive d'un document sur support physique — ce n'est pas le document";

  /**
   * Cette méthode permet d'obtenir un rendu de la fiche descriptive d'un fichier qui a un
   * Exemplaire physique (RG_FILE_FIC_18), PDF à ce jour ({@link #DESCRIPTIVE_SHEET_MEDIA_TYPE}) :
   * construite à la lecture à partir des informations du fichier et de son Exemplaire physique,
   * portant dans le rendu la mention qu'il ne s'agit pas du document. Réponse 409 si le fichier
   * n'a pas d'Exemplaire physique. Ce n'est pas une variante de {@link #getBytes} : elle n'est
   * jamais servie à la place des octets, et ne remplace jamais ceux d'un fichier hybride.
   *
   * @param request la requête, portant l'identifiant du fichier
   * @return le PDF de la fiche descriptive
   */
  @Path(GET_DESCRIPTIVE_SHEET_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces({DESCRIPTIVE_SHEET_MEDIA_TYPE, MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_DESCRIPTIVE_SHEET_IDENTIFIER,
      summary = "Obtention de la fiche descriptive d'un fichier",
      description = "Ce service permet d'obtenir un rendu (PDF à ce jour) de la fiche descriptive "
          + "d'un fichier qui a un exemplaire physique : description et exemplaire, avec la "
          + "mention qu'il ne s'agit pas du document")
  @APIResponse(responseCode = "200",
      content = {@Content(mediaType = DESCRIPTIVE_SHEET_MEDIA_TYPE,
          schema = @Schema(implementation = byte.class))})
  @APIResponse(responseCode = "409",
      description = "Le fichier n'a pas d'exemplaire physique : pas de fiche descriptive")
  Response getDescriptiveSheet(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de la description proposée d'un fichier.
   */
  String GET_PROPOSED_DESCRIPTION_IDENTIFIER = "OBTENTION_DESCRIPTION_PROPOSEE_FICHIER";

  /**
   * Chemin du service d'obtention de la description proposée d'un fichier.
   */
  String GET_PROPOSED_DESCRIPTION_PATH = "description-proposee";

  /**
   * Cette méthode permet d'obtenir, avant la création d'un fichier, la description proposée à
   * partir d'un contenu binaire et de son nom de fichier (RG_FILE_FIC_24) : lecture sans effet,
   * rien n'est enregistré. Un contenu illisible ou d'un format non traité donne une proposition
   * sans Description ni Date, jamais une erreur.
   *
   * @param request la requête, portant les octets et le nom du fichier
   * @return la description proposée ({@link FileDescriptionProposalDto})
   */
  @Path(GET_PROPOSED_DESCRIPTION_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_PROPOSED_DESCRIPTION_IDENTIFIER,
      summary = "Obtention de la description proposée d'un fichier",
      description = "Ce service permet d'obtenir le nom, la description et la date de production "
          + "proposés à partir d'un contenu binaire, avant la création d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileDescriptionProposalDto.class))})
  @APIResponse(responseCode = "400",
      description = "Contenu absent ou au-delà de la taille maximale")
  Response getProposedDescription(GetProposedDescriptionRequestDto request);

  /**
   * Cette classe représente la requête d'obtention de la description proposée d'un fichier. Sans
   * Module ni Propriétaire : rien n'est enregistré.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class GetProposedDescriptionRequestDto extends AbstractAuditedRequestMultipartDto {

    /**
     * Octets du fichier joint.
     */
    @NotNull
    @JsonbProperty(JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    private byte[] bytes;

    /**
     * Nom du fichier joint, facultatif : source du Nom proposé.
     */
    @JsonbProperty(JSON_FILE_NAME)
    @FormParam(value = JSON_FILE_NAME)
    @PartType(MediaType.TEXT_PLAIN + ";charset=UTF-8")
    @Parameter(name = JSON_FILE_NAME, description = "le nom du fichier joint",
        example = "Rapport annuel 2025.pdf")
    private String fileName;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = FileDto.JSON_BYTES;

    /**
     * Identifiant JSON {@link #fileName}.
     */
    public static final String JSON_FILE_NAME = "nomFichier";
  }

  /**
   * Identifiant du service d'obtention des octets d'un fichier.
   */
  String GET_BYTES_IDENTIFIER = "OBTENTION_OCTETS_FICHIER";

  /**
   * Chemin du service d'obtention des octets d'un fichier.
   */
  String GET_BYTES_PATH = "octets";

  /**
   * Cette méthode permet d'obtenir les octets d'un fichier.
   *
   * @param request la requête
   * @return les octets
   */
  @Path(GET_BYTES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_OCTET_STREAM)
  @Operation(operationId = GET_BYTES_IDENTIFIER, summary = "Obtention des octets d'un fichier",
      description = "Ce service permet d'obtenir les octets d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = byte.class))})
  Response getBytes(GetBytesRequestDto request);

  /**
   * Cette méthode permet de résoudre le module servant à filtrer une lecture (TCH_FILE_577) :
   * celui fourni s'il est renseigné, sinon l'identifiant du Propriétaire, interprété comme
   * identifiant de module (identiques par construction, cf. TCH_FILE_549).
   *
   * @param moduleIdentifier identifiant du module
   * @param ownerIdentifier identifiant du Propriétaire
   * @return identifiant du module
   */
  static String resolveModuleIdentifier(String moduleIdentifier, String ownerIdentifier) {
    return moduleIdentifier == null || moduleIdentifier.isBlank() ? ownerIdentifier
        : moduleIdentifier;
  }

  /**
   * Cette classe représente un objet de transfert de donnée de la requête d'obtention des octets
   * d'un fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class GetBytesRequestDto extends AbstractOwnerRequestJsonDto implements HasModuleIdentifierDto {

    /**
     * Identifiant du module propriétaire du fichier ; à défaut, l'identifiant du Propriétaire
     * fourni est interprété comme tel (cf. file-conception-spec-kit TCH_FILE_577).
     */
    @JsonbProperty(value = JSON_MODULE_IDENTIFIER)
    @Parameter(name = JSON_MODULE_IDENTIFIER,
        description = "l'identifiant du module propriétaire du fichier", example = "fichier")
    private String moduleIdentifier;

    /**
     * Identifiant {@link FileDto}.
     */
    @NotNull
    @JsonbProperty(JSON_IDENTIFIER)
    @Parameter(name = JSON_IDENTIFIER)
    private String identifier;

    /**
     * Identifiant JSON {@link #identifier}.
     */
    public static final String JSON_IDENTIFIER = AbstractIdentifiableDto.JSON_IDENTIFIER;

    /**
     * Cette méthode permet d'instantier une requête d'obtention de un.
     *
     * @param request requête
     * @return requête d'obtention de un
     */
    public static GetOneRequestDto instantiate(GetBytesRequestDto request) {
      if (request == null) {
        return null;
      }
      GetOneRequestDto getOneRequestDto = new GetOneRequestDto();
      getOneRequestDto.setAuditSession(request.getAuditSession());
      getOneRequestDto.setAuditWho(request.getAuditWho());
      getOneRequestDto.filter().addCriteria(AbstractIdentifiableFilter.JSON_IDENTIFIER,
          request.getIdentifier());
      getOneRequestDto.filter().addCriteria(FileFilter.JSON_MODULE_IDENTIFIER,
          resolveModuleIdentifier(request.getModuleIdentifier(), request.getOwnerIdentifier()));
      getOneRequestDto.projection().addNames(FileDto.JSON_BYTES);
      return getOneRequestDto;
    }
  }

  /**
   * Identifiant du service d'obtention des octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_OCTETS_PAR_IDENTIFIANT_FICHIER";

  /**
   * Chemin du service d'obtention des octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_PATH = "octets-par-identifiant";

  /**
   * Cette méthode permet d'obtenir les octets par identifiant.
   *
   * @param request la requête
   * @return les octets
   */
  @Path(GET_BYTES_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_OCTET_STREAM)
  @Operation(operationId = GET_BYTES_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = byte.class))})
  Response getBytesByIdentifier(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de l'identifiant d'un fichier par les octets.
   */
  String GET_IDENTIFIER_BY_BYTES_IDENTIFIER = "OBTENTION_IDENTIFIANT_PAR_OCTETS";

  /**
   * Chemin du service d'obtention de l'identifiant d'un fichier par les octets.
   */
  String GET_IDENTIFIER_BY_BYTES_PATH = "identifiant-par-octets";

  /**
   * Cette méthode permet d'obtenir l'identifiant d'un fichier en fonction de ses octets.
   *
   * @param request la requête
   * @return l'identifiant
   */
  @POST
  @Path(GET_IDENTIFIER_BY_BYTES_PATH)
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_IDENTIFIER_BY_BYTES_IDENTIFIER,
      summary = "Obtention de l'identifiant d'un fichier à partir de ses octets",
      description = "Ce service permet d'obtenir l'identifiant d'un fichier à partir de ses octets")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = String.class))})
  Response getIdentifierByBytes(GetIdentifierByBytesRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée de la requête d'obtention de
   * l'identifiant par du contenu de fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class GetIdentifierByBytesRequestDto extends AbstractOwnerRequestMultipartDto
      implements HasModuleIdentifierDto {

    /**
     * Identifiant du module propriétaire du fichier ; à défaut, l'identifiant du Propriétaire
     * fourni est interprété comme tel (cf. file-conception-spec-kit TCH_FILE_577).
     */
    @JsonbProperty(value = JSON_MODULE_IDENTIFIER)
    @FormParam(value = JSON_MODULE_IDENTIFIER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_MODULE_IDENTIFIER,
        description = "l'identifiant du module propriétaire du fichier", example = "fichier")
    private String moduleIdentifier;

    /**
     * Octets.
     */
    @NotNull
    @JsonbProperty(JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    private byte[] bytes;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = FileDto.JSON_BYTES;

    /**
     * Cette méthode permet d'instantier une requête d'obtention de un.
     *
     * @param request requête
     * @param hashComputationFunction fonction de calcul du hash
     * @return requête d'obtention de un
     */
    public static GetOneRequestDto instantiate(GetIdentifierByBytesRequestDto request,
        Function<byte[], String> hashComputationFunction) {
      if (request == null) {
        return null;
      }
      GetOneRequestDto getOneRequestDto = new GetOneRequestDto();
      getOneRequestDto.setAuditSession(request.getAuditSession());
      getOneRequestDto.setAuditWho(request.getAuditWho());
      getOneRequestDto.setFilter(new FilterDto());
      String hash = hashComputationFunction.apply(request.getBytes());
      getOneRequestDto.getFilter().addCriteria(FileFilter.JSON_HASH, hash);
      getOneRequestDto.getFilter().addCriteria(FileFilter.JSON_MODULE_IDENTIFIER,
          resolveModuleIdentifier(request.getModuleIdentifier(), request.getOwnerIdentifier()));
      getOneRequestDto.setProjection(new ProjectionDto());
      getOneRequestDto.getProjection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
      return getOneRequestDto;
    }
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FICHIER";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des fichiers")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<FileDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FICHIER";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un fichier")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention de un par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FICHIER";

  /**
   * Chemin du service d'obtention de un par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir un par identifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un fichier")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FICHIER";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileUpdateRequestDto.class))})
  Response update(FileUpdateRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileUpdateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Identifiant du service de confirmation.
   */
  String CONFIRM_IDENTIFIER = "CONFIRMATION_FICHIER";

  /**
   * Chemin du service de confirmation.
   */
  String CONFIRM_PATH = "confirmation";

  /**
   * Cette méthode permet de confirmer {@link FileDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONFIRM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONFIRM_IDENTIFIER,
      description = "Ce service permet de confirmer un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileConfirmResponseDto.class))})
  Response confirm(FileConfirmRequestDto request);

  /**
   * Cette classe représente la requête de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileConfirmRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<FileStatus>, HasConfirmableDto {

    @JsonbProperty(JSON_STATUS)
    private FileStatus status;

    @JsonbProperty(JSON_CONFIRMABLE)
    private Boolean confirmable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link FileStatus}
     */
    public void initialize(FileStatus status) {
      this.status = status;
    }
  }

  /**
   * Cette classe représente la réponse de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileConfirmResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FICHIER";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un fichier")
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_FICHIER";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le compte {@link FileDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention des identifiants de modules.
   */
  String GET_MODULES_IDENTIFIERS_IDENTIFIER = "OBTENTION_IDENTIFIANTS_MODULES_FICHIER";

  /**
   * Chemin du service d'obtention des identifiants de modules.
   */
  String GET_MODULES_IDENTIFIERS_PATH = "obtention/modules";

  /**
   * Cette méthode permet d'obtenir les identifiants, distincts et triés, des modules auxquels au
   * moins un fichier est rattaché (TCH_FILE_554).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MODULES_IDENTIFIERS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MODULES_IDENTIFIERS_IDENTIFIER,
      description = "Ce service permet d'obtenir les identifiants des modules des fichiers")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = String[].class))})
  Response getModulesIdentifiers(GetModulesIdentifiersRequestDto request);

  /**
   * Cette classe représente la requête d'obtention des identifiants de modules.
   *
   * @author Christian
   *
   */
  class GetModulesIdentifiersRequestDto extends AbstractAuditedRequestJsonDto {

  }

  /**
   * Identifiant du service d'ajout du contenu binaire (RG_FILE_FIC_20).
   */
  String ADD_BYTES_IDENTIFIER = "AJOUT_CONTENU_BINAIRE_FICHIER";

  /**
   * Chemin du service d'ajout du contenu binaire.
   */
  String ADD_BYTES_PATH = "contenu-binaire";

  /**
   * Cette méthode permet d'ajouter le contenu binaire d'un Fichier qui n'en a pas (scan d'un
   * papier), une seule fois : le Fichier devient hybride, son support d'origine ne change pas.
   * Refus (400) : contenu déjà présent, contenu vide, trop volumineux, de type non autorisé ou
   * identique à un autre Fichier du Module, Archive applicable.
   *
   * @param request requête multipart
   * @return Fichier ({@link FileDto})
   */
  @Path(ADD_BYTES_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ADD_BYTES_IDENTIFIER, summary = "Ajout du contenu binaire",
      description = "Ce service permet d'ajouter le contenu binaire d'un fichier qui n'en a pas")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileDto.class))})
  Response addBytes(FileBytesAddRequestDto request);

  /**
   * Cette classe représente la requête d'ajout du contenu binaire.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FileBytesAddRequestDto extends AbstractAuditedRequestMultipartDto
      implements HasContentTypeDto, HasPrimitiveBytesArrayDto {

    /**
     * Identifiant du Fichier.
     */
    @NotNull
    @JsonbProperty(JSON_IDENTIFIER)
    @FormParam(value = JSON_IDENTIFIER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_IDENTIFIER, description = "l'identifiant du fichier")
    private String identifier;

    /**
     * Octets du contenu binaire.
     */
    @NotNull
    @JsonbProperty(JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    @Parameter(name = JSON_BYTES, description = "les données binaires du fichier")
    private byte[] bytes;

    /**
     * Type de contenu, facultatif : déduit des octets s'il est absent.
     */
    @JsonbProperty(JSON_CONTENT_TYPE)
    @FormParam(value = JSON_CONTENT_TYPE)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONTENT_TYPE,
        description = "le type de contenu (format MIME) ; déduit des octets s'il est absent",
        example = "application/pdf")
    private String contentType;

    /**
     * Identifiant JSON {@link #identifier}.
     */
    public static final String JSON_IDENTIFIER = AbstractIdentifiableDto.JSON_IDENTIFIER;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = HasPrimitiveBytesArrayDto.JSON_BYTES;

    /**
     * Identifiant JSON {@link #contentType}.
     */
    public static final String JSON_CONTENT_TYPE = HasContentTypeDto.JSON_CONTENT_TYPE;
  }

  /**
   * Identifiant du service de déclaration de l'Exemplaire physique (RG_FILE_FIC_20).
   */
  String DECLARE_PHYSICAL_ITEM_IDENTIFIER = "DECLARATION_EXEMPLAIRE_PHYSIQUE_FICHIER";

  /**
   * Chemin du service de déclaration de l'Exemplaire physique.
   */
  String DECLARE_PHYSICAL_ITEM_PATH = "exemplaire-physique/declaration";

  /**
   * Cette méthode permet de déclarer l'Exemplaire physique d'un Fichier qui n'en a pas (papier
   * d'un document numérique), une seule fois, avec son Détenteur : le Fichier devient hybride.
   * Refus (400) : Exemplaire déjà présent, Détenteur vide, demande d'Archivage créée, Archive
   * applicable.
   *
   * @param request requête
   * @return Exemplaire physique ({@link PhysicalItemDto})
   */
  @Path(DECLARE_PHYSICAL_ITEM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DECLARE_PHYSICAL_ITEM_IDENTIFIER,
      summary = "Déclaration de l'exemplaire physique",
      description = "Ce service permet de déclarer l'exemplaire physique d'un fichier qui n'en a "
          + "pas")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhysicalItemDto.class))})
  Response declarePhysicalItem(FilePhysicalItemDeclareRequestDto request);

  /**
   * Cette classe représente la requête de déclaration de l'Exemplaire physique. Les Propriétés du
   * papier arrivent avec TCH_FILE_651.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FilePhysicalItemDeclareRequestDto extends ByIdentifierRequestDto {

    /**
     * Détenteur, obligatoire.
     */
    @JsonbProperty(JSON_HOLDER)
    private String holder;

    /**
     * Identifiant JSON {@link #holder}.
     */
    public static final String JSON_HOLDER = PhysicalItemDto.JSON_HOLDER;
  }

  /**
   * Identifiant du service de modification des informations (RG_FILE_FIC_21).
   */
  String UPDATE_INFORMATION_IDENTIFIER = "MODIFICATION_INFORMATION_FICHIER";

  /**
   * Chemin du service de modification des informations.
   */
  String UPDATE_INFORMATION_PATH = "informations/modification";

  /**
   * Cette méthode permet de modifier les informations d'un Fichier (Nom, Description, Date de
   * production), sans justification. Un champ absent n'est pas modifié ; la Description et la
   * Date de production s'effacent en les citant dans {@code champsEffaces}. Refus (400) : aucun
   * changement effectif, Nom vide, {@code champsEffaces} incohérent, Archive applicable.
   *
   * @param request requête
   * @return Fichier ({@link FileDto})
   */
  @Path(UPDATE_INFORMATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_INFORMATION_IDENTIFIER,
      summary = "Modification des informations d'un fichier",
      description = "Ce service permet de modifier le nom, la description et la date de "
          + "production d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileDto.class))})
  Response updateInformation(FileInformationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de modification des informations. Les Propriétés arrivent
   * avec TCH_FILE_651.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FileInformationUpdateRequestDto extends ByIdentifierRequestDto {

    /**
     * Nouveau Nom, facultatif ; jamais vide s'il est fourni.
     */
    @JsonbProperty(JSON_NAME)
    private String name;

    /**
     * Nouvelle Description, facultative.
     */
    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    /**
     * Nouvelle Date de production, facultative.
     */
    @JsonbProperty(JSON_PRODUCTION_DATE)
    private LocalDate productionDate;

    /**
     * Champs à effacer : codes {@link FileJournalFieldKindCode#DESCRIPTION} et
     * {@link FileJournalFieldKindCode#PRODUCTION_DATE} seulement (JSON-B ne distingue pas un
     * champ absent d'un champ nul).
     */
    @JsonbProperty(JSON_CLEARED_FIELDS)
    private Set<String> clearedFields;

    /**
     * Identifiant JSON {@link #name}.
     */
    public static final String JSON_NAME = HasNameDto.JSON_NAME;

    /**
     * Identifiant JSON {@link #description}.
     */
    public static final String JSON_DESCRIPTION = FileDto.JSON_DESCRIPTION;

    /**
     * Identifiant JSON {@link #productionDate}.
     */
    public static final String JSON_PRODUCTION_DATE = FileDto.JSON_PRODUCTION_DATE;

    /**
     * Identifiant JSON {@link #clearedFields}.
     */
    public static final String JSON_CLEARED_FIELDS = "champsEffaces";
  }

  /**
   * Identifiant du service de modification de l'Exemplaire physique (RG_FILE_FIC_22).
   */
  String UPDATE_PHYSICAL_ITEM_IDENTIFIER = "MODIFICATION_EXEMPLAIRE_PHYSIQUE_FICHIER";

  /**
   * Chemin du service de modification de l'Exemplaire physique.
   */
  String UPDATE_PHYSICAL_ITEM_PATH = "exemplaire-physique/modification";

  /**
   * Cette méthode permet de changer le Détenteur de l'Exemplaire physique d'un Fichier. Refus
   * (400) : aucun changement effectif, Détenteur vide, Archive applicable ; 404 explicite si le
   * Fichier n'a pas d'Exemplaire physique.
   *
   * @param request requête
   * @return Exemplaire physique ({@link PhysicalItemDto})
   */
  @Path(UPDATE_PHYSICAL_ITEM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_PHYSICAL_ITEM_IDENTIFIER,
      summary = "Modification de l'exemplaire physique",
      description = "Ce service permet de changer le détenteur de l'exemplaire physique d'un "
          + "fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhysicalItemDto.class))})
  Response updatePhysicalItem(FilePhysicalItemUpdateRequestDto request);

  /**
   * Cette classe représente la requête de modification de l'Exemplaire physique.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FilePhysicalItemUpdateRequestDto extends ByIdentifierRequestDto {

    /**
     * Nouveau Détenteur, obligatoire.
     */
    @JsonbProperty(JSON_HOLDER)
    private String holder;

    /**
     * Identifiant JSON {@link #holder}.
     */
    public static final String JSON_HOLDER = PhysicalItemDto.JSON_HOLDER;
  }
}
