package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une representation de type de fonction.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RepresentationTypeFunctionDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link TypeFunctionDto}.
   */
  @JsonbProperty(JSON_TYPE_FUNCTION_IDENTIFIER)
  private String typeFunctionIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeFunctionIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_FUNCTION_AS_STRING)
  private String typeFunctionAsString;

  /**
   * Identifiant {@link RepresentationDto}.
   */
  @JsonbProperty(JSON_REPRESENTATION_IDENTIFIER)
  private String representationIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #representationIdentifier}.
   */
  @JsonbProperty(JSON_REPRESENTATION_AS_STRING)
  private String representationAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRepresentationTypeFunction";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "representationTypeFunctionChaine";

  /**
   * Identifiant json de {@link #typeFunctionIdentifier}.
   */
  public static final String JSON_TYPE_FUNCTION_IDENTIFIER = "idTypeFunction";

  /**
   * Identifiant json de {@link #typeFunctionAsString}.
   */
  public static final String JSON_TYPE_FUNCTION_AS_STRING = "typeFunctionChaine";

  /**
   * Identifiant json de {@link #representationIdentifier}.
   */
  public static final String JSON_REPRESENTATION_IDENTIFIER = "idRepresentation";

  /**
   * Identifiant json de {@link #representationAsString}.
   */
  public static final String JSON_REPRESENTATION_AS_STRING = "representationChaine";



  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "representation de type de fonction";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "representations de type de fonction";
}
