package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimedValueService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimedValueClient extends AbstractClient<ClaimedValueService>
    implements GetByIdentifier<ClaimedValueDto>, GetMany<ClaimedValueGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimedValueClient service(ClaimedValueService service) {
    return (ClaimedValueClient) super.service(service);
  }

  /**
   * {@link ClaimedValueService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimedValueGetManyResponseDto>(ClaimedValueGetManyResponseDto.class,
        ClaimedValueService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimedValueService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimedValueGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimedValueService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimedValueCreateRequestDto request) {
    return new CreateExecutor(ClaimedValueService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimedValueService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimedValueUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimedValueService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimedValueService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimedValueDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimedValueDto>(ClaimedValueDto.class,
        ClaimedValueService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimedValueService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimedValueDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimedValueService#getByIdentifier}.
   *
   * @param request requête
   * @return valeur réclamée
   */
  public ClaimedValueDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimedValueDto>(ClaimedValueDto.class,
        ClaimedValueService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimedValueService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimedValueDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimedValueService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimedValueService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimedValueService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
