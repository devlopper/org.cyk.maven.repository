package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollModelDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollModelFilter extends AbstractIdentifiableFilter {

  private String groupIdentifier;

  private String typeIdentifier;

  private String payslipTemplateIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollModelFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollModelFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
    typeIdentifier = getTypeIdentifier(filter);
    payslipTemplateIdentifier = getPayslipTemplateIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
    setPayslipTemplateIdentifier(filter, payslipTemplateIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de bulletin de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de bulletin de paie.
   *
   * @param filter filtre
   * @return identifiant du groupe de bulletin de paie
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d ->
            d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant du type de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de paie.
   *
   * @param filter filtre
   * @return identifiant du type de paie
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant du modèle de bulletin de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPayslipTemplateIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYSLIP_TEMPLATE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du modèle de bulletin de paie.
   *
   * @param filter filtre
   * @return identifiant du modèle de bulletin de paie pour les postes de paie rattachés
   */
  public static String getPayslipTemplateIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_PAYSLIP_TEMPLATE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = 
      PayrollModelDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = 
      PayrollModelDto.JSON_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #payslipTemplateIdentifier}.
   */
  public static final String JSON_PAYSLIP_TEMPLATE_IDENTIFIER = 
      PayrollModelDto.JSON_PAYSLIP_TEMPLATE_IDENTIFIER;
}
