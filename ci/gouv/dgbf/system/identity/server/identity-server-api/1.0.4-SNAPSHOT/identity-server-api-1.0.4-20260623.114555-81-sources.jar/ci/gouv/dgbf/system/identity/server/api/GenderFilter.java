package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link GenderDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class GenderFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Est masculin.
   */
  Boolean isMasculine;
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isMasculine = getIsMasculine(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsMasculine(filter, isMasculine);
  }

  /**
   * Cette méthode permet d'assigner est masculin.
   *
   * @param filter filtre
   * @param isMasculine est masculin
   */
  public static void setIsMasculine(FilterDto filter, Boolean isMasculine) {
    set(filter, JSON_IS_MASCULINE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isMasculine));
  }
  
  /**
   * Cette méthode permet d'obtenir est masculin.
   *
   * @param filter filtre
   * @return est masculin
   */
  public static Boolean getIsMasculine(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_MASCULINE));
  }

  /**
   * Champ JSON {@link #isMasculine}.
   */
  public static final String JSON_IS_MASCULINE = "estMasculin";
}

