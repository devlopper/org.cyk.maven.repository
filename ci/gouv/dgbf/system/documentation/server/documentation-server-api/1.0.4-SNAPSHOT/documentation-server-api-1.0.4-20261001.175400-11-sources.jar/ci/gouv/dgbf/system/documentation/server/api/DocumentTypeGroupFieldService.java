package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DocumentTypeGroupFieldDto}.
 *
 * @author si.kimou
 */
@Path(value = DocumentTypeGroupFieldService.PATH)
@Tag(name = "Gestion des Champs de Groupe de Type de Document")
public interface DocumentTypeGroupFieldService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "champs-groupe-type-document";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface DocumentTypeGroupFieldSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant du groupe de type de document.
     *
     * @return identifiant du groupe de type de document
     */
    String getTypeGroupIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du groupe de type de document.
     *
     * @param typeGroupIdentifier identifiant du groupe de type de document
     */
    void setTypeGroupIdentifier(String typeGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir le type de donnée du champ.
     *
     * @return type de donnée du champ
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner le type de donnée du champ.
     *
     * @param valueType type de donnée du champ
     */
    void setValueType(ValueType valueType);

    /**
     * Cette méthode permet d'obtenir si le champ est obligatoire.
     *
     * @return si le champ est obligatoire
     */
    Boolean getRequired();

    /**
     * Cette méthode permet d'assigner si le champ est obligatoire.
     *
     * @param required si le champ est obligatoire
     */
    void setRequired(Boolean required);

    /**
     * {@link DocumentTypeGroupFieldDto#JSON_TYPE_GROUP_IDENTIFIER}.
     */
    String JSON_TYPE_GROUP_IDENTIFIER = DocumentTypeGroupFieldDto.JSON_TYPE_GROUP_IDENTIFIER;

    /**
     * {@link DocumentTypeGroupFieldDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = DocumentTypeGroupFieldDto.JSON_VALUE_TYPE;

    /**
     * {@link DocumentTypeGroupFieldDto#JSON_REQUIRED}.
     */
    String JSON_REQUIRED = DocumentTypeGroupFieldDto.JSON_REQUIRED;
  }

  /**
   * Identifiant du service de création unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de création unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DocumentTypeGroupFieldCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link DocumentTypeGroupFieldDto}.
   *
   * @author si.kimou
   */
  @Getter
  @Setter
  class DocumentTypeGroupFieldCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DocumentTypeGroupFieldSaveRequestDto {

    @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
    private String typeGroupIdentifier;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_REQUIRED)
    private Boolean required;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link DocumentTypeGroupFieldDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link DocumentTypeGroupFieldDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link DocumentTypeGroupFieldDto}.
   *
   * @author si.kimou
   */
  @Getter
  @Setter
  public static class DocumentTypeGroupFieldGetManyResponseDto
      extends AbstractGetByPageResponseDto<DocumentTypeGroupFieldDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DocumentTypeGroupFieldDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link DocumentTypeGroupFieldDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link DocumentTypeGroupFieldDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de mise à jour unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  Response update(DocumentTypeGroupFieldUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de
   * {@link DocumentTypeGroupFieldDto}.
   *
   * @author si.kimou
   */
  @Getter
  @Setter
  class DocumentTypeGroupFieldUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DocumentTypeGroupFieldSaveRequestDto {

    @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
    private String typeGroupIdentifier;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_REQUIRED)
    private Boolean required;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CHAMP_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de suppression unitaire de {@link DocumentTypeGroupFieldDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link DocumentTypeGroupFieldDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  Response delete(DeleteOneRequestDto request);
}
