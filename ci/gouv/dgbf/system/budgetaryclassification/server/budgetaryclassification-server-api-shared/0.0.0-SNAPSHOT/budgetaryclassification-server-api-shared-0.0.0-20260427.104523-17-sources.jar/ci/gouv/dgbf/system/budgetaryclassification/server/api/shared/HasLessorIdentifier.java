package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de bailleur.
 *
 * @author Christian
 */
public interface HasLessorIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la bailleur.
   *
   * @return identifiant de la bailleur
   */
  String getLessorIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la bailleur.
   *
   * @param identifier identifiant de la bailleur
   */
  void setLessorIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de la bailleur.
   */
  String FIELD_LESSOR_IDENTIFIER = "lessorIdentifier";
}
