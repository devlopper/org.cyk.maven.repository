package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDataEntityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDataEntityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourcesCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de source de valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueSourceGroupDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDataEntityIdentifierDto, HasDataEntityAsStringDto, HasValuesCountAsStringDto,
    HasSourcesCountAsStringDto {

  @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
  private String dataEntityIdentifier;

  @JsonbProperty(JSON_DATA_ENTITY_AS_STRING)
  private String dataEntityAsString;

  @JsonbProperty(JSON_VALUES_COUNT_AS_STRING)
  private String valuesCountAsString;

  @JsonbProperty(JSON_SOURCES_COUNT_AS_STRING)
  private String sourcesCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeSourceValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeSourceValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de source de valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de source de valeur";
}
