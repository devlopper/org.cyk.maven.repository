package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentitiesGroupRoleDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentitiesGroupRoleDto}.

    @author Arnaud
               """)
public interface IdentitiesGroupRoleRequestMapper
    extends RequestMapper<IdentitiesGroupRoleDto, 
            IdentitiesGroupRoleCreateRequestDto, 
            IdentitiesGroupRoleUpdateRequestDto> {
                
}
