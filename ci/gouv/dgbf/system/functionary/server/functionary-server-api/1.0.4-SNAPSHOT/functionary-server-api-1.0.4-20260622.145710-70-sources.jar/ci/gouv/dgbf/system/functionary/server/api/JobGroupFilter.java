package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link JobGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class JobGroupFilter extends AbstractIdentifiableFilter {
  
}
