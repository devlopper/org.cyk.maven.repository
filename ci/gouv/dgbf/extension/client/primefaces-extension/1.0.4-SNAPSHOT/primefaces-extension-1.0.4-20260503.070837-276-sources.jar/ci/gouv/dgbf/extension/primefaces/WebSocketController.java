package ci.gouv.dgbf.extension.primefaces;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.websocket.OnClose;
import jakarta.websocket.OnError;
import jakarta.websocket.OnMessage;
import jakarta.websocket.OnOpen;
import jakarta.websocket.Session;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente le contrôleur de socket web.
 *
 * @author Christian
 *
 */
@ServerEndpoint("/{" + WebSocketController.PARAMETER_SOCKET_IDENTIFIER + "}")
@ApplicationScoped
public class WebSocketController {
  private static final Logger LOGGER = Logger.getLogger(WebSocketController.class.getName());

  Map<String, Session> sessions = new ConcurrentHashMap<>();

  /**
   * Cette méthode permet de réagir lorsqu'un socket est ouvert.
   *
   * @param identifier identifiant
   * @param session session
   */
  @OnOpen
  public void onOpen(@PathParam(PARAMETER_SOCKET_IDENTIFIER) String identifier, Session session) {
    sessions.put(identifier, session);
    LOGGER.log(Level.FINEST, "Session ouverte. identifiant={0}", identifier);
  }

  /**
   * Cette méthode permet de réagir lorsqu'un socket est fermé.
   *
   * @param identifier identifiant
   * @param session session
   */
  @OnClose
  public void onClose(@PathParam(PARAMETER_SOCKET_IDENTIFIER) String identifier, Session session) {
    sessions.remove(identifier);
    LOGGER.log(Level.FINEST, "Session fermée. identifiant={0}", identifier);
  }

  /**
   * Cette méthode permet de réagir lorsqu'une erreur survient.
   *
   * @param identifier identifiant
   * @param session session
   * @param throwable exception
   */
  @OnError
  public void onError(@PathParam(PARAMETER_SOCKET_IDENTIFIER) String identifier, Session session,
      Throwable throwable) {
    sessions.remove(identifier);
    LOGGER.log(Level.SEVERE, "Erreur de session. identifiant={0}, erreur={1}",
        new Object[] {identifier, throwable});
  }

  /**
   * Cette méthode permet de réagir lorsqu'un message est reçu.
   *
   * @param identifier identifiant
   * @param message message
   */
  @OnMessage
  public void onMessage(@PathParam(PARAMETER_SOCKET_IDENTIFIER) String identifier, String message) {
    LOGGER.log(Level.FINEST, "Message de session. identifiant={0}, message={1}",
        new Object[] {identifier, message});
  }

  /**
   * Cette méthode permet d'envoyer une message.
   *
   * @param identifier identifiant de la session
   * @param message message
   */
  public void send(String identifier, String message) {
    sessions.get(identifier).getAsyncRemote().sendText(message);
    LOGGER.log(Level.FINEST, "Message envoyé. identifiant={0}, message={1}",
        new Object[] {identifier, message});
  }

  public static final String PARAMETER_SOCKET_IDENTIFIER = "identifier";
}
