package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DataEntityDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DataEntityDto}.

    @author Christian
               """)
public interface DataEntityRequestMapper
    extends RequestMapper<DataEntityDto, DataEntityCreateRequestDto, DataEntityUpdateRequestDto> {

}
