package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenConsumeRequestDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenConsumeResponseDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenCreateRequestDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenCreateResponseDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenGetManyResponseDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenRevokeRequestDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenRevokeResponseDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenVerifyRequestDto;
import ci.gouv.dgbf.system.token.server.api.TokenService.TokenVerifyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

/**
 * Cette classe représente un client de {@link TokenService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class TokenClient extends AbstractClient<TokenService>
    implements GetMany<TokenGetManyResponseDto>, GetByIdentifier<TokenDto> {

  @Override
  public TokenClient service(TokenService service) {
    return (TokenClient) super.service(service);
  }

  /**
   * {@link TokenService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenCreateResponseDto create(TokenCreateRequestDto request) {
    return new Executor<>(TokenCreateResponseDto.class, TokenService.CREATE_IDENTIFIER,
        Response.Status.CREATED.getStatusCode()).execute(() -> service().create(request));
  }

  /**
   * {@link TokenService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TokenGetManyResponseDto>(TokenGetManyResponseDto.class,
        TokenService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link TokenService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TokenGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TokenService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TokenDto>(TokenDto.class, TokenService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link TokenService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TokenDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TokenService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TokenDto>(TokenDto.class, TokenService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TokenService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TokenDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TokenService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(TokenService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link TokenService#verify}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenVerifyResponseDto verify(TokenVerifyRequestDto request) {
    return new GetOneExecutor<>(TokenVerifyResponseDto.class, TokenService.VERIFY_IDENTIFIER)
        .execute(() -> service().verify(request));
  }

  /**
   * {@link TokenService#consume}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenConsumeResponseDto consume(TokenConsumeRequestDto request) {
    return new GetOneExecutor<>(TokenConsumeResponseDto.class, TokenService.CONSUME_IDENTIFIER)
        .execute(() -> service().consume(request));
  }

  /**
   * {@link TokenService#revoke}.
   *
   * @param request requête
   * @return réponse
   */
  public TokenRevokeResponseDto revoke(TokenRevokeRequestDto request) {
    return new GetOneExecutor<>(TokenRevokeResponseDto.class, TokenService.REVOKE_IDENTIFIER)
        .execute(() -> service().revoke(request));
  }
}
