package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entrée en lecture du journal du Fichier (RG_FILE_FIC_23) : ajout
 * d'un exemplaire, modification des informations ou de l'Exemplaire physique. Une valeur de date
 * est écrite au format ISO ({@code AAAA-MM-JJ}) ; pour l'ajout d'un contenu binaire, la valeur est
 * son empreinte.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileJournalEntryDto extends AbstractIdentifiableDto {

  public static final String NAME = "entrée du journal de fichier";
  public static final String PLURAL_NAME = "entrées du journal de fichier";

  @JsonbProperty(JSON_ORDER)
  private Long order;

  @JsonbProperty(JSON_EVENT_DATE)
  private LocalDateTime eventDate;

  @JsonbProperty(JSON_EVENT_TYPE)
  private FileJournalEventType eventType;

  @JsonbProperty(JSON_FIELD_KIND)
  private FileJournalFieldKind fieldKind;

  @JsonbProperty(JSON_OLD_VALUE)
  private String oldValue;

  @JsonbProperty(JSON_VALUE)
  private String value;

  @JsonbProperty(JSON_ACTOR_IDENTIFIER)
  private String actorIdentifier;

  public static final String JSON_ORDER = "ordre";
  public static final String JSON_EVENT_DATE = "dateEvenement";
  public static final String JSON_EVENT_TYPE = "typeEvenement";
  public static final String JSON_FIELD_KIND = "champConcerne";
  public static final String JSON_OLD_VALUE = "ancienneValeur";
  public static final String JSON_VALUE = "valeur";
  public static final String JSON_ACTOR_IDENTIFIER = "identifiantActeur";
  public static final String JSON_FILE_IDENTIFIER = "identifiantFichier";
}
