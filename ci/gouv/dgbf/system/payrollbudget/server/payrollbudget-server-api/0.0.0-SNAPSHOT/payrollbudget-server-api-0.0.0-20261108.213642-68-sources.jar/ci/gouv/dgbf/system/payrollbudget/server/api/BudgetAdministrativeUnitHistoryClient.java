package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitHistoryService.BudgetAdministrativeUnitHistoryGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service de l'historique des états d'une unité administrative de budget.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BudgetAdministrativeUnitHistoryClient
    extends AbstractClient<BudgetAdministrativeUnitHistoryService>
    implements OneRetrievable<BudgetAdministrativeUnitHistoryDto>,
    GetByIdentifier<BudgetAdministrativeUnitHistoryDto>,
    GetMany<BudgetAdministrativeUnitHistoryGetManyResponseDto> {

  @Override
  public BudgetAdministrativeUnitHistoryClient service(
      BudgetAdministrativeUnitHistoryService service) {
    return (BudgetAdministrativeUnitHistoryClient) super.service(service);
  }

  /**
   * Recherche multicritère des transitions d'état.
   *
   * @param request critères, projection et pagination
   * @return les transitions correspondantes
   */
  public BudgetAdministrativeUnitHistoryGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitHistoryGetManyResponseDto>(
        BudgetAdministrativeUnitHistoryGetManyResponseDto.class,
        BudgetAdministrativeUnitHistoryService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public BudgetAdministrativeUnitHistoryGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'une transition unique.
   *
   * @param request critères et projection
   * @return la transition correspondante
   */
  public BudgetAdministrativeUnitHistoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitHistoryDto>(
        BudgetAdministrativeUnitHistoryDto.class,
        BudgetAdministrativeUnitHistoryService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  @Override
  public BudgetAdministrativeUnitHistoryDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'une transition par son identifiant.
   *
   * @param request identifiant et projection
   * @return la transition correspondante
   */
  public BudgetAdministrativeUnitHistoryDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitHistoryDto>(
        BudgetAdministrativeUnitHistoryDto.class,
        BudgetAdministrativeUnitHistoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public BudgetAdministrativeUnitHistoryDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
