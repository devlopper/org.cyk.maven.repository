package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les opérations.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class OperationFilter extends AbstractIdentifiableFilter {

  private String processIdentifier;
  private String moduleIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public OperationFilter() {}

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public OperationFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    processIdentifier = getProcessIdentifier(filter);
    moduleIdentifier = getModuleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setProcessIdentifier(filter, processIdentifier);
    setModuleIdentifier(filter, moduleIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du processus.
   *
   * @param filter filtre
   * @param processIdentifier identifiant du processus
   */
  public static void setProcessIdentifier(FilterDto filter, String processIdentifier) {
    set(filter, HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(processIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du processus.
   *
   * @param filter filtre
   * @return identifiant du processus
   */
  public static String getProcessIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du module.
   *
   * @param filter filtre
   * @param moduleIdentifier identifiant du module
   */
  public static void setModuleIdentifier(FilterDto filter, String moduleIdentifier) {
    set(filter, HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(moduleIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du module.
   *
   * @param filter filtre
   * @return identifiant du module
   */
  public static String getModuleIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER));
  }
}
