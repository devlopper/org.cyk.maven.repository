package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Objects;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le gestionnaire de {@link ProcessingStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class ProcessingStatusManager {

  @Getter
  @Setter
  String createdStyleClass;
  
  @Getter
  @Setter
  String startedStyleClass;
  
  @Getter
  @Setter
  String stoppedStyleClass;
  
  @Getter
  @Setter
  String canceledStyleClass;
  
  @Getter
  @Setter
  String terminatedStyleClass;

  @Getter
  @Setter
  Function<ProcessingStatus, String> nameBuilder;
  
  /**
   * Cette méthode permet d'instanctier.
   */
  public ProcessingStatusManager() {
    createdStyleClass = "processing-status-badge-created";
    startedStyleClass = "processing-status-badge-started";
    stoppedStyleClass = "processing-status-badge-stopped";
    canceledStyleClass = "processing-status-badge-canceled";
    terminatedStyleClass = "processing-status-badge-terminated";
  }
  
  /**
   * Cette méthode permet de transformer le nom.
   *
   * @param status {@link ProcessingStatus}
   * @return nom transformé
   */
  public String buildName(ProcessingStatus status) {
    if (nameBuilder != null) {
      return nameBuilder.apply(status);
    }
    return status.getName();
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link ProcessingStatus#CREATED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link ProcessingStatus#CREATED}
   */
  public boolean isNameCreated(String name) {
    return Objects.equals(ProcessingStatus.CREATED.getName(), name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link ProcessingStatus#STARTED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link ProcessingStatus#STARTED}
   */
  public boolean isNameStarted(String name) {
    return Objects.equals(ProcessingStatus.STARTED.getName(), name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link ProcessingStatus#STOPPED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link ProcessingStatus#STOPPED}
   */
  public boolean isNameStopped(String name) {
    return Objects.equals(ProcessingStatus.STOPPED.getName(), name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link ProcessingStatus#CANCELLED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link ProcessingStatus#CANCELLED}
   */
  public boolean isNameCanceled(String name) {
    return Objects.equals(ProcessingStatus.CANCELLED.getName(), name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link ProcessingStatus#TERMINATED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link ProcessingStatus#TERMINATED}
   */
  public boolean isNameTerminated(String name) {
    return Objects.equals(ProcessingStatus.TERMINATED.getName(), name);
  }

}
