package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de source
 * de financement.
 *
 * @author Christian
 */
public interface HasLessorAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la source de
   * financement.
   *
   * @return représentation en chaine de caractères de la bailleur
   */
  String getLessorAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de la source de
   * financement.
   *
   * @param asString représentation en chaine de caractères de la bailleur
   */
  void setLessorAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de la bailleur.
   */
  String FIELD_LESSOR_AS_STRING = "lessorAsString";
}
