package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Named
@ViewScoped
public class AbstractDictionaryEntryListPage extends AbstractPage {

  @Inject
  @Getter
  protected DictionaryEntryController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + DictionaryEntryDto.PLURAL_NAME;
    initializeController();
  }

  protected void initializeController() {
    controller.initialize();
  }
}
