package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Cette classe représente la description proposée d'un Fichier, tirée d'un contenu binaire et de
 * son nom de fichier avant la création (RG_FILE_FIC_24) : Nom, Description et Date de production,
 * chacun facultatif. Simple proposition : rien n'est enregistré.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class FileDescriptionProposalDto {

  /**
   * Nom proposé : nom du fichier sans son extension.
   */
  @JsonbProperty(value = JSON_NAME)
  private String name;

  /**
   * Description proposée (comme dans {@link FileDto}).
   */
  @JsonbProperty(value = JSON_DESCRIPTION)
  private String description;

  /**
   * Date de production proposée : date de création portée par le document, à n'appliquer que si
   * l'original est numérique.
   */
  @JsonbProperty(value = JSON_PRODUCTION_DATE)
  private LocalDate productionDate;

  /**
   * Date de production proposée, en chaîne.
   */
  @JsonbProperty(value = JSON_PRODUCTION_DATE_AS_STRING)
  private String productionDateAsString;

  /**
   * Vrai si la date proposée est écrite dans le document (« Date : », « …, le … ») : elle vaut
   * alors quel que soit l'original ; faux pour une date technique du fichier, à n'appliquer que si
   * l'original est numérique ; nul sans date proposée (RG_FILE_FIC_24).
   */
  @JsonbProperty(value = JSON_WRITTEN_PRODUCTION_DATE)
  private Boolean writtenProductionDate;

  /**
   * Identifiant JSON {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  /**
   * Identifiant JSON {@link #description}.
   */
  public static final String JSON_DESCRIPTION = FileDto.JSON_DESCRIPTION;

  /**
   * Identifiant JSON {@link #productionDate}.
   */
  public static final String JSON_PRODUCTION_DATE = FileDto.JSON_PRODUCTION_DATE;

  /**
   * Identifiant JSON {@link #productionDateAsString}.
   */
  public static final String JSON_PRODUCTION_DATE_AS_STRING =
      FileDto.JSON_PRODUCTION_DATE_AS_STRING;

  /**
   * Identifiant JSON {@link #writtenProductionDate}.
   */
  public static final String JSON_WRITTEN_PRODUCTION_DATE = "dateProductionEcrite";
}
