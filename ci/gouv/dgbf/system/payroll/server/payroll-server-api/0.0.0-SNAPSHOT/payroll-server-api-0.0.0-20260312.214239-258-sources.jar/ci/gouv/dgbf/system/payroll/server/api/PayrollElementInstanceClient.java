package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollElementInstanceService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollElementInstanceClient extends AbstractClient<PayrollElementInstanceService>
    implements GetByIdentifier<PayrollElementInstanceDto>, 
    GetMany<PayrollElementInstanceGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollElementInstanceClient service(PayrollElementInstanceService service) {
    return (PayrollElementInstanceClient) super.service(service);
  }

  /**
   * {@link PayrollElementInstanceService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollElementInstanceCreateRequestDto request) {
    return new CreateExecutor(PayrollElementInstanceService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollElementInstanceService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementInstanceGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementInstanceGetManyResponseDto>(
        PayrollElementInstanceGetManyResponseDto.class,
        PayrollElementInstanceService.GET_MANY_IDENTIFIER
    ).execute(() -> service().getMany(request));
  }


  /**
   * {@link PayrollElementInstanceService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public PayrollElementInstanceGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementInstanceService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementInstanceDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollElementInstanceDto>(PayrollElementInstanceDto.class,
        PayrollElementInstanceService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollElementInstanceService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementInstanceDto getOne(ProjectionDto projection, FilterDto filter, 
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollElementInstanceService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollElementInstanceDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementInstanceDto>(PayrollElementInstanceDto.class,
        PayrollElementInstanceService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollElementInstanceService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollElementInstanceDto getByIdentifier(String identifier,
                       ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollElementInstanceService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollElementInstanceUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollElementInstanceService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollElementInstanceService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollElementInstanceService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollElementInstanceService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
