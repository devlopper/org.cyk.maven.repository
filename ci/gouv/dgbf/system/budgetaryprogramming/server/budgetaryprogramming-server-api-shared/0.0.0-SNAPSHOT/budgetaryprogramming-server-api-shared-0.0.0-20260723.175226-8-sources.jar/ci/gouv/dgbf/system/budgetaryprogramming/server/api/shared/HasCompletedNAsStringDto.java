package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N est complétée, sous forme de
 * chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedNAsStringDto extends HasCompletedNAsString {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N est complétée, sous forme de chaîne de
   * caractères.
   */
  String JSON_COMPLETED_N_AS_STRING = "completeNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
