package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Énumération représentant le type d'anomalie inter-modules.
 */
@Getter
public enum AnomalyType implements CodableByStringWithGetterOnly {

  /**
   * Écart sur les données civiles.
   */
  ECART_DONNEES_CIVILES(AnomalyTypeCode.ECART_DONNEES_CIVILES, "Écart sur les données civiles"),

  /**
   * Matricule inconnu dans le référentiel RH.
   */
  MATRICULE_INCONNU(AnomalyTypeCode.MATRICULE_INCONNU,
      "Matricule inconnu dans le référentiel RH"),

  /**
   * Adresse email déjà liée à une identité active.
   */
  EMAIL_DEJA_ENREGISTRE(AnomalyTypeCode.EMAIL_DEJA_ENREGISTRE,
      "Adresse email déjà liée à une identité active");

  private final String code;
  private final String name;

  AnomalyType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  /**
   * Recherche un type d'anomalie par son code.
   *
   * @param code code à rechercher
   * @return type d'anomalie correspondant
   */
  public static AnomalyType getByCode(String code) {
    if (code == null) {
      return null;
    }
    for (AnomalyType value : values()) {
      if (value.code.equals(code)) {
        return value;
      }
    }
    throw new IllegalArgumentException("Code de type d'anomalie inconnu : " + code);
  }
}

