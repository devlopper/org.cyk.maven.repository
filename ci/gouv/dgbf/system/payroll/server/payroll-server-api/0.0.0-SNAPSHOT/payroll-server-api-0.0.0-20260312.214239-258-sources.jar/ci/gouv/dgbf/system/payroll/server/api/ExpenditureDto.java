package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetCategoryAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetCategoryIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetSpecializationUnitAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetSpecializationUnitIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasSectionAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasSectionIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentCategoryAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentCategoryIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépense.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureDto extends AbstractIdentifiableAuditableDto
      implements HasSectionIdentifierDto, HasSectionAsStringDto, HasActivityIdentifierDto,
      HasActivityAsStringDto, HasEconomicNatureIdentifierDto, HasEconomicNatureAsStringDto,
      HasBudgetCategoryIdentifierDto, HasBudgetCategoryAsStringDto,
      HasPayrollComponentCategoryIdentifierDto, HasPayrollComponentCategoryAsStringDto,
      HasBudgetSpecializationUnitIdentifierDto, HasBudgetSpecializationUnitAsStringDto {

  /**
   * Année d'exercice .
   */
  @JsonbProperty(JSON_EXERCISE_YEAR)
  private String exerciseYear;


  /**
   * Identifiant de l'activité .
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /**
   * Représentation en chaine de caractères de l'activité .
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Identifiant de la nature économique .
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Représentation en chaine de caractères de la nature économique .
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;


  /**
   * Budget actuel .
   */
  @JsonbProperty(JSON_ACTUAL_BUDGET)
  private Long actualBudget;

  /**
   * Représentation en chaine de caractères du Budget actuel .
   */
  @JsonbProperty(JSON_ACTUAL_BUDGET_AS_STRING)
  private String actualBudgetAsString;

  /**
   * Budget initial .
   */
  @JsonbProperty(JSON_INITIAL_BUDGET)
  private Long initialBudget;

  /**
   * Représentation en chaine de caractères du Budget initial .
   */
  @JsonbProperty(JSON_INITIAL_BUDGET_AS_STRING)
  private String initialBudgetAsString;

  /**
   * Montant engagé .
   */
  @JsonbProperty(JSON_COMMITTED_AMOUNT)
  private Long committedAmount;

  /**
   * Représentation en chaine de caractères du Montant engagé .
   */
  @JsonbProperty(JSON_COMMITTED_AMOUNT_AS_STRING)
  private String committedAmountAsString;

  /**
   * Montant disponible .
   */
  @JsonbProperty(JSON_AVAILABLE_AMOUNT)
  private Long availableAmount;

  /**
   * Représentation en chaine de caractères du Montant disponible .
   */
  @JsonbProperty(JSON_AVAILABLE_AMOUNT_AS_STRING)
  private String availableAmountAsString;

  /**
   * Montant à engager .
   */
  @JsonbProperty(JSON_AMOUNT_TO_COMMIT)
  private Long amountToCommit;

  /**
   * Représentation en chaine de caractères du Montant à engager .
   */
  @JsonbProperty(JSON_AMOUNT_TO_COMMIT_AS_STRING)
  private String amountToCommitAsString;


  /**
   * Montant potentiellement disponible .
   */
  @JsonbProperty(JSON_POTENTIAL_AVAILABLE_AMOUNT)
  private Long potentialAvailableAmount;

  /**
   * Représentation en chaine de caractères du Montant potentiellement disponible .
   */
  @JsonbProperty(JSON_POTENTIAL_AVAILABLE_AMOUNT_AS_STRING)
  private String potentialAvailableAmountAsString;

  @JsonbProperty(JSON_SECTION_IDENTIFIER)
  private String sectionIdentifier;

  @JsonbProperty(JSON_SECTION_AS_STRING)
  private String sectionAsString;


  @JsonbProperty(JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER)
  private String budgetSpecializationUnitIdentifier;

  @JsonbProperty(JSON_BUDGET_SPECIALIZATION_UNIT_AS_STRING)
  private String budgetSpecializationUnitAsString;

  @JsonbProperty(JSON_BUDGET_CATEGORY_IDENTIFIER)
  private String budgetCategoryIdentifier;

  @JsonbProperty(JSON_BUDGET_CATEGORY_AS_STRING)
  private String budgetCategoryAsString;

  @JsonbProperty(JSON_PAYROLL_COMPONENT_CATEGORY_IDENTIFIER)
  private String payrollComponentCategoryIdentifier;

  @JsonbProperty(JSON_PAYROLL_COMPONENT_CATEGORY_AS_STRING)
  private String payrollComponentCategoryAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDepense";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "depenseChaine";

  /**
   * Identifiant champ json {@link #exerciseYear}.
   */
  public static final String JSON_EXERCISE_YEAR = "anneeExercice";

  /**
   * Identifiant champ json {@link #actualBudget}.
   */
  public static final String JSON_ACTUAL_BUDGET = "budgetActuel";

  /**
   * Identifiant champ json {@link #actualBudgetAsString}.
   */
  public static final String JSON_ACTUAL_BUDGET_AS_STRING = "budgetActuelChaine";

  /**
   * Identifiant champ json {@link #initialBudget}.
   */
  public static final String JSON_INITIAL_BUDGET = "budgetInitial";


  /**
   * Identifiant champ json {@link #initialBudgetAsString}.
   */
  public static final String JSON_INITIAL_BUDGET_AS_STRING = "budgetInitialChaine";

  /**
   * Identifiant champ json {@link #committedAmount}.
   */
  public static final String JSON_COMMITTED_AMOUNT = "montantEngage";

  /**
   * Identifiant champ json {@link #committedAmountAsString}.
   */
  public static final String JSON_COMMITTED_AMOUNT_AS_STRING = "montantEngageChaine";

  /**
   * Identifiant champ json {@link #availableAmount}.
   */
  public static final String JSON_AVAILABLE_AMOUNT = "montantDisponible";


  /**
   * Identifiant champ json {@link #availableAmountAsString}.
   */
  public static final String JSON_AVAILABLE_AMOUNT_AS_STRING = "montantDisponibleChaine";

  /**
   * Identifiant champ json {@link #amountToCommit}.
   */
  public static final String JSON_AMOUNT_TO_COMMIT = "montantAEngager";

  /**
   * Identifiant champ json {@link #amountToCommitAsString}.
   */
  public static final String JSON_AMOUNT_TO_COMMIT_AS_STRING = "montantAEngagerChaine";

  /**
   * Identifiant champ json {@link #potentialAvailableAmount}.
   */
  public static final String JSON_POTENTIAL_AVAILABLE_AMOUNT = "montantPotentiellementDisponible";

  /**
   * Identifiant champ json {@link #potentialAvailableAmountAsString}.
   */
  public static final String JSON_POTENTIAL_AVAILABLE_AMOUNT_AS_STRING =
       "montantPotentiellementDisponibleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dépense";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

}

