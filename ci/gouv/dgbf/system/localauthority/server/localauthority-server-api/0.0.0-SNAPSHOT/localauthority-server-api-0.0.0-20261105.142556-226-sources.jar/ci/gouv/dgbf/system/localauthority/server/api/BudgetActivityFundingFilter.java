package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetActivityFundingDto}.
 *
 * @author Donsylla
 */
@Getter
@Setter
public class BudgetActivityFundingFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link BudgetActivityDto}.
   */
  String budgetActivityIdentifier;

  /**
   * Identifiant {@link BudgetDto}.
   */
  String budgetIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetActivityFundingFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetActivityFundingFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    budgetActivityIdentifier = getBudgetActivityIdentifier(filter);
    budgetIdentifier = getBudgetIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setBudgetActivityIdentifier(filter, budgetActivityIdentifier);
    setBudgetIdentifier(filter, budgetIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link BudgetActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link BudgetActivityDto}
   */
  public static String getBudgetActivityIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_BUDGET_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link BudgetActivityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link BudgetActivityDto}
   */
  public static void setBudgetActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BUDGET_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
   *
   * @param filter filtre
   * @return identifiant {@link BudgetDto}
   */
  public static String getBudgetIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_BUDGET_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link BudgetDto}
   */
  public static void setBudgetIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BUDGET_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #budgetActivityIdentifier}.
   */
  public static final String JSON_BUDGET_ACTIVITY_IDENTIFIER =
      BudgetActivityFundingDto.JSON_BUDGET_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER =
      BudgetActivityFundingDto.JSON_BUDGET_IDENTIFIER;
}
