package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'unité administrative de budget.
 *
 * @author Christian
 */
public interface HasBudgetAdministrativeUnitIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité administrative de budget.
   *
   * @return identifiant de l'unité administrative de budget
   */
  String getBudgetAdministrativeUnitIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de l'unité administrative de budget.
   *
   * @param identifier identifiant de l'unité administrative de budget
   */
  void setBudgetAdministrativeUnitIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de l'unité administrative de budget.
   */
  String FIELD_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER = "budgetAdministrativeUnitIdentifier";
}