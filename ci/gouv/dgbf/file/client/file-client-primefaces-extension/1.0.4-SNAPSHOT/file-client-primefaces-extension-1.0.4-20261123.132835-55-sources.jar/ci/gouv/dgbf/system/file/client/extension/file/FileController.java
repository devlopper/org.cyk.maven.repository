package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController.FormLayout;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDescriptionProposalDto;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService;
import ci.gouv.dgbf.system.file.server.api.FileService.FileConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileStatus;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Objects;
import java.util.function.UnaryOperator;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileController extends AbstractController {

  private static final Logger LOGGER = Logger.getLogger(FileController.class.getName());

  @Inject
  FileClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileRequestMapper requestMapper;

  @Inject
  @Getter
  FileFilterController filterController;

  /**
   * Contrôleur du bouton de Confirmation (RG_FILE_FIC_09), affiché dans la colonne Action de la
   * liste. Sa priorité secondaire le place dans le menu « plus » lorsque la limite de trois
   * actions visibles est atteinte (RG_FILE_UI_03).
   */
  @Inject
  @Getter
  IdentifiableProcessingController confirmProcessingController;

  @Inject
  @Getter
  FileJournalDialogController journalDialogController;

  @Inject
  @Getter
  FileEvolutionController evolutionController;

  /**
   * Nature du support choisie en tête du formulaire de création (NUMERIQUE, PHYSIQUE ou HYBRIDE) :
   * elle décide des sections affichées et de ce qui est envoyé au serveur, qui la redéduit des
   * exemplaires reçus (RG_FILE_FIC_17).
   */
  @Getter
  @Setter
  private String mediumNatureCode = MediumNature.DIGITAL.getCode();

  @Getter
  @Setter
  private String physicalItemHolder;

  @Getter
  @Setter
  private String physicalItemContainer;

  @Getter
  @Setter
  private String physicalItemExtent;

  @Getter
  @Setter
  private String physicalItemCondition;

  @Getter
  @Setter
  // Pas de valeur par défaut : pour un Fichier hybride, l'original est un choix conscient et
  // définitif (RG_FILE_FIC_17).
  private String originalMediumCode;

  /**
   * Nom du contenu binaire déposé, gardé à part du champ Nom : il sert de nom quand ce champ est
   * laissé vide (« Nom (facultatif) »), même si le champ a été réaffiché vide après un refus.
   */
  @Getter
  private String uploadedFileName;

  /**
   * Description proposée à partir du contenu déposé (RG_FILE_FIC_24) : le formulaire en remplit
   * les champs vides dans le navigateur. Jamais nulle, vide sans contenu déposé.
   */
  @Getter
  private FileDescriptionProposalDto descriptionProposal = new FileDescriptionProposalDto();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Fichiers";

    listController.setEntityClass(FileDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileDto.JSON_MODULE_IDENTIFIER,
        FileDto.JSON_NAME, FileDto.JSON_CONTENT_TYPE,
        FileDto.JSON_NUMBER_OF_BYTES_AS_STRING, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING,
        FileDto.JSON_MEDIUM_NATURE, FileDto.JSON_MEDIUM_NATURE_AS_STRING,
        FileDto.JSON_CONTENT_FORM, FileDto.JSON_CONTENT_FORM_AS_STRING,
        FileDto.JSON_DESCRIPTION, FileDto.JSON_PRODUCTION_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(6);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.getDataTable().setHeaderRendered(false);
    listController.getDataTable().setGlobalFilterRendered(true);
    listController.setFormLayout(FormLayout.STACKED);
    listController.initialize();

    initializeConfirmProcessing();
    evolutionController.setListController(listController);

    listController.getCreateController().setFunction(entity -> {
      FileDto file = (FileDto) entity;
      FileCreateRequestDto request = new FileCreateRequestDto();
      // Module saisi, seul rattachement du Fichier (TCH_FILE_554) : obligatoire dans le
      // formulaire, sans quoi FileClient y substituerait le module de cette application
      // (caller.module.identifier).
      request.setModuleIdentifier(file.getModuleIdentifier());
      request.setName(isBinaryContentExpected() && Core.isStringBlank(file.getName())
          && file.getBytes() != null ? defaultName() : file.getName());
      // Seul ce que la nature choisie attend est envoyé : un contenu binaire resté d'un essai
      // précédent ne transforme pas un Fichier physique en hybride, ni l'inverse.
      request.setBytes(isBinaryContentExpected() ? file.getBytes() : null);
      request.setDescription(file.getDescription());
      if (file.getProductionDate() != null) {
        request.setProductionDate(file.getProductionDate().toString());
      }
      if (isPhysicalItemExpected()) {
        request.setHolder(physicalItemHolder);
        request.setContainer(physicalItemContainer);
        request.setPhysicalExtent(physicalItemExtent);
        request.setPhysicalCondition(physicalItemCondition);
        // Support d'origine : déclaré seulement pour un Fichier hybride ; sinon le serveur le
        // déduit (RG_FILE_FIC_17).
        request.setOriginalMedium(isHybrid() ? originalMediumCode : null);
      }
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    // Depuis l'onglet d'un module (TCH_FILE_554), le Fichier y est rattaché sans saisie : le module
    // de l'onglet est celui du filtre, renseigné par FileFilterController.
    listController.getCreateController().addEntityConsumer(entity -> {
      ((FileDto) entity).setModuleIdentifier(filterController.getFilter().getModuleIdentifier());
      resetPhysicalItemFields();
    });

    // Voir, Exemplaire papier (Fichier hybride), Journal, Supprimer, et Confirmer (Fichier Créé).
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(6);
    listController.getShowUpdateDialogButton().setRendered(false);
  }

  /**
   * Réinitialise les champs de saisie du support physique.
   */
  public void resetPhysicalItemFields() {
    mediumNatureCode = MediumNature.DIGITAL.getCode();
    physicalItemHolder = null;
    physicalItemContainer = null;
    physicalItemExtent = null;
    physicalItemCondition = null;
    originalMediumCode = null;
    uploadedFileName = null;
    descriptionProposal = new FileDescriptionProposalDto();
  }

  /**
   * Cette méthode permet de réagir au téléchargement d'un fichier : le contenu est gardé pour la
   * création et la description proposée est demandée au serveur (RG_FILE_FIC_24).
   *
   * @param event évènement
   */
  public void handleFileUpload(FileUploadEvent event) {
    FileDto file = createEntity();
    uploadedFileName = event.getFile().getFileName();
    file.setBytes(event.getFile().getContent());
    descriptionProposal = proposeDescription(file.getBytes(), uploadedFileName);
  }

  /**
   * Demande la description proposée ; un échec ne bloque jamais le dépôt (proposition vide).
   *
   * @param bytes octets déposés
   * @param fileName nom du fichier déposé
   * @return description proposée, jamais nulle
   */
  FileDescriptionProposalDto proposeDescription(byte[] bytes, String fileName) {
    try {
      FileDescriptionProposalDto proposal =
          client.getProposedDescription(bytes, fileName, userIdentifier, null);
      return proposal == null ? new FileDescriptionProposalDto() : proposal;
    } catch (RuntimeException exception) {
      LOGGER.log(Level.WARNING, "Description proposée indisponible pour " + fileName, exception);
      return new FileDescriptionProposalDto();
    }
  }

  /**
   * Nom retenu quand le champ Nom est laissé vide : le Nom proposé, à défaut le nom du fichier
   * déposé.
   *
   * @return nom par défaut
   */
  String defaultName() {
    return Core.isStringBlank(descriptionProposal.getName()) ? uploadedFileName
        : descriptionProposal.getName();
  }

  /**
   * Indique si un fichier a été téléversé pour la création en cours.
   *
   * @return {@code true} si le fichier peut être retiré avant l'enregistrement
   */
  public boolean hasUploadedFile() {
    FileDto file = createEntity();
    return file != null && file.getBytes() != null;
  }

  /**
   * Indique si la nature choisie attend un contenu binaire (Numérique ou Hybride).
   *
   * @return {@code true} si la section de dépôt est affichée
   */
  public boolean isBinaryContentExpected() {
    return !MediumNature.PHYSICAL.getCode().equals(mediumNatureCode);
  }

  /**
   * Indique si la nature choisie attend un Exemplaire physique (Physique ou Hybride).
   *
   * @return {@code true} si la section du papier est affichée
   */
  public boolean isPhysicalItemExpected() {
    return !MediumNature.DIGITAL.getCode().equals(mediumNatureCode);
  }

  /**
   * Indique si la nature choisie est Hybride (contenu binaire et papier).
   *
   * @return {@code true} si le choix de l'original est affiché
   */
  public boolean isHybrid() {
    return MediumNature.HYBRID.getCode().equals(mediumNatureCode);
  }

  /**
   * Réagit au changement de nature : un contenu binaire déjà déposé est retiré si la nature n'en
   * attend plus (Physique), pour que l'écran montre ce qui sera vraiment envoyé.
   */
  public void onMediumNatureChange() {
    if (!isBinaryContentExpected()) {
      removeUploadedFile();
    }
  }

  /**
   * Témoin du contenu binaire déposé, lu par un champ caché obligatoire du formulaire : la
   * validation JSF signale ainsi l'absence de contenu pour une nature qui en attend un.
   *
   * @return une valeur non vide si un contenu binaire est déposé, {@code null} sinon
   */
  public String getBinaryContentMarker() {
    return hasUploadedFile() ? "1" : null;
  }

  /**
   * Sans effet : le témoin se déduit du contenu déposé (requis par le champ caché).
   *
   * @param marker valeur soumise, ignorée
   */
  public void setBinaryContentMarker(String marker) {
    // Valeur dérivée de l'entité en cours de création : rien à mémoriser.
  }

  /** Retire le fichier téléversé de la création en cours, avant toute persistance. */
  public void removeUploadedFile() {
    FileDto file = createEntity();
    if (file != null) {
      // Ce qui était proposé à partir du contenu part avec lui (effacé aussi dans le navigateur) ;
      // une saisie reste.
      if (Objects.equals(descriptionProposal.getName(), file.getName())) {
        file.setName(null);
      }
      file.setBytes(null);
    }
    uploadedFileName = null;
    descriptionProposal = new FileDescriptionProposalDto();
  }

  /**
   * Indique si le champ Module est saisi : seulement hors de l'onglet d'un module, qui le fixe.
   *
   * @return {@code true} sur l'onglet « Tout »
   */
  public boolean isModuleInputRendered() {
    return filterController.getFilter().getModuleIdentifier() == null;
  }

  private FileDto createEntity() {
    return (FileDto) listController.getCreateController().getEntity();
  }

  /**
   * Cette méthode permet de savoir si un Fichier peut être confirmé dans l'état où il se trouve
   * (RG_FILE_FIC_09) : encore "Créé" (provisoire), jamais une fois "Confirmé" (RG_FILE_FIC_08,
   * statut terminal).
   *
   * @param file fichier
   * @return {@code true} si le fichier peut être confirmé
   */
  public boolean confirmable(FileDto file) {
    return FileStatus.CREATED.equals(file.getStatus());
  }

  /**
   * Cette méthode permet d'initialiser {@link #confirmProcessingController}, affiché dans la
   * colonne Action de la liste (RG_FILE_FIC_09), selon le mécanisme déjà établi pour ce type de
   * bouton d'action de statut (cf. {@code PayrollElementClaimController} du module
   * {@code payrollelementrequest}).
   */
  void initializeConfirmProcessing() {
    confirmProcessingController.setListController(listController);
    confirmProcessingController.prepareConfirmation(FileDto.class, "Confirmer", "pi pi-thumbs-up",
        confirmFunction());
    confirmProcessingController
        .setSubmitButtonControllerRenderedFunction(entity -> confirmable((FileDto) entity));
    confirmProcessingController.initialize();
  }

  /**
   * Cette méthode permet de confirmer un Fichier par son identifiant (RG_FILE_FIC_09).
   *
   * @return fonction de confirmation
   */
  UnaryOperator<Object> confirmFunction() {
    return identifier -> {
      FileConfirmRequestDto request = new FileConfirmRequestDto();
      request.setIdentifier((String) identifier);
      request.setAuditWho(userIdentifier);
      return client.confirm(request);
    };
  }
}
