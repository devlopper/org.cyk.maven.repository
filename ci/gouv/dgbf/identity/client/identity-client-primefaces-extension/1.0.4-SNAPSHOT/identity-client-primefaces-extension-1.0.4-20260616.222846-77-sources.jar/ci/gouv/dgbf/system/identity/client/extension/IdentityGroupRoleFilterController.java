package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link IdentityGroupRoleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityGroupRoleFilterController
    extends AbstractFilterController<IdentityGroupRoleFilter> {

  /**
   * Cette méthode permet d'instantier.
   */
  public IdentityGroupRoleFilterController() {
    super(IdentityGroupRoleFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setIdentityGroupIdentifier(
        getRequestParameter(IdentityGroupRoleFilter.JSON_IDENTITY_GROUP_IDENTIFIER));
    filter.setRoleIdentifier(getRequestParameter(IdentityGroupRoleFilter.JSON_ROLE_IDENTIFIER));
  }
}

