package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollJobGroupDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = PayrollJobGroupService.PATH)
@Tag(name = "Gestion des groupes d'emplois de paie")
public interface PayrollJobGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-emplois-paie";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface PayrollJobGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du type groupe emploi.
     *
     * @return identifiant du type groupe emploi
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du type groupe emploi.
     *
     * @param typeIdentifier identifiant du type groupe emploi
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la grille indiciaire.
     *
     * @return identifiant de la grille indiciaire
     */
    String getPayScaleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la grille indiciaire.
     *
     * @param payScaleIdentifier identifiant de la grille indiciaire
     */
    void setPayScaleIdentifier(String payScaleIdentifier);

    /**
     * {@link PayrollJobGroupDto#JSON_TYPE_IDENTIFIER}.
     */
    public static final String JSON_TYPE_IDENTIFIER = 
              PayrollJobGroupDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link PayrollJobGroupDto#JSON_PAY_SCALE_IDENTIFIER}.
     */
    public static final String JSON_PAY_SCALE_IDENTIFIER = 
              PayrollJobGroupDto.JSON_PAY_SCALE_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollJobGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class PayrollJobGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayrollJobGroupSaveRequestDto {

    /**
     * {@link PayrollJobGroupDto#getTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    /**
     * {@link PayrollJobGroupDto#getPayScaleIdentifier()}.
     */
    @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
    private String payScaleIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = 
            PayrollJobGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class PayrollJobGroupGetManyResponseDto extends 
                AbstractGetByPageResponseDto<PayrollJobGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollJobGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollJobGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollJobGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollJobGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class PayrollJobGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayrollJobGroupSaveRequestDto {

    /**
     * {@link PayrollJobGroupDto#getTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    /**
     * {@link PayrollJobGroupDto#getPayScaleIdentifier()}.
     */
    @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
    private String payScaleIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_EMPLOI_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollJobGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
