package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeObjectService.ClaimTypeObjectCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeObjectService.ClaimTypeObjectGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeObjectService.ClaimTypeObjectUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimTypeObjectService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimTypeObjectClient extends AbstractClient<ClaimTypeObjectService>
    implements GetByIdentifier<ClaimTypeObjectDto>, GetMany<ClaimTypeObjectGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimTypeObjectClient service(ClaimTypeObjectService service) {
    return (ClaimTypeObjectClient) super.service(service);
  }

  /**
   * {@link ClaimTypeObjectService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimTypeObjectGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimTypeObjectGetManyResponseDto>(
        ClaimTypeObjectGetManyResponseDto.class, ClaimTypeObjectService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimTypeObjectService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimTypeObjectGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimTypeObjectService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimTypeObjectCreateRequestDto request) {
    return new CreateExecutor(ClaimTypeObjectService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimTypeObjectService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimTypeObjectUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimTypeObjectService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimTypeObjectService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimTypeObjectDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimTypeObjectDto>(ClaimTypeObjectDto.class,
        ClaimTypeObjectService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimTypeObjectService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimTypeObjectDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimTypeObjectService#getByIdentifier}.
   *
   * @param request requête
   * @return rattachement
   */
  public ClaimTypeObjectDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimTypeObjectDto>(ClaimTypeObjectDto.class,
        ClaimTypeObjectService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimTypeObjectService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimTypeObjectDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimTypeObjectService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimTypeObjectService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimTypeObjectService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
