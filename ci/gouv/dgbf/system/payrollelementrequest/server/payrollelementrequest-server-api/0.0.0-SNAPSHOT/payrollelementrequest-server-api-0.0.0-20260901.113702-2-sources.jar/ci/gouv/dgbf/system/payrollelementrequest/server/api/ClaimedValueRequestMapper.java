package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimedValueDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimedValueDto}.

    @author akm
               """)
public interface ClaimedValueRequestMapper extends
    RequestMapper<ClaimedValueDto, ClaimedValueCreateRequestDto, ClaimedValueUpdateRequestDto> {

}
