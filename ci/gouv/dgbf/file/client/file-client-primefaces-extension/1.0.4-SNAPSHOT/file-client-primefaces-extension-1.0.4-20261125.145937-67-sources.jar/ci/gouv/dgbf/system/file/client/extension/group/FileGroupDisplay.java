package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Objects;

/**
 * Cette classe est la <b>seule</b> règle d'affichage du nom d'un Fichier de Groupe dans un contexte
 * de Groupe (liste, retrait, fiche) : le Nom effectif est le Nom dans le Groupe s'il existe, sinon
 * le nom du Fichier, et quand les deux diffèrent le nom du Fichier est toujours montré avec lui
 * (RG_FILE_CAT_11, DEC_FILE_04 D02). Tous les écrans d'un Groupe passent par {@link #label}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class FileGroupDisplay {

  /**
   * Séparateur entre le Nom dans le Groupe et le nom du Fichier.
   */
  static final String DOCUMENT_SEPARATOR = " — document : ";

  /**
   * Cette méthode retourne le Nom effectif.
   *
   * @param fileGroup rattachement
   * @return Nom dans le Groupe s'il existe, sinon nom du Fichier
   */
  public String name(FileGroupDto fileGroup) {
    if (fileGroup == null) {
      return null;
    }
    return Core.isStringBlank(fileGroup.getName()) ? fileGroup.getFileAsString()
        : fileGroup.getName();
  }

  /**
   * Cette méthode indique si le Nom dans le Groupe diffère du nom du Fichier.
   *
   * @param fileGroup rattachement
   * @return vrai si le rattachement porte un nom qui lui est propre et différent
   */
  public boolean isRenamed(FileGroupDto fileGroup) {
    return fileGroup != null && !Core.isStringBlank(fileGroup.getName())
        && !Objects.equals(fileGroup.getName(), fileGroup.getFileAsString());
  }

  /**
   * Cette méthode retourne le texte à afficher : le Nom effectif, suivi du nom du Fichier quand
   * ils diffèrent.
   *
   * @param fileGroup rattachement
   * @return texte affiché
   */
  public String label(FileGroupDto fileGroup) {
    if (isRenamed(fileGroup)) {
      return fileGroup.getName() + DOCUMENT_SEPARATOR + fileGroup.getFileAsString();
    }
    return name(fileGroup);
  }
}
