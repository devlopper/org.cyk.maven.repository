package ci.gouv.dgbf.system.file.client.extension.dashboard;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileDashboardChartCode;
import ci.gouv.dgbf.system.file.server.api.FileDashboardClient;
import ci.gouv.dgbf.system.file.server.api.FileDashboardFilter;
import ci.gouv.dgbf.system.file.server.api.FileDashboardKpiCode;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du tableau de bord du module Fichier (v1 hors archivage,
 * sur le modèle du pilote {@code DashboardController} du module {@code logging}).
 *
 * @author Christian
 *
 */
@Dependent
public class FileDashboardController extends AbstractController {

  private static final Logger LOGGER = Logger.getLogger(FileDashboardController.class.getName());

  /**
   * Couleurs sobres à contraste WCAG >= 4,5:1 sur fond blanc pour la répartition par support.
   */
  static final Map<String, String> MEDIUM_NATURE_COLORS = Map.of(
      MediumNature.DIGITAL.getName(), "#1d4ed8",
      MediumNature.PHYSICAL.getName(), "#b45309",
      MediumNature.HYBRID.getName(), "#047857");

  @Inject
  FileDashboardClient client;

  @Inject
  @Getter
  ChartController filesEvolutionChartController;

  @Inject
  @Getter
  ChartController filesByMediumNatureChartController;

  @Getter
  @Setter
  int periodDays = 30;

  /**
   * Composants dont les données n'ont pas pu être chargées : chacun s'affiche en état
   * « indisponible » et les autres restent affichés (constitution-ui.md 3.14).
   */
  final Set<String> unavailableComponents = new LinkedHashSet<>();

  /**
   * Un composant du tableau de bord = un appel au serveur (son code de graphique) et la façon de
   * lire sa réponse. Une panne ne touche que le composant concerné.
   */
  private final Map<String, Consumer<ChartDto>> processors = new LinkedHashMap<>();

  {
    processors.put(FileDashboardChartCode.KPIS, this::processKpis);
    processors.put(FileDashboardChartCode.FILES_EVOLUTION,
        chart -> processChart(filesEvolutionChartController, chart,
            FileDashboardChartCode.FILES_EVOLUTION, "Évolution des fichiers par jour",
            ChartController::buildLineChart));
    processors.put(FileDashboardChartCode.FILES_BY_MEDIUM_NATURE,
        chart -> processChart(filesByMediumNatureChartController, chart,
            FileDashboardChartCode.FILES_BY_MEDIUM_NATURE, "Répartition par nature du support",
            ChartController::buildBarChart));
  }

  @Getter
  long purgeEligible;

  @Getter
  long files;

  @Getter
  long fileGroups;

  @Getter
  long groupFiles;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Tableau de bord";
    for (ChartController controller : List.of(filesEvolutionChartController,
        filesByMediumNatureChartController)) {
      controller.setTitleDisplayed(false);
      controller.setLegendDisplayed(false);
      controller.setIntegerValues(true);
    }
    filesByMediumNatureChartController.setKeyColors(MEDIUM_NATURE_COLORS);
  }

  /**
   * Cette méthode permet d'initialiser les métriques et graphiques du tableau de bord : un appel
   * par composant, pour qu'une panne ne masque que le composant concerné.
   */
  public void initialize() {
    unavailableComponents.clear();
    processors.keySet().forEach(this::load);
  }

  /**
   * Cette méthode permet de recharger un seul composant.
   *
   * @param component code du composant
   */
  public void retry(String component) {
    load(component);
  }

  /**
   * Cette méthode permet de savoir si un composant n'a pas pu être chargé.
   *
   * @param component code du composant
   * @return vrai si ses données sont indisponibles
   */
  public boolean isUnavailable(String component) {
    return unavailableComponents.contains(component);
  }

  /**
   * Cette méthode permet de savoir si plusieurs composants sont indisponibles : la page porte alors
   * un seul bandeau avec un seul « Réessayer », au lieu d'un message dans chaque composant.
   *
   * @return vrai si au moins deux composants sont indisponibles
   */
  public boolean isSeveralUnavailable() {
    return unavailableComponents.size() > 1;
  }

  void load(String component) {
    unavailableComponents.remove(component);
    processors.get(component).accept(fetch(component));
  }

  ChartDto fetch(String component) {
    FileDashboardFilter filter = new FileDashboardFilter();
    filter.setChartCode(component);
    LocalDateTime now = LocalDateTime.now();
    filter.setFromDate(now.minusDays(periodDays));
    filter.setToDate(now);
    try {
      GetChartResponseDto response = client.getChart(filter.toDto(), userIdentifier, null);
      return response == null ? null : response.getChart();
    } catch (RuntimeException exception) {
      unavailableComponents.add(component);
      LOGGER.log(Level.WARNING, "Tableau de bord : composant " + component + " indisponible",
          exception);
      return null;
    }
  }

  void processKpis(ChartDto chart) {
    purgeEligible = 0;
    files = 0;
    fileGroups = 0;
    groupFiles = 0;

    if (chart == null || chart.getDataSets() == null) {
      return;
    }

    ChartDataSetDto kpiDataSet = findDataSet(chart, FileDashboardChartCode.KPIS);
    if (kpiDataSet != null && kpiDataSet.getDatas() != null) {
      for (ChartDataDto data : kpiDataSet.getDatas()) {
        long value = data.getValue() != null ? data.getValue() : 0;
        if (FileDashboardKpiCode.PURGE_ELIGIBLE.equals(data.getKey())) {
          purgeEligible = value;
        } else if (FileDashboardKpiCode.FILES.equals(data.getKey())) {
          files = value;
        } else if (FileDashboardKpiCode.FILE_GROUPS.equals(data.getKey())) {
          fileGroups = value;
        } else if (FileDashboardKpiCode.GROUP_FILES.equals(data.getKey())) {
          groupFiles = value;
        }
      }
    }
  }

  void processChart(ChartController controller, ChartDto chart, String code, String title,
      Consumer<ChartController> builder) {
    ChartDataSetDto dataSet = findDataSet(chart, code);
    controller.setSupplier(() -> buildResponse(title, dataSet));
    builder.accept(controller);
  }

  ChartDataSetDto findDataSet(ChartDto chart, String name) {
    if (chart == null || chart.getDataSets() == null) {
      return null;
    }
    return chart.getDataSets().stream()
        .filter(ds -> name.equals(ds.getName()))
        .findFirst()
        .orElse(null);
  }

  GetChartResponseDto buildResponse(String title, ChartDataSetDto dataSet) {
    ChartDto chart = new ChartDto();
    chart.setName(title);
    if (dataSet != null && dataSet.getDatas() != null && !dataSet.getDatas().isEmpty()) {
      chart.addDataSet(dataSet);
      LinkedHashSet<String> keys = dataSet.getDatas().stream()
          .map(ChartDataDto::getKey)
          .collect(Collectors.toCollection(LinkedHashSet::new));
      chart.setKeys(keys);
    }
    GetChartResponseDto response = new GetChartResponseDto();
    response.setChart(chart);
    return response;
  }

  /**
   * Cette méthode permet d'appliquer une période en jours et de rafraîchir les données.
   *
   * @param days nombre de jours
   */
  public void applyPeriod(int days) {
    this.periodDays = days;
    initialize();
  }
}
