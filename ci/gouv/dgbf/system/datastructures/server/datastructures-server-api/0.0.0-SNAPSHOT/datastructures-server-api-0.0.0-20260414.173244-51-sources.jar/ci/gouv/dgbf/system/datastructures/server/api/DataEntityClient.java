package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierGetValuesRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.ByIdentifierGetGridValuesResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.ByIdentifierGetValuesCountResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link DataEntityService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class DataEntityClient extends AbstractClient<DataEntityService>
    implements GetByIdentifier<DataEntityDto>, GetMany<DataEntityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public DataEntityClient service(DataEntityService service) {
    return (DataEntityClient) super.service(service);
  }

  /**
   * {@link DataEntityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(DataEntityCreateRequestDto request) {
    return new CreateExecutor(DataEntityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link DataEntityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public DataEntityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<DataEntityGetManyResponseDto>(DataEntityGetManyResponseDto.class,
        DataEntityService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link DataEntityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DataEntityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link DataEntityService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ByIdentifierGetGridValuesResponseDto getValues(ByIdentifierGetValuesRequestDto request) {
    return new GetOneExecutor<ByIdentifierGetGridValuesResponseDto>(
        ByIdentifierGetGridValuesResponseDto.class, DataEntityService.GET_VALUES_IDENTIFIER)
            .execute(() -> service().getValues(request));
  }

  /**
   * {@link DataEntityService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ByIdentifierGetValuesCountResponseDto getValuesCount(ByIdentifierRequestDto request) {
    return new GetOneExecutor<ByIdentifierGetValuesCountResponseDto>(
        ByIdentifierGetValuesCountResponseDto.class, DataEntityService.GET_VALUES_COUNT_IDENTIFIER)
            .execute(() -> service().getValuesCount(request));
  }

  /**
   * {@link DataEntityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public DataEntityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<DataEntityDto>(DataEntityDto.class,
        DataEntityService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link DataEntityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DataEntityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link DataEntityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public DataEntityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<DataEntityDto>(DataEntityDto.class,
        DataEntityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link DataEntityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DataEntityDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link DataEntityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(DataEntityUpdateRequestDto request) {
    return new IdentifiableExecutor(DataEntityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link DataEntityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(DataEntityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link DataEntityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
