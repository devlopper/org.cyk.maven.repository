package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketClaimActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketDissatisfactionActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketResolutionActionsCountAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un utilisateur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class UserDto extends AbstractIdentifiableNamableDto
    implements HasTicketClaimActionsCountAsStringDto, HasTicketResolutionActionsCountAsStringDto,
    HasTicketDissatisfactionActionsCountAsStringDto, HasClaimedTicketCountAsStringDto {

  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT_AS_STRING)
  private String claimedTicketCountAsString;

  @JsonbProperty(JSON_TICKET_CLAIM_ACTIONS_COUNT_AS_STRING)
  private String ticketClaimActionsCountAsString;

  @JsonbProperty(JSON_TICKET_RESOLUTION_ACTIONS_COUNT_AS_STRING)
  private String ticketResolutionActionsCountAsString;

  @JsonbProperty(JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT_AS_STRING)
  private String ticketDissatisfactionActionsCountAsString;

  @JsonbProperty(JSON_SUPPORT_TEAM_CLAIMED_TICKET_COUNT_AS_STRING)
  private String supportTeamsClaimedTicketCountAsString;

  @JsonbProperty(JSON_SUPPORT_TEAM_RESOLVED_TICKET_COUNT_AS_STRING)
  private String supportTeamsResolvedTicketCountAsString;

  @JsonbProperty(JSON_SUPPORT_TEAM_DISSATISFIED_TICKET_COUNT_AS_STRING)
  private String supportTeamsDissatisfiedTicketCountAsString;

  /**
   * Identifiant json du nombre de tickets actuellement pris en charge des équipes support de
   * l'utilisateur, sous forme de chaîne.
   */
  public static final String JSON_SUPPORT_TEAM_CLAIMED_TICKET_COUNT_AS_STRING =
      "nombreTicketPrisEnChargeEquipeChaine";

  /**
   * Identifiant json du nombre de tickets résolus des équipes support de l'utilisateur, sous forme
   * de chaîne.
   */
  public static final String JSON_SUPPORT_TEAM_RESOLVED_TICKET_COUNT_AS_STRING =
      "nombreTicketResoluEquipeChaine";

  /**
   * Identifiant json du nombre de tickets non satisfaits des équipes support de l'utilisateur, sous
   * forme de chaîne.
   */
  public static final String JSON_SUPPORT_TEAM_DISSATISFIED_TICKET_COUNT_AS_STRING =
      "nombreTicketInsatisfaitEquipeChaine";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUtilisateur";

  /**
   * Identifiant json du nom.
   */
  public static final String JSON_THIS_NAME = "nomUtilisateur";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
