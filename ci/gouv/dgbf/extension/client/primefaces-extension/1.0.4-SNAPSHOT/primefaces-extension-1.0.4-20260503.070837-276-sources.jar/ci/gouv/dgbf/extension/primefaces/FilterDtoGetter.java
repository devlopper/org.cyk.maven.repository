package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.server.service.api.AbstractFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.function.Supplier;

/**
 * Cette classe représente l'accesseur de filtre.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class FilterDtoGetter {

  /**
   * Cette méthode permet d'obtenir un filtre.
   *
   * @param value valeur
   * @param supplier fournisseur
   * @return filtre
   */
  public FilterDto get(Object value, Supplier<Object> supplier) {
    FilterDto dto = get(value);
    if (dto != null) {
      return dto;
    }
    if (supplier != null) {
      dto = get(supplier.get());
    }
    return dto;
  }

  FilterDto get(Object object) {
    if (object instanceof FilterDto dto) {
      return dto;
    }
    if (object instanceof AbstractFilter filter) {
      return filter.toDto();
    }
    if (object instanceof AbstractFilterController<?> controller && controller.filter != null) {
      return controller.filter.toDto();
    }
    return null;
  }
}
