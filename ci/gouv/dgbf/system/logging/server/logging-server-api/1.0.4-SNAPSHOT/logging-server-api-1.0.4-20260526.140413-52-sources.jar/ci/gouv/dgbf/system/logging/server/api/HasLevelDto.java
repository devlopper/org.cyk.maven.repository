package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;

/**
 * Cette interface représente une classe avec une notion {@link LogLevel}.
 *
 * @author Christian
 */
public interface HasLevelDto extends HasLevel {
  
  /**
   * Identifiant json de {@link LogLevel}.
   */
  String JSON_LEVEL = "niveau";
}
