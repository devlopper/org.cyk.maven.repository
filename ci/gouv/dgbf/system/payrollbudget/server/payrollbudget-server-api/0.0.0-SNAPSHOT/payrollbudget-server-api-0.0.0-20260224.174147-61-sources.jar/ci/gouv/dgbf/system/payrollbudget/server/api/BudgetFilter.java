package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsDefault;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasExerciseIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class BudgetFilter extends AbstractIdentifiableFilter
    implements FilterHasExerciseIdentifier, FilterHasIsDefault {

  /**
   * Identifiant {@link ExerciseDto}.
   */
  String exerciseIdentifier;

  /**
   * Est par défaut.
   */
  Boolean isDefault;
  
  /**
   * Cette méthode permet d'instancier un objet.
   */
  public BudgetFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public BudgetFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateExerciseIdentifier(filter);
    updateIsDefault(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterExerciseIdentifier(filter);
    updateFilterIsDefault(filter);
  }
}
