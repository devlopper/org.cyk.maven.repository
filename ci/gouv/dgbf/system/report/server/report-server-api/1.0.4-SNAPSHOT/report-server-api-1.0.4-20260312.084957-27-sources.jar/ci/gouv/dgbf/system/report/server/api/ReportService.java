package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des rapports.
 *
 * @author Christian
 *
 */
@Path(ReportService.PATH)
@Tag(name = "Gestion des rapports")
public interface ReportService {

  /**
   * Chemin de base des services.
   */
  String PATH = "rapports";

  /**
   * Cette classe représente l'objet de transfert de donnée de paramètre de rapport.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ParameterDto {
    /**
     * Nom.
     */
    @JsonbProperty(JSON_NAME)
    private String name;

    /**
     * Valeurs.
     */
    @JsonbProperty(JSON_VALUES)
    private List<String> values;

    /**
     * Identifiant json {@link #name}.
     */
    public static final String JSON_NAME = "nom";

    /**
     * Identifiant json {@link #values}.
     */
    public static final String JSON_VALUES = "valeurs";
  }


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Desysoft
   *
   */
  interface ReportSaveRequestDto {

    /**
     * Cette méthode me permet d'obtenir la description de {@link ReportDto}.
     *
     * @return description de {@link ReportDto}
     */
    String getDescription();

    /**
     * Cette méthode me permet d'assigner la description de {@link ReportDto}.
     *
     * @param description description de {@link ReportDto}
     */
    void setDescription(String description);


    /**
     * Cette méthode me permet d'obtenir l'identifiant du template de {@link ReportDto}.
     *
     * @return identifiant du template de {@link ReportDto}
     */
    String getTemplateIdentifier();

    /**
     * Cette méthode me permet d'assigner l'identifiant du template de {@link ReportDto}.
     *
     * @param templateIdentifier identifiant du template de {@link ReportDto}
     */
    void setTemplateIdentifier(String templateIdentifier);
    
    /**
     * Identifiant JSON de la description.
     */
    String JSON_DESCRIPTION = ReportDto.JSON_DESCRIPTION;

    /**
     * Identifiant JSON de l'identifiant du modèle.
     */
    String JSON_TEMPLATE_IDENTIFIER = ReportDto.JSON_TEMPLATE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RAPPORT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ReportDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ReportCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {AbstractCodableCreateRequestJsonDto.FIELD_CODE,
      AbstractCodableNamableCreateRequestJsonDto.FIELD_NAME, AbstractRequestDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION})
  class ReportCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ReportSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_TEMPLATE_IDENTIFIER)
    private String templateIdentifier;

  }

  /**
   * Identifiant du service d'obtention d'octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_OCTETS_PAR_IDENTIFIANT";

  /**
   * Chemin du service d'obtention d'octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_PATH = "octets-par-identifiant";

  /**
   * Cette méthode permet d'obtenir d'octets par identifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BYTES_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_OCTET_STREAM + "," + MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_BYTES_BY_IDENTIFIER_IDENTIFIER,
      summary = "Obtention octets par identifiant",
      description = "Ce service permet d'obtenir les octets par identifiant")
  @APIResponses(value = {
      @APIResponse(responseCode = "200",
          content = {@Content(mediaType = MediaType.APPLICATION_OCTET_STREAM,
              schema = @Schema(implementation = byte[].class))}),
      @APIResponse(responseCode = "500", content = {@Content(mediaType = MediaType.TEXT_PLAIN,
          schema = @Schema(implementation = String.class))})})

  Response getBytesByIdentifier(GetBytesByIdentifierRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête d'obtention d'octets par
   * identifiant.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetBytesByIdentifierRequestDto extends ByIdentifierRequestDto {

    /**
     * Paramètres.
     */
    @JsonbProperty(JSON_PARAMETERS)
    private List<ParameterDto> parameters;

    /**
     * Type de fichier.
     */
    @JsonbProperty(JSON_FILE_TYPE)
    private String fileType;

    /**
     * Nom du fichier.
     */
    @JsonbProperty(JSON_FILE_NAME)
    private String fileName;

    /**
     * Identifiant json {@link #parameters}.
     */
    public static final String JSON_PARAMETERS = "parametres";

    /**
     * Identifiant json {@link #fileType}.
     */
    public static final String JSON_FILE_TYPE = "typeFichier";

    /**
     * Identifiant json {@link #fileName}.
     */
    public static final String JSON_FILE_NAME = "nomFichier";
  }

  /**
   * Type de fichier par défaut.
   */
  String DEFAULT_FILE_TYPE = "pdf";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REPORT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ReportGetManyResponseDto extends AbstractGetByPageResponseDto<ReportDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ReportDto> datas;
  }


  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RAPPORT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RAPPORT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ReportDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ReportDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);



  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RAPPORT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ReportUpdateRequestDto request);


  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {ByIdentifierRequestDto.FIELD_IDENTIFIER,
      AbstractCodableNamableUpdateRequestJsonDto.FIELD_CODE,
      AbstractCodableNamableUpdateRequestJsonDto.FIELD_NAME, AbstractRequestDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION})
  class ReportUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ReportSaveRequestDto {
    
    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_TEMPLATE_IDENTIFIER)
    private String templateIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_RAPPORT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ReportDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
