package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de l'unité de spécialisation du
 * budget.
 *
 * @author Arnaud
 */
public interface HasBudgetSpecializationUnitIdentifierDto
       extends HasBudgetSpecializationUnitIdentifier {

  /**
   * Identifiant json de l'identifiant de l'unité de spécialisation du budget.
   */
  String JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER = "idUniteSpecialisationBudget";
}