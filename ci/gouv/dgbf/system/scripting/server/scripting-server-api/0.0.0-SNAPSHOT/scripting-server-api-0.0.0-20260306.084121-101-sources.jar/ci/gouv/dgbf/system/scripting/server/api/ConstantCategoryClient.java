package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryEvaluateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryEvaluateResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ConstantCategoryService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ConstantCategoryClient extends AbstractClient<ConstantCategoryService>
    implements GetByIdentifier<ConstantCategoryDto>, GetMany<ConstantCategoryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ConstantCategoryClient service(ConstantCategoryService service) {
    return (ConstantCategoryClient) super.service(service);
  }

  /**
   * {@link ConstantCategoryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ConstantCategoryCreateRequestDto request) {
    return new CreateExecutor(ConstantCategoryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ConstantCategoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantCategoryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ConstantCategoryGetManyResponseDto>(
        ConstantCategoryGetManyResponseDto.class, ConstantCategoryService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ConstantCategoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConstantCategoryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ConstantCategoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantCategoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ConstantCategoryDto>(ConstantCategoryDto.class,
        ConstantCategoryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ConstantCategoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ConstantCategoryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ConstantCategoryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ConstantCategoryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ConstantCategoryDto>(ConstantCategoryDto.class,
        ConstantCategoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ConstantCategoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConstantCategoryDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ConstantCategoryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ConstantCategoryUpdateRequestDto request) {
    return new IdentifiableExecutor(ConstantCategoryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ConstantCategoryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ConstantCategoryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ConstantCategoryService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ConstantCategoryService#evaluate}.
   *
   * @param request requête
   * @return réponse
   */
  public ConstantCategoryEvaluateResponseDto evaluate(ConstantCategoryEvaluateRequestDto request) {
    return new GetOneExecutor<>(ConstantCategoryEvaluateResponseDto.class,
        ConstantCategoryService.EVALUATE_IDENTIFIER).execute(() -> service().evaluate(request));
  }
}
