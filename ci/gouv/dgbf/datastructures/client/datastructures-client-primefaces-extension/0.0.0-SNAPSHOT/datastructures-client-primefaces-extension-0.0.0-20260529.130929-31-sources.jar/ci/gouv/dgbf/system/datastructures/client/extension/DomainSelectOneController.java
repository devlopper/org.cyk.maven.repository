package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.DomainClient;
import ci.gouv.dgbf.system.datastructures.server.api.DomainDto;
import ci.gouv.dgbf.system.datastructures.server.api.DomainService.DomainGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DomainDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class DomainSelectOneController extends
    AbstractSelectOneIdentifiableController<DomainDto, DomainGetManyResponseDto, DomainClient> {

  @Getter
  @Inject
  DomainClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected DomainSelectOneController() {
    super(DomainDto.class, SelectItemLabelStrategy.NAME);
  }
}
