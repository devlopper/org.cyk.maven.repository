package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.FunctionClient;
import ci.gouv.dgbf.system.functionary.server.api.FunctionDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionService.FunctionGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FunctionDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FunctionSelectOneController extends AbstractSelectOneIdentifiableController<
    FunctionDto, FunctionGetManyResponseDto, FunctionClient> {

  @Getter
  @Inject
  FunctionClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FunctionSelectOneController() {
    super(FunctionDto.class, SelectItemLabelStrategy.NAME);
  }
}
