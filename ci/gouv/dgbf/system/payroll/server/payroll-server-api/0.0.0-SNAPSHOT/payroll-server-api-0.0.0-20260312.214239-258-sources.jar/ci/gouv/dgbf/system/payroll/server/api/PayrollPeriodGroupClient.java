package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PayrollPeriodGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PayrollPeriodGroupGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PeriodGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PayrollPeriodGroupService}.
 *
 * @author arnaud
 *
 */
@ApplicationScoped
public class PayrollPeriodGroupClient extends AbstractClient<PayrollPeriodGroupService> implements
    GetByIdentifier<PayrollPeriodGroupDto>, GetMany<PayrollPeriodGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollPeriodGroupClient service(PayrollPeriodGroupService service) {
    return (PayrollPeriodGroupClient) super.service(service);
  }

  /**
   * {@link PayrollPeriodGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollPeriodGroupCreateRequestDto request) {
    return new CreateExecutor(PayrollPeriodGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollPeriodGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollPeriodGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollPeriodGroupGetManyResponseDto>(
        PayrollPeriodGroupGetManyResponseDto.class, PayrollPeriodGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollPeriodGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollPeriodGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollPeriodGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollPeriodGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollPeriodGroupDto>(PayrollPeriodGroupDto.class,
        PayrollPeriodGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollPeriodGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollPeriodGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollPeriodGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe de periode
   */
  public PayrollPeriodGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollPeriodGroupDto>(PayrollPeriodGroupDto.class,
        PayrollPeriodGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollPeriodGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollPeriodGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollPeriodGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PeriodGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollPeriodGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollPeriodGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollPeriodGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollPeriodGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
