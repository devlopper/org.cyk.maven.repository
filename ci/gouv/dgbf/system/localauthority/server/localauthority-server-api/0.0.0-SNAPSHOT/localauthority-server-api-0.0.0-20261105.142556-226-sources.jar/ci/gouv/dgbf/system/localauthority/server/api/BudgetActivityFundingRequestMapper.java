package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.BudgetActivityFundingService.BudgetActivityFundingCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.BudgetActivityFundingService.BudgetActivityFundingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BudgetActivityFundingDto}.
 *
 * @author Donsylla
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BudgetActivityFundingDto}.

    @author Donsylla
               """)
public interface BudgetActivityFundingRequestMapper
    extends RequestMapper<BudgetActivityFundingDto,
    BudgetActivityFundingCreateRequestDto, BudgetActivityFundingUpdateRequestDto> {

}
