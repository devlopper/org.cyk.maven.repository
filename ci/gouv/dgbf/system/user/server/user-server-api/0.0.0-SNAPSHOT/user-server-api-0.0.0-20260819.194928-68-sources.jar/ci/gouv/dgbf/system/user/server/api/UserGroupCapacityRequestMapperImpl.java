package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UserGroupCapacityDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-19T19:49:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UserGroupCapacityRequestMapperImpl implements UserGroupCapacityRequestMapper {

    @Override
    public UserGroupCapacityService.UserGroupCapacityCreateRequestDto mapCreate(UserGroupCapacityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserGroupCapacityService.UserGroupCapacityCreateRequestDto userGroupCapacityCreateRequestDto = new UserGroupCapacityService.UserGroupCapacityCreateRequestDto();

        userGroupCapacityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        userGroupCapacityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        userGroupCapacityCreateRequestDto.setUserGroupIdentifier( arg0.getUserGroupIdentifier() );
        userGroupCapacityCreateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return userGroupCapacityCreateRequestDto;
    }

    @Override
    public UserGroupCapacityService.UserGroupCapacityUpdateRequestDto mapUpdate(UserGroupCapacityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserGroupCapacityService.UserGroupCapacityUpdateRequestDto userGroupCapacityUpdateRequestDto = new UserGroupCapacityService.UserGroupCapacityUpdateRequestDto();

        userGroupCapacityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        userGroupCapacityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        userGroupCapacityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        userGroupCapacityUpdateRequestDto.setUserGroupIdentifier( arg0.getUserGroupIdentifier() );
        userGroupCapacityUpdateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return userGroupCapacityUpdateRequestDto;
    }
}
