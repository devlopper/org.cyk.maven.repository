package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link PartitionUnitDto}.
 *
 * @author Christian
 */
@Dependent
public class PartitionUnitFilterController extends AbstractFilterController<PartitionUnitFilter> {

  @Inject
  @Getter
  InputTextController partitionTypeCodeInputTextController;

  @Inject
  @Getter
  InputTextController partitionValueDataInputTextController;

  /**
   * Cette méthode permet d'instantier.
   */
  public PartitionUnitFilterController() {
    super(PartitionUnitFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    partitionTypeCodeInputTextController.setOutputLableValue("Code du type de partition");
    partitionTypeCodeInputTextController.getInputText()
        .addValueConsumer(code -> filter.setPartitionTypeCode(code));

    partitionValueDataInputTextController
        .setOutputLableValue("Donnée de la valeur de la partition");
    partitionValueDataInputTextController.getInputText()
        .addValueConsumer(data -> filter.setPartitionValueData(data));
  }

}
