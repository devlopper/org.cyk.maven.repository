package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-20T20:40:20+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityGroupRequestMapperImpl implements IdentityGroupRequestMapper {

    @Override
    public IdentityGroupService.IdentityGroupCreateRequestDto mapCreate(IdentityGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityGroupService.IdentityGroupCreateRequestDto identityGroupCreateRequestDto = new IdentityGroupService.IdentityGroupCreateRequestDto();

        identityGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityGroupCreateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityGroupCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        Set<String> set = arg0.getRolesIdentifiers();
        if ( set != null ) {
            identityGroupCreateRequestDto.setRolesIdentifiers( new LinkedHashSet<String>( set ) );
        }
        identityGroupCreateRequestDto.setUpdateRolesIdentifiers( arg0.getUpdateRolesIdentifiers() );

        return identityGroupCreateRequestDto;
    }

    @Override
    public IdentityGroupService.IdentityGroupUpdateRequestDto mapUpdate(IdentityGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityGroupService.IdentityGroupUpdateRequestDto identityGroupUpdateRequestDto = new IdentityGroupService.IdentityGroupUpdateRequestDto();

        identityGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identityGroupUpdateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityGroupUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        Set<String> set = arg0.getRolesIdentifiers();
        if ( set != null ) {
            identityGroupUpdateRequestDto.setRolesIdentifiers( new LinkedHashSet<String>( set ) );
        }
        identityGroupUpdateRequestDto.setUpdateRolesIdentifiers( arg0.getUpdateRolesIdentifiers() );

        return identityGroupUpdateRequestDto;
    }

    @Override
    public IdentityGroupService.IdentityGroupUpdateRolesRequestDto mapUpdateRoles(IdentityGroupDto identityGroup) {
        if ( identityGroup == null ) {
            return null;
        }

        IdentityGroupService.IdentityGroupUpdateRolesRequestDto identityGroupUpdateRolesRequestDto = new IdentityGroupService.IdentityGroupUpdateRolesRequestDto();

        identityGroupUpdateRolesRequestDto.setAuditWho( identityGroup.getAuditWho() );
        identityGroupUpdateRolesRequestDto.setAuditSession( identityGroup.getAuditSession() );
        identityGroupUpdateRolesRequestDto.setIdentifier( identityGroup.getIdentifier() );
        Set<String> set = identityGroup.getRolesIdentifiers();
        if ( set != null ) {
            identityGroupUpdateRolesRequestDto.setRolesIdentifiers( new LinkedHashSet<String>( set ) );
        }

        return identityGroupUpdateRolesRequestDto;
    }
}
