package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentProjectionService.PayrollComponentProjectionCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentProjectionService.PayrollComponentProjectionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentProjectionDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentProjectionDto}.

    @author Christian
               """)
public interface PayrollComponentProjectionRequestMapper
    extends RequestMapper<PayrollComponentProjectionDto, PayrollComponentProjectionCreateRequestDto,
        PayrollComponentProjectionUpdateRequestDto> {

}
