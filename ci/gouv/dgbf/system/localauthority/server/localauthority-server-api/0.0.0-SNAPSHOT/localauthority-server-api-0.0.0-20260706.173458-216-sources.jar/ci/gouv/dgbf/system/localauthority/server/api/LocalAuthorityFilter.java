package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link LocalAuthorityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LocalAuthorityFilter extends AbstractIdentifiableFilter {

  
}

