package ci.gouv.dgbf.system.identity.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'identifiant d'identité.
 *
 * @author Christian
 */
public interface FilterHasIdentityIdentifier extends HasIdentityIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'identité.
   *
   * @param filter {@link FilterDto}
   */
  default void updateIdentityIdentifier(FilterDto filter) {
    setIdentityIdentifier(IdentityIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'identité de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterIdentityIdentifier(FilterDto filter) {
    IdentityIdentifierFilter.set(filter, getIdentityIdentifier());
  }

}
