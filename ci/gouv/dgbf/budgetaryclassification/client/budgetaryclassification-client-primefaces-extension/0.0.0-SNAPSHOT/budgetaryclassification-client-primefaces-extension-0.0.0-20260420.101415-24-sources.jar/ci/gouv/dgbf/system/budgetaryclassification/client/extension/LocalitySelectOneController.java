package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LocalityClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LocalityDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LocalityService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link LocalityDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class LocalitySelectOneController extends AbstractSelectOneIdentifiableController<
    LocalityDto, GetManyResponseDto, LocalityClient> {

  @Inject
  @Getter
  LocalityClient client;

  protected LocalitySelectOneController() {
    super(LocalityDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
