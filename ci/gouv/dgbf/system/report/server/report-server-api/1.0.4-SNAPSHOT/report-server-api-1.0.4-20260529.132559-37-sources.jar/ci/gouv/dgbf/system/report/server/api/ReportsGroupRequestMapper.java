package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ReportsGroupDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ReportGroupsDto}.
    
    @author Desysoft
    """)
public interface ReportsGroupRequestMapper extends RequestMapper<ReportsGroupDto,
    ReportsGroupService.ReportsGroupCreateRequestDto,
    ReportsGroupService.ReportsGroupUpdateRequestDto> {

}
