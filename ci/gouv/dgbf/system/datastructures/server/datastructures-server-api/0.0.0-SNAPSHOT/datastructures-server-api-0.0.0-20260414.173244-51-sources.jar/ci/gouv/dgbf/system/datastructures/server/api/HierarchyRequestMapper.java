package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchyService.HierarchyCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchyService.HierarchyUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link HierarchyDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link HierarchyDto}.

    @author Christian
               """)
public interface HierarchyRequestMapper
    extends RequestMapper<HierarchyDto, HierarchyCreateRequestDto, HierarchyUpdateRequestDto> {

}
