package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasMovementTypeIdentifier extends HasMovementTypeIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de {@link MovementTypeDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateMovementTypeIdentifier(FilterDto filter) {
    setMovementTypeIdentifier(MovementTypeIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de {@link MovementTypeDto} de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterMovementTypeIdentifier(FilterDto filter) {
    MovementTypeIdentifierFilter.set(filter, getMovementTypeIdentifier());
  }

}
