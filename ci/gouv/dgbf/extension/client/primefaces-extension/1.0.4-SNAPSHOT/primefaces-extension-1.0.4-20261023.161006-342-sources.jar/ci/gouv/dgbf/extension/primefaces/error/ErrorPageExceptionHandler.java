package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.el.ELException;
import jakarta.faces.FacesException;
import jakarta.faces.application.ViewHandler;
import jakarta.faces.component.UIViewRoot;
import jakarta.faces.context.ExceptionHandler;
import jakarta.faces.context.ExceptionHandlerWrapper;
import jakarta.faces.context.ExternalContext;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.AbortProcessingException;
import jakarta.faces.event.ExceptionQueuedEvent;
import jakarta.faces.event.PreRenderViewEvent;
import jakarta.faces.view.ViewDeclarationLanguage;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.omnifaces.config.WebXml;
import org.omnifaces.exceptionhandler.FullAjaxExceptionHandler;
import org.omnifaces.util.Exceptions;
import org.omnifaces.util.Hacks;

/**
 * Cette classe affiche la page d'erreur déclarée à l'adresse demandée, pour les requêtes non Ajax.
 *
 * <p>Sans elle, l'exception remonte au conteneur : Quarkus 3.15 échoue alors dans son propre
 * gestionnaire (NullPointerException) et le navigateur reçoit une page tronquée, tandis qu'une
 * redirection vers la page d'erreur empêcherait de retenter la page en l'actualisant. Les requêtes
 * Ajax restent confiées à {@link FullAjaxExceptionHandler}.
 *
 * @author Christian
 */
public class ErrorPageExceptionHandler extends ExceptionHandlerWrapper {
  private static final Logger LOGGER = Logger.getLogger(ErrorPageExceptionHandler.class.getName());
  private static final String FALLBACK = "<!DOCTYPE html><html lang=\"fr\"><head>"
      + "<meta charset=\"UTF-8\" /><title>Une erreur est survenue</title></head><body>"
      + "<h1>Une erreur est survenue</h1><p>Veuillez réessayer dans quelques instants.</p>"
      + "</body></html>";

  /**
   * Ce constructeur enveloppe le gestionnaire suivant.
   *
   * @param wrapped gestionnaire enveloppé
   */
  public ErrorPageExceptionHandler(ExceptionHandler wrapped) {
    super(wrapped);
  }

  @Override
  public void handle() {
    FacesContext context = FacesContext.getCurrentInstance();
    if (context != null && !context.getPartialViewContext().isAjaxRequest()) {
      handleNonAjaxException(context);
    }
    getWrapped().handle();
  }

  private void handleNonAjaxException(FacesContext context) {
    Iterator<ExceptionQueuedEvent> events = getUnhandledExceptionQueuedEvents().iterator();
    if (!events.hasNext()) {
      return;
    }
    Throwable exception = events.next().getContext().getException();
    if (exception instanceof AbortProcessingException) {
      return;
    }
    Throwable cause = Exceptions.unwrap(exception, FacesException.class, ELException.class);
    String location = WebXml.instance().findErrorPageLocation(cause);
    if (location == null) {
      return;
    }
    events.remove();
    ExternalContext external = context.getExternalContext();
    HttpServletRequest request = (HttpServletRequest) external.getRequest();
    String uuid = UUID.randomUUID().toString();
    request.setAttribute(FullAjaxExceptionHandler.EXCEPTION_UUID, uuid);
    LOGGER.log(Level.SEVERE, String.format("[%s][%s] Erreur affichée par la page %s", uuid,
        request.getRemoteAddr(), location), cause);
    // Une réponse déjà envoyée (au-delà de la limite du filtre) ne peut plus être remplacée.
    if (!external.isResponseCommitted()) {
      request.setAttribute(RequestDispatcher.ERROR_EXCEPTION_TYPE, cause.getClass());
      request.setAttribute(RequestDispatcher.ERROR_REQUEST_URI, request.getRequestURI());
      request.setAttribute(RequestDispatcher.ERROR_STATUS_CODE,
          HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
      resetResponse(external);
      render(context, location);
    }
    context.responseComplete();
    while (events.hasNext()) {
      events.next();
      events.remove();
    }
  }

  private static void resetResponse(ExternalContext external) {
    String contentType = external.getResponseContentType();
    String encoding = external.getResponseCharacterEncoding();
    external.responseReset();
    external.setResponseContentType(contentType == null ? "text/html" : contentType);
    external.setResponseCharacterEncoding(encoding == null ? "UTF-8" : encoding);
    external.setResponseStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
  }

  private static void render(FacesContext context, String location) {
    try {
      ViewHandler viewHandler = context.getApplication().getViewHandler();
      String viewId = location.split("\\?", 2)[0];
      UIViewRoot viewRoot = viewHandler.createView(context, viewId);
      // Oublie les scripts et feuilles déjà déclarés par la vue en échec.
      Hacks.removeResourceDependencyState(context);
      context.setViewRoot(viewRoot);
      ViewDeclarationLanguage vdl = viewHandler.getViewDeclarationLanguage(context, viewId);
      vdl.buildView(context, viewRoot);
      context.getApplication().publishEvent(context, PreRenderViewEvent.class, viewRoot);
      vdl.renderView(context, viewRoot);
    } catch (IOException | RuntimeException failure) {
      LOGGER.log(Level.SEVERE, "La page d'erreur " + location + " a elle-même échoué", failure);
      ExternalContext external = context.getExternalContext();
      if (!external.isResponseCommitted()) {
        resetResponse(external);
        try {
          external.getResponseOutputWriter().write(FALLBACK);
        } catch (IOException ignored) {
          // La réponse est inutilisable : il n'y a plus rien à envoyer.
        }
      }
    }
  }
}
