package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur par des boutons.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectOneBooleanButton extends AbstractSelectOneBoolean {

  String onLabel;
  String offLabel;
  String onIcon;
  String offIcon;

  /**
   * Cette méthode permet d'instancier.
   */
  public SelectOneBooleanButton() {
    onLabel = "Oui";
    offLabel = "Non";
    onIcon = "pi pi-check";
    offIcon = "pi pi-times";
  }
}
