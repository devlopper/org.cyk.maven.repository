package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de type de réclamation.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimTypeGroupDto
    extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link PayrollElementClaimTypeGroupDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeTypeReclamation";

  /**
   * Identifiant json de représentation en chaine de caractères
   * de {@link PayrollElementClaimTypeGroupDto}.
   */
  public static final String JSON_THIS_AS_STRING = "groupeTypeReclamationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de type de réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de type de réclamation";
}
