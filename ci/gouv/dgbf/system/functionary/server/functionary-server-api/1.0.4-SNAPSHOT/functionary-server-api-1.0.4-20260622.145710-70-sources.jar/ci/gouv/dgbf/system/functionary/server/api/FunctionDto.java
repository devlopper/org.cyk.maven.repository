package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une fonction.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;
  
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;
  
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;
  
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonction";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionChaine";
  
  /**
   * Identifiant json de {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = FunctionGroupDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = FunctionGroupDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json de {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = FunctionTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = FunctionTypeDto.JSON_THIS_AS_STRING;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonction";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
