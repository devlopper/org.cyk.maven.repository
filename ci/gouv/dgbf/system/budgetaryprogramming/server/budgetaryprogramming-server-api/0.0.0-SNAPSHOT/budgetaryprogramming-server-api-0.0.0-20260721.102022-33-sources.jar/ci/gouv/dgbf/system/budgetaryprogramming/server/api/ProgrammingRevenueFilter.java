package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasProgrammingIdentifier;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasRevenueIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProgrammingRevenueDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ProgrammingRevenueFilter extends AbstractIdentifiableFilter
    implements FilterHasProgrammingIdentifier, FilterHasRevenueIdentifier {

  String programmingIdentifier;

  String revenueIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateProgrammingIdentifier(filter);
    updateRevenueIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterProgrammingIdentifier(filter);
    updateFilterRevenueIdentifier(filter);
  }

}
