package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FileDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileFilter extends AbstractIdentifiableFilter {

  /**
   * {@link FileDto#getOwnerIdentifier()}.
   */
  String ownerIdentifier;

  /**
   * {@link FileDto#getHash()}.
   */
  String hash;
  
  /**
   * {@link FileDto#getGroupIdentifier()}.
   */
  String groupIdentifier;

  /**
   * {@link AbstractIdentifiableNamableDto#getName()}.
   */
  String name;

  /**
   * Extension du fichier.
   */
  String extension;

  /**
   * Identifiants des groupes de fichiers.
   */
  Set<String> groupIdentifiers;

  /**
   * Ensemble des identifiants de groupe utilisés pour produire une liste de fichiers sans doublons.
   */
  Set<String> groupIdentifiersForUniqueResult;

  /**
   * Cette méthode permet de construire une instance.
   *
   * @param filter filtre
   */
  public FileFilter(FilterDto filter) {
    super(filter);
  }

  /**
   * Cette méthode permet de construire une instance.
   *
   */
  public FileFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    ownerIdentifier = getOwnerIdentifier(filter);
    groupIdentifier = getGroupIdentifier(filter);
    hash = getHash(filter);
    name = getName(filter);
    extension = getExtension(filter);
    groupIdentifiers = getGroupIdentifiers(filter);
    groupIdentifiersForUniqueResult = getGroupIdentifiersForUniqueResult(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setOwnerIdentifier(filter, ownerIdentifier);
    setGroupIdentifier(filter, groupIdentifier);
    setHash(filter, hash);
    setName(filter, name);
    setExtension(filter, extension);
    setGroupIdentifiers(filter, groupIdentifiers);
    setGroupIdentifiersForUniqueResult(filter, groupIdentifiersForUniqueResult);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link OwnerDto}.
   *
   * @param filter filtre
   * @param ownerIdentifier identifiant {@link OwnerDto}
   */
  public static void setOwnerIdentifier(FilterDto filter, String ownerIdentifier) {
    set(filter, JSON_OWNER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(ownerIdentifier));
  }
  
  /**
   * Cette méthode permet d'obtenir identifiant {@link OwnerDto}.
   *
   * @param filter filtre
   * @return identifiant {@link OwnerDto}
   */
  public static String getOwnerIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_OWNER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }
  
  /**
   * Cette méthode permet d'obtenir identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link FilesGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner le hash de {@link FileDto}.
   *
   * @param filter filtre
   * @param hash hash de {@link FileDto}
   */
  public static void setHash(FilterDto filter, String hash) {
    set(filter, JSON_HASH, f -> f.getValueAsString(), f -> f.setValueAsString(hash));
  }

  /**
   * Cette méthode permet d'obtenir hash de {@link FileDto}.
   *
   * @param filter filtre
   * @return hash de {@link FileDto}
   */
  public static String getHash(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_HASH));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param name nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner l'extension.
   *
   * @param filter filtre
   * @param extension extension
   */
  public static void setExtension(FilterDto filter, String extension) {
    set(filter, JSON_EXTENSION, f -> f.getValueAsString(),
        f -> f.setValueAsString(extension));
  }

  /**
   * Cette méthode permet d'obtenir l'extension.
   *
   * @param filter filtre
   * @return extension
   */
  public static String getExtension(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXTENSION));
  }

  /**
   * Cette méthode permet d'assigner les identifiants des groupes de fichiers.
   *
   * @param filter filtre
   * @param groupIdentifiers identifiants des groupes de fichiers
   */
  public static void setGroupIdentifiers(FilterDto filter, Set<String> groupIdentifiers) {
    set(filter, JSON_GROUP_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(groupIdentifiers));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants des groupes de fichiers.
   *
   * @param filter filtre
   * @return identifiants des groupes de fichiers
   */
  public static Set<String> getGroupIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_GROUP_IDENTIFIERS));
  }

  /**
   * Cette méthode permet d'assigner les identifiants des groupes de fichiers
   * utilisés pour produire une liste de fichiers sans doublons.
   *
   * @param filter filtre
   * @param groupIdentifiersForUniqueResult identifiants des groupes de fichiers
   *                                        utilisés pour produire une liste de
   *                                        fichiers sans doublons.
   */
  public static void setGroupIdentifiersForUniqueResult(FilterDto filter,
                                               Set<String> groupIdentifiersForUniqueResult) {
    set(filter, JSON_GROUP_IDENTIFIERS_FOR_UNIQUE_RESULT, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(groupIdentifiersForUniqueResult));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants des groupes de fichiers
   * utilisés pour produire une liste de fichiers sans doublons.
   *
   * @param filter filtre
   * @return identifiants des groupes de fichiers utilisés pour produire une
   *         liste de fichiers sans doublons.
   */
  public static Set<String> getGroupIdentifiersForUniqueResult(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringsSetByName(JSON_GROUP_IDENTIFIERS_FOR_UNIQUE_RESULT));
  }

  /**
   * Identifiant JSON {@link #ownerIdentifier}.
   */
  public static final String JSON_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER;

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = FileDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant JSON {@link #groupIdentifiers}.
   */
  public static final String JSON_GROUP_IDENTIFIERS = "idGroupesFichiers";

  /**
   * Identifiant JSON {@link #groupIdentifiersForUniqueResult}.
   */
  public static final String JSON_GROUP_IDENTIFIERS_FOR_UNIQUE_RESULT =
      "idGroupeFichiersPourResultatSansDoublon";
  
  /**
   * Identifiant JSON {@link #hash}.
   */
  public static final String JSON_HASH = FileDto.JSON_HASH;

  /**
   * Identifiant JSON {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  /**
   * Identifiant JSON {@link #extension}.
   */
  public static final String JSON_EXTENSION = "extension";
}
