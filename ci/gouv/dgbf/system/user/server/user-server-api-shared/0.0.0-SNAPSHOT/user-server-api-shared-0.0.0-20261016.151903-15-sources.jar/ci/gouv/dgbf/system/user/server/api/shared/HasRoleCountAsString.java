package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de rôles métier sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasRoleCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de rôles métier sous forme de chaîne.
   *
   * @return le nombre de rôles métier sous forme de chaîne
   */
  String getRoleCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre de rôles métier sous forme de chaîne.
   *
   * @param roleCountAsString le nombre de rôles métier sous forme de chaîne
   */
  void setRoleCountAsString(String roleCountAsString);

  /**
   * Identifiant java du nombre de rôles métier sous forme de chaîne.
   */
  String FIELD_ROLE_COUNT_AS_STRING = "roleCountAsString";
}
