package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DomainDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DomainRequestMapperImpl implements DomainRequestMapper {

    @Override
    public DomainService.DomainCreateRequestDto mapCreate(DomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DomainService.DomainCreateRequestDto domainCreateRequestDto = new DomainService.DomainCreateRequestDto();

        domainCreateRequestDto.setCode( arg0.getCode() );
        domainCreateRequestDto.setName( arg0.getName() );
        domainCreateRequestDto.setValueReferenceTableName( arg0.getValueReferenceTableName() );
        domainCreateRequestDto.setValueReferenceTableFilterColumnName( arg0.getValueReferenceTableFilterColumnName() );

        return domainCreateRequestDto;
    }

    @Override
    public DomainService.DomainUpdateRequestDto mapUpdate(DomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DomainService.DomainUpdateRequestDto domainUpdateRequestDto = new DomainService.DomainUpdateRequestDto();

        domainUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        domainUpdateRequestDto.setCode( arg0.getCode() );
        domainUpdateRequestDto.setName( arg0.getName() );
        domainUpdateRequestDto.setValueReferenceTableName( arg0.getValueReferenceTableName() );
        domainUpdateRequestDto.setValueReferenceTableFilterColumnName( arg0.getValueReferenceTableFilterColumnName() );

        return domainUpdateRequestDto;
    }
}
