package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentitiesGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentitiesGroupDto}.

    @author Christian
               """)
public interface IdentitiesGroupRequestMapper extends RequestMapper<IdentitiesGroupDto,
    IdentitiesGroupCreateRequestDto, IdentitiesGroupUpdateRequestDto> {

}
