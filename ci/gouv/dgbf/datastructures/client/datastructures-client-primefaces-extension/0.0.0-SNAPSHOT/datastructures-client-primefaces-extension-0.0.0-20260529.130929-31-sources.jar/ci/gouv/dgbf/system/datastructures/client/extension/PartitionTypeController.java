package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeService;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeService.PartitionTypeCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionTypeService.PartitionTypeUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link PartitionTypeDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionTypeController extends AbstractController {

  @Inject
  PartitionTypeClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  PartitionTypeRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  DomainSelectOneController domainSelectOneController;

  @Inject
  @Getter
  ValueSourceSelectOneController valueSourceSelectOneController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = PartitionTypeDto.NAME;

    listController.setEntityClass(PartitionTypeDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(PartitionTypeService.PATH);

    listController.getReadController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, AbstractIdentifiableCodableDto.JSON_CODE,
        AbstractIdentifiableCodableNamableDto.JSON_NAME, HasDomainAsStringDto.JSON_DOMAIN_AS_STRING,
        HasValueSourceAsStringDto.JSON_VALUE_SOURCE_AS_STRING));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      PartitionTypeCreateRequestDto request = requestMapper.mapCreate((PartitionTypeDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    domainSelectOneController.getSelectOneMenu().setRequired(true);
    domainSelectOneController.getSelectOneMenu().addValueConsumer(domainIdentifierConsumer());

    valueSourceSelectOneController.getSelectOneMenu().setRequired(true);
    valueSourceSelectOneController.getSelectOneMenu()
        .addValueConsumer(valueSourceIdentifierConsumer());
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((PartitionTypeDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((PartitionTypeDto) entity).getName());
      domainSelectOneController.getSelectOneMenu()
          .writeValue(((PartitionTypeDto) entity).getDomainIdentifier());
      valueSourceSelectOneController.getSelectOneMenu()
          .writeValue(((PartitionTypeDto) entity).getValueSourceIdentifier());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionTypeDto.class).setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionTypeDto.class).setName(name);
  }

  Consumer<String> domainIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionTypeDto.class)
        .setDomainIdentifier(identifier);
  }

  Consumer<String> valueSourceIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionTypeDto.class)
        .setValueSourceIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      PartitionTypeUpdateRequestDto request = requestMapper.mapUpdate((PartitionTypeDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            domainSelectOneController.getSelectOneMenu(),
            valueSourceSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
