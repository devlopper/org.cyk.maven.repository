package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TemplateDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class TemplateFilter extends AbstractIdentifiableFilter {

}
