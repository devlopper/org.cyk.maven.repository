package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class DocumentTypeGroupListPage extends AbstractPage {

  @Inject
  @Getter
  DocumentTypeGroupController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + DocumentTypeGroupDto.NAME;
  }

  public static final String OUTCOME = "documentTypeGroupListPage";
}
