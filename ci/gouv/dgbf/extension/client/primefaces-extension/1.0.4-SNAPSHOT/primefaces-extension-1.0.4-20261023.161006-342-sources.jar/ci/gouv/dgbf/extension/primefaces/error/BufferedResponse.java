package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.WriteListener;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpServletResponseWrapper;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;

/**
 * Cette classe retient une réponse en mémoire jusqu'à {@link #finish()}, sauf au-delà de sa
 * limite, après un envoi d'erreur ou une redirection : elle est alors transmise directement.
 *
 * <p>Tant qu'elle est retenue, elle n'est jamais engagée : réinitialiser la réponse efface donc
 * tout ce qui a été rendu. Le texte est conservé en caractères et encodé à l'envoi, avec
 * l'encodage alors défini.
 *
 * @author Christian
 */
class BufferedResponse extends HttpServletResponseWrapper {
  private final int limit;
  private final ByteArrayOutputStream bytes = new ByteArrayOutputStream();
  private final StringBuilder chars = new StringBuilder();
  private boolean direct;
  private ServletOutputStream stream;
  private PrintWriter writer;

  BufferedResponse(HttpServletResponse response, int limit) {
    super(response);
    this.limit = limit;
  }

  @Override
  public ServletOutputStream getOutputStream() {
    if (stream == null) {
      stream = new ServletOutputStream() {
        @Override
        public void write(int value) throws IOException {
          if (direct) {
            getResponse().getOutputStream().write(value);
            return;
          }
          bytes.write(value);
          releaseBeyondLimit(bytes.size());
        }

        @Override
        public boolean isReady() {
          return true;
        }

        @Override
        public void setWriteListener(WriteListener listener) {
          throw new UnsupportedOperationException("Écriture asynchrone non prise en charge");
        }
      };
    }
    return stream;
  }

  @Override
  public PrintWriter getWriter() {
    if (writer == null) {
      writer = new PrintWriter(new Writer() {
        @Override
        public void write(char[] buffer, int offset, int length) throws IOException {
          if (direct) {
            getResponse().getWriter().write(buffer, offset, length);
            return;
          }
          chars.append(buffer, offset, length);
          releaseBeyondLimit(chars.length());
        }

        @Override
        public void flush() {
          // Retenu jusqu'à la fin de la requête ; le conteneur vide ensuite sa réponse.
        }

        @Override
        public void close() {
          // La réponse est terminée par finish() ou par le conteneur.
        }
      });
    }
    return writer;
  }

  private void releaseBeyondLimit(int size) throws IOException {
    if (size > limit) {
      direct = true;
      if (writer == null) {
        getResponse().getOutputStream().write(bytes.toByteArray());
      } else {
        getResponse().getWriter().append(chars);
      }
      clear();
    }
  }

  private void clear() {
    bytes.reset();
    chars.setLength(0);
  }

  /**
   * Cette méthode envoie la réponse retenue, avec sa longueur.
   *
   * @throws IOException si l'envoi échoue
   */
  void finish() throws IOException {
    if (direct) {
      return;
    }
    byte[] content = writer == null ? bytes.toByteArray()
        : chars.toString().getBytes(getCharacterEncoding());
    super.setContentLength(content.length);
    getResponse().getOutputStream().write(content);
  }

  @Override
  public boolean isCommitted() {
    return direct && super.isCommitted();
  }

  @Override
  public void reset() {
    clear();
    super.reset();
  }

  @Override
  public void resetBuffer() {
    clear();
    super.resetBuffer();
  }

  @Override
  public void flushBuffer() {
    // Retenu jusqu'à la fin de la requête.
  }

  @Override
  public void setBufferSize(int size) {
    // La taille est fixée par la limite de rétention.
  }

  @Override
  public int getBufferSize() {
    return limit;
  }

  @Override
  public void setContentLength(int length) {
    // Calculée à l'envoi.
  }

  @Override
  public void setContentLengthLong(long length) {
    // Calculée à l'envoi.
  }

  @Override
  public void sendError(int status, String message) throws IOException {
    bypass();
    super.sendError(status, message);
  }

  @Override
  public void sendError(int status) throws IOException {
    bypass();
    super.sendError(status);
  }

  @Override
  public void sendRedirect(String location) throws IOException {
    bypass();
    super.sendRedirect(location);
  }

  private void bypass() {
    clear();
    direct = true;
  }
}
