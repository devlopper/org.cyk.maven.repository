package ci.gouv.dgbf.extension.primefaces.page;

import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.IdentifiableFilterGetter;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import java.util.function.Consumer;

/**
 * Cette interface représente la base de page d'identifiable.
 *
 * @param <I> type de l'identifiable
 * @param <F> type de filtre de l'identifiable
 * @author Christian
 */
public interface IdentifiablePage<I, F extends AbstractIdentifiableFilter> {

  /**
   * Cette méthode permet d'instantier le filtre.
   *
   * @return filtre
   */
  default IdentifiableFilterGetter<F> instantiateFilter() {
    IdentifiableFilterGetter<F> filterGetter =
        new IdentifiableFilterGetter<F>(getIdentifiableFilterClass())
            .onBlankIdentifier(this::processFilterWhenIdentifierBlank)
            .connectedUserSharedSelectionPageOutcome(getConnectedUserSharedSelectionPageOutcome());
    filterGetter.viewParameterValueGetter().authorized(isViewParameterValueAuthorized());
    filterGetter.onFilterPresent(onFilterPresent());
    return filterGetter;
  }

  Class<F> getIdentifiableFilterClass();

  void processFilterWhenIdentifierBlank(F filter);

  String getConnectedUserSharedSelectionPageOutcome();

  /**
   * Cette méthode permet de savoir si la valeur du parametre de la vue est autorisée.
   *
   * @return vrai si la valeur du parametre de la vue est autorisée
   */
  default Boolean isViewParameterValueAuthorized() {
    return true;
  }

  /**
   * Cette méthode permet d'instantier et d'obtenir le filtre.
   *
   * @return filtre
   */
  default F instantiateAndGetFilter() {
    IdentifiableFilterGetter<F> filterGetter = instantiateFilter();
    return filterGetter.get();
  }

  OneRetrievable<I> getIdentifiableRetriever();

  /**
   * Cette méthode permet d'obtenir un consommateur du filtre.
   *
   * @return consommateur du filtre
   */
  default Consumer<F> onFilterPresent() {
    return filter -> {
      I identifiable = getIdentifiableRetriever().getOne(getIdentifiableProjection(),
          filter.toDto(), getUserIdentifier(), null);
      initializeWhenFilterPresent(identifiable);
    };
  }

  /**
   * Cette méthode permet d'obtenir la projection.
   *
   * @return projection
   */
  default ProjectionDto getIdentifiableProjection() {
    return new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER);
  }

  String getUserIdentifier();

  /**
   * Cette méthode permet d'initialiser lorsque le filtre est présent.
   *
   * @param identifiable identifiable
   */
  default void initializeWhenFilterPresent(I identifiable) {
    if (identifiable == null) {
      initializeWhenIdentifiableNull();
    } else {
      initializeWhenIdentifiableNotNull(identifiable);
    }
  }

  /**
   * Cette méthode d'initialiser lorsque l'identifiable est nul.
   */
  default void initializeWhenIdentifiableNull() {}

  /**
   * Cette méthode d'initialiser lorsque l'identifiable est non nul.
   */
  default void initializeWhenIdentifiableNotNull(I identifiable) {}

}
