package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketPriorityDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-24T16:11:31+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketPriorityRequestMapperImpl implements TicketPriorityRequestMapper {

    @Override
    public TicketPriorityService.TicketPriorityCreateRequestDto mapCreate(TicketPriorityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketPriorityService.TicketPriorityCreateRequestDto ticketPriorityCreateRequestDto = new TicketPriorityService.TicketPriorityCreateRequestDto();

        ticketPriorityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketPriorityCreateRequestDto.setCode( arg0.getCode() );
        ticketPriorityCreateRequestDto.setName( arg0.getName() );

        return ticketPriorityCreateRequestDto;
    }

    @Override
    public TicketPriorityService.TicketPriorityUpdateRequestDto mapUpdate(TicketPriorityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketPriorityService.TicketPriorityUpdateRequestDto ticketPriorityUpdateRequestDto = new TicketPriorityService.TicketPriorityUpdateRequestDto();

        ticketPriorityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketPriorityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketPriorityUpdateRequestDto.setCode( arg0.getCode() );
        ticketPriorityUpdateRequestDto.setName( arg0.getName() );

        return ticketPriorityUpdateRequestDto;
    }
}
