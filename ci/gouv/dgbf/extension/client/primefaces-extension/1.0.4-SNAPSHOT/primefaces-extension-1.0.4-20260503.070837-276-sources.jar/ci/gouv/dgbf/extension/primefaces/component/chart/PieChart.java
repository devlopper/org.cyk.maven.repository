package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import java.util.concurrent.atomic.AtomicInteger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartDataSet;
import org.primefaces.model.charts.pie.PieChartDataSet;
import org.primefaces.model.charts.pie.PieChartModel;
import org.primefaces.model.charts.pie.PieChartOptions;

/**
 * Cette classe représente un camembert.
 *
 * @author Christian
 *
 */
public class PieChart extends AbstractChart<PieChartModel> {

  public PieChart() {
    contentFilePath = Constant.SLASH + "extension/component/chart/pie/default.xhtml";
  }

  /**
   * Cette classe représentente un constructeur de modèle.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class ModelBuilder
      extends AbstractModelBuilder<PieChartModel, PieChartOptions, PieChart> {

    @Override
    ChartDataSet instantiateCharDataSet(ChartDataSetDto dto, int dtosCount,
        AtomicInteger dtoIndex) {
      PieChartDataSet chartDataSet = new PieChartDataSet();
      chartDataSet.setData(dto.getDatasNumbers());
      styleDataSet(chartDataSet);
      return chartDataSet;
    }

    @Override
    PieChartModel instantateModel() {
      return new PieChartModel();
    }

    @Override
    void processModel(PieChartModel model, ChartData chartData) {
      model.setData(chartData);
    }

    @Override
    PieChartOptions instantateOptions() {
      return new PieChartOptions();
    }

    @Override
    void processOptions(PieChartModel model, ChartData chartData, PieChartOptions options) {
      model.setOptions(options);
    }

    void styleDataSet(PieChartDataSet pieChartDataSet) {
      pieChartDataSet.setBackgroundColor(colorPalette.getRgbaList());
      pieChartDataSet.setBorderColor(colorPalette.getRgbList());
    }
  }

  /**
   * Cette méthode permet de créer et d'obtenir {@link Builder}.
   *
   * @return {@link Builder}
   */
  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représentente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder
      extends AbstractBuilder<PieChartModel, PieChartOptions, ModelBuilder, PieChart> {

    @Override
    protected PieChart instantiateWidget() {
      return new PieChart();
    }
  }
}
