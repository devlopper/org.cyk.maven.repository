package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import jakarta.enterprise.context.Dependent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Cette classe représente un contrôleur de gestion d'un ensemble de {@link AbstractInput}.
 */
@Dependent
public class InputsGroupController extends AbstractController {

  Collection<AbstractInput<?>> inputs;

  /**
   * Cette méthode permet d'ajouter un tableau de {@link AbstractInput}.
   *
   * @param inputs tableau de {@link AbstractInput}
   * @return {@link InputsGroupController}
   */
  public InputsGroupController add(AbstractInput<?>... inputs) {
    add(Arrays.stream(inputs).toList());
    return this;
  }

  /**
   * Cette méthode permet d'ajouter une collection de {@link AbstractInput}.
   *
   * @param inputs collection de {@link AbstractInput}
   * @return {@link InputsGroupController}
   */
  public InputsGroupController add(Collection<AbstractInput<?>> inputs) {
    if (CollectionCore.isNotEmpty(inputs)) {
      inputs().addAll(inputs);
    }
    return this;
  }

  Collection<AbstractInput<?>> inputs() {
    if (inputs == null) {
      inputs = new ArrayList<>();
    }
    return inputs;
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return Optional.ofNullable(inputs).orElse(Collections.emptyList()).stream()
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
