package ci.gouv.dgbf.system.identity.server.api;

/**
 * Cette classe représente les codes de {@link IdentityEmailAddressStatus}.
 *
 * @author Christian
 *
 */
public class IdentityEmailAddressStatusCode {

  private IdentityEmailAddressStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Vérifié.
   */
  public static final String VERIFIED = "VERIFIE";

  /**
   * Revoqué.
   */
  public static final String REVOKED = "REVOQUE";
}
