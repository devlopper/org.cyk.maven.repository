package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollJobGroupTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollJobGroupTypeRequestMapperImpl implements PayrollJobGroupTypeRequestMapper {

    @Override
    public PayrollJobGroupTypeService.PayrollJobGroupTypeCreateRequestDto mapCreate(PayrollJobGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobGroupTypeService.PayrollJobGroupTypeCreateRequestDto payrollJobGroupTypeCreateRequestDto = new PayrollJobGroupTypeService.PayrollJobGroupTypeCreateRequestDto();

        payrollJobGroupTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollJobGroupTypeCreateRequestDto.setCode( arg0.getCode() );
        payrollJobGroupTypeCreateRequestDto.setName( arg0.getName() );

        return payrollJobGroupTypeCreateRequestDto;
    }

    @Override
    public PayrollJobGroupTypeService.PayrollJobGroupTypeUpdateRequestDto mapUpdate(PayrollJobGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobGroupTypeService.PayrollJobGroupTypeUpdateRequestDto payrollJobGroupTypeUpdateRequestDto = new PayrollJobGroupTypeService.PayrollJobGroupTypeUpdateRequestDto();

        payrollJobGroupTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollJobGroupTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollJobGroupTypeUpdateRequestDto.setCode( arg0.getCode() );
        payrollJobGroupTypeUpdateRequestDto.setName( arg0.getName() );

        return payrollJobGroupTypeUpdateRequestDto;
    }
}
