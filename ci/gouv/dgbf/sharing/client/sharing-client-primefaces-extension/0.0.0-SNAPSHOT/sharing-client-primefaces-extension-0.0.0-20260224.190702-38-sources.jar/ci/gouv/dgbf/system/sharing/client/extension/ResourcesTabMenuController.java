package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.extension.server.service.api.filter.UserNameFilter;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverFilter;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.Dependent;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link TabMenu} des {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourcesTabMenuController {

  @Getter
  TabMenu menu;

  @Getter
  @Setter
  String requestParameterTypeName;

  @Getter
  @Setter
  String requestParameterLocationName;

  @Getter
  @Setter
  String requestParameterUserNameName;

  @Getter
  @Setter
  String requestParameterUserNameValue;

  /**
   * Cette méthode permet de construire.
   */
  protected ResourcesTabMenuController() {
    requestParameterUserNameName = UserNameFilter.JSON_KEY;
    requestParameterTypeName = AbstractResourceOrReceiverFilter.JSON_TYPE;
    requestParameterLocationName = AbstractResourceOrReceiverFilter.JSON_LOCATION;

    menu = new TabMenu();
    menu.setMenuItemStyleClassPrefix("sharing-resource");
    menu.getOutcomesMap().put(ResourceListPage.class, ResourceListPage.OUTCOME);
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    addMenu(ResourceType.SECTION, Location.BUDGETARY_CLASSIFICATION,
        requestParameterUserNameValue, "pi pi-building", null);
    
    addMenu(ResourceType.ADMINISTRATIVE_UNIT, Location.BUDGETARY_CLASSIFICATION,
        requestParameterUserNameValue, "pi pi-warehouse", null);

    menu.initialize();
  }

  void addMenu(ResourceType type, Location location, String userName, String menuItemIcon,
      String count) {
    menu.tabBuilder().menuItemValue("%s(%s)".formatted(type.getName(), location.getName()))
        .menuItemIcon(menuItemIcon).type(ResourceListPage.class)
        .addMenuItemParameter(requestParameterTypeName, type.name())
        .addMenuItemParameter(requestParameterLocationName, location.name())
        .addMenuItemParameter(requestParameterUserNameName, userName)
        .menuItemStyleClassSuffix(
            "%s_%s".formatted(type.name().toLowerCase(), location.name().toLowerCase()))
        .count(count).build();
  }
}
