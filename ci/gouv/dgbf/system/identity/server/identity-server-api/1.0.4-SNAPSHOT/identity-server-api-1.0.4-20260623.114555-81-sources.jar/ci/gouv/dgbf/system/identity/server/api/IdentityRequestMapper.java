package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityDeclareRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentityDto}.

    @author Christian
               """)
public interface IdentityRequestMapper
    extends RequestMapper<IdentityDto, IdentityCreateRequestDto, IdentityUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link IdentityDeclareRequestDto}.
   *
   * @param identity {@link IdentityDto}
   * @return {@link IdentityDeclareRequestDto}
   */
  IdentityDeclareRequestDto mapDeclare(IdentityDto identity);
  
}
