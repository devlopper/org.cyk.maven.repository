package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.MenuItem;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController.Viewer;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.RoleRequestMapper;
import ci.gouv.dgbf.system.user.server.api.RoleService;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleRevokeRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserService;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RoleController extends AbstractController {

  @Inject
  RoleClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  RoleFilterController filterController;

  @Inject
  RoleRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController descriptionInputTextController;

  @Inject
  @Getter
  ApplicationSelectOneController applicationSelectOneController;

  @Inject
  @Getter
  IdentifiableProcessingController assignUsersProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController revokeProcessingController;

  @Inject
  @Getter
  UserSelectOneController userSelectOneController;

  @Inject
  @Getter
  UserSelectManyController userSelectManyController;

  @Getter
  @Setter
  private List<UserDto> selectedSystemAdminUsers;

  @Inject
  UserClient userClient;

  @Inject
  @Getter
  IdentifiableProcessingController assignSystemAdministratorProcessingController;

  @Getter
  @Setter
  private List<UserDto> users;

  @Getter
  @Setter
  UserFilter userFilter;

  @Getter
  @Setter
  private List<String> selectedUserIdentifiers = new ArrayList<>();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = RoleDto.NAME;
    users = new ArrayList<>();
    selectedSystemAdminUsers = new ArrayList<>();
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(RoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(RoleService.PATH);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(RoleReadUsersPage.OUTCOME);

    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        RoleDto.JSON_DESCRIPTION, RoleDto.JSON_APPLICATION_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      RoleCreateRequestDto request = requestMapper.mapCreate((RoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME, RoleDto.JSON_DESCRIPTION,
            RoleDto.JSON_APPLICATION_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    descriptionInputTextController.setOutputLableValue("Description");
    descriptionInputTextController.getInputTextarea().addValueConsumer(descriptionConsumer());

    applicationSelectOneController.getSelectOneMenu().setRequired(true);
    applicationSelectOneController.getSelectOneMenu()
        .addValueConsumer(applicationIdentifierConsumer());

    initializeAssignUsersProcessingController();
    initializeRevokeProcessingController();
    initializeUserSelectManyController();

    /* Menu bouton d'actions (comme sur la liste des utilisateurs) */
    assignUsersProcessingController.addToRecordMenuButton(listController.recordMenuButton());
    revokeProcessingController.addToRecordMenuButton(listController.recordMenuButton());
  }

  /**
   * Cette méthode permet d'ajouter "Consulter" (bouton de lecture) au menu "..." de chaque ligne,
   * à la place de l'icône séparée. Appel explicite car ce bouton pointe vers
   * {@link RoleReadUsersPage}, une page absente des consommateurs qui n'en ont pas besoin (ex.
   * ticket-client) : contrairement à l'assignation/révocation, l'ajouter systématiquement ici
   * romprait ces consommateurs.
   */
  public void addGotoReadPageButtonToRecordMenuButton() {
    listController.recordMenuButton().buttonBuilder()
        .menuItemBuilder((MenuItem.Builder) MenuItem.newBuilder()
            .outcome(listController.getGotoReadPageButton().getOutcome())
            .value(listController.getGotoReadPageButton().getTitle())
            .icon(listController.getGotoReadPageButton().getIcon()))
        .build();
    listController.getGotoReadPageButton().setRendered(false);
  }


  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {

      codeInputTextController.getInputText().writeValue(((RoleDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((RoleDto) entity).getName());
      descriptionInputTextController.getInputTextarea()
          .writeValue(((RoleDto) entity).getDescription());

      applicationSelectOneController.getSelectOneMenu()
          .writeValue(((RoleDto) entity).getApplicationIdentifier());
    };
  }

  /**
   * Initialise le contrôleur de sélection multiple d'utilisateurs pour l'administrateur système.
   * Basé sur le pattern d'ApplicationController.
   */
  void initializeUserSelectManyController() {
    userSelectManyController.setOutputLableValue("Utilisateurs");
    userSelectManyController.getAutoComplete().setMultiple(true);
    userSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeUser(query)));
  }

  /**
   * Méthode de complétion pour l'autocomplete des utilisateurs.
   * Identique à ApplicationController.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants
   */
  public List<UserDto> completeUser(String query) {
    if (query == null || query.trim().length() < 2) {
      return List.of();
    }

    UserFilter filter = new UserFilter();
    filter.setNameContains(query);

    PageDto pageDto = new PageDto();
    pageDto.setIndex(0);
    pageDto.setSize(20);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_AS_STRING
    );

    UserService.UserGetManyResponseDto response =
        userClient.getMany(projection,
            filter.toDto(),
            pageDto,
            userIdentifier,
            null);

    return response != null && response.getDatas() != null
        ? response.getDatas()
        : List.of();
  }

  Consumer<String> applicationIdentifierConsumer() {
    return identifier -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setApplicationIdentifier(identifier);
  }

  Consumer<String> descriptionConsumer() {
    return description -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RoleDto.class).setDescription(description);
  }


  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      RoleUpdateRequestDto request = requestMapper.mapUpdate((RoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            descriptionInputTextController.getInputTextarea(),
            applicationSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }

  void initializeAssignUsersProcessingController() {
    assignUsersProcessingController.setViewer(Viewer.DIALOG);
    assignUsersProcessingController.prepareDialog(RoleDto.class, "Assignation d'utilisateurs",
        "pi pi-user-plus", assignUsersFunction(), "assignUsersForm", client);
    assignUsersProcessingController.setListController(listController);
    assignUsersProcessingController.addShowDialogConsumer(loadAvailableRolesForAssignment());
    assignUsersProcessingController.initialize();
  }

  void initializeRevokeProcessingController() {
    revokeProcessingController.setViewer(Viewer.DIALOG);
    revokeProcessingController.prepareDialog(RoleDto.class, "Revocation d'utilisateurs",
        "pi pi-user-minus", revokeFunction(), "revokeForm", client);
    revokeProcessingController.setListController(listController);
    revokeProcessingController.addShowDialogConsumer(loadAssignedRoles());
    revokeProcessingController.initialize();
  }

  UnaryOperator<Object> assignUsersFunction() {
    return entity -> {
      RoleAssignRequestDto request = new RoleAssignRequestDto();
      request.setIdentifier(((RoleDto) entity).getIdentifier());
      request.setUserIdentifiers(
          users.stream().map(user -> user.getIdentifier()).collect(Collectors.toSet()));
      request.setAuditWho(this.userIdentifier);
      return client.assign(request);
    };
  }

  /**
   * Cette méthode permet l'insertion d'un utilisateur sélectionné. dans le tableau.
   *
   */
  public void addSelectedUser() {
    String selectedUserId = (String) userSelectOneController.getSelectOneMenu().getValue();
    List<SelectItem> listUser = userSelectOneController.getSelectOneMenu().getChoices();
    SelectItem[] selectItemSelected = {null};
    listUser.stream().filter(selectItem -> selectItem.getValue() != null)
        .filter(selectItem -> selectItem.getValue().equals(selectedUserId)).forEach(selectItem -> {
          UserDto user = new UserDto();
          user.setIdentifier((String) selectItem.getValue());
          user.setName(selectItem.getLabel());
          users.add(user);

          selectItemSelected[0] = selectItem;
        });

    userSelectOneController.getSelectOneMenu().getChoices().remove(selectItemSelected[0]);
  }


  UnaryOperator<Object> revokeFunction() {
    return entity -> {
      // Créer et envoyer la requête
      RoleRevokeRequestDto request = new RoleRevokeRequestDto();
      request.setIdentifier(((RoleDto) entity).getIdentifier());
      request.setUserIdentifiers(
          users.stream().map(user -> user.getIdentifier()).collect(Collectors.toSet()));
      request.setAuditWho(this.userIdentifier);
      return client.revoke(request);
    };
  }

  /**
   * Charge les utilisateurs disponibles pour l'assignation (non encore assignés au rôle).
   */
  public Consumer<String> loadAvailableRolesForAssignment() {
    return identifier -> {
      UserFilter filter = new UserFilter();
      filter.setUnassignedRoleIdentifier(identifier);
      userSelectOneController.setFilter(filter.toDto());
      userSelectOneController.computeSelectOneMenuChoices();
    };
  }

  /**
   * Charge les utilisateurs déjà assignés au rôle (pour la révocation).
   */
  public Consumer<String> loadAssignedRoles() {
    return identifier -> {
      UserFilter filter = new UserFilter();
      filter.setAssignedRoleIdentifier(identifier);
      userSelectOneController.setFilter(filter.toDto());
      userSelectOneController.computeSelectOneMenuChoices();
    };
  }

  /**
   * Méthode pour obtenir le label d'affichage d'un utilisateur.
   *
   * @param user l'utilisateur
   * @return le label formaté
   */
  public String getUserLabel(UserDto user) {
    return user.getName() + " (" + user.getIdentityAsString() + ")";
  }

  /**
   * Méthode pour assigner un administrateur système.
   */
  public void assignSystemAdministratorAction() {
    Set<String> userIdentifiers =
        new HashSet<>(userSelectManyController.getAutoComplete().getValue());

    RoleService.RoleAssignSystemAdministratorRequestDto request =
        new RoleService.RoleAssignSystemAdministratorRequestDto();
    request.setUserIdentifiers(userIdentifiers);
    client.assignSystemAdministrator(request);
  }

  /**
   * Cette méthode permet de préparer la sélection multiple.
   *
   * @param controller     controller
   * @param client         client
   * @param userIdentifier user
   */

  public static void prepareSelectManyController(RoleSelectManyController controller,
                                                 RoleClient client,
                                                 String userIdentifier) {
    controller.getAutoComplete().setMultiple(true);
    controller
        .getAutoComplete()
        .setOnCompleteFunction(query ->
            new ArrayList<>(complete(client, query, userIdentifier)));
  }

  /**
   * Cette méthode permet de compléter la liste des rôles.
   *
   * @param client         client
   * @param query          query
   * @param userIdentifier user
   * @return list of users
   */
  static List<RoleDto> complete(RoleClient client, String query, String userIdentifier) {
    GetManyRequestDto request = new GetManyRequestDto();
    RoleFilter filter = new RoleFilter();
    filter.setNameContains(query);
    request.useFilter(filter);
    request.projection().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME
    );
    request.setAuditWho(userIdentifier);
    RoleService.RoleGetManyResponseDto response = client.getMany(request);
    return RoleService.RoleGetManyResponseDto.getDatas(RoleDto.class, response);
  }

}

