package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityClient;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DataEntityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DataEntitySelectOneController extends AbstractSelectOneIdentifiableController<
    DataEntityDto, DataEntityGetManyResponseDto, DataEntityClient> {

  @Getter
  @Inject
  DataEntityClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected DataEntitySelectOneController() {
    super(DataEntityDto.class, SelectItemLabelStrategy.NAME);
  }
}
