package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un attribut de filtre de {@link ValueSelectorDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueSelectorFilterAttributeDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasValueSelectorIdentifierDto, HasValueSelectorAsStringDto {

  @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
  private String valueSelectorIdentifier;

  @JsonbProperty(JSON_VALUE_SELECTOR_AS_STRING)
  private String valueSelectorAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idAttributFiltreSelecteurValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "attributFiltreSelecteurValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "attribut de filtre de sélecteur de valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "attributs de filtre de sélecteur de valeur";
}
