package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PartitionTypeService}.
 *
 * @author Boobacool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PartitionTypeClient extends AbstractClient<PartitionTypeService>
    implements GetByIdentifier<PartitionTypeDto>,
    GetMany<PartitionTypeService.PartitionTypeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PartitionTypeClient service(PartitionTypeService service) {
    return (PartitionTypeClient) super.service(service);
  }

  /**
   * {@link PartitionTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PartitionTypeService.PartitionTypeCreateRequestDto request) {
    return new CreateExecutor(PartitionTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PartitionTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionTypeService.PartitionTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PartitionTypeService.PartitionTypeGetManyResponseDto>(
        PartitionTypeService.PartitionTypeGetManyResponseDto.class,
        PartitionTypeService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PartitionTypeService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionTypeService.PartitionTypeGetManyResponseDto getMany(ProjectionDto projection,
                                                                      FilterDto filter,
                                                                      PageDto page, String auditWho,
                                                                      String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link HierarchyService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PartitionTypeDto>(PartitionTypeDto.class,
        PartitionTypeService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PartitionTypeService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PartitionTypeDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                                 String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PartitionTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PartitionTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PartitionTypeDto>(PartitionTypeDto.class,
        PartitionTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PartitionTypeService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionTypeDto getByIdentifier(String identifier, ProjectionDto projection,
                                          String auditWho,
                                          String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PartitionTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(
      PartitionTypeService.PartitionTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(PartitionTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PartitionTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PartitionTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PartitionTypeService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
