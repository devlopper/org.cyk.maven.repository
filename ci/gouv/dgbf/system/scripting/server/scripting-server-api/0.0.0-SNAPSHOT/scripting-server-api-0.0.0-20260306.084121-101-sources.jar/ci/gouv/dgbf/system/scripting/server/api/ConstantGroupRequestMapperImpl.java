package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ConstantGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ConstantGroupRequestMapperImpl implements ConstantGroupRequestMapper {

    @Override
    public ConstantGroupService.ConstantGroupCreateRequestDto mapCreate(ConstantGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantGroupService.ConstantGroupCreateRequestDto constantGroupCreateRequestDto = new ConstantGroupService.ConstantGroupCreateRequestDto();

        constantGroupCreateRequestDto.setName( arg0.getName() );
        constantGroupCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );

        return constantGroupCreateRequestDto;
    }

    @Override
    public ConstantGroupService.ConstantGroupUpdateRequestDto mapUpdate(ConstantGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantGroupService.ConstantGroupUpdateRequestDto constantGroupUpdateRequestDto = new ConstantGroupService.ConstantGroupUpdateRequestDto();

        constantGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        constantGroupUpdateRequestDto.setName( arg0.getName() );
        constantGroupUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );

        return constantGroupUpdateRequestDto;
    }
}
