package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitService.BudgetSpecializationUnitGetManyResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SectionDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class BudgetSpecializationUnitSelectOneController extends
    AbstractSelectOneIdentifiableController<BudgetSpecializationUnitDto,
    BudgetSpecializationUnitGetManyResponseDto, BudgetSpecializationUnitClient> {

  @Inject
  @Getter
 BudgetSpecializationUnitClient client;

  protected BudgetSpecializationUnitSelectOneController() {
    super(BudgetSpecializationUnitDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
