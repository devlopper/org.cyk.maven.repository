package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un réel.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputFloat extends AbstractInputNumber<Float> {

  public InputFloat() {
    decimalPlaces = "2";
  }
  
}
