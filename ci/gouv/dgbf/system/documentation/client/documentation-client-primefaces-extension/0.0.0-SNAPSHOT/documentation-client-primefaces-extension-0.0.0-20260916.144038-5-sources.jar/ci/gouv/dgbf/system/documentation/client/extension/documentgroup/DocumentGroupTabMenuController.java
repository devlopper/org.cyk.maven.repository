package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTypedTabMenuController;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de {@link DocumentGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class DocumentGroupTabMenuController
    extends AbstractTypedTabMenuController<DocumentGroupDto, DocumentationIconManager> {

  @Inject
  @Getter
  DocumentationIconManager iconManager;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentGroupTabMenuController() {
    super(DocumentGroupDto.class);
  }

}
