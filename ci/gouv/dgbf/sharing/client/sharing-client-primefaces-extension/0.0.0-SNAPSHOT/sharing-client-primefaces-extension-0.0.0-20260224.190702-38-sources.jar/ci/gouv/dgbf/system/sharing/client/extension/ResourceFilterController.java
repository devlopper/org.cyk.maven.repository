package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverFilter;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceFilter;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceFilterController extends AbstractFilterController<ResourceFilter> {

  @Inject
  @Getter
  ResourceTypeSelectOneController typeSelectOneController;

  @Inject
  @Getter
  LocationSelectOneController locationSelectOneController;

  @Inject
  @Getter
  InputTextController userNameInputTextController;

  @Inject
  @Getter
  SelectBooleanController isNationalPublicInstitutionSelectBooleanController;

  @Inject
  @Getter
  SelectBooleanController isLocalAuthoritySelectBooleanController;

  /**
   * Cette méthode permet de construire.
   */
  public ResourceFilterController() {
    super(ResourceFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setReference(getRequestParameter(AbstractResourceOrReceiverFilter.JSON_REFERENCE));
    filter.setType(Core.getEnumerationValueByName(ResourceType.class,
        getRequestParameter(AbstractResourceOrReceiverFilter.JSON_TYPE)));
    filter.setLocation(Core.getEnumerationValueByName(Location.class,
        getRequestParameter(AbstractResourceOrReceiverFilter.JSON_LOCATION)));

    typeSelectOneController.getSelectOneMenu().addValueConsumer(
        name -> filter.setType(Core.getEnumerationValueByName(ResourceType.class, name)));

    isNationalPublicInstitutionSelectBooleanController.setOutputLableValue("Est EPN");
    isNationalPublicInstitutionSelectBooleanController.getSelectOneRadioBoolean()
        .addTrueOrFalseChoices(true)
        .addValueConsumer(yes -> filter.setIsNationalPublicInstitution(yes));

    isLocalAuthoritySelectBooleanController.setOutputLableValue("Est collectivité");
    isLocalAuthoritySelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices(true)
        .addValueConsumer(yes -> filter.setIsLocalAuthority(yes));
  }
}

