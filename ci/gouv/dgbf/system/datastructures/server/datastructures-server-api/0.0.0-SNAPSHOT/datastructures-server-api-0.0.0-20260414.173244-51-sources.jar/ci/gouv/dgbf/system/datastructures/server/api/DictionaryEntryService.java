package ci.gouv.dgbf.system.datastructures.server.api;

import static ci.gouv.dgbf.extension.core.segregation.HasDefaultValueDto.JSON_DEFAULT_VALUE;
import static ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto.JSON_VALUE_TYPE;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Path(value = DictionaryEntryService.PATH)
@Tag(name = "Gestion des entrées de dictionnaire")
public interface DictionaryEntryService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "entreeDictionnaire";


  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Desysoft
   */
  interface SaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du dictionnaire.
     *
     * @return l'identifiant du dictionnaire
     */
    String getDictionaryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du dictionnaire.
     *
     * @param dictionaryIdentifier l'identifiant du dictionnaire
     */
    void setDictionaryIdentifier(String dictionaryIdentifier);


    /**
     * Cette méthode permet d'obtenir le type de valeur.
     *
     * @return le type de valeur
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner le type de valeur.
     *
     */
    void setValueType(ValueType valueType);

    /**
     * Cette méthode permet d'obtenir la valeur par défaut.
     *
     * @return la valeur par défaut
     */
    String getDefaultValue();

    /**
     * Cette méthode permet d'assigner la valeur par défaut.
     *
     */
    void setDefaultValue(String defaultValue);


    /**
     * {@link DictionaryEntryDto#JSON_DICTIONARY_IDENTIFIER}.
     */
    String JSON_DICTIONARY_IDENTIFIER = DictionaryEntryDto.JSON_DICTIONARY_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DictionaryEntryCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class DictionaryEntryCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SaveRequestDto {

    @JsonbProperty(JSON_DICTIONARY_IDENTIFIER)
    private String dictionaryIdentifier;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_DEFAULT_VALUE)
    private String defaultValue;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = DictionaryEntryGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  public static class DictionaryEntryGetManyResponseDto
      extends AbstractGetByPageResponseDto<DictionaryEntryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DictionaryEntryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DictionaryEntryDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DictionaryEntryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DictionaryEntryUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class DictionaryEntryUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SaveRequestDto {

    @JsonbProperty(JSON_DICTIONARY_IDENTIFIER)
    private String dictionaryIdentifier;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;

    @JsonbProperty(JSON_DEFAULT_VALUE)
    private String defaultValue;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ENTREE_DICTIONNAIRE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DictionaryEntryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

