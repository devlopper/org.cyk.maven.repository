package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexClient;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService.PayIndexGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayIndexDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayIndexSelectOneController extends AbstractSelectOneIdentifiableController<
    PayIndexDto, PayIndexGetManyResponseDto, PayIndexClient> {

  @Getter
  @Inject
  PayIndexClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PayIndexSelectOneController() {
    super(PayIndexDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
