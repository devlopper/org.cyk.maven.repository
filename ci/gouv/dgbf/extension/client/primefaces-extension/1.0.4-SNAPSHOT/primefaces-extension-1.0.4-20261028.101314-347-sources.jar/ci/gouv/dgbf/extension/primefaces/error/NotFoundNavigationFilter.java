package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.servlet.DispatcherType;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Cette classe réserve la page 404 aux navigations.
 *
 * <p>Une image, un script ou une requête Ajax introuvables reçoivent un 404 sans corps : la page
 * complète, rendue dans le gabarit de l'application pour un utilisateur connecté, serait lourde et
 * créerait un identifiant de fenêtre Faces inutile.
 *
 * @author Christian
 */
public class NotFoundNavigationFilter extends HttpFilter {
  private static final long serialVersionUID = 1L;

  @Override
  protected void doFilter(HttpServletRequest request, HttpServletResponse response,
      FilterChain chain) throws IOException, ServletException {
    if (request.getDispatcherType() == DispatcherType.ERROR && !isNavigation(request)) {
      response.setStatus(HttpServletResponse.SC_NOT_FOUND);
      return;
    }
    chain.doFilter(request, response);
  }

  /**
   * Cette méthode indique si la requête affichera une page.
   *
   * @param request la requête
   * @return vrai pour un document ou un cadre ; sans {@code Sec-Fetch-Dest}, si l'en-tête
   *         {@code Accept} accepte le HTML
   */
  static boolean isNavigation(HttpServletRequest request) {
    String destination = request.getHeader("Sec-Fetch-Dest");
    if (destination != null) {
      return "document".equals(destination) || "iframe".equals(destination);
    }
    String accept = request.getHeader("Accept");
    return accept == null || accept.contains("text/html");
  }
}
