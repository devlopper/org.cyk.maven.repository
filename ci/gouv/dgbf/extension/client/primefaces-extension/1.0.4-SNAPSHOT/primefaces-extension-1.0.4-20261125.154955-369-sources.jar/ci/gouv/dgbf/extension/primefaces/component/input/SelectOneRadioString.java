package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur chaine de caractères par des boutons radio.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectOneRadioString extends AbstractSelectOneString {

  public static final String LAYOUT_VERTICAL = "pageDirection";
  public static final String LAYOUT_HORIZONTAL = "lineDirection";

  /**
   * Disposition des boutons radio ({@code pageDirection} vertical par défaut, ou
   * {@code lineDirection} horizontal).
   */
  String layout = LAYOUT_VERTICAL;
}
