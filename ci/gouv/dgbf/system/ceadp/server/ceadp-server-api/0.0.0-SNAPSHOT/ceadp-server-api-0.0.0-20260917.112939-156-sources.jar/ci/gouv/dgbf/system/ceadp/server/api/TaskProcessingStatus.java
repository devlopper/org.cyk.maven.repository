package ci.gouv.dgbf.system.ceadp.server.api;

import lombok.Getter;

/**
 * Cette énumération représente le nom de statut de processus.
 *
 * @author Christian
 *
 */
@Getter
public enum TaskProcessingStatus {

  /**
   * Créée.
   */
  CREATED("Créée", "Créer", "Création"),
  
  /**
   * En cours.
   */
  STARTED("En cours", "Démarrer", "Démarrage"),
  
  /**
   * Suspendue.
   */
  STOPPED("Suspendue", "Suspendre", "Suspension"),
  
  /**
   * Annulée.
   */
  CANCELED("Arrêtée", "Arrêter", "Arrêt"),
  
  /**
   * Réalisée.
   */
  TERMINATED("Réalisée", "Réaliser", "Réalisation")
  
  ;

  String name;
  
  String action;

  String actionName;
  
  /**
   * Cette méthode permet d'instancier.
   *
   * @param name nom
   * @param actionName action
   */
  private TaskProcessingStatus(String name, String action, String actionName) {
    this.name = name;
    this.action = action;
    this.actionName = actionName;
  }
}
