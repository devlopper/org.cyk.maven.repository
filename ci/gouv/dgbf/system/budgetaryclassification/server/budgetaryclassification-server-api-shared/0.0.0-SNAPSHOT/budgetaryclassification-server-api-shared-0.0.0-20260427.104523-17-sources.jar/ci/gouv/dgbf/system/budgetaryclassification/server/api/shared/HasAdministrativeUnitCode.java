package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un code d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitCode extends HasField {

  /**
   * Cette méthode permet d'obtenir le code de unité administrative.
   *
   * @return code de l'unité administrative
   */
  String getAdministrativeUnitCode();

  /**
   * Cette méthode permet d'assigner le code de l'unité administrative.
   *
   * @param code code de l'unité administrative
   */
  void setAdministrativeUnitCode(String code);

  /**
   * Identifiant java du code de l'unité administrative.
   */
  String FIELD_ADMINISTRATIVE_UNIT_CODE = "administrativeUnitCode";
}
