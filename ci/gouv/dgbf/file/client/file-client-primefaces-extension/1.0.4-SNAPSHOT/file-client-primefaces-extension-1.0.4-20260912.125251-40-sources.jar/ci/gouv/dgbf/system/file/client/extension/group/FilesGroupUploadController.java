package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.ByteCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.file.client.extension.file.OpenFileViewerButtonController;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupFilter;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de téléchargement de {@link FilesGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class FilesGroupUploadController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  FileGroupClient fileGroupClient;

  @Inject
  FileClient fileClient;

  @Inject
  @Getter
  OpenFileViewerButtonController openFileViewerButtonController;

  /**
   * Si actif, n'affiche que les fichiers déjà rattachés, sans possibilité d'ajout ni de
   * suppression (widget d'upload et boutons de retrait masqués).
   */
  @Getter
  @Setter
  boolean readOnly;

  @Getter
  Map<String, FileDto> files;

  /**
   * Fichiers déjà rattachés au groupe en cours de modification (clé = identifiant du rattachement
   * Fichier de Groupe), chargés à l'ouverture du dialogue de modification.
   */
  @Getter
  Map<String, FileGroupDto> existingFileGroups;

  /**
   * Identifiants des rattachements Fichier de Groupe existants dont la suppression a été demandée,
   * en attente de confirmation par {@link #update(String, String)}.
   */
  Set<String> removedFileGroupIdentifiers;

  /**
   * Cette méthode permet de constuire.
   */
  public FilesGroupUploadController() {
    files = new LinkedHashMap<>();
    existingFileGroups = new LinkedHashMap<>();
    removedFileGroupIdentifiers = new LinkedHashSet<>();
  }

  /**
   * Cette méthode permet d'ajouter un fichier.
   *
   * @param event {@link FileUploadEvent}
   */
  public void add(FileUploadEvent event) {
    FileDto file = new FileDto();
    file.setName(event.getFile().getFileName());
    file.setBytes(event.getFile().getContent());
    file.setHash(ByteCore.digestToString(file.getBytes(), "SHA-256"));
    files.put(file.getHash(), file);
  }

  /**
   * Cette méthode permet de supprimer un fichier.
   *
   * @param key clé
   */
  public void remove(String key) {
    files.remove(key);
  }

  /**
   * Cette méthode permet de créer {@link FilesGroupDto}.
   */
  public String createTemporary() {
    FilesGroupCreateRequestDto request = new FilesGroupCreateRequestDto();
    request.setIsConfirmed(false);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(UUID.randomUUID().toString());
    CreateResponseDto response = client.create(request);
    String identifier = response.getIdentifier();
    createFiles(identifier, request.getAuditSession());
    return identifier;
  }

  /**
   * Cette méthode permet de créer les fichiers du groupe.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}.
   * @param auditSession session
   */
  public void createFiles(String groupIdentifier, String auditSession) {
    files.values().forEach(file -> createFileGroup(file, groupIdentifier, auditSession));
    files.clear();
  }

  /**
   * Cette méthode permet de charger les fichiers déjà rattachés à un groupe existant, à
   * l'ouverture du dialogue de modification.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   * @param auditWho audit acteur
   */
  public void loadExisting(String groupIdentifier, String auditWho) {
    files.clear();
    existingFileGroups.clear();
    removedFileGroupIdentifiers.clear();
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileGroupDto.JSON_FILE_AS_STRING,
        FileGroupDto.JSON_FILE_IDENTIFIER, FileGroupDto.JSON_FILE_OWNER_IDENTIFIER);
    FilterDto filter = new FilterDto();
    FileGroupFilter.setGroupIdentifier(filter, groupIdentifier);
    FileGroupGetManyResponseDto response =
        fileGroupClient.getMany(projection, filter, null, auditWho, null);
    Optional.ofNullable(response).map(r -> r.getDatas())
        .orElse(Collections.emptyList())
        .forEach(fileGroup -> existingFileGroups.put(fileGroup.getIdentifier(), fileGroup));
  }

  /**
   * Cette méthode permet de retirer un fichier déjà rattaché (suppression différée, appliquée par
   * {@link #update(String, String)}).
   *
   * @param fileGroupIdentifier identifiant du rattachement Fichier de Groupe
   */
  public void removeExisting(String fileGroupIdentifier) {
    existingFileGroups.remove(fileGroupIdentifier);
    removedFileGroupIdentifiers.add(fileGroupIdentifier);
  }

  /**
   * Cette méthode permet d'appliquer, pour un groupe existant, les ajouts ({@link #files}) et les
   * suppressions ({@link #removedFileGroupIdentifiers}) demandés depuis l'ouverture du dialogue de
   * modification.
   *
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   * @param auditWho audit acteur
   */
  public void update(String groupIdentifier, String auditWho) {
    String auditSession = UUID.randomUUID().toString();
    removedFileGroupIdentifiers.forEach(
        identifier -> fileGroupClient.deleteByIdentifier(identifier, auditWho, auditSession));
    removedFileGroupIdentifiers.clear();
    createFiles(groupIdentifier, auditSession);
  }


  void createFileGroup(FileDto file, String groupIdentifier, String auditSession) {
    FileGroupCreateRequestDto request = new FileGroupCreateRequestDto();
    request.setGroupIdentifier(groupIdentifier);
    String fileIdentifier = createFileOrGetIdentifier(file, auditSession);
    request.setFileIdentifier(fileIdentifier);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(auditSession);
    fileGroupClient.create(request);
  }

  String createFileOrGetIdentifier(FileDto file, String auditSession) {
    return fileClient.getIdentifierByBytesOrByCreate(file.getName(), file.getBytes(),
        userIdentifier, auditSession);
  }
}
