package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleClient;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleDto;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService.PayScaleCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService.PayScaleUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link PayScaleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PayScaleController extends AbstractController {

  @Inject
  PayScaleClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  PayScaleRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;


  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = PayScaleDto.NAME;

    listController.setEntityClass(PayScaleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(PayScaleService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            PayScaleDto.JSON_CIVIL_SERVICE_STATUS_AS_STRING,
            PayScaleDto.JSON_PAY_INDEX_COUNT_AS_STRING));

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome("payScaleReadIndexesPage");

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      PayScaleCreateRequestDto request = requestMapper.mapCreate((PayScaleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            PayScaleDto.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    civilServiceStatusSelectOneController.getSelectOneMenu().setRequired(true);
    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(civilServiceStatusIdentifierConsumer());

  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((PayScaleDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((PayScaleDto) entity).getName());
      civilServiceStatusSelectOneController.getSelectOneMenu()
          .writeValue(((PayScaleDto) entity).getCivilServiceStatusIdentifier());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(PayScaleDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(PayScaleDto.class)
        .setName(name);
  }

  Consumer<String> civilServiceStatusIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PayScaleDto.class)
        .setCivilServiceStatusIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      PayScaleUpdateRequestDto request = requestMapper.mapUpdate((PayScaleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
