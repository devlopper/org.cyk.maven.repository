package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


/**
 * Cette classe représente un client SSO (Single Sign-On).
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SsoApplicationDto extends AbstractIdentifiableCodableNamableDto {


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idApplicationReferencee";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "applicationReferenceeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "application référencée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "applications référencées";
}