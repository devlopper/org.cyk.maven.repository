package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de politique.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PolicyTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nombre de {@link PolicyDto} du type, en chaîne de caractères (TCH_IDT_750).
   */
  @JsonbProperty(JSON_POLICIES_COUNT_AS_STRING)
  private String policiesCountAsString;

  /**
   * Identifiant json pour {@link #policiesCountAsString}.
   */
  public static final String JSON_POLICIES_COUNT_AS_STRING = "nombrePolitiquesChaine";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypePolitique";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "typePolitiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de politique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de politique";
}
