package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Les droits de l'arbitrage : un par cas d'utilisation.
 *
 * <p><strong>Un droit est une action, pas une personne.</strong> Les profils — chargé de
 * contrôle, chef d'équipe, responsable d'arbitrage — sont décrits par {@link UserProfile}, qui
 * dit quels droits chacun porte. Le code ne teste jamais un profil : il demande « cet
 * utilisateur peut-il valider les transferts de solde ? », et la réponse vaut quel que soit le
 * profil par lequel il l'obtient.</p>
 *
 * <p>Cette séparation a une raison pratique. Un écran gardé par un profil devient faux le jour
 * où l'organisation change de nom ; un écran gardé par un droit reste juste, et c'est le
 * référentiel des profils qu'on met à jour, en un seul endroit.</p>
 *
 * <p>Les codes sont ceux que Keycloak porte, dans le realm SIIB. Ils sont en français, comme
 * tout ce qui sort du code.</p>
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // --- Rôle technique ---

  /**
   * Super administrateur. Passe partout, y compris sur le paramétrage.
   *
   * <p>Il ouvre l'énumération par commodité de lecture, et non par convention : <strong>aucun
   * code ne dépend de l'ordre de ces constantes</strong>. Les droits se lisent par leur
   * {@code code}, {@link #getByCode} ne regarde que lui, et rien n'est persisté en
   * {@code EnumType.ORDINAL} — cette énumération n'est pas persistée du tout.</p>
   */
  SUPER_ADMINISTRATOR("SUPER_ADMINISTRATEUR"),

  // --- Réception et contrôle d'admissibilité ---

  /**
   * Réceptionner le projet de masse salariale d'un EPN.
   */
  RECEIVE_DOSSIER("RECEPTIONNER_PROJET_MS"),

  /**
   * Déclarer un dossier admissible au traitement.
   *
   * <p>Ce droit <strong>n'est pas mort</strong> avec l'étape d'admission. Ce qui a disparu,
   * c'est la transition qu'il déclenchait ; le droit, lui, désigne toujours le chargé de
   * contrôle, et commande l'ouverture du menu de réception, l'écran de contrôle et la
   * vérification des pièces jointes.</p>
   */
  DECLARE_DOSSIER_ADMISSIBLE("DECLARER_DOSSIER_ADMISSIBLE"),

  // --- Traitement des demandes ---

  /**
   * Traiter un mouvement à venir : prime, retraite, glissement catégoriel, indemnité,
   * avancement.
   *
   * <p><strong>Les familles de traitement ont été redessinées le 12/10/2026.</strong> Elles
   * suivaient la <em>forme</em> de la ligne — mouvement projeté d'un côté, mesure ponctuelle de
   * l'autre — là où le métier les distingue par leur <em>objet</em> : ce qui va arriver, ce qui
   * rattrape le passé, ce qui se déplace d'un EPN à l'autre. Une prime et un avancement sont deux
   * formes différentes d'une même chose à instruire ; un rappel n'en est pas une.</p>
   */
  PROCESS_FORTHCOMING_MOVEMENT("TRAITER_MOUVEMENT_A_VENIR"),

  /**
   * Traiter une régularisation : rappel, régularisation.
   *
   * <p>Une famille nouvelle. Ces lignes rattrapent un exercice déjà clos et se jugent sur des
   * pièces différentes ; les instruire était jusqu'ici confondu avec les mesures ponctuelles.</p>
   */
  PROCESS_REGULARIZATION("TRAITER_REGULARISATION"),

  /**
   * Traiter un transfert de solde.
   */
  PROCESS_BALANCE_TRANSFER("TRAITER_TRANSFERT_SOLDE"),

  /**
   * Former les équipes d'arbitrage : les créer, les composer, leur confier des dossiers.
   *
   * <p>Le modèle d'équipe existait en base et dans les services depuis l'origine, mais aucun
   * écran ne le servait : les équipes se peuplaient à la main, par INSERT. Le droit manquait
   * avec l'écran.</p>
   */
  MANAGE_ARBITRATION_TEAM("GERER_EQUIPE_ARBITRAGE"),

  // --- Validation du traitement ---

  /**
   * Valider les données maintenues en l'état.
   */
  VALIDATE_MAINTAINED_DATA("VALIDER_DONNEES_MAINTENUES"),

  /**
   * Valider le traitement des mouvements projetés.
   */
  VALIDATE_PROJECTED_MOVEMENTS("VALIDER_MOUVEMENTS_PROJETES"),

  /**
   * Valider le traitement des mesures ponctuelles.
   */
  VALIDATE_PUNCTUAL_MEASURES("VALIDER_MESURES_PONCTUELLES"),

  /**
   * Valider le traitement des transferts de solde.
   */
  VALIDATE_BALANCE_TRANSFERS("VALIDER_TRANSFERTS_SOLDE"),

  /**
   * Transmettre le dossier au responsable d'arbitrage.
   */
  TRANSMIT_TO_ARBITRATION_MANAGER("TRANSMETTRE_AU_RESPONSABLE_ARBITRAGE"),

  /**
   * Prendre en compte les observations du responsable d'arbitrage.
   */
  TAKE_OBSERVATION_INTO_ACCOUNT("PRENDRE_EN_COMPTE_OBSERVATION"),

  // --- Validation du projet ---

  /**
   * Valider définitivement le projet de masse salariale.
   *
   * <p>La pré-validation qui figurait ici a été retirée : les écrans ne la portent plus. Le
   * cycle d'un dossier s'arrête à l'état consolidé, et le dernier geste rendu est la clôture,
   * qui remet le dossier au responsable d'arbitrage.</p>
   */
  VALIDATE_PAYROLL_PROJECT("VALIDER_PROJET_MASSE_SALARIALE"),

  // --- Consultation, reporting et tableaux de bord ---

  /**
   * Consulter les résultats des travaux.
   */
  CONSULT_PROCESSING_RESULTS("CONSULTER_RESULTATS_TRAVAUX"),

  /**
   * Consulter le tableau de bord budgétaire.
   */
  CONSULT_BUDGET_DASHBOARD("CONSULTER_TABLEAU_BORD_BUDGETAIRE"),

  /**
   * Éditer le dossier unique de synthèse.
   */
  EDIT_CONSOLIDATED_DOSSIER("EDITER_DOSSIER_UNIQUE_SYNTHESE"),

  /**
   * Éditer les résultats des travaux de traitement.
   */
  EDIT_PROCESSING_RESULTS("EDITER_RESULTATS_TRAVAUX_TRAITEMENT"),

  /**
   * Éditer le projet de masse salariale.
   */
  EDIT_PAYROLL_PROJECT("EDITER_PROJET_MASSE_SALARIALE"),

  // --- Côté établissement ---

  /**
   * Consulter le dossier de son propre établissement.
   *
   * <p>Ce droit et le suivant ne figurent pas aux diagrammes de cas d'utilisation, qui décrivent
   * le travail de la DCB. Ils sont déduits des écrans que le module sert déjà à l'EPN.</p>
   */
  CONSULT_OWN_DOSSIER("CONSULTER_MON_EPN"),

  /**
   * Corriger un dossier retourné et le retransmettre.
   */
  CORRECT_AND_RETRANSMIT("CORRIGER_ET_RETRANSMETTRE");

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Le droit que porte un code, ou {@code null} s'il n'en désigne aucun.
   *
   * <p>Un code inconnu rend {@code null} plutôt que de lever : il vient du référentiel, où un
   * paramétrage périmé peut survivre à un droit renommé. Faire tomber l'écran sur cette
   * donnée-là en ferait un incident là où c'est une correction de paramétrage.</p>
   *
   * @param code code recherché
   * @return le droit, ou {@code null}
   */
  public static UserRole getByCode(String code) {
    if (code == null) {
      return null;
    }
    for (UserRole role : values()) {
      if (role.getCode().equals(code)) {
        return role;
      }
    }
    return null;
  }

  /**
   * Code.
   */
  String code;
}
