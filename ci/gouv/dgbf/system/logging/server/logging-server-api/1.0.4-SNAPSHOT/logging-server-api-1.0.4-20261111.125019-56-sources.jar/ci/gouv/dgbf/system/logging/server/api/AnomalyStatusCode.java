package ci.gouv.dgbf.system.logging.server.api;

/**
 * Codes stables des statuts du cycle de vie d'une anomalie.
 */
public interface AnomalyStatusCode {

  /**
   * Créée / Non traitée.
   */
  String CREATED = "CREE";

  /**
   * Traitée par l'administrateur.
   */
  String TREATED = "TRAITE";
}

