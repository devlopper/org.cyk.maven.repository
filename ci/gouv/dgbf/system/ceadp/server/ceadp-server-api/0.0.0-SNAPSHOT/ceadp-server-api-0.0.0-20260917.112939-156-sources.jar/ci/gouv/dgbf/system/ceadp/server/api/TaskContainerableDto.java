package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link TaskDto}.
 *
 * @author Christian
 *
 */
public interface TaskContainerableDto extends TaskContainerable {

  /**
   * Identifiant json {@link TaskContainerableDto#getCreatedTaskCountAsString()}.
   */
  String JSON_CREATED_TASK_COUNT_AS_STRING = "nombreTacheCreeeChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getSuspendedTaskCountAsString()}.
   */
  String JSON_SUSPENDED_TASK_COUNT_AS_STRING = "nombreTacheSuspendueChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getStartedTaskCount()}.
   */
  String JSON_STARTED_TASK_COUNT = "nombreTacheDemarree";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getStartedTaskCountAsString()}.
   */
  String JSON_STARTED_TASK_COUNT_AS_STRING = "nombreTacheDemarreeChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getStoppedTaskCountAsString()}.
   */
  String JSON_STOPPED_TASK_COUNT_AS_STRING = "nombreTacheArreteeChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getRealizedTaskCount()}.
   */
  String JSON_REALIZED_TASK_COUNT = "nombreTacheRealisee";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getRealizedTaskCountAsString()}.
   */
  String JSON_REALIZED_TASK_COUNT_AS_STRING = "nombreTacheRealiseeChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getLateTaskCount()}.
   */
  String JSON_LATE_TASK_COUNT = "nombreTacheEnRetard";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getLateTaskCountAsString()}.
   */
  String JSON_LATE_TASK_COUNT_AS_STRING = "nombreTacheEnRetardChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getNotLateTaskCountAsString()}.
   */
  String JSON_NOT_LATE_TASK_COUNT_AS_STRING = "nombreTacheNonEnRetardChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getTaskEarliestFromDateAsString()}.
   */
  String JSON_TASK_EARLIEST_FROM_DATE_AS_STRING = "dateDebutAuPlusTotChaine";

  /**
   * Identifiant json {@link TaskContainerableDto#getTaskLatestToDateAsString()}.
   */
  String JSON_TASK_LATEST_TO_DATE_AS_STRING = "dateFinAuPlusTardChaine";

  /**
   * Identifiant json {@link TaskContainerableDto#getTaskCount()}.
   */
  String JSON_TASK_COUNT = "nombreTache";

  /**
   * Identifiant json {@link TaskContainerableDto#getTaskCountAsString()}.
   */
  String JSON_TASK_COUNT_AS_STRING = "nombreTacheChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getDoneTaskCount()}.
   */
  String JSON_DONE_TASK_COUNT = "nombreTacheEffeftuee";

  /**
   * Identifiant json {@link TaskContainerableDto#getDoneTaskCountAsString()}.
   */
  String JSON_DONE_TASK_COUNT_AS_STRING = "nombreTacheEffeftueeChaine";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getNotDoneTaskCountAsString()}.
   */
  String JSON_NOT_DONE_TASK_COUNT_AS_STRING = "nombreTacheNonEffeftueeChaine";

  /**
   * Identifiant json {@link TaskContainerableDto#getPendingStartTaskCount()}.
   */
  String JSON_PENDING_START_TASK_COUNT = "nombreTacheEnAttenteDemarrage";
  
  /**
   * Identifiant json {@link TaskContainerableDto#getPendingStartTaskCountAsString()}.
   */
  String JSON_PENDING_START_TASK_COUNT_AS_STRING = "nombreTacheEnAttenteDemarrageChaine";
}
