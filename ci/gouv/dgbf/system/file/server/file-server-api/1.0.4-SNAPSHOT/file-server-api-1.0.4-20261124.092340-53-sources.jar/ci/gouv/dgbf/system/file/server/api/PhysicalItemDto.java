package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente l'Exemplaire physique d'un {@link FileDto} : la détention et la
 * logistique du papier. Son identifiant est celui du Fichier (RG_FILE_FIC_19). Il est lu à part,
 * pour ne pas alourdir les listes de Fichiers. Le contenant, le volume et l'état du papier sont des
 * Propriétés du Fichier depuis DEC_FILE_02 (D09).
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PhysicalItemDto extends AbstractIdentifiableDto {

  /**
   * Détenteur : qui détient le papier, texte libre, obligatoire.
   */
  @JsonbProperty(value = JSON_HOLDER)
  private String holder;

  /**
   * Localisation dans le service d'archives ; vide tant qu'aucune Archive n'est applicable, et
   * masquée au niveau de visibilité {@code SUMMARY} (RG_FILE_FIC_14).
   */
  @JsonbProperty(value = JSON_LOCATION)
  private String location;

  /**
   * Contenant de l'Exemplaire physique ; retiré à la reprise dans datastructures
   * (DEC_FILE_02 D16, TCH_FILE_644).
   */
  @Deprecated
  @JsonbProperty(value = JSON_CONTAINER)
  private String container;

  /**
   * Importance matérielle de l'Exemplaire physique ; retirée à la reprise dans datastructures
   * (DEC_FILE_02 D16, TCH_FILE_644).
   */
  @Deprecated
  @JsonbProperty(value = JSON_PHYSICAL_EXTENT)
  private String physicalExtent;

  /**
   * État matériel de l'Exemplaire physique ; retiré à la reprise dans datastructures
   * (DEC_FILE_02 D16, TCH_FILE_644).
   */
  @Deprecated
  @JsonbProperty(value = JSON_PHYSICAL_CONDITION)
  private String physicalCondition;

  /**
   * Identifiant JSON {@link #holder}.
   */
  public static final String JSON_HOLDER = "detenteur";

  /**
   * Identifiant JSON {@link #container}, retiré avec le champ (TCH_FILE_644).
   */
  @Deprecated
  public static final String JSON_CONTAINER = "contenant";

  /**
   * Identifiant JSON {@link #physicalExtent}, retiré avec le champ (TCH_FILE_644).
   */
  @Deprecated
  public static final String JSON_PHYSICAL_EXTENT = "importanceMaterielle";

  /**
   * Identifiant JSON {@link #physicalCondition}, retiré avec le champ (TCH_FILE_644).
   */
  @Deprecated
  public static final String JSON_PHYSICAL_CONDITION = "etatMateriel";

  /**
   * Identifiant JSON {@link #location}.
   */
  public static final String JSON_LOCATION = "localisation";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exemplaire physique";
}
