package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIsCessibleAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsCessibleDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEarningAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEarningDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEvaluableInSecondaryContextAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEvaluableInSecondaryContextDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasEmployeeCalculationFormulaTextDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un poste de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollComponentDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasIsEarningDto, HasIsEarningAsStringDto, HasEmployeeCalculationFormulaTextDto,
    HasIsCessibleDto, HasIsCessibleAsStringDto, HasIsEvaluableInSecondaryContextDto,
    HasIsEvaluableInSecondaryContextAsStringDto {

  @JsonbProperty(JSON_IS_EARNING)
  private Boolean isEarning;

  @JsonbProperty(JSON_IS_EARNING_AS_STRING)
  private String isEarningAsString;

  @JsonbProperty(JSON_IS_CESSIBLE)
  private Boolean isCessible;

  @JsonbProperty(JSON_IS_CESSIBLE_AS_STRING)
  private String isCessibleAsString;
  
  @JsonbProperty(JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT)
  private Boolean isEvaluableInSecondaryContext;

  @JsonbProperty(JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT_AS_STRING)
  private String isEvaluableInSecondaryContextAsString;

  /**
   * Est taxable.
   */
  @JsonbProperty(JSON_IS_TAXABLE)
  private Boolean isTaxable;

  /**
   * Représentation en chaine de caractères de {@link #isTaxable}.
   */
  @JsonbProperty(JSON_IS_TAXABLE_AS_STRING)
  private String isTaxableAsString;

  /**
   * Est pensionnable.
   */
  @JsonbProperty(JSON_IS_PENSIONABLE)
  private Boolean isPensionable;

  /**
   * Représentation en chaine de caractères de {@link #isPensionable}.
   */
  @JsonbProperty(JSON_IS_PENSIONABLE_AS_STRING)
  private String isPensionableAsString;

  /**
   * Est cumulable au net.
   */
  @JsonbProperty(JSON_IS_NET_CUMULABLE)
  private Boolean isNetCumulable;

  /**
   * Représentation en chaine de caractères de {@link #isNetCumulable}.
   */
  @JsonbProperty(JSON_IS_NET_CUMULABLE_AS_STRING)
  private String isNetCumulableAsString;

  /**
   * Identifiant {@link Script} employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER)
  private String employeeCalculationFormulaIdentifier;

  @JsonbProperty(JSON_EMPLOYEE_CALCULATION_FORMULA_TEXT)
  private String employeeCalculationFormulaText;

  /**
   * Représentation en chaine de caractères de {@link Script} employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_CALCULATION_FORMULA_AS_STRING)
  private String employeeCalculationFormulaAsString;

  /**
   * Identifiant {@link Script} employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER)
  private String employerCalculationFormulaIdentifier;

  /**
   * Représentation en chaine de caractères de {@link Script} employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_CALCULATION_FORMULA_AS_STRING)
  private String employerCalculationFormulaAsString;

  /**
   * Identifiant {@link PayrollComponentCategory}.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #categoryIdentifier}.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  /**
   * Identifiant {@link PayrollComponentNature}.
   */
  @JsonbProperty(JSON_NATURE_IDENTIFIER)
  private String natureIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #natureIdentifier}.
   */
  @JsonbProperty(JSON_NATURE_AS_STRING)
  private String natureAsString;

  /**
   * Identifiant {@link EconomicNature}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #economicNatureIdentifier}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPostePaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "postePaieChaine";

  /**
   * Identifiant json {@link #isEarning}.
   */
  public static final String JSON_IS_EARNING = "estGain";

  /**
   * Identifiant json {@link #isEarningAsString}.
   */
  public static final String JSON_IS_EARNING_AS_STRING = JSON_IS_EARNING + "Chaine";

  /**
   * Identifiant json {@link #isTaxable}.
   */
  public static final String JSON_IS_TAXABLE = "estTaxable";

  /**
   * Identifiant json {@link #isTaxableAsString}.
   */
  public static final String JSON_IS_TAXABLE_AS_STRING = JSON_IS_TAXABLE + "Chaine";

  /**
   * Identifiant json {@link #isPensionable}.
   */
  public static final String JSON_IS_PENSIONABLE = "estPensionnable";

  /**
   * Identifiant json {@link #isPensionableAsString}.
   */
  public static final String JSON_IS_PENSIONABLE_AS_STRING = JSON_IS_PENSIONABLE + "Chaine";

  /**
   * Identifiant json {@link #isNetCumulable}.
   */
  public static final String JSON_IS_NET_CUMULABLE = "estCumulableNet";

  /**
   * Identifiant json {@link #isNetCumulableAsString}.
   */
  public static final String JSON_IS_NET_CUMULABLE_AS_STRING = JSON_IS_NET_CUMULABLE + "Chaine";

  /**
   * Identifiant json {@link #employeeCalculationFormulaIdentifier}.
   */
  public static final String JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER =
      "idFormuleCalculEmploye";

  /**
   * Identifiant json {@link #employeeCalculationFormulaAsString}.
   */
  public static final String JSON_EMPLOYEE_CALCULATION_FORMULA_AS_STRING =
      "formuleCalculEmployeChaine";

  /**
   * Identifiant json {@link #employerCalculationFormulaIdentifier}.
   */
  public static final String JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER =
      "idFormuleCalculEmployeur";

  /**
   * Identifiant json {@link #employerCalculationFormulaAsString}.
   */
  public static final String JSON_EMPLOYER_CALCULATION_FORMULA_AS_STRING =
      "formuleCalculEmployeurChaine";

  /**
   * Identifiant json {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = "idCategoriePostePaie";

  /**
   * Identifiant json {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = "categoriePosteChaine";

  /**
   * Identifiant json {@link #natureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER = "idNaturePostePaie";

  /**
   * Identifiant json {@link #natureAsString}.
   */
  public static final String JSON_NATURE_AS_STRING = "naturePostePaieChaine";

  /**
   * Identifiant json {@link #economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureEconomique";

  /**
   * Identifiant json {@link #economicNatureAsString}.
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING = "natureEconomiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de paie";
}
