package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptEvaluationDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptEvaluationDto}.

    @author Christian
               """)
public interface ScriptEvaluationRequestMapper extends RequestMapper<ScriptEvaluationDto,
    ScriptEvaluationCreateRequestDto, ScriptEvaluationUpdateRequestDto> {

}
