package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.ConfidentialityLevel;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityRequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/** Controleur CRUD de la confidentialite par type. */
@Dependent
public class ResourceTypeConfidentialityController extends AbstractController {
  @Inject ResourceTypeConfidentialityClient client;
  @Inject @Getter ListController listController;
  @Inject @Getter ResourceTypeConfidentialityFilterController filterController;
  @Inject @Getter ResourceTypeSelectOneController resourceTypeSelectOneController;
  @Inject @Getter ConfidentialityLevelSelectOneController confidentialityLevelSelectOneController;
  @Inject ResourceTypeConfidentialityRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ResourceTypeConfidentialityDto.NAME;
  }

  /** Initialise le CRUD et la previsualisation d'impact. */
  public void initialize() {
    listController.setEntityClass(ResourceTypeConfidentialityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ResourceTypeConfidentialityService.PATH);
    listController.setFilterController(filterController);
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ResourceTypeConfidentialityDto.JSON_RESOURCE_TYPE,
        ResourceTypeConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL,
        ResourceTypeConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();
    listController.getCreateController().setFunction(entity -> {
      ResourceTypeConfidentialityCreateRequestDto request =
          requestMapper.mapCreate((ResourceTypeConfidentialityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
    listController.getUpdateController().setProjection(projection);
    listController.getUpdateController().setFunction(entity -> {
      ResourceTypeConfidentialityUpdateRequestDto request =
          requestMapper.mapUpdate((ResourceTypeConfidentialityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
    resourceTypeSelectOneController.getSelectOneMenu().addValueConsumer(name ->
        listController.getCreateControllerOrUpdateControllerEntityAs(
            ResourceTypeConfidentialityDto.class).setResourceType(
                name == null ? null : Core.getEnumerationValueByName(ResourceType.class, name)));
    confidentialityLevelSelectOneController.getSelectOneMenu().addValueConsumer(name ->
        listController.getCreateControllerOrUpdateControllerEntityAs(
            ResourceTypeConfidentialityDto.class).setConfidentialityLevel(
                name == null ? null : Core.getEnumerationValueByName(ConfidentialityLevel.class,
                    name)));
  }
}
