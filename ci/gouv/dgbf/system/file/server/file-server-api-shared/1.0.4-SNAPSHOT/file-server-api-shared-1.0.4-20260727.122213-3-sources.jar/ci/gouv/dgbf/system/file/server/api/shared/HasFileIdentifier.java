package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de fichier.
 *
 * @author Christian
 */
public interface HasFileIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du fichier.
   *
   * @return identifiant du fichier
   */
  String getFileIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du fichier.
   *
   * @param identifier identifiant du fichier
   */
  void setFileIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant du fichier.
   */
  String FIELD_FILE_IDENTIFIER = "fileIdentifier";
}
