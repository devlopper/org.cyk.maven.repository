package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SalaryElementService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SalaryElementClient extends AbstractClient<SalaryElementService>
    implements GetByIdentifier<SalaryElementDto>, GetMany<SalaryElementGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SalaryElementClient service(SalaryElementService service) {
    return (SalaryElementClient) super.service(service);
  }

  /**
   * {@link SalaryElementService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SalaryElementCreateRequestDto request) {
    return new CreateExecutor(SalaryElementService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SalaryElementService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SalaryElementGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SalaryElementGetManyResponseDto>(
        SalaryElementGetManyResponseDto.class,
        SalaryElementService.GET_MANY_IDENTIFIER
    ).execute(() -> service().getMany(request));
  }


  /**
   * {@link SalaryElementService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public SalaryElementGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SalaryElementService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SalaryElementDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SalaryElementDto>(SalaryElementDto.class,
        SalaryElementService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SalaryElementService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SalaryElementDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SalaryElementService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SalaryElementDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SalaryElementDto>(SalaryElementDto.class,
        SalaryElementService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SalaryElementService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SalaryElementDto getByIdentifier(String identifier,
                       ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SalaryElementService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SalaryElementUpdateRequestDto request) {
    return new IdentifiableExecutor(SalaryElementService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SalaryElementService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SalaryElementService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SalaryElementService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
