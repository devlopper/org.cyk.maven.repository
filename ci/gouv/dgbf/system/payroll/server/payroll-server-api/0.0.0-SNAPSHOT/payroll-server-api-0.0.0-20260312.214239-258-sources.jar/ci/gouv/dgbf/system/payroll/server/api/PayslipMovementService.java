package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEffectiveDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusReasonDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasActualMovementIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPreviousMovementIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayslipMovementDto}.
 *
 * @author stephane
 *
 */
@Path(value = PayslipMovementService.PATH)
@Tag(name = "Gestion des mouvements de bulletin de paie")
public interface PayslipMovementService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "mouvements-bulletin";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author stephane
   *
   */
  interface PayslipMovementSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipDto}.
     *
     * @return l'identifiant de {@link PayslipDto}
     */
    String getPayslipIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipDto}.
     *
     * @param payslipIdentifier l'identifiant de {@link PayslipDto}
     */
    void setPayslipIdentifier(String payslipIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du mouvement actuel.
     *
     * @return l'identifiant du mouvement actuel
     */
    String getActualMovementIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du mouvement actuel.
     *
     * @param actualMovementIdentifier l'identifiant ddu mouvement actuel
     */
    void setActualMovementIdentifier(String actualMovementIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du mouvement précédent.
     *
     * @return l'identifiant du mouvement précédent
     */
    String getPreviousMovementIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du mouvement précédent.
     *
     * @param previousMovementIdentifier l'identifiant du mouvement précédent
     */
    void setPreviousMovementIdentifier(String previousMovementIdentifier);

    /**
     * Cette méthode permet d'obtenir la date d'effet.
     *
     * @return la date d'effet
     */
    LocalDate getEffectiveDate();

    /**
     * Cette méthode permet d'assigner la date d'effet.
     *
     * @param effectiveDate la date d'effet
     */
    void setEffectiveDate(LocalDate effectiveDate);

    /**
     * {@link PayslipDto#JSON_THIS_IDENTIFIER}.
     */
    String JSON_PAYSPLIP_IDENTIFIER = PayslipDto.JSON_THIS_IDENTIFIER;

    /**
     * {@link MovementDto#JSON_THIS_IDENTIFIER}.
     */
    String JSON_ACTUAL_MOVEMENT_IDENTIFIER =
        HasActualMovementIdentifierDto.JSON_ACTUAL_MOVEMENT_IDENTIFIER;

    /**
     * {@link MovementDto#JSON_THIS_IDENTIFIER}.
     */
    String JSON_PREVIOUS_MOVEMENT_IDENTIFIER =
        HasPreviousMovementIdentifierDto.JSON_PREVIOUS_MOVEMENT_IDENTIFIER;

    /**
     * {@link HasEffectiveDateDto#JSON_EFFECTIVE_DATE}.
     */
    String JSON_EFFECTIVE_DATE = HasEffectiveDateDto.JSON_EFFECTIVE_DATE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayslipMovementCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author stephane
   *
   */
  @Getter
  @Setter
  class PayslipMovementCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayslipMovementSaveRequestDto {

    @JsonbProperty(JSON_PAYSPLIP_IDENTIFIER)
    private String payslipIdentifier;

    @JsonbProperty(JSON_ACTUAL_MOVEMENT_IDENTIFIER)
    private String actualMovementIdentifier;

    @JsonbProperty(JSON_PREVIOUS_MOVEMENT_IDENTIFIER)
    private String previousMovementIdentifier;

    @JsonbProperty(JSON_EFFECTIVE_DATE)
    private LocalDate effectiveDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author stephane
   *
   */
  @Getter
  @Setter
  public static class PayslipMovementGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayslipMovementDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayslipMovementDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipMovementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipMovementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayslipMovementUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author stephane
   *
   */
  @Getter
  @Setter
  class PayslipMovementUpdateRequestDto extends ByIdentifierRequestDto
      implements PayslipMovementSaveRequestDto {

    @JsonbProperty(JSON_PAYSPLIP_IDENTIFIER)
    private String payslipIdentifier;

    @JsonbProperty(JSON_ACTUAL_MOVEMENT_IDENTIFIER)
    private String actualMovementIdentifier;

    @JsonbProperty(JSON_PREVIOUS_MOVEMENT_IDENTIFIER)
    private String previousMovementIdentifier;

    @JsonbProperty(JSON_EFFECTIVE_DATE)
    private LocalDate effectiveDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayslipMovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette classe représente la requête de flux de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipMovementProcessRequestDto extends ByIdentifierRequestDto
      implements HasStatusReasonDto {

    @JsonbProperty(JSON_STATUS_REASON)
    private String statusReason;
  }

  /**
   * Cette classe représente la réponse de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipMovementProcessResponseDto extends IdentifiableResponseDto {

    /**
     * {@link PayslipMovementDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private PayslipMovementStatus status;

    /**
     * {@link PayslipMovementDto#getActivatable()}.
     */
    @JsonbProperty(JSON_ACTIVATABLE)
    private Boolean activatable;

    /**
     * {@link PayslipMovementDto#getDeferrableProposal()}.
     */
    @JsonbProperty(JSON_DEFERRABLE_PROPOSAL)
    private Boolean deferrableProposal;

    /**
     * {@link PayslipMovementDto#getDeferrable()}.
     */
    @JsonbProperty(JSON_DEFERRABLE)
    private Boolean deferrable;

    /**
     * {@link PayslipMovementDto#getRejectableProposal()}.
     */
    @JsonbProperty(JSON_REJECTABLE_PROPOSAL)
    private Boolean rejectableProposal;

    /**
     * {@link PayslipMovementDto#getRejectable()}.
     */
    @JsonbProperty(JSON_REJECTABLE)
    private Boolean rejectable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link PayrollStatus}
     */
    public void initialize(PayslipMovementStatus status) {
      this.status = status;
      activatable = PayslipMovementStatus.ACTIVATED.getPrevious().contains(status);
      deferrableProposal = PayslipMovementStatus.DEFERRED_PROPOSED.getPrevious().contains(status);
      deferrable = PayslipMovementStatus.DEFERRED.getPrevious().contains(status);
      rejectableProposal = PayslipMovementStatus.REJECTION_PROPOSED.getPrevious().contains(status);
      rejectable = PayslipMovementStatus.REJECTED.getPrevious().contains(status);
    }

    /**
     * {@link PayslipMovementDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = PayslipMovementDto.JSON_STATUS;

    /**
     * {@link PayslipMovementDto#JSON_ACTIVATABLE}.
     */
    public static final String JSON_ACTIVATABLE = PayslipMovementDto.JSON_ACTIVATABLE;

    /**
     * {@link PayslipMovementDto#JSON_DEFERRABLE_PROPOSAL}.
     */
    public static final String JSON_DEFERRABLE_PROPOSAL =
        PayslipMovementDto.JSON_DEFERRABLE_PROPOSAL;

    /**
     * {@link PayslipMovementDto#JSON_DEFERRABLE}.
     */
    public static final String JSON_DEFERRABLE = PayslipMovementDto.JSON_DEFERRABLE;

    /**
     * {@link PayslipMovementDto#JSON_REJECTABLE_PROPOSAL}.
     */
    public static final String JSON_REJECTABLE_PROPOSAL =
        PayslipMovementDto.JSON_REJECTABLE_PROPOSAL;

    /**
     * {@link PayslipMovementDto#JSON_REJECTABLE}.
     */
    public static final String JSON_REJECTABLE = PayslipMovementDto.JSON_REJECTABLE;
  }

  /**
   * Identifiant du service d'activiation.
   */
  String ACTIVATE_IDENTIFIER = "ACTIVATION_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service d'activiation.
   */
  String ACTIVATE_PATH = "activation";

  /**
   * Cette méthode permet d'activer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACTIVATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = ACTIVATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementProcessResponseDto.class))})
  Response activate(PayslipMovementProcessRequestDto request);

  /**
   * Identifiant du service de différé.
   */
  String DEFER_IDENTIFIER = "DIFFERE_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de différé.
   */
  String DEFER_PATH = "differe";

  /**
   * Cette méthode permet de différer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DEFER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DEFER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementProcessResponseDto.class))})
  Response defer(PayslipMovementProcessRequestDto request);

  /**
   * Identifiant du service de rejet.
   */
  String REJECT_IDENTIFIER = "REJET_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de rejet.
   */
  String REJECT_PATH = "rejet";

  /**
   * Cette méthode permet de rejeter.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REJECT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = REJECT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementProcessResponseDto.class))})
  Response reject(PayslipMovementProcessRequestDto request);

  /**
   * Identifiant du service de proposition de différé.
   */
  String PROPOSE_DEFERRAL_IDENTIFIER = "PROPOSITION_DIFFERE_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de proposition de différé.
   */
  String PROPOSE_DEFERRAL_PATH = "proposition-differe";

  /**
   * Cette méthode permet de proposer un différé.
   *
   * @param request requête
   * @return réponse
   */
  @Path(PROPOSE_DEFERRAL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = PROPOSE_DEFERRAL_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementProcessResponseDto.class))})
  Response proposeDeferral(PayslipMovementProcessRequestDto request);

  /**
   * Identifiant du service de proposition de rejet.
   */
  String PROPOSE_REJECTION_IDENTIFIER = "PROPOSITION_REJET_MOUVEMENT_BULLETIN";

  /**
   * Chemin du service de proposition de rejet.
   */
  String PROPOSE_REJECTION_PATH = "proposition-rejet";

  /**
   * Cette méthode permet de proposer un rejet.
   *
   * @param request requête
   * @return réponse
   */
  @Path(PROPOSE_REJECTION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = PROPOSE_REJECTION_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipMovementProcessResponseDto.class))})
  Response proposeRejection(PayslipMovementProcessRequestDto request);

  /**
   * Identifiant du service de mise à jour du mouvement actuel.
   */
  String UPDATE_ACTUAL_MOVEMENT_IDENTIFIER = "MISE_A_JOUR_MOUVEMENT_ACTUEL";

  /**
   * Chemin du service de mise à jour du mouvement actuel.
   */
  String UPDATE_ACTUAL_MOVEMENT_PATH = "mise-a-jour-mouvement-actuel";

  /**
   * Cette méthode permet de mettre à jour le mouvement actuel.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_ACTUAL_MOVEMENT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_ACTUAL_MOVEMENT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateActualMovement(PayslipMovementUpdateRequestDto request);
}
