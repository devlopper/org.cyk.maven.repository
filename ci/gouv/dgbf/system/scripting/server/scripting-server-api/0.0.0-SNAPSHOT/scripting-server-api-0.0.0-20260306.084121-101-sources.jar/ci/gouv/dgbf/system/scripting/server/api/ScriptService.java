package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.BooleanCore;
import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.core.NumberCore;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIntValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasOrderNumberDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueAsBooleanDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueAsIntegerDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.EvaluateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractIdentifiablesResponseDto.OrderedIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.EvaluateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest;
import ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse;
import ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest;
import ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse;
import com.google.protobuf.Struct;
import com.google.protobuf.Value;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ScriptDto}.
 *
 * @author Christian
 *
 */
@Path(value = ScriptService.PATH)
@Tag(name = "Gestion des scripts")
public interface ScriptService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "scripts";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ScriptSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
     *
     * @return identifiant de {@link DomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
     *
     * @param domainIdentifier identifiant de {@link DomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ScriptEvaluationDto}.
     *
     * @return identifiant de {@link ScriptEvaluationDto}
     */
    String getEvaluatorIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ScriptEvaluationDto}.
     *
     * @param evaluatorIdentifier identifiant de {@link ScriptEvaluationDto}
     */
    void setEvaluatorIdentifier(String evaluatorIdentifier);

    /**
     * Cette méthode permet d'obtenir le texte.
     *
     * @return texte
     */
    String getText();

    /**
     * Cette méthode permet d'assigner le texte.
     *
     * @param text texte
     */
    void setText(String text);

    /**
     * Cette méthode permet d'obtenir le type de résultat.
     *
     * @return type de résultat
     */
    ValueType getResultType();

    /**
     * Cette méthode permet d'assigner le type de résultat.
     *
     * @param resultType type de résultat
     */
    void setResultType(ValueType resultType);

    /**
     * Identifiant json identifiant de {@link DomainDto}.
     */
    String JSON_DOMAIN_IDENTIFIER = ScriptDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link ScriptEvaluationDto}.
     */
    String JSON_EVALUATOR_IDENTIFIER = ScriptDto.JSON_EVALUATOR_IDENTIFIER;

    /**
     * Identifiant json du texte.
     */
    String JSON_TEXT = ScriptDto.JSON_TEXT;

    /**
     * Identifiant json de {@link ValueType}.
     */
    String JSON_RESULT_TYPE = ScriptDto.JSON_RESULT_TYPE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SCRIPT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ScriptCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ScriptSaveRequestDto {
    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_EVALUATOR_IDENTIFIER)
    private String evaluatorIdentifier;

    @JsonbProperty(JSON_TEXT)
    private String text;

    @JsonbProperty(JSON_RESULT_TYPE)
    private ValueType resultType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SCRIPT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ScriptGetManyResponseDto extends AbstractGetByPageResponseDto<ScriptDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ScriptDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SCRIPT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SCRIPT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ScriptUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ScriptSaveRequestDto {
    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_EVALUATOR_IDENTIFIER)
    private String evaluatorIdentifier;

    @JsonbProperty(JSON_TEXT)
    private String text;

    @JsonbProperty(JSON_RESULT_TYPE)
    private ValueType resultType;
  }

  /**
   * Identifiant du service de mise à jour du texte.
   */
  String UPDATE_TEXT_IDENTIFIER = "MISE_A_JOUR_TEXTE_SCRIPT";

  /**
   * Chemin du service de mise à jour du texte.
   */
  String UPDATE_TEXT_PATH = "texte";

  /**
   * Cette méthode permet de mettre à jour le texte de {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_TEXT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_TEXT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateText(ScriptUpdateTextRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de texte.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptUpdateTextRequestDto extends ByIdentifierRequestDto {
    @JsonbProperty(ScriptSaveRequestDto.JSON_TEXT)
    private String text;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SCRIPT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'évaluation.
   */
  String EVALUATE_IDENTIFIER = "EVALUATION_SCRIPT";

  /**
   * Chemin du service d'évaluation.
   */
  String EVALUATE_PATH = "evaluation";

  /**
   * Cette méthode permet d'évaluer {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptEvaluateResponseDto.class))})
  Response evaluate(ScriptEvaluateRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluateRequestDto extends EvaluateRequestDto {

  }

  /**
   * Cette classe représente la réponse d'évaluation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluateResponseDto extends EvaluateResponseDto {

  }

  /**
   * Cette classe représente la base de requête d'évaluation de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  abstract class AbstractScriptEvaluateManyRequestDto extends AbstractAuditedRequestJsonDto {
    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty(JSON_GROUPS)
    Collection<GroupDto> groups;

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param orderNumber numéro d'ordre
     * @param scriptIdentifiers identifiants {@link ScriptDto}
     * @param arguments arguments
     */
    public void addGroup(int orderNumber, Collection<String> scriptIdentifiers,
        Map<String, Object> arguments) {
      GroupDto group = group();
      group.orderNumber = orderNumber;
      group.addScriptIdentifiers(scriptIdentifiers);
      group.arguments = arguments;
    }

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param scriptIdentifiers identifiants {@link ScriptDto}
     * @param arguments arguments
     */
    public void addGroup(Collection<String> scriptIdentifiers, Map<String, Object> arguments) {
      addGroup(Optional.ofNullable(groups).orElse(Collections.emptyList()).size(),
          scriptIdentifiers, arguments);
    }

    /**
     * Cette méthode permet d'obtenir une collection de groupe non nulle.
     *
     * @return collection de groupe non nulle
     */
    public Collection<GroupDto> groups() {
      if (groups == null) {
        groups = new ArrayList<>();
      }
      return groups;
    }

    /**
     * Cette méthode permet d'obtenir {@link GroupDto}.
     *
     * @return {@link GroupDto}
     */
    public GroupDto group() {
      GroupDto group = new GroupDto();
      groups().add(group);
      return group;
    }

    /**
     * Identifiant json {@link #groups}.
     */
    public static final String JSON_GROUPS = "groupes";

    /**
     * Cette classe représente un groupe.
     *
     * @author Christian
     */
    @Getter
    @Setter
    public static class GroupDto implements HasOrderNumberDto {

      @JsonbProperty(JSON_ORDER_NUMBER)
      private Integer orderNumber;

      /**
       * Carte d'identifiants {@link ScriptDto} et index.
       */
      @JsonbProperty(JSON_SCRIPT_IDENTIFIERS)
      private Map<String, Integer> scriptIdentifiers;

      /**
       * Arguments.
       */
      @JsonbProperty(JSON_ARGUMENTS)
      private Map<String, Object> arguments;

      /**
       * Cette méthode permet d'ajouter des identifiants de {@link ScriptDto}.
       *
       * @param identifiers identifiants de {@link ScriptDto}
       */
      public void addScriptIdentifiers(Collection<String> identifiers) {
        Optional.ofNullable(identifiers).orElse(Collections.emptyList()).forEach(identifier -> {
          scriptIdentifiers().put(identifier, scriptIdentifiers.size());
        });
      }

      /**
       * Cette méthode permet d'obtenir une carte non nulle.
       *
       * @return carte non nulle
       */
      public Map<String, Integer> scriptIdentifiers() {
        if (scriptIdentifiers == null) {
          scriptIdentifiers = new HashMap<>();
        }
        return scriptIdentifiers;
      }

      /**
       * Identifiant json {@link #scriptIdentifiers}.
       */
      public static final String JSON_SCRIPT_IDENTIFIERS = ScriptDto.JSON_THIS_IDENTIFIER;

      /**
       * Identifiant json {@link #arguments}.
       */
      public static final String JSON_ARGUMENTS = ScriptEvaluationDto.JSON_ARGUMENTS;
    }

    static Map<String, Object> convertStructToMap(Struct struct) {
      Map<String, Object> map = new HashMap<>();
      struct.getFieldsMap().forEach((key, value) -> {
        map.put(key, convertValue(value));
      });
      return map;
    }

    static Object convertValue(Value value) {
      switch (value.getKindCase()) {
        case NUMBER_VALUE:
          double d = value.getNumberValue();
          // ✅ Version la plus rapide pour la conversion
          if (d == Math.floor(d)) {
            return (long) d; // Autoboxing implicite, géré par le JIT
          }
          return d;

        case STRING_VALUE:
          return value.getStringValue();

        case BOOL_VALUE:
          return value.getBoolValue();

        case STRUCT_VALUE:
          return convertStructToMap(value.getStructValue());

        case NULL_VALUE:
        default:
          return null;
      }
    }

    /**
     * Cette méthode permet de convertir un dictionnaire en {@link Struct}.
     *
     * @param map dictionnaire
     * @return {@link Struct}
     */
    public static Struct convertMapToStruct(Map<String, Object> map) {
      Struct.Builder structBuilder = com.google.protobuf.Struct.newBuilder();

      for (Map.Entry<String, Object> entry : map.entrySet()) {
        structBuilder.putFields(entry.getKey(), buildValue(entry.getValue()));
      }
      return structBuilder.build();
    }

    /**
     * Cette méthode permet de construire {@link com.google.protobuf.Value}.
     *
     * @param value valeur
     * @return {@link com.google.protobuf.Value}
     */
    public static com.google.protobuf.Value buildValue(Object value) {
      // ✅ ORDRE OPTIMISÉ: du plus fréquent au moins fréquent
      // (à ajuster selon vos données)

      if (value instanceof String) {
        return com.google.protobuf.Value.newBuilder().setStringValue((String) value).build();
      }

      if (value instanceof Number) {
        double d = ((Number) value).doubleValue();
        return com.google.protobuf.Value.newBuilder().setNumberValue(d).build();
      }

      if (value instanceof Boolean) {
        return com.google.protobuf.Value.newBuilder().setBoolValue((Boolean) value).build();
      }

      if (value == null) {
        return com.google.protobuf.Value.newBuilder()
            .setNullValue(com.google.protobuf.NullValue.NULL_VALUE).build();
      }

      if (value instanceof Map) {
        @SuppressWarnings("unchecked")
        Map<String, Object> subMap = (Map<String, Object>) value;
        return com.google.protobuf.Value.newBuilder().setStructValue(convertMapToStruct(subMap))
            .build();
      }

      if (value instanceof List) {
        com.google.protobuf.ListValue.Builder listBuilder =
            com.google.protobuf.ListValue.newBuilder();
        for (Object item : (List<?>) value) {
          listBuilder.addValues(buildValue(item));
        }
        return com.google.protobuf.Value.newBuilder().setListValue(listBuilder.build()).build();
      }

      return com.google.protobuf.Value.newBuilder().setStringValue(value.toString()).build();
    }
  }

  /**
   * Identifiant du service d'évaluation de plusieurs.
   */
  String EVALUATE_MANY_IDENTIFIER = "EVALUATION_PLUSIEURS_SCRIPT";

  /**
   * Chemin du service d'évaluation de plusieurs.
   */
  String EVALUATE_MANY_PATH = "evaluations";

  /**
   * Cette méthode permet d'évaluer plusieurs {@link ScriptDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptEvaluateManyResponseDto.class))})
  Response evaluateMany(ScriptEvaluateManyRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluateManyRequestDto extends AbstractScriptEvaluateManyRequestDto {
    /**
     * {@link StringFormat} de la représentation en chaine de caractères du résultat.
     */
    @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
    private StringFormat resultAsStringFormat;

    /**
     * Identifiant json {@link #resultAsStringFormat}.
     */
    public static final String JSON_RESULT_AS_STRING_FORMAT =
        ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;

    /**
     * Cette méthode permet de convertir.
     *
     * @param request {@link ScriptEvaluateManyRequest}.
     * @return {@link ScriptEvaluateManyRequestDto}
     */
    public static ScriptEvaluateManyRequestDto toDto(ScriptEvaluateManyRequest request) {
      ScriptEvaluateManyRequestDto dto = new ScriptEvaluateManyRequestDto();

      // Mapping du format avec gestion sécurisée du nom
      String formatName = request.getFormat().name();
      // gRPC génère JSON, STRING, RAW. Votre enum StringFormat attend probablement ces noms.
      dto.setResultAsStringFormat(StringFormat.valueOf(formatName));

      request.getGroupsMap().forEach((order, grpcGroup) -> {
        // Conversion propre du Struct en Map
        Map<String, Object> arguments = convertStructToMap(grpcGroup.getArguments());

        // Si votre Business attend une collection pour les identifiants,
        // il faut la créer à partir de la liste gRPC
        Collection<String> scriptIdentifiers = new ArrayList<>();
        grpcGroup.getScriptIdentifiersList().forEach(id -> scriptIdentifiers.add(id));

        // Ajoutez le groupe au DTO avec la map d'identifiants
        dto.addGroup(order, scriptIdentifiers, arguments);
      });

      return dto;
    }
  }

  /**
   * Cette classe représente la réponse de d'évaluation de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ScriptEvaluateManyResponseDto extends AbstractResponseDto {

    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty("groupes")
    private Collection<GroupDto> groups;

    /**
     * Cette méthode permet d'obtenir {@link GroupDto} par numéro d'ordre.
     *
     * @param orderNumber numéro d'ordre
     * @return {@link GroupDto}
     */
    public GroupDto getGroupByOrderNumber(Integer orderNumber) {
      return Optional.ofNullable(groups).orElse(Collections.emptyList()).stream()
          .filter(group -> Objects.equals(group.orderNumber, orderNumber)).findFirst().orElse(null);
    }

    /**
     * Cette méthode permet d'obtenir {@link ResultDto} par numéro d'ordre.
     *
     * @param orderNumber numéro d'ordre
     * @return Collection de {@link ResultDto}
     */
    public Collection<ResultDto> getGroupResultsByOrderNumber(Integer orderNumber) {
      GroupDto group = getGroupByOrderNumber(orderNumber);
      return Optional.ofNullable(group).map(GroupDto::getResults).orElse(Collections.emptyList());
    }

    /**
     * Cette méthode permet d'obtenir une collection non nulle.
     *
     * @return collection non nulle
     */
    public Collection<GroupDto> groups() {
      if (groups == null) {
        groups = new ArrayList<>();
      }
      return groups;
    }

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param group {@link GroupDto}
     * @return {@link ScriptEvaluateManyResponseDto}
     */
    public ScriptEvaluateManyResponseDto addGroup(GroupDto group) {
      if (group != null) {
        groups().add(group);
      }
      return this;
    }

    /**
     * Cette classe représente un groupe.
     *
     * @author Christian
     */
    @Getter
    @Setter
    @ToString
    @EqualsAndHashCode(of = {"orderNumber"})
    public static class GroupDto implements HasOrderNumberDto {

      @JsonbProperty(JSON_ORDER_NUMBER)
      private Integer orderNumber;

      /**
       * Collection de {@link ResultDto}.
       */
      @JsonbProperty(JSON_RESULTS)
      private Collection<ResultDto> results;

      /**
       * Cette méthode permet d'obtenir {@link ResultDto} par numéro d'ordre.
       *
       * @param orderNumber numéro d'ordre
       * @return {@link ResultDto}
       */
      public ResultDto getResultByOrderNumber(Integer orderNumber) {
        return Optional.ofNullable(results).orElse(Collections.emptyList()).stream()
            .filter(result -> Objects.equals(result.getOrderNumber(), orderNumber)).findFirst()
            .orElse(null);
      }

      /**
       * Cette méthode permet d'obtenir {@link ResultDto} par identifiant.
       *
       * @param identifier identifiant
       * @return {@link ResultDto}
       */
      public ResultDto getResultByIdentifier(String identifier) {
        return Optional.ofNullable(results).orElse(Collections.emptyList()).stream()
            .filter(result -> Objects.equals(result.getIdentifier(), identifier)).findFirst()
            .orElse(null);
      }

      /**
       * Cette méthode permet d'obtenir une collection non nulle.
       *
       * @return collection non nulle
       */
      public Collection<ResultDto> results() {
        if (results == null) {
          results = new ArrayList<>();
        }
        return results;
      }

      /**
       * Cette méthode permet d'ajouter {@link ResultDto}.
       *
       * @param result {@link ResultDto}
       * @return {@link GroupDto}
       */
      public GroupDto addResult(ResultDto result) {
        if (result != null) {
          results().add(result);
        }
        return this;
      }

      /**
       * Identifiant json {@link #results}.
       */
      public static final String JSON_RESULTS = "resultats";
    }

    /**
     * Format de {@link ResultDto#valueAsString}.
     */
    @JsonbProperty(JSON_RESULT_VALUE_AS_STRING_FORMAT)
    private StringFormat resultValueAsStringFormat;

    /**
     * Identifiant json {@link #resultValueAsStringFormat}.
     */
    public static final String JSON_RESULT_VALUE_AS_STRING_FORMAT =
        ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;

    /**
     * Cette classe représente un résultat.
     *
     * @author Christian
     */
    @Getter
    @Setter
    @ToString
    @EqualsAndHashCode(callSuper = true)
    public static class ResultDto extends OrderedIdentifierDto
        implements HasMessageDto, HasValueAsStringDto, HasValueAsIntegerDto, HasValueAsBooleanDto {

      @JsonbProperty(JSON_VALUE_AS_STRING)
      private String valueAsString;

      @JsonbProperty(JSON_VALUE_AS_INTEGER)
      private Integer valueAsInteger;

      @JsonbProperty(JSON_VALUE_AS_BOOLEAN)
      private Boolean valueAsBoolean;

      @JsonbProperty(JSON_MESSAGE)
      private String message;

      /**
       * Cette classe représente un constructeur de {@link ResultDto}.
       *
       * @author Christian
       */
      @Getter
      @Setter
      @Accessors(chain = true, fluent = true)
      public static class Builder {

        /**
         * Identifiant.
         */
        private String identifier;

        /**
         * Représentation en entier de la valeur.
         */
        private Integer valueAsInteger;

        /**
         * Message.
         */
        private String message;

        /**
         * Cette méthode permet de construire {@link ResultDto}.
         *
         * @return {@link ResultDto}
         */
        public ResultDto build() {
          ResultDto dto = new ResultDto();
          dto.setIdentifier(identifier);
          dto.setValueAsInteger(valueAsInteger);
          dto.setMessage(message);
          return dto;
        }

        /**
         * cette méthode permet d'instantier un {@link Builder}.
         *
         * @return {@link Builder}
         */
        public static Builder instantiate() {
          return new Builder();
        }
      }
    }

    // gRPC

    /**
     * Cette méthode permet de construire {@link ScriptEvaluateManyResponse}.
     *
     * @return {@link ScriptEvaluateManyResponse}
     */
    public ScriptEvaluateManyResponse toGrpc() {
      ScriptEvaluateManyResponse.Builder responseBuilder = ScriptEvaluateManyResponse.newBuilder();

      if (CollectionCore.isEmpty(groups)) {
        return responseBuilder.build();
      }

      for (ScriptEvaluateManyResponseDto.GroupDto groupDto : groups) {
        ScriptEvaluateManyResponse.GroupResult.Builder groupResultBuilder =
            ScriptEvaluateManyResponse.GroupResult.newBuilder();

        Collection<ScriptEvaluateManyResponseDto.ResultDto> results = groupDto.getResults();
        if (CollectionCore.isNotEmpty(results)) {
          for (ResultDto resultDto : results) {
            if (resultDto == null) {
              continue;
            }
            String identifier = resultDto.getIdentifier();
            String valueAsString = resultDto.getValueAsString();
            String message = resultDto.getMessage();
            Boolean valueAsBoolean = resultDto.getValueAsBoolean();
            Integer valueAsInteger = resultDto.getValueAsInteger();

            ScriptEvaluateManyResponse.ScriptResult scriptResult =
                ScriptEvaluateManyResponse.ScriptResult.newBuilder()
                    .setIdentifier(StringCore.getOrDefaultToEmptyIfNull(identifier))
                    .setValueAsString(StringCore.getOrDefaultToEmptyIfNull(valueAsString))
                    .setValueAsBoolean(BooleanCore.getOrDefaultToFalseIfNull(valueAsBoolean))
                    .setValueAsInteger(NumberCore.getOrDefaultToZeroIfNull(valueAsInteger))
                    .setMessage(StringCore.getOrDefaultToEmptyIfNull(message)).build();

            groupResultBuilder.addResults(scriptResult);
          }
        }

        // ✅ OPTIMISATION 5: Order number extrait une seule fois
        Integer orderNumber = groupDto.getOrderNumber();
        responseBuilder.putGroups(NumberCore.getOrDefaultToZeroIfNull(orderNumber),
            groupResultBuilder.build());
      }

      return responseBuilder.build();
    }


  }

  /**
   * Identifiant du service d'évaluation de plusieurs en entier primitif int.
   */
  String EVALUATE_MANY_AS_INTEGER_PRIMITIVE_IDENTIFIER =
      "EVALUATION_PLUSIEURS_EN_ENTIER_PRIMITIF_INT_SCRIPT";

  /**
   * Chemin du service d'évaluation de plusieurs en entier primitif int.
   */
  String EVALUATE_MANY_AS_INTEGER_PRIMITIVE_PATH = "evaluations/entier-primitif-int";

  /**
   * Cette méthode permet d'évaluer plusieurs {@link ScriptDto} en entier primitif int.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_MANY_AS_INTEGER_PRIMITIVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_MANY_AS_INTEGER_PRIMITIVE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = ScriptEvaluateManyAsIntegerPrimitiveResponseDto.class))})
  Response evaluateManyAsIntegerPrimitive(ScriptEvaluateManyAsIntegerPrimitiveRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation de plusieurs en entier primitif int.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluateManyAsIntegerPrimitiveRequestDto
      extends AbstractScriptEvaluateManyRequestDto {
    
    /**
     * Indique s'il faut ignorer les résultats dont la valeur est 0 
     * et qui n'ont pas de message d'erreur.
     */
    @JsonbProperty("ignorerValeurZeroSansMessage")
    boolean ignoreZeroValueWithoutMessage;

    /**
     * Cette méthode permet de convertir.
     *
     * @param request {@link ScriptEvaluateManyRequest}.
     * @return {@link ScriptEvaluateManyRequestDto}
     */
    public static ScriptEvaluateManyAsIntegerPrimitiveRequestDto toDto(
        ScriptEvaluateManyAsIntegerPrimitiveRequest request) {
      ScriptEvaluateManyAsIntegerPrimitiveRequestDto dto =
          new ScriptEvaluateManyAsIntegerPrimitiveRequestDto();
      dto.setIgnoreZeroValueWithoutMessage(request.getIgnoreZeroValueWithoutMessage());
      request.getGroupsMap().forEach((order, grpcGroup) -> {
        // Conversion propre du Struct en Map
        Map<String, Object> arguments = convertStructToMap(grpcGroup.getArguments());

        // Si votre Business attend une collection pour les identifiants,
        // il faut la créer à partir de la liste gRPC
        Collection<String> scriptIdentifiers = new ArrayList<>();
        grpcGroup.getScriptIdentifiersList().forEach(scriptIdentifiers::add);

        // Ajoutez le groupe au DTO avec la map d'identifiants
        dto.addGroup(order, scriptIdentifiers, arguments);
      });

      return dto;
    }

  }

  /**
   * Cette classe représente la réponse de d'évaluation de plusieurs en entier primitif int.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ScriptEvaluateManyAsIntegerPrimitiveResponseDto extends AbstractResponseDto {

    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty("groupes")
    Collection<GroupDto> groups;

    /**
     * Cette méthode permet d'obtenir {@link GroupDto} par numéro d'ordre.
     *
     * @param orderNumber numéro d'ordre
     * @return {@link GroupDto}
     */
    public GroupDto getGroupByOrderNumber(Integer orderNumber) {
      return Optional.ofNullable(groups).orElse(Collections.emptyList()).stream()
          .filter(group -> Objects.equals(group.orderNumber, orderNumber)).findFirst().orElse(null);
    }

    /**
     * Cette méthode permet d'obtenir {@link ResultDto} par numéro d'ordre.
     *
     * @param orderNumber numéro d'ordre
     * @return Collection de {@link ResultDto}
     */
    public Collection<ResultDto> getGroupResultsByOrderNumber(Integer orderNumber) {
      GroupDto group = getGroupByOrderNumber(orderNumber);
      return Optional.ofNullable(group).map(g -> g.results).orElse(Collections.emptyList());
    }

    /**
     * Cette méthode permet d'obtenir une collection non nulle.
     *
     * @return collection non nulle
     */
    public Collection<GroupDto> groups() {
      if (groups == null) {
        groups = new ArrayList<>();
      }
      return groups;
    }

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param group {@link GroupDto}
     * @return {@link ScriptEvaluateManyAsIntegerPrimitiveResponseDto}
     */
    public ScriptEvaluateManyAsIntegerPrimitiveResponseDto addGroup(GroupDto group) {
      if (group != null) {
        groups().add(group);
      }
      return this;
    }

    /**
     * Ce record représente un groupe.
     *
     * @author Christian
     */
    public static record GroupDto(
        @JsonbProperty(HasOrderNumberDto.JSON_ORDER_NUMBER) int orderNumber,
        @JsonbProperty(JSON_RESULTS) Collection<ResultDto> results) {


      /**
       * Cette méthode permet d'obtenir {@link ResultDto} par identifiant.
       *
       * @param identifier identifiant
       * @return {@link ResultDto}
       */
      public ResultDto getResultByIdentifier(String identifier) {
        return Optional.ofNullable(results).orElse(Collections.emptyList()).stream()
            .filter(result -> Objects.equals(result.identifier(), identifier)).findFirst()
            .orElse(null);
      }

      /**
       * Cette méthode permet d'ajouter {@link ResultDto}.
       *
       * @param result {@link ResultDto}
       * @return {@link GroupDto}
       */
      public GroupDto addResult(ResultDto result) {
        if (results != null && result != null) {
          results.add(result);
        }
        return this;
      }

      /**
       * Identifiant json {@link #results}.
       */
      public static final String JSON_RESULTS = "resultats";
    }

    /**
     * Ce record représente un résultat.
     *
     * @author Christian
     */
    public static record ResultDto(
        @JsonbProperty(HasIdentifierDto.JSON_IDENTIFIER) String identifier,
        @JsonbProperty(HasIntValueDto.JSON_VALUE) int value,
        @JsonbProperty(HasMessageDto.JSON_MESSAGE) String message) {

      /**
       * Cette classe représente un constructeur de {@link ResultDto}.
       *
       * @author Christian
       */
      @Getter
      @Setter
      @Accessors(chain = true, fluent = true)
      public static class Builder {

        /**
         * Identifiant.
         */
        private String identifier;

        /**
         * Valeur.
         */
        private int value;

        /**
         * Message.
         */
        private String message;

        /**
         * Cette méthode permet de construire {@link ResultDto}.
         *
         * @return {@link ResultDto}
         */
        public ResultDto build() {
          return new ResultDto(identifier, value, message);
        }

        /**
         * cette méthode permet d'instantier un {@link Builder}.
         *
         * @return {@link Builder}
         */
        public static Builder instantiate() {
          return new Builder();
        }
      }

    }

    // gRPC

    /**
     * Cette méthode permet de construire {@link ScriptEvaluateManyResponse}.
     *
     * @return {@link ScriptEvaluateManyResponse}
     */
    public ScriptEvaluateManyAsIntegerPrimitiveResponse toGrpc() {
      ScriptEvaluateManyAsIntegerPrimitiveResponse.Builder responseBuilder =
          ScriptEvaluateManyAsIntegerPrimitiveResponse.newBuilder();

      if (CollectionCore.isEmpty(groups)) {
        return responseBuilder.build();
      }

      for (ScriptEvaluateManyAsIntegerPrimitiveResponseDto.GroupDto groupDto : groups) {
        ScriptEvaluateManyAsIntegerPrimitiveResponse.GroupResult.Builder groupResultBuilder =
            ScriptEvaluateManyAsIntegerPrimitiveResponse.GroupResult.newBuilder();

        Collection<ScriptEvaluateManyAsIntegerPrimitiveResponseDto.ResultDto> results =
            groupDto.results();
        if (CollectionCore.isNotEmpty(results)) {
          for (ResultDto result : results) {
            if (result == null) {
              continue;
            }
            String identifier = result.identifier();
            int value = result.value();
            String message = result.message();

            ScriptEvaluateManyAsIntegerPrimitiveResponse.ScriptIntegerPrimitiveResult scriptResult =
                ScriptEvaluateManyAsIntegerPrimitiveResponse.ScriptIntegerPrimitiveResult
                    .newBuilder().setIdentifier(StringCore.getOrDefaultToEmptyIfNull(identifier))
                    .setValue(value).setMessage(StringCore.getOrDefaultToEmptyIfNull(message))
                    .build();

            groupResultBuilder.addResults(scriptResult);
          }
        }

        Integer orderNumber = groupDto.orderNumber();
        responseBuilder.putGroups(NumberCore.getOrDefaultToZeroIfNull(orderNumber),
            groupResultBuilder.build());
      }

      return responseBuilder.build();
    }



  }
}
