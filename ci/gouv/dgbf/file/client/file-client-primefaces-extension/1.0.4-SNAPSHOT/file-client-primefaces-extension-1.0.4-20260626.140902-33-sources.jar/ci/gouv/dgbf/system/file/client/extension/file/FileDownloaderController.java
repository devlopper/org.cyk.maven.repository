package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.RequestScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.io.ByteArrayInputStream;
import lombok.Getter;
import org.primefaces.PrimeFaces;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

/**
 * Cette classe représente le contrôleur de téléchargement de fichier.
 *
 * @author Christian
 *
 */
@Named
@RequestScoped
public class FileDownloaderController extends AbstractController {

  @Getter
  StreamedContent streamedContent;

  @Inject
  FileClient fileClient;

  @PostConstruct
  @Override
  protected void postConstruct() {
    super.postConstruct();
    String identifier = FacesContext.getCurrentInstance().getExternalContext()
        .getRequestParameterMap().get("identifier");
    String ownerIdentifier = FacesContext.getCurrentInstance().getExternalContext()
        .getRequestParameterMap().get("ownerIdentifier");

    FileDto file = fileClient.getByIdentifier(identifier, new ProjectionDto().addNames(
        AbstractIdentifiableNamableDto.JSON_NAME, FileDto.JSON_CONTENT_TYPE), userIdentifier, null);
    if (file == null) {
      PrimeFaces.current().dialog().showMessageDynamic(
          new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aucun fichier trouvé", ""));
    } else {
      byte[] bytes = fileClient.getBytes(identifier, ownerIdentifier, userIdentifier, null);
      if (bytes == null) {
        PrimeFaces.current().dialog().showMessageDynamic(
            new FacesMessage(FacesMessage.SEVERITY_ERROR, "Aucun contenu trouvé", ""));
      } else {
        streamedContent =
            DefaultStreamedContent.builder().name(file.getName()).contentType(file.getContentType())
                .stream(() -> new ByteArrayInputStream(bytes)).build();
      }

    }
  }
}
