package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptParameterDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptParameterRequestMapperImpl implements ScriptParameterRequestMapper {

    @Override
    public ScriptParameterService.ScriptParameterCreateRequestDto mapCreate(ScriptParameterDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptParameterService.ScriptParameterCreateRequestDto scriptParameterCreateRequestDto = new ScriptParameterService.ScriptParameterCreateRequestDto();

        scriptParameterCreateRequestDto.setCode( arg0.getCode() );
        scriptParameterCreateRequestDto.setName( arg0.getName() );
        scriptParameterCreateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptParameterCreateRequestDto.setType( arg0.getType() );

        return scriptParameterCreateRequestDto;
    }

    @Override
    public ScriptParameterService.ScriptParameterUpdateRequestDto mapUpdate(ScriptParameterDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptParameterService.ScriptParameterUpdateRequestDto scriptParameterUpdateRequestDto = new ScriptParameterService.ScriptParameterUpdateRequestDto();

        scriptParameterUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptParameterUpdateRequestDto.setCode( arg0.getCode() );
        scriptParameterUpdateRequestDto.setName( arg0.getName() );
        scriptParameterUpdateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptParameterUpdateRequestDto.setType( arg0.getType() );

        return scriptParameterUpdateRequestDto;
    }
}
