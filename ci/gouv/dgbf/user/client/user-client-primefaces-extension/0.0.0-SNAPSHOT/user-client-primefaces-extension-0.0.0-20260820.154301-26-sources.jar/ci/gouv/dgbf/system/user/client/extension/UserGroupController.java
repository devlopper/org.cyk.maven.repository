package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.core.segregation.HasCapacityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCapacityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupClient;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupRequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserGroupService;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link UserGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class UserGroupController extends AbstractController {

  @Inject
  UserGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  UserGroupRequestMapper requestMapper;

  @Inject
  @Getter
  UsersGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  UserSelectOneController userSelectOneController;

  @Inject
  @Getter
  UserCapacitySelectOneController capacitySelectOneController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = UserGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(UserGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(UserGroupService.PATH);

    ProjectionDto projection = new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
        HasUserAsStringDto.JSON_USER_AS_STRING, HasGroupAsStringDto.JSON_GROUP_AS_STRING,
        HasCapacityAsStringDto.JSON_CAPACITY_AS_STRING);

    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      UserGroupCreateRequestDto request = requestMapper.mapCreate((UserGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
            HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER,
            HasUserIdentifierDto.JSON_USER_IDENTIFIER,
            HasCapacityIdentifierDto.JSON_CAPACITY_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    groupSelectOneController.getAutoComplete().setRequired(true);
    groupSelectOneController.getAutoComplete().addValueConsumer(groupIdentifierConsumer());

    userSelectOneController.getAutoComplete().setRequired(true);
    userSelectOneController.getAutoComplete().addValueConsumer(userIdentifierConsumer());

    capacitySelectOneController.getAutoComplete().addValueConsumer(capacityIdentifierConsumer());
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      groupSelectOneController.getAutoComplete()
          .writeValue(((UserGroupDto) entity).getGroupIdentifier());
      userSelectOneController.getAutoComplete()
          .writeValue(((UserGroupDto) entity).getUserIdentifier());
      capacitySelectOneController.getAutoComplete()
          .writeValue(((UserGroupDto) entity).getCapacityIdentifier());
    };
  }

  Consumer<String> groupIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setGroupIdentifier(identifier);
  }

  Consumer<String> userIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setUserIdentifier(identifier);
  }

  Consumer<String> capacityIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(UserGroupDto.class)
        .setCapacityIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      UserGroupUpdateRequestDto request = requestMapper.mapUpdate((UserGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(groupSelectOneController.getAutoComplete(), userSelectOneController.getAutoComplete(),
            capacitySelectOneController.getAutoComplete())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
