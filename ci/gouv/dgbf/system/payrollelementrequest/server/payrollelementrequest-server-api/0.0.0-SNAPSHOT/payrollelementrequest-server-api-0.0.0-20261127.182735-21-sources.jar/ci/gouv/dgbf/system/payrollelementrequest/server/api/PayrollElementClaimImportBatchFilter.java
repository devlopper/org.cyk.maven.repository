package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimImportBatchDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimImportBatchFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de l'émetteur.
   */
  String submitterIdentifier;

  /**
   * Type de FUR du Lot.
   */
  String furType;

  /**
   * Exercice de la période du Lot.
   */
  Integer year;

  /**
   * Mois de la période du Lot, de 1 à 12.
   */
  Integer month;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementClaimImportBatchFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementClaimImportBatchFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    submitterIdentifier = getSubmitterIdentifier(filter);
    furType = getFurType(filter);
    year = getYear(filter);
    month = getMonth(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setSubmitterIdentifier(filter, submitterIdentifier);
    setFurType(filter, furType);
    setYear(filter, year);
    setMonth(filter, month);
  }

  /**
   * Cette méthode permet d'assigner le type de FUR du Lot.
   *
   * @param filter filtre
   * @param furType type de FUR
   */
  public static void setFurType(FilterDto filter, String furType) {
    set(filter, JSON_FUR_TYPE, f -> f.getValueAsString(), f -> f.setValueAsString(furType));
  }

  /**
   * Cette méthode permet d'obtenir le type de FUR du Lot.
   *
   * @param filter filtre
   * @return type de FUR
   */
  public static String getFurType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUR_TYPE));
  }

  /**
   * Cette méthode permet d'assigner l'exercice de la période du Lot.
   *
   * @param filter filtre
   * @param year exercice
   */
  public static void setYear(FilterDto filter, Integer year) {
    set(filter, JSON_YEAR, f -> f.getValueAsInteger(), f -> f.setValueAsInteger(year));
  }

  /**
   * Cette méthode permet d'obtenir l'exercice de la période du Lot.
   *
   * @param filter filtre
   * @return exercice
   */
  public static Integer getYear(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_YEAR));
  }

  /**
   * Cette méthode permet d'assigner le mois de la période du Lot.
   *
   * @param filter filtre
   * @param month mois, de 1 à 12
   */
  public static void setMonth(FilterDto filter, Integer month) {
    set(filter, JSON_MONTH, f -> f.getValueAsInteger(), f -> f.setValueAsInteger(month));
  }

  /**
   * Cette méthode permet d'obtenir le mois de la période du Lot.
   *
   * @param filter filtre
   * @return mois
   */
  public static Integer getMonth(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_MONTH));
  }

  /**
   * Cette méthode permet d'assigner identifiant de l'émetteur.
   *
   * @param filter filtre
   * @param submitterIdentifier identifiant de l'émetteur
   */
  public static void setSubmitterIdentifier(FilterDto filter, String submitterIdentifier) {
    set(filter, JSON_SUBMITTER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(submitterIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir identifiant de l'émetteur.
   *
   * @param filter filtre
   * @return identifiant de l'émetteur
   */
  public static String getSubmitterIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SUBMITTER_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #furType}.
   */
  public static final String JSON_FUR_TYPE = PayrollElementClaimImportBatchDto.JSON_FUR_TYPE;

  /**
   * Identifiant json champ {@link #year}.
   */
  public static final String JSON_YEAR = "annee";

  /**
   * Identifiant json champ {@link #month}.
   */
  public static final String JSON_MONTH = "mois";

  /**
   * Identifiant json champ {@link #submitterIdentifier}.
   */
  public static final String JSON_SUBMITTER_IDENTIFIER =
      PayrollElementClaimImportBatchDto.JSON_SUBMITTER_IDENTIFIER;
}
