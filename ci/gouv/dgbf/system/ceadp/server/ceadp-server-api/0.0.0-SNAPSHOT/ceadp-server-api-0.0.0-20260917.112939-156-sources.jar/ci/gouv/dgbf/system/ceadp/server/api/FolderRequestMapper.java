package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.FolderService.FolderCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderService.FolderUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FolderDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FolderDto}.

    @author Christian
               """)
public interface FolderRequestMapper
    extends RequestMapper<FolderDto, FolderCreateRequestDto, FolderUpdateRequestDto> {

}
