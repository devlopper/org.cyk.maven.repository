package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipDto}.

    @author Christian
               """)
public interface PayslipRequestMapper
    extends RequestMapper<PayslipDto, PayslipCreateRequestDto, PayslipUpdateRequestDto> {

}
