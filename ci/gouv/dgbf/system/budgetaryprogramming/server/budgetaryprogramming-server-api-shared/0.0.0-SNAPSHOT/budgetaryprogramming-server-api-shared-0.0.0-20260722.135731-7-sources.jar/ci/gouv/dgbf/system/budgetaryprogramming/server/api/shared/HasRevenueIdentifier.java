package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de revenu.
 *
 * @author Christian
 */
public interface HasRevenueIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du revenu.
   *
   * @return identifiant du revenu
   */
  String getRevenueIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du revenu.
   *
   * @param identifier identifiant du revenu
   */
  void setRevenueIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de la dépense.
   */
  String FIELD_REVENUE_IDENTIFIER = "revenueIdentifier";
}
