package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusClient;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link CivilServiceStatusDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class CivilServiceStatusSelectOneController 
    extends AbstractSelectOneIdentifiableController<
    CivilServiceStatusDto, 
    CivilServiceStatusGetManyResponseDto, CivilServiceStatusClient> {

  @Getter
  @Inject
  CivilServiceStatusClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected CivilServiceStatusSelectOneController() {
    super(CivilServiceStatusDto.class, SelectItemLabelStrategy.NAME);
  }
}
