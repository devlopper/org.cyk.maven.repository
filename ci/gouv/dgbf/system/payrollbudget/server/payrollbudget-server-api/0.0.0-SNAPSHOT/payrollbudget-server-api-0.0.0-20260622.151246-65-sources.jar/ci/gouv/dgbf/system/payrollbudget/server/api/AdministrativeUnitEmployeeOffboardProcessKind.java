package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Valeurs possibles du genre de processus lors de la sortie d'un employé d'une unité
 * administrative. Ce choix détermine notamment le périmètre des types de mouvement admissibles
 * (sortie définitive versus temporaire). La donnée est sérialisée sous la clé JSON définie par
 * {@link AdministrativeUnitEmployeeDto#JSON_OFFBOARD_PROCESS_KIND}.
 *
 * @author Christian
 */
public enum AdministrativeUnitEmployeeOffboardProcessKind {

  /** Sortie définitive (décès, fin de contrat, retraite). */
  SORTIE_DEFINITIVE,

  /** Sortie temporaire (détachement, mise à disponibilité). */
  SORTIE_TEMPORAIRE;
}
