package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de prise en
 * charge de ticket sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketClaimActionsCountAsStringDto
    extends HasTicketClaimActionsCountAsString {

  /**
   * Identifiant json du nombre cumulé d'actions de prise en charge de ticket sous forme de
   * chaîne.
   */
  String JSON_TICKET_CLAIM_ACTIONS_COUNT_AS_STRING = "nombreActionsPriseEnChargeTicketChaine";
}
