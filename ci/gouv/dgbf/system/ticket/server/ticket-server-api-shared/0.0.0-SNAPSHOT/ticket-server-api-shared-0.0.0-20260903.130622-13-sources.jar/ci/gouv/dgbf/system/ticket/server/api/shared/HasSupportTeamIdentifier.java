package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'équipe support.
 *
 * @author Arnaud
 */
public interface HasSupportTeamIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'équipe support.
   *
   * @return identifiant de l'équipe support
   */
  String getSupportTeamIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'équipe support.
   *
   * @param supportTeamIdentifier identifiant de l'équipe support
   */
  void setSupportTeamIdentifier(String supportTeamIdentifier);

  /**
   * Identifiant java de l'identifiant de l'équipe support.
   */
  String FIELD_SUPPORT_TEAM_IDENTIFIER = "supportTeamIdentifier";
}
