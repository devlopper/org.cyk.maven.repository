package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeDto}.

    @author akm
               """)
public interface PayrollElementClaimTypeRequestMapper extends
    RequestMapper<PayrollElementClaimTypeDto, PayrollElementClaimTypeCreateRequestDto,
        PayrollElementClaimTypeUpdateRequestDto> {

}
