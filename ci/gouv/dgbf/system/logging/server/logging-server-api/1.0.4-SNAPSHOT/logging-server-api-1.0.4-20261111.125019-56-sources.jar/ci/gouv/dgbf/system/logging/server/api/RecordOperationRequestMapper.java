package ci.gouv.dgbf.system.logging.server.api;

import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RecordOperationDto}.
 *
 * @author Arnaud
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RecordOperationDto}.

    @author Arnaud
    """)
public interface RecordOperationRequestMapper {

  /**
   * Cette méthode permet de mapper une requête de création.
   *
   * @param dto {@link RecordOperationDto}
   * @return requête de création
   */
  RecordOperationService.RecordOperationCreateRequestDto mapCreate(RecordOperationDto dto);
}
