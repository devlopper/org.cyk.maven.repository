package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentNatureService.PayrollComponentNatureCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentNatureService.PayrollComponentNatureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentNatureDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentNatureDto}.

    @author akm
               """)
public interface PayrollComponentNatureRequestMapper
    extends RequestMapper<PayrollComponentNatureDto, 
            PayrollComponentNatureCreateRequestDto, PayrollComponentNatureUpdateRequestDto> {

}
