package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de mail.
 *
 * @author Christian
 */
public interface HasMailIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du mail.
   *
   * @return identifiant du mail
   */
  String getMailIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du mail.
   *
   * @param identifier identifiant du mail
   */
  void setMailIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant du mail.
   */
  String FIELD_MAIL_IDENTIFIER = "mailIdentifier";
}
