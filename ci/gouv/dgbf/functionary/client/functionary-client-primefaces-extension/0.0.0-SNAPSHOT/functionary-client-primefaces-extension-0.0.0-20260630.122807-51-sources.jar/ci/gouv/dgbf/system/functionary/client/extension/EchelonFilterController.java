package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.functionary.server.api.EchelonDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link EchelonDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class EchelonFilterController extends AbstractFilterController<EchelonFilter> {

  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public EchelonFilterController() {
    super(EchelonFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setCivilServiceStatusIdentifier(
        getRequestParameter(EchelonFilter.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));

    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setCivilServiceStatusIdentifier(identifier));
  }
}
