package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fournisseur.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class SupplierDto extends AbstractIdentifiableCodableNamableAuditableDto {


  /**
   * Numéro de compte contribuable.
   */
  @JsonbProperty(JSON_TAX_ACCOUNT_NUMBER)
  private String taxAccountNumber;


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fournisseur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";


  /**
   * Identifiant json {@link #taxAccountNumber}.
   */
  public static final String JSON_TAX_ACCOUNT_NUMBER = "numeroCompteContribuable";
}
