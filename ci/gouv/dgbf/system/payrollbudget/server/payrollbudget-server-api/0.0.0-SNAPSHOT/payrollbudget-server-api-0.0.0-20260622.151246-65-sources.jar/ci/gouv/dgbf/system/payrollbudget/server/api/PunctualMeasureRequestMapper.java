package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.PunctualMeasureService.PunctualMeasureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PunctualMeasureService.PunctualMeasureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PunctualMeasureDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PunctualMeasureDto}.

    @author Christian
               """)
public interface PunctualMeasureRequestMapper extends
    RequestMapper<PunctualMeasureDto,
        PunctualMeasureCreateRequestDto,
        PunctualMeasureUpdateRequestDto> {

}
