package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.file.server.api.FileFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre pour la recherche de fichiers.
 * Les champs « Groupe de fichiers » et « Ensemble de groupes de fichiers » sont
 * contrôlables via les contrôleurs exposés : la page consommatrice peut appeler
 * {@code getGroupIdentifierInputController().visible(false)} ou
 * {@code getGroupIdentifiersInputController().visible(false)} pour les masquer.
 *
 * @author Christian
 *
 */
@Dependent
public class FileFilterController extends AbstractFilterController<FileFilter> {

  @Inject
  @Getter
  InputTextController groupIdentifierInputController;

  @Inject
  @Getter
  InputTextController groupIdentifiersInputController;

  /**
   * Cette méthode permet de construire.
   */
  public FileFilterController() {
    super(FileFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    // Propriétaire porté par l'onglet actif (menu en onglet de FileListPage)
    filter.setOwnerIdentifier(getRequestParameter(FileFilter.JSON_OWNER_IDENTIFIER));

    // Configuration du champ "Groupe de fichiers"
    groupIdentifierInputController.setOutputLableValue("Groupe de fichiers");
    groupIdentifierInputController.getInputText()
        .addValueConsumer(value -> getFilter().setGroupIdentifier(value));

    // Configuration du champ "Ensemble de Groupe de fichiers"
    groupIdentifiersInputController.setOutputLableValue("Ensemble de Groupe de fichiers");
    groupIdentifiersInputController.getInputText()
        .setPlaceholder("Ex: GRP001, GRP002, GRP003");
    groupIdentifiersInputController.getInputText()
        .addValueConsumer(value -> {
          if (value == null || value.trim().isEmpty()) {
            getFilter().setGroupIdentifiers(Collections.emptySet());
          } else {
            Set<String> identifiers = Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .collect(Collectors.toSet());
            getFilter().setGroupIdentifiers(identifiers);
          }
        });
  }
}

