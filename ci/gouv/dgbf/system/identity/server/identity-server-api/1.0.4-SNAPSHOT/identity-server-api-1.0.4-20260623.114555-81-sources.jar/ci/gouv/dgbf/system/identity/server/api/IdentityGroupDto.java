package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une identité d'un groupe.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityGroupDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;

  /**
   * Représentation en chaine de caractères {@link #identityIdentifier}.
   */
  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;

  /**
   * Identifiant {@link IdentityGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Représentation en chaine de caractères {@link #groupAsString}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;
  
  /**
   * Mise à jour des identifiants {@link RoleDto}.
   */
  @JsonbProperty(JSON_UPDATE_ROLES_IDENTIFIERS)
  private Boolean updateRolesIdentifiers;
  
  /**
   * Identifiants {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLES_IDENTIFIERS)
  private Set<String> rolesIdentifiers;
    
  /**
   * Représentation en chaine de caractères {@link #rolesAsString}.
   */
  @JsonbProperty(JSON_ROLES_AS_STRING)
  private String rolesAsString;
  
  /**
   * Identifiant JSON {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";
  
  /**
   * Identifiant JSON {@link #identityAsString}.
   */
  public static final String JSON_IDENTITY_AS_STRING = "identiteChaine";
  
  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";
  
  /**
   * Identifiant JSON {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";
  
  /**
   * Identifiant JSON {@link #rolesIdentifiers}.
   */
  public static final String JSON_ROLES_IDENTIFIERS = "idsRoles";
  
  /**
   * Identifiant JSON {@link #rolesAsString}.
   */
  public static final String JSON_ROLES_AS_STRING = "rolesChaine";

  /**
   * Identifiant JSON de {@link #updateRolesIdentifiers}.
   */
  public static final String JSON_UPDATE_ROLES_IDENTIFIERS = "modificationIdsRoles";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "identité de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "identités de groupe";
}
