package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UserDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-17T20:40:03+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UserRequestMapperImpl implements UserRequestMapper {

    @Override
    public UserService.UserCreateRequestDto mapCreate(UserDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserService.UserCreateRequestDto userCreateRequestDto = new UserService.UserCreateRequestDto();

        userCreateRequestDto.setName( arg0.getName() );
        userCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        userCreateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        userCreateRequestDto.setPass( arg0.getPass() );

        return userCreateRequestDto;
    }

    @Override
    public UserService.UserUpdateRequestDto mapUpdate(UserDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserService.UserUpdateRequestDto userUpdateRequestDto = new UserService.UserUpdateRequestDto();

        userUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        userUpdateRequestDto.setName( arg0.getName() );
        userUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        userUpdateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );

        return userUpdateRequestDto;
    }

    @Override
    public UserService.UserCreateAccountRequestDto mapCreateAccount(UserDto user) {
        if ( user == null ) {
            return null;
        }

        UserService.UserCreateAccountRequestDto userCreateAccountRequestDto = new UserService.UserCreateAccountRequestDto();

        userCreateAccountRequestDto.setIdentifier( user.getIdentifier() );
        userCreateAccountRequestDto.setPass( user.getPass() );

        return userCreateAccountRequestDto;
    }
}
