package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProgrammingDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ProgrammingFilter extends AbstractIdentifiableFilter implements FilterHasStatusCode {

  String statusCode;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
  }

}
