package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueSourceDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueSourceDto}.

    @author Christian
               """)
public interface ValueSourceRequestMapper extends
    RequestMapper<ValueSourceDto, ValueSourceCreateRequestDto, ValueSourceUpdateRequestDto> {

}
