package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RevenueDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class RevenueFilter extends AbstractIdentifiableFilter {

}
