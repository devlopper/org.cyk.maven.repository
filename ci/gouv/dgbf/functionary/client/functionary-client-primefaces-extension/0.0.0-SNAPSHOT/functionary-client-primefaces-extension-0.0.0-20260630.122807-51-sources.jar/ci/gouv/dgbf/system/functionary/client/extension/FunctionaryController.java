package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryClient;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryImportAllRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FunctionaryController extends AbstractController {

  @Inject
  FunctionaryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  FunctionaryFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FunctionaryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(FunctionaryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FunctionaryService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        FunctionaryDto.JSON_REGISTRATION_NUMBER, FunctionaryDto.JSON_FIRST_NAME_AND_LAST_NAMES,
        FunctionaryDto.JSON_EMAIL_ADDRESS, FunctionaryDto.JSON_BIRTH_DATE_AS_STRING,
        FunctionaryDto.JSON_FIRST_SERVICE_START_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getDataTable().getOrderNumberColumn().setWidth("50");

    listController.getDataTable().setHeaderRendered(false);
    listController.getDataTable().getExportButton().setRendered(false);
    listController.getDataTable().getColumnsButton().setRendered(false);
    listController.getShowCreateDialogButton().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(1);
  }

  /**
   * Cette méthode permet d'importer.
   */
  public void importAll() {
    FunctionaryImportAllRequestDto request = new FunctionaryImportAllRequestDto();
    request.setAuditWho(userIdentifier);
    new ActionExecutor<>(this, "Importation", () -> client.importAll(request)).execute();
  }
}
