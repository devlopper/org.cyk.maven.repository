package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette classe représente les codes de {@link PayslipMovementStatus}.
 *
 * @author Christian
 *
 */
public class PayslipMovementStatusCode {

  private PayslipMovementStatusCode() {
    
  }
    
  /**
   * Activé.
   */
  public static final String ACTIVATED = "ACTIVE";
  
  /**
   * Différé proposé.
   */
  public static final String DEFERRED_PROPOSED = "DIFFERE_PROPOSE";
  
  /**
   * Différé.
   */
  public static final String DEFERRED = "DIFFERE";
  
  /**
   * Rejet proposé.
   */
  public static final String REJECTION_PROPOSED = "REJET_PROPOSE";
  
  /**
   * Rejeté.
   */
  public static final String REJECTED = "REJETE"; 

  /**
   * Cloturé.
   */
  public static final String CLOSED = "CLOTURE";
}