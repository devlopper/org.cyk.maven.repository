package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptDto}.

    @author Christian
               """)
public interface ScriptRequestMapper
    extends RequestMapper<ScriptDto, ScriptCreateRequestDto, ScriptUpdateRequestDto> {

}
