package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.SsoUserRoleService.SsoUserRoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.SsoUserRoleService.SsoUserRoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SsoUserRoleDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SsoUserRoleDto}.
    
    @author BoobaCool
    """)
public interface SsoUserRoleRequestMapper extends
    RequestMapper<SsoUserRoleDto, SsoUserRoleCreateRequestDto,
        SsoUserRoleUpdateRequestDto> {

}
