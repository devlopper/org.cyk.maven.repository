package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette classe représente les codes de {@link ProcessNature}, valeurs du référentiel
 * {@code TR_NATURE_PROCESSUS}.
 *
 * @author Christian
 *
 */
public class ProcessNatureCode {

  private ProcessNatureCode() {

  }

  /**
   * Backend.
   */
  public static final String BACKEND = "BACKEND";

  /**
   * Frontend Web.
   */
  public static final String FRONTEND_WEB = "FRONTEND_WEB";

  /**
   * Frontend Mobile (Flutter).
   */
  public static final String FRONTEND_MOBILE_FLUTTER = "FRONTEND_MOBILE_FLUTTER";

  /**
   * Frontend Mobile (Android natif).
   */
  public static final String FRONTEND_MOBILE_ANDROID = "FRONTEND_MOBILE_ANDROID";

  /**
   * Frontend Mobile (iOS natif).
   */
  public static final String FRONTEND_MOBILE_IOS = "FRONTEND_MOBILE_IOS";
}
