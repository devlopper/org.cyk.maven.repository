package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.RoleClient;
import ci.gouv.dgbf.system.identity.server.api.RoleDto;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de plusieurs {@link RoleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class RoleSelectManyController
    extends AbstractSelectManyIdentifiableController<RoleDto, RoleGetManyResponseDto, RoleClient> {

  @Inject
  @Getter
  RoleClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected RoleSelectManyController() {
    super(RoleDto.class, SelectItemLabelStrategy.NAME);
  }
}
