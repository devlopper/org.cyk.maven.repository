package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTabMenuController;
import ci.gouv.dgbf.extension.server.service.api.filter.StatusCodeFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.StatusCodesFilter;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.system.file.client.extension.FileIconManager;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupFilter;
import ci.gouv.dgbf.system.file.server.api.FilesGroupStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de collection de {@link FilesGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class FilesGroupCollectionTabMenuController extends AbstractTabMenuController {

  @Inject
  FilesGroupClient client;

  @Inject
  FileIconManager iconManager;

  @Getter
  String statusCodeParameterName;

  @Getter
  String statusCodesParameterName;

  /**
   * Cette méthode permet de construire.
   */
  public FilesGroupCollectionTabMenuController() {
    menu.setMenuItemStyleClassPrefix("tickets");
    addPage(FilesGroupListPage.class, FilesGroupListPage.OUTCOME);
    statusCodeParameterName = StatusCodeFilter.JSON_KEY;
    statusCodesParameterName = StatusCodesFilter.JSON_KEY;
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();

    menu.tabBuilder().menuItemValue("Tout").type(FilesGroupListPage.class)
        .count(count((FilesGroupStatus) null)).build();

    addMenuTabsFromStatuses();
  }

  String count(FilesGroupStatus status) {
    GetCountRequestDto countRequest = new GetCountRequestDto();
    if (status != null) {
      FilesGroupFilter filter = new FilesGroupFilter();
      filter.setStatusCode(status.getCode());
      countRequest.useFilter(filter);
    }
    countRequest.setAuditWho(userIdentifier);
    Long count = client.getCount(countRequest);
    return String.valueOf(count);
  }

  void addMenuTabsFromStatuses() {
    addMenuTabsFromStatuses(FilesGroupStatus.CREATED, iconManager.getFilesGroupStatusCreated());
    addMenuTabsFromStatuses(FilesGroupStatus.CONFIRMED, iconManager.getFilesGroupStatusConfirmed());
  }

  void addMenuTabsFromStatuses(FilesGroupStatus status, String icon) {
    menu.tabBuilder().menuItemValue(status.getName()).count(count(status)).menuItemIcon(icon)
        .menuItemStyleClassSuffix(status.name().toLowerCase()).type(FilesGroupListPage.class)
        .addMenuItemParameter(statusCodeParameterName, status.getCode()).build();
  }
}
