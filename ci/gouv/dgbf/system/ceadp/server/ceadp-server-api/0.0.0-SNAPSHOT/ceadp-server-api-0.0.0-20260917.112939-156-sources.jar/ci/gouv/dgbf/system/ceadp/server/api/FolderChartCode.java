package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette classe représente les codes de {@link FolderChart}.
 *
 * @author Christian
 *
 */
public class FolderChartCode {

  private FolderChartCode() {
    
  }
  
  /**
   * Compte des statuts des activités.
   */
  public static final String ACTIVITY_STATUS_COUNTS = "COMPTE_STATUT_ACTIVITE";
  
  /**
   * Compte des statuts des taches.
   */
  public static final String TASK_STATUS_COUNTS = "COMPTE_STATUT_TACHE";

  /**
   * Compte du nombre d'activités en retard.
   */
  public static final String ACTIVITY_LATE_COUNT  = "COMPTE_RETARD_ACTIVITE";
}
