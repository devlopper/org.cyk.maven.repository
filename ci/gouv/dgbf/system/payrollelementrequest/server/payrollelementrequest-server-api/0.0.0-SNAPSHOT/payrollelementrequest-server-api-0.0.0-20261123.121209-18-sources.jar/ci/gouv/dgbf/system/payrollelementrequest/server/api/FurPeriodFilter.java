package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FurPeriodDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FurPeriodFilter extends AbstractIdentifiableFilter {

  /**
   * Exercice de la période.
   */
  Integer year;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FurPeriodFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FurPeriodFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    year = getYear(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setYear(filter, year);
  }

  /**
   * Cette méthode permet d'assigner l'exercice.
   *
   * @param filter filtre
   * @param year exercice
   */
  public static void setYear(FilterDto filter, Integer year) {
    set(filter, JSON_YEAR, f -> f.getValueAsInteger(), f -> f.setValueAsInteger(year));
  }

  /**
   * Cette méthode permet d'obtenir l'exercice.
   *
   * @param filter filtre
   * @return exercice
   */
  public static Integer getYear(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_YEAR));
  }

  /**
   * Identifiant json champ {@link #year}.
   */
  public static final String JSON_YEAR = "annee";
}
