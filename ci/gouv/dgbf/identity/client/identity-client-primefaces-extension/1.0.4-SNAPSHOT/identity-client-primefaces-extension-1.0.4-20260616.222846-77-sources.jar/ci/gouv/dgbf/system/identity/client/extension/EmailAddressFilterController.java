package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.server.service.api.filter.IdentifierFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.StringValueFilter;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link EmailAddressDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class EmailAddressFilterController
    extends AbstractFilterController<EmailAddressFilter> {

  /**
   * Cette méthode permet d'instantier.
   */
  public EmailAddressFilterController() {
    super(EmailAddressFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setIdentifier(getRequestParameter(IdentifierFilter.JSON_KEY));
    filter.setValue(getRequestParameter(StringValueFilter.JSON_KEY));
  }
}

