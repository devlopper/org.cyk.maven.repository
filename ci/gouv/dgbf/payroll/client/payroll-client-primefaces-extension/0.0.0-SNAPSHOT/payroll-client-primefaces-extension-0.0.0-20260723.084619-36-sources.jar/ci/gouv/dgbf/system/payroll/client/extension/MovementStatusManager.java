package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.payroll.server.api.MovementStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link MovementStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class MovementStatusManager extends AbstractStatusManager<MovementStatus> {
  
  /**
   * Cette méthode permet d'instanctier.
   */
  public MovementStatusManager() {
    super(MovementStatus.class, e -> e.getName());
  }
}
