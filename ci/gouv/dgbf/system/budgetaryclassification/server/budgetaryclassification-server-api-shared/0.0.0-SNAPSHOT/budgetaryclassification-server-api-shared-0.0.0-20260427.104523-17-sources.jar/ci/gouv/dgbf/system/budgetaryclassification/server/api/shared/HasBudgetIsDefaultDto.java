package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de budget est par défaut.
 *
 * @author Christian
 */
public interface HasBudgetIsDefaultDto extends HasBudgetIsDefault {
  
  /**
   * Identifiant json de budget est par défaut.
   */
  String JSON_BUDGET_IS_DEFAULT = "budgetEstParDefaut";
}