package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasSourceIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStringData;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ValueDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ValueFilter extends AbstractIdentifiableFilter
    implements FilterHasSourceIdentifier, FilterHasStringData {

  private String sourceIdentifier;

  private String data;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ValueFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ValueFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateSourceIdentifier(filter);
    updateData(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterSourceIdentifier(filter);
    updateFilterData(filter);
  }

}
