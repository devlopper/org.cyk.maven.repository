package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FurGradeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-23T12:07:56+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FurGradeRequestMapperImpl implements FurGradeRequestMapper {

    @Override
    public FurGradeService.FurGradeCreateRequestDto mapCreate(FurGradeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurGradeService.FurGradeCreateRequestDto furGradeCreateRequestDto = new FurGradeService.FurGradeCreateRequestDto();

        furGradeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        furGradeCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        furGradeCreateRequestDto.setScaleCorpsCode( arg0.getScaleCorpsCode() );
        furGradeCreateRequestDto.setGradeCode( arg0.getGradeCode() );
        furGradeCreateRequestDto.setCategoryCode( arg0.getCategoryCode() );
        furGradeCreateRequestDto.setCaloJobCode( arg0.getCaloJobCode() );
        furGradeCreateRequestDto.setCaloGradeCode( arg0.getCaloGradeCode() );
        furGradeCreateRequestDto.setCaloClassCode( arg0.getCaloClassCode() );
        furGradeCreateRequestDto.setCaloStepCode( arg0.getCaloStepCode() );

        return furGradeCreateRequestDto;
    }

    @Override
    public FurGradeService.FurGradeUpdateRequestDto mapUpdate(FurGradeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurGradeService.FurGradeUpdateRequestDto furGradeUpdateRequestDto = new FurGradeService.FurGradeUpdateRequestDto();

        furGradeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        furGradeUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        furGradeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        furGradeUpdateRequestDto.setScaleCorpsCode( arg0.getScaleCorpsCode() );
        furGradeUpdateRequestDto.setGradeCode( arg0.getGradeCode() );
        furGradeUpdateRequestDto.setCategoryCode( arg0.getCategoryCode() );
        furGradeUpdateRequestDto.setCaloJobCode( arg0.getCaloJobCode() );
        furGradeUpdateRequestDto.setCaloGradeCode( arg0.getCaloGradeCode() );
        furGradeUpdateRequestDto.setCaloClassCode( arg0.getCaloClassCode() );
        furGradeUpdateRequestDto.setCaloStepCode( arg0.getCaloStepCode() );

        return furGradeUpdateRequestDto;
    }
}
