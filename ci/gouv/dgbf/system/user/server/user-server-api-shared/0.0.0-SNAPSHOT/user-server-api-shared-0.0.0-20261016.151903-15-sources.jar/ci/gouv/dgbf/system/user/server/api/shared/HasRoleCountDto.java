package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de rôles métier.
 *
 * @author Christian Yao Komenan
 */
public interface HasRoleCountDto extends HasRoleCount {

  /**
   * Identifiant json du nombre de rôles métier.
   */
  String JSON_ROLE_COUNT = "nombreRoles";
}
