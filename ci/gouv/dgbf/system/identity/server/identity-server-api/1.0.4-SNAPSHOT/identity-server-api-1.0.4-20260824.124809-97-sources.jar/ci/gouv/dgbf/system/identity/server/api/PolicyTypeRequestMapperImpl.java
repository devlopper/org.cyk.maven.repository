package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PolicyTypeDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-24T12:48:30+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PolicyTypeRequestMapperImpl implements PolicyTypeRequestMapper {

    @Override
    public PolicyTypeService.PolicyTypeCreateRequestDto mapCreate(PolicyTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyTypeService.PolicyTypeCreateRequestDto policyTypeCreateRequestDto = new PolicyTypeService.PolicyTypeCreateRequestDto();

        policyTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyTypeCreateRequestDto.setCode( arg0.getCode() );
        policyTypeCreateRequestDto.setName( arg0.getName() );

        return policyTypeCreateRequestDto;
    }

    @Override
    public PolicyTypeService.PolicyTypeUpdateRequestDto mapUpdate(PolicyTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyTypeService.PolicyTypeUpdateRequestDto policyTypeUpdateRequestDto = new PolicyTypeService.PolicyTypeUpdateRequestDto();

        policyTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        policyTypeUpdateRequestDto.setCode( arg0.getCode() );
        policyTypeUpdateRequestDto.setName( arg0.getName() );

        return policyTypeUpdateRequestDto;
    }
}
