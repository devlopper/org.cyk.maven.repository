package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+1.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN1Dto extends HasRemainingAmountToInputN1 {

  /**
   * Identifiant json du montant restant à saisir pour l'année N+1.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N1 = "montantResteASaisirN1";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName