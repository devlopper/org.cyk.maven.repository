package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitPunctualMeasureDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitPunctualMeasureFilter extends AbstractIdentifiableFilter
    implements FilterHasBudgetIdentifier, FilterHasAdministrativeUnitIdentifier,
    FilterHasBudgetAdministrativeUnitIdentifier {

  /**
   * Identifiant du budget.
   */
  String budgetIdentifier;

  /**
   * Identifiant de l'unité administrative.
   */
  String administrativeUnitIdentifier;

  /**
   * Identifiant de l'unité administrative de budget (composite).
   */
  String budgetAdministrativeUnitIdentifier;

  /**
   * Identifiant de la mesure ponctuelle.
   */
  String punctualMeasureIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public AdministrativeUnitPunctualMeasureFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitPunctualMeasureFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetIdentifier(filter);
    updateAdministrativeUnitIdentifier(filter);
    updateBudgetAdministrativeUnitIdentifier(filter);
    punctualMeasureIdentifier = getPunctualMeasureIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetIdentifier(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    updateFilterBudgetAdministrativeUnitIdentifier(filter);
    setPunctualMeasureIdentifier(filter, punctualMeasureIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la mesure ponctuelle.
   *
   * @param filter filtre
   * @return identifiant de la mesure ponctuelle
   */
  public static String getPunctualMeasureIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PUNCTUAL_MEASURE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la mesure ponctuelle.
   *
   * @param filter filtre
   * @param identifier identifiant de la mesure ponctuelle
   */
  public static void setPunctualMeasureIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PUNCTUAL_MEASURE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Clé JSON de {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER =
      AdministrativeUnitPunctualMeasureDto.JSON_BUDGET_IDENTIFIER;

  /**
   * Clé JSON de {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitPunctualMeasureDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Clé JSON du filtre d'unité administrative de budget (composite).
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Clé JSON de {@link #punctualMeasureIdentifier}.
   */
  public static final String JSON_PUNCTUAL_MEASURE_IDENTIFIER =
      AdministrativeUnitPunctualMeasureDto.JSON_PUNCTUAL_MEASURE_IDENTIFIER;
}
