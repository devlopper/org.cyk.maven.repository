package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationService.RepresentationCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationService.RepresentationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RepresentationDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RepresentationDto}.

    @author akm
               """)
public interface RepresentationRequestMapper extends RequestMapper<RepresentationDto,
    RepresentationCreateRequestDto, RepresentationUpdateRequestDto> {

}
