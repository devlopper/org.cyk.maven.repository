package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasActivityIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetCategoryIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetSpecializationUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasEconomicNatureIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasExerciseIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasSectionIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetCategoryIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetSpecializationUnitIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasSectionIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollComponentCategoryIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollComponentCategoryIdentifierDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExpenditureDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ExpenditureFilter extends AbstractIdentifiableFilter
       implements FilterHasActivityIdentifier,
                  FilterHasEconomicNatureIdentifier,
                  HasEconomicNatureIdentifierDto,
                  FilterHasSectionIdentifier,
                  HasSectionIdentifierDto,
                  FilterHasBudgetCategoryIdentifier,
                  HasBudgetCategoryIdentifierDto,
                  FilterHasPayrollComponentCategoryIdentifier,
                  HasPayrollComponentCategoryIdentifierDto,
                  FilterHasBudgetSpecializationUnitIdentifier,
                  HasBudgetSpecializationUnitIdentifierDto, FilterHasExerciseIdentifier {


  /**
   * Identifiant activité.
   */
  private String activityIdentifier;

  /**
   * Identifiant nature Economique.
   */
  private String economicNatureIdentifier;

  /**
   * Identifiant section.
   */
  private String sectionIdentifier;

  /**
   * Identifiant categorie.
   */
  private String budgetCategoryIdentifier;

  /**
   * Identifiant categorie.
   */
  private String payrollComponentCategoryIdentifier;

  /**
   * Identifiant unite.
   */
  private String budgetSpecializationUnitIdentifier;

  /**
   * Identifiant exercice.
   */
  private String exerciseIdentifier;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ExpenditureFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ExpenditureFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateActivityIdentifier(filter);
    updateEconomicNatureIdentifier(filter);
    updateSectionIdentifier(filter);
    updateBudgetCategoryIdentifier(filter);
    updatePayrollComponentCategoryIdentifier(filter);
    updateBudgetSpecializationUnitIdentifier(filter);
    updateExerciseIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterActivityIdentifier(filter);
    updateFilterEconomicNatureIdentifier(filter);
    updateFilterSectionIdentifier(filter);
    updateFilterBudgetCategoryIdentifier(filter);
    updateFilterPayrollComponentCategoryIdentifier(filter);
    updateFilterBudgetSpecializationUnitIdentifier(filter);
    updateFilterExerciseIdentifier(filter);
  }

}
