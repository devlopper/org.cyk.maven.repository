package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}.
 *
 * @author parfait
 */
public interface HasBudgetAdministrativeUnitStaffIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @return identifiant de {@link BudgetAdministrativeUnitStaffDto}
   */
  String getBudgetAdministrativeUnitStaffIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param identifier identifiant de {@link BudgetAdministrativeUnitStaffDto}
   */
  void setBudgetAdministrativeUnitStaffIdentifier(String identifier);

}
