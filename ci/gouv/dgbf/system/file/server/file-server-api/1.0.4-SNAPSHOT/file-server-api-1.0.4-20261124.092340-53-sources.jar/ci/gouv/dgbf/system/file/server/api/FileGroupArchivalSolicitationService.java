package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des demandes d'archivage.
 *
 * @author Christian
 *
 */
@Path(value = FileGroupArchivalSolicitationService.PATH)
@Tag(name = "Gestion des demandes d'archivage de fichiers de groupe")
public interface FileGroupArchivalSolicitationService extends SpecificService {

  /**
   * Chemin des services.
   */
  String PATH = "demandes-archivage-fichiers-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer une demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une demande d'archivage ou de retrait",
      description = "Ce service permet de créer une demande d'archivage ou de retrait")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileGroupArchivalSolicitationCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement d'une demande d'archivage.
   *
   * @author Christian
   *
   */
  interface FileGroupArchivalSolicitationSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du fichier de groupe maître.
     *
     * @return identifiant du fichier de groupe
     */
    String getFileGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du fichier de groupe maître.
     *
     * @param fileGroupIdentifier identifiant du fichier de groupe
     */
    void setFileGroupIdentifier(String fileGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'archive d'origine.
     *
     * @return identifiant de l'archive d'origine
     */
    String getOriginIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'archive d'origine.
     *
     * @param originIdentifier identifiant de l'archive d'origine
     */
    void setOriginIdentifier(String originIdentifier);

    /**
     * Cette méthode permet d'obtenir le motif.
     *
     * @return motif
     */
    String getReason();

    /**
     * Cette méthode permet d'assigner le motif.
     *
     * @param reason motif
     */
    void setReason(String reason);

    /**
     * {@link FileGroupArchivalSolicitationDto#JSON_FILE_GROUP_IDENTIFIER}.
     */
    String JSON_FILE_GROUP_IDENTIFIER =
        FileGroupArchivalSolicitationDto.JSON_FILE_GROUP_IDENTIFIER;

    /**
     * {@link FileGroupArchivalSolicitationDto#JSON_ORIGIN_IDENTIFIER}.
     */
    String JSON_ORIGIN_IDENTIFIER =
        FileGroupArchivalSolicitationDto.JSON_ORIGIN_IDENTIFIER;

    /**
     * {@link FileGroupArchivalSolicitationDto#JSON_REASON}.
     */
    String JSON_REASON = FileGroupArchivalSolicitationDto.JSON_REASON;
  }

  /**
   * Cette classe représente la requête de création d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationCreateRequestDto extends ByIdentifierRequestDto
      implements FileGroupArchivalSolicitationSaveRequestDto {

    @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
    private String fileGroupIdentifier;

    @JsonbProperty(JSON_ORIGIN_IDENTIFIER)
    private String originIdentifier;

    @JsonbProperty(JSON_REASON)
    private String reason;

    @Override
    public String getFileGroupIdentifier() {
      return fileGroupIdentifier != null ? fileGroupIdentifier : getIdentifier();
    }

    @Override
    public void setFileGroupIdentifier(String fileGroupIdentifier) {
      this.fileGroupIdentifier = fileGroupIdentifier;
      if (getIdentifier() == null) {
        setIdentifier(fileGroupIdentifier);
      }
    }
  }

  /**
   * Identifiant du service d'obtention de plusieurs demandes d'archivage.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs demandes d'archivage.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs demandes d'archivage.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des demandes d'archivage")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs demandes d'archivage.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileGroupArchivalSolicitationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileGroupArchivalSolicitationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une demande d'archivage.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une demande d'archivage")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant une demande d'archivage.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une demande d'archivage")
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = FileGroupArchivalSolicitationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'annulation d'une demande d'archivage ou de retrait.
   */
  String CANCEL_IDENTIFIER = "ANNULATION_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'annulation d'une demande d'archivage ou de retrait.
   */
  String CANCEL_PATH = "annulation";

  /**
   * Cette méthode permet d'annuler sa propre demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CANCEL_IDENTIFIER,
      summary = "Annulation d'une demande d'archivage ou de retrait",
      description = "Ce service permet d'annuler sa propre demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchivalSolicitationCancelResponseDto.class))})
  Response cancel(FileGroupArchivalSolicitationCancelRequestDto request);

  /**
   * Cette classe représente la requête d'annulation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationCancelRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire de l'annulation.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif.
     */
    public static final String JSON_REASON = "motifAnnulation";
  }

  /**
   * Cette classe représente la réponse d'annulation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationCancelResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage annulée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";
  }

  /**
   * Identifiant du service d'acceptation d'une demande d'archivage ou de retrait.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'acceptation d'une demande d'archivage ou de retrait.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet d'accepter une demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ACCEPT_IDENTIFIER,
      summary = "Acceptation d'une demande d'archivage ou de retrait",
      description = "Ce service permet d'accepter une demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchivalSolicitationAcceptResponseDto.class))})
  Response accept(FileGroupArchivalSolicitationAcceptRequestDto request);

  /**
   * Cette classe représente la requête d'acceptation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationAcceptRequestDto extends ByIdentifierRequestDto {
  }

  /**
   * Cette classe représente la réponse d'acceptation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationAcceptResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage acceptée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Archive effective créée ou clôturée.
     */
    @JsonbProperty(JSON_ARCHIVE)
    private FileGroupArchiveDto archive;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";

    /**
     * Clé JSON de l'archive.
     */
    public static final String JSON_ARCHIVE = "archive";
  }

  /**
   * Identifiant du service de refus d'une demande d'archivage ou de retrait.
   */
  String REFUSE_IDENTIFIER = "REFUS_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service de refus d'une demande d'archivage ou de retrait.
   */
  String REFUSE_PATH = "refus";

  /**
   * Cette méthode permet de refuser une demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REFUSE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REFUSE_IDENTIFIER,
      summary = "Refus d'une demande d'archivage ou de retrait",
      description = "Ce service permet de refuser une demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchivalSolicitationRefuseResponseDto.class))})
  Response refuse(FileGroupArchivalSolicitationRefuseRequestDto request);

  /**
   * Cette classe représente la requête de refus d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationRefuseRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire du refus.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif de refus.
     */
    public static final String JSON_REASON = "motifRefus";
  }

  /**
   * Cette classe représente la réponse de refus d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationRefuseResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage refusée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";
  }

  /** Identifiant du service d'obtention du journal des événements d'Archivage. */
  String GET_JOURNAL_ENTRIES_IDENTIFIER = "OBTENTION_JOURNAL_ARCHIVAGE_FICHIER_GROUPE";

  /** Chemin du service d'obtention du journal des événements d'Archivage. */
  String GET_JOURNAL_ENTRIES_PATH = "journal-archivage/obtention";

  /**
   * Cette méthode permet d'obtenir le journal des événements d'Archivage d'un fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_JOURNAL_ENTRIES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_JOURNAL_ENTRIES_IDENTIFIER,
      description = "Ce service permet d'obtenir le journal des événements d'Archivage")
  Response getArchivalJournalEntries(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs entrées du journal
   * des événements d'Archivage.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FileGroupArchivalJournalEntriesGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileGroupArchivalJournalEntryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileGroupArchivalJournalEntryDto> datas;
  }

  /** Identifiant du service de correction d'une information de Demande. */
  String CORRECT_INFORMATION_IDENTIFIER = "CORRECTION_INFORMATION_ARCHIVE_FICHIER_GROUPE";

  /** Chemin du service de correction d'une information de Demande. */
  String CORRECT_INFORMATION_PATH = "correction-information";

  /** Corrige une information de Demande dans une transaction exclusive. */
  @Path(CORRECT_INFORMATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CORRECT_INFORMATION_IDENTIFIER,
      description = "Ce service permet de corriger une information de Demande")
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(
          implementation = FileGroupArchivalSolicitationDto.class))})
  Response correctInformation(FileGroupArchivalSolicitationInformationCorrectionRequestDto request);

  /** Requête de correction d'une information de Demande. */
  @Getter
  @Setter
  class FileGroupArchivalSolicitationInformationCorrectionRequestDto
      extends ByIdentifierRequestDto {
    @JsonbProperty(JSON_FIELD_KIND)
    private String fieldKind;
    @JsonbProperty(JSON_EXPECTED_VALUE)
    private String expectedValue;
    @JsonbProperty(JSON_NEW_VALUE)
    private String newValue;
    @JsonbProperty(JSON_JUSTIFICATION)
    private String justification;

    public static final String JSON_FIELD_KIND = "champConcerne";
    public static final String JSON_EXPECTED_VALUE = "valeurAttendue";
    public static final String JSON_NEW_VALUE = "nouvelleValeur";
    public static final String JSON_JUSTIFICATION = "justification";
  }

  /** Identifiant du service d'obtention du compte. */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_DEMANDE_ARCHIVAGE_FICHIER_GROUPE";
  String GET_COUNT_PATH = "obtention/compte";

  /** Obtient le nombre de concepts correspondant aux filtres. */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);
}
