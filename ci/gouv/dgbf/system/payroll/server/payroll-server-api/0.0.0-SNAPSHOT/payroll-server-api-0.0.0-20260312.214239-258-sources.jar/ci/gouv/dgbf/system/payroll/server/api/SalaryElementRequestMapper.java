package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SalaryElementDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SalaryElementDto}.

    @author stephane
               """)
public interface SalaryElementRequestMapper
    extends RequestMapper<SalaryElementDto, 
            SalaryElementCreateRequestDto, SalaryElementUpdateRequestDto> {

}
