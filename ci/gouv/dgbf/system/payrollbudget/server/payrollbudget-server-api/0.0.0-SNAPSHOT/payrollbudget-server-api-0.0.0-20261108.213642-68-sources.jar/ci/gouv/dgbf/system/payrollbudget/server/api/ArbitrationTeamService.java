package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat des équipes d'arbitrage : qui les forme, et ce qu'elles bornent.
 *
 * <p>Chaque chef d'équipe compose la sienne. Le service ne lui impose pas de l'être : il
 * enregistre le chef qu'on lui donne, et c'est l'écran qui propose à l'agent connecté de se
 * désigner. Le forcer ici aurait interdit à un administrateur de rattraper une équipe dont le
 * chef a quitté le service.</p>
 *
 * <p>Une équipe ne se supprime qu'avant d'avoir servi. Dès qu'elle a instruit, ses décisions
 * portent son nom : on la désactive.</p>
 *
 * @author Christian
 *
 */
@Path(value = ArbitrationTeamService.PATH)
@Tag(name = "Gestion des équipes d'arbitrage")
public interface ArbitrationTeamService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "equipes-arbitrage";

  /**
   * Ce qu'une équipe porte au-delà de son code et de son libellé.
   *
   * <p>Une seule déclaration pour la création et la modification : un attribut qu'on pourrait
   * poser à la création sans savoir le reprendre ensuite serait un piège.</p>
   */
  interface ArbitrationTeamSaveRequestDto {

    /**
     * Retourne l'exercice de l'équipe.
     *
     * @return l'exercice
     */
    String getExercise();

    /**
     * Assigne l'exercice de l'équipe.
     *
     * @param exercise l'exercice
     */
    void setExercise(String exercise);

    /**
     * Retourne le chef d'équipe.
     *
     * @return son identifiant de connexion
     */
    String getLeader();

    /**
     * Assigne le chef d'équipe.
     *
     * @param leader son identifiant de connexion
     */
    void setLeader(String leader);

    /**
     * Indique si l'équipe travaille.
     *
     * @return vrai si elle est active
     */
    Boolean getActive();

    /**
     * Assigne l'activité de l'équipe.
     *
     * @param active vrai si elle travaille
     */
    void setActive(Boolean active);

    /**
     * {@link ArbitrationTeamDto#JSON_EXERCISE}.
     */
    String JSON_EXERCISE = ArbitrationTeamDto.JSON_EXERCISE;

    /**
     * {@link ArbitrationTeamDto#JSON_LEADER}.
     */
    String JSON_LEADER = ArbitrationTeamDto.JSON_LEADER;

    /**
     * {@link ArbitrationTeamDto#JSON_ACTIVE}.
     */
    String JSON_ACTIVE = ArbitrationTeamDto.JSON_ACTIVE;
  }

  /**
   * Identifiant du service de création unitaire de {@link ArbitrationTeamDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service de création unitaire de {@link ArbitrationTeamDto}.
   */
  String CREATE_PATH = "";

  /**
   * Création d'une équipe.
   *
   * @param request l'équipe à créer
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une équipe d'arbitrage")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ArbitrationTeamCreateRequestDto request);

  /**
   * Requête de création d'une équipe.
   */
  @Getter
  @Setter
  class ArbitrationTeamCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ArbitrationTeamSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE)
    private String exercise;

    @JsonbProperty(JSON_LEADER)
    private String leader;

    @JsonbProperty(JSON_ACTIVE)
    private Boolean active;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ArbitrationTeamDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ArbitrationTeamDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des équipes.
   *
   * @param request critères, projection et pagination
   * @return les équipes correspondantes
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER, summary = "Consultation des équipes d'arbitrage")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ArbitrationTeamGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche d'équipes.
   */
  @Getter
  @Setter
  public static class ArbitrationTeamGetManyResponseDto
      extends AbstractGetByPageResponseDto<ArbitrationTeamDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ArbitrationTeamDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ArbitrationTeamDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service d'obtention unitaire de {@link ArbitrationTeamDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Recherche d'une équipe unique.
   *
   * @param request critères et projection
   * @return l'équipe correspondante
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ArbitrationTeamDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ArbitrationTeamDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service d'obtention par identifiant de {@link ArbitrationTeamDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'une équipe par son identifiant.
   *
   * @param request identifiant et projection
   * @return l'équipe correspondante
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ArbitrationTeamDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ArbitrationTeamDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service de mise à jour unitaire de {@link ArbitrationTeamDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Modification d'une équipe.
   *
   * @param request l'équipe modifiée
   * @return l'identifiant touché
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER, summary = "Modification d'une équipe d'arbitrage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ArbitrationTeamUpdateRequestDto request);

  /**
   * Requête de modification d'une équipe.
   */
  @Getter
  @Setter
  class ArbitrationTeamUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ArbitrationTeamSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE)
    private String exercise;

    @JsonbProperty(JSON_LEADER)
    private String leader;

    @JsonbProperty(JSON_ACTIVE)
    private Boolean active;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ArbitrationTeamDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EQUIPE_ARBITRAGE";

  /**
   * Chemin du service de suppression unitaire de {@link ArbitrationTeamDto}.
   */
  String DELETE_PATH = "";

  /**
   * Suppression d'une équipe.
   *
   * <p>Refusée dès qu'un dossier lui est confié : l'effacer laisserait des décisions sans
   * auteur collectif. Pour celles-là, l'indicateur <em>actif</em> met fin sans effacer.</p>
   *
   * @param request l'identifiant à supprimer
   * @return l'identifiant supprimé
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER, summary = "Suppression d'une équipe d'arbitrage")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
