package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Date;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProcedureDetailModelDto}.
 *
 * @author Desysoft
 */
@Path(value = ProcedureDetailModelService.PATH)
@Tag(name = "Gestion des modèles de detail de procedure")
public interface ProcedureDetailModelService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "modeles-detail-procedure";


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MODELE_DETAIL_PROCEDURE";

  /**
   * Identifiant du service de création par modèle.
   */
  String CREATE_BY_MODEL_IDENTIFIER = "CREATION_PAR_MODELE_MODELE_DETAIL_PROCEDURE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Chemin du service de création par modele.
   */
  String CREATE_BY_MODEL_PATH = "creation-par-modele";
  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MODELES_DETAIL_PROCEDURE";
  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";
  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MODELE_DETAIL_PROCEDURE";
  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";
  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MODELE_DETAIL_PROCEDURE";
  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";
  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MODELE_DETAIL_PROCEDURE";
  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";
  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MODELE_DETAIL_PROCEDURE";
  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProcedureDetailModelCreateRequestDto request);

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_MODEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_MODEL_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByModel(ProcedureDetailCreateByProcedureDetailModelRequestDto request);

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema =
          @Schema(implementation = ProcedureDetailModelGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette méthode permet d'obtenir {@link ProcedureDetailModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureDetailModelDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Cette méthode permet d'obtenir par identrifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureDetailModelDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcedureDetailModelUpdateRequestDto request);

  /**
   * Cette méthode permet de supprimer {@link ProcedureDetailModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Desysoft
   */
  interface ProcedureDetailModelSaveRequestDto {

    /**
     * Identifiant JSON {@link ProcedureDto}.
     */
    String JSON_PROCEDURE_MODEL_IDENTIFIER =
        ProcedureDetailModelDto.JSON_PROCEDURE_MODEL_IDENTIFIER;

    /**
     * Identifiant json du champ d'ordre.
     */
    String JSON_ORDER = ProcedureDetailModelDto.JSON_ORDER;

    /**
     * Identifiant json du champ de date detail.
     */
    String JSON_DETAIL_DATE = ProcedureDetailModelDto.JSON_DETAIL_DATE;

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ProcedureDto}.
     *
     * @param procedureModelIdentifier identifiant de {@link ProcedureDto}
     */
    void setProcedureModelIdentifier(String procedureModelIdentifier);
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ProcedureDetailModelCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ProcedureDetailModelSaveRequestDto {

    @JsonbProperty(JSON_PROCEDURE_MODEL_IDENTIFIER)
    private String procedureModelIdentifier;

    @JsonbProperty(JSON_ORDER)
    private Integer order;

    @JsonbProperty(JSON_DETAIL_DATE)
    private Date detailDate;

  }

  /**
   * Cette classe représente la requête de création par modèle de procédure.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ProcedureDetailCreateByProcedureDetailModelRequestDto
      extends AbstractCodableNamableCreateRequestJsonDto {
    @JsonbProperty(JSON_PROCEDURE_DETAIL_MODEL_IDENTIFIER)
    private String procedureDetailModelIdentifier;

    @JsonbProperty(JSON_PROCEDURE_IDENTIFIER)
    private String procedureIdentifier;

    /**
     * Identifiant champ json du modèle de détail de procédure.
     */
    public static final String JSON_PROCEDURE_DETAIL_MODEL_IDENTIFIER =
        "idProcedureDetailModel";


    /**
     * Identifiant champ json de l'identifiant de procédure.
     */
    public static final String JSON_PROCEDURE_IDENTIFIER =
        "idProcedure";

  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ProcedureDetailModelGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcedureDetailModelDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcedureDetailModelDto> datas;
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ProcedureDetailModelUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ProcedureDetailModelSaveRequestDto {

    @JsonbProperty(JSON_PROCEDURE_MODEL_IDENTIFIER)
    private String procedureModelIdentifier;

    @JsonbProperty(JSON_ORDER)
    private Integer order;

    @JsonbProperty(JSON_DETAIL_DATE)
    private Date detailDate;
  }
}

