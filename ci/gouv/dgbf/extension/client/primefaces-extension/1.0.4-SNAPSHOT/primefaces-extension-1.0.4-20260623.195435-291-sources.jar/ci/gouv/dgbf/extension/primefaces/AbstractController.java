package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.UriBuilder;
import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Arrays;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'un contrôleur.
 *
 * @author Christian
 *
 */
public abstract class AbstractController {

  @Getter
  @Setter
  protected String name;

  @Inject
  protected UserSession userSession;

  @Getter
  protected String userIdentifier;

  @Getter
  protected String requestParameterIdentifierName;

  @Getter
  protected String requestParameterRedirectUrlValue;

  @Inject
  protected RequestManager requestManager;

  @PostConstruct
  void listenPostConstruct() {
    postConstruct();
  }

  protected void postConstruct() {
    userIdentifier = computeUserIdentifier();
    requestParameterIdentifierName = "identifiant";
    setRequestParameterRedirectUrlValue();
  }

  protected String computeUserIdentifier() {
    return userSession.getUserIdentifier();
  }

  protected void setRequestParameterRedirectUrlValue() {
    requestParameterRedirectUrlValue =
        requestManager == null ? null : requestManager.getParameterRedirectUrl();
  }

  protected Set<String> getRequestParameterValues(String key) {
    return Optional
        .ofNullable(FacesContext.getCurrentInstance().getExternalContext()
            .getRequestParameterValuesMap().get(key))
        .map(array -> Arrays.stream(array).collect(Collectors.toSet()))
        .orElse(Constant.EMPTY_STRINGS_LINKED_HASH_SET);
  }

  protected Set<String> getRequestParameterValuesOrNullIfEmpty(String key) {
    Set<String> set = getRequestParameterValues(key);
    if (CollectionCore.isEmpty(set)) {
      return null;
    }
    return set;
  }

  protected String getRequestParameter(String key) {
    return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(key);
  }

  protected String getRequestParameterIdentifier() {
    return getRequestParameter(requestParameterIdentifierName);
  }
  
  protected Boolean getRequestParameterAsBoolean(String key) {
    return Core.getBooleanFromString(getRequestParameter(key));
  }

  protected boolean redirectIfUrlNotBlank() {
    if (Core.isStringBlank(requestParameterRedirectUrlValue)) {
      return false;
    }
    navigateByUrl(requestParameterRedirectUrlValue);
    return true;
  }

  protected boolean navigateByUrl(String url) {
    if (Core.isStringBlank(url)) {
      return false;
    }
    NavigationManager.navigateByUrl(url);
    return true;
  }

  protected String buildRequestRelativeUrl() {
    return new UriBuilder().relativeFromRequest(
        (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest())
        .build().toString();
  }

  protected boolean isUserInRole(Object role) {
    return User.hasRole(userSession.getUser(), role);
  }

  protected boolean isUserInAtLeastOneOfRoles(Object[] roles) {
    return User.hasAtLeastOneOfRoles(userSession.getUser(), roles);
  }
}
