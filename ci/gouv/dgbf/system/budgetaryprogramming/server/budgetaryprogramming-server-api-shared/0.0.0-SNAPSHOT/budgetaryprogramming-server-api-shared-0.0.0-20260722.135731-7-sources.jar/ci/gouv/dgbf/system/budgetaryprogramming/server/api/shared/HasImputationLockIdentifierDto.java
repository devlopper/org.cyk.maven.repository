package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de verrou d'imputation.
 *
 * @author Christian
 */
public interface HasImputationLockIdentifierDto extends HasImputationLockIdentifier {

  /**
   * Identifiant json de l'identifiant du verrou d'imputation.
   */
  String JSON_IMPUTATION_LOCK_IDENTIFIER = "idVerrouImputation";
}