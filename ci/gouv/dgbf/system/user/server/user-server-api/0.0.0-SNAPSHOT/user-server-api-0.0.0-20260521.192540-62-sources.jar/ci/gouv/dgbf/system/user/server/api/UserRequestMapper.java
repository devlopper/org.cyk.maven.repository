package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateAccountRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UserDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link UserDto}.

    @author Christian
               """)
public interface UserRequestMapper
    extends RequestMapper<UserDto, UserCreateRequestDto, UserUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link UserCreateAccountRequestDto}.
   *
   * @param user {@link UserDto}.
   * @return {@link UserCreateAccountRequestDto}
   */
  UserCreateAccountRequestDto mapCreateAccount(UserDto user);
  
}
