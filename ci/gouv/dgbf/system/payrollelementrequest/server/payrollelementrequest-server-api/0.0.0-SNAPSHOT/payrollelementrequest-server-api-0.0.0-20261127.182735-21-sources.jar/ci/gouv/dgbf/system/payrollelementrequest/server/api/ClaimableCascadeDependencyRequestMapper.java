package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeDependencyService.ClaimableCascadeDependencyUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimableCascadeDependencyDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimableCascadeDependencyDto}.

    @author akm
               """)
public interface ClaimableCascadeDependencyRequestMapper extends
    RequestMapper<ClaimableCascadeDependencyDto, ClaimableCascadeDependencyCreateRequestDto,
        ClaimableCascadeDependencyUpdateRequestDto> {

}
