package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie d'employé.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EmployeeCategoryDto extends AbstractIdentifiableCodableNamableDto {
  
  /**
   * Identifiant json de identifiant de {@link EmployeeCategoryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCategorieEmploye";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link EmployeeCategoryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "categorieEmployeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie d'employé";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories d'employé";
}
