package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche de l'historique des états d'un dossier.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class BudgetAdministrativeUnitHistoryFilter extends AbstractIdentifiableFilter {

  /**
   * Dossier dont on veut l'historique.
   */
  String dossierIdentifier;

  /**
   * Code {@link BudgetAdministrativeUnitStatus} atteint.
   */
  String statusCode;

  public BudgetAdministrativeUnitHistoryFilter() {
    super();
  }

  public BudgetAdministrativeUnitHistoryFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setDossierIdentifier(read(filter,
        BudgetAdministrativeUnitHistoryDto.JSON_DOSSIER_IDENTIFIER));
    setStatusCode(read(filter, BudgetAdministrativeUnitHistoryDto.JSON_STATUS_CODE));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter,
        BudgetAdministrativeUnitHistoryDto.JSON_DOSSIER_IDENTIFIER,
        getDossierIdentifier());
    write(filter, BudgetAdministrativeUnitHistoryDto.JSON_STATUS_CODE, getStatusCode());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats, sous la forme
   * {@code dto -> BudgetAdministrativeUnitHistoryFilter.read(dto, clé)}.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
