package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PartitionDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-14T17:33:09+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PartitionRequestMapperImpl implements PartitionRequestMapper {

    @Override
    public PartitionService.PartitionCreateRequestDto mapCreate(PartitionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionService.PartitionCreateRequestDto partitionCreateRequestDto = new PartitionService.PartitionCreateRequestDto();

        partitionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        partitionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        partitionCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        partitionCreateRequestDto.setValueIdentifier( arg0.getValueIdentifier() );

        return partitionCreateRequestDto;
    }

    @Override
    public PartitionService.PartitionUpdateRequestDto mapUpdate(PartitionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionService.PartitionUpdateRequestDto partitionUpdateRequestDto = new PartitionService.PartitionUpdateRequestDto();

        partitionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        partitionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        partitionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        partitionUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        partitionUpdateRequestDto.setValueIdentifier( arg0.getValueIdentifier() );

        return partitionUpdateRequestDto;
    }
}
