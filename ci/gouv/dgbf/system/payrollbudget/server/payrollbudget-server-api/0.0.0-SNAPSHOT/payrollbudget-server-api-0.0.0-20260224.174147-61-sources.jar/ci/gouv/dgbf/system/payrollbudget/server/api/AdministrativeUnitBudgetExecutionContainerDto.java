package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette interface représente un Dto de conteneur de {@link AdministrativeUnitBudgetExecutionDto}.
 *
 * @author parfait
 */
public interface AdministrativeUnitBudgetExecutionContainerDto 
        extends AdministrativeUnitBudgetExecutionContainer {
    
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#mandateAmountAsString}.
   */
  String JSON_MANDATE_AMOUNT_AS_STRING = "montantMandatChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#mandateAmountPrecedentAsString}.
   */
  String JSON_MANDATE_AMOUNT_PRECEDENT_AS_STRING = 
      "montantMandatPreceddentChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#initialBudgetAsString}.
   */
  String JSON_INITIAL_BUDGET_AS_STRING = "budgetInitialChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#initialBudgetPrecedentAsString}.
   */
  String JSON_INITIAL_BUDGET_PRECEDENT_AS_STRING = 
      "budgetInitialPrecedentChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#actualBudgetAsString}.
   */
  String JSON_ACTUAL_BUDGET_AS_STRING = "budgetActuelChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#actualBudgetPrecedentAsString}.
   */
  String JSON_ACTUAL_BUDGET_PRECEDENT_AS_STRING = "budgetActuelPrecedentChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#remainingExecutedBudgetAsString}.
   */
  String JSON_REMAINING_EXECUTED_BUDGET_AS_STRING = "resteBudgetExecute";
  
  /**
   * Identifiant json 
   * {@link AdministrativeUnitBudgetExecutionDto#remainingExecutedBudgetPrecedentAsString}.
   */
  String JSON_REMAINING_EXECUTED_BUDGET_PRECEDENT_AS_STRING = 
      "resteBudgetPrecedentExecute";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#referenceAmount}.
   */
  String JSON_REFERENCE_AMOUNT = "montantReference";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#referenceAmountAsString}.
   */
  String JSON_REFERENCE_AMOUNT_AS_STRING = "montantReferenceChaine";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#amountVariation}.
   */
  String JSON_AMOUNT_VARIANCE = "variation";
  
  /**
   * Identifiant json {@link AdministrativeUnitBudgetExecutionDto#amountVariationAsString}.
   */
  String JSON_AMOUNT_VARIANCE_AS_STRING = "variationChaine";
  
  /**
   * Identifiant json du montant.
   */
  String JSON_AMOUNT = "montant";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du montant.
   */
  String JSON_AMOUNT_AS_STRING = "montantChaine";

}
