package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcedureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-03T19:56:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcedureRequestMapperImpl implements ProcedureRequestMapper {

    @Override
    public ProcedureService.ProcedureCreateRequestDto mapCreate(ProcedureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureService.ProcedureCreateRequestDto procedureCreateRequestDto = new ProcedureService.ProcedureCreateRequestDto();

        procedureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureCreateRequestDto.setName( arg0.getName() );
        procedureCreateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        procedureCreateRequestDto.setOrder( arg0.getOrder() );
        procedureCreateRequestDto.setDate( arg0.getDate() );
        procedureCreateRequestDto.setObservation( arg0.getObservation() );

        return procedureCreateRequestDto;
    }

    @Override
    public ProcedureService.ProcedureUpdateRequestDto mapUpdate(ProcedureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureService.ProcedureUpdateRequestDto procedureUpdateRequestDto = new ProcedureService.ProcedureUpdateRequestDto();

        procedureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        procedureUpdateRequestDto.setName( arg0.getName() );
        procedureUpdateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        procedureUpdateRequestDto.setOrder( arg0.getOrder() );
        procedureUpdateRequestDto.setDate( arg0.getDate() );
        procedureUpdateRequestDto.setObservation( arg0.getObservation() );

        return procedureUpdateRequestDto;
    }
}
