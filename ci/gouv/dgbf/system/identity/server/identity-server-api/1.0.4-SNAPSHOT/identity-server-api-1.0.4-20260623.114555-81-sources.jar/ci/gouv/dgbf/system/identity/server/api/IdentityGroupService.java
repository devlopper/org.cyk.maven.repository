package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IdentityGroupDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = IdentityGroupService.PATH)
@Tag(name = "Gestion des identités de groupe")
public interface IdentityGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "identites-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_IDENTITE_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un identité de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une identité de groupe",
      description = "Ce service permet de créer une identité de groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IdentityGroupCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface IdentityGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentityDto}.
     *
     * @return identifiant de {@link IdentityDto}
     */
    String getIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link IdentityDto}.
     *
     * @param identityIdentifier identifiant de {@link IdentityDto}
     */
    void setIdentityIdentifier(String identityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentitiesGroupDto}.
     *
     * @return identifiant de {@link IdentitiesGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de @link IdentitiesGroupDto}.
     *
     * @param groupIdentifier identifiant de @link IdentitiesGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'odre de mise à jour des identifiants de
     * {@link RoleDto}.
     *
     * @return odre de mise à jour des identifiants de {@link RoleDto}
     */
    Boolean getUpdateRolesIdentifiers();

    /**
     * Cette méthode permet d'assigner l'odre de mise à jour des identifiants de
     * {@link RoleDto}.
     *
     * @param updateRolesIdentifiers odre de mise à jour des identifiants de
     *        {@link RoleDto}
     */
    void setUpdateRolesIdentifiers(Boolean updateRolesIdentifiers);

    /**
     * Cette méthode permet d'obtenir les identifiants de {@link RoleDto}.
     *
     * @return identifiants de {@link RoleDto}
     */
    Set<String> getRolesIdentifiers();

    /**
     * Cette méthode permet d'assigner les identifiants de @link FileCategoryDto}.
     *
     * @param rolesIdentifiers identifiants de @link FileCategoryDto}
     */
    void setRolesIdentifiers(Set<String> rolesIdentifiers);
    
    /**
     * {@link IdentityGroupDto#JSON_IDENTITY_IDENTIFIER}.
     */
    String JSON_IDENTITY_IDENTIFIER = IdentityGroupDto.JSON_IDENTITY_IDENTIFIER;

    /**
     * {@link IdentityGroupDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = IdentityGroupDto.JSON_GROUP_IDENTIFIER;
    
    /**
     * {@link IdentityGroupDto#JSON_ROLES_IDENTIFIERS}.
     */
    String JSON_ROLES_IDENTIFIERS = IdentityGroupDto.JSON_ROLES_IDENTIFIERS;

    /**
     * {@link IdentityGroupDto#JSON_UPDATE_ROLES_IDENTIFIERS}.
     */
    String JSON_UPDATE_ROLES_IDENTIFIERS = IdentityGroupDto.JSON_UPDATE_ROLES_IDENTIFIERS;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityGroupCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements IdentityGroupSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;
    
    @JsonbProperty(JSON_ROLES_IDENTIFIERS)
    private Set<String> rolesIdentifiers;

    @JsonbProperty(JSON_UPDATE_ROLES_IDENTIFIERS)
    private Boolean updateRolesIdentifiers;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IDENTITE_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des identités de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class IdentityGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentityGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentityGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_IDENTITE_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une identité de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IDENTITE_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link IdentityGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_IDENTITE_GROUPE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentityGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IdentityGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityGroupUpdateRequestDto extends ByIdentifierRequestDto
      implements IdentityGroupSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;
    
    @JsonbProperty(JSON_ROLES_IDENTIFIERS)
    private Set<String> rolesIdentifiers;

    @JsonbProperty(JSON_UPDATE_ROLES_IDENTIFIERS)
    private Boolean updateRolesIdentifiers;
  }

  /**
   * Identifiant du service de mise à jour les {@link RoleDto}.
   */
  String UPDATE_ROLES_IDENTIFIER = "MISE_A_JOUR_ROLES_IDENTITE_GROUPE";

  /**
   * Chemin du service de mise à jour les {@link RoleDto}.
   */
  String UPDATE_ROLES_PATH = "roles";

  /**
   * Cette méthode permet de mettre à jour les {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_ROLES_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_ROLES_IDENTIFIER,
      description = "Ce service permet de mettre à jour les rôles d'une identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateRoles(IdentityGroupUpdateRolesRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityGroupUpdateRolesRequestDto extends ByIdentifierRequestDto {
    /**
     * Identifiants {@link RoleDto}.
     */
    @JsonbProperty(JSON_ROLES_IDENTIFIERS)
    private Set<String> rolesIdentifiers;

    /**
     * {@link IdentityGroupDto#JSON_ROLES_IDENTIFIERS}.
     */
    public static final String JSON_ROLES_IDENTIFIERS = IdentityGroupDto.JSON_ROLES_IDENTIFIERS;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_IDENTITE_GROUPE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une identité de groupe")
  Response delete(DeleteOneRequestDto request);
}
