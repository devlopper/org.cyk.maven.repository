package ci.gouv.dgbf.system.user.server.api;

/**
 * Cette classe représente les codes de {@link RoleSolicitationStatus}.
 *
 * @author BoobaCool
 */
public class RoleSolicitationStatusCode {

  private RoleSolicitationStatusCode() {

  }

  /**
   * Créée.
   */
  public static final String CREATED = "CREEE";

  /**
   * Acceptée.
   */
  public static final String ACCEPTED = "ACCEPTEE";

  /**
   * Refusée.
   */
  public static final String REFUSED = "REFUSEE";

  /**
   * Annulée.
   */
  public static final String CANCELLED = "ANNULEE";
}
