package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une ressource.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceDto extends AbstractResourceOrReceiverDto {
  
  /**
   * {@link ResourceType}.
   */
  @JsonbProperty(JSON_TYPE)
  private ResourceType type;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ressource";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
