package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les groupes de type de document.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentTypeGroupFilter extends AbstractIdentifiableFilter
    implements HasGroupIdentifier {

  /**
   * Identifiant du groupe de types de document ({@link DocumentTypesGroupDto}) auquel le type de
   * document est rattaché.
   */
  String groupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DocumentTypeGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DocumentTypeGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de types de document.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant du groupe de types de document
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de types de document -- sans elle, le
   * critère envoyé par le client (ex. {@code DocumentGroupExpectedDocumentController.refresh})
   * serait silencieusement ignoré : {@code DocumentTypeGroupClient.getMany(...)} retournerait
   * tous les rattachements type/groupe, et non les seuls types attendus du groupe de types
   * sélectionné.
   *
   * @param filter filtre
   * @return identifiant du groupe de types de document
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;
}
