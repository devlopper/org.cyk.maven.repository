package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une adresse email.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EmailAddressDto extends AbstractIdentifiableDto implements HasValueDto<String> {

  @JsonbProperty(JSON_VALUE)
  private String value;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "adresse email";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "adresses email";
}
