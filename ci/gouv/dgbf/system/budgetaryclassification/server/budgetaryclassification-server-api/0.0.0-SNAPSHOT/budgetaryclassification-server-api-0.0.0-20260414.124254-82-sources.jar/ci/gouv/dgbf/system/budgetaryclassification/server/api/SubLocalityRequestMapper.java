package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubLocalityService.SubLocalityCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubLocalityService.SubLocalityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SubLocalityDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SubLocalityDto}.

    @author stephane
               """)
public interface SubLocalityRequestMapper extends RequestMapper<SubLocalityDto,
    SubLocalityCreateRequestDto, SubLocalityUpdateRequestDto> {

}
