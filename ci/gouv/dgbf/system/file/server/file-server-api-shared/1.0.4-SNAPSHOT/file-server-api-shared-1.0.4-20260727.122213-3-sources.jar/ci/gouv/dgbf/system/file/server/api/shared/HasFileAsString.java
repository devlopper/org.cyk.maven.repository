package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * fichier.
 *
 * @author Christian
 */
public interface HasFileAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du de fichier.
   *
   * @return représentation en chaine de caractères du de fichier
   */
  String getFilesAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du fichier.
   *
   * @param asString représentation en chaine de caractères du de fichier
   */
  void setFilesAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du de fichier.
   */
  String FIELD_FILE_AS_STRING = "filesAsString";
}
