package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une activité de {@link TriennialProgramDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TriennialProgramActivityDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;

  /**
   * Représentation en chaine de caractères de {@link FunctionalAccountDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_AS_STRING)
  private String functionalAccountAsString;

  /**
   * Représentation en chaine de caractères de {@link FunctionalAccountDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_CODE)
  private String functionalAccountCode;


  /**
   * Représentation en chaine de caractères de {@link ActivityNatureDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_NATURE_AS_STRING)
  private String activityNatureAsString;

  /**
   * Code de {@link ActivityNatureDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_NATURE_CODE)
  private String activityNatureCode;

  /**
   * Représentation en chaine de caractères de date de creation.
   */
  @JsonbProperty(JSON_CREATION_DATE_AS_STRING)
  private String creationDateAsString;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_CODE)
  private String localAuthorityCode;

  /**
   * Année de {@link ExerciseDto} de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_EXERCISE_YEAR)
  private Integer triennialProgramExerciseYear;

  /**
   * Identifiant {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;


  /**
   * Identifiant {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_CODE)
  private String activityCode;

  /**
   * Représentation en chaine de caractères de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * {@link ActivityCategory}.
   */
  @JsonbProperty(JSON_ACTIVITY_CATEGORY)
  private ActivityCategory activityCategoryEnum;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Long amount;

  /**
   * Représentation en chaine de caractères de Montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;

  /**
   * Montants des {@link FundingDto} modifiable.
   */
  @JsonbProperty(JSON_FUNDINGS_AMOUNTS_UPDATABLE)
  private Boolean fundingsAmountsUpdatable;

  /**
   * Représentation en chaine de caractères du nombre de {@link FundingDto}.
   */
  @JsonbProperty(JSON_FUNDING_COUNT_AS_STRING)
  private String fundingCountAsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT1_AS_STRING)
  private String totalFundingAmount1AsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT2_AS_STRING)
  private String totalFundingAmount2AsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT3_AS_STRING)
  private String totalFundingAmount3AsString;


  /**
   * Représentation en chaine de caractères la somme des totaux des financements
   * des années n, n+1 et n+2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT_AS_STRING)
  private String totalFundingAmountAsString;

  /**
   * Représentation en chaine de caractères du total des moyens de financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_AMOUNT1_AS_STRING)
  private String totalFundingTypeAmount1AsString;

  /**
   * Représentation en chaine de caractères du total des moyens de financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_AMOUNT2_AS_STRING)
  private String totalFundingTypeAmount2AsString;

  /**
   * Représentation en chaine de caractères du total des moyens de financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_AMOUNT3_AS_STRING)
  private String totalFundingTypeAmount3AsString;

  /**
   * Total des montants prévus des types de financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT1)
  private Long totalFundingTypePlannedAmount1;

  /**
   * Total des montants prévus des types de financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT2)
  private Long totalFundingTypePlannedAmount2;

  /**
   * Total des montants prévus des types de financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT3)
  private Long totalFundingTypePlannedAmount3;

  /**
   * Total des montants utilisés des types de financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT1)
  private Long totalFundingTypeUsedAmount1;

  /**
   * Représentation en chaine de caractères du total des montants utilisés des types de
   * financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT1_AS_STRING)
  private String totalFundingTypeUsedAmount1AsString;

  /**
   * Total des montants utilisés des types de financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT2)
  private Long totalFundingTypeUsedAmount2;

  /**
   * Représentation en chaine de caractères du total des montants utilisés des types de
   * financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT2_AS_STRING)
  private String totalFundingTypeUsedAmount2AsString;

  /**
   * Total des montants utilisés des types de financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT3)
  private Long totalFundingTypeUsedAmount3;

  /**
   * Représentation en chaine de caractères du total des montants utilisés des types de
   * financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT3_AS_STRING)
  private String totalFundingTypeUsedAmount3AsString;

  /**
   * Total des montants restants des types de financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT1)
  private Long totalFundingTypeRemainingAmount1;

  /**
   * Représentation en chaine de caractères du total des montants restants des types de
   * financement en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT1_AS_STRING)
  private String totalFundingTypeRemainingAmount1AsString;

  /**
   * Total des montants restants des types de financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT2)
  private Long totalFundingTypeRemainingAmount2;

  /**
   * Représentation en chaine de caractères du total des montants restants des types de
   * financement en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT2_AS_STRING)
  private String totalFundingTypeRemainingAmount2AsString;

  /**
   * Total des montants restants des types de financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT3)
  private Long totalFundingTypeRemainingAmount3;

  /**
   * Représentation en chaine de caractères du total des montants restants des types de
   * financement en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT3_AS_STRING)
  private String totalFundingTypeRemainingAmount3AsString;

  /**
   * Commentaires des {@link FundingDto} modifiable.
   */
  @JsonbProperty(JSON_FUNDINGS_COMMENTS_UPDATABLE)
  private Boolean fundingsCommentsUpdatable;

  /**
   * Justification.
   */
  @JsonbProperty(JSON_JUSTIFICATION)
  private String justification;

  /**
   * Priorité.
   */
  @JsonbProperty(JSON_PRIORITY)
  private Integer priority;

  /**
   * Représentation en chaine de caractères de la priorité.
   */
  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;


  /**
   * Montant exécuté.
   */
  @JsonbProperty(JSON_EXECUTED_AMOUNT)
  private Long executedAmount;

  /**
   * Représentation en chaine de caractères du montant exécuté.
   */
  @JsonbProperty(JSON_EXECUTED_AMOUNT_AS_STRING)
  private String executedAmountAsString;


  /**
   * Montant restant.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT)
  private Long remainingAmount;

  /**
   * Représentation en chaine de caractères du montant restant.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_AS_STRING)
  private String remainingAmountAsString;


  /**
   * Identifiant json de identifiant de {@link TriennialProgramActivityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idActiviteProgrammeTriennal";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link TriennialProgramActivityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "activiteProgrammeTriennalChaine";

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER = "idProgrammeTriennal";

  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING = "programmeTriennalChaine";

  /**
   * Identifiant json {@link #triennialProgramExerciseYear}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_EXERCISE_YEAR =
      "anneeExerciceProgrammeTriennal";

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_CODE = "codeCollectivite";

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant json {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = "idActivite";

  /**
   * Identifiant json {@link #activityCode}.
   */
  public static final String JSON_ACTIVITY_CODE = "codeActivite";

  /**
   * Identifiant json {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = "activiteChaine";

  /**
   * Identifiant json {@link ActivityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = "categorieActivite";

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Identifiant json {@link #fundingsAmountsUpdatable}.
   */
  public static final String JSON_FUNDINGS_AMOUNTS_UPDATABLE = "montantsFinancementsModifiable";

  /**
   * Identifiant json champ {@link #fundingCountAsString}.
   */
  public static final String JSON_FUNDING_COUNT_AS_STRING = "nombreFinancementChaine";

  /**
   * Format des identifiants json des champs de montants.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT_AS_STRING_FORMAT =
      "totalFinancementMontant%sChaine";

  /**
   * Identifiant json champ {@link #totalFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT1_AS_STRING =
      "totalFinancementMontant1Chaine";

  /**
   * Identifiant json champ {@link #totalFundingAmount2AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT2_AS_STRING =
      "totalFinancementMontant2Chaine";

  /**
   * Identifiant json champ {@link #totalFundingAmount3AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT3_AS_STRING =
      "totalFinancementMontant3Chaine";


  /**
   * Identifiant json champ {@link #totalFundingAmountAsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT_AS_STRING =
      "totalMontantFinancementChaine";

  /**
   * Format des identifiants json des champs de montants des moyens de financement.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_AMOUNT_AS_STRING_FORMAT =
      "totalMoyenFinancementMontant%sChaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeAmount1AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_AMOUNT1_AS_STRING =
      "totalMoyenFinancementMontant1Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeAmount2AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_AMOUNT2_AS_STRING =
      "totalMoyenFinancementMontant2Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeAmount3AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_AMOUNT3_AS_STRING =
      "totalMoyenFinancementMontant3Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypePlannedAmount1}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT1 =
      "totalTypeFinancementMontantPrevu1";

  /**
   * Identifiant json champ {@link #totalFundingTypePlannedAmount2}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT2 =
      "totalTypeFinancementMontantPrevu2";

  /**
   * Identifiant json champ {@link #totalFundingTypePlannedAmount3}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_PLANNED_AMOUNT3 =
      "totalTypeFinancementMontantPrevu3";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount1}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT1 =
      "totalTypeFinancementMontantUtilise1";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount1AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT1_AS_STRING =
      "totalTypeFinancementMontantUtilise1Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount2}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT2 =
      "totalTypeFinancementMontantUtilise2";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount2AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT2_AS_STRING =
      "totalTypeFinancementMontantUtilise2Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount3}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT3 =
      "totalTypeFinancementMontantUtilise3";

  /**
   * Identifiant json champ {@link #totalFundingTypeUsedAmount3AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_USED_AMOUNT3_AS_STRING =
      "totalTypeFinancementMontantUtilise3Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount1}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT1 =
      "totalTypeFinancementMontantRestant1";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount1AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT1_AS_STRING =
      "totalTypeFinancementMontantRestant1Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount2}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT2 =
      "totalTypeFinancementMontantRestant2";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount2AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT2_AS_STRING =
      "totalTypeFinancementMontantRestant2Chaine";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount3}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT3 =
      "totalTypeFinancementMontantRestant3";

  /**
   * Identifiant json champ {@link #totalFundingTypeRemainingAmount3AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_TYPE_REMAINING_AMOUNT3_AS_STRING =
      "totalTypeFinancementMontantRestant3Chaine";

  /**
   * Identifiant json {@link #fundingsCommentsUpdatable}.
   */
  public static final String JSON_FUNDINGS_COMMENTS_UPDATABLE =
      "commentairesFinancementsModifiable";

  /**
   * Identifiant json {@link #justification}.
   */
  public static final String JSON_JUSTIFICATION = "justification";

  /**
   * Identifiant json {@link #priority}.
   */
  public static final String JSON_PRIORITY = "priorite";

  /**
   * Identifiant json {@link #priorityAsString}.
   */
  public static final String JSON_PRIORITY_AS_STRING = "prioriteChaine";



  /**
   * Identifiant json {@link #executedAmount}.
   */
  public static final String JSON_EXECUTED_AMOUNT = "montantExecute";

  /**
   * Identifiant json {@link #executedAmountAsString}.
   */
  public static final String JSON_EXECUTED_AMOUNT_AS_STRING = "montantExecuteChaine";

  /**
   * Identifiant json {@link #remainingAmount}.
   */
  public static final String JSON_REMAINING_AMOUNT = "montantRestant";

  /**
   * Identifiant json {@link #remainingAmountAsString}.
   */
  public static final String JSON_REMAINING_AMOUNT_AS_STRING = "montantRestantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "activité de programme triennal";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "activités de programme triennal";

  /**
   * Identifiant json {@link #functionalAccountAsString}.
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_AS_STRING = "compteFonctionnelChaine";

  /**
   * Identifiant json {@link #functionalAccountCode}..
   */
  public static final String JSON_FUNCTIONAL_ACCOUNT_CODE = "codeCompteFonctionnel";

  /**
   * Identifiant json {@link #activityNatureAsString}.
   */
  public static final String JSON_ACTIVITY_NATURE_AS_STRING = "natureActiviteChaine";

  /**
   * Identifiant json {@link #activityNatureCode}.
   */
  public static final String JSON_ACTIVITY_NATURE_CODE = "codeNatureActivite";

  /**
   * Identifiant json {@link #creationDateAsString}.
   */
  public static final String JSON_CREATION_DATE_AS_STRING = "dateCreationChaine";
}
