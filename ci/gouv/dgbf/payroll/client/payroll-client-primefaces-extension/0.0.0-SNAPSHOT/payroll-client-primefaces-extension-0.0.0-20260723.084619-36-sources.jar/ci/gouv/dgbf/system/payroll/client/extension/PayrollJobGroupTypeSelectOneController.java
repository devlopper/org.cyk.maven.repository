package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollJobGroupTypeDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PayrollJobGroupTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollJobGroupTypeDto, PayrollJobGroupTypeGetManyResponseDto, PayrollJobGroupTypeClient> {

  @Inject
  @Getter
  PayrollJobGroupTypeClient client;

  protected PayrollJobGroupTypeSelectOneController() {
    super(PayrollJobGroupTypeDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
