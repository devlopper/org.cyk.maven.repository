package ci.gouv.dgbf.extension.server.service.impl;

import ci.gouv.dgbf.extension.core.throwable.ThrowableHelper;
import ci.gouv.dgbf.extension.server.business.BusinessInputValidationException;
import ci.gouv.dgbf.extension.server.service.api.ClientRuntimeException;
import jakarta.inject.Inject;
import jakarta.persistence.LockTimeoutException;
import jakarta.persistence.NoResultException;
import jakarta.persistence.PessimisticLockException;
import jakarta.ws.rs.BadRequestException;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.ext.ExceptionMapper;
import jakarta.ws.rs.ext.Provider;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente l'intercepteur des exceptions de type RuntimeException.
 *
 * @author Christian
 *
 */
@Provider
public class RuntimeExceptionMapper implements ExceptionMapper<RuntimeException> {
  private static final Logger LOGGER = Logger.getLogger(RuntimeExceptionMapper.class.getName());

  /**
   * Message rendu quand le verrou d'un enregistrement n'a pas pu être obtenu (attente expirée ou
   * interblocage) : l'erreur reste technique (500), mais l'appelant apprend qu'un nouvel essai
   * suffit, au lieu de recevoir la requête SQL qui a échoué.
   */
  static final String LOCK_UNAVAILABLE_MESSAGE = "Une autre opération est en cours sur cet "
      + "élément (verrou indisponible) : réessayez dans quelques instants";

  @Inject
  ThrowableHelper throwableHelper;

  ThrowableHelper throwableHelper() {
    if (throwableHelper == null) {
      throwableHelper = new ThrowableHelper();
    }
    return throwableHelper;
  }

  @Override
  public Response toResponse(RuntimeException exception) {
    String message = computeMessage(exception);
    int statusCode;
    if (exception instanceof BadRequestException
        || exception instanceof BusinessInputValidationException) {
      statusCode = Response.Status.BAD_REQUEST.getStatusCode();
    } else if (exception instanceof NoResultException) {
      statusCode = Response.Status.NOT_FOUND.getStatusCode();
    } else if (exception instanceof ClientRuntimeException clientRuntimeException) {
      statusCode = clientRuntimeException.getResponseCode();
    } else {
      statusCode = Response.Status.INTERNAL_SERVER_ERROR.getStatusCode();
      /*
       * Les erreurs internes doivent être complètement logger afin de faciliter de débogage.
       */
      exception.printStackTrace();
    }
    Response response = Response.status(statusCode).entity(message).build();
    LOGGER.log(Level.FINEST,
        "Réponse de mappage de l''exception générée. exception={0}"
            + ", réponse | code={1}, message={2}",
        new Object[] {exception.getMessage(), statusCode, message});
    return response;
  }

  /**
   * Cette méthode permet d'obtenir le message de la réponse.
   *
   * @param exception exception
   * @return message lisible ; celui du verrou indisponible si la chaîne des causes en contient un
   */
  String computeMessage(RuntimeException exception) {
    if (isLockUnavailable(exception)) {
      return LOCK_UNAVAILABLE_MESSAGE;
    }
    return throwableHelper().getMessage(exception, Boolean.TRUE);
  }

  /**
   * Cette méthode permet de savoir si l'exception, ou l'une de ses causes, signale un verrou
   * indisponible : Hibernate les traduit en exceptions JPA quelle que soit la base (Oracle, H2...).
   *
   * @param throwable exception
   * @return vrai si un verrou n'a pas pu être obtenu
   */
  static boolean isLockUnavailable(Throwable throwable) {
    for (Throwable cause = throwable; cause != null; cause = cause.getCause()) {
      if (cause instanceof LockTimeoutException || cause instanceof PessimisticLockException) {
        return true;
      }
    }
    return false;
  }
}
