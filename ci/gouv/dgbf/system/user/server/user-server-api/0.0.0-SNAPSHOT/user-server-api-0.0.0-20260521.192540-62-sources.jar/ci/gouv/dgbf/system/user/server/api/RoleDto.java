package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rôle.
 *
 * @author Arnaud
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RoleDto extends AbstractIdentifiableCodableNamableAuditableDto {


  @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
  private String applicationIdentifier;

  @JsonbProperty(JSON_APPLICATION_AS_STRING)
  private String applicationAsString;

  /**
   * Description.
   */
  @JsonbProperty(value = JSON_DESCRIPTION)
  private String description;

  /**
   * Identifiant de l'utilisateur pour les rôles NON assignés à cet utilisateur.
   * Utilisé pour obtenir les rôles disponibles pour attribution.
   */
  @JsonbProperty(value = JSON_UNASSIGNED_USER_IDENTIFIER)
  private String unassignedUserIdentifier;

  /**
   * Identifiant de l'utilisateur pour les rôles assignés à cet utilisateur.
   * Utilisé pour obtenir les rôles actuels de l'utilisateur.
   */
  @JsonbProperty(value = JSON_ASSIGNED_USER_IDENTIFIER)
  private String assignedUserIdentifier;

  /**
   * Identifiant json champ {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = ApplicationDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #applicationAsString}.
   */
  public static final String JSON_APPLICATION_AS_STRING = ApplicationDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #unassignedUserIdentifier}.
   */
  public static final String JSON_UNASSIGNED_USER_IDENTIFIER = "idUtilisateurNonAssigne";

  /**
   * Identifiant json {@link #assignedUserIdentifier}.
   */
  public static final String JSON_ASSIGNED_USER_IDENTIFIER = "idUtilisateurAssigne";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRole";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "roleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "role";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
