package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProcessDto}.
 *
 * @author Christian
 */
@Path(value = ProcessService.PATH)
@Tag(name = "Gestion des Processus")
public interface ProcessService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "processus";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProcessSaveRequestDto
      extends HasDescriptionDto, HasVisibleDto, HasModuleIdentifierDto {

    /**
     * Cette méthode permet d'obtenir la nature du processus.
     *
     * @return nature du processus
     */
    ProcessNature getNature();

    /**
     * Cette méthode permet d'assigner la nature du processus.
     *
     * @param nature nature du processus
     */
    void setNature(ProcessNature nature);

    /**
     * Cette méthode permet d'obtenir URL de base, adresse d'entrée du processus.
     *
     * @return URL de base, adresse d'entrée du processus
     */
    String getBaseUrl();

    /**
     * Cette méthode permet d'assigner URL de base, adresse d'entrée du processus.
     *
     * @param baseUrl URL de base, adresse d'entrée du processus
     */
    void setBaseUrl(String baseUrl);

    /**
     * Cette méthode permet d'obtenir l'accès public du processus : utilisable sans connexion et
     * présenté dans le Portail public (RG_SVC_VIS_04).
     *
     * @return accès public du processus
     */
    Boolean getPublicAccess();

    /**
     * Cette méthode permet d'assigner l'accès public du processus : utilisable sans connexion et
     * présenté dans le Portail public (RG_SVC_VIS_04).
     *
     * @param publicAccess accès public du processus
     */
    void setPublicAccess(Boolean publicAccess);

    /**
     * {@link ProcessDto#JSON_NATURE}.
     */
    String JSON_NATURE = ProcessDto.JSON_NATURE;

    /**
     * {@link ProcessDto#JSON_BASE_URL}.
     */
    String JSON_BASE_URL = ProcessDto.JSON_BASE_URL;

    /**
     * {@link ProcessDto#JSON_PUBLIC_ACCESS}.
     */
    String JSON_PUBLIC_ACCESS = ProcessDto.JSON_PUBLIC_ACCESS;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProcessDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_PROCESSUS";

  /**
   * Chemin du service de création unitaire de {@link ProcessDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProcessCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcessCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ProcessSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_NATURE)
    private ProcessNature nature;

    @JsonbProperty(JSON_BASE_URL)
    private String baseUrl;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_PUBLIC_ACCESS)
    private Boolean publicAccess;

    @JsonbProperty(JSON_MODULE_IDENTIFIER)
    private String moduleIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProcessDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROCESSUS";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProcessDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProcessGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcessDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcessDto> datas;
  }

  /**
   * Identifiant du service d'obtention du compte de {@link ProcessDto}.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_PROCESSUS";

  /**
   * Chemin du service d'obtention de compte de {@link ProcessDto}.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le compte de {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention unitaire de {@link ProcessDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PROCESSUS";

  /**
   * Chemin du service d'obtention unitaire de {@link ProcessDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProcessDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROCESSUS";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProcessDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProcessDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProcessDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROCESSUS";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProcessDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcessUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProcessDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcessUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ProcessSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_NATURE)
    private ProcessNature nature;

    @JsonbProperty(JSON_BASE_URL)
    private String baseUrl;

    @JsonbProperty(JSON_VISIBLE)
    private Boolean visible;

    @JsonbProperty(JSON_PUBLIC_ACCESS)
    private Boolean publicAccess;

    @JsonbProperty(JSON_MODULE_IDENTIFIER)
    private String moduleIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProcessDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROCESSUS";

  /**
   * Chemin du service de suppression unitaire de {@link ProcessDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProcessDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
