package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseIdentifierDto;
import ci.gouv.dgbf.system.datastructures.server.api.shared.HasPeriodIntervalAsStringDto;
import ci.gouv.dgbf.system.datastructures.server.api.shared.HasPeriodIntervalIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un exercice de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingExerciseDto extends AbstractIdentifiableAuditableDto
    implements HasExerciseIdentifierDto, HasExerciseAsStringDto, HasPeriodIntervalIdentifierDto,
    HasPeriodIntervalAsStringDto {

  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  @JsonbProperty(JSON_PERIOD_INTERVAL_IDENTIFIER)
  private String periodIntervalIdentifier;

  @JsonbProperty(JSON_PERIOD_INTERVAL_AS_STRING)
  private String periodIntervalAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idExerciceProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "exerciceProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exercice de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "exercices de programmation";

}
