package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSupportTeamAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSupportTeamIdentifierDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link SupportLevelDto} de {@link FunctionalDomainDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DomainLevelDto extends AbstractIdentifiableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasLevelIdentifierDto,
    HasLevelAsStringDto, HasSupportTeamIdentifierDto, HasSupportTeamAsStringDto,
    HasUsersGroupIdentifierDto, HasUsersGroupAsStringDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_LEVEL_IDENTIFIER)
  private String levelIdentifier;

  @JsonbProperty(JSON_LEVEL_AS_STRING)
  private String levelAsString;

  @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
  private String supportTeamIdentifier;

  @JsonbProperty(JSON_SUPPORT_TEAM_AS_STRING)
  private String supportTeamAsString;

  /**
   * Ancien identifiant du groupe d'utilisateurs, avant TCH_TK_556.
   *
   * @deprecated remplacé par {@link #supportTeamIdentifier}. Conservé pour ne pas casser la
   *             compilation de ticket-server-impl-quarkus/ticket-client-quarkus-primefaces tant
   *             qu'ils ne sont pas migrés.
   */
  @Deprecated
  @JsonbProperty(JSON_USERS_GROUP_IDENTIFIER)
  private String usersGroupIdentifier;

  /**
   * Ancienne représentation en chaine de caractères du groupe d'utilisateurs, avant TCH_TK_556.
   *
   * @deprecated remplacé par {@link #supportTeamAsString}. Conservé pour ne pas casser la
   *             compilation de ticket-server-impl-quarkus/ticket-client-quarkus-primefaces tant
   *             qu'ils ne sont pas migrés.
   */
  @Deprecated
  @JsonbProperty(JSON_USERS_GROUP_AS_STRING)
  private String usersGroupAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idNiveauDomaine";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "niveauDomaineChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "niveau de domaine";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "niveaux de domaine";

}

