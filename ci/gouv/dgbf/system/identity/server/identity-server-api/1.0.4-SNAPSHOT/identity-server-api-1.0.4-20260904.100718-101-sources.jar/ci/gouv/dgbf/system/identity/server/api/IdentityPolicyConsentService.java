package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasFrontEndBaseUriDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IdentityPolicyConsentDto}.
 *
 * @author Desysoft
 *
 */
@Path(value = IdentityPolicyConsentService.PATH)
@Tag(name = "Gestion des consentements aux politiques")
public interface IdentityPolicyConsentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "consentements";

  /**
   * Identifiant du service d'obtention de plusieurs {@link IdentityPolicyConsentDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONSENTEMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link IdentityPolicyConsentDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link IdentityPolicyConsentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs consentements")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link IdentityPolicyConsentDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  public static class IdentityPolicyConsentGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentityPolicyConsentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentityPolicyConsentDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link IdentityPolicyConsentDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_CONSENTEMENT";

  /**
   * Chemin du service d'obtention unitaire de {@link IdentityPolicyConsentDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link IdentityPolicyConsentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un consentement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityPolicyConsentDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link IdentityPolicyConsentDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONSENTEMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link IdentityPolicyConsentDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link IdentityPolicyConsentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un consentement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityPolicyConsentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de suppression unitaire de {@link IdentityPolicyConsentDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONSENTEMENT";

  /**
   * Chemin du service de suppression unitaire de {@link IdentityPolicyConsentDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link IdentityPolicyConsentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un consentement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'envoi de mail de demande de consentement.
   */
  String SEND_CONSENT_REQUEST_MAIL_IDENTIFIER = "ENVOI_MAIL_DEMANDE_CONSENTEMENT";

  /**
   * Chemin du service d'envoi de mail de demande de consentement.
   */
  String SEND_CONSENT_REQUEST_MAIL_PATH = "envoi-mail-demande-consentement";

  /**
   * Cette méthode permet d'envoyer un mail de demande de consentement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SEND_CONSENT_REQUEST_MAIL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SEND_CONSENT_REQUEST_MAIL_IDENTIFIER,
      description = "Ce service permet d'envoyer un mail de demande de consentement")
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = IdentityPolicyConsentSendConsentRequestMailResponseDto.class))})
  Response sendConsentRequestMail(IdentityPolicyConsentSendConsentRequestMailRequestDto request);

  /**
   * Cette classe représente la requête d'envoi de mail de demande de consentement.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentSendConsentRequestMailRequestDto
      extends AbstractAuditedRequestJsonDto
      implements HasIdentityIdentifierDto, HasFrontEndBaseUriDto {

    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER)
    private String policyVersionIdentifier;

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;
  }

  /**
   * Cette classe représente la réponse d'envoi de mail de demande de consentement.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentSendConsentRequestMailResponseDto extends IdentifiableResponseDto {

  }

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<IdentityPolicyConsentStatus> {

    @JsonbProperty(JSON_STATUS)
    private IdentityPolicyConsentStatus status;

    /**
     * Cette méthode permet d'initialiser la réponse à partir de
     * {@link IdentityPolicyConsentStatus}.
     *
     * @param status {@link IdentityPolicyConsentStatus}
     */
    public void initialize(IdentityPolicyConsentStatus status) {
      this.status = status;
    }
  }

  /**
   * Identifiant du service d'acceptation.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_CONSENTEMENT";

  /**
   * Chemin du service d'acceptation.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet d'accepter un consentement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ACCEPT_IDENTIFIER, description = "Ce service permet d'accepter")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentityPolicyConsentAcceptResponseDto.class))})
  Response accept(IdentityPolicyConsentAcceptRequestDto request);

  /**
   * Cette classe représente la requête d'acceptation.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentAcceptRequestDto extends AbstractAuditedRequestJsonDto
      implements HasIdentityIdentifierDto, HasFrontEndBaseUriDto {

    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER)
    private String policyVersionIdentifier;

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;
  }

  /**
   * Cette classe représente la réponse d'acceptation.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentAcceptResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de refus.
   */
  String REFUSE_IDENTIFIER = "REFUS_CONSENTEMENT";

  /**
   * Chemin du service de refus.
   */
  String REFUSE_PATH = "refus";

  /**
   * Cette méthode permet de refuser un consentement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REFUSE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REFUSE_IDENTIFIER, description = "Ce service permet de refuser")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentityPolicyConsentRefuseResponseDto.class))})
  Response refuse(IdentityPolicyConsentRefuseRequestDto request);

  /**
   * Cette classe représente la requête de refus.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentRefuseRequestDto extends AbstractAuditedRequestJsonDto
      implements HasIdentityIdentifierDto, HasFrontEndBaseUriDto {

    @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
    private String identityIdentifier;

    @JsonbProperty(IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER)
    private String policyVersionIdentifier;

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;
  }

  /**
   * Cette classe représente la réponse de refus.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class IdentityPolicyConsentRefuseResponseDto extends ProcessResponseDto {

  }
}
