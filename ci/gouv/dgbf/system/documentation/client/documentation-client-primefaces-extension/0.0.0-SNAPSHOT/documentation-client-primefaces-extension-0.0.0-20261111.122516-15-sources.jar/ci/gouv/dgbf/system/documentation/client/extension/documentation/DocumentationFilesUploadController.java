package ci.gouv.dgbf.system.documentation.client.extension.documentation;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationFilter;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationGetManyResponseDto;
import ci.gouv.dgbf.system.file.client.extension.file.FileViewerUriBuilder;
import ci.gouv.dgbf.system.file.client.extension.group.FileGroupController;
import ci.gouv.dgbf.system.file.client.extension.group.FilesGroupUploadController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le contrôleur de dépôt de fichiers rattachés à un enregistrement, à
 * l'usage des autres modules (ex. {@code Ticket}).
 *
 * <p>Le module hôte fournit le contexte métier (processus, source, enregistrement, opération) par
 * les setters, puis appelle {@link #initialize()} ; pour changer d'enregistrement, il pose le
 * nouveau contexte et rappelle {@link #initialize()}, faute de quoi les fichiers affichés restent
 * ceux de l'ancien contexte. Les fichiers sont portés par la
 * {@link DocumentationDto documentation} de ce contexte, créée au premier dépôt, et stockés dans
 * un groupe de fichiers du module {@code file}.
 *
 * <p>Le fragment associé est {@code /private/documentation/component/filesUpload.xhtml}, livré par
 * ce même module ; il est piloté par le {@code ui:param name="controller"} pointant vers une
 * instance de cette classe.
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentationFilesUploadController extends AbstractController {

  /**
   * Classe CSS portée par le conteneur du fragment.
   */
  public static final String PANEL_STYLE_CLASS = "documentation-files-panel";

  /**
   * Sélecteur PrimeFaces du panneau de dépôt, à utiliser comme cible de rafraîchissement ajax
   * ({@code update}) depuis le contrôleur de la page hôte.
   */
  public static final String PANEL_SELECTOR = "@(." + PANEL_STYLE_CLASS + ")";

  /**
   * Nom du paramètre de retour ajax positionné à {@code true} quand les fichiers ont été
   * enregistrés, pour que le fragment puisse fermer le dialogue qui le contient.
   */
  public static final String CALLBACK_PARAM_SAVED = "filesSaved";

  @Inject
  DocumentationClient client;

  @Inject
  FileViewerUriBuilder viewerUriBuilder;

  /**
   * Contrôleur des fichiers en attente et des fichiers déjà rattachés (tableau « Nom »).
   */
  @Inject
  @Getter
  FilesGroupUploadController filesGroupUploadController;

  /**
   * Identifiant du processus, posé par l'hôte puis {@link #initialize()}.
   */
  @Getter
  @Setter
  String processIdentifier;

  /**
   * Identifiant de la source, posé par l'hôte puis {@link #initialize()}.
   */
  @Getter
  @Setter
  String sourceIdentifier;

  /**
   * Identifiant de l'enregistrement, posé par l'hôte puis {@link #initialize()}.
   */
  @Getter
  @Setter
  String recordIdentifier;

  /**
   * Identifiant de l'opération, posé par l'hôte puis {@link #initialize()}.
   */
  @Getter
  @Setter
  String operationIdentifier;

  /**
   * Si vrai, les fichiers déjà rattachés sont listés dans leur propre tableau (édition). Faux par
   * défaut : le formulaire ne sert alors qu'à ajouter de nouveaux fichiers (création).
   */
  @Getter
  @Setter
  boolean showExistingFiles;

  /**
   * Vrai si {@link #initializeFilesList()} a préparé la liste de File : l'hôte n'affiche la liste
   * que dans ce cas.
   */
  @Getter
  boolean filesListAvailable;

  /**
   * Contrôleur de la liste de File des fichiers rattachés, préparé par
   * {@link #initializeFilesList()} : l'hôte le passe à {@code listForm.xhtml}.
   */
  @Inject
  @Getter
  FileGroupController fileGroupController;

  /**
   * Si faux, le téléchargement est masqué dans la liste (pages publiques : le téléchargement
   * exige un utilisateur connecté). Vrai par défaut ; à définir avant
   * {@link #initializeFilesList()}.
   */
  @Getter
  @Setter
  boolean downloadable = true;

  /**
   * Identifiant du rattachement de fichier (la ligne) rappelé par {@link #load(String)}, ou
   * {@code null} : tous les fichiers déjà déposés sont alors listés.
   */
  @Getter
  String fileGroupIdentifier;

  /**
   * Cette méthode permet de charger les fichiers déjà rattachés au contexte métier posé par les
   * setters (processus, source, enregistrement, opération). Les fichiers en attente et ceux de
   * l'ancien contexte sont d'abord retirés, pour qu'un changement d'enregistrement n'en laisse
   * aucun à l'écran ni ne les dépose sur le nouvel enregistrement. Une indisponibilité du module
   * {@code documentation} ou {@code file} est journalisée sans bloquer l'ouverture de la page hôte.
   *
   * @throws IllegalStateException si l'un des quatre identifiants du contexte n'est pas renseigné
   */
  public void initialize() {
    validateContext();
    reset();
  }

  /**
   * Cette méthode permet de vérifier que les quatre identifiants du contexte sont renseignés.
   *
   * @throws IllegalStateException si l'un des quatre identifiants du contexte n'est pas renseigné
   */
  void validateContext() {
    if (Stream.of(processIdentifier, sourceIdentifier, recordIdentifier, operationIdentifier)
        .anyMatch(value -> value == null || value.isBlank())) {
      throw new IllegalStateException("Le processus, la source, l'enregistrement et l'opération "
          + "doivent être renseignés avant l'initialisation.");
    }
  }

  /**
   * Cette méthode permet de préparer la liste de File des fichiers rattachés au contexte métier
   * posé par les setters, sans recoder le tableau : l'hôte décore {@code listForm.xhtml} de File
   * avec {@link #getFileGroupController()}. La liste est en consultation : l'œil et le
   * téléchargement seulement (sauf si {@link #isDownloadable()} est faux), sans ajout, export,
   * colonnes, modification, suppression, partage ni catégorie. Sans documentation ou sans groupe
   * de fichiers, la liste n'est pas préparée (un filtre sans groupe listerait tous les fichiers)
   * et {@link #isFilesListAvailable()} est faux. Une indisponibilité du module
   * {@code documentation} est journalisée sans bloquer l'ouverture de la page hôte.
   *
   * @throws IllegalStateException si l'un des quatre identifiants du contexte n'est pas renseigné
   */
  public void initializeFilesList() {
    validateContext();
    filesListAvailable = false;
    String groupIdentifier = findFilesGroupIdentifier();
    if (groupIdentifier == null) {
      return;
    }
    ListController listController = fileGroupController.getListController();
    fileGroupController.setCategorizable(false);
    fileGroupController.setShareable(false);
    listController.getReadController().setUserIdentifier(userIdentifier);
    listController.getDataTable().getActionsOutputPanel().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
    fileGroupController.getFilterController().getFilter().setGroupIdentifier(groupIdentifier);
    fileGroupController.initialize();
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(2);
    if (!downloadable) {
      fileGroupController.getDownloadButton().addStyleClass("d-none");
    }
    filesListAvailable = true;
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de fichiers de la documentation du
   * contexte, sans en créer.
   *
   * @return identifiant du groupe, ou {@code null} sans documentation, sans groupe ou si le module
   *         {@code documentation} est indisponible
   */
  String findFilesGroupIdentifier() {
    try {
      DocumentationDto documentation = findDocumentation();
      return documentation == null ? null : documentation.getFilesGroupIdentifier();
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des fichiers de l'enregistrement " + recordIdentifier + " en échec.",
          exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de préparer le formulaire à l'ajout de fichiers : les fichiers déjà
   * rattachés ne sont pas listés, et le formulaire est rechargé depuis le serveur.
   */
  public void startCreation() {
    fileGroupIdentifier = null;
    showExistingFiles = false;
    cancel();
  }

  /**
   * Cette méthode permet de rappeler une ligne pour la modifier : elle devient la seule listée
   * parmi les fichiers déjà déposés, et le formulaire est rechargé depuis le serveur.
   *
   * @param fileGroupIdentifier identifiant du rattachement de fichier de la ligne
   */
  public void load(String fileGroupIdentifier) {
    this.fileGroupIdentifier = fileGroupIdentifier;
    showExistingFiles = true;
    cancel();
  }

  /**
   * Cette méthode permet de brancher le formulaire sur le bouton « Ajouter » d'une liste de
   * fichiers de {@code file} : son contenu remplace celui du dialogue de création, et il est
   * préparé à l'ajout à chaque ouverture, après le nettoyage des champs fait par la liste. Le
   * contexte doit avoir été initialisé par {@link #initialize()}.
   *
   * @param listController liste des fichiers de la page hôte
   * @param contentFilePath chemin de la vue du dialogue, qui inclut {@code filesUpload.xhtml}
   */
  public void initializeCreateDialog(ListController listController, String contentFilePath) {
    listController.getCreateDialog().setContentFilePath(contentFilePath);
    listController.getCreateController().addEntityConsumer(entity -> startCreation());
  }

  /**
   * Cette méthode permet de brancher le formulaire sur le crayon d'une ligne d'une liste de
   * fichiers de {@code file} : son contenu remplace celui du dialogue de mise à jour, et il
   * rappelle la ligne cliquée à chaque ouverture, après le nettoyage des champs fait par la
   * liste. Le contexte doit avoir été initialisé par {@link #initialize()}.
   *
   * @param listController liste des fichiers de la page hôte
   * @param contentFilePath chemin de la vue du dialogue, qui inclut {@code filesUpload.xhtml}
   */
  public void initializeUpdateDialog(ListController listController, String contentFilePath) {
    listController.getUpdateDialog().setContentFilePath(contentFilePath);
    listController.getUpdateController().addEntityConsumer(this::recallLine);
  }

  /**
   * Cette méthode permet de rappeler dans le formulaire le fichier de la ligne cliquée. Une ligne
   * absente ou d'un autre type est ignorée ; si le fichier n'est pas retrouvé, un message en
   * avertit l'utilisateur plutôt que d'afficher un tableau vide sans explication.
   *
   * @param entity ligne cliquée dans la liste des fichiers
   */
  void recallLine(Object entity) {
    if (!(entity instanceof AbstractIdentifiableDto line)) {
      return;
    }
    load(line.getIdentifier());
    if (getExistingFileRows().isEmpty()) {
      FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(
          FacesMessage.SEVERITY_WARN, "Fichier introuvable",
          "Le fichier de cette ligne n'a pas été retrouvé."));
    }
  }

  /**
   * Cette méthode permet d'obtenir les lignes du tableau des fichiers déjà rattachés à la
   * documentation. Elles sont vides en création ({@link #showExistingFiles} faux). Seule la ligne
   * rappelée par {@link #load(String)} est listée, le cas échéant.
   *
   * @return les lignes du tableau des fichiers déjà rattachés
   */
  public List<FileRow> getExistingFileRows() {
    List<FileRow> rows = new ArrayList<>();
    if (showExistingFiles) {
      filesGroupUploadController.getExistingFileGroups().forEach((key, fileGroup) -> rows.add(
          new FileRow(fileGroup.getFileAsString(), key, fileGroup.getFileIdentifier(),
              fileGroup.getFileOwnerIdentifier(), true)));
      if (fileGroupIdentifier != null) {
        rows.removeIf(row -> !fileGroupIdentifier.equals(row.getKey()));
      }
    }
    return rows;
  }

  /**
   * Cette méthode permet d'obtenir les lignes du tableau des fichiers ajoutés et pas encore
   * enregistrés.
   *
   * @return les lignes du tableau des fichiers à déposer
   */
  public List<FileRow> getAddedFileRows() {
    List<FileRow> rows = new ArrayList<>();
    filesGroupUploadController.getFiles().forEach(
        (key, file) -> rows.add(new FileRow(file.getName(), key, null, null, false)));
    return rows;
  }

  /**
   * Cette méthode permet de retirer une ligne du tableau : un fichier déjà rattaché est retiré
   * à l'enregistrement, un fichier ajouté est simplement abandonné.
   *
   * @param row ligne à retirer
   */
  public void removeRow(FileRow row) {
    if (row.isExisting()) {
      filesGroupUploadController.removeExisting(row.getKey());
    } else {
      filesGroupUploadController.remove(row.getKey());
    }
  }

  /**
   * Cette méthode permet de déposer les fichiers en attente : la documentation du contexte est
   * retrouvée ou créée, puis un groupe de fichiers lui est attribué si elle n'en a pas encore, et
   * enfin les ajouts et retraits demandés sont appliqués. Un échec est signalé à l'utilisateur
   * dans une boîte de dialogue, sans interrompre la page.
   */
  public void upload() {
    ActionExecutor<String> executor = new ActionExecutor<>(this,
        "Dépôt des fichiers de l'enregistrement " + recordIdentifier, () -> {
          depositFiles();
          return recordIdentifier;
        }).setExceptionMessageSummary("Dépôt des fichiers impossible");
    executor.execute();
    if (executor.getException() == null) {
      loadExistingFiles();
      notifySaved();
    }
  }

  /**
   * Cette méthode permet de signaler au navigateur que les fichiers sont enregistrés.
   */
  void notifySaved() {
    PrimeFaces.current().ajax().addCallbackParam(CALLBACK_PARAM_SAVED, true);
  }

  /**
   * Cette méthode permet d'obtenir l'adresse d'affichage d'un fichier rattaché. Le fichier est
   * ouvert par un lien (nouvel onglet) plutôt que par le script d'ouverture de fenêtre du
   * visualisateur, lancé depuis un retour ajax et donc exposé au blocage des fenêtres
   * intempestives du navigateur.
   *
   * @param fileIdentifier identifiant du fichier
   * @param ownerIdentifier identifiant du propriétaire du fichier, éventuellement {@code null}
   * @return adresse d'affichage du fichier
   */
  public String viewerUri(String fileIdentifier, String ownerIdentifier) {
    return viewerUriBuilder.build(fileIdentifier, ownerIdentifier, userIdentifier, null)
        .toString();
  }

  /**
   * Cette méthode permet d'annuler les modifications non enregistrées : fichiers en attente de
   * dépôt et retraits demandés. Les fichiers déjà rattachés sont rechargés.
   */
  public void cancel() {
    reset();
  }

  /**
   * Cette méthode permet de remettre les fichiers affichés à l'état enregistré : les fichiers en
   * attente et ceux de l'ancien contexte sont retirés, puis les fichiers rattachés sont chargés.
   */
  void reset() {
    filesGroupUploadController.getFiles().clear();
    filesGroupUploadController.getExistingFileGroups().clear();
    loadExistingFiles();
  }

  /**
   * Cette méthode permet de déposer les fichiers en attente. Sans documentation pour le contexte,
   * le module {@code file} dépose les fichiers dans un nouveau groupe dont l'identifiant sert
   * directement à créer la documentation ; sans fichier, rien n'est créé. Sinon, les fichiers
   * rejoignent le groupe de la documentation existante.
   */
  void depositFiles() {
    DocumentationDto documentation = findDocumentation();
    if (documentation == null) {
      if (filesGroupUploadController.getFiles().isEmpty()) {
        return;
      }
      createDocumentation(filesGroupUploadController.createTemporary());
    } else {
      filesGroupUploadController.update(filesGroupIdentifierOf(documentation), userIdentifier);
    }
  }

  /**
   * Cette méthode permet de créer la documentation du contexte, rattachée à un groupe de fichiers
   * déjà déposé.
   *
   * @param filesGroupIdentifier identifiant du groupe de fichiers
   */
  void createDocumentation(String filesGroupIdentifier) {
    DocumentationCreateRequestDto request = new DocumentationCreateRequestDto();
    request.setProcessIdentifier(processIdentifier);
    request.setSourceIdentifier(sourceIdentifier);
    request.setRecordIdentifier(recordIdentifier);
    request.setOperationIdentifier(operationIdentifier);
    request.setFilesGroupIdentifier(filesGroupIdentifier);
    request.setAuditWho(userIdentifier);
    client.create(request);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de fichiers d'une documentation
   * existante, en lui en attribuant un si elle n'en a pas encore.
   *
   * @param documentation documentation du contexte
   * @return identifiant du groupe de fichiers
   */
  String filesGroupIdentifierOf(DocumentationDto documentation) {
    if (documentation.getFilesGroupIdentifier() != null) {
      return documentation.getFilesGroupIdentifier();
    }
    ByIdentifierRequestDto request = new ByIdentifierRequestDto();
    request.setIdentifier(documentation.getIdentifier());
    request.setAuditWho(userIdentifier);
    client.updateFilesGroupIdentifierToNonNull(request);
    return client.getByIdentifier(documentation.getIdentifier(),
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            DocumentationDto.JSON_FILES_GROUP_IDENTIFIER),
        userIdentifier, null).getFilesGroupIdentifier();
  }

  /**
   * Cette méthode permet de retrouver la documentation du contexte métier.
   *
   * @return la documentation, ou {@code null} si aucune n'existe encore
   */
  DocumentationDto findDocumentation() {
    FilterDto filter = new FilterDto();
    DocumentationFilter.setProcessIdentifier(filter, processIdentifier);
    DocumentationFilter.setSourceIdentifier(filter, sourceIdentifier);
    DocumentationFilter.setRecordIdentifier(filter, recordIdentifier);
    DocumentationFilter.setOperationIdentifier(filter, operationIdentifier);
    ProjectionDto projection = new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, DocumentationDto.JSON_FILES_GROUP_IDENTIFIER);
    DocumentationGetManyResponseDto response =
        client.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null || response.getDatas().isEmpty()) {
      return null;
    }
    return response.getDatas().get(0);
  }

  /**
   * Cette méthode permet de charger les fichiers déjà rattachés au contexte, pour le tableau
   * « Nom ».
   */
  void loadExistingFiles() {
    try {
      DocumentationDto documentation = findDocumentation();
      if (documentation != null && documentation.getFilesGroupIdentifier() != null) {
        filesGroupUploadController.loadExisting(documentation.getFilesGroupIdentifier(),
            userIdentifier);
      }
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des fichiers de l'enregistrement " + recordIdentifier + " en échec.",
          exception);
    }
  }

  /**
   * Cette classe représente une ligne du tableau des fichiers.
   */
  @Getter
  @AllArgsConstructor
  public static class FileRow {

    /** Nom du fichier. */
    String name;

    /** Clé dans le contrôleur de fichiers : rattachement existant ou empreinte du fichier. */
    String key;

    /** Identifiant du fichier, pour l'afficher ; {@code null} pour un fichier pas encore déposé. */
    String fileIdentifier;

    /** Identifiant du propriétaire du fichier, éventuellement {@code null}. */
    String ownerIdentifier;

    /** Vrai si le fichier est déjà rattaché à la documentation. */
    boolean existing;
  }
}
