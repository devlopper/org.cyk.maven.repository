package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une localité du FUR : elle associe le code de la localité d'affectation
 * au mode de règlement, c'est-à-dire à la trésorerie de paiement de l'agent (RG-07 du dossier de
 * spécifications du FUR).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurLocalityDto extends AbstractIdentifiableAuditableDto {

  /**
   * Code de la localité d'affectation, tel qu'il figure dans la colonne
   * {@code CODE_LIEU_AFFECTATION}.
   */
  @JsonbProperty(JSON_LOCALITY_CODE)
  private String localityCode;

  /**
   * Code de la localité CALO.
   */
  @JsonbProperty(JSON_CALO_LOCALITY_CODE)
  private String caloLocalityCode;

  /**
   * Code du mode de règlement : la trésorerie de paiement (quatre caractères).
   */
  @JsonbProperty(JSON_PAYMENT_MODE_CODE)
  private String paymentModeCode;

  /**
   * Identifiant json {@link #localityCode}.
   */
  public static final String JSON_LOCALITY_CODE = "codeLocalite";

  /**
   * Identifiant json {@link #caloLocalityCode}.
   */
  public static final String JSON_CALO_LOCALITY_CODE = "codeLocaliteCalo";

  /**
   * Identifiant json {@link #paymentModeCode}.
   */
  public static final String JSON_PAYMENT_MODE_CODE = "codeModeReglement";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "localité du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "localités du FUR";
}
