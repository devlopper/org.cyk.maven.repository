package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Path(AdministrativeUnitEmployeeService.PATH)
@Tag(name = "Gestion des employés d'unités administratives")
public interface AdministrativeUnitEmployeeService extends Service {

  /**
   * Chemin de base.
   */
  String PATH = "employes-unites-administratives";

  /**
   * Cette interface représente la base de requête d'enregistrement.
   */
  interface AdministrativeUnitEmployeeBaseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
     *
     * @return identifiant {@link BudgetDto}
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
     *
     * @param identifier identifiant {@link BudgetDto}
     */
    void setBudgetIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant unité administrative.
     *
     * @return identifiant unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant unité administrative.
     *
     * @param identifier identifiant unité administrative
     */
    void setAdministrativeUnitIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_BUDGET_IDENTIFIER}.
     */
    String JSON_BUDGET_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_BUDGET_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;
  }

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface AdministrativeUnitEmployeeSaveRequestDto
      extends AdministrativeUnitEmployeeBaseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant employé.
     *
     * @return identifiant employé
     */
    String getEmployeeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant employé.
     *
     * @param identifier identifiant employé
     */
    void setEmployeeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'emploi.
     *
     * @return identifiant de l'emploi
     */
    String getJobIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'emploi.
     *
     * @param identifier identifiant de l'emploi
     */
    void setJobIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'indice de paie.
     *
     * @return identifiant de l'indice de paie
     */
    String getPayIndexIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'indice de paie.
     *
     * @param identifier identifiant de l'indice de paie
     */
    void setPayIndexIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la fonction.
     *
     * @return identifiant de la fonction
     */
    String getFunctionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la fonction.
     *
     * @param identifier identifiant de la fonction
     */
    void setFunctionIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_EMPLOYEE_IDENTIFIER}.
     */
    String JSON_EMPLOYEE_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_EMPLOYEE_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_JOB_IDENTIFIER}.
     */
    String JSON_JOB_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_JOB_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_PAY_INDEX_IDENTIFIER}.
     */
    String JSON_PAY_INDEX_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_PAY_INDEX_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_FUNCTION_IDENTIFIER}.
     */
    String JSON_FUNCTION_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_FUNCTION_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(AdministrativeUnitEmployeeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements AdministrativeUnitEmployeeSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
    String employeeIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;

    @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
    String payIndexIdentifier;

    @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
    String functionIdentifier;
  }

  /**
   * Identifiant du service de création par fonctionnaire.
   */
  String CREATE_BY_FUNCTIONARY_IDENTIFIER =
      "CREATION_PAR_FONCTIONNAIRE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création par fonctionnaire.
   */
  String CREATE_BY_FUNCTIONARY_PATH = "creation-par-fonctionnaire";

  /**
   * Cette méthode permet de créer {@link AdministrativeUnitEmployeeDto} par fonctionnaire.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_FUNCTIONARY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_FUNCTIONARY_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByFunctionary(AdministrativeUnitEmployeeCreateByFunctionaryRequestDto request);

  /**
   * Cette classe représente la requête de création par fonctionnaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeCreateByFunctionaryRequestDto extends
      AbstractAuditedRequestJsonDto implements AdministrativeUnitEmployeeBaseSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    String functionaryIdentifier;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_FUNCTIONARY_IDENTIFIER}.
     */
    public static final String JSON_FUNCTIONARY_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_FUNCTIONARY_IDENTIFIER;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class AdministrativeUnitEmployeeGetManyResponseDto
      extends AbstractGetByPageResponseDto<AdministrativeUnitEmployeeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<AdministrativeUnitEmployeeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = AdministrativeUnitEmployeeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(AdministrativeUnitEmployeeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeUpdateRequestDto extends ByIdentifierRequestDto
      implements AdministrativeUnitEmployeeSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
    String employeeIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;

    @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
    String payIndexIdentifier;

    @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
    String functionIdentifier;
  }

  /**
   * Cette interface représente la requête d'entrée ou de sortie.
   */
  interface AdministrativeUnitEmployeeBoardRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link MovementTypeDto}.
     *
     * @return identifiant {@link MovementTypeDto}
     */
    String getMovementTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link MovementTypeDto}.
     *
     * @param identifier identifiant {@link MovementTypeDto}
     */
    void setMovementTypeIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_MOVEMENT_TYPE_IDENTIFIER}.
     */
    String JSON_MOVEMENT_TYPE_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_MOVEMENT_TYPE_IDENTIFIER;
  }

  /**
   * Identifiant du service de sortie.
   */
  String OFFBOARD_IDENTIFIER = "SORTIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de sortie.
   */
  String OFFBOARD_PATH = "sortie";

  /**
   * Cette méthode permet de sortir {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(OFFBOARD_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = OFFBOARD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response offboard(AdministrativeUnitEmployeeOffboardRequestDto request);

  /**
   * Cette classe représente la requête de sortie.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeOffboardRequestDto extends ByIdentifierRequestDto
      implements AdministrativeUnitEmployeeBoardRequestDto {

    @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
    String movementTypeIdentifier;
  }

  /**
   * Identifiant du service d'annulation de sortie.
   */
  String CANCEL_OFFBOARD_IDENTIFIER = "ANNULATION_SORTIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'annulation de sortie.
   */
  String CANCEL_OFFBOARD_PATH = "annulation-sortie";

  /**
   * Cette méthode permet d'annuler une sortie de {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_OFFBOARD_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CANCEL_OFFBOARD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response cancelOffboard(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de calcul.
   */
  String CALCULATE_IDENTIFIER = "CALCUL_POSTE_UNITE_ADMINISTRATIVE_EMPLOYE";

  /**
   * Chemin du service de calcul.
   */
  String CALCULATE_PATH = "calcul";

  /**
   * Cette méthode permet de calculer les projections de poste d'un AdministrativeUnitEmployee.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CALCULATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CALCULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response calculate(AdministrativeUnitEmployeeCalculateRequestDto request);

  /**
   * Cette classe représente la requête de calcul.
   *
   * @author Christian
   */
  class AdministrativeUnitEmployeeCalculateRequestDto extends ByIdentifierRequestDto {

  }
}
