package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Un type de mouvement confié à un membre d'équipe.
 *
 * <p><strong>Ce lien restreint, il n'accorde pas.</strong> Le droit d'instruire vient du jeton, et
 * de lui seul : un membre à qui l'on confie les rappels sans qu'il porte
 * {@code TRAITER_REGULARISATION} n'instruira rien. Ce qui est décrit ici, c'est le partage du
 * travail <em>à l'intérieur</em> de ce que le jeton ouvre déjà — qui, dans l'équipe, prend les
 * primes et qui prend les retraites.</p>
 *
 * <p><strong>Aucun lien vaut tout le périmètre du jeton</strong>, et ce n'est pas un oubli. Le
 * partage est une organisation, pas une condition : un membre à qui l'on n'a rien confié
 * particulièrement instruit toute sa famille, comme avant que cette table n'existe. L'inverse —
 * aucun lien, aucun droit — bloquerait tout le monde le jour où la table est créée vide.</p>
 *
 * <p>Rien de plus que les deux extrémités du lien : une association qui porterait des attributs
 * propres cesserait d'être une association et deviendrait un objet, qu'il faudrait alors savoir
 * modifier, dater, justifier.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ArbitrationTeamMemberMovementTypeDto extends AbstractIdentifiableDto {

  /**
   * Membre d'équipe à qui le type est confié.
   */
  @JsonbProperty(JSON_MEMBER_IDENTIFIER)
  private String memberIdentifier;

  /**
   * Identifiant de connexion du membre, pour relire le partage sans un appel de plus.
   */
  @JsonbProperty(JSON_MEMBER_USER)
  private String memberUser;

  /**
   * Type de mouvement confié.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
  private String movementTypeIdentifier;

  /**
   * Libellé du type de mouvement.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_AS_STRING)
  private String movementTypeAsString;

  /**
   * Code du type de mouvement, qui est ce que la ligne d'arbitrage transporte.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_CODE)
  private String movementTypeCode;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeMouvementMembre";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "typeMouvementMembreChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de mouvement d'un membre";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de mouvement des membres";

  /**
   * Identifiant json pour {@link #memberIdentifier}.
   */
  public static final String JSON_MEMBER_IDENTIFIER =
      ArbitrationTeamMemberDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #memberUser}.
   */
  public static final String JSON_MEMBER_USER = "membreUtilisateur";

  /**
   * Identifiant json pour {@link #movementTypeIdentifier}.
   */
  public static final String JSON_MOVEMENT_TYPE_IDENTIFIER = MovementTypeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #movementTypeAsString}.
   */
  public static final String JSON_MOVEMENT_TYPE_AS_STRING = MovementTypeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #movementTypeCode}.
   */
  public static final String JSON_MOVEMENT_TYPE_CODE =
      ArbitrationMovementDto.JSON_MOVEMENT_TYPE_CODE;
}
