package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.localauthority.server.api.LocalAuthorityService.LocalAuthorityGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link LocalAuthorityService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class LocalAuthorityClient extends AbstractClient<LocalAuthorityService> implements
    GetByIdentifier<LocalAuthorityDto>, GetMany<LocalAuthorityGetManyResponseDto>,
    OneRetrievable<LocalAuthorityDto> {

  @Override
  public LocalAuthorityClient service(LocalAuthorityService service) {
    return (LocalAuthorityClient) super.service(service);
  }

  /**
   * {@link LocalAuthorityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public LocalAuthorityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<LocalAuthorityGetManyResponseDto>(
        LocalAuthorityGetManyResponseDto.class, LocalAuthorityService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link LocalAuthorityService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public LocalAuthorityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link LocalAuthorityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public LocalAuthorityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<LocalAuthorityDto>(LocalAuthorityDto.class,
        LocalAuthorityService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link LocalAuthorityService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public LocalAuthorityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link LocalAuthorityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public LocalAuthorityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<LocalAuthorityDto>(LocalAuthorityDto.class,
        LocalAuthorityService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link LocalAuthorityService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LocalAuthorityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
