package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FundGroupTypeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T18:33:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FundGroupTypeRequestMapperImpl implements FundGroupTypeRequestMapper {

    @Override
    public FundGroupTypeService.FundGroupTypeCreateRequestDto mapCreate(FundGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundGroupTypeService.FundGroupTypeCreateRequestDto fundGroupTypeCreateRequestDto = new FundGroupTypeService.FundGroupTypeCreateRequestDto();

        fundGroupTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundGroupTypeCreateRequestDto.setCode( arg0.getCode() );
        fundGroupTypeCreateRequestDto.setName( arg0.getName() );

        return fundGroupTypeCreateRequestDto;
    }

    @Override
    public FundGroupTypeService.FundGroupTypeUpdateRequestDto mapUpdate(FundGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundGroupTypeService.FundGroupTypeUpdateRequestDto fundGroupTypeUpdateRequestDto = new FundGroupTypeService.FundGroupTypeUpdateRequestDto();

        fundGroupTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundGroupTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fundGroupTypeUpdateRequestDto.setCode( arg0.getCode() );
        fundGroupTypeUpdateRequestDto.setName( arg0.getName() );

        return fundGroupTypeUpdateRequestDto;
    }
}
