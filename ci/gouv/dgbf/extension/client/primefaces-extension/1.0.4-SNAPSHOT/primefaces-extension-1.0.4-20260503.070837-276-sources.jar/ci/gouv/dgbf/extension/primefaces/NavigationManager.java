package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.UriQueryBuilder;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.application.ConfigurableNavigationHandler;
import jakarta.faces.application.NavigationCase;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Cette classe représente un gestionnaire de navigation.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Named
public class NavigationManager {

  /**
   * Cette méthode permet de naviguer.
   *
   * @param outcome identifiant navigation
   * @param queryParameters paramètres de requête
   */
  public void navigate(String outcome, Map<String, List<String>> queryParameters) {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    ConfigurableNavigationHandler navigationHandler =
        (ConfigurableNavigationHandler) facesContext.getApplication().getNavigationHandler();
    NavigationCase navigationCase =
        navigationHandler.getNavigationCase(facesContext, null, outcome);

    HttpServletRequest request =
        (HttpServletRequest) facesContext.getExternalContext().getRequest();
    String path = navigationCase.getToViewId(facesContext);
    String query = buildQuery(queryParameters);
    navigateByUrl(request.getContextPath() + path + query);
  }

  /**
   * Cette méthode permet de naviguer.
   *
   * @param outcome identifiant navigation
   */
  public void navigate(String outcome) {
    navigate(outcome, null);
  }

  /**
   * Cette méthode permet de naviguer par url.
   *
   * @param url url
   */
  public static void navigateByUrl(String url) {
    try {
      FacesContext.getCurrentInstance().getExternalContext().redirect(url);
    } catch (IOException exception) {
      throw new Exception(exception);
    }
  }

  String buildQuery(Map<String, List<String>> queryParameters) {
    UriQueryBuilder uriQueryBuilder = new UriQueryBuilder();
    uriQueryBuilder.setAppendQuestionMarkIfNotBlank(true);
    uriQueryBuilder.map().add(queryParameters);
    return uriQueryBuilder.build();
  }

  /**
   * Cette classe représente une exception de navigation.
   *
   * @author Christian
   *
   */
  public static class Exception extends RuntimeException {

    public Exception(Throwable cause) {
      super(cause);
    }

  }
}
