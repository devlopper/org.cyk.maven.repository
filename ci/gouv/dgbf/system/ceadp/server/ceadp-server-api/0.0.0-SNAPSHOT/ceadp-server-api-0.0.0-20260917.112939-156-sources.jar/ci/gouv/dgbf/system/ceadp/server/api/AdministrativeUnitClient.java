package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.ceadp.server.api.AdministrativeUnitService.AdministrativeUnitGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link AdministrativeUnitService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class AdministrativeUnitClient extends AbstractClient<AdministrativeUnitService>
    implements OneRetrievable<AdministrativeUnitDto>, GetByIdentifier<AdministrativeUnitDto>,
    GetMany<AdministrativeUnitGetManyResponseDto> {

  @Override
  public AdministrativeUnitClient service(AdministrativeUnitService service) {
    return (AdministrativeUnitClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitGetManyResponseDto>(
        AdministrativeUnitGetManyResponseDto.class, AdministrativeUnitService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link AdministrativeUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitDto>(AdministrativeUnitDto.class,
        AdministrativeUnitService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AdministrativeUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AdministrativeUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitDto>(AdministrativeUnitDto.class,
        AdministrativeUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AdministrativeUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AdministrativeUnitDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
