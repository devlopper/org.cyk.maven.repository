package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant de rôle.
 *
 * @author BoobaCool
 */
public interface HasRoleIdentifierDto extends HasRoleIdentifier {

  /**
   * Identifiant json de l'identifiant du rôle.
   */
  String JSON_ROLE_IDENTIFIER = "idRole";
}
