package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringDataDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ValueDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueController extends AbstractController {

  @Inject
  ValueClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ValueFilterController filterController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ValueDto.NAME;

    listController.setEntityClass(ValueDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ValueService.PATH);
    listController.setFilterController(filterController);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasSourceAsStringDto.JSON_SOURCE_AS_STRING, HasStringDataDto.JSON_DATA,
            ValueDto.JSON_NAME));

    listController.getDataTable().getFilterButton().setRendered(true);
    
    listController.initialize();
  }
}
