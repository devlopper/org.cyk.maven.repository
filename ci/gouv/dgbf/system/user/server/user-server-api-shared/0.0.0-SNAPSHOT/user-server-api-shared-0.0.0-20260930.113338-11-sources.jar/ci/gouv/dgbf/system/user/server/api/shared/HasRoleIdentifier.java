package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant de rôle.
 *
 * @author BoobaCool
 */
public interface HasRoleIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du rôle.
   *
   * @return identifiant du rôle
   */
  String getRoleIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du rôle.
   *
   * @param roleIdentifier identifiant du rôle
   */
  void setRoleIdentifier(String roleIdentifier);

  /**
   * Identifiant java de l'identifiant du rôle.
   */
  String FIELD_ROLE_IDENTIFIER = "roleIdentifier";
}
