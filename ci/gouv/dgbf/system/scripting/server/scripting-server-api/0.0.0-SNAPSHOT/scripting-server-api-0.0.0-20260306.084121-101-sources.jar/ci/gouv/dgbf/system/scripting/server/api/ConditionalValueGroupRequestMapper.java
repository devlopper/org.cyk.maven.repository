package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ConditionalValueGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ConditionalValueGroupDto}.

    @author Christian
               """)
public interface ConditionalValueGroupRequestMapper extends RequestMapper<ConditionalValueGroupDto,
    ConditionalValueGroupCreateRequestDto, ConditionalValueGroupUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper.
   *
   * @param conditionalValueGroup {@link ConditionalValueGroupDto}
   * @return {@link ConditionalValueGroupGetApplicableValueRequestDto}
   */
  ConditionalValueGroupGetApplicableValueRequestDto mapGetApplicableValue(
      ConditionalValueGroupDto conditionalValueGroup);

}
