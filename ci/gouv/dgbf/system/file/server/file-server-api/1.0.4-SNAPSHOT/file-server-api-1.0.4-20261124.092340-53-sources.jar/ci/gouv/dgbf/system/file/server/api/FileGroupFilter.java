package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileGroupFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link FilesGroupDtos}.
   */
  String groupIdentifier;

  /**
   * Identifiants {@link FilesGroupDtos}.
   */
  Set<String> groupsIdentifiers;

  /**
   * Indicateur d'archivage effectif (présence d'une période sans date de fin).
   */
  Boolean archived;

  /**
   * Indicateur de gel pour archivage (période sans fin ou demande d'archivage en cours).
   */
  Boolean archivalFrozen;

  @Override
  protected void doInitialize(FilterDto filter) {
    groupIdentifier = getGroupIdentifier(filter);
    groupsIdentifiers = getGroupsIdentifiers(filter);
    archived = getArchived(filter);
    archivalFrozen = getArchivalFrozen(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setGroupsIdentifiers(filter, groupsIdentifiers);
    setArchived(filter, archived);
    setArchivalFrozen(filter, archivalFrozen);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant {@link FilesGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir identifiant {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link FilesGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @param groupsIdentifiers identifiants {@link FilesGroupDto}
   */
  public static void setGroupsIdentifiers(FilterDto filter, Set<String> groupsIdentifiers) {
    set(filter, JSON_GROUPS_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet((LinkedHashSet<String>) Core
            .getOrNullifyIfCollectionEmpty(Core.getLinkedHashSet(groupsIdentifiers))));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants {@link FilesGroupDto}.
   *
   * @param filter filtre
   * @return identifiants {@link FilesGroupDto}
   */
  public static Set<String> getGroupsIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_GROUPS_IDENTIFIERS));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur d'archivage effectif.
   *
   * @param filter filtre
   * @param archived indicateur d'archivage effectif
   */
  public static void setArchived(FilterDto filter, Boolean archived) {
    set(filter, JSON_ARCHIVED, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(archived));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur d'archivage effectif.
   *
   * @param filter filtre
   * @return indicateur d'archivage effectif
   */
  public static Boolean getArchived(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_ARCHIVED));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur de gel pour archivage.
   *
   * @param filter filtre
   * @param archivalFrozen indicateur de gel pour archivage
   */
  public static void setArchivalFrozen(FilterDto filter, Boolean archivalFrozen) {
    set(filter, JSON_ARCHIVAL_FROZEN, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(archivalFrozen));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur de gel pour archivage.
   *
   * @param filter filtre
   * @return indicateur de gel pour archivage
   */
  public static Boolean getArchivalFrozen(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_ARCHIVAL_FROZEN));
  }

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = FileDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant JSON {@link #groupsIdentifiers}.
   */
  public static final String JSON_GROUPS_IDENTIFIERS = "idsGroupes";

  /**
   * Identifiant JSON {@link #archived}.
   */
  public static final String JSON_ARCHIVED = FileGroupDto.JSON_ARCHIVED;

  /**
   * Identifiant JSON {@link #archivalFrozen}.
   */
  public static final String JSON_ARCHIVAL_FROZEN = FileGroupDto.JSON_ARCHIVAL_FROZEN;
}
