package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayIndexDto}.
 *
 * @author A.K.M
 *
 */
@Path(value = PayIndexService.PATH)
@Tag(name = "Gestion des indices")
public interface PayIndexService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "indices";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author A.K.M
   *
   */
  interface PayIndexSaveRequestDto {


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link EchelonDto}.
     *
     * @return identifiant de {@link EchelonDto}
     */
    String getEchelonIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link EchelonDto}.
     *
     * @param identifier identifiant de {@link EchelonDto}
     */
    void setEchelonIdentifier(String identifier);

    /**
     * Identifiant json de {@link EchelonDto}.
     */
    String JSON_ECHELON_IDENTIFIER =
        PayIndexDto.JSON_ECHELON_IDENTIFIER;


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayScaleDto}.
     *
     * @return identifiant de {@link PayScaleDto}
     */
    String getPayScaleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayScaleDto}.
     *
     * @param identifier identifiant de {@link PayScaleDto}
     */
    void setPayScaleIdentifier(String identifier);

    /**
     * Identifiant json de {@link PayScaleDto}.
     */
    String JSON_PAY_SCALE_IDENTIFIER =
        PayIndexDto.JSON_PAY_SCALE_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link GradeDto}.
     *
     * @return identifiant de {@link GradeDto}
     */
    String getGradeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link GradeDto}.
     *
     * @param identifier identifiant de {@link GradeDto}
     */
    void setGradeIdentifier(String identifier);

    /**
     * Identifiant json de {@link GradeDto}.
     */
    String JSON_GRADE_IDENTIFIER =
        PayIndexDto.JSON_GRADE_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link GradeClassDto}.
     *
     * @return identifiant de {@link GradeClassDto}
     */
    String getGradeClassIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link GradeClassDto}.
     *
     * @param identifier identifiant de {@link GradeClassDto}
     */
    void setGradeClassIdentifier(String identifier);

    /**
     * Identifiant json de {@link GradeClassDto}.
     */
    String JSON_GRADE_CLASS_IDENTIFIER =
        PayIndexDto.JSON_GRADE_CLASS_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir la valeur de l'indice.
     *
     * @return valeur de l'indice
     */
    Integer getValue();

    /**
     * Cette méthode permet d'assigner la valeur de l'indice.
     *
     * @param value valeur de l'indice
     */
    void setValue(Integer value);

    /**
     * {@link PayIndexSaveRequestDto#JSON_VALUE}.
     */
    String JSON_VALUE =  PayIndexDto.JSON_VALUE;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_INDICE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayIndexCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class PayIndexCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayIndexSaveRequestDto {

    @JsonbProperty(value = JSON_VALUE)
    private Integer value;

    @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
    private String payScaleIdentifier;

    @JsonbProperty(JSON_GRADE_IDENTIFIER)
    private String gradeIdentifier;

    @JsonbProperty(JSON_GRADE_CLASS_IDENTIFIER)
    private String gradeClassIdentifier;

    @JsonbProperty(JSON_ECHELON_IDENTIFIER)
    private String echelonIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_INDICE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayIndexGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  public static class PayIndexGetManyResponseDto extends AbstractGetByPageResponseDto<PayIndexDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayIndexDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_INDICE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayIndexDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_INDICE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayIndexDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_INDICE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayIndexUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class PayIndexUpdateRequestDto extends ByIdentifierRequestDto
      implements PayIndexSaveRequestDto {

    @JsonbProperty(value = JSON_VALUE)
    private Integer value;

    @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
    private String payScaleIdentifier;


    @JsonbProperty(JSON_GRADE_IDENTIFIER)
    private String gradeIdentifier;

    @JsonbProperty(JSON_GRADE_CLASS_IDENTIFIER)
    private String gradeClassIdentifier;


    @JsonbProperty(JSON_ECHELON_IDENTIFIER)
    private String echelonIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_INDICE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayIndexDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
