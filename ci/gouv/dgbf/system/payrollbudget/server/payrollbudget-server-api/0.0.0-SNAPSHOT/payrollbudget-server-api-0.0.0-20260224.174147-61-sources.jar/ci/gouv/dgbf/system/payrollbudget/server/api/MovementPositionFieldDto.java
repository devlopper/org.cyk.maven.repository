package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de position de {@link MovementPositionFieldDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementPositionFieldDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link MovementDto}.
   */
  @JsonbProperty(JSON_MOVEMENT_IDENTIFIER)
  private String movementIdentifier;

  /**
   * Représentation en chaine de caractères de {@link MovementDto}.
   */
  @JsonbProperty(JSON_MOVEMENT_AS_STRING)
  private String movementAsString;

  /**
   * {@link PositionField}.
   */
  @JsonbProperty(JSON_POSITION_FIELD)
  private PositionField positionField;

  /**
   * Représentation en chaine de caractères de {@link PositionField}.
   */
  @JsonbProperty(JSON_POSITION_FIELD_AS_STRING)
  private String positionFieldAsString;

  /**
   * Référence.
   */
  @JsonbProperty(JSON_REFERENCE)
  private String reference;

  /**
   * Libellé de la référence.
   */
  @JsonbProperty(JSON_REFERENCE_NAME)
  private String referenceName;
  
  /**
   * Identifiant json de identifiant de {@link MovementPositionFieldDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idChampPositionMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementPositionFieldDto}.
   */
  public static final String JSON_THIS_AS_STRING = "champPositionMouvementChaine";

  /**
   * Identifiant json de {@link #movementIdentifier}.
   */
  public static final String JSON_MOVEMENT_IDENTIFIER =
      MovementDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #movementAsString}.
   */
  public static final String JSON_MOVEMENT_AS_STRING =
      MovementDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #positionField}.
   */
  public static final String JSON_POSITION_FIELD = "champPosition";

  /**
   * Identifiant json de {@link #positionFieldAsString}.
   */
  public static final String JSON_POSITION_FIELD_AS_STRING = JSON_POSITION_FIELD + "Chaine";

  /**
   * Identifiant json de {@link #reference}.
   */
  public static final String JSON_REFERENCE = "reference";

  /**
   * Identifiant json de {@link #referenceName}.
   */
  public static final String JSON_REFERENCE_NAME = "nomReference";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "champ de position de mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "champs de position de mouvement";
}
