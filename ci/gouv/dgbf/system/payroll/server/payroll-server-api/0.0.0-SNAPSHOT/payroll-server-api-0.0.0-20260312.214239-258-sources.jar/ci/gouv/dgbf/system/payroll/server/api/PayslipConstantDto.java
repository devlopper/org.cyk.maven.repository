package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollConstantAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollConstantIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link PayrollConstantDto} de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipConstantDto extends AbstractIdentifiableAuditableDto
    implements HasPayslipIdentifierDto, HasPayslipAsStringDto, HasPayrollConstantIdentifierDto,
    HasPayrollConstantAsStringDto, HasValueDto<Integer>, HasValueAsStringDto {

  @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
  private String payslipIdentifier;

  @JsonbProperty(JSON_PAYSLIP_AS_STRING)
  private String payslipAsString;

  @JsonbProperty(JSON_PAYROLL_CONSTANT_IDENTIFIER)
  private String payrollConstantIdentifier;

  @JsonbProperty(JSON_PAYROLL_CONSTANT_AS_STRING)
  private String payrollConstantAsString;

  @JsonbProperty(JSON_VALUE)
  private Integer value;

  @JsonbProperty(JSON_VALUE_AS_STRING)
  private String valueAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idConstanteBulletinPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "constanteBulletinPaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "constante de bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "constantes de bulletin de paie";
}
