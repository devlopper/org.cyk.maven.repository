package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;

/**
 * Cette classe représente un domaine de compétence.
 *
 * @author Desysoft
 *
 */
public class ExpertiseDomainDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "domaine de compétence";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "domaines de compétence";


  /**
   * Identifiant json de identifiant de {@link ExpertiseDomainDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "identifiantDomaineExpertise";


  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExpertiseDomainDto}.
   */
  public static final String JSON_THIS_AS_STRING = "DomaineExpertiseChaine";
}
