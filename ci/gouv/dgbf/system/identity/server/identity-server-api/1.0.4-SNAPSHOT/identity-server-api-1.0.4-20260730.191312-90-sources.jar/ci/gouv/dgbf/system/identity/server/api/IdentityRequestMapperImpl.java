package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T19:13:33+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityRequestMapperImpl implements IdentityRequestMapper {

    @Override
    public IdentityService.IdentityCreateRequestDto mapCreate(IdentityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityService.IdentityCreateRequestDto identityCreateRequestDto = new IdentityService.IdentityCreateRequestDto();

        identityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityCreateRequestDto.setFirstName( arg0.getFirstName() );
        identityCreateRequestDto.setLastNames( arg0.getLastNames() );
        identityCreateRequestDto.setEmailAddress( arg0.getEmailAddress() );
        identityCreateRequestDto.setGenderIdentifier( arg0.getGenderIdentifier() );
        identityCreateRequestDto.setIsGenderMasculine( arg0.getIsGenderMasculine() );
        identityCreateRequestDto.setBirthDate( arg0.getBirthDate() );
        identityCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        identityCreateRequestDto.setRegistrationNumberGroupIdentifier( arg0.getRegistrationNumberGroupIdentifier() );
        identityCreateRequestDto.setIsRegistrationNumberGroupPublicFunction( arg0.getIsRegistrationNumberGroupPublicFunction() );
        identityCreateRequestDto.setRegistrationNumber( arg0.getRegistrationNumber() );

        return identityCreateRequestDto;
    }

    @Override
    public IdentityService.IdentityUpdateRequestDto mapUpdate(IdentityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityService.IdentityUpdateRequestDto identityUpdateRequestDto = new IdentityService.IdentityUpdateRequestDto();

        identityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identityUpdateRequestDto.setFirstName( arg0.getFirstName() );
        identityUpdateRequestDto.setLastNames( arg0.getLastNames() );
        identityUpdateRequestDto.setEmailAddress( arg0.getEmailAddress() );
        identityUpdateRequestDto.setGenderIdentifier( arg0.getGenderIdentifier() );
        identityUpdateRequestDto.setIsGenderMasculine( arg0.getIsGenderMasculine() );
        identityUpdateRequestDto.setBirthDate( arg0.getBirthDate() );
        identityUpdateRequestDto.setRegistrationNumberGroupIdentifier( arg0.getRegistrationNumberGroupIdentifier() );
        identityUpdateRequestDto.setIsRegistrationNumberGroupPublicFunction( arg0.getIsRegistrationNumberGroupPublicFunction() );
        identityUpdateRequestDto.setRegistrationNumber( arg0.getRegistrationNumber() );
        identityUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );

        return identityUpdateRequestDto;
    }

    @Override
    public IdentityService.IdentityDeclareRequestDto mapDeclare(IdentityDto identity) {
        if ( identity == null ) {
            return null;
        }

        IdentityService.IdentityDeclareRequestDto identityDeclareRequestDto = new IdentityService.IdentityDeclareRequestDto();

        identityDeclareRequestDto.setAuditWho( identity.getAuditWho() );
        identityDeclareRequestDto.setAuditSession( identity.getAuditSession() );
        identityDeclareRequestDto.setFirstName( identity.getFirstName() );
        identityDeclareRequestDto.setLastNames( identity.getLastNames() );
        identityDeclareRequestDto.setEmailAddress( identity.getEmailAddress() );
        identityDeclareRequestDto.setGenderIdentifier( identity.getGenderIdentifier() );
        identityDeclareRequestDto.setIsGenderMasculine( identity.getIsGenderMasculine() );
        identityDeclareRequestDto.setBirthDate( identity.getBirthDate() );
        identityDeclareRequestDto.setAdministrativeUnitIdentifier( identity.getAdministrativeUnitIdentifier() );

        return identityDeclareRequestDto;
    }
}
