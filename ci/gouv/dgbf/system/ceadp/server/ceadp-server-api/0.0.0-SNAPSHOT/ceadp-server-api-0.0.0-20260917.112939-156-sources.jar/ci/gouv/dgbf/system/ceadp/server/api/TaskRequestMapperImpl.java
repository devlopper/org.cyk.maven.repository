package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TaskDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TaskRequestMapperImpl implements TaskRequestMapper {

    @Override
    public TaskService.TaskCreateRequestDto mapCreate(TaskDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TaskService.TaskCreateRequestDto taskCreateRequestDto = new TaskService.TaskCreateRequestDto();

        taskCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        taskCreateRequestDto.setName( arg0.getName() );
        taskCreateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        taskCreateRequestDto.setFromDate( arg0.getFromDate() );
        taskCreateRequestDto.setToDate( arg0.getToDate() );
        taskCreateRequestDto.setDescription( arg0.getDescription() );
        taskCreateRequestDto.setCreationDate( arg0.getCreationDate() );
        taskCreateRequestDto.setExecutionAdministrativeUnitIdentifier( arg0.getExecutionAdministrativeUnitIdentifier() );

        return taskCreateRequestDto;
    }

    @Override
    public TaskService.TaskUpdateRequestDto mapUpdate(TaskDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TaskService.TaskUpdateRequestDto taskUpdateRequestDto = new TaskService.TaskUpdateRequestDto();

        taskUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        taskUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        taskUpdateRequestDto.setName( arg0.getName() );
        taskUpdateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        taskUpdateRequestDto.setFromDate( arg0.getFromDate() );
        taskUpdateRequestDto.setToDate( arg0.getToDate() );
        taskUpdateRequestDto.setDescription( arg0.getDescription() );
        taskUpdateRequestDto.setCreationDate( arg0.getCreationDate() );
        taskUpdateRequestDto.setExecutionAdministrativeUnitIdentifier( arg0.getExecutionAdministrativeUnitIdentifier() );

        return taskUpdateRequestDto;
    }
}
