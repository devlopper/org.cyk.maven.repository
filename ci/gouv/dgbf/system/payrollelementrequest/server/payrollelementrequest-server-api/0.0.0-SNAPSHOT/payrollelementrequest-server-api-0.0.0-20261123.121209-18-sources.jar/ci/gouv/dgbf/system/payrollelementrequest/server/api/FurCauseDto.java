package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une cause d'anomalie du FUR : le code est celui de la cause, le libellé
 * est celui sous lequel la simulation regroupe les lignes concernées, et le motif est le texte
 * enregistré avec chaque ligne laissée de côté, auquel s'ajoute le détail propre à la ligne.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurCauseDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Début du motif enregistré avec la ligne.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * {@code true} si la cause écarte la ligne de la version finale du FUR ; sinon la ligne est
   * conservée, sans réclamation.
   */
  @JsonbProperty(JSON_SET_ASIDE)
  private Boolean setAside;

  /**
   * Explication donnée à l'utilisateur sur les lignes de cette cause.
   */
  @JsonbProperty(JSON_ADVICE)
  private String advice;

  /**
   * {@code true} si la ligne d'une anomalie de cette cause peut être forcée par dérogation malgré
   * le refus du contrôle.
   */
  @JsonbProperty(JSON_FORCEABLE)
  private Boolean forceable;

  /**
   * Identifiant json {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json {@link #setAside}.
   */
  public static final String JSON_SET_ASIDE = "ecartee";

  /**
   * Identifiant json {@link #advice}.
   */
  public static final String JSON_ADVICE = "conseil";

  /**
   * Identifiant json {@link #forceable}.
   */
  public static final String JSON_FORCEABLE = "forcable";

  /**
   * Identifiant json de identifiant de {@link FurCauseDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCauseFur";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FurCauseDto}.
   */
  public static final String JSON_THIS_AS_STRING = "causeFurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "cause d'anomalie du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "causes d'anomalie du FUR";
}
