package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupClient;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RegistrationNumberGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class RegistrationNumberGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<RegistrationNumberGroupDto,
        RegistrationNumberGroupGetManyResponseDto, RegistrationNumberGroupClient> {

  @Inject
  @Getter
  RegistrationNumberGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected RegistrationNumberGroupSelectOneController() {
    super(RegistrationNumberGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
