package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  /**
   * Super administrateur.
   */
  SUPER_ADMINISTRATOR("SUPER_ADMINISTRATEUR")
  
  ;
  
  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;
}
