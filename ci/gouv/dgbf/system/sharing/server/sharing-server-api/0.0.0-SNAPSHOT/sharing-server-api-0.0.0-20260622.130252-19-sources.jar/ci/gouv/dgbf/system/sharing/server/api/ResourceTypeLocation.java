package ci.gouv.dgbf.system.sharing.server.api;

import lombok.EqualsAndHashCode;
import lombok.Getter;

/**
 * Cette classe représente un couple {@link ResourceType} et {@link Location}.
 *
 * @author Christian
 *
 */
@EqualsAndHashCode(of = {"resourceType", "location"})
public class ResourceTypeLocation {

  /**
   * {@link ResourceType}.
   */
  @Getter
  ResourceType resourceType;

  /**
   * {@link Location}.
   */
  @Getter
  Location location;

  /**
   * Cette méthode permet d'instantier.
   *
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   */
  public ResourceTypeLocation(ResourceType resourceType, Location location) {
    this.resourceType = resourceType;
    this.location = location;
  }
}
