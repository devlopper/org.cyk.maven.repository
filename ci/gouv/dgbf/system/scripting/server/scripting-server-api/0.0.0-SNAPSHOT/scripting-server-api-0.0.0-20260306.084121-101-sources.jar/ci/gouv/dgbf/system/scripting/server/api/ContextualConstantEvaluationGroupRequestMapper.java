package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ContextualConstantEvaluationGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et. 
    {@link ContextualConstantEvaluationGroupDto}.

    @author Arnaud
               """)
public interface ContextualConstantEvaluationGroupRequestMapper extends
    RequestMapper<ContextualConstantEvaluationGroupDto,
    ContextualConstantEvaluationGroupCreateRequestDto, 
    ContextualConstantEvaluationGroupUpdateRequestDto> {
}
