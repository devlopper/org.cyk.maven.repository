package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un effectif d'unité administrative.
 *
 * @author parfait
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetAdministrativeUnitStaffDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  String exerciseAsString;

  /**
   * Identifiant de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  String administrativeUnitAsString;

  /**
   * Identifiant de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING)
  String budgetAdministrativeUnitAsString;

  /**
   * Identifiant de l'emploi.
   */
  @JsonbProperty(JSON_JOB_IDENTIFIER)
  String jobIdentifier;

  /**
   * Représentation en chaine de caractères de l'emploi.
   */
  @JsonbProperty(JSON_JOB_AS_STRING)
  String jobAsString;
  
  /**
   * Compétence demandée.
   */
  @JsonbProperty(JSON_COMPETENCE)
  String competence;
 
  /**
   * Identifiant de la catégorie de employé.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  String categoryIdentifier;

  /**
   * Représentation en chaine de caractères de la catégorie de employé.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  String categoryAsString;
  
  /**
   * employé est fonctionnaire.
   */
  @JsonbProperty(JSON_IS_FUNCTIONARY)
  Boolean isFunctionary;

  /**
   * Représentation en chaine de caractères employé est fonctionnaire.
   */
  @JsonbProperty(JSON_IS_FUNCTIONARY_AS_STRING)
  String isFunctionaryAsString;
  
  /**
   * Effectif.
   */
  @JsonbProperty(JSON_STAFF)
  Integer staff;
  
  /**
   * Représentation en chaine de caractères de l'effectif.
   */
  @JsonbProperty(JSON_STAFF_AS_STRING)
  String staffAsString;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  Integer amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;
  
  /**
   * Identifiant json de identifiant de {@link BudgetAdministrativeUnitStaffDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBudgetUniteAdministrativeEffectif";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link BudgetAdministrativeUnitStaffDto}.
   */
  public static final String JSON_THIS_AS_STRING = "budgetUniteAdministrativeEffectifChaine";

  /**
   * Identifiant json {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_ADMINISTRATIVE_UNIT_AS_STRING;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitAsString}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #jobIdentifier}.
   */
  public static final String JSON_JOB_IDENTIFIER = "idEmploi";

  /**
   * Identifiant json {@link #jobAsString}.
   */
  public static final String JSON_JOB_AS_STRING = "emploiChaine";

  /**
   * Identifiant json {@link #competence}.
   */
  public static final String JSON_COMPETENCE = "competence";
  
  /**
   * Identifiant json {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER =
      AdministrativeUnitEmployeeCategoryDto.JSON_EMPLOYEE_CATEGORY_IDENTIFIER;

  /**
   * Identifiant json {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING =
      AdministrativeUnitEmployeeCategoryDto.JSON_EMPLOYEE_CATEGORY_AS_STRING;

  /**
   * Identifiant json {@link #isFunctionary}.
   */
  public static final String JSON_IS_FUNCTIONARY = "estFonctionnaire";

  /**
   * Identifiant json {@link #isFunctionaryAsString}.
   */
  public static final String JSON_IS_FUNCTIONARY_AS_STRING = "estFonctionnaireChaine";

  /**
   * Identifiant json {@link #staff}.
   */
  public static final String JSON_STAFF = "effectif";

  /**
   * Identifiant json {@link #staffAsString}.
   */
  public static final String JSON_STAFF_AS_STRING = "effectifChaine";

  /**
   * Identifiant json {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "effectif d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "effectifs d'unité administrative";
}
