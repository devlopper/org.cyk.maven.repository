package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.report.server.api.ReportDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
@Named
@ViewScoped
public class ReportListPage extends AbstractPage {

  @Inject
  @Getter
  ReportController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ReportDto.NAME;
  }

  public static final String OUTCOME = "reportListPage";
}

