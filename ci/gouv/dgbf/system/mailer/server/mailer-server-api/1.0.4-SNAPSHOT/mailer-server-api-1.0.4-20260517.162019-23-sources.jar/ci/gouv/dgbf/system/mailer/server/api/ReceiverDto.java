package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un destinataire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReceiverDto extends AbstractIdentifiableAuditableDto {

  @JsonbProperty(value = JSON_MAIL_IDENTIFIER)
  public String mailIdentifier;
  
  @JsonbProperty(value = JSON_ADDRESS)
  public String address;
  
  public static final String JSON_MAIL_IDENTIFIER = "idMail";
  public static final String JSON_ADDRESS = "adresse";
}
