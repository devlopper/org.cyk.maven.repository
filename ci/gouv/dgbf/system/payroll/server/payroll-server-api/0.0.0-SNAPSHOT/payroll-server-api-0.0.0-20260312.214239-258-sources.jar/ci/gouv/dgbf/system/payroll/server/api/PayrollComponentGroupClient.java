package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentGroupService.PayrollComponentGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentGroupService.PayrollComponentGroupGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentGroupService.PayrollComponentGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollComponentGroupService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollComponentGroupClient extends AbstractClient<PayrollComponentGroupService>
    implements GetByIdentifier<PayrollComponentGroupDto>, 
               GetMany<PayrollComponentGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollComponentGroupClient service(PayrollComponentGroupService service) {
    return (PayrollComponentGroupClient) super.service(service);
  }

  /**
   * {@link PayrollComponentGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollComponentGroupCreateRequestDto request) {
    return new CreateExecutor(PayrollComponentGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollComponentGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollComponentGroupGetManyResponseDto>(
        PayrollComponentGroupGetManyResponseDto.class,
        PayrollComponentGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }


  /**
   * {@link PayrollComponentGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public PayrollComponentGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollComponentGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollComponentGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollComponentGroupDto>(PayrollComponentGroupDto.class,
        PayrollComponentGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollComponentGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollComponentGroupDto getOne(ProjectionDto projection, 
          FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollComponentGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollComponentGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollComponentGroupDto>(PayrollComponentGroupDto.class,
        PayrollComponentGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollComponentGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollComponentGroupDto getByIdentifier(String identifier, 
             ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollComponentGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollComponentGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollComponentGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollComponentGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollComponentGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
