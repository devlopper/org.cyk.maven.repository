package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe avec une notion de filtre est EPN.
 *
 * @author Christian
 */
public interface FilterHasIsNationalPublicInstitution
    extends HasIsNationalPublicInstitution {

  /**
   * Cette méthode permet de mettre à jour est EPN.
   *
   * @param filter {@link FilterDto}
   */
  default void updateIsNationalPublicInstitution(FilterDto filter) {
    setIsNationalPublicInstitution(
        IsNationalPublicInstitutionFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour est EPN de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterIsNationalPublicInstitution(FilterDto filter) {
    IsNationalPublicInstitutionFilter.set(filter,
        getIsNationalPublicInstitution());
  }

}
