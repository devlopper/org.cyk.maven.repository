package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente le contrôleur de sélection de la nature du Réclamable ciblé par un
 * Réclamable de Type de Réclamation. Restreint à Élément de Paie/Constante de Paie (contrainte
 * {@code TA_TYPE_RECLAMATION_RECLAMABLE_NATURE_CK}) -- un Poste n'est jamais un Réclamable, retiré
 * du référentiel le 2026-08-27 (RG_REP_EFF_02).
 *
 * @author akm
 *
 */
@Dependent
public class ClaimTypeClaimableNatureSelectOneController extends AbstractSelectOneController {

  protected ClaimTypeClaimableNatureSelectOneController() {
    outputLableValue = "Nature de l'objet";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem(VALUE_ELEMENT_PAIE, "Element de Paie"),
        new SelectItem(VALUE_CONSTANTE_PAIE, "Constante de Paie"));
  }

  /**
   * Cette méthode permet d'obtenir le libellé correspondant à une valeur.
   *
   * @param value valeur
   * @return libellé, ou la valeur elle-même si aucune correspondance
   */
  public String labelOf(String value) {
    return computeSelectItemsWhenChoicable().stream()
        .filter(item -> Objects.equals(item.getValue(), value)).map(SelectItem::getLabel)
        .findFirst().orElse(value);
  }

  /**
   * Valeur désignant un Élément de Paie.
   */
  public static final String VALUE_ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Valeur désignant une Constante de Paie.
   */
  public static final String VALUE_CONSTANTE_PAIE = "CONSTANTE_PAIE";
}
