package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.GenderClient;
import ci.gouv.dgbf.system.identity.server.api.GenderDto;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link GenderDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class GenderSelectOneController
    extends AbstractSelectOneIdentifiableController<GenderDto,
        GenderGetManyResponseDto, GenderClient> {

  @Inject
  @Getter
  GenderClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected GenderSelectOneController() {
    super(GenderDto.class, SelectItemLabelStrategy.NAME);
  }
}
