package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'identité de déclarant.
 *
 * @author Christian
 */
public interface HasReporterIdentityIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité du déclarant.
   *
   * @return l'identifiant de l'identité du déclarant
   */
  String getReporterIdentityIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité du déclarant.
   *
   * @param reporterIdentityIdentifier l'identifiant de l'identité du déclarant
   */
  void setReporterIdentityIdentifier(String reporterIdentityIdentifier);

  /**
   * Identifiant java de l'identifiant de l'identité du déclarant.
   */
  String FIELD_REPORTER_IDENTITY_IDENTIFIER = "reporterIdentityIdentifier";
}
