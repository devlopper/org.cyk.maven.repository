package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SupplierDto}.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class SupplierFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SupplierFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SupplierFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;
}
