package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.Email;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une réclamation d'élément de paie.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto,
    HasStatusDto<PayrollElementClaimStatus>, HasStatusAsStringDto, HasEmailAddressDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Statut courant du cycle de vie de la réclamation (RG_REP_STA_01).
   */
  @JsonbProperty(JSON_STATUS)
  private PayrollElementClaimStatus status;

  /**
   * Représentation en chaine de caractères de {@link #status}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Nature de la réclamation -- Ordinaire ou Contentieux (référentiel
   * {@code TR_NATURE_RECLAMATION}), simple discriminant classificatoire sans effet sur son
   * traitement.
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant du Fonctionnaire ou Agent de l'État concerné par la réclamation, module
   * {@code functionary} -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_CONCERNED_FUNCTIONARY_IDENTIFIER)
  private String concernedFunctionaryIdentifier;

  /**
   * Instantané (pas une référence vivante) de la structure du FAE concerné choisie à la
   * soumission ({@code FunctionaryDto#getStructures()}) -- {@code null} si le FAE n'a qu'une
   * structure ou si la réclamation ne passe pas par l'annuaire (ex. "Ma fonction").
   */
  @JsonbProperty(JSON_CONCERNED_STRUCTURE)
  private Map<String, String> concernedStructure;

  /**
   * Identifiant de l'émetteur de la réclamation, module {@code identity} -- sans FK (couplage
   * faible).
   */
  @JsonbProperty(JSON_ISSUER_IDENTIFIER)
  private String issuerIdentifier;

  /**
   * Identifiant du Groupe de Documents constituant le dossier de pièces de la réclamation, module
   * {@code documentation} -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_DOCUMENTS_GROUP_IDENTIFIER)
  private String documentsGroupIdentifier;

  /**
   * Identifiant de l'agent de traitement actuellement en charge de la réclamation -- vide avant
   * sa Prise en charge.
   */
  @JsonbProperty(JSON_PROCESSING_AGENT_IDENTIFIER)
  private String processingAgentIdentifier;

  /**
   * Date de création de la réclamation.
   */
  @JsonbProperty(JSON_CREATION_DATE)
  private LocalDateTime creationDate;

  /**
   * Commentaire libre de l'Émetteur, facultatif.
   */
  @JsonbProperty(JSON_COMMENT)
  private String comment;

  /**
   * Adresse email de contact, facultative -- instantané figé à la Soumission (pré-rempli depuis
   * {@code VA_FONCTIONNAIRE} si connue pour le FAE concerné), jamais mis à jour ensuite.
   */
  @Email
  @JsonbProperty(JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Nombre de {@code ClaimedValueReview} encore à l'état Générée (projection calculée, jamais
   * une colonne réelle) -- portefeuille de l'Agent, onglet "Mes revues à transmettre"
   * (RU_REP_007/RU_REP_015).
   */
  @JsonbProperty(JSON_PENDING_REVIEWS_COUNT)
  private Long pendingReviewsCount;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #concernedFunctionaryIdentifier}.
   */
  public static final String JSON_CONCERNED_FUNCTIONARY_IDENTIFIER = "idFaeConcerne";

  /**
   * Identifiant json {@link #concernedStructure}.
   */
  public static final String JSON_CONCERNED_STRUCTURE = "structureConcernee";

  /**
   * Identifiant json {@link #issuerIdentifier}.
   */
  public static final String JSON_ISSUER_IDENTIFIER = "idEmetteur";

  /**
   * Identifiant json {@link #documentsGroupIdentifier}.
   */
  public static final String JSON_DOCUMENTS_GROUP_IDENTIFIER = "idDossierPieces";

  /**
   * Identifiant json {@link #processingAgentIdentifier}.
   */
  public static final String JSON_PROCESSING_AGENT_IDENTIFIER = "idAgentTraitement";

  /**
   * Identifiant json {@link #creationDate}.
   */
  public static final String JSON_CREATION_DATE = "dateCreation";

  /**
   * Identifiant json {@link #comment}.
   */
  public static final String JSON_COMMENT = "commentaire";

  /**
   * Identifiant json {@link #pendingReviewsCount}.
   */
  public static final String JSON_PENDING_REVIEWS_COUNT = "nombreRevuesEnAttente";

  /**
   * Identifiant json de identifiant de {@link PayrollElementClaimDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayrollElementClaimDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "réclamations";

  /**
   * Nature Ordinaire.
   */
  public static final String NATURE_ORDINARY = "ORDINAIRE";

  /**
   * Nature Contentieux.
   */
  public static final String NATURE_LITIGATION = "CONTENTIEUX";
}
