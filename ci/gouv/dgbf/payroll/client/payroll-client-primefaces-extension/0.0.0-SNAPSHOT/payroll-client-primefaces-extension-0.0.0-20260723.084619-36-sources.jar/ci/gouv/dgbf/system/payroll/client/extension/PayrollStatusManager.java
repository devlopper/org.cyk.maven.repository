package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.payroll.server.api.PayrollStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link PayrollStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class PayrollStatusManager extends AbstractStatusManager<PayrollStatus> {
  
  /**
   * Cette méthode permet d'instanctier.
   */
  public PayrollStatusManager() {
    super(PayrollStatus.class, e -> e.getName());
  }
}
