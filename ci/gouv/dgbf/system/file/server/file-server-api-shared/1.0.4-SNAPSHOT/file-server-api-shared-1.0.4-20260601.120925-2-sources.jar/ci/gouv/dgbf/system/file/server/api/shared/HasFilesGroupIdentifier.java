package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de groupe de fichiers.
 *
 * @author Christian
 */
public interface HasFilesGroupIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de fichiers.
   *
   * @return identifiant du groupe de fichiers
   */
  String getFilesGroupIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de fichiers.
   *
   * @param identifier identifiant du groupe de fichiers
   */
  void setFilesGroupIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant du groupe de fichiers.
   */
  String FIELD_FILES_GROUP_IDENTIFIER = "filesGroupIdentifier";
}
