package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'administrateurs.
 *
 * @author Christian Yao Komenan
 */
public interface HasAdministratorCountDto extends HasAdministratorCount {

  /**
   * Identifiant json du nombre d'administrateurs.
   */
  String JSON_ADMINISTRATOR_COUNT = "nombreAdministrateurs";
}
