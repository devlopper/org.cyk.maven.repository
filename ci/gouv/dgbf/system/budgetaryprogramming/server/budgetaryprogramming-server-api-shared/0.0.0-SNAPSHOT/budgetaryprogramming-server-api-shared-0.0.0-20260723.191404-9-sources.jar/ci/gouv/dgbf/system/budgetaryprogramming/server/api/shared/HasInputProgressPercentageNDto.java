package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le pourcentage de progression de la saisie
 * pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputProgressPercentageNDto extends HasInputProgressPercentageN {

  /**
   * Identifiant json du pourcentage de progression de la saisie pour l'année N.
   */
  String JSON_INPUT_PROGRESS_PERCENTAGE_N = "pourcentageProgressionSaisieN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName