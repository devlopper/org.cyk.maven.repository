package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.SessionManager;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeLocation;
import jakarta.servlet.FilterRegistration;
import jakarta.servlet.ServletContext;

/**
 * Cette interface représente la base d'écouteur d'évènement de l'application web.
 *
 * @author Christian
 *
 */
public interface SharingServletContextListener {

  /**
   * Cette méthode permet d'initialiser le contexte de partage.
   *
   * @param servletContext {@link ServletContext}
   * @param sessionManager {@link SessionManager}
   */
  default void initializeSharingContext(ServletContext servletContext,
      SessionManager sessionManager) {
    initializeSharingConnectedUserSharedResourceFilter(servletContext, sessionManager,
        ResourceType.ADMINISTRATIVE_UNIT, Location.BUDGETARY_CLASSIFICATION);
  }

  /**
   * Cette méthode permet d'initialiser le filtre de {@link ResourceType} de {@link Location}
   * l'utilisateur connecté.
   *
   * @param servletContext {@link ServletContext}
   * @param sessionManager {@link SessionManager}
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   */
  default void initializeSharingConnectedUserSharedResourceFilter(ServletContext servletContext,
      SessionManager sessionManager, ResourceType resourceType, Location location) {
    ConnectedUserSharedResourceFilter filter =
        instantiateSharingFilter(sessionManager, resourceType, location);

    FilterRegistration.Dynamic registration =
        servletContext.addFilter(ConnectedUserSharedResourceFilter.class.getSimpleName(), filter);

    processSharingFilterRegistration(resourceType, location, registration);
  }

  /**
   * Cette méthode permet de traiter le filtre.
   *
   * @param sessionManager {@link SessionManager}
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   * @return {@link ConnectedUserSharedResourceFilter}
   */
  default ConnectedUserSharedResourceFilter instantiateSharingFilter(SessionManager sessionManager,
      ResourceType resourceType, Location location) {
    return new ConnectedUserSharedResourceFilter(sessionManager,
        new ResourceTypeLocation(resourceType, location));
  }

  /**
   * Cette méthode permet de traiter le filtre.
   *
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   * @param registration {@link FilterRegistration.Dynamic}
   */
  default void processSharingFilterRegistration(ResourceType resourceType, Location location,
      FilterRegistration.Dynamic registration) {
    registration.addMappingForUrlPatterns(null, false,
        getSharingFilterRegistrationMappingForUrlPatterns(resourceType, location, registration));
  }

  /**
   * Cette méthode permet d'obtenir le tableau des motifs d'urls.
   *
   * @param resourceType {@link ResourceType}
   * @param location {@link Location}
   * @param registration {@link FilterRegistration.Dynamic}
   * @return tableau des motifs d'urls
   */
  default String[] getSharingFilterRegistrationMappingForUrlPatterns(ResourceType resourceType,
      Location location, FilterRegistration.Dynamic registration) {
    return new String[] {"/private/*"};
  }
}
