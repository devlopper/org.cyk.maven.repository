package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Passage de l'{@link ArbitrationTeamDto} de l'écran aux requêtes du service.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-08T21:37:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ArbitrationTeamRequestMapperImpl implements ArbitrationTeamRequestMapper {

    @Override
    public ArbitrationTeamService.ArbitrationTeamCreateRequestDto mapCreate(ArbitrationTeamDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ArbitrationTeamService.ArbitrationTeamCreateRequestDto arbitrationTeamCreateRequestDto = new ArbitrationTeamService.ArbitrationTeamCreateRequestDto();

        arbitrationTeamCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        arbitrationTeamCreateRequestDto.setCode( arg0.getCode() );
        arbitrationTeamCreateRequestDto.setName( arg0.getName() );
        arbitrationTeamCreateRequestDto.setExercise( arg0.getExercise() );
        arbitrationTeamCreateRequestDto.setLeader( arg0.getLeader() );
        arbitrationTeamCreateRequestDto.setActive( arg0.getActive() );

        return arbitrationTeamCreateRequestDto;
    }

    @Override
    public ArbitrationTeamService.ArbitrationTeamUpdateRequestDto mapUpdate(ArbitrationTeamDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ArbitrationTeamService.ArbitrationTeamUpdateRequestDto arbitrationTeamUpdateRequestDto = new ArbitrationTeamService.ArbitrationTeamUpdateRequestDto();

        arbitrationTeamUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        arbitrationTeamUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        arbitrationTeamUpdateRequestDto.setCode( arg0.getCode() );
        arbitrationTeamUpdateRequestDto.setName( arg0.getName() );
        arbitrationTeamUpdateRequestDto.setExercise( arg0.getExercise() );
        arbitrationTeamUpdateRequestDto.setLeader( arg0.getLeader() );
        arbitrationTeamUpdateRequestDto.setActive( arg0.getActive() );

        return arbitrationTeamUpdateRequestDto;
    }
}
