package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollDto}.
 *
 * @author A.K.M
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollDto}.

    @author A.K.M
               """)
public interface PayrollRequestMapper
    extends RequestMapper<PayrollDto, PayrollCreateRequestDto, PayrollUpdateRequestDto> {

}
