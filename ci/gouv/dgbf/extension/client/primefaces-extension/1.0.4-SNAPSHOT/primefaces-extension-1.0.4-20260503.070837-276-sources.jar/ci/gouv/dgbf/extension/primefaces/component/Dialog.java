package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un dialogue.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Dialog extends AbstractWidget {

  String header;
  Integer width;
  Integer height;
}
