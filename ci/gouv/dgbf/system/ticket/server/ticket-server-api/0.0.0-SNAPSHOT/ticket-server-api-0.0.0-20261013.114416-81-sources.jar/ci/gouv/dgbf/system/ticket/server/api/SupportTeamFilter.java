package ci.gouv.dgbf.system.ticket.server.api;


import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDomainIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUsersGroupIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SupportTeamDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class SupportTeamFilter extends AbstractIdentifiableFilter
      implements FilterHasUsersGroupIdentifier, FilterHasUserName, FilterHasDomainIdentifier {

  private String usersGroupIdentifier;

  /**
   * Nom d'utilisateur (login) de l'utilisateur.
   */
  private String userName;

  /**
   * Identifiant du domaine fonctionnel : équipes rattachées à ce domaine.
   */
  private String domainIdentifier;

  /**
   * Cette méthode permet de construire.
   *
   * @param dto {@link FilterDto}
   */
  public SupportTeamFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet de construire.
   */
  public SupportTeamFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateUsersGroupIdentifier(filter);
    updateUserName(filter);
    updateDomainIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterUsersGroupIdentifier(filter);
    updateFilterUserName(filter);
    updateFilterDomainIdentifier(filter);
  }

}
