package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la configuration d'un filtrage en cascade entre deux Réclamables
 * Élément de Paie : une fois la valeur du Réclamable {@link #parentClaimableIdentifier} connue
 * (nouvelle valeur réclamée, ou valeur actuelle du fonctionnaire si ce Réclamable n'est pas une
 * Cible du Type en cours), la chaîne de sauts configurée ({@code ClaimableCascadeHopDto})
 * détermine les valeurs valides du Réclamable {@link #childClaimableIdentifier}.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableCascadeDependencyDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant du Réclamable parent -- vraie FK vers le référentiel {@code Claimable}
   * ({@code TA_RECLAMABLE}, RG_REP_CIB_07).
   */
  @JsonbProperty(JSON_PARENT_CLAIMABLE_IDENTIFIER)
  private String parentClaimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #parentClaimableIdentifier} -- résolue côté
   * serveur (lecture directe de {@code Claimable}, même module).
   */
  @JsonbProperty(JSON_PARENT_CLAIMABLE_AS_STRING)
  private String parentClaimableAsString;

  /**
   * Identifiant du Réclamable enfant, dont les valeurs valides sont déterminées par le
   * résolveur -- vraie FK vers le référentiel {@code Claimable}.
   */
  @JsonbProperty(JSON_CHILD_CLAIMABLE_IDENTIFIER)
  private String childClaimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #childClaimableIdentifier} -- voir
   * {@link #parentClaimableAsString}.
   */
  @JsonbProperty(JSON_CHILD_CLAIMABLE_AS_STRING)
  private String childClaimableAsString;

  /**
   * Identifiant json {@link #parentClaimableIdentifier}.
   */
  public static final String JSON_PARENT_CLAIMABLE_IDENTIFIER = "idReclamableParent";

  /**
   * Identifiant json {@link #parentClaimableAsString}.
   */
  public static final String JSON_PARENT_CLAIMABLE_AS_STRING = "reclamableParentChaine";

  /**
   * Identifiant json {@link #childClaimableIdentifier}.
   */
  public static final String JSON_CHILD_CLAIMABLE_IDENTIFIER = "idReclamableEnfant";

  /**
   * Identifiant json {@link #childClaimableAsString}.
   */
  public static final String JSON_CHILD_CLAIMABLE_AS_STRING = "reclamableEnfantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "cascade de réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "cascades de réclamables";
}
