package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExpenditureSettlementDto}.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class ExpenditureSettlementFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * Identifiant de critère d'appartenance à un {@link TriennialProgramDto}.
   */
  String inTriennialProgramIdentifier;

  /**
   * Identifiant de critère de non appartenance à un {@link TriennialProgramDto}.
   */
  String notInTriennialProgramIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ExpenditureSettlementFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ExpenditureSettlementFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    inTriennialProgramIdentifier = getInTriennialProgramIdentifier(filter);
    notInTriennialProgramIdentifier = getNotInTriennialProgramIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setInTriennialProgramIdentifier(filter, inTriennialProgramIdentifier);
    setNotInTriennialProgramIdentifier(filter, notInTriennialProgramIdentifier);
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IN_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramDto}
   * pour lequel on veut vérifier l'appartenance de la liquidation.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link TriennialProgramDto}
   */
  public static void setInTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IN_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramDto}
   * pour lequel on veut vérifier l'appartenance de la liquidation.
   *
   * @param filter filtre
   * @return identifiant de {@link TriennialProgramDto}
   */
  public static String getInTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IN_TRIENNIAL_PROGRAM_IDENTIFIER));
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramDto}
   * pour lequel on veut vérifier la non appartenance de la liquidation.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link TriennialProgramDto}
   */
  public static void setNotInTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_NOT_IN_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramDto}
   * pour lequel on veut vérifier la non appartenance de la liquidation.
   *
   * @param filter filtre
   * @return identifiant de {@link TriennialProgramDto}
   */
  public static String getNotInTriennialProgramIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_NOT_IN_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #inTriennialProgramIdentifier}.
   */
  public static final String JSON_IN_TRIENNIAL_PROGRAM_IDENTIFIER = "EstDansCeProgrammeTriennal";


  /**
   * Identifiant json champ {@link #notInTriennialProgramIdentifier}.
   */
  public static final String JSON_NOT_IN_TRIENNIAL_PROGRAM_IDENTIFIER =
      "nestPasDansCeProgrammeTriennal";

}

