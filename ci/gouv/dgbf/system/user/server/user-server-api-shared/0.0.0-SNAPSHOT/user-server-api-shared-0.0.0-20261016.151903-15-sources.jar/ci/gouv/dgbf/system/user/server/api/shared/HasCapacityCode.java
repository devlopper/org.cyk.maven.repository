package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de code de capacité.
 *
 * @author Arnaud
 */
public interface HasCapacityCode extends HasField {

  /**
   * Cette méthode permet d'obtenir le code de la capacité.
   *
   * @return code de la capacité
   */
  String getCapacityCode();

  /**
   * Cette méthode permet d'assigner le code de la capacité.
   *
   * @param capacityCode code de la capacité
   */
  void setCapacityCode(String capacityCode);

  /**
   * Identifiant java du code de la capacité.
   */
  String FIELD_CAPACITY_CODE = "capacityCode";
}
