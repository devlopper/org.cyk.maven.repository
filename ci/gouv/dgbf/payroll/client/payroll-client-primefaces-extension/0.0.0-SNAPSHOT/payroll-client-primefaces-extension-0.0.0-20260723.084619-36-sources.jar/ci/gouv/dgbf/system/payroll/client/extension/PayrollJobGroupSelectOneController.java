package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollJobGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PayrollJobGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollJobGroupDto, PayrollJobGroupGetManyResponseDto, PayrollJobGroupClient> {

  @Getter
  @Inject
  PayrollJobGroupClient client;

  protected PayrollJobGroupSelectOneController() {
    super(PayrollJobGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
