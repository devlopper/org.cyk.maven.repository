package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de partition.
 *
 * @author Boobacool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PartitionTypeDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasValueSourceIdentifierDto,
    HasValueSourceAsStringDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_VALUE_SOURCE_IDENTIFIER)
  private String valueSourceIdentifier;

  @JsonbProperty(JSON_VALUE_SOURCE_AS_STRING)
  private String valueSourceAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypePartition";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "typePartitionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de partition";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de partition";
}
