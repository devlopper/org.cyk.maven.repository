package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailModelService.ProcedureDetailModelCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailModelService.ProcedureDetailModelGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailModelService.ProcedureDetailModelUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ProcedureDetailModelService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ProcedureDetailModelClient extends AbstractClient<ProcedureDetailModelService>
    implements GetByIdentifier<ProcedureDetailModelDto>,
    GetMany<ProcedureDetailModelGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ProcedureDetailModelClient service(ProcedureDetailModelService service) {
    return (ProcedureDetailModelClient) super.service(service);
  }

  /**
   * {@link ProcedureDetailModelService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcedureDetailModelCreateRequestDto request) {
    return new CreateExecutor(ProcedureDetailModelService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProcedureDetailModelService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByModel(
      ProcedureDetailModelService.ProcedureDetailCreateByProcedureDetailModelRequestDto request) {
    return new CreateExecutor(ProcedureDetailModelService.CREATE_IDENTIFIER)
        .execute(() -> service().createByModel(request));
  }

  /**
   * {@link ProcedureDetailModelService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureDetailModelGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcedureDetailModelGetManyResponseDto>(
        ProcedureDetailModelGetManyResponseDto.class,
        ProcedureDetailModelService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcedureDetailModelService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureDetailModelGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                                        PageDto page, String auditWho,
                                                        String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcedureDetailModelService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureDetailModelDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ProcedureDetailModelDto>(ProcedureDetailModelDto.class,
        ProcedureDetailModelService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProcedureDetailModelService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcedureDetailModelDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                                        String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ProcedureDetailModelService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ProcedureDetailModelDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ProcedureDetailModelDto>(ProcedureDetailModelDto.class,
        ProcedureDetailModelService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProcedureDetailModelService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureDetailModelDto getByIdentifier(String identifier, ProjectionDto projection,
                                                 String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ProcedureDetailModelService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcedureDetailModelUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcedureDetailModelService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcedureDetailModelService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProcedureDetailModelService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ProcedureDetailModelService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

