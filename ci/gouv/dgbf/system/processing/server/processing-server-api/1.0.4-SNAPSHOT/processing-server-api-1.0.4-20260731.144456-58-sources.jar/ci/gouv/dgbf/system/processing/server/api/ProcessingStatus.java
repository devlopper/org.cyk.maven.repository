package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente les statuts de {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum ProcessingStatus {

  /**
   * Créé.
   */
  CREATED(ProcessingStatusCode.CREATED, "Créé", "Créer", "create", "Création"),

  /**
   * Démarré.
   */
  STARTED(ProcessingStatusCode.STARTED, "Démarré", "Démarrer", "start", "Démarrage"),

  /**
   * Terminé.
   */
  TERMINATED(ProcessingStatusCode.TERMINATED, "Terminé", "Terminer", "terminate", "Terminaison"),

  /**
   * Arrêté.
   */
  STOPPED(ProcessingStatusCode.STOPPED, "Arrêté", "Arrêter", "stop", "Arrêt"),

  /**
   * Annulé.
   */
  CANCELLED(ProcessingStatusCode.CANCELLED, "Annulé", "Annuler", "cancel", "Annulation")

  ;

  private ProcessingStatus(String code, String name, String action, String actionCode,
      String actionName) {
    this.code = code;
    this.name = name;
    this.action = action;
    this.actionCode = actionCode;
    this.actionName = actionName;
  }

  /**
   * Code.
   */
  private String code;

  /**
   * Libellé.
   */
  @Setter
  private String name;

  /**
   * Action.
   */
  @Setter
  private String action;

  /**
   * Code de l'action.
   */
  @Setter
  private String actionCode;

  /**
   * Nom de l'action.
   */
  @Setter
  private String actionName;

  /**
   * Précédents.
   */
  private Set<ProcessingStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir un statut par code.
   *
   * @param code code
   * @return statut
   */
  public static ProcessingStatus getByCode(String code) {
    return Stream.of(ProcessingStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(
            () -> new IllegalArgumentException("Code traitement <<%s>> inconnu".formatted(code)));
  }

  /**
   * Cette méthode permet d'obtenir le code par le nom.
   *
   * @param name nom
   * @return code
   */
  public static String getCodeByName(String name) {
    if (Core.isStringBlank(name)) {
      return null;
    }
    for (ProcessingStatus status : ProcessingStatus.values()) {
      if (status.name().equals(name)) {
        return status.code;
      }
    }
    return null;
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link #CREATED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link #CREATED}
   */
  public static boolean isNameCreated(String name) {
    return Objects.equals(CREATED.name, name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link #STARTED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link #STARTED}
   */
  public static boolean isNameStarted(String name) {
    return Objects.equals(STARTED.name, name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link #STOPPED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link #STOPPED}
   */
  public static boolean isNameStopped(String name) {
    return Objects.equals(STOPPED.name, name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link #CANCELLED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link #CANCELLED}
   */
  public static boolean isNameCanceled(String name) {
    return Objects.equals(CANCELLED.name, name);
  }

  /**
   * Cette méthode permet de savoir si le nom du statut est {@link #TERMINATED}.
   *
   * @param name nom
   * @return vrai si le nom du statut est {@link #TERMINATED}
   */
  public static boolean isNameTerminated(String name) {
    return Objects.equals(TERMINATED.name, name);
  }

  static {
    CREATED.previous = Collections.emptySet();
    STARTED.previous = Core.getSet(List.of(CREATED, STOPPED));
    STOPPED.previous = Core.getSet(List.of(STARTED));
    CANCELLED.previous = Core.getSet(List.of(STOPPED));
    TERMINATED.previous = Core.getSet(List.of(STARTED));
  }
}
