package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateCategoriesRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FileGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FileGroupDto}.

    @author Christian
               """)
public interface FileGroupRequestMapper
    extends RequestMapper<FileGroupDto, FileGroupCreateRequestDto, FileGroupUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link FileGroupUpdateCategoriesRequestDto}.
   *
   * @param fileGroup {@link FileGroupDto}
   * @return {@link FileGroupUpdateCategoriesRequestDto}
   */
  FileGroupUpdateCategoriesRequestDto mapUpdateCategories(FileGroupDto fileGroup);
}
