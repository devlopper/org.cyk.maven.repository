package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Page d'index de lecture de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityReadIndexPage extends AbstractIdentityReadDatasPage {

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "identityReadIndexPage";
}
