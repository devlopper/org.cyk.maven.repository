package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link SubAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Path(SubAdministrativeUnitService.PATH)
@Tag(name = "Gestion des sous unités administratives")
public interface SubAdministrativeUnitService extends Service {

  /**
   * Chemin du service de gestion des identités.
   */
  String PATH = "sous-unites-administratives";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SubAdministrativeUnitCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface SubAdministrativeUnitSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de l'unité administrative.
     *
     * @return identifiant de l'unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'unité administrative.
     *
     * @param typeIdentifier identifiant de l'unité administrative
     */
    void setAdministrativeUnitIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir le libellé.
     *
     * @return le libellé
     */
    String getName();

    /**
     * Cette méthode permet d'assigner le libellé.
     *
     * @param name le libellé
     */
    void setName(String name);

    /**
     * Identifiant json champ identifiant de l'unité administrative.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        HasAdministrativeUnitIdentifierDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

    /**
     * {@link HasNameDto#JSON_NAME}.
     */
    String JSON_NAME = HasNameDto.JSON_NAME;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class SubAdministrativeUnitCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SubAdministrativeUnitSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_NAME)
    private String name;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class SubAdministrativeUnitGetManyResponseDto
      extends AbstractGetByPageResponseDto<SubAdministrativeUnitDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SubAdministrativeUnitDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SubAdministrativeUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SubAdministrativeUnitDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SubAdministrativeUnitUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class SubAdministrativeUnitUpdateRequestDto extends ByIdentifierRequestDto
      implements SubAdministrativeUnitSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_NAME)
    private String name;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SOUS_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
