package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de code de capacité.
 *
 * @author Arnaud
 */
public interface HasCapacityCodeDto extends HasCapacityCode {

  /**
   * Identifiant json du code de la capacité.
   */
  String JSON_CAPACITY_CODE = "codeCapacite";
}
