package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptRequestMapperImpl implements ScriptRequestMapper {

    @Override
    public ScriptService.ScriptCreateRequestDto mapCreate(ScriptDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptService.ScriptCreateRequestDto scriptCreateRequestDto = new ScriptService.ScriptCreateRequestDto();

        scriptCreateRequestDto.setCode( arg0.getCode() );
        scriptCreateRequestDto.setName( arg0.getName() );
        scriptCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        scriptCreateRequestDto.setEvaluatorIdentifier( arg0.getEvaluatorIdentifier() );
        scriptCreateRequestDto.setText( arg0.getText() );
        scriptCreateRequestDto.setResultType( arg0.getResultType() );

        return scriptCreateRequestDto;
    }

    @Override
    public ScriptService.ScriptUpdateRequestDto mapUpdate(ScriptDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptService.ScriptUpdateRequestDto scriptUpdateRequestDto = new ScriptService.ScriptUpdateRequestDto();

        scriptUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptUpdateRequestDto.setCode( arg0.getCode() );
        scriptUpdateRequestDto.setName( arg0.getName() );
        scriptUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        scriptUpdateRequestDto.setEvaluatorIdentifier( arg0.getEvaluatorIdentifier() );
        scriptUpdateRequestDto.setText( arg0.getText() );
        scriptUpdateRequestDto.setResultType( arg0.getResultType() );

        return scriptUpdateRequestDto;
    }
}
