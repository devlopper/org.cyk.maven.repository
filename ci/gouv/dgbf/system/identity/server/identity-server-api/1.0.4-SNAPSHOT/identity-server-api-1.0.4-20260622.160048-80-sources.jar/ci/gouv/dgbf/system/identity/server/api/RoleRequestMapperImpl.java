package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RoleDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T16:01:10+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RoleRequestMapperImpl implements RoleRequestMapper {

    @Override
    public RoleService.RoleCreateRequestDto mapCreate(RoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleService.RoleCreateRequestDto roleCreateRequestDto = new RoleService.RoleCreateRequestDto();

        roleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleCreateRequestDto.setCode( arg0.getCode() );
        roleCreateRequestDto.setName( arg0.getName() );

        return roleCreateRequestDto;
    }

    @Override
    public RoleService.RoleUpdateRequestDto mapUpdate(RoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleService.RoleUpdateRequestDto roleUpdateRequestDto = new RoleService.RoleUpdateRequestDto();

        roleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        roleUpdateRequestDto.setCode( arg0.getCode() );
        roleUpdateRequestDto.setName( arg0.getName() );

        return roleUpdateRequestDto;
    }
}
