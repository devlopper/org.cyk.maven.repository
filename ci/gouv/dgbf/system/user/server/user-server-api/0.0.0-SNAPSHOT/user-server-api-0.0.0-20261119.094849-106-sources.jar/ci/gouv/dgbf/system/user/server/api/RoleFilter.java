package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RoleDto}. Hérite des critères de code du framework
 * (code, code exclu, codes exclus) : les listes de choix des écrans d'attribution et de demande
 * de rôle excluent ainsi les Rôles réservés ({@link ReservedRole#CODES}, RG_UTI_ROL_17).
 *
 * @author Arnaud
 */
@Getter
@Setter
public class RoleFilter extends AbstractIdentifiableCodableFilter {


  /**
   * Identifiant de l'application pour filtrer les rôles. Si renseigné, retourne uniquement les
   * rôles de cette application.
   */
  private String applicationIdentifier;

  /**
   * Code de l'application pour filtrer les rôles. Si renseigné, retourne uniquement les rôles de
   * l'application portant ce code.
   */
  private String applicationCode;

  /**
   * Identifiant de l'utilisateur pour filtrer les rôles NON assignés. Si renseigné, retourne
   * uniquement les rôles que cet utilisateur n'a PAS.
   */
  private String unassignedUserIdentifier;

  /**
   * Identifiant de l'utilisateur pour filtrer les rôles assignés. Si renseigné, retourne uniquement
   * les rôles que cet utilisateur possède.
   */
  private String assignedUserIdentifier;

  /**
   * Nom.
   */
  private String name;

  /**
   * Nom contenant.
   */
  private String nameContains;

  /**
   * Code de la Nature pour filtrer les rôles ({@link RoleNatureCode}). Si renseigné, retourne
   * uniquement les rôles de cette Nature.
   */
  private String natureCode;

  /**
   * Indicateur Demandable pour filtrer les rôles. Si renseigné, retourne uniquement les
   * rôles dont l'indicateur Demandable correspond.
   */
  private Boolean requestable;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RoleFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RoleFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    applicationIdentifier = getApplicationIdentifier(filter);
    applicationCode = getApplicationCode(filter);
    unassignedUserIdentifier = getUnassignedUserIdentifier(filter);
    assignedUserIdentifier = getAssignedUserIdentifier(filter);
    name = getName(filter);
    nameContains = getNameContains(filter);
    natureCode = getNatureCode(filter);
    requestable = getRequestable(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setApplicationIdentifier(filter, applicationIdentifier);
    setApplicationCode(filter, applicationCode);
    setUnassignedUserIdentifier(filter, unassignedUserIdentifier);
    setAssignedUserIdentifier(filter, assignedUserIdentifier);
    setName(filter, name);
    setNameContains(filter, nameContains);
    setNatureCode(filter, natureCode);
    setRequestable(filter, requestable);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur pour les rôles NON assignés.
   *
   * @param filter                   filtre
   * @param unassignedUserIdentifier identifiant de l'utilisateur
   */
  public static void setUnassignedUserIdentifier(FilterDto filter,
                                                 String unassignedUserIdentifier) {
    set(filter, JSON_UNASSIGNED_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(unassignedUserIdentifier));
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur pour les rôles NON assignés.
   *
   * @param filter filtre
   * @return identifiant de l'utilisateur
   */
  public static String getUnassignedUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_UNASSIGNED_USER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur pour les rôles assignés.
   *
   * @param filter                 filtre
   * @param assignedUserIdentifier identifiant de l'utilisateur
   */

  public static void setAssignedUserIdentifier(FilterDto filter, String assignedUserIdentifier) {
    set(filter, JSON_ASSIGNED_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(assignedUserIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur pour les rôles assignés.
   *
   * @param filter filtre
   * @return identifiant de l'utilisateur
   */
  public static String getAssignedUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ASSIGNED_USER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param name   nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * assigner l'id app.
   *
   * @param filter                filtre
   * @param applicationIdentifier id app.
   */
  public static void setApplicationIdentifier(FilterDto filter, String applicationIdentifier) {
    set(filter, JSON_APPLICATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(applicationIdentifier));
  }

  /**
   * obtenir id app.
   *
   * @param filter filtre
   * @return id app.
   */
  public static String getApplicationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_APPLICATION_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de l'application.
   *
   * @param filter          filtre
   * @param applicationCode code de l'application
   */
  public static void setApplicationCode(FilterDto filter, String applicationCode) {
    set(filter, JSON_APPLICATION_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(applicationCode));
  }

  /**
   * Cette méthode permet d'obtenir le code de l'application.
   *
   * @param filter filtre
   * @return code de l'application
   */
  public static String getApplicationCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_APPLICATION_CODE));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter       filtre
   * @param nameContains nom
   */
  public static void setNameContains(FilterDto filter, String nameContains) {
    set(filter, JSON_NAME_CONTAINS, f -> f.getValueAsString(),
        f -> f.setValueAsString(nameContains));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getNameContains(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME_CONTAINS));
  }

  /**
   * Cette méthode permet d'assigner le code de la Nature.
   *
   * @param filter     filtre
   * @param natureCode code de la Nature
   */
  public static void setNatureCode(FilterDto filter, String natureCode) {
    set(filter, JSON_NATURE, f -> f.getValueAsString(), f -> f.setValueAsString(natureCode));
  }

  /**
   * Cette méthode permet d'obtenir le code de la Nature.
   *
   * @param filter filtre
   * @return code de la Nature
   */
  public static String getNatureCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NATURE));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur Demandable.
   *
   * @param filter       filtre
   * @param requestable  indicateur Demandable
   */
  public static void setRequestable(FilterDto filter, Boolean requestable) {
    set(filter, JSON_REQUESTABLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(requestable));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur Demandable.
   *
   * @param filter filtre
   * @return indicateur Demandable
   */
  public static Boolean getRequestable(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_REQUESTABLE));
  }

  /**
   * Identifiant json champ {@link #unassignedUserIdentifier}.
   */
  public static final String JSON_UNASSIGNED_USER_IDENTIFIER =
      RoleDto.JSON_UNASSIGNED_USER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #assignedUserIdentifier}.
   */
  public static final String JSON_ASSIGNED_USER_IDENTIFIER = RoleDto.JSON_ASSIGNED_USER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = RoleDto.JSON_APPLICATION_IDENTIFIER;

  /**
   * Identifiant json champ {@link #applicationCode}.
   */
  public static final String JSON_APPLICATION_CODE = "codeApplication";

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #nameContains}.
   */
  public static final String JSON_NAME_CONTAINS = "nameContains";

  /**
   * Identifiant json champ {@link #natureCode}.
   */
  public static final String JSON_NATURE = RoleDto.JSON_NATURE;

  /**
   * Identifiant json champ {@link #requestable}.
   */
  public static final String JSON_REQUESTABLE = RoleDto.JSON_REQUESTABLE;

}
