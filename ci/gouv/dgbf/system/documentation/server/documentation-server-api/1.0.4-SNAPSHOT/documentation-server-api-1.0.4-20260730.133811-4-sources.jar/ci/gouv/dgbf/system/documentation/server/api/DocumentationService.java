package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTextDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DocumentationDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = DocumentationService.PATH)
@Tag(name = "Gestion des documentations")
public interface DocumentationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "documentations";

  /**
   * Cette interface représente l'enregistrement.
   *
   * @author Christian
   *
   */
  interface DocumentationSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant du processus.
     *
     * @return identifiant du processus
     */
    String getProcessIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du processus.
     *
     * @param processIdentifier identifiant du processus
     */
    void setProcessIdentifier(String processIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la source.
     *
     * @return identifiant de la source
     */
    String getSourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la source.
     *
     * @param sourceIdentifier identifiant de la source
     */
    void setSourceIdentifier(String sourceIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'enregistrement.
     *
     * @return identifiant de l'enregistrement
     */
    String getRecordIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'enregistrement.
     *
     * @param recordIdentifier identifiant de l'enregistrement
     */
    void setRecordIdentifier(String recordIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'opération.
     *
     * @return identifiant de l'opération
     */
    String getOperationIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'opération.
     *
     * @param operationIdentifier identifiant de l'opération
     */
    void setOperationIdentifier(String operationIdentifier);

    /**
     * Cette méthode permet d'obtenir le texte.
     *
     * @return le texte
     */
    String getText();

    /**
     * Cette méthode permet d'assigner le texte.
     *
     * @param text le texte
     */
    void setText(String text);

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe de fichiers.
     *
     * @return identifiant du groupe de fichiers
     */
    String getFilesGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe de fichiers.
     *
     * @param filesGroupIdentifier identifiant du groupe de fichiers
     */
    void setFilesGroupIdentifier(String filesGroupIdentifier);

    /**
     * Identifiant json identifiant de le texte.
     */
    String JSON_TEXT = HasTextDto.JSON_TEXT;

    /**
     * Identifiant json identifiant du groupe de fichiers.
     */
    String JSON_FILES_GROUP_IDENTIFIER = HasFilesGroupIdentifierDto.JSON_FILES_GROUP_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_DOCUMENTATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer une documentation.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DocumentationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DocumentationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements DocumentationSaveRequestDto {

    @JsonbProperty("processIdentifier")
    private String processIdentifier;

    @JsonbProperty("sourceIdentifier")
    private String sourceIdentifier;

    @JsonbProperty("recordIdentifier")
    private String recordIdentifier;

    @JsonbProperty("operationIdentifier")
    private String operationIdentifier;

    @JsonbProperty(JSON_TEXT)
    private String text;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DOCUMENTATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class DocumentationGetManyResponseDto
      extends AbstractGetByPageResponseDto<DocumentationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DocumentationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DOCUMENTATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DOCUMENTATION";

  /**
   * Chemin du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant.
   *
   * @param request requête
   * @return réponse.
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DOCUMENTATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  Response update(DocumentationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DocumentationUpdateRequestDto extends ByIdentifierRequestDto
      implements DocumentationSaveRequestDto {
    @JsonbProperty("processIdentifier")
    private String processIdentifier;

    @JsonbProperty("sourceIdentifier")
    private String sourceIdentifier;

    @JsonbProperty("recordIdentifier")
    private String recordIdentifier;

    @JsonbProperty("operationIdentifier")
    private String operationIdentifier;

    @JsonbProperty(JSON_TEXT)
    private String text;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Identifiant du service de mise à jour du texte.
   */
  String UPDATE_TEXT_IDENTIFIER = "MISE_A_JOUR_TEXTE_DOCUMENTATION";

  /**
   * Chemin du service de mise à jour du texte.
   */
  String UPDATE_TEXT_PATH = "texte";

  /**
   * Cette méthode permet de mettre à jour le texte.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_TEXT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_TEXT_IDENTIFIER)
  Response updateText(DocumentationUpdateTextRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DocumentationUpdateTextRequestDto extends ByIdentifierRequestDto {
    /**
     * Texte.
     */
    @JsonbProperty(JSON_TEXT)
    private String text;

    /**
     * Identifiant json {@link #text}.
     */
    public static final String JSON_TEXT = DocumentationDto.JSON_TEXT;
  }

  /**
   * Identifiant du service de mise à jour de l'identifiant de groupe de fichiers à une valeur non
   * nulle.
   */
  String UPDATE_FILES_GROUP_IDENTIFIER_TO_NON_NULL_IDENTIFIER =
      "MISE_A_JOUR_IDENTIFIANT_GROUPE_FICHIER_A_NON_NUL_DOCUMENTATION";

  /**
   * Chemin du service de mise à jour de l'identifiant de groupe de fichiers à une valeur non nulle.
   */
  String UPDATE_FILES_GROUP_IDENTIFIER_TO_NON_NULL_PATH = "identifiantGroupeFichiersNonNull";

  /**
   * Cette méthode permet de mettre à jour l'identifiant de groupe de fichiers à une valeur non
   * nulle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_FILES_GROUP_IDENTIFIER_TO_NON_NULL_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_FILES_GROUP_IDENTIFIER_TO_NON_NULL_IDENTIFIER)
  Response updateFilesGroupIdentifierToNonNull(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour de l'identifiant de groupe de fichiers à une valeur
   * nulle.
   */
  String UPDATE_FILES_GROUP_IDENTIFIER_TO_NULL_IDENTIFIER =
      "MISE_A_JOUR_IDENTIFIANT_GROUPE_FICHIER_A_NUL_DOCUMENTATION";

  /**
   * Chemin du service de mise à jour de l'identifiant de groupe de fichiers à une valeur nulle.
   */
  String UPDATE_FILES_GROUP_IDENTIFIER_TO_NULL_PATH = "identifiantGroupeFichiersNull";

  /**
   * Cette méthode permet de mettre à jour l'identifiant de groupe de fichiers à une valeur non
   * nulle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_FILES_GROUP_IDENTIFIER_TO_NULL_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_FILES_GROUP_IDENTIFIER_TO_NULL_IDENTIFIER)
  Response updateFilesGroupIdentifierToNull(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DOCUMENTATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse.
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  Response delete(DeleteOneRequestDto request);
}
