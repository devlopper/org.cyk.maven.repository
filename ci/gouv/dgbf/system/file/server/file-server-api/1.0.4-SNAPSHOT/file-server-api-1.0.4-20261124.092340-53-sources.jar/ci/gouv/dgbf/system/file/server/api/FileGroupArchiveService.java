package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des archives de fichiers de groupe.
 *
 * @author Christian
 *
 */
@Path(value = FileGroupArchiveService.PATH)
@Tag(name = "Gestion des archives de fichiers de groupe")
public interface FileGroupArchiveService extends SpecificService {

  /**
   * Chemin des services.
   */
  String PATH = "archives-fichiers-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer une archive de fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une archive de fichier de groupe",
      description = "Ce service permet de créer une archive de fichier de groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileGroupArchiveCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement d'une archive de fichier de groupe.
   *
   * @author Christian
   *
   */
  interface FileGroupArchiveSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du fichier de groupe maître.
     *
     * @return identifiant du fichier de groupe
     */
    String getFileGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du fichier de groupe maître.
     *
     * @param fileGroupIdentifier identifiant du fichier de groupe
     */
    void setFileGroupIdentifier(String fileGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'archive d'origine.
     *
     * @return identifiant de l'archive d'origine
     */
    String getOriginIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'archive d'origine.
     *
     * @param originIdentifier identifiant de l'archive d'origine
     */
    void setOriginIdentifier(String originIdentifier);

    /**
     * Cette méthode permet d'obtenir le motif.
     *
     * @return motif
     */
    String getReason();

    /**
     * Cette méthode permet d'assigner le motif.
     *
     * @param reason motif
     */
    void setReason(String reason);

    /**
     * {@link FileGroupArchiveDto#JSON_FILE_GROUP_IDENTIFIER}.
     */
    String JSON_FILE_GROUP_IDENTIFIER = FileGroupArchiveDto.JSON_FILE_GROUP_IDENTIFIER;

    /**
     * Clé JSON de l'identifiant d'origine.
     */
    String JSON_ORIGIN_IDENTIFIER = "identifiantOrigine";

    /**
     * {@link FileGroupArchiveDto#JSON_START_REASON}.
     */
    String JSON_REASON = "motif";
  }

  /**
   * Cette classe représente la requête de création d'archive ou demande d'archive (statut CREE).
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveCreateRequestDto extends ByIdentifierRequestDto
      implements FileGroupArchiveSaveRequestDto {

    @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
    private String fileGroupIdentifier;

    @JsonbProperty(JSON_ORIGIN_IDENTIFIER)
    private String originIdentifier;

    @JsonbProperty(JSON_REASON)
    private String reason;

    @Override
    public String getFileGroupIdentifier() {
      return fileGroupIdentifier != null ? fileGroupIdentifier : getIdentifier();
    }

    @Override
    public void setFileGroupIdentifier(String fileGroupIdentifier) {
      this.fileGroupIdentifier = fileGroupIdentifier;
      if (getIdentifier() == null) {
        setIdentifier(fileGroupIdentifier);
      }
    }
  }

  /**
   * Alias de compatibilité pour la requête de création de demande d'archive.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveRequestDto extends FileGroupArchiveCreateRequestDto {
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs archives de fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des archives de fichier de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileGroupArchiveDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileGroupArchiveDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une archive de fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une archive de fichier de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant une archive de fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant"
          + " une archive de fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupArchiveDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de terminaison / mise à fin.
   */
  String TERMINATE_IDENTIFIER = "TERMINAISON_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service de terminaison / mise à fin.
   */
  String TERMINATE_PATH = "terminaison";

  /**
   * Cette méthode permet de mettre fin à une archive de fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TERMINATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TERMINATE_IDENTIFIER,
      description = "Ce service permet de mettre fin à une archive de fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response terminate(FileGroupArchiveTerminateRequestDto request);

  /**
   * Cette classe représente la requête pour mettre fin à une archive.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveTerminateRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif de fin d'archivage.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif.
     */
    public static final String JSON_REASON = "motif";
  }

  /**
   * Identifiant du service d'annulation d'une demande d'archivage ou de retrait.
   */
  String CANCEL_IDENTIFIER = "ANNULATION_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service d'annulation d'une demande d'archivage ou de retrait.
   */
  String CANCEL_PATH = "annulation-archive";

  /**
   * Cette méthode permet d'annuler sa propre demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CANCEL_IDENTIFIER,
      summary = "Annulation d'une demande d'archivage ou de retrait",
      description = "Ce service permet d'annuler sa propre demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchiveCancellationResponseDto.class))})
  Response cancel(FileGroupArchiveCancellationRequestDto request);

  /**
   * Cette classe représente la requête d'annulation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveCancellationRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire de l'annulation.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif.
     */
    public static final String JSON_REASON = "motifAnnulation";
  }

  /**
   * Cette classe représente la réponse d'annulation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveCancellationResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage annulée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";
  }

  /**
   * Identifiant du service d'acceptation d'une demande d'archivage ou de retrait.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service d'acceptation d'une demande d'archivage ou de retrait.
   */
  String ACCEPT_PATH = "acceptation-archive";

  /**
   * Cette méthode permet d'accepter une demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ACCEPT_IDENTIFIER,
      summary = "Acceptation d'une demande d'archivage ou de retrait",
      description = "Ce service permet d'accepter une demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchiveAcceptanceResponseDto.class))})
  Response accept(FileGroupArchiveAcceptanceRequestDto request);

  /**
   * Cette classe représente la requête d'acceptation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveAcceptanceRequestDto extends ByIdentifierRequestDto {
  }

  /**
   * Cette classe représente la réponse d'acceptation d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveAcceptanceResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage acceptée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Archive effective créée ou clôturée.
     */
    @JsonbProperty(JSON_ARCHIVE)
    private FileGroupArchiveDto archive;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";

    /**
     * Clé JSON de l'archive.
     */
    public static final String JSON_ARCHIVE = "archive";
  }

  /**
   * Identifiant du service de refus d'une demande d'archivage ou de retrait.
   */
  String REFUSE_IDENTIFIER = "REFUS_ARCHIVE_FICHIER_GROUPE";

  /**
   * Chemin du service de refus d'une demande d'archivage ou de retrait.
   */
  String REFUSE_PATH = "refus-archive";

  /**
   * Cette méthode permet de refuser une demande d'archivage ou de retrait.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REFUSE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REFUSE_IDENTIFIER,
      summary = "Refus d'une demande d'archivage ou de retrait",
      description = "Ce service permet de refuser une demande d'archivage ou de retrait")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = FileGroupArchiveRefusalResponseDto.class))})
  Response refuse(FileGroupArchiveRefusalRequestDto request);

  /**
   * Cette classe représente la requête de refus d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveRefusalRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire du refus.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif de refus.
     */
    public static final String JSON_REASON = "motifRefus";
  }

  /**
   * Cette classe représente la réponse de refus d'une demande d'archivage ou de retrait.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveRefusalResponseDto extends AbstractResponseDto {

    /**
     * Demande d'archivage refusée.
     */
    @JsonbProperty(JSON_SOLICITATION)
    private FileGroupArchivalSolicitationDto solicitation;

    /**
     * Clé JSON de la demande.
     */
    public static final String JSON_SOLICITATION = "demande";
  }

  /** Identifiant du service d'obtention du compte. */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_ARCHIVE_FICHIER_GROUPE";
  String GET_COUNT_PATH = "obtention/compte";

  /** Obtient le nombre de concepts correspondant aux filtres. */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);
}
