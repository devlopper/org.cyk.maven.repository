package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N.
 *
 * @author Christian
 */
public interface HasRemainingAmountToIntegrateN {

  /**
   * Obtient le montant restant à intégrer pour l'année N.
   *
   * @return le montant restant à intégrer pour l'année N
   */
  Long getRemainingAmountToIntegrateN();

  /**
   * Définit le montant restant à intégrer pour l'année N.
   *
   * @param remainingAmountToIntegrateN le montant restant à intégrer pour l'année N
   */
  void setRemainingAmountToIntegrateN(Long remainingAmountToIntegrateN);

  /**
   * Identifiant java du montant restant à intégrer pour l'année N.
   */
  String FIELD_REMAINING_AMOUNT_TO_INTEGRATE_N = "remainingAmountToIntegrateN";
}