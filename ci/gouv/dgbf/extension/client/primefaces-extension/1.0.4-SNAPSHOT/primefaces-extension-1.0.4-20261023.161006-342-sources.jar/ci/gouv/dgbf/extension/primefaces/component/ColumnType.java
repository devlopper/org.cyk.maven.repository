package ci.gouv.dgbf.extension.primefaces.component;

/**
 * Cette énumération représente le type d'une colonne de tableau. Chaque type porte une classe de
 * style {@code column-<type>}, définie dans {@code datatable-columns.css} : alignement, chasse des
 * chiffres, retour à la ligne et largeur. Un type par colonne, pas de variante par champ.
 *
 * @author Christian
 *
 */
public enum ColumnType {

  /** Libellé en titre, code et informations secondaires en sous-ligne. */
  IDENTITY,
  /** Code métier : gauche, chiffres à chasse fixe, une ligne. */
  CODE,
  /** Texte : gauche, deux lignes au plus. */
  TEXT,
  /** Nombre ou montant : droite, chiffres à chasse fixe. */
  NUMBER,
  /** Date : gauche, chiffres à chasse fixe, une ligne. */
  DATE,
  /** Case de sélection : centrée, largeur fixe. */
  SELECTION,
  /** Actions de la ligne : à droite. */
  ACTIONS;

  /**
   * Cette méthode permet d'obtenir la classe de style du type.
   *
   * @return classe de style
   */
  public String getStyleClass() {
    return "column-" + name().toLowerCase();
  }
}
