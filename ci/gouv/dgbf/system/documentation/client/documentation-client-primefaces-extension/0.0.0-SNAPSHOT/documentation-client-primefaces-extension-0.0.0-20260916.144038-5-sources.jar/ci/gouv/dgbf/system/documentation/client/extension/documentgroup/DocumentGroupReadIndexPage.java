package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page d'index de lecture de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class DocumentGroupReadIndexPage extends AbstractDocumentGroupReadDatasPage {

  @Inject
  @Getter
  DocumentGroupRecordFilesController recordFilesController;

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "documentGroupReadIndexPage";

  @Override
  protected void postConstruct() {
    super.postConstruct();
    recordFilesController.initialize(getInstance().getRecordIdentifier(), userIdentifier);
  }
}
