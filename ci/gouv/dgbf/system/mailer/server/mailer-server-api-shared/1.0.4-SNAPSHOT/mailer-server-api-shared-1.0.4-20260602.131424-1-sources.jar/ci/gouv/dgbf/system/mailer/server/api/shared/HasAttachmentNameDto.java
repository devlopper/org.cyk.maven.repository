package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a un nom de pièce jointe.
 *
 * @author Christian
 */
public interface HasAttachmentNameDto extends HasAttachmentName {

  /**
   * Identifiant json du nom de la pièce jointe.
   */
  String JSON_ATTACHMENT_NAME = "nomPieceJointe";
}
