package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les groupes de type de document.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentTypeGroupFilter extends AbstractIdentifiableFilter
    implements HasGroupIdentifier, HasTypeIdentifier {

  /**
   * Identifiant du groupe de types de document ({@link DocumentTypesGroupDto}) auquel le type de
   * document est rattaché.
   */
  String groupIdentifier;

  /**
   * Identifiant du type de document ({@link DocumentTypeDto}) rattaché au groupe de types de
   * document -- utilisé par le client pour résoudre le {@link DocumentTypeGroupDto} exact à partir
   * du type et du groupe de types choisis au dépôt d'un {@link DocumentDto}.
   */
  String typeIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DocumentTypeGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DocumentTypeGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
    typeIdentifier = getTypeIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de types de document.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant du groupe de types de document
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de types de document -- sans elle, le
   * critère envoyé par le client (ex. {@code DocumentGroupExpectedDocumentController.refresh})
   * serait silencieusement ignoré : {@code DocumentTypeGroupClient.getMany(...)} retournerait
   * tous les rattachements type/groupe, et non les seuls types attendus du groupe de types
   * sélectionné.
   *
   * @param filter filtre
   * @return identifiant du groupe de types de document
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type de document.
   *
   * @param filter filtre
   * @param typeIdentifier identifiant du type de document
   */
  public static void setTypeIdentifier(FilterDto filter, String typeIdentifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(typeIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de document -- utilisé par le client pour
   * résoudre le {@link DocumentTypeGroupDto} exact à partir du type et du groupe de types choisis
   * au dépôt d'un {@link DocumentDto}.
   *
   * @param filter filtre
   * @return identifiant du type de document
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = HasTypeIdentifierDto.JSON_TYPE_IDENTIFIER;
}
