package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SharingDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SharingFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ResourceDto}.
   */
  private String resourceIdentifier;

  /**
   * {@link ResourceType}.
   */
  private ResourceType resourceType;

  /**
   * {@link Location} de {@link ResourceDto}.
   */
  private Location resourceLocation;

  /**
   * Identifiant {@link ReceiverDto}.
   */
  private String receiverIdentifier;

  /**
   * Nom d'utilisateur.
   */
  private String userName;

  /**
   * Code du domaine de {@link #userName} (realm Keycloak). Le nom n'est unique que dans son
   * domaine. Absent : domaine par défaut du serveur (transition, TCH_SHA_070).
   */
  private String userDomainCode;

  /**
   * {@link VisibilityLevel} accordé.
   */
  private VisibilityLevel visibilityLevel;

  /**
   * Si vrai, ne garder que les Partages actifs (RG_SHA_15) d'une ressource que leur destinataire
   * voit complètement (RG_SHA_21 : refus direct et niveau effectif pris en compte). Par défaut
   * tous, pour l'administration.
   */
  private Boolean isActive;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SharingFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SharingFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    resourceIdentifier = getResourceIdentifier(filter);
    resourceType = getResourceType(filter);
    resourceLocation = getResourceLocation(filter);
    receiverIdentifier = getReceiverIdentifier(filter);
    userName = getUserName(filter);
    userDomainCode = getUserDomainCode(filter);
    visibilityLevel = getVisibilityLevel(filter);
    isActive = getIsActive(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setResourceIdentifier(filter, resourceIdentifier);
    setResourceType(filter, resourceType);
    setResourceLocation(filter, resourceLocation);
    setReceiverIdentifier(filter, receiverIdentifier);
    setUserName(filter, userName);
    setUserDomainCode(filter, userDomainCode);
    setVisibilityLevel(filter, visibilityLevel);
    setIsActive(filter, isActive);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ResourceDto}.
   *
   * @param filter filtre
   * @param resourceIdentifier identifiant {@link ResourceDto}
   */
  public static void setResourceIdentifier(FilterDto filter, String resourceIdentifier) {
    set(filter, JSON_RESOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(resourceIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ResourceDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ResourceDto}
   */
  public static String getResourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_RESOURCE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner {@link ResourceType}.
   *
   * @param filter filtre
   * @param resourceType {@link ResourceType}
   */
  public static void setResourceType(FilterDto filter, ResourceType resourceType) {
    set(filter, JSON_RESOURCE_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(resourceType));
  }

  /**
   * Cette méthode permet d'obtenir {@link ResourceType}.
   *
   * @param filter filtre
   * @return {@link ResourceType}
   */
  public static ResourceType getResourceType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_RESOURCE_TYPE, ResourceType.class));
  }

  /**
   * Cette méthode permet d'assigner {@link Location}.
   *
   * @param filter filtre
   * @param resourceLocation {@link Location}
   */
  public static void setResourceLocation(FilterDto filter, Location resourceLocation) {
    set(filter, JSON_RESOURCE_LOCALTION, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(resourceLocation));
  }

  /**
   * Cette méthode permet d'obtenir {@link Location} de {@link ResourceDto}.
   *
   * @param filter filtre
   * @return {@link Location} de {@link ResourceDto}
   */
  public static Location getResourceLocation(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_RESOURCE_LOCALTION, Location.class));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ReceiverDto}.
   *
   * @param filter filtre
   * @param receiverIdentifier identifiant {@link ReceiverDto}
   */
  public static void setReceiverIdentifier(FilterDto filter, String receiverIdentifier) {
    set(filter, JSON_RECEIVER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(receiverIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ReceiverDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ReceiverDto}
   */
  public static String getReceiverIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_RECEIVER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom utilisateur.
   *
   * @param filter filtre
   * @param userName nom utilisateur
   */
  public static void setUserName(FilterDto filter, String userName) {
    set(filter, JSON_USER_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'obtenir le nom utilisateur.
   *
   * @param filter filtre
   * @return nom utilisateur
   */
  public static String getUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le code du domaine de l'utilisateur.
   *
   * @param filter filtre
   * @param userDomainCode code du domaine
   */
  public static void setUserDomainCode(FilterDto filter, String userDomainCode) {
    set(filter, JSON_USER_DOMAIN_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(userDomainCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du domaine de l'utilisateur.
   *
   * @param filter filtre
   * @return code du domaine
   */
  public static String getUserDomainCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_DOMAIN_CODE));
  }

  /**
   * Cette méthode permet d'assigner le {@link VisibilityLevel}.
   *
   * @param filter filtre
   * @param visibilityLevel {@link VisibilityLevel}
   */
  public static void setVisibilityLevel(FilterDto filter, VisibilityLevel visibilityLevel) {
    set(filter, JSON_VISIBILITY_LEVEL, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(visibilityLevel));
  }

  /**
   * Cette méthode permet d'obtenir le {@link VisibilityLevel}.
   *
   * @param filter filtre
   * @return {@link VisibilityLevel}
   */
  public static VisibilityLevel getVisibilityLevel(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_VISIBILITY_LEVEL, VisibilityLevel.class));
  }

  /**
   * Cette méthode permet d'assigner le filtre des Partages actifs.
   *
   * @param filter filtre
   * @param isActive vrai pour ne garder que les Partages actifs
   */
  public static void setIsActive(FilterDto filter, Boolean isActive) {
    set(filter, JSON_IS_ACTIVE, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(isActive));
  }

  /**
   * Cette méthode permet d'obtenir le filtre des Partages actifs.
   *
   * @param filter filtre
   * @return vrai pour ne garder que les Partages actifs
   */
  public static Boolean getIsActive(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_ACTIVE));
  }

  /**
   * Identifiant json champ {@link #resourceIdentifier}.
   */
  public static final String JSON_RESOURCE_IDENTIFIER = SharingDto.JSON_RESOURCE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #resourceType}.
   */
  public static final String JSON_RESOURCE_TYPE = SharingDto.JSON_RESOURCE_TYPE;

  /**
   * Identifiant json champ {@link #resourceLocation}.
   */
  public static final String JSON_RESOURCE_LOCALTION = SharingDto.JSON_RESOURCE_LOCATION;

  /**
   * Identifiant json champ {@link #receiverIdentifier}.
   */
  public static final String JSON_RECEIVER_IDENTIFIER = SharingDto.JSON_RECEIVER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #userName}.
   */
  public static final String JSON_USER_NAME = "nomUtilisateur";

  /**
   * Identifiant json champ {@link #userDomainCode}.
   */
  public static final String JSON_USER_DOMAIN_CODE = "codeDomaineUtilisateur";

  /**
   * Identifiant json champ {@link #visibilityLevel}.
   */
  public static final String JSON_VISIBILITY_LEVEL = SharingDto.JSON_VISIBILITY_LEVEL;

  /**
   * Identifiant json champ {@link #isActive}.
   */
  public static final String JSON_IS_ACTIVE = "estActif";
}
