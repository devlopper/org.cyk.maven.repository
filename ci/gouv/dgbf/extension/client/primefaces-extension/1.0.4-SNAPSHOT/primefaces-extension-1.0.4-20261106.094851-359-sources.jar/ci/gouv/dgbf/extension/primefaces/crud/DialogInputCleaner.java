package ci.gouv.dgbf.extension.primefaces.crud;

import jakarta.el.ELContext;
import jakarta.el.ValueExpression;
import jakarta.faces.component.EditableValueHolder;
import jakarta.faces.component.UIComponent;
import jakarta.faces.context.FacesContext;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe vide les champs d'un dialogue de formulaire.
 *
 * <p>{@code PrimeFaces.resetInputs} ne remet à zéro que l'état local des composants. Or les champs
 * des formulaires affichent la valeur d'une expression ({@code value="#{...}"}) portée par le
 * contrôleur de champ : sans cette classe, le formulaire de création s'ouvre avec les valeurs de la
 * dernière modification consultée, car les deux formulaires partagent les mêmes champs.
 *
 * @author Christian
 */
final class DialogInputCleaner {
  private static final Logger LOGGER = Logger.getLogger(DialogInputCleaner.class.getName());

  private DialogInputCleaner() {}

  /**
   * Cette méthode écrit {@code null} dans l'expression de valeur de chaque champ du dialogue.
   *
   * @param dialogIdentifier identifiant du composant du dialogue
   */
  static void clear(String dialogIdentifier) {
    FacesContext context = FacesContext.getCurrentInstance();
    if (context == null || context.getViewRoot() == null) {
      return;
    }
    UIComponent dialog = find(context.getViewRoot(), dialogIdentifier);
    if (dialog != null) {
      clearInputs(context.getELContext(), dialog);
    }
  }

  private static UIComponent find(UIComponent component, String identifier) {
    if (identifier.equals(component.getId())) {
      return component;
    }
    Iterator<UIComponent> children = component.getFacetsAndChildren();
    while (children.hasNext()) {
      UIComponent found = find(children.next(), identifier);
      if (found != null) {
        return found;
      }
    }
    return null;
  }

  /*
   * Un contrôleur qui n'accepte pas null ne doit pas empêcher l'ouverture du formulaire. De
   * même, un champ stampé par un composant itérant (ex. <ui:repeat var="fieldInput">) porte une
   * expression dont l'identifiant de base n'existe que pendant le cycle de vie de ce composant :
   * évaluée ici, en dehors de ce cycle, elle lève une PropertyNotFoundException qui ne doit pas
   * non plus empêcher l'ouverture du formulaire.
   */
  private static void clearValue(ELContext elContext, UIComponent component) {
    try {
      ValueExpression expression = component.getValueExpression("value");
      if (expression != null && !expression.isReadOnly(elContext)) {
        expression.setValue(elContext, null);
      }
    } catch (RuntimeException exception) {
      LOGGER.log(Level.WARNING, "Champ {0} non vidé : {1}",
          new Object[] {component.getId(), exception});
    }
  }

  private static void clearInputs(ELContext elContext, UIComponent component) {
    if (component instanceof EditableValueHolder) {
      clearValue(elContext, component);
    }
    Iterator<UIComponent> children = component.getFacetsAndChildren();
    while (children.hasNext()) {
      clearInputs(elContext, children.next());
    }
  }
}
