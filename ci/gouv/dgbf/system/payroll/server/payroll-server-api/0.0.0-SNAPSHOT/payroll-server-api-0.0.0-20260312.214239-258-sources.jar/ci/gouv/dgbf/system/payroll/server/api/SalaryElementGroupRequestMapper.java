package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementGroupService.SalaryElementGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementGroupService.SalaryElementGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SalaryElementGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SalaryElementGroupDto}.

    @author Arnaud
               """)
public interface SalaryElementGroupRequestMapper
    extends RequestMapper<SalaryElementGroupDto, 
            SalaryElementGroupCreateRequestDto, SalaryElementGroupUpdateRequestDto> {

}
