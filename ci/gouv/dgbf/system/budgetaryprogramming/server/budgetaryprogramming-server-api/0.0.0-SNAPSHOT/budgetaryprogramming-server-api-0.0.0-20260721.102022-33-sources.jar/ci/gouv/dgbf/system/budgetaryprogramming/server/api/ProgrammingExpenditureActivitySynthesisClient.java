package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExpenditureActivitySynthesisService.ProgrammingExpenditureActivitySynthesisGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client de {@link ProgrammingExpenditureActivitySynthesisDto}.
 *
 * @author Christian
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
@ApplicationScoped
public class ProgrammingExpenditureActivitySynthesisClient
    extends AbstractClient<ProgrammingExpenditureActivitySynthesisService>
    implements GetByIdentifier<ProgrammingExpenditureActivitySynthesisDto>,
    GetMany<ProgrammingExpenditureActivitySynthesisGetManyResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ProgrammingExpenditureActivitySynthesisService}
   * @return client {@link ProgrammingExpenditureActivitySynthesisClient}
   */
  @Override
  public ProgrammingExpenditureActivitySynthesisClient service(
      ProgrammingExpenditureActivitySynthesisService service) {
    return (ProgrammingExpenditureActivitySynthesisClient) super.service(service);
  }

  /**
   * {@link ProgrammingExpenditureActivitySynthesisService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProgrammingExpenditureActivitySynthesisGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<ProgrammingExpenditureActivitySynthesisGetManyResponseDto>(
        ProgrammingExpenditureActivitySynthesisGetManyResponseDto.class,
        ProgrammingExpenditureActivitySynthesisService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ProgrammingExpenditureActivitySynthesisService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExpenditureActivitySynthesisGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProgrammingExpenditureActivitySynthesisService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExpenditureActivitySynthesisDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ProgrammingExpenditureActivitySynthesisDto>(
        ProgrammingExpenditureActivitySynthesisDto.class,
        ProgrammingExpenditureActivitySynthesisService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link ProgrammingExpenditureActivitySynthesisService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProgrammingExpenditureActivitySynthesisDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ProgrammingExpenditureActivitySynthesisDto>(
        ProgrammingExpenditureActivitySynthesisDto.class,
        ProgrammingExpenditureActivitySynthesisService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }
}
