package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SubAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SubAdministrativeUnitFilter extends AbstractIdentifiableFilter
    implements FilterHasAdministrativeUnitIdentifier {

  /**
   * Nombre de {@link FolderDto} plus grand que zéro.
   */
  Boolean isFolderCountGreaterThanZero;

  private String administrativeUnitIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SubAdministrativeUnitFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SubAdministrativeUnitFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitIdentifier(filter);
    isFolderCountGreaterThanZero = getIsFolderCountGreaterThanZero(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    setIsFolderCountGreaterThanZero(filter, isFolderCountGreaterThanZero);
  }

  /**
   * Cette méthode permet d'obtenir est nombre de {@link FolderDto} plus grand que zéro.
   *
   * @param filter filtre
   * @return est nombre de {@link FolderDto} plus grand que zéro
   */
  public static Boolean getIsFolderCountGreaterThanZero(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO));
  }

  /**
   * Cette méthode permet d'assigner est nombre de {@link FolderDto} plus grand que zéro.
   *
   * @param filter filtre
   * @param isLate est nombre de {@link FolderDto} plus grand que zéro
   */
  public static void setIsFolderCountGreaterThanZero(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO, f -> f.getValueAsString(),
        f -> f.setValueAsBoolean(isLate));
  }

  /**
   * Identifiant json champ {@link #isFolderCountGreaterThanZero}.
   */
  public static final String JSON_IS_FOLDER_COUNT_GREATER_THAN_ZERO = "nombreDossierSuperieurZero";
}

