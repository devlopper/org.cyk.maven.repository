package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateN2AsStringDto
    extends HasTotalAmountToIntegrateN2AsString {

  /**
   * Identifiant json du montant total à intégrer pour l'année N+2.
   */
  String JSON_TOTAL_AMOUNT_TO_INTEGRATE_N2_AS_STRING =
      "montantTotalAIntegrerN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName