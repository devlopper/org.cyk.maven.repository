package ci.gouv.dgbf.system.file.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashSet;
import java.util.Set;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FileGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-10T18:34:24+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FileGroupRequestMapperImpl implements FileGroupRequestMapper {

    @Override
    public FileGroupService.FileGroupCreateRequestDto mapCreate(FileGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileGroupService.FileGroupCreateRequestDto fileGroupCreateRequestDto = new FileGroupService.FileGroupCreateRequestDto();

        fileGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        fileGroupCreateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        fileGroupCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        Set<String> set = arg0.getCategoriesIdentifiers();
        if ( set != null ) {
            fileGroupCreateRequestDto.setCategoriesIdentifiers( new LinkedHashSet<String>( set ) );
        }
        fileGroupCreateRequestDto.setUpdateCategoriesIdentifiers( arg0.getUpdateCategoriesIdentifiers() );

        return fileGroupCreateRequestDto;
    }

    @Override
    public FileGroupService.FileGroupUpdateRequestDto mapUpdate(FileGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileGroupService.FileGroupUpdateRequestDto fileGroupUpdateRequestDto = new FileGroupService.FileGroupUpdateRequestDto();

        fileGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        fileGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fileGroupUpdateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        fileGroupUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        Set<String> set = arg0.getCategoriesIdentifiers();
        if ( set != null ) {
            fileGroupUpdateRequestDto.setCategoriesIdentifiers( new LinkedHashSet<String>( set ) );
        }
        fileGroupUpdateRequestDto.setUpdateCategoriesIdentifiers( arg0.getUpdateCategoriesIdentifiers() );

        return fileGroupUpdateRequestDto;
    }

    @Override
    public FileGroupService.FileGroupUpdateCategoriesRequestDto mapUpdateCategories(FileGroupDto fileGroup) {
        if ( fileGroup == null ) {
            return null;
        }

        FileGroupService.FileGroupUpdateCategoriesRequestDto fileGroupUpdateCategoriesRequestDto = new FileGroupService.FileGroupUpdateCategoriesRequestDto();

        fileGroupUpdateCategoriesRequestDto.setAuditWho( fileGroup.getAuditWho() );
        fileGroupUpdateCategoriesRequestDto.setAuditSession( fileGroup.getAuditSession() );
        fileGroupUpdateCategoriesRequestDto.setIdentifier( fileGroup.getIdentifier() );
        Set<String> set = fileGroup.getCategoriesIdentifiers();
        if ( set != null ) {
            fileGroupUpdateCategoriesRequestDto.setCategoriesIdentifiers( new LinkedHashSet<String>( set ) );
        }

        return fileGroupUpdateCategoriesRequestDto;
    }
}
