package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une opération, l'exécution d'un code donné (une fonction) qu'un
 * Processus expose.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class OperationDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Description de l'opération.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Chemin technique ({@code @Path}) du endpoint réel, combiné à l'URL de base du Processus
   * implémenteur — adresse d'appel, jamais de navigation humaine.
   */
  @JsonbProperty(JSON_EXECUTION_PATH)
  private String executionPath;

  /**
   * Verbe HTTP du endpoint (GET, POST, PUT, DELETE, PATCH).
   */
  @JsonbProperty(JSON_HTTP_METHOD)
  private String httpMethod;

  /**
   * Référence optionnelle vers le Cas d'Utilisation du module propriétaire (ex: CU_DOC_004) —
   * best-effort, non garantie à jour, jamais utilisée par une règle de gestion.
   */
  @JsonbProperty(JSON_USE_CASE_REFERENCE)
  private String useCaseReference;

  /**
   * Identifiant du Processus auquel cette opération est obligatoirement rattachée.
   */
  @JsonbProperty(JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idOperation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "operationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "opération";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "opérations";

  /**
   * Identifiant json pour {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json pour {@link #executionPath}.
   */
  public static final String JSON_EXECUTION_PATH = "cheminDExecution";

  /**
   * Identifiant json pour {@link #httpMethod}.
   */
  public static final String JSON_HTTP_METHOD = "methodeHttp";

  /**
   * Identifiant json pour {@link #useCaseReference}.
   */
  public static final String JSON_USE_CASE_REFERENCE = "referenceCasUtilisation";

  /**
   * Identifiant json pour {@link #processIdentifier}.
   */
  public static final String JSON_PROCESS_IDENTIFIER = "idProcessus";
}
