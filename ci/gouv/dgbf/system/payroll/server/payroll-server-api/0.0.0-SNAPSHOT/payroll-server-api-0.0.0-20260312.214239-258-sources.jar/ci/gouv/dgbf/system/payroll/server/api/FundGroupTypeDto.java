package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type groupe caisse.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FundGroupTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link FundGroupTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeGroupeCaisse";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FundGroupTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeGroupeCaisseChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type groupe caisse";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types groupe caisse";
}
