package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SsoRoleDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-03T07:27:37+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SsoRoleRequestMapperImpl implements SsoRoleRequestMapper {

    @Override
    public SsoRoleService.SsoRoleCreateRequestDto mapCreate(SsoRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoRoleService.SsoRoleCreateRequestDto ssoRoleCreateRequestDto = new SsoRoleService.SsoRoleCreateRequestDto();

        ssoRoleCreateRequestDto.setCode( arg0.getCode() );
        ssoRoleCreateRequestDto.setClient( arg0.getClient() );

        return ssoRoleCreateRequestDto;
    }

    @Override
    public SsoRoleService.SsoRoleUpdateRequestDto mapUpdate(SsoRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoRoleService.SsoRoleUpdateRequestDto ssoRoleUpdateRequestDto = new SsoRoleService.SsoRoleUpdateRequestDto();

        ssoRoleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ssoRoleUpdateRequestDto.setClient( arg0.getClient() );

        return ssoRoleUpdateRequestDto;
    }
}
