package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypesGroupService.DocumentTypesGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypesGroupService.DocumentTypesGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentTypesGroupDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentTypesGroupDto}.

    @author Christian
               """)
public interface DocumentTypesGroupRequestMapper
    extends RequestMapper<DocumentTypesGroupDto, DocumentTypesGroupCreateRequestDto,
        DocumentTypesGroupUpdateRequestDto> {

}
