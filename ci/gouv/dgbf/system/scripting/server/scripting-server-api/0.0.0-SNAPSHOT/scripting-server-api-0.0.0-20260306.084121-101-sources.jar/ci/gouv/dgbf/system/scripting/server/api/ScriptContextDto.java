package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierDto;
import ci.gouv.dgbf.extension.core.segregation.HasScriptAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasScriptIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.math.BigDecimal;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contexte de script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptContextDto extends AbstractIdentifiableAuditableDto implements
    HasGroupIdentifierDto, HasScriptIdentifierDto, HasScriptAsStringDto, HasGroupAsStringDto,
    HasMultiplierDto<BigDecimal>, HasMultiplierAsStringDto, HasMinValueDto<Integer>,
    HasMinValueAsStringDto, HasMaxValueDto<Integer>, HasMaxValueAsStringDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
  private String scriptIdentifier;

  @JsonbProperty(JSON_SCRIPT_AS_STRING)
  private String scriptAsString;

  @JsonbProperty(value = JSON_MULTIPLIER)
  private BigDecimal multiplier;

  @JsonbProperty(value = JSON_MULTIPLIER_AS_STRING)
  private String multiplierAsString;
  
  @JsonbProperty(value = JSON_MIN_VALUE)
  private Integer minValue;

  @JsonbProperty(value = JSON_MIN_VALUE_AS_STRING)
  private String minValueAsString;

  @JsonbProperty(value = JSON_MAX_VALUE)
  private Integer maxValue;

  @JsonbProperty(value = JSON_MAX_VALUE_AS_STRING)
  private String maxValueAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idContexteScript";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "contexteScriptChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "contexte de script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "contextes de scripts";
}
