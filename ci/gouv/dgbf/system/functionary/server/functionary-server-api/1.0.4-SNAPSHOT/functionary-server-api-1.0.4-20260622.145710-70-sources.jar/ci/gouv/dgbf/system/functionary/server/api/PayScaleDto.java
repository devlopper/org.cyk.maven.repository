package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie.
 *
 * @author Arnaud 
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayScaleDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Représentation en chaine de caractères du nombre de {@link PayIndexDto}.
   */
  @JsonbProperty(JSON_PAY_INDEX_COUNT_AS_STRING)
  private String payIndexCountAsString;


  @JsonbProperty(JSON_CIVIL_SERVICE_STATUS_IDENTIFIER)
  private String civilServiceStatusIdentifier;

  @JsonbProperty(JSON_CIVIL_SERVICE_STATUS_AS_STRING)
  private String civilServiceStatusAsString;

  /**
   * Identifiant JSON de {@link #payIndexCountAsString}.
   */
  public static final String JSON_PAY_INDEX_COUNT_AS_STRING = "nombreIndiceChaine";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGrilleIndiciaire";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "grilleIndiciaireChaine";

  /**
   * Identifiant json de {@link #civilServiceStatusIdentifier}.
   */
  public static final String JSON_CIVIL_SERVICE_STATUS_IDENTIFIER =
      CivilServiceStatusDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #civilServiceStatusAsString}.
   */
  public static final String JSON_CIVIL_SERVICE_STATUS_AS_STRING =
      CivilServiceStatusDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "grille indiciaire";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "grilles indiciaires";
}
