package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie d'acte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ActCategoryDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Groupe catégorie d'acte.
   */
  @JsonbProperty(JSON_CATEGORY_GROUP)
  private ActCategoryGroup categoryGroup;

  /**
   * Statut de l'acte au format chaine de caractère.
   */
  @JsonbProperty(JSON_CATEGORY_GROUP_AS_STRING)
  private String categoryGroupAsString;

  /**
   * Identifiant json champ {@link ActCategoryDto#categoryGroup}.
   */
  public static final String JSON_CATEGORY_GROUP = "categoryGroup";

  /**
   * Identifiant json champ {@link ActCategoryDto#categoryGroupAsString}.
   */
  public static final String JSON_CATEGORY_GROUP_AS_STRING = "categoryGroupAsString";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie d'acte";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories d'acte";
}
