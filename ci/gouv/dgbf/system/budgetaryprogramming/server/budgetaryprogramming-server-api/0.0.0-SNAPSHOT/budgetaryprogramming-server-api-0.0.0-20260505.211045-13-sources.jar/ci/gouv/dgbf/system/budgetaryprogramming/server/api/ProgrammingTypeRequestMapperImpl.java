package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-05T21:11:05+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingTypeRequestMapperImpl implements ProgrammingTypeRequestMapper {

    @Override
    public ProgrammingTypeService.ProgrammingTypeCreateRequestDto mapCreate(ProgrammingTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingTypeService.ProgrammingTypeCreateRequestDto programmingTypeCreateRequestDto = new ProgrammingTypeService.ProgrammingTypeCreateRequestDto();

        programmingTypeCreateRequestDto.setCode( arg0.getCode() );
        programmingTypeCreateRequestDto.setName( arg0.getName() );

        return programmingTypeCreateRequestDto;
    }

    @Override
    public ProgrammingTypeService.ProgrammingTypeUpdateRequestDto mapUpdate(ProgrammingTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingTypeService.ProgrammingTypeUpdateRequestDto programmingTypeUpdateRequestDto = new ProgrammingTypeService.ProgrammingTypeUpdateRequestDto();

        programmingTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingTypeUpdateRequestDto.setCode( arg0.getCode() );
        programmingTypeUpdateRequestDto.setName( arg0.getName() );

        return programmingTypeUpdateRequestDto;
    }
}
