package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente le contrôleur de sélection de la nature du Mouvement appliqué à
 * l'Impact d'un Réclamable : création, modification ou suppression.
 *
 * @author akm
 *
 */
@Dependent
public class MovementNatureSelectOneController extends AbstractSelectOneController {

  protected MovementNatureSelectOneController() {
    outputLableValue = "Nature du mouvement";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem(VALUE_CREATION, "Création"),
        new SelectItem(VALUE_MODIFICATION, "Modification"),
        new SelectItem(VALUE_DELETION, "Suppression"));
  }

  /**
   * Cette méthode permet d'obtenir le libellé correspondant à une valeur.
   *
   * @param value valeur
   * @return libellé, ou la valeur elle-même si aucune correspondance
   */
  public String labelOf(String value) {
    return computeSelectItemsWhenChoicable().stream()
        .filter(item -> Objects.equals(item.getValue(), value)).map(SelectItem::getLabel)
        .findFirst().orElse(value);
  }

  /**
   * Valeur désignant la création : crée le Mouvement.
   */
  public static final String VALUE_CREATION = "CREATION";

  /**
   * Valeur désignant la modification : clôture le Mouvement actif concerné puis crée le nouveau.
   */
  public static final String VALUE_MODIFICATION = "MODIFICATION";

  /**
   * Valeur désignant la suppression : clôture le Mouvement actif concerné.
   */
  public static final String VALUE_DELETION = "SUPPRESSION";
}
