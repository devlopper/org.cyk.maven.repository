package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.logging.server.api.AnomalyFilter;
import ci.gouv.dgbf.system.logging.server.api.AnomalyStatus;
import ci.gouv.dgbf.system.logging.server.api.AnomalyType;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import lombok.Getter;

/**
 * Contrôleur des filtres de gestion des anomalies.
 *
 * @author Christian
 *
 */
@Dependent
public class AnomalyFilterController extends AbstractFilterController<AnomalyFilter> {

  @Inject
  @Getter
  InputTextController auditSessionInputTextController;

  @Inject
  @Getter
  InputTextController typeInputTextController;

  @Inject
  @Getter
  InputTextController moduleInputTextController;

  @Inject
  @Getter
  InputTextController statusInputTextController;

  @Inject
  @Getter
  InputTextController containsMaskedDataInputTextController;

  @Inject
  @Getter
  InputTextController dateFromInputTextController;

  @Inject
  @Getter
  InputTextController dateToInputTextController;

  private static final DateTimeFormatter DATE_TIME_FORMATTER =
      DateTimeFormatter.ISO_LOCAL_DATE_TIME;

  /**
   * Construit une instance.
   */
  public AnomalyFilterController() {
    super(AnomalyFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    auditSessionInputTextController.setOutputLableValue("Session d'audit");
    auditSessionInputTextController.getInputText().addValueConsumer(
        value -> filter.setAuditSession(value));

    typeInputTextController.setOutputLableValue("Type (code)");
    typeInputTextController.getInputText().addValueConsumer(value -> filter.setType(
        value == null || value.isBlank() ? null : AnomalyType.getByCode(value)));

    moduleInputTextController.setOutputLableValue("Module");
    moduleInputTextController.getInputText().addValueConsumer(
        value -> filter.setModule(value));

    statusInputTextController.setOutputLableValue("Statut (code)");
    statusInputTextController.getInputText().addValueConsumer(value -> filter.setStatus(
        value == null || value.isBlank() ? null : AnomalyStatus.getByCode(value)));

    containsMaskedDataInputTextController.setOutputLableValue("Données masquées (true/false)");
    containsMaskedDataInputTextController.getInputText().addValueConsumer(value ->
        filter.setContainsMaskedData(value == null || value.isBlank()
            ? null : Boolean.valueOf(value)));

    dateFromInputTextController.setOutputLableValue("Date début (ISO)");
    dateFromInputTextController.getInputText().addValueConsumer(
        value -> filter.setDateFrom(parseDateTime(value)));

    dateToInputTextController.setOutputLableValue("Date fin (ISO)");
    dateToInputTextController.getInputText().addValueConsumer(
        value -> filter.setDateTo(parseDateTime(value)));

    // Valeurs par défaut : non-traitées uniquement et période récente (90 jours)
    filter.setStatus(AnomalyStatus.CREATED);
    statusInputTextController.getInputText().setValue(AnomalyStatus.CREATED.getCode());

    LocalDateTime defaultDateFrom = LocalDateTime.now().minusDays(90);
    filter.setDateFrom(defaultDateFrom);
    dateFromInputTextController.getInputText().setValue(
        defaultDateFrom.format(DATE_TIME_FORMATTER));
  }

  private LocalDateTime parseDateTime(String value) {
    if (value == null || value.isBlank()) {
      return null;
    }
    try {
      return LocalDateTime.parse(value, DATE_TIME_FORMATTER);
    } catch (DateTimeParseException exception) {
      return null;
    }
  }
}

