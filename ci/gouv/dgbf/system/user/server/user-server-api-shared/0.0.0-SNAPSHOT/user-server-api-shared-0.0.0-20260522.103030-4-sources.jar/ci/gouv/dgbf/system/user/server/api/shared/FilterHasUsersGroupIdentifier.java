package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'identifiant de groupe
 * d'utilisateurs.
 *
 * @author Christian
 */
public interface FilterHasUsersGroupIdentifier extends HasUsersGroupIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe d'utilisateurs.
   *
   * @param filter {@link FilterDto}
   */
  default void updateUsersGroupIdentifier(FilterDto filter) {
    setUsersGroupIdentifier(UsersGroupIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe d'utilisateurs de
   * {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterUsersGroupIdentifier(FilterDto filter) {
    UsersGroupIdentifierFilter.set(filter, getUsersGroupIdentifier());
  }

}
