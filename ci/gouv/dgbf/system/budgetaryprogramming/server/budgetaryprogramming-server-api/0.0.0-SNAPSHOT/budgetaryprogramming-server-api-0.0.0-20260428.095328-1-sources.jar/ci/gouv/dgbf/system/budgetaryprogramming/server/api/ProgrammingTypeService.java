package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingTypeDto}.
 *
 * @author Christian
 *
 */
@Path(value = ProgrammingTypeService.PATH)
@Tag(name = "Gestion des Types de Programmation")
public interface ProgrammingTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "types-programmation";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingTypeSaveRequestDto {
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingTypeDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_TYPE_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingTypeDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingTypeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingTypeDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProgrammingTypeCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingTypeSaveRequestDto {
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingTypeDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingTypeDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingTypeGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingTypeDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ProgrammingTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingTypeDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TYPE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingTypeDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingTypeDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingTypeDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TYPE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingTypeDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingTypeDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TYPE_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingTypeDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingTypeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProgrammingTypeDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProgrammingTypeUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingTypeSaveRequestDto {
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingTypeDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TYPE_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingTypeDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
