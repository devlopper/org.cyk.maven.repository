package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une sélection de valeur par menu.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectOneMenu<T> extends AbstractSelectOne<T> {

  boolean filter;
  String filterMatchMode;
  boolean dynamic;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectOneMenu() {
    nullChoiceLabel = String.format("-- %s --", nullChoiceLabel);
    filter = true;
    filterMatchMode = "contains";
    dynamic = true;
  }
}
