package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsConfirmedDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de fichiers.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FilesGroupDto extends AbstractIdentifiableAuditableDto
    implements HasStatusDto<FilesGroupStatus>, HasStatusAsStringDto, HasConfirmableDto,
    HasIsConfirmedDto, HasPlannedPurgeDateDto<LocalDateTime>, HasPlannedPurgeDateAsStringDto {

  @JsonbProperty(JSON_STATUS)
  private FilesGroupStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_IS_CONFIRMED)
  private Boolean isConfirmed;

  @JsonbProperty(JSON_CONFIRMABLE)
  private Boolean confirmable;

  @JsonbProperty(JSON_PLANNED_PURGE_DATE)
  private LocalDateTime plannedPurgeDate;
  
  @JsonbProperty(JSON_PLANNED_PURGE_DATE_AS_STRING)
  private String plannedPurgeDateAsString;

  /**
   * Indicateur "Suppression en Cascade" (RG_FILE_GRP_05).
   */
  @JsonbProperty(JSON_CASCADE_ON_DELETE)
  private Boolean cascadeOnDelete;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de fichiers";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de fichiers";

  /**
   * Identifiant json pour {@link #cascadeOnDelete}.
   */
  public static final String JSON_CASCADE_ON_DELETE = "suppressionEnCascade";
}
