package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre interne de {@code ClaimedValueReview} -- entité jamais
 * exposée via un DTO/service REST propre (RU_REP_007), ce filtre ne sert qu'à l'usage interne de
 * {@code ClaimedValueReviewTransmitToVisaBusiness} (transmission groupée pour Visa,
 * RG_REP_RVR_01).
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimedValueReviewFilter extends AbstractIdentifiableFilter {

  /**
   * Étape courante du circuit ({@code GENERE}, {@code TRANSMIS_VISA}, ...).
   */
  String currentStep;

  /**
   * Identifiant de l'Agent de Traitement ayant traité la réclamation à l'origine de la revue
   * (via {@code ClaimedValue.claim.processingAgentIdentifier}).
   */
  String processingAgentIdentifier;

  /**
   * Identifiants des réclamations sélectionnées par l'Agent (portefeuille, "Transmettre la
   * sélection") -- l'Agent choisit quelles réclamations transmettre pour Visa, jamais quelle
   * Revue individuelle parmi celles d'une même réclamation (RG_REP_RVR_02).
   */
  Set<String> claimIdentifiers;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimedValueReviewFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimedValueReviewFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    currentStep = getCurrentStep(filter);
    processingAgentIdentifier = getProcessingAgentIdentifier(filter);
    claimIdentifiers = getClaimIdentifiers(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setCurrentStep(filter, currentStep);
    setProcessingAgentIdentifier(filter, processingAgentIdentifier);
    setClaimIdentifiers(filter, claimIdentifiers);
  }

  /**
   * Cette méthode permet d'assigner l'étape courante.
   *
   * @param filter filtre
   * @param currentStep étape courante
   */
  public static void setCurrentStep(FilterDto filter, String currentStep) {
    set(filter, JSON_CURRENT_STEP, f -> f.getValueAsString(), f -> f.setValueAsString(currentStep));
  }

  /**
   * Cette méthode permet d'obtenir l'étape courante.
   *
   * @param filter filtre
   * @return étape courante
   */
  public static String getCurrentStep(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CURRENT_STEP));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'Agent de Traitement.
   *
   * @param filter filtre
   * @param processingAgentIdentifier identifiant de l'Agent de Traitement
   */
  public static void setProcessingAgentIdentifier(FilterDto filter,
      String processingAgentIdentifier) {
    set(filter, JSON_PROCESSING_AGENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(processingAgentIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'Agent de Traitement.
   *
   * @param filter filtre
   * @return identifiant de l'Agent de Traitement
   */
  public static String getProcessingAgentIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESSING_AGENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants de réclamations sélectionnées.
   *
   * @param filter filtre
   * @param claimIdentifiers identifiants de réclamations sélectionnées
   */
  public static void setClaimIdentifiers(FilterDto filter, Set<String> claimIdentifiers) {
    set(filter, JSON_CLAIM_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet(
            (LinkedHashSet<String>) Core.getLinkedHashSet(claimIdentifiers)));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants de réclamations sélectionnées.
   *
   * @param filter filtre
   * @return identifiants de réclamations sélectionnées
   */
  public static Set<String> getClaimIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_CLAIM_IDENTIFIERS));
  }

  /**
   * Identifiant json champ {@link #currentStep}.
   */
  public static final String JSON_CURRENT_STEP = "etapeCourante";

  /**
   * Identifiant json champ {@link #processingAgentIdentifier}.
   */
  public static final String JSON_PROCESSING_AGENT_IDENTIFIER = "agentTraitement";

  /**
   * Identifiant json champ {@link #claimIdentifiers}.
   */
  public static final String JSON_CLAIM_IDENTIFIERS = "idsReclamations";
}
