package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de programmation.
 *
 * @author Christian
 */
public interface HasProgrammingIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la programmation.
   *
   * @return identifiant de la programmation
   */
  String getProgrammingIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la programmation.
   *
   * @param identifier identifiant de la programmation
   */
  void setProgrammingIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de la programmation.
   */
  String FIELD_PROGRAMMING_IDENTIFIER = "programmingIdentifier";
}
