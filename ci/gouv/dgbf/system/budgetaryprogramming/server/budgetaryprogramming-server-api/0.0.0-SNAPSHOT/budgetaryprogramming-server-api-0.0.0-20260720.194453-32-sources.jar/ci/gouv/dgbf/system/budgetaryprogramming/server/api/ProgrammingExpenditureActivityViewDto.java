package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une vue d'activité de dépense de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingExpenditureActivityViewDto extends AbstractAmountsContainerDto
    implements HasActivityIdentifierDto, HasActivityAsStringDto {
  
  // Activity

  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idActiviteDepenseProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "activiteDepenseProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "activité de dépense de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "activités de dépenses de programmation";

}
