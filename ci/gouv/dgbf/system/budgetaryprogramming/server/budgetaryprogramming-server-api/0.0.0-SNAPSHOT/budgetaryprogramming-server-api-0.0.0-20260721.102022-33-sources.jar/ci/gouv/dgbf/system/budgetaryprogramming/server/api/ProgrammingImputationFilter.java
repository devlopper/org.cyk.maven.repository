package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasImputationIdentifier;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.FilterHasProgrammingIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProgrammingImputationDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ProgrammingImputationFilter extends AbstractIdentifiableFilter
    implements FilterHasProgrammingIdentifier, FilterHasImputationIdentifier {

  String programmingIdentifier;
  
  String imputationIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateProgrammingIdentifier(filter);
    updateImputationIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterProgrammingIdentifier(filter);
    updateFilterImputationIdentifier(filter);
  }
  
}
