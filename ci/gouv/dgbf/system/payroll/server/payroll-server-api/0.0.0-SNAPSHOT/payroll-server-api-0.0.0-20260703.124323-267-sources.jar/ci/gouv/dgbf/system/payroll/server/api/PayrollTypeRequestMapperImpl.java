package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollTypeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollTypeRequestMapperImpl implements PayrollTypeRequestMapper {

    @Override
    public PayrollTypeService.PayrollTypeCreateRequestDto mapCreate(PayrollTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollTypeService.PayrollTypeCreateRequestDto payrollTypeCreateRequestDto = new PayrollTypeService.PayrollTypeCreateRequestDto();

        payrollTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollTypeCreateRequestDto.setCode( arg0.getCode() );
        payrollTypeCreateRequestDto.setName( arg0.getName() );

        return payrollTypeCreateRequestDto;
    }

    @Override
    public PayrollTypeService.PayrollTypeUpdateRequestDto mapUpdate(PayrollTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollTypeService.PayrollTypeUpdateRequestDto payrollTypeUpdateRequestDto = new PayrollTypeService.PayrollTypeUpdateRequestDto();

        payrollTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollTypeUpdateRequestDto.setCode( arg0.getCode() );
        payrollTypeUpdateRequestDto.setName( arg0.getName() );

        return payrollTypeUpdateRequestDto;
    }
}
