package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe porte la taille maximale d'un fichier téléversé depuis les écrans, unique source
 * des vues XHTML (champ {@code sizeLimit}, message d'erreur et aides).
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class FileUploadLimit {

  private static final long MEGABYTES = 5;

  private static final long BYTES_PER_MEGABYTE = 1024L * 1024L;

  /**
   * Cette méthode retourne la taille maximale en octets.
   *
   * @return taille maximale en octets
   */
  public long getSizeLimit() {
    return MEGABYTES * BYTES_PER_MEGABYTE;
  }

  /**
   * Cette méthode retourne la taille maximale lisible.
   *
   * @return taille maximale, par exemple « 5 Mo »
   */
  public String getLabel() {
    return MEGABYTES + " Mo";
  }

  /**
   * Cette méthode retourne le message affiché quand un fichier dépasse la taille maximale.
   *
   * @return message
   */
  public String getInvalidSizeMessage() {
    return "la taille maximale est de " + getLabel() + ".";
  }
}
