package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasDataEntityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDataEntityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourcesCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.HasListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ValueSourceGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSourceGroupController extends AbstractController implements HasListController {

  @Inject
  ValueSourceGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  ValueSourceGroupRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  DataEntitySelectOneController dataEntitySelectOneController;

  @Inject
  @Getter
  ValueSourceGroupFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ValueSourceGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ValueSourceGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ValueSourceGroupService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getDataEntityIdentifier(),
        HasDataEntityAsStringDto.JSON_DATA_ENTITY_AS_STRING);
    projection.addNames(HasIdentifierDto.JSON_IDENTIFIER, HasCodeDto.JSON_CODE,
        HasNameDto.JSON_NAME, HasValuesCountAsStringDto.JSON_VALUES_COUNT_AS_STRING,
        HasSourcesCountAsStringDto.JSON_SOURCES_COUNT_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());
    listController.getCreateController().setFunction(entity -> {
      ValueSourceGroupCreateRequestDto request =
          requestMapper.mapCreate((ValueSourceGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().setProjection(
        new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER, HasCodeDto.JSON_CODE,
            HasNameDto.JSON_NAME, HasDataEntityIdentifierDto.JSON_DATA_ENTITY_IDENTIFIER));
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());
    dataEntitySelectOneController
        .setRenderable(StringCore.isBlank(filterController.getFilter().getDataEntityIdentifier()));
    dataEntitySelectOneController.getSelectOneMenu()
        .addValueConsumer(dataEntityIdentifierConsumer());
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
      ((ValueSourceGroupDto) entity)
          .setDataEntityIdentifier(filterController.getFilter().getDataEntityIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((ValueSourceGroupDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((ValueSourceGroupDto) entity).getName());
      dataEntitySelectOneController.getSelectOneMenu()
          .writeValue(((ValueSourceGroupDto) entity).getDataEntityIdentifier());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceGroupDto.class).setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceGroupDto.class).setName(name);
  }

  Consumer<String> dataEntityIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceGroupDto.class)
        .setDataEntityIdentifier(identifier);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ValueSourceGroupUpdateRequestDto request =
          requestMapper.mapUpdate((ValueSourceGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            dataEntitySelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
