package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N, sous forme
 * de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountNAsStringDto extends HasInputtedAmountNAsString {

  /**
   * Identifiant json du montant saisi à l'horizon N, sous forme de chaîne de caractères.
   */
  String JSON_INPUTTED_AMOUNT_N_AS_STRING = "montantSaisiNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
