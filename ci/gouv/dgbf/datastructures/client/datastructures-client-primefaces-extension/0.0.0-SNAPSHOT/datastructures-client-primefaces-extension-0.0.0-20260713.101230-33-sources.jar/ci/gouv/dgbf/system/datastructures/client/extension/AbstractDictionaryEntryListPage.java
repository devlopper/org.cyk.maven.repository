package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
public abstract class AbstractDictionaryEntryListPage extends AbstractPage {

  @Inject
  @Getter
  protected DictionaryEntryController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + DictionaryEntryDto.PLURAL_NAME;
    initializeController();
  }

  /**
   * Cette méthode permet d'initialiser {@link DictionaryEntryController}.
   */
  protected void initializeController() {
    controller.initialize();
  }
}
