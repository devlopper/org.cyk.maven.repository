package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentStaffProjectionDto}.
 *
 * @author parfait
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentStaffProjectionDto}.

    @author parfait
               """)
public interface PayrollComponentStaffProjectionRequestMapper
    extends RequestMapper<PayrollComponentStaffProjectionDto, 
        PayrollComponentStaffProjectionCreateRequestDto,
        PayrollComponentStaffProjectionUpdateRequestDto> {

}
