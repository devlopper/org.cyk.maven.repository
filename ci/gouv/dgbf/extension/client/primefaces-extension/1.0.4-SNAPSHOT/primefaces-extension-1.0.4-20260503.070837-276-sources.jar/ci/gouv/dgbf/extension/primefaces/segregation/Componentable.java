package ci.gouv.dgbf.extension.primefaces.segregation;

import ci.gouv.dgbf.extension.primefaces.Form;

/**
 * Cette interface représente un composant.
 *
 * @author Christian
 *
 */
public interface Componentable {

  String getCompleteIdentifier();

  void setCompleteIdentifier(String completeIdentifier);

  Form getForm();
  
  void setForm(Form form);
}
