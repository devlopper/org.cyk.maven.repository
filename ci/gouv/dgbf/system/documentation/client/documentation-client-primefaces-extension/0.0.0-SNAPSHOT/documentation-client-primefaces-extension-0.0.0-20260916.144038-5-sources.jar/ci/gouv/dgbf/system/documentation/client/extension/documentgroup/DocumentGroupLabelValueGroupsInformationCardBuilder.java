package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un constructeur de {@link LabelValueGroupsInformationCard} de
 * {@link DocumentGroupDto}.
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class DocumentGroupLabelValueGroupsInformationCardBuilder {

  DocumentationIconManager iconManager;

  String process;

  String source;

  String record;

  String operation;

  String typeGroup;

  /**
   * Cette méthode permet de construire.
   *
   * @param iconManager {@link DocumentationIconManager}
   */
  public DocumentGroupLabelValueGroupsInformationCardBuilder(
      DocumentationIconManager iconManager) {
    this.iconManager = iconManager;
  }

  /**
   * Cette méthode permet de construire.
   *
   * @return {@link LabelValueGroupsInformationCard}
   */
  public LabelValueGroupsInformationCard build() {
    LabelValueGroupsInformationCard labelValueGroupsInformationCard =
        new LabelValueGroupsInformationCard();
    labelValueGroupsInformationCard.getHeaderText().setValue("Propriétés");
    LabelValueGroupsInformationCard.Group group = labelValueGroupsInformationCard.group();
    group.addIfValueNotBlank("Identifiant du processus", process)
        .addIfValueNotBlank("Identifiant de la source", source)
        .addIfValueNotBlank("Identifiant de enregistrement", record)
        .addIfValueNotBlank("Identifiant de l'opération", operation)
        .addIfValueNotBlank("Groupe de types de document", typeGroup);

    return labelValueGroupsInformationCard;
  }
}
