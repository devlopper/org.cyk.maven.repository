package ci.gouv.dgbf.extension.primefaces.component.input;

import jakarta.faces.model.SelectItem;
import java.util.Collections;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur de sélecteur.
 *
 * @author Christian
 *
 */
public abstract class AbstractSelectController extends AbstractInputController {

  /* Controls */

  @Getter
  @Setter
  protected boolean choicable;

  @Getter
  @Setter
  protected boolean nullChoicable;
  
  @Getter
  @Setter
  protected SelectItemLabelStrategy selectItemLabelStrategy;
  
  protected AbstractSelectController() {
    super();
    choicable = true;
    nullChoicable = true;
  }

  /**
   * Cette méthode permet de définir la visibilité.
   *
   * @param visibility visibilité
   */
  @Override
  public void visible(boolean visibility) {
    super.visible(visibility);
    if (visibility) {
      choicable = true;
    } else {
      choicable = false;
    }
  }
  
  /* -------------------------------------------------------------------------------------------- */
  
  protected List<SelectItem> computeSelectItems() {
    if (choicable) {
      return computeSelectItemsWhenChoicable();
    }
    return computeSelectItemsWhenNotChoicable();
  }

  protected abstract List<SelectItem> computeSelectItemsWhenChoicable();

  protected List<SelectItem> computeSelectItemsWhenNotChoicable() {
    return Collections.emptyList();
  }

  protected void processSelectOneRadio(SelectOneRadioString selector) {
    processInput(selector);
  }

  /*  */

  
  /**
   * Cette énumération représente la stratégie de construction de libellé de choix.
   *
   * @author Christian
   *
   */
  public enum SelectItemLabelStrategy {
    AUTO, NAME, CODE_NAME, AS_STRING
  }

}
