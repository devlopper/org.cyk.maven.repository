package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeGroupDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeGroupDto}.

    @author akm
               """)
public interface PayrollElementClaimTypeGroupRequestMapper extends
    RequestMapper<PayrollElementClaimTypeGroupDto, PayrollElementClaimTypeGroupCreateRequestDto,
        PayrollElementClaimTypeGroupUpdateRequestDto> {

}
