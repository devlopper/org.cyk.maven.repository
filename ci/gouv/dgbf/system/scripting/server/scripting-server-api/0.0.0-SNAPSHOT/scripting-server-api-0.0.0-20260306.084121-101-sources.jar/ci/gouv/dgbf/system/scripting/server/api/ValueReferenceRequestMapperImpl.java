package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueReferenceDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueReferenceRequestMapperImpl implements ValueReferenceRequestMapper {

    @Override
    public ValueReferenceService.ValueReferenceCreateRequestDto mapCreate(ValueReferenceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueReferenceService.ValueReferenceCreateRequestDto valueReferenceCreateRequestDto = new ValueReferenceService.ValueReferenceCreateRequestDto();

        valueReferenceCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueReferenceCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueReferenceCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        valueReferenceCreateRequestDto.setTableName( arg0.getTableName() );
        valueReferenceCreateRequestDto.setProjectionColumnName( arg0.getProjectionColumnName() );
        valueReferenceCreateRequestDto.setFilterColumnName( arg0.getFilterColumnName() );
        valueReferenceCreateRequestDto.setValueType( arg0.getValueType() );

        return valueReferenceCreateRequestDto;
    }

    @Override
    public ValueReferenceService.ValueReferenceUpdateRequestDto mapUpdate(ValueReferenceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueReferenceService.ValueReferenceUpdateRequestDto valueReferenceUpdateRequestDto = new ValueReferenceService.ValueReferenceUpdateRequestDto();

        valueReferenceUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueReferenceUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueReferenceUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueReferenceUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        valueReferenceUpdateRequestDto.setTableName( arg0.getTableName() );
        valueReferenceUpdateRequestDto.setProjectionColumnName( arg0.getProjectionColumnName() );
        valueReferenceUpdateRequestDto.setFilterColumnName( arg0.getFilterColumnName() );
        valueReferenceUpdateRequestDto.setValueType( arg0.getValueType() );

        return valueReferenceUpdateRequestDto;
    }
}
