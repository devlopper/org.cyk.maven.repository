package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringDataDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueDto extends AbstractIdentifiableNamableDto
    implements HasStringDataDto, HasSourceIdentifierDto, HasSourceAsStringDto {

  @JsonbProperty(JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(JSON_SOURCE_AS_STRING)
  private String sourceAsString;

  @JsonbProperty(JSON_DATA)
  private String data;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "valeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
