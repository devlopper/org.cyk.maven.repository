package ci.gouv.dgbf.system.token.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être consommé.
 *
 * @author Christian
 */
public interface HasConsumable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être consommé.
   *
   * @return peut être consommé
   */
  Boolean getConsumable();

  /**
   * Cette méthode permet d'assigner peut être consommé.
   *
   * @param consumable peut être consommé
   */
  void setConsumable(Boolean consumable);

  /**
   * Identifiant java de peut être consommé.
   */
  String FIELD_CONSUMABLE = "consumable";
}
