package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.logging.server.api.HasLevelDto;
import ci.gouv.dgbf.system.logging.server.api.LogClient;
import ci.gouv.dgbf.system.logging.server.api.LogDto;
import ci.gouv.dgbf.system.logging.server.api.LogService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link LogDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class LogController extends AbstractController {

  @Inject
  LogClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  LogFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = LogDto.NAME;
  }
  
  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(LogDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(LogService.PATH);
    listController.setFilterController(filterController);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasProcessAsStringDto.JSON_PROCESS_AS_STRING, HasLevelDto.JSON_LEVEL,
            HasMessageDto.JSON_MESSAGE, AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING));

    listController.getDataTable().getFilterButton().setRendered(true);
    
    listController.initialize();
    
    listController.getDataTable().getActionColumn().setRendered(false);
    
    listController.getDataTable().getOrderNumberColumn().setWidth("48");
    
    listController.getDataTable().getAuditColumn().setRendered(true);
    listController.getDataTable().getAuditColumn().setVisible(true);
    listController.getDataTable().getAuditColumn().setWidth("300");
    
    listController.getShowCreateDialogButton().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
  }
}
