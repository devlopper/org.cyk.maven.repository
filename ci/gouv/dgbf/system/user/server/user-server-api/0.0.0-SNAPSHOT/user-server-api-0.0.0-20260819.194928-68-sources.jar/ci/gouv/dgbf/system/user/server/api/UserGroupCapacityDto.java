package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCapacityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCapacityIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserGroupAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une qualité de l'utilisateur de groupe.
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserGroupCapacityDto extends AbstractIdentifiableAuditableDto
    implements HasUserGroupIdentifierDto, HasUserGroupAsStringDto, HasCapacityIdentifierDto,
    HasCapacityAsStringDto {

  @JsonbProperty(JSON_USER_GROUP_IDENTIFIER)
  private String userGroupIdentifier;

  @JsonbProperty(JSON_USER_GROUP_AS_STRING)
  private String userGroupAsString;

  @JsonbProperty(JSON_CAPACITY_IDENTIFIER)
  private String capacityIdentifier;

  @JsonbProperty(JSON_CAPACITY_AS_STRING)
  private String capacityAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idQualiteUtilisateurGroupe";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "qualiteUtilisateurGroupeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "qualité de l'utilisateur de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "qualités de l'utilisateur de groupe";
}
