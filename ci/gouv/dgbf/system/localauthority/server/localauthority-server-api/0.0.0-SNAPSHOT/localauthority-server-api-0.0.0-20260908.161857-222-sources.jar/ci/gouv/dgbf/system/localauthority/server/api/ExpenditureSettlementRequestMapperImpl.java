package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ExpenditureSettlementDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-08T16:19:40+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ExpenditureSettlementRequestMapperImpl implements ExpenditureSettlementRequestMapper {

    @Override
    public ExpenditureSettlementService.ExpenditureSettlementCreateRequestDto mapCreate(ExpenditureSettlementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureSettlementService.ExpenditureSettlementCreateRequestDto expenditureSettlementCreateRequestDto = new ExpenditureSettlementService.ExpenditureSettlementCreateRequestDto();

        expenditureSettlementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        expenditureSettlementCreateRequestDto.setName( arg0.getName() );
        expenditureSettlementCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        expenditureSettlementCreateRequestDto.setSupplierIdentifier( arg0.getSupplierIdentifier() );
        expenditureSettlementCreateRequestDto.setSupplierCode( arg0.getSupplierCode() );
        expenditureSettlementCreateRequestDto.setSupplierName( arg0.getSupplierName() );
        expenditureSettlementCreateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        expenditureSettlementCreateRequestDto.setEconomicNatureCode( arg0.getEconomicNatureCode() );
        expenditureSettlementCreateRequestDto.setEconomicNatureName( arg0.getEconomicNatureName() );
        expenditureSettlementCreateRequestDto.setSubject( arg0.getSubject() );
        expenditureSettlementCreateRequestDto.setCommitmentReference( arg0.getCommitmentReference() );
        expenditureSettlementCreateRequestDto.setInvoiceReferenceNumber( arg0.getInvoiceReferenceNumber() );
        expenditureSettlementCreateRequestDto.setDate( arg0.getDate() );
        if ( arg0.getAmount() != null ) {
            expenditureSettlementCreateRequestDto.setAmount( arg0.getAmount() );
        }
        if ( arg0.getAuthorizedAmount() != null ) {
            expenditureSettlementCreateRequestDto.setAuthorizedAmount( arg0.getAuthorizedAmount() );
        }
        if ( arg0.getRemainingAmountToAuthorize() != null ) {
            expenditureSettlementCreateRequestDto.setRemainingAmountToAuthorize( arg0.getRemainingAmountToAuthorize() );
        }

        return expenditureSettlementCreateRequestDto;
    }

    @Override
    public ExpenditureSettlementService.ExpenditureSettlementUpdateRequestDto mapUpdate(ExpenditureSettlementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureSettlementService.ExpenditureSettlementUpdateRequestDto expenditureSettlementUpdateRequestDto = new ExpenditureSettlementService.ExpenditureSettlementUpdateRequestDto();

        expenditureSettlementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        expenditureSettlementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        expenditureSettlementUpdateRequestDto.setName( arg0.getName() );
        expenditureSettlementUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        expenditureSettlementUpdateRequestDto.setSubject( arg0.getSubject() );
        expenditureSettlementUpdateRequestDto.setSupplierIdentifier( arg0.getSupplierIdentifier() );
        expenditureSettlementUpdateRequestDto.setSupplierCode( arg0.getSupplierCode() );
        expenditureSettlementUpdateRequestDto.setSupplierName( arg0.getSupplierName() );
        expenditureSettlementUpdateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        expenditureSettlementUpdateRequestDto.setEconomicNatureCode( arg0.getEconomicNatureCode() );
        expenditureSettlementUpdateRequestDto.setEconomicNatureName( arg0.getEconomicNatureName() );
        expenditureSettlementUpdateRequestDto.setCommitmentReference( arg0.getCommitmentReference() );
        expenditureSettlementUpdateRequestDto.setInvoiceReferenceNumber( arg0.getInvoiceReferenceNumber() );
        expenditureSettlementUpdateRequestDto.setDate( arg0.getDate() );
        if ( arg0.getAmount() != null ) {
            expenditureSettlementUpdateRequestDto.setAmount( arg0.getAmount() );
        }
        if ( arg0.getAuthorizedAmount() != null ) {
            expenditureSettlementUpdateRequestDto.setAuthorizedAmount( arg0.getAuthorizedAmount() );
        }
        if ( arg0.getRemainingAmountToAuthorize() != null ) {
            expenditureSettlementUpdateRequestDto.setRemainingAmountToAuthorize( arg0.getRemainingAmountToAuthorize() );
        }

        return expenditureSettlementUpdateRequestDto;
    }
}
