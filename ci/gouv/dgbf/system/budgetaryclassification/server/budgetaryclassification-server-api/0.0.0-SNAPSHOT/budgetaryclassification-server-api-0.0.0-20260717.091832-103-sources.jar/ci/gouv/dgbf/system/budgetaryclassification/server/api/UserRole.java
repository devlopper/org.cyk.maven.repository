package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Arnaud
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {


  /**
   * Gérer bailleurs.
   */
  MANAGE_LESSOR("GERER_BAILLEUR"),

  /**
   * Gérer actions.
   */
  MANAGE_ACTION("GERER_ACTION"),

  /**
   * Gérer unités de spécialisation budgétaire.
   */
  MANAGE_BUDGET_SPECIALIZATION_UNIT("GERER_UNITE_SPECIALISATION_BUDGETAIRE"),

  /**
   * Super administrateur.
   */
  SUPER_ADMINISTRATOR("SUPER_ADMINISTRATEUR");

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;

}
