package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le gestionnaire de partage.
 */
@ApplicationScoped
public class SharingManager {

  @Getter
  @Setter
  Consumer<ResourceDto> onResourceStoredInSession;
  
  @Getter
  @Setter
  Boolean isSetSectionWhenSetAdministrativeUnit;
  
}
