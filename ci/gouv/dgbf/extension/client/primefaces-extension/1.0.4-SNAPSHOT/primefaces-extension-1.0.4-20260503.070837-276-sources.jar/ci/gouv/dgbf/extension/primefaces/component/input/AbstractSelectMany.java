package ci.gouv.dgbf.extension.primefaces.component.input;

import java.util.List;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une sélection de plusieurs valeurs.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectMany<T> extends AbstractSelect<List<T>> {

  
}
