package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasBudgetAdministrativeUnitStaffIdentifier extends 
        HasBudgetAdministrativeUnitStaffIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de 
   * {@link BudgetAdministrativeUnitStaffDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateHasBudgetAdministrativeUnitStaffIdentifier(FilterDto filter) {
    setBudgetAdministrativeUnitStaffIdentifier(
        BudgetAdministrativeUnitStaffIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de 
   * {@link BudgetAdministrativeUnitStaffDto} de {@link FilterDto}.
   *
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterHasBudgetAdministrativeUnitStaffIdentifier(FilterDto filter) {
    BudgetAdministrativeUnitStaffIdentifierFilter.set(filter, 
        getBudgetAdministrativeUnitStaffIdentifier());
  }

}
