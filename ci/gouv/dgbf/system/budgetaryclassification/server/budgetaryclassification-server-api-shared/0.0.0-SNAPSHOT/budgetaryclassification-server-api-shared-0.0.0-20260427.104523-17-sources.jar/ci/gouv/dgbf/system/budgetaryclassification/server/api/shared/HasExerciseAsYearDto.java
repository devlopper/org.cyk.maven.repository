package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une année
 * d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseAsYearDto extends HasExerciseAsYear {

  /**
   * Identifiant json de l'année de l'exercice.
   */
  String JSON_EXERCISE_YEAR = "anneeExercice";
}
