package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DataEntityDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-27T13:33:51+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DataEntityRequestMapperImpl implements DataEntityRequestMapper {

    @Override
    public DataEntityService.DataEntityCreateRequestDto mapCreate(DataEntityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DataEntityService.DataEntityCreateRequestDto dataEntityCreateRequestDto = new DataEntityService.DataEntityCreateRequestDto();

        dataEntityCreateRequestDto.setCode( arg0.getCode() );
        dataEntityCreateRequestDto.setName( arg0.getName() );
        dataEntityCreateRequestDto.setType( arg0.getType() );
        dataEntityCreateRequestDto.setAddress( arg0.getAddress() );
        dataEntityCreateRequestDto.setCreationScript( arg0.getCreationScript() );
        dataEntityCreateRequestDto.setDeletionScript( arg0.getDeletionScript() );
        dataEntityCreateRequestDto.setExistenceVerificationScript( arg0.getExistenceVerificationScript() );

        return dataEntityCreateRequestDto;
    }

    @Override
    public DataEntityService.DataEntityUpdateRequestDto mapUpdate(DataEntityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DataEntityService.DataEntityUpdateRequestDto dataEntityUpdateRequestDto = new DataEntityService.DataEntityUpdateRequestDto();

        dataEntityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        dataEntityUpdateRequestDto.setCode( arg0.getCode() );
        dataEntityUpdateRequestDto.setName( arg0.getName() );
        dataEntityUpdateRequestDto.setType( arg0.getType() );
        dataEntityUpdateRequestDto.setAddress( arg0.getAddress() );
        dataEntityUpdateRequestDto.setCreationScript( arg0.getCreationScript() );
        dataEntityUpdateRequestDto.setDeletionScript( arg0.getDeletionScript() );
        dataEntityUpdateRequestDto.setExistenceVerificationScript( arg0.getExistenceVerificationScript() );

        return dataEntityUpdateRequestDto;
    }
}
