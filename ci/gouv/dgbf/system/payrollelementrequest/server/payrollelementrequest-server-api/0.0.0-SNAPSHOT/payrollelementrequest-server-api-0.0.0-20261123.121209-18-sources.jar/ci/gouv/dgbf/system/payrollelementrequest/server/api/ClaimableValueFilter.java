package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableValueDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableValueFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du {@link ClaimableDto} parent (pour filtrer les options d'un Réclamable donné).
   */
  String claimableIdentifier;

  /**
   * Code de la valeur qui fait autorité sur le Réclamable parent configuré en cascade (ex. code du
   * Service choisi, pour filtrer les options du Réclamable Localité) -- voir
   * {@code ClaimableCascadeDependency}.
   */
  String cascadeAuthorityCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableValueFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableValueFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    claimableIdentifier = getClaimableIdentifier(filter);
    cascadeAuthorityCode = getCascadeAuthorityCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setClaimableIdentifier(filter, claimableIdentifier);
    setCascadeAuthorityCode(filter, cascadeAuthorityCode);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Réclamable parent.
   *
   * @param filter filtre
   * @param claimableIdentifier identifiant du Réclamable parent
   */
  public static void setClaimableIdentifier(FilterDto filter, String claimableIdentifier) {
    set(filter, JSON_CLAIMABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(claimableIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Réclamable parent.
   *
   * @param filter filtre
   * @return identifiant du Réclamable parent
   */
  public static String getClaimableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CLAIMABLE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER =
      ClaimableValueDto.JSON_CLAIMABLE_IDENTIFIER;

  /**
   * Cette méthode permet d'assigner le code qui fait autorité en cascade.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setCascadeAuthorityCode(FilterDto filter, String code) {
    set(filter, JSON_CASCADE_AUTHORITY_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code qui fait autorité en cascade.
   *
   * @param filter filtre
   * @return code qui fait autorité en cascade
   */
  public static String getCascadeAuthorityCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CASCADE_AUTHORITY_CODE));
  }

  /**
   * Identifiant json champ {@link #cascadeAuthorityCode}.
   */
  public static final String JSON_CASCADE_AUTHORITY_CODE = "codeAutoriteCascade";
}
