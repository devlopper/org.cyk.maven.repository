package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingClient;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingRequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.SharingService;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link SharingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class SharingController extends AbstractController {

  @Inject
  SharingClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  SharingFilterController filterController;

  @Inject
  @Getter
  ResourceSelectOneController resourceSelectOneController;

  @Inject
  @Getter
  ReceiverSelectOneController receiverSelectOneController;

  @Inject
  SharingRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = SharingDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(SharingDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(SharingService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);


    projection.addNamesIfStringBlank(filterController.getFilter().getResourceIdentifier(),
        SharingDto.JSON_RESOURCE_AS_STRING);

    projection.addNamesIfStringBlank(filterController.getFilter().getReceiverIdentifier(),
        SharingDto.JSON_RECEIVER_AS_STRING);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getCreateController().addEntityConsumer(entity -> {
      ((SharingDto) entity)
          .setResourceIdentifier(filterController.getFilter().getResourceIdentifier());
      ((SharingDto) entity)
          .setReceiverIdentifier(filterController.getFilter().getReceiverIdentifier());
    });

    listController.getCreateController().setFunction(entity -> {
      SharingCreateRequestDto request = requestMapper.mapCreate((SharingDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            SharingDto.JSON_RESOURCE_IDENTIFIER, SharingDto.JSON_RECEIVER_IDENTIFIER));

    listController.getUpdateController().setFunction(entity -> {
      SharingUpdateRequestDto request = requestMapper.mapUpdate((SharingDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    resourceSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, SharingDto.JSON_RESOURCE_AS_STRING);
    resourceSelectOneController.getAutoComplete()
        .writeValue(filterController.getFilter().getResourceIdentifier());
    resourceSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(SharingDto.class)
            .setResourceIdentifier(identifier));

    receiverSelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, SharingDto.JSON_RECEIVER_AS_STRING);
    receiverSelectOneController.getAutoComplete()
        .writeValue(filterController.getFilter().getReceiverIdentifier());
    receiverSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(SharingDto.class)
            .setReceiverIdentifier(identifier));

  }
}
