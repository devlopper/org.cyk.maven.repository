package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentNatureService.SupportingDocumentNatureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentNatureService.SupportingDocumentNatureGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentNatureService.SupportingDocumentNatureUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des natures de pièces justificatives.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupportingDocumentNatureClient
    extends AbstractClient<SupportingDocumentNatureService>
    implements OneRetrievable<SupportingDocumentNatureDto>,
    GetByIdentifier<SupportingDocumentNatureDto>,
    GetMany<SupportingDocumentNatureGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SupportingDocumentNatureClient service(
      SupportingDocumentNatureService service) {
    return (SupportingDocumentNatureClient) super.service(service);
  }

  /**
   * Création d'une nature de pièce.
   *
   * @param request la nature à créer
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(SupportingDocumentNatureCreateRequestDto request) {
    return new CreateExecutor(SupportingDocumentNatureService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des natures de pièces.
   *
   * @param request critères, projection et pagination
   * @return les natures correspondantes
   */
  public SupportingDocumentNatureGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<SupportingDocumentNatureGetManyResponseDto>(
        SupportingDocumentNatureGetManyResponseDto.class,
        SupportingDocumentNatureService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public SupportingDocumentNatureGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'une nature unique.
   *
   * @param request critères et projection
   * @return la nature correspondante
   */
  public SupportingDocumentNatureDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupportingDocumentNatureDto>(
        SupportingDocumentNatureDto.class,
        SupportingDocumentNatureService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  @Override
  public SupportingDocumentNatureDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'une nature par son identifiant.
   *
   * @param request identifiant et projection
   * @return la nature correspondante
   */
  public SupportingDocumentNatureDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupportingDocumentNatureDto>(
        SupportingDocumentNatureDto.class,
        SupportingDocumentNatureService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public SupportingDocumentNatureDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Modification d'une nature de pièce.
   *
   * @param request la nature modifiée
   * @return l'identifiant touché
   */
  public IdentifiableResponseDto update(SupportingDocumentNatureUpdateRequestDto request) {
    return new IdentifiableExecutor(SupportingDocumentNatureService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * Suppression d'une nature de pièce.
   *
   * @param request l'identifiant à supprimer
   * @return l'identifiant supprimé
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SupportingDocumentNatureService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
