package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RoleDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-04T16:36:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RoleRequestMapperImpl implements RoleRequestMapper {

    @Override
    public RoleService.RoleCreateRequestDto mapCreate(RoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleService.RoleCreateRequestDto roleCreateRequestDto = new RoleService.RoleCreateRequestDto();

        roleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleCreateRequestDto.setCode( arg0.getCode() );
        roleCreateRequestDto.setName( arg0.getName() );
        roleCreateRequestDto.setApplicationIdentifier( arg0.getApplicationIdentifier() );
        roleCreateRequestDto.setDescription( arg0.getDescription() );
        roleCreateRequestDto.setNature( arg0.getNature() );
        List<String> list = arg0.getComponentIdentifiers();
        if ( list != null ) {
            roleCreateRequestDto.setComponentIdentifiers( new ArrayList<String>( list ) );
        }

        return roleCreateRequestDto;
    }

    @Override
    public RoleService.RoleUpdateRequestDto mapUpdate(RoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RoleService.RoleUpdateRequestDto roleUpdateRequestDto = new RoleService.RoleUpdateRequestDto();

        roleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        roleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        roleUpdateRequestDto.setCode( arg0.getCode() );
        roleUpdateRequestDto.setName( arg0.getName() );
        roleUpdateRequestDto.setDescription( arg0.getDescription() );
        List<String> list = arg0.getComponentIdentifiers();
        if ( list != null ) {
            roleUpdateRequestDto.setComponentIdentifiers( new ArrayList<String>( list ) );
        }

        return roleUpdateRequestDto;
    }
}
