package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Base de pages de lecture des {@link IdentityEmailAddressDto} d'une identité.
 *
 * @author Christian
 *
 */
public abstract class AbstractIdentityReadEmailAddressesPage
    extends AbstractIdentityReadDatasPage {

  @Inject
  @Getter
  IdentityEmailAddressController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    initializeController();
  }

  void initializeController() {
    controller.getFilterController().getFilter().setIdentityIdentifier(instance.getIdentifier());
    controller.initialize();
  }
}
