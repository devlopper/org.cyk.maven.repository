package ci.gouv.dgbf.system.budgetaryclassification.client.extension.expenditureactivity;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.ActionSelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.ExpenditureCategorySelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.ExpenditureNatureSelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.FunctionalAccountSelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.LocalitySelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative.AdministrativeUnitSelectOneController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityRequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService.ExpenditureActivityCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService.ExpenditureActivityUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ExpenditureActivityDto}.
 *
 * @author akm
 *
 */

@Dependent
public class ExpenditureActivityController extends AbstractController {

  @Inject
  @Getter
  ExpenditureActivityClient client;

  @Inject
  @Getter
  ExpenditureActivityRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController shortNameInputTextController;

  @Inject
  @Getter
  AdministrativeUnitSelectOneController beneficiaryAdministrativeUnitSelectOneController;

  @Inject
  @Getter
  ActionSelectOneController actionSelectOneController;

  @Inject
  @Getter
  FunctionalAccountSelectOneController functionalAccountSelectOneController;

  @Inject
  @Getter
  ExpenditureNatureSelectOneController expenditureNatureSelectOneController;

  @Inject
  @Getter
  LocalitySelectOneController localitySelectOneController;

  @Inject
  @Getter
  ExpenditureCategorySelectOneController expenditureCategorySelectOneController;

  @Inject
  @Getter
  SelectBooleanController isProjectSelectBooleanController;

  @Inject
  @Getter
  ExpenditureActivityFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ExpenditureActivityDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ExpenditureActivityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ExpenditureActivityService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE,
        AbstractIdentifiableCodableNamableDto.JSON_NAME,
        ExpenditureActivityDto.JSON_SHORT_NAME,
        ExpenditureActivityDto.JSON_ACTION_AS_STRING,
        ExpenditureActivityDto.JSON_IS_PROJECT,
        ExpenditureActivityDto.JSON_BENEFICIARY_ADMINISTRATIVE_UNIT_AS_STRING,
        ExpenditureActivityDto.JSON_CATEGORY_AS_STRING,
        ExpenditureActivityDto.JSON_FUNCTIONAL_ACCOUNT_AS_STRING,
        ExpenditureActivityDto.JSON_LOCALITY_AS_STRING,
        ExpenditureActivityDto.JSON_NATURE_AS_STRING,
        ExpenditureActivityDto.JSON_STATUS
    );

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getShowCreateDialogButton().setRendered(true);
    listController.getDataTable().getActionColumn().setRendered(true);

    listController.getCreateController().setFunction(entity -> {
      ExpenditureActivityCreateRequestDto request =
          requestMapper.mapCreate((ExpenditureActivityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().setProjection(
        new ProjectionDto().addNames(
            AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            ExpenditureActivityDto.JSON_SHORT_NAME,
            ExpenditureActivityDto.JSON_IS_PROJECT,
            ExpenditureActivityDto.JSON_ACTION_IDENTIFIER,
            ExpenditureActivityDto.JSON_BENEFICIARY_ADMINISTRATIVE_UNIT_IDENTIFIER,
            ExpenditureActivityDto.JSON_NATURE_IDENTIFIER,
            ExpenditureActivityDto.JSON_CATEGORY_IDENTIFIER,
            ExpenditureActivityDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER,
            ExpenditureActivityDto.JSON_LOCALITY_IDENTIFIER,
            ExpenditureActivityDto.JSON_STATUS
        )
    );

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController().setFunction(updateControllerFunction());

    nameInputTextController.initializeName(nameConsumer());

    shortNameInputTextController.getInputText().getOutputLabel().setValue("Libellé court");
    shortNameInputTextController.getInputText().addValueConsumer(shortNameConsumer());

    actionSelectOneController.getSelectOneMenu().getOutputLabel().setValue("Action");
    actionSelectOneController.getSelectOneMenu()
        .addValueConsumer(actionIdentifierConsumer());


    beneficiaryAdministrativeUnitSelectOneController.getSelectOneMenu().getOutputLabel().setValue(
        "UA Bénéficiaire");
    beneficiaryAdministrativeUnitSelectOneController.getSelectOneMenu().setRequired(true);
    beneficiaryAdministrativeUnitSelectOneController.getSelectOneMenu()
        .addValueConsumer(beneficiaryAdministrativeUnitIdentifierConsumer());

    expenditureNatureSelectOneController.getSelectOneMenu().getOutputLabel().setValue(
        "Nature");
    expenditureNatureSelectOneController.getSelectOneMenu().setRequired(true);
    expenditureNatureSelectOneController.getSelectOneMenu()
        .addValueConsumer(natureIdentifierConsumer());

    expenditureCategorySelectOneController.getSelectOneMenu().getOutputLabel().setValue(
        "Catégorie");
    expenditureCategorySelectOneController.getSelectOneMenu().setRequired(true);
    expenditureCategorySelectOneController.getSelectOneMenu()
        .addValueConsumer(categoryIdentifierConsumer());

    localitySelectOneController.getSelectOneMenu().getOutputLabel().setValue("Localité");
    localitySelectOneController.getSelectOneMenu().setRequired(true);
    localitySelectOneController.getSelectOneMenu()
        .addValueConsumer(localityIdentifierConsumer());

    functionalAccountSelectOneController.getSelectOneMenu().getOutputLabel().setValue(
        "Compte fonctionnel");
    functionalAccountSelectOneController.getSelectOneMenu().setRequired(true);
    functionalAccountSelectOneController.getSelectOneMenu()
        .addValueConsumer(functionalAccountIdentifierConsumer());


    isProjectSelectBooleanController.setOutputLableValue("Est projet ?");
    isProjectSelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices();
    isProjectSelectBooleanController.getSelectOneRadioBoolean()
        .addValueConsumer(isProjectConsumer());


  }
  
  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      ExpenditureActivityDto dto = (ExpenditureActivityDto) entity;

      nameInputTextController.getInputText().writeValue(dto.getName());
      shortNameInputTextController.getInputText().writeValue(dto.getShortName());

      isProjectSelectBooleanController.getSelectOneRadioBoolean()
          .writeValue(dto.getIsProject());

      actionSelectOneController.getSelectOneMenu()
          .writeValue(dto.getActionIdentifier());

      beneficiaryAdministrativeUnitSelectOneController.getSelectOneMenu()
          .writeValue(dto.getBeneficiaryAdministrativeUnitIdentifier());

      expenditureNatureSelectOneController.getSelectOneMenu()
          .writeValue(dto.getNatureIdentifier());

      expenditureCategorySelectOneController.getSelectOneMenu()
          .writeValue(dto.getCategoryIdentifier());

      localitySelectOneController.getSelectOneMenu()
          .writeValue(dto.getLocalityIdentifier());

      functionalAccountSelectOneController.getSelectOneMenu()
          .writeValue(dto.getFunctionalAccountIdentifier());
    };
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setName(name);
  }

  Consumer<String> shortNameConsumer() {
    return shortName -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setShortName(shortName);
  }

  Consumer<String> actionIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setActionIdentifier(identifier);
  }

  Consumer<String> beneficiaryAdministrativeUnitIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setBeneficiaryAdministrativeUnitIdentifier(identifier);
  }

  Consumer<String> natureIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setNatureIdentifier(identifier);
  }

  Consumer<String> categoryIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setCategoryIdentifier(identifier);
  }

  Consumer<String> localityIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setLocalityIdentifier(identifier);
  }

  Consumer<String> functionalAccountIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setFunctionalAccountIdentifier(identifier);
  }

  Consumer<Boolean> isProjectConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ExpenditureActivityDto.class)
        .setIsProject(value);
  }


  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ExpenditureActivityUpdateRequestDto request =
          requestMapper.mapUpdate((ExpenditureActivityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(
            nameInputTextController.getInputText(),
            shortNameInputTextController.getInputText(),
            actionSelectOneController.getSelectOneMenu(),
            beneficiaryAdministrativeUnitSelectOneController.getSelectOneMenu(),
            expenditureNatureSelectOneController.getSelectOneMenu(),
            expenditureCategorySelectOneController.getSelectOneMenu(),
            localitySelectOneController.getSelectOneMenu(),
            functionalAccountSelectOneController.getSelectOneMenu(),
            isProjectSelectBooleanController.getSelectOneRadioBoolean())
        .stream().map(input -> input.getMessage().getIdentifier())
        .collect(Collectors.joining(","));
  }
}