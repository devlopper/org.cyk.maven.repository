package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a un format d'exemple de valeurs de paramètres.
 *
 * @author Christian
 */
public interface HasParameterValuesExampleFormatDto extends HasParameterValuesExampleFormat {

  /**
   * Identifiant json du format de l'exemple de valeurs de paramètres.
   */
  String JSON_PARAMETER_VALUES_EXAMPLE_FORMAT = "formatExempleValeursParametres";
}
