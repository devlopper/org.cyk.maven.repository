package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpSession;

/**
 * Cette classe représente le gestion de session.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class SessionManager {

  public void setAttributeRedirectUrl(String url, HttpSession session) {
    session.setAttribute(RequestManager.PARAMETER_REDIRECT_URL_NAME, url);
  }

  public void setAttributeRedirectUrl(String url) {
    setAttributeRedirectUrl(url,
        (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false));
  }
  
  public String getAttributeRedirectUrl(HttpSession session) {
    return (String) session.getAttribute(RequestManager.PARAMETER_REDIRECT_URL_NAME);
  }

  public void removeAttributeRedirectUrl(HttpSession session) {
    session.removeAttribute(RequestManager.PARAMETER_REDIRECT_URL_NAME);
  }

  public boolean isAttributeRedirectUrlBlank(HttpSession session) {
    return Core.isStringBlank(getAttributeRedirectUrl(session));
  }

  public boolean isAttributeRedirectUrlNotBlank(HttpSession session) {
    return !isAttributeRedirectUrlBlank(session);
  }  
}
