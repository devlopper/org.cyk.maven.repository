package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentityEmailAddressDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentityEmailAddressDto}.

    @author Christian
               """)
public interface IdentityEmailAddressRequestMapper extends RequestMapper<IdentityEmailAddressDto,
    IdentityEmailAddressCreateRequestDto, IdentityEmailAddressUpdateRequestDto> {

}
