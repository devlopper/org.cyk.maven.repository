package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de d'employé d'unité
 * administrative.
 *
 * @author Christian
 */
public interface FilterHasAdministrativeUnitEmployeeIdentifier
    extends HasAdministrativeUnitEmployeeIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant unité administrative.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAdministrativeUnitEmployeeIdentifier(FilterDto filter) {
    setAdministrativeUnitEmployeeIdentifier(AdministrativeUnitEmployeeIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant unité administrative de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAdministrativeUnitEmployeeIdentifier(FilterDto filter) {
    AdministrativeUnitEmployeeIdentifierFilter.set(filter,
        getAdministrativeUnitEmployeeIdentifier());
  }

}
