package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+1.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN1Dto extends HasTotalAmountToInputN1 {

  /**
   * Identifiant json du montant total à saisir pour l'année N+1.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N1 = "montantTotalASaisirN1";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName