package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementTypePayrollComponentService.MovementTypePayrollComponentCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementTypePayrollComponentService.MovementTypePayrollComponentGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du paramétrage des postes de paie par type de mouvement.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class MovementTypePayrollComponentClient
    extends AbstractClient<MovementTypePayrollComponentService>
    implements GetMany<MovementTypePayrollComponentGetManyResponseDto>,
    GetByIdentifier<MovementTypePayrollComponentDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public MovementTypePayrollComponentClient service(
      MovementTypePayrollComponentService service) {
    return (MovementTypePayrollComponentClient) super.service(service);
  }

  /**
   * Rattache un poste de paie à un type de mouvement.
   *
   * @param request le rattachement à créer
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(MovementTypePayrollComponentCreateRequestDto request) {
    return new CreateExecutor(MovementTypePayrollComponentService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère du paramétrage.
   *
   * @param request critères, projection et pagination
   * @return les rattachements correspondants
   */
  public MovementTypePayrollComponentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<MovementTypePayrollComponentGetManyResponseDto>(
        MovementTypePayrollComponentGetManyResponseDto.class,
        MovementTypePayrollComponentService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public MovementTypePayrollComponentGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Lecture d'un rattachement par son identifiant.
   *
   * @param request identifiant et projection
   * @return le rattachement correspondant
   */
  public MovementTypePayrollComponentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<MovementTypePayrollComponentDto>(
        MovementTypePayrollComponentDto.class,
        MovementTypePayrollComponentService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public MovementTypePayrollComponentDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Détache un poste de paie d'un type de mouvement.
   *
   * @param request l'identifiant du rattachement à retirer
   * @return l'identifiant retiré
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(MovementTypePayrollComponentService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
