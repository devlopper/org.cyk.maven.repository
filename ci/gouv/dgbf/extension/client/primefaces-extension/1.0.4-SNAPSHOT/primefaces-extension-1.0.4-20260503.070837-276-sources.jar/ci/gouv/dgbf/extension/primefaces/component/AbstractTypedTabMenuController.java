package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur de {@link TabMenu}.
 *
 * @param <T> Type de l'entité
 * @param <I> type du gestionnaire d'icône
 * 
 * @author Christian
 */
public abstract class AbstractTypedTabMenuController<T, I> extends AbstractTabMenuController {

  @Getter
  @Setter
  T instance;

  /**
   * Cette méthode permet de construire.
   */
  protected AbstractTypedTabMenuController(Class<T> entityClass) {
    menu.setMenuItemStyleClassPrefix(entityClass.getSimpleName().toLowerCase());
  }

  protected abstract I getIconManager();
}
