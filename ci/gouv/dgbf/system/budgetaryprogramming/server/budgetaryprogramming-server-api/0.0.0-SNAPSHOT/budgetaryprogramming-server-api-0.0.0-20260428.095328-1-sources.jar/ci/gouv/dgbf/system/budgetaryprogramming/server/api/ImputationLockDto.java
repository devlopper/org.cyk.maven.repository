package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un verrou d'imputation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ImputationLockDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_INPUTABLE_N)
  private Boolean inputableN;

  @JsonbProperty(JSON_INPUTABLE_N1)
  private Boolean inputableN1;

  @JsonbProperty(JSON_INPUTABLE_N2)
  private Boolean inputableN2;

  @JsonbProperty(JSON_ARBITRABLE_N)
  private Boolean arbitrableN;

  @JsonbProperty(JSON_ARBITRABLE_N1)
  private Boolean arbitrableN1;

  @JsonbProperty(JSON_ARBITRABLE_N2)
  private Boolean arbitrableN2;

  @JsonbProperty(JSON_VALIDATABLE)
  private Boolean validatable;

  @JsonbProperty(JSON_INTEGRATABLE)
  private Boolean integratable;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idVerrouImputation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "verrouImputationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "verrou d'imputation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "verrous d'imputation";

  /**
   * Identifiant json de estSaisissableN.
   */
  public static final String JSON_INPUTABLE_N = "estSaisissableN";

  /**
   * Identifiant json de estSaisissableN1.
   */
  public static final String JSON_INPUTABLE_N1 = "estSaisissableN1";

  /**
   * Identifiant json de estSaisissableN2.
   */
  public static final String JSON_INPUTABLE_N2 = "estSaisissableN2";

  /**
   * Identifiant json de estArbitrableN.
   */
  public static final String JSON_ARBITRABLE_N = "estArbitrableN";

  /**
   * Identifiant json de estArbitrableN1.
   */
  public static final String JSON_ARBITRABLE_N1 = "estArbitrableN1";

  /**
   * Identifiant json de estArbitrableN2.
   */
  public static final String JSON_ARBITRABLE_N2 = "estArbitrableN2";

  /**
   * Identifiant json de estValidable.
   */
  public static final String JSON_VALIDATABLE = "estValidable";

  /**
   * Identifiant json de estIntegrable.
   */
  public static final String JSON_INTEGRATABLE = "estIntegrable";

}
