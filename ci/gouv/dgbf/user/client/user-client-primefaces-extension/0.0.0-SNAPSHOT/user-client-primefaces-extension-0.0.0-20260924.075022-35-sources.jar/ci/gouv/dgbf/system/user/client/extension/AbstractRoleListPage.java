package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe abstraite représente une page de liste de rôles s'appuyant sur
 * {@link RoleController}, afin que ses sous-classes bénéficient du filtre sans avoir à le
 * recabler.
 *
 * @author BoobaCool
 */
public abstract class AbstractRoleListPage extends AbstractPage {

  @Inject
  @Getter
  protected RoleController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + RoleDto.NAME;
    controller.initialize();
  }
}
