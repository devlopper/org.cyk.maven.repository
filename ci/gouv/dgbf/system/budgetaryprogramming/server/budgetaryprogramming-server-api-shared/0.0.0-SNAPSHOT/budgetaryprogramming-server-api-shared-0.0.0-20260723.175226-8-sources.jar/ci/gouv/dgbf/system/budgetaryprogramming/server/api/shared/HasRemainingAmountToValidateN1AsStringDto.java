package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateN1AsStringDto
    extends HasRemainingAmountToValidateN1AsString {

  /**
   * Identifiant json du montant restant à valider pour l'année N+1,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_VALIDATE_N1_AS_STRING =
      "montantResteAValiderN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName