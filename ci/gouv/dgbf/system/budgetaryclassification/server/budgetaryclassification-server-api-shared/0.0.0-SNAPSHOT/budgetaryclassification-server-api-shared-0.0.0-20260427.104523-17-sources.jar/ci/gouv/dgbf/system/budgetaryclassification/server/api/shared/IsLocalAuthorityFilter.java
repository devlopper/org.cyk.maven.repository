package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représentante un filtre basé sur la notion de est collectivité.
 *
 * @author Christian
 */
public interface IsLocalAuthorityFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir est collectivité.
   *
   * @param filter {@link FilterDto}
   * @return est collectivité
   */
  public static Boolean get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsBooleanByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner est collectivité.
   *
   * @param filter {@link FilterDto}
   * @param isLocalAuthority est collectivité
   */
  public static void set(FilterDto filter, Boolean isLocalAuthority) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isLocalAuthority));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = HasIsLocalAuthorityDto.JSON_IS_LOCAL_AUTHORITY;


}

