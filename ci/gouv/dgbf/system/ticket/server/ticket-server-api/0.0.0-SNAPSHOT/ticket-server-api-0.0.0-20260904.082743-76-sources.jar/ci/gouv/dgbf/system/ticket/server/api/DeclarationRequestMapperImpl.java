package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DeclarationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-04T08:28:20+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DeclarationRequestMapperImpl implements DeclarationRequestMapper {

    @Override
    public DeclarationService.DeclarationCreateRequestDto mapCreate(DeclarationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeclarationService.DeclarationCreateRequestDto declarationCreateRequestDto = new DeclarationService.DeclarationCreateRequestDto();

        declarationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        declarationCreateRequestDto.setTicketIdentifier( arg0.getTicketIdentifier() );
        declarationCreateRequestDto.setReporterIdentityIdentifier( arg0.getReporterIdentityIdentifier() );
        declarationCreateRequestDto.setBeneficiaryIdentityIdentifier( arg0.getBeneficiaryIdentityIdentifier() );
        declarationCreateRequestDto.setBeneficiaryFullName( arg0.getBeneficiaryFullName() );
        declarationCreateRequestDto.setBeneficiaryAdditionalInformation( arg0.getBeneficiaryAdditionalInformation() );

        return declarationCreateRequestDto;
    }

    @Override
    public DeclarationService.DeclarationUpdateRequestDto mapUpdate(DeclarationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeclarationService.DeclarationUpdateRequestDto declarationUpdateRequestDto = new DeclarationService.DeclarationUpdateRequestDto();

        declarationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        declarationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        declarationUpdateRequestDto.setTicketIdentifier( arg0.getTicketIdentifier() );
        declarationUpdateRequestDto.setReporterIdentityIdentifier( arg0.getReporterIdentityIdentifier() );
        declarationUpdateRequestDto.setBeneficiaryIdentityIdentifier( arg0.getBeneficiaryIdentityIdentifier() );
        declarationUpdateRequestDto.setBeneficiaryFullName( arg0.getBeneficiaryFullName() );
        declarationUpdateRequestDto.setBeneficiaryAdditionalInformation( arg0.getBeneficiaryAdditionalInformation() );

        return declarationUpdateRequestDto;
    }

    @Override
    public DeclarationService.DeclarationCreateIncidentRequestDto mapCreateIncident(DeclarationDto declaration) {
        if ( declaration == null ) {
            return null;
        }

        DeclarationService.DeclarationCreateIncidentRequestDto declarationCreateIncidentRequestDto = new DeclarationService.DeclarationCreateIncidentRequestDto();

        declarationCreateIncidentRequestDto.setAuditWho( declaration.getAuditWho() );
        declarationCreateIncidentRequestDto.setDomainIdentifier( declaration.getDomainIdentifier() );
        declarationCreateIncidentRequestDto.setName( declaration.getName() );
        declarationCreateIncidentRequestDto.setDescription( declaration.getDescription() );
        declarationCreateIncidentRequestDto.setFilesGroupIdentifier( declaration.getFilesGroupIdentifier() );
        declarationCreateIncidentRequestDto.setReporterIdentityIdentifier( declaration.getReporterIdentityIdentifier() );
        declarationCreateIncidentRequestDto.setBeneficiaryIdentityIdentifier( declaration.getBeneficiaryIdentityIdentifier() );
        declarationCreateIncidentRequestDto.setBeneficiaryFullName( declaration.getBeneficiaryFullName() );
        declarationCreateIncidentRequestDto.setBeneficiaryAdditionalInformation( declaration.getBeneficiaryAdditionalInformation() );

        return declarationCreateIncidentRequestDto;
    }
}
