package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une application.
 *
 * @author Boobacool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ApplicationDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Identifiant json {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = DomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #domainAsString}.
   */
  public static final String JSON_DOMAIN_AS_STRING = DomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #userIdentifier}.
   */

  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idApplication";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "applicationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "application";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
