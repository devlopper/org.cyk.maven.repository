package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link LogDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(LogService.PATH)
@Tag(name = "Gestion des logs")
public interface LogService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "logs";

  /**
   * Cette interface représente la requête d'enregitrement.
   */
  interface LogSaveRequest {
    /**
     * Cette méthode permet d'obtenir l'identifiant du processus.
     *
     * @return l'identifiant du processus
     */
    String getProcessIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du processus.
     *
     * @param processIdentifeir l'identifiant du processus
     */
    void setProcessIdentifier(String processIdentifeir);

    /**
     * Cette méthode permet d'obtenir le niveau.
     *
     * @return le niveau
     */
    LogLevel getLevel();

    /**
     * Cette méthode permet d'assigner le niveau.
     *
     * @param level le niveau
     */
    void setLevel(LogLevel level);

    /**
     * Cette méthode permet d'obtenir le message.
     *
     * @return le message
     */
    String getMessage();

    /**
     * Cette méthode permet d'assigner le message.
     *
     * @param message le message
     */
    void setMessage(String message);

    /**
     * {@link HasProcessIdentifierDto#JSON_PROCESS_IDENTIFIER}.
     */
    String JSON_PROCESS_IDENTIFIER = HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER;

    /**
     * {@link HasLevelDto#JSON_LEVEL}.
     */
    String JSON_LEVEL = HasLevelDto.JSON_LEVEL;

    /**
     * {@link HasMessageDto#JSON_MESSAGE}.
     */
    String JSON_MESSAGE = HasMessageDto.JSON_MESSAGE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_LOG";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un log.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un log",
      description = "Ce service permet de créer un log")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(LogCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class LogCreateRequestDto extends AbstractAuditedRequestJsonDto implements LogSaveRequest {

    @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(value = JSON_LEVEL)
    private LogLevel level;

    @JsonbProperty(value = JSON_MESSAGE)
    private String message;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_LOG";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des logs")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<LogDto> {

    @JsonbProperty(JSON_DATAS)
    private List<LogDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_LOG";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER, description = "Ce service permet d'obtenir un log")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_LOG";

  /**
   * Chemin du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir un par identifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un log")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_LOG";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un log")
  Response update(LogUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class LogUpdateRequestDto extends ByIdentifierRequestDto implements LogSaveRequest {

    @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(value = JSON_LEVEL)
    private LogLevel level;

    @JsonbProperty(value = JSON_MESSAGE)
    private String message;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_LOG";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER, description = "Ce service permet de supprimer un log")
  Response delete(DeleteOneRequestDto request);
}
