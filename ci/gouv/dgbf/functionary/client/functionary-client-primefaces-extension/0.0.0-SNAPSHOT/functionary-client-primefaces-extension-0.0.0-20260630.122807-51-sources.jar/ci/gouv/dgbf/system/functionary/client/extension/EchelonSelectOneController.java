package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.EchelonClient;
import ci.gouv.dgbf.system.functionary.server.api.EchelonDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService.EchelonGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link EchelonDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class EchelonSelectOneController extends AbstractSelectOneIdentifiableController<
    EchelonDto, EchelonGetManyResponseDto, EchelonClient> {

  @Getter
  @Inject
  EchelonClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected EchelonSelectOneController() {
    super(EchelonDto.class, SelectItemLabelStrategy.NAME);
  }
}
