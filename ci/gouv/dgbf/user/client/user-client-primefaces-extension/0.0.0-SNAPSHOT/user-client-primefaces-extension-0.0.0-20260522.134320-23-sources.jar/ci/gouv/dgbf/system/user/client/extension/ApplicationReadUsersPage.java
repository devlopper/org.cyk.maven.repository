package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste des utilisateurs d'une {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Named
@ViewScoped
public class ApplicationReadUsersPage extends AbstractApplicationReadDatasPage {

  @Inject
  @Getter
  UserController userController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    userController.getFilterController().getFilter()
        .setApplicationIdentifier(application.getIdentifier());
    userController.initialize();
  }

  public static final String OUTCOME = "applicationReadUsersPage";
}
