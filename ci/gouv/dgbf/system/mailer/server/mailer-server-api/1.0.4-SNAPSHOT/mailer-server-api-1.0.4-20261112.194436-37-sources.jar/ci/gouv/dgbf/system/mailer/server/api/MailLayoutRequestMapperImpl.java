package ci.gouv.dgbf.system.mailer.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MailLayoutDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-12T19:45:00+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MailLayoutRequestMapperImpl implements MailLayoutRequestMapper {

    @Override
    public MailLayoutService.MailLayoutCreateRequestDto mapCreate(MailLayoutDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MailLayoutService.MailLayoutCreateRequestDto mailLayoutCreateRequestDto = new MailLayoutService.MailLayoutCreateRequestDto();

        mailLayoutCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        mailLayoutCreateRequestDto.setCode( arg0.getCode() );
        mailLayoutCreateRequestDto.setName( arg0.getName() );
        mailLayoutCreateRequestDto.setBodyHtml( arg0.getBodyHtml() );
        mailLayoutCreateRequestDto.setBodyText( arg0.getBodyText() );
        mailLayoutCreateRequestDto.setIsDefault( arg0.getIsDefault() );

        return mailLayoutCreateRequestDto;
    }

    @Override
    public MailLayoutService.MailLayoutUpdateRequestDto mapUpdate(MailLayoutDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MailLayoutService.MailLayoutUpdateRequestDto mailLayoutUpdateRequestDto = new MailLayoutService.MailLayoutUpdateRequestDto();

        mailLayoutUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        mailLayoutUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        mailLayoutUpdateRequestDto.setCode( arg0.getCode() );
        mailLayoutUpdateRequestDto.setName( arg0.getName() );
        mailLayoutUpdateRequestDto.setBodyHtml( arg0.getBodyHtml() );
        mailLayoutUpdateRequestDto.setBodyText( arg0.getBodyText() );
        mailLayoutUpdateRequestDto.setIsDefault( arg0.getIsDefault() );

        return mailLayoutUpdateRequestDto;
    }
}
