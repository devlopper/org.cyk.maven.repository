package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasFundingSourceAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasLessorAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasExpenditureAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasExpenditureIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépense de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingExpenditureDto extends AbstractProgrammingExpenditureOrRevenueDto
    implements HasExpenditureIdentifierDto, HasExpenditureAsStringDto, HasActivityAsStringDto,
    HasEconomicNatureAsStringDto, HasFundingSourceAsStringDto, HasLessorAsStringDto {

  // Expenditure

  @JsonbProperty(JSON_EXPENDITURE_IDENTIFIER)
  private String expenditureIdentifier;

  @JsonbProperty(JSON_EXPENDITURE_AS_STRING)
  private String expenditureAsString;

  // Activity
  
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;
  
  // EconomicNature
  
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;
  
  // Funding source

  @JsonbProperty(JSON_FUNDING_SOURCE_AS_STRING)
  private String fundingSourceAsString;

  // Lessor

  @JsonbProperty(JSON_LESSOR_AS_STRING)
  private String lessorAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDepenseProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "depenseProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dépense de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "dépenses de programmation";

}
