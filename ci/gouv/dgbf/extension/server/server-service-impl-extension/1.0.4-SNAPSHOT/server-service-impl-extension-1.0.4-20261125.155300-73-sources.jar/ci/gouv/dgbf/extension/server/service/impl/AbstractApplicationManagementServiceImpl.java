package ci.gouv.dgbf.extension.server.service.impl;

import ci.gouv.dgbf.extension.server.service.api.ApplicationManagementService;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

/**
 * Cette classe représente l'implémentation du service ApplicationManagementService.
 *
 * @author Christian
 *
 */
public abstract class AbstractApplicationManagementServiceImpl extends AbstractServiceImpl
    implements ApplicationManagementService {

  @Override
  public Response initialiseDatabase(InitialiseDatabaseRequestDto request) {
    InitialiseDatabaseResponseDto response = processDatabaseInitialisation(request);
    return Response.status(Status.OK.getStatusCode()).entity(response).build();
  }

  /**
   * Cette méthode permet d'exécuter le processus d'initialisation de la base de données.
   *
   * @param request requête
   * @return réponse
   */
  protected InitialiseDatabaseResponseDto processDatabaseInitialisation(
      InitialiseDatabaseRequestDto request) {
    throw new ServerRuntimeException("Pas encore implémenté");
  }
}
