package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollConstantDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayrollConstantFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Cette méthode permet d'instantier.
   *
   * @param dto {@link FilterDto}
   */
  public PayrollConstantFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier.
   *
   */
  public PayrollConstantFilter() {}
}
