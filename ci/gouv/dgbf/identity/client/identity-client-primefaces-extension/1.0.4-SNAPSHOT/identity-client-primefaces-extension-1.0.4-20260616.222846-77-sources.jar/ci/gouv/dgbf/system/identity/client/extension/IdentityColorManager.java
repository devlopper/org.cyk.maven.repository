package ci.gouv.dgbf.system.identity.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire de couleurs.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class IdentityColorManager {

  String identityEmailAddressStatusCreated;
  String identityEmailAddressStatusCreatedLight;

  String identityEmailAddressStatusVerified;
  String identityEmailAddressStatusVerifiedLight;

  String identityEmailAddressStatusRevoked;
  String identityEmailAddressStatusRevokedLight;

  /**
   * Cette méthode permet d'instancier.
   */
  public IdentityColorManager() {

    // Créé
    identityEmailAddressStatusCreated = "#4F46E5";
    identityEmailAddressStatusCreatedLight = "#E0E7FF";

    // Vérifié
    identityEmailAddressStatusVerified = "#0284C7";
    identityEmailAddressStatusVerifiedLight = "#E0F2FE";

    // Revoqué
    identityEmailAddressStatusRevoked = "#16A34A";
    identityEmailAddressStatusRevokedLight = "#DCFCE7";
  }
}
