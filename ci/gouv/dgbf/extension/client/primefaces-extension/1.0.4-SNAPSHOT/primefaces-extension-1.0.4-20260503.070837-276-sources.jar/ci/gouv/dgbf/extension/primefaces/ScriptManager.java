package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.primefaces.segregation.Widgetable;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le gestionnaire de script.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ScriptManager {

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet d'exécuter un script.
   *
   * @param script script
   */
  public void execute(String script) {
    if (stringHelper.isNotBlank(script)) {
      PrimeFaces.current().executeScript(script);
    }
  }

  /**
   * Cette méthode permet d'exécuter un script.
   *
   * @param widgetable widget
   * @param consumer consommateur
   */
  void execute(Widgetable widgetable, Consumer<Widgetable> consumer) {
    if (widgetable != null) {
      if (consumer == null) {
        throw new IllegalArgumentException("Le consommateur est obligatoire");
      }
      consumer.accept(widgetable);
    }
  }

  public void show(String widgetVar) {
    execute(String.format(PF_FORMAT, widgetVar, "show()"));
  }

  /**
   * Cette méthode permet d'exécuter le script pour afficher.
   *
   * @param widgetable widget
   */
  public void show(Widgetable widgetable) {
    execute(widgetable, w -> show(w.getWidgetVar()));
  }

  public void hide(String widgetVar) {
    execute(String.format(PF_FORMAT, widgetVar, "hide()"));
  }

  /**
   * Cette méthode permet d'exécuter le script pour cacher.
   *
   * @param widgetable widget
   */
  public void hide(Widgetable widgetable) {
    execute(widgetable, w -> hide(w.getWidgetVar()));
  }

  public void reloadPage() {
    execute("window.location.reload();");
  }
  
  private static final String PF_FORMAT = "PF('%s').%s;";
}
