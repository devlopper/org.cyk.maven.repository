package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôle du bouton d'impression de rapport.
 *
 * @author Christian
 *
 */
@Dependent
public class PrintButtonController extends AbstractController {

  @Getter
  @Setter
  Button button;

  @Getter
  @Setter
  ListController listController;
  
  @Setter
  Consumer<ViewerOpener> viewerOpenerConsumer;

  @Getter
  @Setter
  PrintParametersDialogController parametersDialogController;

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet de construire une instance.
   */
  public PrintButtonController() {
    button = new Button();
    button.setTitle("Editer");
    button.setValueFromTitle();
    button.setIcon("pi pi-print");
  }
  
  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    if (listController != null) {
      button.setValue(null);
    }
  }

  /**
   * Cette méthode permet de calculer le script javascript de l'évènement onclick.
   */
  public void computeOnClick() {
    validateParametersController();
    validateParametersDialogWidgetVar();
    button.setOnClick(
        String.format("PF('%s').show()", parametersDialogController.dialog.getWidgetVar()));
    /*
     * Le type de la commande est changé en bouton pour désactiver l'envoi de requête au serveur et
     * permettre l'appel immédiat au script prévu sur l'évènement de clique.
     */
    button.setTypeAsButton();
  }

  /**
   * Cette méthode permet d'imprimer.
   */
  public void print() {
    validateParametersController();
    parametersDialogController.open();
  }

  void validateParametersController() {
    if (parametersDialogController == null) {
      throw new IllegalStateException(
          "Le contrôleur de dialogue de paramètres de rapport ne doit pas être nul.");
    }
  }

  void validateParametersDialogWidgetVar() {
    if (stringHelper.isBlank(parametersDialogController.dialog.getWidgetVar())) {
      throw new IllegalStateException(
          "Le widgetVar du contrôleur de dialogue de paramètres de rapport ne doit "
              + "pas être blanc.");
    }
  }
}
