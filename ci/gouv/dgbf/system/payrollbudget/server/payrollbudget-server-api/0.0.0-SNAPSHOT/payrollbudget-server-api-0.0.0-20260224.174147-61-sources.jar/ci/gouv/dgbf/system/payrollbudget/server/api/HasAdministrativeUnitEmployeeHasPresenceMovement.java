package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeHasPresenceMovement extends HasField {

  /**
   * Cette méthode permet d'obtenir a un mouvement de présence.
   *
   * @return a un mouvement de présence
   */
  Boolean getIsAdministrativeUnitEmployeeHasPresenceMovement();

  /**
   * Cette méthode permet d'assigner a un mouvement de présence.
   *
   * @param hasPresenceMovement a un mouvement de présence
   */
  void setIsAdministrativeUnitEmployeeHasPresenceMovement(Boolean hasPresenceMovement);

}
