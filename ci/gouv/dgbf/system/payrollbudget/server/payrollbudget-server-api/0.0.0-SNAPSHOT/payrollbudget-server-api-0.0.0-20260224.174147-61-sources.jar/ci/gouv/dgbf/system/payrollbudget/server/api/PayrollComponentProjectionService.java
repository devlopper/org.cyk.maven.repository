package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIndexDto;
import ci.gouv.dgbf.extension.core.segregation.HasIntegerAmountDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollComponentProjectionDto}.
 *
 * @author Christian
 *
 */
@Path(value = PayrollComponentProjectionService.PATH)
@Tag(name = "Gestion des projections de poste de paie")
public interface PayrollComponentProjectionService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "projections-postes-paie";

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface PayrollComponentProjectionSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitEmployeeDto}.
     *
     * @return identifiant de {@link AdministrativeUnitEmployeeDto}
     */
    String getAdministrativeUnitEmployeeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitEmployeeDto}.
     *
     * @param identifier identifiant de {@link AdministrativeUnitEmployeeDto}
     */
    void setAdministrativeUnitEmployeeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du poste de paie.
     *
     * @return identifiant du poste de paie
     */
    String getPayrollComponentIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du poste de paie.
     *
     * @param identifier identifiant du poste de paie
     */
    void setPayrollComponentIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe de la période de paie.
     *
     * @return identifiant du groupe de la période de paie
     */
    String getPayrollPeriodGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe de la période de paie.
     *
     * @param identifier identifiant du groupe de la période de paie
     */
    void setPayrollPeriodGroupIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    Integer getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(Integer amount);

    /**
     * Cette méthode permet d'obtenir le montant de référence.
     *
     * @return montant de référence
     */
    Integer getReferenceAmount();

    /**
     * Cette méthode permet d'assigner le montant de référence.
     *
     * @param amount montant de référence
     */
    void setReferenceAmount(Integer amount);

    /**
     * Identifiant json champ identifiant de {@link AdministrativeUnitEmployeeDto}.
     */
    String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER =
        PayrollComponentProjectionDto.JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER;

    /**
     * Identifiant json champ identifiant du poste de paie.
     */
    String JSON_PAYROLL_COMPONENT_IDENTIFIER =
        PayrollComponentProjectionDto.JSON_PAYROLL_COMPONENT_IDENTIFIER;

    /**
     * Identifiant json champ identifiant du groupe de la periode de paie.
     */
    String JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER =
        PayrollComponentProjectionDto.JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER;

    /**
     * Identifiant json champ montant de référence.
     */
    String JSON_REFERENCE_AMOUNT = PayrollComponentProjectionDto.JSON_REFERENCE_AMOUNT;

    /**
     * Identifiant json champ montant.
     */
    String JSON_AMOUNT = PayrollComponentProjectionDto.JSON_AMOUNT;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une projection de poste de paie",
      description = "Ce service permet de créer une projection de poste de paie")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollComponentProjectionCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollComponentProjectionCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayrollComponentProjectionSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
    private String administrativeUnitEmployeeIdentifier;

    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    private String payrollComponentIdentifier;

    @JsonbProperty(JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER)
    private String payrollPeriodGroupIdentifier;

    @JsonbProperty(JSON_REFERENCE_AMOUNT)
    private Integer referenceAmount;

    @JsonbProperty(JSON_AMOUNT)
    private Integer amount;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROJECTIONS_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des projections de poste de paie")
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = PayrollComponentProjectionGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class PayrollComponentProjectionGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollComponentProjectionDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollComponentProjectionDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UNE_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollComponentProjectionDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollComponentProjectionDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une projection de poste")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollComponentProjectionUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollComponentProjectionUpdateRequestDto extends ByIdentifierRequestDto
      implements PayrollComponentProjectionSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
    private String administrativeUnitEmployeeIdentifier;

    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    private String payrollComponentIdentifier;

    @JsonbProperty(JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER)
    private String payrollPeriodGroupIdentifier;

    @JsonbProperty(JSON_REFERENCE_AMOUNT)
    private Integer referenceAmount;

    @JsonbProperty(JSON_AMOUNT)
    private Integer amount;
  }

  /**
   * Identifiant du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_IDENTIFIER = "MISE_A_JOUR_MONTANT_POSTE_PAIE";

  /**
   * Chemin du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_PATH = PayrollComponentProjectionUpdateAmountRequestDto.JSON_AMOUNT;

  /**
   * Cette méthode permet de mettre à jour montant de {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_AMOUNT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_AMOUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateAmount(PayrollComponentProjectionUpdateAmountRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de montant.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class PayrollComponentProjectionUpdateAmountRequestDto extends ByIdentifierRequestDto
      implements HasIntegerAmountDto, HasIndexDto {
    /**
     * Montant.
     */
    @JsonbProperty(JSON_AMOUNT)
    private Integer amount;

    /**
     * Index.
     */
    @JsonbProperty(JSON_INDEX)
    private Integer index;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROJECTION_POSTE_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollComponentProjectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une projection de poste de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
