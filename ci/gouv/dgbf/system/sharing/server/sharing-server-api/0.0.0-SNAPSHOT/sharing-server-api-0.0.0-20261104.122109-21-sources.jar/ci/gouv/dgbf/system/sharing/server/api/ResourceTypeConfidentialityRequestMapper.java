package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto;
import org.mapstruct.Mapper;

/** Mapping des requetes de confidentialite par type. */
@Mapper
public interface ResourceTypeConfidentialityRequestMapper extends
    RequestMapper<ResourceTypeConfidentialityDto, ResourceTypeConfidentialityCreateRequestDto,
        ResourceTypeConfidentialityUpdateRequestDto> {
}
