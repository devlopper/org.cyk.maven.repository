package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceFilter;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;

/**
 * Cette classe représente la base de page de liste de {@link ResourceDto} de {@link SharingDto} de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public abstract class AbstractConnectedUserSharedResourceListPage extends AbstractPage {

  private static final Logger LOGGER =
      Logger.getLogger(AbstractConnectedUserSharedResourceListPage.class.getName());

  @Inject
  @Getter
  ResourceController controller;

  @Inject
  SharingSessionController sessionController;

  @Inject
  ResourceClient resourceClient;

  Location resourceLocation;

  ResourceType resourceType;

  Consumer<ResourceFilter> selectOneControllerFilterConsumer;

  @Getter
  Boolean resourceSelectedOnDemand;

  /**
   * Cette méthode permet de construire.
   */
  protected AbstractConnectedUserSharedResourceListPage(Location resourceLocation,
      ResourceType resourceType) {
    this.resourceLocation = resourceLocation;
    this.resourceType = resourceType;
    contentTitle = "Liste de mes %s".formatted(resourceTypeName());
    title = contentTitle;
  }

  @Override
  protected void prepareContent() {
    super.prepareContent();

    if (StringCore.isBlank(requestParameterRedirectUrlValue)) {
      prepareFilterController();
      controller.initialize();
      prepareListController();
    } else {
      resourceSelectedOnDemand = selectResource();
    }
  }

  /**
   * Cette méthode permet de sélectionner {@link ResourceDto} et de le mettre en session à la
   * demande.
   *
   * @return vrai si demande satisfaite.
   */
  Boolean selectResource() {
    /*
     * Cette page a été sollicité afin que l'utilisateur puisse sélectionner une ressource à
     * utiliser.
     */

    /*
     * On identifie une ressource parmis la liste afin de l'utiliser par défaut. Cela permet
     * d'éviter une sélection manuelle par l'utilisateur connecté.
     */
    ResourceDto resource = sessionController.storeFirstResource(resourceLocation, resourceType,
        selectOneControllerFilterConsumer);
    /*
     * Si une ressource a été trouvée alors on se redirige vers la page qui en avait besoin.
     */
    if (resource == null) {
      LOGGER.log(Level.WARNING,
          "L'utilisateur {0} n'a pas de {1} {2}.{3}. Veuillez créer un partage puis réessayer.",
          new Object[] {userIdentifier, ResourceDto.NAME, resourceLocation.name(),
              resourceType.name()});
      return false;
    } else {
      return navigateByUrl(requestParameterRedirectUrlValue);
    }

  }

  /**
   * Cette méthode permet d'obtenir le nom de {@link #resourceType}.
   *
   * @return nom de {@link #resourceType}
   */
  protected String resourceTypeName() {
    return resourceType.getName();
  }

  /**
   * Cette méthode permet de préparer {@link ResourceFilterController}.
   */
  protected void prepareFilterController() {
    controller.getFilterController().getFilter().setUserName(userIdentifier);
    controller.getFilterController().getFilter().setType(resourceType);
    controller.getFilterController().getFilter().setLocation(resourceLocation);
  }

  void prepareListController() {
    controller.getListController().getDataTable().getFilterButton().setRendered(false);
    controller.getListController().getDataTable().setHeaderRendered(false);
    controller.getListController().getDataTable().getActionsOutputPanel().setRendered(false);
  }
}
