package ci.gouv.dgbf.system.sharing.server.api;

/** Codes des niveaux de confidentialité. */
public final class ConfidentialityLevelCode {

  /** Donnée privée par défaut. */
  public static final String PRIVATE = "PRIVATE";

  /** Donnée publiable. */
  public static final String PUBLIC = "PUBLIC";

  private ConfidentialityLevelCode() {
  }
}
