package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a une notion filtre de budget est par défaut.
 *
 * @author Christian
 */
public interface FilterHasBudgetIsDefault extends HasBudgetIsDefault {

  /**
   * Cette méthode permet de mettre à jour budget est par défaut.
   *
   * @param filter {@link FilterDto}
   */
  default void updateBudgetIsDefault(FilterDto filter) {
    setBudgetIsDefault(BudgetIsDefaultFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour budget est par défaut de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterBudgetIsDefault(FilterDto filter) {
    BudgetIsDefaultFilter.set(filter, getBudgetIsDefault());
  }

}
