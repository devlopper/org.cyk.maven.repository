package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Ligne d'arbitrage : la copie, déversée à la transmission, sur laquelle la DCB décide.
 *
 * <p>La table d'expression des besoins n'est jamais modifiée après transmission — elle reste la
 * preuve de ce que l'EPN a demandé. Toutes les évolutions de l'arbitrage portent sur cet objet.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ArbitrationMovementDto extends AbstractIdentifiableAuditableDto {

  /**
   * Dossier de masse salariale qui contient la ligne.
   */
  @JsonbProperty(JSON_DOSSIER_IDENTIFIER)
  private String dossierIdentifier;

  /**
   * Référence de la ligne d'origine dans l'expression des besoins. Pour un ajout de la DCB, elle
   * est forgée et porte le préfixe {@link #EXPRESSION_LINE_DCB_PREFIX}.
   */
  @JsonbProperty(JSON_EXPRESSION_LINE_IDENTIFIER)
  private String expressionLineIdentifier;

  /**
   * Nature de l'élément déversé : mouvement de personnel, mesure ponctuelle ou transfert de
   * solde.
   */
  @JsonbProperty(JSON_ELEMENT_TYPE)
  private String elementType;

  /**
   * Budget de rattachement.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Unité administrative — l'EPN — où la ligne produit son effet.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Unité administrative d'origine, renseignée sur la ligne d'entrée d'un transfert de solde.
   */
  @JsonbProperty(JSON_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String originAdministrativeUnitIdentifier;

  /**
   * Agent concerné. Nul pour une mesure ponctuelle, qui vise l'unité administrative entière.
   */
  @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
  private String employeeIdentifier;

  /**
   * Code de la nature du mouvement, qui désigne aussi le droit qui l'instruit.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_CODE)
  private String movementTypeCode;

  /**
   * Libellé de la nature du mouvement, alimenté par jointure.
   */
  @JsonbProperty(JSON_MOVEMENT_TYPE_AS_STRING)
  private String movementTypeAsString;

  /**
   * Indique un mouvement commun, qui suit l'agent à glissement catégoriel ou avancement.
   */
  @JsonbProperty(JSON_COMMON)
  private Boolean common;

  /**
   * Visa du contrôleur. Trois valeurs et non deux : {@code null} dit que la ligne n'est pas
   * encore passée devant lui.
   */
  @JsonbProperty(JSON_ENDORSED)
  private Boolean endorsed;

  /**
   * Rang chronologique de la version de ligne.
   */
  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  /**
   * Montant d'impact, figé à la création de la ligne d'origine et jamais recalculé.
   */
  @JsonbProperty(JSON_IMPACT_AMOUNT)
  private Long impactAmount;

  /**
   * État de la ligne dans le circuit d'arbitrage.
   *
   * <p><strong>Écart assumé à R44b, qui attend un statut typé.</strong> La règle veut
   * {@code implements HasStatusDto<ArbitrationMovementStatus>} et un champ
   * {@code status} de ce type. Le passage touche environ cinq cents points d'appel sur
   * les trois dépôts, et surtout la persistance : la colonne porte un code français,
   * donc il faut un {@code AttributeConverter}, et Hibernate valide le schéma au
   * démarrage. C'est un chantier à part, à mener là où les tests d'intégration tournent,
   * et non une retouche de contrat.</p>
   */
  @JsonbProperty(JSON_STATUS_CODE)
  private String statusCode;

  /**
   * Libellé de l'état, alimenté par jointure.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Motif de la décision. Obligatoire pour tout rejet, retour ou ajustement (RG_PRB_ARB_06).
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Montant d'ajustement, positif ou négatif, appliqué à une mesure ponctuelle.
   */
  @JsonbProperty(JSON_ADJUSTMENT_AMOUNT)
  private Long adjustmentAmount;

  /**
   * Acteur ayant pris la dernière décision.
   */
  @JsonbProperty(JSON_DECISION_ACTOR)
  private String decisionActor;

  /**
   * Indique une ligne recréée dans la structure d'origine par la cascade RG_PRB_ARB_04.
   */
  @JsonbProperty(JSON_RECREATED)
  private Boolean recreated;

  /**
   * Sur une ligne recréée, référence la ligne rejetée en cascade dont elle procède.
   */
  @JsonbProperty(JSON_CASCADE_LINE_IDENTIFIER)
  private String cascadeLineIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idLigneArbitrage";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "ligneArbitrageChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ligne d'arbitrage";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "lignes d'arbitrage";

  /**
   * Identifiant json pour {@link #dossierIdentifier}.
   */
  public static final String JSON_DOSSIER_IDENTIFIER =
      BudgetAdministrativeUnitDossierDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #expressionLineIdentifier}.
   */
  public static final String JSON_EXPRESSION_LINE_IDENTIFIER = "idLigneExpressionBesoin";

  /**
   * Identifiant json pour {@link #elementType}.
   */
  public static final String JSON_ELEMENT_TYPE = "typeElement";

  /**
   * Identifiant json pour {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";

  /**
   * Identifiant json pour {@link #originAdministrativeUnitIdentifier}.
   */
  public static final String JSON_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER =
      "idUniteAdministrativeOrigine";

  /**
   * Identifiant json pour {@link #employeeIdentifier}.
   */
  public static final String JSON_EMPLOYEE_IDENTIFIER = "idEmploye";

  /**
   * Identifiant json pour {@link #movementTypeCode}.
   */
  public static final String JSON_MOVEMENT_TYPE_CODE = "codeTypeMouvement";

  /**
   * Identifiant json pour {@link #movementTypeAsString}.
   */
  public static final String JSON_MOVEMENT_TYPE_AS_STRING =
      MovementTypeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #common}.
   */
  public static final String JSON_COMMON = "estCommun";

  /**
   * Identifiant json pour {@link #endorsed}.
   */
  public static final String JSON_ENDORSED = "estVise";

  /**
   * Identifiant json pour {@link #orderNumber}.
   */
  public static final String JSON_ORDER_NUMBER = "ordre";

  /**
   * Identifiant json pour {@link #impactAmount}.
   */
  public static final String JSON_IMPACT_AMOUNT = "montantImpact";

  /**
   * Identifiant json pour {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "statut";

  /**
   * Identifiant json pour {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant json pour {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json pour {@link #adjustmentAmount}.
   */
  public static final String JSON_ADJUSTMENT_AMOUNT = "montantAjustement";

  /**
   * Identifiant json pour {@link #decisionActor}.
   */
  public static final String JSON_DECISION_ACTOR = "acteurDecision";

  /**
   * Identifiant json pour {@link #recreated}.
   */
  public static final String JSON_RECREATED = "estRecree";

  /**
   * Identifiant json pour {@link #cascadeLineIdentifier}.
   */
  public static final String JSON_CASCADE_LINE_IDENTIFIER = "idLigneCascade";

  /**
   * Préfixe des références forgées pour les éléments ajoutés par la DCB au cours du
   * traitement (CU03-RG02, CU04-RG02, CU05-RG02).
   *
   * <p>Un tel élément n'a aucune ligne d'expression des besoins derrière lui. Laisser la
   * référence <em>vide</em> aurait été le dire plus simplement, mais la contrainte d'unicité
   * {@code (DOSSIER, LIGNE_EB, EST_RECREE)} n'aurait alors toléré qu'un seul ajout par
   * dossier : le second aurait été refusé par la base, en plein écran.</p>
   *
   * <p>Chaque ajout reçoit donc sa propre référence, que ce préfixe rend reconnaissable : elle
   * ne désigne rien dans l'expression des besoins, et l'annonce. L'unicité garde son sens —
   * une ligne d'arbitrage par source — et les ajouts se comptent sans se gêner.</p>
   */
  public static final String EXPRESSION_LINE_DCB_PREFIX = "DCB-";

  /**
   * Valeur de {@link #elementType} pour une ligne issue d'un mouvement de personnel.
   */
  public static final String ELEMENT_TYPE_MOVEMENT = "MOUVEMENT";

  /**
   * Nature des lignes de reprise, consolidées dès la réception (RG_PRB_ARB_17).
   */
  public static final String NATURE_INITIALIZATION = "INITIALISATION";

  /**
   * Valeur de {@link #elementType} pour une ligne issue d'une mesure ponctuelle.
   */
  public static final String ELEMENT_TYPE_PUNCTUAL_MEASURE = "MESURE_PONCTUELLE";

  /**
   * Nature des transferts de solde entre EPN. Comme l'initialisation, elle nomme un type de
   * mouvement que l'écran doit savoir distinguer : un transfert se contrôle dans son propre
   * onglet, et son rejet déclenchera la cascade RG-C (TCH_PRB_ARB_06).
   */
  public static final String NATURE_BALANCE_TRANSFER = "TRANSFERT_SOLDE";
}
