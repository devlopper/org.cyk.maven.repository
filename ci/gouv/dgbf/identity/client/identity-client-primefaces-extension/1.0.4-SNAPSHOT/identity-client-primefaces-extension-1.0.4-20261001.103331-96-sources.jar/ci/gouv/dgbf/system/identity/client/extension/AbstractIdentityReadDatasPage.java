package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.AbstractIdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import jakarta.inject.Inject;
import java.util.Set;
import lombok.Getter;

/**
 * Base de pages de lecture de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
public abstract class AbstractIdentityReadDatasPage extends AbstractPage {

  @Inject
  IdentityClient client;

  @Getter
  IdentityDto instance;

  @Inject
  @Getter
  IdentityReadTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture " + IdentityDto.NAME;
    instance =
        client.getByIdentifier(getRequestParameterIdentifier(), projection(), userIdentifier, null);

    tabMenuController.setInstance(instance);
    tabMenuController.initialize();
  }

  ProjectionDto projection() {
    return new ProjectionDto().addNames(PROJECTION_NAMES);
  }

  public static final Set<String> PROJECTION_NAMES = Set.of(HasIdentifierDto.JSON_IDENTIFIER,
      AbstractIdentityDto.JSON_FIRST_NAME, AbstractIdentityDto.JSON_LAST_NAMES,
      AbstractIdentityDto.JSON_EMAIL_ADDRESS);
}
