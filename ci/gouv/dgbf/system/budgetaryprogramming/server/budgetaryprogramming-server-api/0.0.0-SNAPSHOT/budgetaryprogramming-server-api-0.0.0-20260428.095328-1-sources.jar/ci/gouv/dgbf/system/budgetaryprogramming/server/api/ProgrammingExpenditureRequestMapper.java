package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExpenditureService.ProgrammingExpenditureCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExpenditureService.ProgrammingExpenditureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingExpenditureDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingExpenditureDto}.

    @author Christian
               """)
public interface ProgrammingExpenditureRequestMapper
    extends RequestMapper<ProgrammingExpenditureDto, ProgrammingExpenditureCreateRequestDto,
        ProgrammingExpenditureUpdateRequestDto> {

}
