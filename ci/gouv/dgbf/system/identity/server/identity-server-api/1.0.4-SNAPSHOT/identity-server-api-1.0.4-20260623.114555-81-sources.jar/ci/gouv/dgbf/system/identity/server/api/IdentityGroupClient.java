package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupService.IdentityGroupUpdateRolesRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link IdentityGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class IdentityGroupClient extends AbstractClient<IdentityGroupService>
    implements GetMany<IdentityGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetByIdentifier<IdentityGroupDto> {

  @Override
  public IdentityGroupClient service(IdentityGroupService service) {
    return (IdentityGroupClient) super.service(service);
  }

  /**
   * {@link IdentityGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(IdentityGroupCreateRequestDto request) {
    return new CreateExecutor(IdentityGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }
  
  /**
   * {@link IdentityGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentityGroupGetManyResponseDto>(
        IdentityGroupGetManyResponseDto.class, IdentityGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link IdentityGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentityGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentityGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentityGroupDto>(IdentityGroupDto.class,
        IdentityGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentityGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentityGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentityGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public IdentityGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentityGroupDto>(IdentityGroupDto.class,
        IdentityGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentityGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentityGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentityGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(IdentityGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(IdentityGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }
  
  /**
   * {@link IdentityGroupService#updateRoles}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateRoles(IdentityGroupUpdateRolesRequestDto request) {
    return new IdentifiableExecutor(IdentityGroupService.UPDATE_ROLES_IDENTIFIER)
        .execute(() -> service().updateRoles(request));
  }

  /**
   * {@link IdentityGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentityGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer une identité de groupe.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
