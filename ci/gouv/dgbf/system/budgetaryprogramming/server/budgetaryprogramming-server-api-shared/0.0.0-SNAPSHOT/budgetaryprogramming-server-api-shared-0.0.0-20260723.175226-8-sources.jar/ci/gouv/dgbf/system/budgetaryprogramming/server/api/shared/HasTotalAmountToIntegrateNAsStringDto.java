package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateNAsStringDto
    extends HasTotalAmountToIntegrateNAsString {

  /**
   * Identifiant json du montant total à intégrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_INTEGRATE_N_AS_STRING =
      "montantTotalAIntegrerNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName