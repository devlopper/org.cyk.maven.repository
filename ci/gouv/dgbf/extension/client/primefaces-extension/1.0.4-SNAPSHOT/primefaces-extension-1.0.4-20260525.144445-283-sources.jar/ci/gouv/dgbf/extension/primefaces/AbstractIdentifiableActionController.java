package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur d'action.
 *
 * @param <T> Type d'entité
 * @param <C> Type du client
 *
 * @author Christian 
 */
public abstract class AbstractIdentifiableActionController<T, C> extends AbstractController {

  @Getter
  @Setter
  protected T identifiable;

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param identifiable identifiable
   */
  public void initialize(T identifiable) {
    if (identifiable == null) {
      initializeWhenNull();
    } else {
      this.identifiable = identifiable;
      initializeWhenNotNull(identifiable);
    }
  }

  protected void initializeWhenNull() {}

  protected abstract void initializeWhenNotNull(T identifiable);

  protected abstract C getClient();
}
