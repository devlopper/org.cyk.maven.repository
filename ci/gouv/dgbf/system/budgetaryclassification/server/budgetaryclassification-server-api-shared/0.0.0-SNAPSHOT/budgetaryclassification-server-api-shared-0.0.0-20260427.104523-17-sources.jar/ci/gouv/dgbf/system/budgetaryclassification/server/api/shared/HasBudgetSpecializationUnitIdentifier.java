package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de l'unité de spécialisation du
 * budget.
 *
 * @author arnaud
 */
public interface HasBudgetSpecializationUnitIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité de spécialisation du budget.
   *
   * @return identifiant de l'unité de spécialisation du budget
   */
  String getBudgetSpecializationUnitIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'unité de spécialisation du budget.
   *
   * @param identifier identifiant de l'unité de spécialisation du budget
   */

  void setBudgetSpecializationUnitIdentifier(String identifier);
  /**
   * Identifiant java de l'identifiant de l'unité de spécialisation du budget.
   */

  String FIELD_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER = "budgetSpecializationUnitIdentifier";
}