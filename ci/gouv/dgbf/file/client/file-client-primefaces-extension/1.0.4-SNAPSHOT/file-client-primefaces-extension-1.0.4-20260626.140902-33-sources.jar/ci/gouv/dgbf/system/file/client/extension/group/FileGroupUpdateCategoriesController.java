package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListRecordProcessingController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.client.extension.file.FileCategorySelectOneController;
import ci.gouv.dgbf.system.file.server.api.FileCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateCategoriesRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de mise à jour des {@link FileCategoryDto} d'un
 * {@link FileGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupUpdateCategoriesController extends AbstractController {

  @Inject
  FileGroupClient client;

  @Inject
  FileGroupRequestMapper requestMapper;

  @Inject
  @Getter
  ListRecordProcessingController updateController;

  @Inject
  @Getter
  FileCategorySelectOneController categorySelectOneController;

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param listController contrôleur de liste
   */
  public void initialize(ListController listController) {
    updateController.initialize(listController, FileCategoryDto.PLURAL_NAME,
        "updateCategoriesForm");
    updateController.getController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, FileGroupDto.JSON_CATEGORIES_IDENTIFIERS));
    updateController.getController()
        .addEntityConsumer(entity -> Core.runIfCollectionNotEmpty(
            ((FileGroupDto) entity).getCategoriesIdentifiers(),
            () -> categorySelectOneController.getSelectOneRadio()
                .writeValue(((FileGroupDto) entity).getCategoriesIdentifiers().iterator().next())));
    updateController.getController().setFunction(entity -> {
      FileGroupUpdateCategoriesRequestDto request =
          requestMapper.mapUpdateCategories((FileGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.updateCategories(request);
    });

    categorySelectOneController.getSelectOneRadio().addValueConsumer(
        identifier -> ((FileGroupDto) updateController.getController().getEntity())
            .setCategoriesIdentifiersFrom(identifier));
  }
}
