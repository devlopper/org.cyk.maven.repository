package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.servicecatalog.server.api.OperationService.OperationCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.OperationService.OperationGetManyResponseDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.OperationService.OperationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link OperationDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class OperationClient extends AbstractClient<OperationService>
    implements GetByIdentifier<OperationDto>, GetMany<OperationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link OperationService}
   * @return client {@link OperationClient}
   */
  @Override
  public OperationClient service(OperationService service) {
    return (OperationClient) super.service(service);
  }

  /**
   * {@link OperationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(OperationCreateRequestDto request) {
    return new CreateExecutor(OperationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link OperationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public OperationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<OperationGetManyResponseDto>(
        OperationGetManyResponseDto.class,
        OperationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link OperationService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public OperationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link OperationService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public OperationDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    return new GetOneExecutor<OperationDto>(OperationDto.class,
        OperationService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link OperationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public OperationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    return new GetOneExecutor<OperationDto>(OperationDto.class,
        OperationService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link OperationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(OperationUpdateRequestDto request) {
    return new IdentifiableExecutor(OperationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link OperationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(OperationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
