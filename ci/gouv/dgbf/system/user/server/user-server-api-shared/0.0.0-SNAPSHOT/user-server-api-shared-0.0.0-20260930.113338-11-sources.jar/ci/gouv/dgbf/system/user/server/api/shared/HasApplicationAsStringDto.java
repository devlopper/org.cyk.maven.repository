package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'application.
 *
 * @author BoobaCool
 */
public interface HasApplicationAsStringDto extends HasApplicationAsString {

  /**
   * Identifiant json de représentation en chaine de caractères de l'application.
   */
  String JSON_APPLICATION_AS_STRING = "applicationChaine";
}
