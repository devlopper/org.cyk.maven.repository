package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityAsStringDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityIdentifierDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentityEmailAddressDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityEmailAddressController extends AbstractController {

  @Inject
  IdentityEmailAddressClient client;

  @Inject
  IdentityEmailAddressRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentitySelectOneController identitySelectOneController;

  @Inject
  @Getter
  InputTextController emailAddressInputTextController;

  @Inject
  @Getter
  IdentityEmailAddressFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = IdentityEmailAddressDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(IdentityEmailAddressDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(IdentityEmailAddressService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    
    projection.addNamesIfStringBlank(filterController.getFilter().getIdentityIdentifier(),
        HasIdentityAsStringDto.JSON_IDENTITY_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getEmailAddress(),
        HasEmailAddressDto.JSON_EMAIL_ADDRESS);
    projection.addNamesIfStringBlank(filterController.getFilter().getStatusCode(),
        IdentityEmailAddressDto.JSON_STATUS);

    listController.getReadController().setProjection(projection);

    listController.initialize();

    /* Creation */

    listController.getCreateController().addEntityConsumer(entity -> {
      identitySelectOneController.getAutoComplete().setRendered(true);
      emailAddressInputTextController.getInputText().writeValue(null);
    });
    listController.getCreateController().setFunction(entity -> {
      IdentityEmailAddressCreateRequestDto request =
          requestMapper.mapCreate((IdentityEmailAddressDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    /* Update */

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasIdentityIdentifierDto.JSON_IDENTITY_IDENTIFIER,
            HasEmailAddressDto.JSON_EMAIL_ADDRESS));

    listController.getUpdateController().addEntityConsumer(entity -> {
      identitySelectOneController.getAutoComplete().setRendered(false);
    });

    listController.getUpdateController().setFunction(entity -> {
      IdentityEmailAddressUpdateRequestDto request =
          requestMapper.mapUpdate((IdentityEmailAddressDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    /* Inputs */

    identitySelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, HasIdentityAsStringDto.JSON_IDENTITY_AS_STRING);

    identitySelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityEmailAddressDto.class)
            .setIdentityIdentifier(identifier));

    emailAddressInputTextController.setOutputLableValue("Adresse email");
    emailAddressInputTextController.getInputText()
        .addValueConsumer(value -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityEmailAddressDto.class)
            .setEmailAddress(value));
  }
}
