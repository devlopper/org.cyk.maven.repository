package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollFunctionaryService.PayrollFunctionaryCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollFunctionaryService.PayrollFunctionaryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollFunctionaryDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et
    {@link PayrollFunctionaryDto}.

    @author Christian
               """)
public interface PayrollFunctionaryRequestMapper extends RequestMapper<PayrollFunctionaryDto,
    PayrollFunctionaryCreateRequestDto, PayrollFunctionaryUpdateRequestDto> {

}
