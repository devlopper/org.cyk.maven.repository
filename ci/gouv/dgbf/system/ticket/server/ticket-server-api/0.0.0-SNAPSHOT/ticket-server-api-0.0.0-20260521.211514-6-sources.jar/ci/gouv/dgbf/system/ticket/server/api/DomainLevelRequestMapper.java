package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.DomainLevelService.DomainLevelCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.DomainLevelService.DomainLevelUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DomainLevelDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DomainLevelDto}.

    @author Christian
               """)
public interface DomainLevelRequestMapper
    extends RequestMapper<DomainLevelDto, DomainLevelCreateRequestDto,
     DomainLevelUpdateRequestDto> {

}
