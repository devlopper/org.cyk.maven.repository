package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe emploi.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class JobGroupDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto {

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  String typeIdentifier;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  String typeAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeEmploi";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeEmploiChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe d'emploi";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes d'emploi";
}
