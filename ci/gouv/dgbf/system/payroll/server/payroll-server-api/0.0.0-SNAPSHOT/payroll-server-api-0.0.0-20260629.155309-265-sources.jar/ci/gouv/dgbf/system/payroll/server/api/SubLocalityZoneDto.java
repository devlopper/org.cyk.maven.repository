package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une zone de sous-localité.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SubLocalityZoneDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link SubLocalityDto}.
   */
  @JsonbProperty(JSON_SUB_LOCALITY_IDENTIFIER)
  private String subLocalityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #subLocalityIdentifier}.
   */
  @JsonbProperty(JSON_SUB_LOCALITY_AS_STRING)
  private String subLocalityAsString;

  /**
   * Identifiant {@link PayrollTypeDto}.
   */
  @JsonbProperty(JSON_ZONE_IDENTIFIER)
  private String zoneIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #zoneIdentifier}.
   */
  @JsonbProperty(JSON_ZONE_AS_STRING)
  private String zoneAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSubLocalityZone";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "subLocalityZoneChaine";

  /**
   * Identifiant json de {@link #subLocalityIdentifier}.
   */
  public static final String JSON_SUB_LOCALITY_IDENTIFIER = "idSousLocalite";

  /**
   * Identifiant json de {@link #subLocalityAsString}.
   */
  public static final String JSON_SUB_LOCALITY_AS_STRING = "subLocalityChaine";

  /**
   * Identifiant json de {@link #zoneIdentifier}.
   */
  public static final String JSON_ZONE_IDENTIFIER = "idZone";

  /**
   * Identifiant json de {@link #zoneAsString}.
   */
  public static final String JSON_ZONE_AS_STRING = "zoneChaine";



  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "zone de sous-localité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "zones de sous-localité";
}
