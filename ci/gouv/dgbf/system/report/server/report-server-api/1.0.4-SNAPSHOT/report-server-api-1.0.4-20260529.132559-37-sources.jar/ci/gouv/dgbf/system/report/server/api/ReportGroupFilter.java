package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReportGroupDto}.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class ReportGroupFilter extends AbstractIdentifiableFilter {


  /**
   * Identifiant {@link ReportDto}.
   */
  String reportIdentifier;


  /**
   * Identifiant {@link ReportsGroupDto}.
   */
  String groupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ReportGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ReportGroupFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    reportIdentifier = getReportIdentifier(filter);
    groupIdentifier = getGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setReportIdentifier(filter, reportIdentifier);
    setGroupIdentifier(filter, groupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ReportDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link ReportDto}
   */
  public static void setReportIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_REPORT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ReportDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ReportDto}
   */
  public static String getReportIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REPORT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ReportsGroupDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link ReportsGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ReportsGroupDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ReportsGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link ReportGroupFilter#reportIdentifier}.
   */
  public static final String JSON_REPORT_IDENTIFIER =
      ReportGroupDto.JSON_REPORT_IDENTIFIER;


  /**
   * Identifiant json champ {@link ReportGroupFilter#groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
      ReportGroupDto.JSON_GROUP_IDENTIFIER;
}

