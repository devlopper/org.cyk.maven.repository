package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-04T12:21:41+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ResourceTypeConfidentialityRequestMapperImpl implements ResourceTypeConfidentialityRequestMapper {

    @Override
    public ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto mapCreate(ResourceTypeConfidentialityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto resourceTypeConfidentialityCreateRequestDto = new ResourceTypeConfidentialityService.ResourceTypeConfidentialityCreateRequestDto();

        resourceTypeConfidentialityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceTypeConfidentialityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceTypeConfidentialityCreateRequestDto.setResourceType( arg0.getResourceType() );
        resourceTypeConfidentialityCreateRequestDto.setConfidentialityLevel( arg0.getConfidentialityLevel() );

        return resourceTypeConfidentialityCreateRequestDto;
    }

    @Override
    public ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto mapUpdate(ResourceTypeConfidentialityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto resourceTypeConfidentialityUpdateRequestDto = new ResourceTypeConfidentialityService.ResourceTypeConfidentialityUpdateRequestDto();

        resourceTypeConfidentialityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceTypeConfidentialityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceTypeConfidentialityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        resourceTypeConfidentialityUpdateRequestDto.setResourceType( arg0.getResourceType() );
        resourceTypeConfidentialityUpdateRequestDto.setConfidentialityLevel( arg0.getConfidentialityLevel() );

        return resourceTypeConfidentialityUpdateRequestDto;
    }
}
