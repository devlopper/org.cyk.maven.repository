package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'unité administrative.
 *
 * @author Christian
 */
public interface FilterHasAdministrativeUnitIdentifier extends HasAdministrativeUnitIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant unité administrative.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAdministrativeUnitIdentifier(FilterDto filter) {
    setAdministrativeUnitIdentifier(AdministrativeUnitIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant unité administrative de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAdministrativeUnitIdentifier(FilterDto filter) {
    AdministrativeUnitIdentifierFilter.set(filter, getAdministrativeUnitIdentifier());
  }

}
