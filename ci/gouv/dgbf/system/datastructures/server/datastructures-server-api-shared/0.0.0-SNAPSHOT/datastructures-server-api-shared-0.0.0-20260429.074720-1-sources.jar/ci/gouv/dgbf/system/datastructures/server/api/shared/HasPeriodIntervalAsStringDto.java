package ci.gouv.dgbf.system.datastructures.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'intervalle de période.
 *
 * @author Christian
 */
public interface HasPeriodIntervalAsStringDto extends HasPeriodIntervalAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'intervalle de période.
   */
  String JSON_PERIOD_INTERVAL_AS_STRING = "intervallePeriodeChaine";
}
