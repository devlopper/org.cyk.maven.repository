package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PolicyTypeDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class PolicyTypeFilter extends AbstractIdentifiableFilter {

}
