package ci.gouv.dgbf.extension.primefaces.page;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/** Modèle de présentation stable, détenu par le bean de page. */
public final class IdentifiablePageModel implements Serializable {
  private static final long serialVersionUID = 1L;
  private IdentifiablePageStatus status = IdentifiablePageStatus.INITIAL;
  private IdentifiablePageStatus presentationStatus = IdentifiablePageStatus.INITIAL;
  private String message;
  private String title;
  private final List<IdentifiablePageNavigation> navigations = new ArrayList<>();

  public IdentifiablePageStatus getStatus() {
    return status;
  }

  public String getMessage() {
    return message;
  }

  public String getTitle() {
    return title;
  }

  /** Titre contextualisé facultatif ; null conserve le titre générique de la vue. */
  public void setTitle(String title) {
    this.title = title;
  }

  public IdentifiablePageStatus getPresentationStatus() {
    return presentationStatus;
  }

  public boolean isAvailable() {
    return status == IdentifiablePageStatus.AVAILABLE;
  }

  public boolean isLoading() {
    return status == IdentifiablePageStatus.LOADING;
  }

  /** Indique si la page doit afficher le panneau de message et de navigation. */
  public boolean isUnavailable() {
    return status == IdentifiablePageStatus.MISSING_IDENTIFIER
        || status == IdentifiablePageStatus.NO_RESOURCE_AVAILABLE
        || status == IdentifiablePageStatus.NOT_FOUND
        || status == IdentifiablePageStatus.ACCESS_DENIED
        || status == IdentifiablePageStatus.ERROR;
  }

  public List<IdentifiablePageNavigation> getNavigations() {
    return List.copyOf(navigations);
  }

  public IdentifiablePageModel addNavigation(IdentifiablePageNavigation navigation) {
    navigations.add(Objects.requireNonNull(navigation));
    return this;
  }

  public void update(IdentifiablePageStatus status, String message) {
    update(status, message, false);
  }

  /** Sépare la cause interne de sa présentation publique lorsque l'accès doit être masqué. */
  public void update(IdentifiablePageStatus status, String message, boolean hideAccessDenied) {
    this.status = Objects.requireNonNull(status);
    presentationStatus = hideAccessDenied && status == IdentifiablePageStatus.ACCESS_DENIED
        ? IdentifiablePageStatus.NOT_FOUND : status;
    this.message = message;
    title = null;
  }

  /** Vérifie la présence d'une issue de navigation avant la résolution. */
  public void validate() {
    if (navigations.isEmpty()) {
      throw new IllegalStateException("Au moins une navigation de page de ressource est requise");
    }
  }
}
