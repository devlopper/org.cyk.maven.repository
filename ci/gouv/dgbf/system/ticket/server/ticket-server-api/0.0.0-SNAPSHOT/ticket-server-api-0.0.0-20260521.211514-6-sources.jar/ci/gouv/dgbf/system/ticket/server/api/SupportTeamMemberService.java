package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SupportTeamMemberDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = SupportTeamMemberService.PATH)
@Tag(name = "Gestion des membres équipe support")
public interface SupportTeamMemberService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "membres-equipe-support";


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface SupportTeamMemberSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link SupportTeamDto}.
     *
     * @return identifiant de {@link SupportTeamDto}
     */
    String getSupportTeamIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link SupportTeamDto}.
     *
     * @param supportServiceIdentifier identifiant de {@link SupportTeamDto}
     */
    void setSupportTeamIdentifier(String supportServiceIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'utilisateur.
     *
     * @return identifiant de l'utilisateur
     */
    String getUserIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'utilisateur.
     *
     * @param userIdentifier identifiant de l'utilisateur
     */
    void setUserIdentifier(String userIdentifier);

    /**
     * Cette méthode permet de savoir vrai si un agent est responsable.
     *
     * @return vrai es responsable sinon faux
     */
    Boolean getIsResponsible();


    /**
     * Identifiant json identifiant de {@link SupportTeamDto}.
     */
    String JSON_SUPPORT_TEAM_IDENTIFIER = SupportTeamDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link SupportTeamMemberDto}.
     */
    String JSON_USER_IDENTIFIER = SupportTeamMemberDto.JSON_USER_IDENTIFIER;

    /**
     * {@link SupportTeamMemberDto#JSON_IS_RESPONSIBLE}.
     */
    String JSON_IS_RESPONSIBLE = SupportTeamMemberDto.JSON_IS_RESPONSIBLE;


  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SupportTeamMemberCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class SupportTeamMemberCreateRequestDto extends AbstractAuditedRequestJsonDto
        implements SupportTeamMemberSaveRequestDto {
    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_SUPPORT_TEAM_IDENTIFIER)
    private String supportTeamIdentifier;

    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_IS_RESPONSIBLE)
    private Boolean isResponsible;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = SupportTeamMemberGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class SupportTeamMemberGetManyResponseDto
      extends AbstractGetByPageResponseDto<SupportTeamMemberDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SupportTeamMemberDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SupportTeamMemberDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SupportTeamMemberDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SupportTeamMemberUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class SupportTeamMemberUpdateRequestDto extends ByIdentifierRequestDto implements
        SupportTeamMemberSaveRequestDto {
    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_SUPPORT_TEAM_IDENTIFIER)
    private String supportTeamIdentifier;

    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(SupportTeamMemberSaveRequestDto.JSON_IS_RESPONSIBLE)
    private Boolean isResponsible;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MEMBRE_SERVICE_SUPPORT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SupportTeamMemberDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
