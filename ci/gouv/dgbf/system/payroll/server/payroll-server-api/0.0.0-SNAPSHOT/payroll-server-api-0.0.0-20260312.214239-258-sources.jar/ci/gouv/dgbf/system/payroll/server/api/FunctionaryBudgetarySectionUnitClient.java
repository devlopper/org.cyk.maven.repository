package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.FunctionaryBudgetarySectionUnitService.FunctionaryBudgetarySectionUnitGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link FunctionaryBudgetarySectionUnitService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class FunctionaryBudgetarySectionUnitClient extends AbstractClient<
    FunctionaryBudgetarySectionUnitService> implements
    GetByIdentifier<FunctionaryBudgetarySectionUnitDto>, 
    GetMany<FunctionaryBudgetarySectionUnitGetManyResponseDto> {

  @Override
  public FunctionaryBudgetarySectionUnitClient service(
          FunctionaryBudgetarySectionUnitService service) {
    return (FunctionaryBudgetarySectionUnitClient) super.service(service);
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionaryBudgetarySectionUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FunctionaryBudgetarySectionUnitGetManyResponseDto>(
        FunctionaryBudgetarySectionUnitGetManyResponseDto.class, 
        FunctionaryBudgetarySectionUnitService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionaryBudgetarySectionUnitGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionaryBudgetarySectionUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FunctionaryBudgetarySectionUnitDto>(
        FunctionaryBudgetarySectionUnitDto.class,
        FunctionaryBudgetarySectionUnitService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionaryBudgetarySectionUnitDto getOne(ProjectionDto projection, FilterDto filter, 
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FunctionaryBudgetarySectionUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FunctionaryBudgetarySectionUnitDto>(
        FunctionaryBudgetarySectionUnitDto.class,
        FunctionaryBudgetarySectionUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FunctionaryBudgetarySectionUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionaryBudgetarySectionUnitDto getByIdentifier(String identifier, 
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
