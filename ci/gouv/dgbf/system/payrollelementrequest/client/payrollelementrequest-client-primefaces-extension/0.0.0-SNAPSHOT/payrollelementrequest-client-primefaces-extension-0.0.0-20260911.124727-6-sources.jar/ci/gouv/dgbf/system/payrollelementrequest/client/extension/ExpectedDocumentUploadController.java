package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup.DocumentTypeGroupUploadController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentGetManyResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentUpdateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe étend le contrôleur de dépôt des pièces attendues du module {@code documentation}
 * ({@link DocumentTypeGroupUploadController} : rafraîchissement de la liste attendue, dépôt et
 * retrait d'un fichier, création des documents, remise à blanc) avec le cycle de vie propre à la
 * Réclamation (RG_REP_PCE_02) : création du dossier de pièces avant la réclamation, rechargement
 * des pièces déjà déposées à l'ouverture en modification, et synchronisation
 * création/remplacement/suppression au ré-enregistrement.
 *
 * @author akm
 *
 */
@Dependent
public class ExpectedDocumentUploadController extends DocumentTypeGroupUploadController {

  @Inject
  DocumentGroupClient documentGroupClient;

  @Inject
  DocumentClient documentClient;

  @Inject
  FileClient fileClient;

  /**
   * Identifiant du document déjà persisté et identifiant de son fichier d'origine, par
   * identifiant de type de pièce. Renseigné par {@link #loadExistingDocuments(String)} à
   * l'ouverture d'une réclamation existante, exploité par {@link #syncDocuments(String)} pour
   * distinguer une pièce déjà persistée (à mettre à jour ou supprimer) d'une pièce nouvellement
   * déposée (à créer) et pour détecter un remplacement de fichier -- l'{@code Upload} partagé ne
   * porte pas cet état.
   */
  private final Map<String, PersistedDocument> persistedDocuments = new HashMap<>();

  /**
   * Identifiant du processus métier transmis au module {@code documentation} (contexte
   * obligatoire, RG_DOC_GRP_01).
   */
  public static final String PROCESS_IDENTIFIER = "RECLAMATION_ELEMENTS_PAIE";

  /**
   * Identifiant du module source transmis au module {@code documentation}.
   */
  public static final String SOURCE_IDENTIFIER = "reclamation-elements-paie";

  /**
   * Identifiant de l'opération transmise au module {@code documentation}.
   */
  public static final String OPERATION_IDENTIFIER = "CREATION_RECLAMATION";

  /**
   * Cette méthode permet de créer le dossier de pièces ({@link DocumentGroupDto}) d'une
   * réclamation (RG_REP_PCE_02). La réclamation n'existe pas encore à cet instant (le dossier de
   * pièces est créé avant elle, pour disposer de son identifiant à la création) : l'identifiant
   * d'enregistrement transmis au module {@code documentation} est donc un identifiant de
   * corrélation généré ici, sans lien de clé étrangère (couplage faible, comme les autres
   * références inter-modules de la Réclamation).
   *
   * @param typeGroupIdentifier identifiant du groupe de types de document attendu
   * @return identifiant du dossier de pièces créé
   */
  public String createDocumentGroup(String typeGroupIdentifier) {
    DocumentGroupCreateRequestDto request = new DocumentGroupCreateRequestDto();
    request.setTypeGroupIdentifier(typeGroupIdentifier);
    request.setProcessIdentifier(PROCESS_IDENTIFIER);
    request.setSourceIdentifier(SOURCE_IDENTIFIER);
    request.setRecordIdentifier(UUID.randomUUID().toString());
    request.setOperationIdentifier(OPERATION_IDENTIFIER);
    request.setAuditWho(userIdentifier);
    CreateResponseDto response = documentGroupClient.create(request);
    return response.getIdentifier();
  }

  /**
   * Cette méthode permet de compléter la liste des dépôts attendus (déjà rafraîchie via
   * {@link #refresh(String)}) avec les documents déjà déposés dans un dossier de pièces
   * existant -- utilisé à l'ouverture d'une réclamation existante en modification. Une
   * indisponibilité du module {@code documentation} ne doit pas empêcher cette ouverture : on se
   * contente de journaliser et de retomber sur la liste des dépôts attendus sans documents déjà
   * déposés.
   *
   * @param groupIdentifier identifiant du dossier de pièces
   */
  public void loadExistingDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentDto.JSON_TYPE_IDENTIFIER, DocumentDto.JSON_FILE_IDENTIFIER);
    FilterDto filter =
        new FilterDto().addCriteria(DocumentDto.JSON_GROUP_IDENTIFIER, groupIdentifier);
    DocumentGetManyResponseDto response;
    try {
      response = documentClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des documents du dossier " + groupIdentifier + " en échec.", exception);
      return;
    }
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(document -> getUploads().stream()
        .filter(upload -> upload.getTypeIdentifier().equals(document.getTypeIdentifier()))
        .findFirst().ifPresent(upload -> {
          persistedDocuments.put(upload.getTypeIdentifier(),
              new PersistedDocument(document.getIdentifier(), document.getFileIdentifier()));
          upload.setFileIdentifier(document.getFileIdentifier());
          FileDto file = resolveFile(document.getFileIdentifier());
          upload.setFileName(file == null ? document.getFileIdentifier() : file.getName());
        }));
  }

  /**
   * Cette méthode permet d'obtenir le fichier déjà déposé pour un document existant, à partir de
   * son identifiant -- une indisponibilité du module {@code file} ne doit pas empêcher l'ouverture
   * du dialogue de modification d'une réclamation existante (RG_REP_PCE_02 reste consultable/
   * modifiable même si son nom de fichier ne peut pas être affiché) : on se contente de
   * journaliser et de retomber sur l'identifiant brut du fichier (cf.
   * {@link #loadExistingDocuments}).
   *
   * @param fileIdentifier identifiant du fichier
   * @return le fichier, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private FileDto resolveFile(String fileIdentifier) {
    try {
      return fileClient.getByIdentifier(fileIdentifier,
          new ProjectionDto().addNames(FileDto.JSON_NAME), userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention du fichier " + fileIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de synchroniser, en modification d'une réclamation existante, les
   * documents du dossier de pièces avec l'état courant des dépôts attendus : création des pièces
   * nouvellement déposées, mise à jour de celles dont le fichier a été remplacé, et suppression
   * de celles retirées par l'utilisateur (RG_REP_PCE_02).
   *
   * @param groupIdentifier identifiant du dossier de pièces
   */
  public void syncDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    getUploads().forEach(upload -> {
      PersistedDocument persisted = persistedDocuments.get(upload.getTypeIdentifier());
      if (persisted == null) {
        if (upload.getFileIdentifier() != null) {
          DocumentCreateRequestDto request = new DocumentCreateRequestDto();
          request.setTypeIdentifier(upload.getTypeIdentifier());
          request.setGroupIdentifier(groupIdentifier);
          request.setFileIdentifier(upload.getFileIdentifier());
          request.setAuditWho(userIdentifier);
          documentClient.create(request);
        }
      } else if (upload.getFileIdentifier() == null) {
        documentClient.deleteByIdentifier(persisted.documentIdentifier(), userIdentifier, null);
      } else if (!upload.getFileIdentifier().equals(persisted.originalFileIdentifier())) {
        DocumentUpdateRequestDto request = new DocumentUpdateRequestDto();
        request.setIdentifier(persisted.documentIdentifier());
        request.setTypeIdentifier(upload.getTypeIdentifier());
        request.setGroupIdentifier(groupIdentifier);
        request.setFileIdentifier(upload.getFileIdentifier());
        request.setAuditWho(userIdentifier);
        documentClient.update(request);
      }
    });
  }

  /**
   * Cette méthode permet de repartir d'un formulaire vierge : au vidage des dépôts et de
   * l'identifiant de groupe courant fait par {@link DocumentTypeGroupUploadController#reset()},
   * elle ajoute l'oubli des documents déjà persistés référencés pour la synchronisation.
   */
  @Override
  public void reset() {
    super.reset();
    persistedDocuments.clear();
  }

  /**
   * Cette classe représente un document déjà persisté pour une pièce attendue : son identifiant
   * et l'identifiant de son fichier d'origine, afin de détecter un remplacement de fichier
   * (RG_REP_PCE_02).
   *
   * @param documentIdentifier identifiant du document persisté
   * @param originalFileIdentifier identifiant du fichier tel que chargé depuis ce document
   */
  private record PersistedDocument(String documentIdentifier, String originalFileIdentifier) {
  }
}
