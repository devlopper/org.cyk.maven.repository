package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationClient;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base de page de lecture de données de {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
public abstract class AbstractApplicationReadDatasPage extends AbstractPage {

  @Inject
  protected ApplicationClient client;

  @Getter
  ApplicationDto application;

  @Inject
  @Getter
  UserRoleCreateManyController createManyController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + ApplicationDto.NAME;

    String identifier = getRequestParameterIdentifier();
    application = client.getByIdentifier(identifier,
        new ProjectionDto().addNames(
            AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            ApplicationDto.JSON_DOMAIN_AS_STRING,
            // Code du Domaine : Droits calculés pour la fiche (RG_UTI_ROL_16)
            ApplicationDto.JSON_DOMAIN_CODE,
            // Nombres de la fiche (RU_UTI_027)
            HasRoleCountAsStringDto.JSON_ROLE_COUNT_AS_STRING,
            HasUserCountAsStringDto.JSON_USER_COUNT_AS_STRING,
            HasPendingRoleSolicitationCountAsStringDto
                .JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING),
        userIdentifier, null);
  }
}
