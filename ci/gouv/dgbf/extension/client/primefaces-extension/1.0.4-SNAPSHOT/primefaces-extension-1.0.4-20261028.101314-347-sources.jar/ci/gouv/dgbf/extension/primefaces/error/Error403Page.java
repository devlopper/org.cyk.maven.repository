package ci.gouv.dgbf.extension.primefaces.error;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page d'erreur de code 403.
 *
 * @author Christian
 */
@Named
@RequestScoped
public class Error403Page extends AbstractPage {

  public Error403Page() {
    title = "Accès non autorisé (403)";
    contentTitle = "Accès non autorisé";
  }
}
