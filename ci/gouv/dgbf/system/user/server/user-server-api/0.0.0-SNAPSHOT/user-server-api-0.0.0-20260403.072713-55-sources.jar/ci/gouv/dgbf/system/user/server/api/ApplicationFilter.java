package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DomainDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class ApplicationFilter extends AbstractIdentifiableFilter {

  /**
   * Nom.
   */
  private String name;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ApplicationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ApplicationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);

  }

  /**
   * Cette méthode permet d'assigner le libelle du application.
   *
   * @param filter filtre
   * @param name libelle du application
   */

  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir libelle de l'application  assignés.
   *
   * @param filter filtre
   * @return identifiant libelle
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  
  
  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME =
      ApplicationDto.JSON_NAME;

}
