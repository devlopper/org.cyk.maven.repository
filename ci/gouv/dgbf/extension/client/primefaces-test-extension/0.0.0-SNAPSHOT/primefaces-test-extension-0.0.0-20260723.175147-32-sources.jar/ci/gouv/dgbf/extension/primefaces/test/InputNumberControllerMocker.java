package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.input.InputBigDecimal;
import ci.gouv.dgbf.extension.primefaces.component.input.InputFloat;
import ci.gouv.dgbf.extension.primefaces.component.input.InputInteger;
import ci.gouv.dgbf.extension.primefaces.component.input.InputLong;
import ci.gouv.dgbf.extension.primefaces.component.input.InputNumberController;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link InputNumberController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class InputNumberControllerMocker {

  InputInteger inputInteger;

  InputLong inputLong;
  
  InputFloat inputFloat;
  
  InputBigDecimal inputBigDecimal;
  
  /**
   * Cette méthode permet d'instancier.
   *
   */
  public InputNumberControllerMocker() {
    inputInteger = new InputInteger();
    inputLong = new InputLong();
    inputFloat = new InputFloat();
    inputBigDecimal = new InputBigDecimal();
  }

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link InputNumberController}
   */
  public InputNumberController mock() {
    InputNumberController controller = Mockito.mock(InputNumberController.class);
    Mockito.when(controller.getInputInteger()).thenReturn(inputInteger);
    Mockito.when(controller.getInputLong()).thenReturn(inputLong);
    Mockito.when(controller.getInputFloat()).thenReturn(inputFloat);
    Mockito.when(controller.getInputBigDecimal()).thenReturn(inputBigDecimal);
    return controller;
  }

}
