package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceGroupService.ValueSourceGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueSourceGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSourceGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    ValueSourceGroupDto, ValueSourceGroupGetManyResponseDto, ValueSourceGroupClient> {

  @Getter
  @Inject
  ValueSourceGroupClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected ValueSourceGroupSelectOneController() {
    super(ValueSourceGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
