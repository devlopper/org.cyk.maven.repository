package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextService.ScriptContextCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextService.ScriptContextUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptContextDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptContextDto}.

    @author Christian
               """)
public interface ScriptContextRequestMapper extends
    RequestMapper<ScriptContextDto, ScriptContextCreateRequestDto, ScriptContextUpdateRequestDto> {
}
