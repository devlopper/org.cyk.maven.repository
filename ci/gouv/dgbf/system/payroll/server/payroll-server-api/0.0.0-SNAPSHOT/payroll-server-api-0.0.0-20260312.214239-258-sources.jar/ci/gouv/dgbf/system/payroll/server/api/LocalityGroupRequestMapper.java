package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.LocalityGroupService.LocalityGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.LocalityGroupService.LocalityGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link LocalityGroupDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link LocalityDto}.

    @author arnaud
               """)
public interface LocalityGroupRequestMapper extends RequestMapper<LocalityGroupDto,
    LocalityGroupCreateRequestDto, LocalityGroupUpdateRequestDto> {

}
