package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputNumberController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexClient;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService.PayIndexCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService.PayIndexUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link PayIndexDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayIndexController extends AbstractController {

  @Inject
  PayIndexClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  PayIndexFilterController filterController;

  @Inject
  PayIndexRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputNumberController valueInputNumberController;

  @Inject
  @Getter
  PayScaleSelectOneController payScaleSelectOneController;

  @Inject
  @Getter
  GradeSelectOneController gradeSelectOneController;

  @Inject
  @Getter
  GradeClassSelectOneController gradeClassSelectOneController;

  @Inject
  @Getter
  EchelonSelectOneController echelonSelectOneController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = PayIndexDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(PayIndexDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(PayIndexService.PATH);

    listController.getDataTable().getFilterButton().setRendered(true);


    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        PayIndexDto.JSON_GRADE_IDENTIFIER, PayIndexDto.JSON_GRADE_AS_STRING,
        PayIndexDto.JSON_GRADE_CLASS_IDENTIFIER, PayIndexDto.JSON_GRADE_CLASS_AS_STRING,
        PayIndexDto.JSON_ECHELON_AS_STRING, PayIndexDto.JSON_VALUE);

    projection.addNamesIfStringBlank(filterController.getFilter().getPayScaleIdentifier(),
        PayIndexDto.JSON_PAY_SCALE_AS_STRING);

    listController.getReadController().setProjection(projection);

    payScaleSelectOneController.setRenderable(StringCore.isBlank(filterController
        .getFilter().getPayScaleIdentifier()));

    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());

    listController.getCreateController().setFunction(entity -> {
      PayIndexCreateRequestDto request = requestMapper.mapCreate((PayIndexDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            PayIndexDto.JSON_PAY_SCALE_IDENTIFIER, PayIndexDto.JSON_GRADE_IDENTIFIER,
            PayIndexDto.JSON_GRADE_CLASS_IDENTIFIER, PayIndexDto.JSON_ECHELON_IDENTIFIER,
            PayIndexDto.JSON_VALUE));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    payScaleSelectOneController.getSelectOneMenu().setRequired(true);
    payScaleSelectOneController.getSelectOneMenu().addValueConsumer(payScaleIdentifierConsumer());

    gradeSelectOneController.getSelectOneMenu().setRequired(true);
    gradeSelectOneController.getSelectOneMenu().addValueConsumer(gradeIdentifierConsumer());

    gradeClassSelectOneController.getSelectOneMenu().setRequired(true);
    gradeClassSelectOneController.getSelectOneMenu()
        .addValueConsumer(gradeClassIdentifierConsumer());

    echelonSelectOneController.getSelectOneMenu().setRequired(true);
    echelonSelectOneController.getSelectOneMenu().addValueConsumer(echelonIdentifierConsumer());

    valueInputNumberController.setOutputLableValue("Valeur");
    valueInputNumberController.getInputInteger().setRequired(true);
    valueInputNumberController.getInputInteger().addValueConsumer(valueConsumer());

    
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
    
      ((PayIndexDto) entity).setPayScaleIdentifier(filterController.getFilter()
          .getPayScaleIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {

      payScaleSelectOneController.getSelectOneMenu()
          .writeValue(((PayIndexDto) entity).getPayScaleIdentifier());

      gradeSelectOneController.getSelectOneMenu()
          .writeValue(((PayIndexDto) entity).getGradeIdentifier());

      gradeClassSelectOneController.getSelectOneMenu()
          .writeValue(((PayIndexDto) entity).getGradeClassIdentifier());

      echelonSelectOneController.getSelectOneMenu()
          .writeValue(((PayIndexDto) entity).getEchelonIdentifier());

      valueInputNumberController.getInputInteger().writeValue(((PayIndexDto) entity).getValue());
    };
  }

  Consumer<String> payScaleIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PayIndexDto.class)
        .setPayScaleIdentifier(identifier);
  }

  Consumer<String> gradeIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PayIndexDto.class)
        .setGradeIdentifier(identifier);
  }

  Consumer<String> gradeClassIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PayIndexDto.class)
        .setGradeClassIdentifier(identifier);
  }

  Consumer<String> echelonIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PayIndexDto.class)
        .setEchelonIdentifier(identifier);
  }

  Consumer<Integer> valueConsumer() {
    return value -> listController.getCreateControllerOrUpdateControllerEntityAs(PayIndexDto.class)
        .setValue(value);
  }



  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      PayIndexUpdateRequestDto request = requestMapper.mapUpdate((PayIndexDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(valueInputNumberController.getInputInteger()).stream()
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
