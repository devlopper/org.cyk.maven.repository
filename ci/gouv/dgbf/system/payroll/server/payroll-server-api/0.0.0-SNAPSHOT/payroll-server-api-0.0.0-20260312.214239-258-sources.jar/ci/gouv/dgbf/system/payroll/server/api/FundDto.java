package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une caisse.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FundDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCaisse";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "caisseChaine";

  /**
   * Identifiant json de {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
      FundGroupDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant json de {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING =
      FundGroupDto.JSON_THIS_AS_STRING;


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "caisse";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "caisses";
}
