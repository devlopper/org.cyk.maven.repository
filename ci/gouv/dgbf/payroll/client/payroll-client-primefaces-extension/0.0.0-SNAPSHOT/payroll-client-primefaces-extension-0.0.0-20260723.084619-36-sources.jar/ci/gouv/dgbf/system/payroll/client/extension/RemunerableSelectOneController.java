package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.RemunerableClient;
import ci.gouv.dgbf.system.payroll.server.api.RemunerableDto;
import ci.gouv.dgbf.system.payroll.server.api.RemunerableService.RemunerableGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RemunerableDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class RemunerableSelectOneController extends AbstractSelectOneIdentifiableController<
    RemunerableDto, RemunerableGetManyResponseDto, RemunerableClient> {

  @Getter
  @Inject
  RemunerableClient client;

  protected RemunerableSelectOneController() {
    super(RemunerableDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
