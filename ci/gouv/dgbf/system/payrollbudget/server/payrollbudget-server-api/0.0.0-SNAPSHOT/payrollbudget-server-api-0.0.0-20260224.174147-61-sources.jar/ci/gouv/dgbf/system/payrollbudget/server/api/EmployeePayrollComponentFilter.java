package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitEmployeeIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class EmployeePayrollComponentFilter extends AbstractIdentifiableFilter
    implements FilterHasAdministrativeUnitEmployeeIdentifier {

  /**
   * Identifiant {@link AdministrativeUnitEmployeeDto}.
   */
  String administrativeUnitEmployeeIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public EmployeePayrollComponentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public EmployeePayrollComponentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitEmployeeIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitEmployeeIdentifier(filter);
  }
}

