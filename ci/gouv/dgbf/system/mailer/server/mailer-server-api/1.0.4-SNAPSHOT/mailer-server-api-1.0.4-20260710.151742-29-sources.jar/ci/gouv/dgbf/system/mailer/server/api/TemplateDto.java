package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.segregation.HasBodyHtmlDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyHtmlPreviewDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyTextDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyTextPreviewDto;
import ci.gouv.dgbf.extension.core.segregation.HasSubjectDto;
import ci.gouv.dgbf.extension.core.segregation.HasSubjectPreviewDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.HasParameterValuesExampleDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.HasParameterValuesExampleFormatDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un modèle de mail.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TemplateDto extends AbstractIdentifiableCodableNamableAuditableDto implements
    HasSubjectDto, HasSubjectPreviewDto, HasBodyHtmlDto, HasBodyHtmlPreviewDto, HasBodyTextDto,
    HasBodyTextPreviewDto, HasParameterValuesExampleDto, HasParameterValuesExampleFormatDto {

  @JsonbProperty(JSON_SUBJECT)
  private String subject;

  @JsonbProperty(JSON_SUBJECT_PREVIEW)
  private String subjectPreview;

  @JsonbProperty(JSON_BODY_HTML)
  private String bodyHtml;

  @JsonbProperty(JSON_BODY_HTML_PREVIEW)
  private String bodyHtmlPreview;

  @JsonbProperty(JSON_BODY_TEXT)
  private String bodyText;

  @JsonbProperty(JSON_BODY_TEXT_PREVIEW)
  private String bodyTextPreview;

  @JsonbProperty(JSON_PARAMETER_VALUES_EXAMPLE)
  private String parameterValuesExample;

  @JsonbProperty(JSON_PARAMETER_VALUES_EXAMPLE_FORMAT)
  private StringFormat parameterValuesExampleFormat;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idModele";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "modeleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "modèle de mail";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modèles de mail";
}
