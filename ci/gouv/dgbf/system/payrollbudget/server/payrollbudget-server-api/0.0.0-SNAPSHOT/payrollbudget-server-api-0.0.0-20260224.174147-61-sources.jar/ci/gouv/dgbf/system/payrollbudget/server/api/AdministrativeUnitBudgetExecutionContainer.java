package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette interface représente un conteneur de {@link AdministrativeUnitBudgetExecutionDto}.
 *
 * @author parfait
 */
public interface AdministrativeUnitBudgetExecutionContainer {
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'exercice 
   * du budget.
   *
   * @return représentation en chaine de caractères de l'exercice du budget
   */
  String getBudgetExerciseAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget de l'unité 
   * administrative.
   *
   * @return représentation en chaine de caractères du budget de l'unité administrative
   */
  String getBudgetAdministrativeUnitAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'activité.
   *
   * @return représentation en chaine de caractères de l'activité
   */
  String getActivityAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la nature
   * économique.
   *
   * @return représentation en chaine de caractères de la nature économique
   */
  String getEconomicNatureAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du mandat.
   *
   * @return représentation en chaine de caractères du mandat
   */
  String getMandateAmountAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du mandat précédent.
   *
   * @return représentation en chaine de caractères du mandat précédent
   */
  String getMandateAmountPrecedentAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget initial.
   *
   * @return représentation en chaine de caractères du budget initial
   */
  String getInitialBudgetAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget initial
   * précédent.
   *
   * @return représentation en chaine de caractères du budget initial précédent
   */
  String getInitialBudgetPrecedentAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget actuel.
   *
   * @return représentation en chaine de caractères du budget actuel
   */
  String getActualBudgetAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget actuel
   * précédent.
   *
   * @return représentation en chaine de caractères du budget actuel précédent
   */
  String getActualBudgetPrecedentAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget exécuté.
   *
   * @return représentation en chaine de caractères du budget exécuté
   */
  String getRemainingExecutedBudgetAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du budget précédent 
   * exécuté.
   *
   * @return représentation en chaine de caractères du budget précédent exécuté
   */
  String getRemainingExecutedBudgetPrecedentAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant de
   * référence.
   *
   * @return représentation en chaine de caractères du montant de référence
   */
  String getReferenceAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la variance du
   * montant.
   *
   * @return représentation en chaine de caractères de la variance du montant
   */
  String getAmountVariationAsString();
  
  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant.
   *
   * @return représentation en chaine de caractères du montant
   */
  String getAmountAsString();

  /**
   * Identifiant java {@link ExerciseDto}.
   */
  String FIELD_BUDGET_EXERCISE_IDENTIFIER = "budgetExerciseIdentifier";

  /**
   * Identifiant java de la représentation en chaine de caractères de {@link ExerciseDto}.
   */
  String FIELD_BUDGET_EXERCISE_AS_STRING = "budgetExerciseAsString";

  /**
   * Identifiant java {@link BudgetAdministrativeUnitDto}.
   */
  String FIELD_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      "budgetAdministrativeUnitIdentifier";

  /**
   * Identifiant java de la représentation en chaine de caractères de 
   * {@link BudgetAdministrativeUnitDto}.
   */
  String FIELD_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING =
      "budgetAdministrativeUnitAsString";
  
  /**
   * Identifiant java de la représentation de l'activité du poste de dépense 
   * en chaine de caractères.
   */
  String FIELD_ACTIVITY_AS_STRING = "activityAsString";
  
  /**
   * Identifiant java de la représentation de la nature économique du poste de dépense 
   * en chaine de caractères.
   */
  String FIELD_ECONOMIC_NATURE_AS_STRING = "economicNatureAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du montant mandaté.
   */
  String FIELD_MANDATE_AMOUNT_AS_STRING = "mandateAmountAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du montant mandaté précédent.
   */
  String FIELD_MANDATE_AMOUNT_PRECEDENT_AS_STRING = "mandateAmountPrecedentAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du budget initial.
   */
  String FIELD_INITIAL_BUDGET_AS_STRING = "initialBudgetAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du budget initial précédent.
   */
  String FIELD_INITIAL_BUDGET_PRECEDENT_AS_STRING = "initialBudgetPrecedentAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du budget actuel.
   */
  String FIELD_ACTUAL_BUDGET_AS_STRING = "actualBudgetAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du budget actuel précédent.
   */
  String FIELD_ACTUAL_BUDGET_PRECEDENT_AS_STRING = "actualBudgetPrecedentAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du reste du budget exécuté.
   */
  String FIELD_REMAINING_EXECUTED_BUDGET_AS_STRING = "remainingExecutedBudgetAsString";
  
  /**
   * Identifiant java de la représentation en chaine de caractères 
   * du reste du budget précédent exécuté.
   */
  String FIELD_REMAINING_EXECUTED_BUDGET_PRECEDENT_AS_STRING = 
      "remainingExecutedBudgetPrecedentAsString";
  
  /**
   * Identifiant java du montant de référence.
   */
  String FIELD_REFERENCE_AMOUNT = "referenceAmount";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du montant de référence.
   */
  String FIELD_REFERENCE_AMOUNT_AS_STRING = "referenceAmountAsString";

  /**
   * Identifiant java de la variation du montant.
   */
  String FIELD_AMOUNT_VARIATION = "amountVariation";
  
  /**
   * Identifiant java de la représentation en chaine de caractères de la variation du montant.
   */
  String FIELD_AMOUNT_VARIATION_AS_STRING = "amountVariationAsString";
  
  /**
   * Identifiant java du montant.
   */
  String FIELD_AMOUNT = "amount";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du montant.
   */
  String FIELD_AMOUNT_AS_STRING = "amountAsString";
}
