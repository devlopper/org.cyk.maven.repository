package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamExpertiseService.SupportTeamExpertiseCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamExpertiseService.SupportTeamExpertiseUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SupportTeamExpertiseDto}.
 *
 * @author kimou
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SupportTeamExpertiseDto}.

    @author Kimou
               """)
public interface SupportTeamExpertiseRequestMapper
    extends RequestMapper<SupportTeamExpertiseDto, SupportTeamExpertiseCreateRequestDto,
     SupportTeamExpertiseUpdateRequestDto> {

}
