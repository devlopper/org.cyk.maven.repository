package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RoleDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RoleDto}.

    @author Christian
               """)
public interface RoleRequestMapper
    extends RequestMapper<RoleDto, RoleCreateRequestDto, RoleUpdateRequestDto> {

}
