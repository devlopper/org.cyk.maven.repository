package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un utilisateur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant de {@link DomainDto}.
   */
  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link DomainDto}.
   */
  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  /**
   * Identifiant de {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;

  /**
   * Passe.
   */
  @JsonbProperty(JSON_PASS)
  private String pass;

  /**
   * Compte existe.
   */
  @JsonbProperty(JSON_ACCOUNT_EXISTS)
  private Boolean accountExists;

  /**
   * Identifiant du role pour les utilisateurs non assignés à cet utilisateur.
   * Utilisé pour obtenir les utilisateurs disponibles pour attribution.
   */
  @JsonbProperty(value = JSON_UNASSIGNED_ROLE_IDENTIFIER)
  private String unassignedRoleIdentifier;

  /**
   * Identifiant du rôles pour les utilisateurs assignés à ce role.
   * Utilisé pour obtenir les utilisateurs actuels du role.
   */
  @JsonbProperty(value = JSON_ASSIGNED_ROLE_IDENTIFIER)
  private String assignedRoleIdentifier;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUtilisateur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "utilisateurChaine";

  /**
   * Identifiant champ java {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = DomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #domainAsString}.
   */
  public static final String JSON_DOMAIN_AS_STRING = DomainDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant champ java {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = IdentityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #identityAsString}.
   */
  public static final String JSON_IDENTITY_AS_STRING = IdentityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #unassignedRoleIdentifier}.
   */
  public static final String JSON_UNASSIGNED_ROLE_IDENTIFIER = "idRoleNonAssigne";

  /**
   * Identifiant json {@link #assignedRoleIdentifier}.
   */
  public static final String JSON_ASSIGNED_ROLE_IDENTIFIER = "idRoleAssigne";


  /**
   * Identifiant champ java {@link #pass}.
   */
  public static final String JSON_PASS = "passe";

  /**
   * Identifiant champ java {@link #accountExists}.
   */
  public static final String JSON_ACCOUNT_EXISTS = "compteExiste";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
