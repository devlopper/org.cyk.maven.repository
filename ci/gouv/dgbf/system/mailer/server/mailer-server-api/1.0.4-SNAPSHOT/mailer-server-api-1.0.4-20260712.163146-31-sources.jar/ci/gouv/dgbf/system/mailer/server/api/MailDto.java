package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasBodyHtmlDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyTextDto;
import ci.gouv.dgbf.extension.core.segregation.HasSubjectDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.HasReceiverAddressesAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un mail.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MailDto extends AbstractIdentifiableAuditableDto implements HasSubjectDto,
    HasBodyTextDto, HasBodyHtmlDto, HasReceiverAddressesAsStringDto, HasFilesGroupIdentifierDto {

  @JsonbProperty(value = JSON_SUBJECT)
  public String subject;

  @JsonbProperty(value = JSON_BODY_HTML)
  public String bodyHtml;

  @JsonbProperty(value = JSON_BODY_TEXT)
  public String bodyText;

  @JsonbProperty(value = JSON_RECEIVER_ADDRESSES_AS_STRING)
  private String receiverAddressesAsString;

  @JsonbProperty(value = JSON_FILES_GROUP_IDENTIFIER)
  public String filesGroupIdentifier;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mail";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "mails";
}
