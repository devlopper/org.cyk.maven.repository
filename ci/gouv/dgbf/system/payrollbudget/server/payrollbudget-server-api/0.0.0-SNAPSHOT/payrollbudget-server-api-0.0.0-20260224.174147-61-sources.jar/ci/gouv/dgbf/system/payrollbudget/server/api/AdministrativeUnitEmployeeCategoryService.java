package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de
 * {@link AdministrativeUnitEmployeeCategoryDto}.
 *
 * @author Christian
 *
 */
@Path(AdministrativeUnitEmployeeCategoryService.PATH)
@Tag(name = "Gestion des catégories d'employés d'unités administratives")
public interface AdministrativeUnitEmployeeCategoryService extends Service {

  /**
   * Chemin de base.
   */
  String PATH = "categories-employes-unites-administratives";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CATEGORIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class AdministrativeUnitEmployeeCategoryGetManyResponseDto
      extends AbstractGetByPageResponseDto<AdministrativeUnitEmployeeCategoryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<AdministrativeUnitEmployeeCategoryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CATEGORIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_CATEGORIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link AdministrativeUnitEmployeeCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = AdministrativeUnitEmployeeCategoryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);
  
  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_CATEGORIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER)
  Response getChart(GetChartRequestDto request);
}
