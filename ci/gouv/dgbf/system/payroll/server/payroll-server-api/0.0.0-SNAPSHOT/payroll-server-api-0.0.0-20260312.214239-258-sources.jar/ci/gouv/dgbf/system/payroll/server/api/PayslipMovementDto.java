package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusReasonDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementProcessResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasActualMovementAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasActualMovementIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPreviousMovementAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPreviousMovementIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un {@link MovementDto} de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipMovementDto extends AbstractMovementDto implements HasPayslipIdentifierDto,
    HasPayslipAsStringDto, HasActualMovementIdentifierDto, HasActualMovementAsStringDto,
    HasPreviousMovementIdentifierDto, HasPreviousMovementAsStringDto, HasStatusReasonDto {

  @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
  private String payslipIdentifier;

  @JsonbProperty(JSON_PAYSLIP_AS_STRING)
  private String payslipAsString;

  @JsonbProperty(JSON_ACTUAL_MOVEMENT_IDENTIFIER)
  private String actualMovementIdentifier;

  @JsonbProperty(JSON_ACTUAL_MOVEMENT_AS_STRING)
  private String actualMovementAsString;

  @JsonbProperty(JSON_PREVIOUS_MOVEMENT_IDENTIFIER)
  private String previousMovementIdentifier;

  @JsonbProperty(JSON_PREVIOUS_MOVEMENT_AS_STRING)
  private String previousMovementAsString;

  @JsonbProperty(JSON_STATUS)
  private PayslipMovementStatus status;

  @JsonbProperty(JSON_STATUS_REASON)
  private String statusReason;
  
  @JsonbProperty(JSON_ACTIVATABLE)
  private Boolean activatable;

  @JsonbProperty(JSON_DEFERRABLE_PROPOSAL)
  private Boolean deferrableProposal;

  @JsonbProperty(JSON_DEFERRABLE)
  private Boolean deferrable;

  @JsonbProperty(JSON_REJECTABLE_PROPOSAL)
  private Boolean rejectableProposal;

  @JsonbProperty(JSON_REJECTABLE)
  private Boolean rejectable;

  @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
  private String remunerableIdentifier;

  @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER)
  private String payrollElementInstanceIdentifier;

  /**
   * Cette méthode permet d'initialiser à partir d'une réponse.
   *
   * @param response résponse
   */
  public void initialize(PayslipMovementProcessResponseDto response) {
    status = response.getStatus();
    setStatusAsString(response.getStatus().getName());
    activatable = response.getActivatable();
    deferrableProposal = response.getDeferrableProposal();
    deferrable = response.getDeferrable();
    rejectableProposal = response.getRejectableProposal();
    rejectable = response.getRejectable();
  }

  /**
   * Identifiant json de identifiant de {@link PayslipMovementDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMouvementBulletinPaie";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayslipMovementDto}.
   */
  public static final String JSON_THIS_AS_STRING = "mouvementBulletinPaieChaine";

  /**
   * Identifiant json de {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /* Statuses */

  /**
   * Identifiant json {@link #activatable}.
   */
  public static final String JSON_ACTIVATABLE = "activable";

  /**
   * Identifiant json {@link #deferrableProposal}.
   */
  public static final String JSON_DEFERRABLE_PROPOSAL = "propositionDifferrable";

  /**
   * Identifiant json {@link #deferrable}.
   */
  public static final String JSON_DEFERRABLE = "diferrable";

  /**
   * Identifiant json {@link #rejectableProposal}.
   */
  public static final String JSON_REJECTABLE_PROPOSAL = "propositionRejetable";

  /**
   * Identifiant json {@link #rejectable}.
   */
  public static final String JSON_REJECTABLE = "rejetable";


  /**
   * Identifiant json {@link #payrollElementInstanceIdentifier}.
   */
  public static final String JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER = 
      "identifiantInstanceElementPaie";

  /**
   * Identifiant json {@link #remunerableIdentifier}.
   */
  public static final String JSON_REMUNERABLE_IDENTIFIER = "identifiantRemunerable";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "mouvement de bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "mouvements de bulletin paie";
}
