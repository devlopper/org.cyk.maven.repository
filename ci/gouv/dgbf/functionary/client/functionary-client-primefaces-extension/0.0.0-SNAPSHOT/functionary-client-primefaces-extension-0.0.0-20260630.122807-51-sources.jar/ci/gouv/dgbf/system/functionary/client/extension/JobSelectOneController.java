package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.JobClient;
import ci.gouv.dgbf.system.functionary.server.api.JobDto;
import ci.gouv.dgbf.system.functionary.server.api.JobService.JobGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link JobDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class JobSelectOneController extends AbstractSelectOneIdentifiableController<
    JobDto, JobGetManyResponseDto, JobClient> {

  @Getter
  @Inject
  JobClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected JobSelectOneController() {
    super(JobDto.class, SelectItemLabelStrategy.NAME);
  }
}
