package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasMovementIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link MovementDto}.
   *
   * @return identifiant de {@link MovementDto}
   */
  String getMovementIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link MovementDto}.
   *
   * @param identifier identifiant de {@link MovementDto}
   */
  void setMovementIdentifier(String identifier);

}
