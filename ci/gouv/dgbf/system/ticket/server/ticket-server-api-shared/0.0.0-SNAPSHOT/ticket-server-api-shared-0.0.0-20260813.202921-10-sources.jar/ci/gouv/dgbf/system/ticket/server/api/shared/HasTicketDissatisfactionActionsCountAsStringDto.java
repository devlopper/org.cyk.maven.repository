package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'insatisfactions
 * constatées sur des tickets (indicateur qualité) sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketDissatisfactionActionsCountAsStringDto
    extends HasTicketDissatisfactionActionsCountAsString {

  /**
   * Identifiant json du nombre cumulé d'insatisfactions constatées sur des tickets sous forme
   * de chaîne.
   */
  String JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT_AS_STRING =
      "nombreActionsInsatisfactionTicketChaine";
}
