package ci.gouv.dgbf.system.employee.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateManyExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeCreateRequestDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeGetManyResponseDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeImportAllRequestDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeImportByFunctionaryRegistrationNumberRequestDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

/**
 * Cette classe représente le client de {@link EmployeeService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class EmployeeClient extends AbstractClient<EmployeeService> implements GetByIdentifier<
    EmployeeDto>, GetMany<EmployeeGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public EmployeeClient service(EmployeeService service) {
    return (EmployeeClient) super.service(service);
  }

  /**
   * {@link EmployeeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(EmployeeCreateRequestDto request) {
    return new CreateExecutor(EmployeeService.CREATE_IDENTIFIER).execute(() -> service().create(
        request));
  }

  /**
   * {@link EmployeeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public EmployeeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<EmployeeGetManyResponseDto>(EmployeeGetManyResponseDto.class,
        EmployeeService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link EmployeeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmployeeGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link EmployeeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public EmployeeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<EmployeeDto>(EmployeeDto.class, EmployeeService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link EmployeeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmployeeDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link EmployeeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public EmployeeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<EmployeeDto>(EmployeeDto.class,
        EmployeeService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> service().getByIdentifier(
            request));
  }

  /**
   * {@link EmployeeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public EmployeeDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link EmployeeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(EmployeeUpdateRequestDto request) {
    return new IdentifiableExecutor(EmployeeService.UPDATE_IDENTIFIER).execute(() -> service()
        .update(request));
  }

  /**
   * {@link EmployeeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(EmployeeService.DELETE_IDENTIFIER).execute(() -> service()
        .delete(request));
  }

  /**
   * {@link EmployeeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link EmployeeService#importByFunctionaryRegistrationNumber}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto importByFunctionaryRegistrationNumber(
      EmployeeImportByFunctionaryRegistrationNumberRequestDto request) {
    return new CreateExecutor(EmployeeService.IMPORT_BY_FUNCTIONARY_REGISTRATION_NUMBER_PATH)
        .execute(() -> service().importByFunctionaryRegistrationNumber(request));
  }

  /**
   * {@link EmployeeService#importAll}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateManyResponseDto importAll(EmployeeImportAllRequestDto request) {
    return new CreateManyExecutor(EmployeeService.IMPORT_ALL_PATH).setExpectedResponseStatusCode(
        Response.Status.OK.getStatusCode()).execute(() -> service().importAll(request));
  }
}
