package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action Prise
 * en charge (RG_REP_PEC_01) sur une réponse de traitement (motif R44/R45).
 *
 * @author akm
 *
 */
public interface HasTakeChargeableDto {

  /**
   * Identifiant json de {@link #getTakeChargeable()}.
   */
  String JSON_TAKE_CHARGEABLE = "priseEnChargeable";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Prise en charge.
   *
   * @return indicateur de disponibilité de l'action Prise en charge
   */
  Boolean getTakeChargeable();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Prise en charge.
   *
   * @param takeChargeable indicateur de disponibilité de l'action Prise en charge
   */
  void setTakeChargeable(Boolean takeChargeable);
}
