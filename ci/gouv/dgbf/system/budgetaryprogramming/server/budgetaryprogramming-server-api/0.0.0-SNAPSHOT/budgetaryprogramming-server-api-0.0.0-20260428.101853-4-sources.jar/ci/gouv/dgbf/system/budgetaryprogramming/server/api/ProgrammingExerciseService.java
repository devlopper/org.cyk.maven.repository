package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingExerciseDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingExerciseService.PATH)
@Tag(name = "Gestion des Exercices de Programmation")
public interface ProgrammingExerciseService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "exercices-programmation";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingExerciseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'exercice budgétaire.
     *
     * @return identifiant de l'exercice budgétaire
     */
    String getExerciseIdentifier();

    /**
     * Définit l'identifiant de l'exercice budgétaire.
     *
     * @param exerciseIdentifier l'identifiant de l'exercice budgétaire
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'intervalle de la période de temps.
     *
     * @return identifiant de l'intervalle de la période de temps
     */
    String getPeriodIntervalIdentifier();

    /**
     * Définit l'identifiant de l'intervalle de la période de temps.
     *
     * @param periodIntervalIdentifier l'identifiant de l'intervalle de la période de temps
     */
    void setPeriodIntervalIdentifier(String periodIntervalIdentifier);

    /**
     * Identifiant de l'exercice budgétaire.
     */
    String JSON_EXERCISE_IDENTIFIER = ProgrammingExerciseDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * Identifiant de l'intervalle de temps.
     */
    String JSON_PERIOD_INTERVAL_IDENTIFIER = ProgrammingExerciseDto.JSON_PERIOD_INTERVAL_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingExerciseDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingExerciseDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingExerciseCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingExerciseDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingExerciseCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingExerciseSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_PERIOD_INTERVAL_IDENTIFIER)
    private String periodIntervalIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingExerciseDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingExerciseDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExerciseGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingExerciseDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingExerciseGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingExerciseDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingExerciseDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingExerciseDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingExerciseDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExerciseDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingExerciseDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingExerciseDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingExerciseDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingExerciseDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingExerciseDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingExerciseUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProgrammingExerciseDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingExerciseUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingExerciseSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_PERIOD_INTERVAL_IDENTIFIER)
    private String periodIntervalIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingExerciseDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EXERCICE_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingExerciseDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingExerciseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
