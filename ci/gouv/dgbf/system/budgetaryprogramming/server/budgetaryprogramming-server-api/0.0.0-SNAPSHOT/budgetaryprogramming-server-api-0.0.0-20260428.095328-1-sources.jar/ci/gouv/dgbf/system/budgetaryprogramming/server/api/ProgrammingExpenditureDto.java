package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasExpenditureAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasExpenditureIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépense de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingExpenditureDto extends AbstractIdentifiableAuditableDto
    implements HasProgrammingIdentifierDto, HasProgrammingAsStringDto, HasExpenditureIdentifierDto,
    HasExpenditureAsStringDto {

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  private String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  private String programmingAsString;
  
  @JsonbProperty(JSON_EXPENDITURE_IDENTIFIER)
  private String expenditureIdentifier;

  @JsonbProperty(JSON_EXPENDITURE_AS_STRING)
  private String expenditureAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDepenseProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "depenseProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dépense de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "dépenses de programmation";

}
