package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.report.server.api.ReportDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages de liste de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
public abstract class AbstractReportListPage extends AbstractPage {

  @Inject
  @Getter
  ReportController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    initializeController();
  }

  protected void initializeController() {
    controller.initialize();
  }
}

