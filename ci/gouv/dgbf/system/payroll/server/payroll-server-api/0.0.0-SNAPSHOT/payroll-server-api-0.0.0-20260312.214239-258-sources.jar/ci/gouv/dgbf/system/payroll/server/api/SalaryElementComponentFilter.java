package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SalaryElementComponentDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class SalaryElementComponentFilter extends AbstractIdentifiableFilter {
  /**
   * Identifiant de {@link SalaryElementDto}.
   */
  String salaryElementIdentifier;

  /**
   * Identifiant de {@link PayrollComponentDto}.
   */
  String payrollComponentIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SalaryElementComponentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SalaryElementComponentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    salaryElementIdentifier = getSalaryElementIdentifier(filter);
    payrollComponentIdentifier = getPayrollComponentIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setSalaryElementIdentifier(filter, salaryElementIdentifier);
    setPayrollComponentIdentifier(filter, payrollComponentIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link SalaryElementDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setSalaryElementIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_SALARY_ELEMENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link SalaryElementDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link SalaryElementDto}
   */
  public static String getSalaryElementIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SALARY_ELEMENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link PayrollDto}.
   *
   * @param filter filtre
   * @param identifier identifiant de {@link PayrollDto}
   */
  public static void setPayrollComponentIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYROLL_COMPONENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link PayrollDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link PayrollDto}
   */
  public static String getPayrollComponentIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PAYROLL_COMPONENT_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link SalaryElementComponentFilter#salaryElementIdentifier}.
   */
  public static final String JSON_SALARY_ELEMENT_IDENTIFIER = 
            SalaryElementComponentDto.JSON_SALARY_ELEMENT_IDENTIFIER;

  /**
   * Identifiant json champ {@link SalaryElementComponentFilter#payrollComponentIdentifier}.
   */
  public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
      SalaryElementComponentDto.JSON_PAYROLL_COMPONENT_IDENTIFIER;
}
