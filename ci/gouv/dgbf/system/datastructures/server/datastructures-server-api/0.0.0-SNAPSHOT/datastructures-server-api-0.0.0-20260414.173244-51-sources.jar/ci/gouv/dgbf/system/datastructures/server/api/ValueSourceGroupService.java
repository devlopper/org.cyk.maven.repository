package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDataEntityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasLongTotalDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueSourceGroupDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ValueSourceGroupService.PATH)
@Tag(name = "Gestion des groupes de sources de valeur")
public interface ValueSourceGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-sources-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueSourceGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'entité de données.
     *
     * @return l'identifiant de l'entité de données
     */
    String getDataEntityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'entité de données.
     *
     * @param dataEntityIdentifier l'identifiant de l'entité de données
     */
    void setDataEntityIdentifier(String dataEntityIdentifier);

    /**
     * {@link HasDataEntityIdentifierDto#JSON_DATA_ENTITY_IDENTIFIER}.
     */
    String JSON_DATA_ENTITY_IDENTIFIER = HasDataEntityIdentifierDto.JSON_DATA_ENTITY_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueSourceGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ValueSourceGroupSaveRequestDto {

    @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
    private String dataEntityIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSourceGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueSourceGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueSourceGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueSourceGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention des valeurs.
   */
  String GET_VALUES_IDENTIFIER = "OBTENTION_VALEURS_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention des valeurs.
   */
  String GET_VALUES_PATH = "obtention/valeurs";

  /**
   * Cette méthode permet d'obtenir les valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSourceGroupGetValuesResponseDto.class))})
  Response getValues(ValueSourceGroupGetValuesRequestDto request);

  /**
   * Cette classe représente la requête d'obtention des valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGroupGetValuesRequestDto extends ByIdentifierRequestDto {
    /**
     * Page.
     */
    @JsonbProperty(JSON_PAGE)
    PageDto page;

    /**
     * Identifiant json {@link #page}.
     */
    public static final String JSON_PAGE = "page";
  }

  /**
   * Cette classe représente la réponse d'obtention des valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGroupGetValuesResponseDto extends IdentifiableResponseDto
      implements HasLongTotalDto {

    @JsonbProperty("valeurs")
    private List<String> values;

    @JsonbProperty(JSON_TOTAL)
    private Long total;
  }

  /**
   * Identifiant du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_VALEURS_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_PATH = "obtention/nombre-valeurs";

  /**
   * Cette méthode permet d'obtenir le nombre de valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSourceGroupGetValuesCountResponseDto.class))})
  Response getValuesCount(ByIdentifierRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention du nombre de valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGroupGetValuesCountResponseDto extends IdentifiableResponseDto
      implements HasLongTotalDto {

    @JsonbProperty(JSON_TOTAL)
    private Long total;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSourceGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSourceGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueSourceGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ValueSourceGroupSaveRequestDto {

    @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
    private String dataEntityIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_SOURCE_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueSourceGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
