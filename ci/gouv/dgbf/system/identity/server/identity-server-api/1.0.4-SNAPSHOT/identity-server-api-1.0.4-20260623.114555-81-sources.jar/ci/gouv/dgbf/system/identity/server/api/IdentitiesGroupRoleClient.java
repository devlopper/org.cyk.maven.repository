package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client de {@link IdentitiesGroupRoleService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
public class IdentitiesGroupRoleClient extends AbstractClient<IdentitiesGroupRoleService>
    implements GetByIdentifier<IdentitiesGroupRoleDto>, 
    GetMany<IdentitiesGroupRoleGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public IdentitiesGroupRoleClient service(IdentitiesGroupRoleService service) {
    return (IdentitiesGroupRoleClient) super.service(service);
  }

  /**
   * {@link IdentitiesGroupRoleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(IdentitiesGroupRoleCreateRequestDto request) {
    return new CreateExecutor(IdentitiesGroupRoleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentitiesGroupRoleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupRoleGetManyResponseDto>(
    IdentitiesGroupRoleGetManyResponseDto.class,
        IdentitiesGroupRoleService.GET_MANY_IDENTIFIER).execute(() 
            -> service().getMany(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentitiesGroupRoleGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentitiesGroupRoleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentitiesGroupRoleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupRoleDto>(IdentitiesGroupRoleDto.class,
        IdentitiesGroupRoleService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentitiesGroupRoleDto getOne(ProjectionDto projection, 
      FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentitiesGroupRoleService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public IdentitiesGroupRoleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupRoleDto>(IdentitiesGroupRoleDto.class,
        IdentitiesGroupRoleService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentitiesGroupRoleDto getByIdentifier(String identifier, 
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentitiesGroupRoleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentitiesGroupRoleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(IdentitiesGroupRoleUpdateRequestDto request) {
    return new IdentifiableExecutor(IdentitiesGroupRoleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link IdentitiesGroupRoleService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    IdentitiesGroupRoleUpdateRequestDto request = new IdentitiesGroupRoleUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link IdentitiesGroupRoleService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

