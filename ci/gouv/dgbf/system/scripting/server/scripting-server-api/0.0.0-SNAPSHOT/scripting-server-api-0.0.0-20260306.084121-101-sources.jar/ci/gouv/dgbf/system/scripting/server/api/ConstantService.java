package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ConstantDto}.
 *
 * @author Christian
 *
 */
@Path(value = ConstantService.PATH)
@Tag(name = "Gestion des constantes")
public interface ConstantService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "constantes";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ConstantSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du domaine.
     *
     * @return l'identifiant du domaine
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du domaine.
     *
     * @param domainIdentifier l'identifiant du domaine
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir la valeur.
     *
     * @return la valeur
     */
    String getValue();

    /**
     * Cette méthode permet d'assigner la valeur.
     *
     * @param value la valeur
     */
    void setValue(String value);

    /**
     * Cette méthode permet d'obtenir le type de valeur.
     *
     * @return le type de valeur
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner le type de valeur.
     *
     * @param valueType le type de valeur
     */
    void setValueType(ValueType valueType);

    /**
     * {@link HasDomainIdentifierDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * {@link HasValueDto#JSON_VALUE}.
     */
    String JSON_VALUE = HasValueDto.JSON_VALUE;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CONSTANTE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ConstantCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ConstantSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONSTANTE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ConstantGetManyResponseDto extends AbstractGetByPageResponseDto<ConstantDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ConstantDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CONSTANTE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONSTANTE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CONSTANTE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ConstantUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ConstantSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONSTANTE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
