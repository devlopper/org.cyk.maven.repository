package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.FunctionTypeService.FunctionTypeCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionTypeService.FunctionTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionTypeDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionTypeDto}.

    @author stephane
               """)
public interface FunctionTypeRequestMapper
    extends RequestMapper<FunctionTypeDto, FunctionTypeCreateRequestDto, 
        FunctionTypeUpdateRequestDto> {

}
