package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingCreateByTriennialProgramByActivityRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingUpdateAmountRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingUpdateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.GetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FundingService}.
 *
 * @author Christian
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FundingClient extends AbstractClient<FundingService>
    implements GetByIdentifier<FundingDto>, GetMany<GetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FundingClient service(FundingService service) {
    return (FundingClient) super.service(service);
  }

  /**
   * {@link FundingService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FundingCreateRequestDto request) {
    return new CreateExecutor(FundingService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FundingService#createByTriennialProgramByActivity}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByTriennialProgramByActivity(
      FundingCreateByTriennialProgramByActivityRequestDto request) {
    return new CreateExecutor(FundingService.CREATE_BY_TRIENNIAL_PROGRAM_BY_ACTIVITY_IDENTIFIER)
        .execute(() -> service().createByTriennialProgramByActivity(request));
  }

  /**
   * {@link FundingService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        FundingService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FundingService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FundingService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FundingDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FundingDto>(FundingDto.class, FundingService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link FundingService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FundingDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FundingService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FundingDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FundingDto>(FundingDto.class,
        FundingService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FundingService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FundingDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FundingService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FundingUpdateRequestDto request) {
    return new IdentifiableExecutor(FundingService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FundingService#updateAmount}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateAmount(FundingUpdateAmountRequestDto request) {
    return new IdentifiableExecutor(FundingService.UPDATE_AMOUNT_IDENTIFIER)
        .execute(() -> service().updateAmount(request));
  }

  /**
   * {@link FundingService#updateComment}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateComment(
      FundingService.FundingUpdateCommentRequestDto request) {
    return new IdentifiableExecutor(FundingService.UPDATE_COMMENT_IDENTIFIER)
        .execute(() -> service().updateComment(request));
  }

  /**
   * {@link FundingService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FundingService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FundingService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
