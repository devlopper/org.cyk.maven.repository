package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets actuellement pris
 * en charge (statut PRIS_EN_CHARGE, en cours de traitement) sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasActiveClaimedTicketCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de tickets actuellement pris en charge sous forme
   * de chaîne.
   *
   * @return le nombre de tickets actuellement pris en charge sous forme de chaîne
   */
  String getActiveClaimedTicketCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre de tickets actuellement pris en charge sous forme
   * de chaîne.
   *
   * @param activeClaimedTicketCountAsString le nombre de tickets actuellement pris en charge
   *                                          sous forme de chaîne
   */
  void setActiveClaimedTicketCountAsString(String activeClaimedTicketCountAsString);

  /**
   * Identifiant java du nombre de tickets actuellement pris en charge sous forme de chaîne.
   */
  String FIELD_ACTIVE_CLAIMED_TICKET_COUNT_AS_STRING = "activeClaimedTicketCountAsString";
}
