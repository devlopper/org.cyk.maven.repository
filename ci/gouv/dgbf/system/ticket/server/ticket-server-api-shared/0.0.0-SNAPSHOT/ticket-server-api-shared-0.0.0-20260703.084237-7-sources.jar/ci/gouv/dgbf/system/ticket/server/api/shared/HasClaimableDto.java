package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion de peut être pris en charge.
 *
 * @author Christian
 */
public interface HasClaimableDto extends HasClaimable {
  
  /**
   * Identifiant json de peut être pris en charge.
   */
  String JSON_CLAIMABLE = "prenableEnCharge";
}
