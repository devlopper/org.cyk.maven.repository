package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentService.PayrollComponentCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentService.PayrollComponentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentDto}.

    @author Christian
               """)
public interface PayrollComponentRequestMapper extends RequestMapper<PayrollComponentDto,
    PayrollComponentCreateRequestDto, PayrollComponentUpdateRequestDto> {

}
