package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets traités.
 *
 * @author Christian
 */
public interface HasProcessedTicketCountDto extends HasProcessedTicketCount {

  /**
   * Identifiant json du nombre de tickets traités.
   */
  String JSON_PROCESSED_TICKET_COUNT = "nombreTicketsTraites";
}
