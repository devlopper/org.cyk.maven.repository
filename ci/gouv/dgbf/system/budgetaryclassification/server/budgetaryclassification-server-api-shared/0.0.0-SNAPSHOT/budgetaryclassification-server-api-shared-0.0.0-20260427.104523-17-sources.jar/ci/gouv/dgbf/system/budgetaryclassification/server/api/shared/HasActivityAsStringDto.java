package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de l'activité.
 *
 * @author arnaud
 */
public interface HasActivityAsStringDto
       extends HasActivityAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'activité.
   */
  String JSON_ACTIVITY_AS_STRING = "activiteChaine";
}
