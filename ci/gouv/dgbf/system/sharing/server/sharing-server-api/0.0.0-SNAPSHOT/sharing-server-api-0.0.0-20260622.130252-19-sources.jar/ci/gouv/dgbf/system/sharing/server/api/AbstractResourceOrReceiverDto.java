package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une ressource ou d'un destinataire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractResourceOrReceiverDto extends AbstractIdentifiableNamableDto {
  
  /**
   * Référence de le ressource.
   */
  @JsonbProperty(JSON_REFERENCE)
  private String reference;

  /**
   * Représentation en chaine de caractères de {@link #type}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * {@link Location} de {@link AbstractResourceOrReceiverDto}.
   */
  @JsonbProperty(JSON_LOCATION)
  private Location location;
  
  /**
   * Représentation en chaine de caractères de {@link #location}.
   */
  @JsonbProperty(JSON_LOCATION_AS_STRING)
  private String locationAsString;
  
  /**
   * Identifiant champ json {@link #reference}.
   */
  public static final String JSON_REFERENCE = "reference";
  /**
   * Identifiant champ json du type.
   */
  public static final String JSON_TYPE = "type";
  /**
   * Identifiant champ json {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = "typeChaine";
  /**
   * Identifiant champ json {@link #location}.
   */
  public static final String JSON_LOCATION = "localisation";
  /**
   * Identifiant champ json {@link #locationAsString}.
   */
  public static final String JSON_LOCATION_AS_STRING = "localisationChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ressource";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
