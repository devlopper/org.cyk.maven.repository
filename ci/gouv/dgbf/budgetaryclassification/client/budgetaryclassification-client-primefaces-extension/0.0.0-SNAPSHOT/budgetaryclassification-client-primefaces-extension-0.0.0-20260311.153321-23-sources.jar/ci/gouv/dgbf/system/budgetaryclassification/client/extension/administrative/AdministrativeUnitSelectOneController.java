package ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AdministrativeUnitClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AdministrativeUnitDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AdministrativeUnitService.AdministrativeUnitGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link AdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class AdministrativeUnitSelectOneController extends AbstractSelectOneIdentifiableController<
    AdministrativeUnitDto, AdministrativeUnitGetManyResponseDto, AdministrativeUnitClient> {

  @Inject
  @Getter
  AdministrativeUnitClient client;

  public AdministrativeUnitSelectOneController() {
    super(AdministrativeUnitDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
