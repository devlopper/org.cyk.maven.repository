package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN2AsString {

  /**
   * Obtient le montant total à valider pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant total à valider pour l'année N+2 sous forme de chaîne de caractères
   */
  String getTotalAmountToValidateN2AsString();

  /**
   * Définit le montant total à valider pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param totalAmountToValidateN2AsString le montant total à valider pour l'année N+2 sous forme
   *        de chaîne de caractères
   */
  void setTotalAmountToValidateN2AsString(String totalAmountToValidateN2AsString);

  /**
   * Identifiant java du montant total à valider pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N2_AS_STRING =
      "totalAmountToValidateN2AsString";
}
