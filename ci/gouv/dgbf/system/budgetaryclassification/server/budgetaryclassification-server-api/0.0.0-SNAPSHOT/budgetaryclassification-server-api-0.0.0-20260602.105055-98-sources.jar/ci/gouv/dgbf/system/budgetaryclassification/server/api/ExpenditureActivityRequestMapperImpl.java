package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ExpenditureActivityDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T10:51:22+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ExpenditureActivityRequestMapperImpl implements ExpenditureActivityRequestMapper {

    @Override
    public ExpenditureActivityService.ExpenditureActivityCreateRequestDto mapCreate(ExpenditureActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureActivityService.ExpenditureActivityCreateRequestDto expenditureActivityCreateRequestDto = new ExpenditureActivityService.ExpenditureActivityCreateRequestDto();

        expenditureActivityCreateRequestDto.setName( arg0.getName() );
        expenditureActivityCreateRequestDto.setShortName( arg0.getShortName() );
        expenditureActivityCreateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        expenditureActivityCreateRequestDto.setBeneficiaryAdministrativeUnitIdentifier( arg0.getBeneficiaryAdministrativeUnitIdentifier() );
        expenditureActivityCreateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );
        expenditureActivityCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        expenditureActivityCreateRequestDto.setStatus( arg0.getStatus() );
        expenditureActivityCreateRequestDto.setIsProject( arg0.getIsProject() );
        expenditureActivityCreateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        expenditureActivityCreateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );

        return expenditureActivityCreateRequestDto;
    }

    @Override
    public ExpenditureActivityService.ExpenditureActivityUpdateRequestDto mapUpdate(ExpenditureActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureActivityService.ExpenditureActivityUpdateRequestDto expenditureActivityUpdateRequestDto = new ExpenditureActivityService.ExpenditureActivityUpdateRequestDto();

        expenditureActivityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        expenditureActivityUpdateRequestDto.setName( arg0.getName() );
        expenditureActivityUpdateRequestDto.setShortName( arg0.getShortName() );
        expenditureActivityUpdateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );
        expenditureActivityUpdateRequestDto.setBeneficiaryAdministrativeUnitIdentifier( arg0.getBeneficiaryAdministrativeUnitIdentifier() );
        expenditureActivityUpdateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );
        expenditureActivityUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );
        expenditureActivityUpdateRequestDto.setStatus( arg0.getStatus() );
        expenditureActivityUpdateRequestDto.setIsProject( arg0.getIsProject() );
        expenditureActivityUpdateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        expenditureActivityUpdateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );

        return expenditureActivityUpdateRequestDto;
    }
}
