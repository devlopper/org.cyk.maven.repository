package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileJournalEntryService.FileJournalEntryGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client du service {@link FileJournalEntryService}.
 *
 * @author Christian
 */
@ApplicationScoped
public class FileJournalEntryClient extends AbstractClient<FileJournalEntryService>
    implements GetMany<FileJournalEntryGetManyResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link FileJournalEntryService}
   * @return client {@link FileJournalEntryClient}
   */
  @Override
  public FileJournalEntryClient service(FileJournalEntryService service) {
    return (FileJournalEntryClient) super.service(service);
  }

  /**
   * {@link FileJournalEntryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FileJournalEntryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FileJournalEntryGetManyResponseDto>(
        FileJournalEntryGetManyResponseDto.class, FileJournalEntryService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link FileJournalEntryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileJournalEntryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Cette méthode permet d'obtenir les entrées du journal d'un Fichier.
   *
   * @param fileIdentifier identifiant du Fichier
   * @param projection projection
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileJournalEntryGetManyResponseDto getManyByFileIdentifier(String fileIdentifier,
      ProjectionDto projection, PageDto page, String auditWho, String auditSession) {
    FilterDto filter = new FilterDto();
    FileJournalEntryFilter.setFileIdentifier(filter, fileIdentifier);
    return getMany(projection, filter, page, auditWho, auditSession);
  }

  /**
   * {@link FileJournalEntryService#getCount}.
   *
   * @param request requête
   * @return nombre d'entrées
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(FileJournalEntryService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }
}
