package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateNAsString {

  /**
   * Obtient le montant restant à intégrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant restant à intégrer pour l'année N sous forme de chaîne de caractères
   */
  String getRemainingAmountToIntegrateNAsString();

  /**
   * Définit le montant restant à intégrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToIntegrateNAsString le montant restant à intégrer pour l'année N sous
   *        forme de chaîne de caractères
   */
  void setRemainingAmountToIntegrateNAsString(String remainingAmountToIntegrateNAsString);

  /**
   * Identifiant java du montant restant à intégrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INTEGRATE_N_AS_STRING =
      "remainingAmountToIntegrateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName