package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SsoApplicationDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class SsoApplicationFilter extends AbstractIdentifiableFilter {

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SsoApplicationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SsoApplicationFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
  }
}
