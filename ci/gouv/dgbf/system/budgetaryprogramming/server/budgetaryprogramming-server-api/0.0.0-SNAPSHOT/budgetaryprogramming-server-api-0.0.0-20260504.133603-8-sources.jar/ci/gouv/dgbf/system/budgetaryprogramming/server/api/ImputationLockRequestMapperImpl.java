package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ImputationLockDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-04T13:36:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ImputationLockRequestMapperImpl implements ImputationLockRequestMapper {

    @Override
    public ImputationLockService.ImputationLockCreateRequestDto mapCreate(ImputationLockDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ImputationLockService.ImputationLockCreateRequestDto imputationLockCreateRequestDto = new ImputationLockService.ImputationLockCreateRequestDto();

        imputationLockCreateRequestDto.setCode( arg0.getCode() );
        imputationLockCreateRequestDto.setName( arg0.getName() );
        imputationLockCreateRequestDto.setInputableN( arg0.getInputableN() );
        imputationLockCreateRequestDto.setInputableN1( arg0.getInputableN1() );
        imputationLockCreateRequestDto.setInputableN2( arg0.getInputableN2() );
        imputationLockCreateRequestDto.setArbitrableN( arg0.getArbitrableN() );
        imputationLockCreateRequestDto.setArbitrableN1( arg0.getArbitrableN1() );
        imputationLockCreateRequestDto.setArbitrableN2( arg0.getArbitrableN2() );
        imputationLockCreateRequestDto.setValidatable( arg0.getValidatable() );
        imputationLockCreateRequestDto.setIntegratable( arg0.getIntegratable() );

        return imputationLockCreateRequestDto;
    }

    @Override
    public ImputationLockService.ImputationLockUpdateRequestDto mapUpdate(ImputationLockDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ImputationLockService.ImputationLockUpdateRequestDto imputationLockUpdateRequestDto = new ImputationLockService.ImputationLockUpdateRequestDto();

        imputationLockUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        imputationLockUpdateRequestDto.setCode( arg0.getCode() );
        imputationLockUpdateRequestDto.setName( arg0.getName() );
        imputationLockUpdateRequestDto.setInputableN( arg0.getInputableN() );
        imputationLockUpdateRequestDto.setInputableN1( arg0.getInputableN1() );
        imputationLockUpdateRequestDto.setInputableN2( arg0.getInputableN2() );
        imputationLockUpdateRequestDto.setArbitrableN( arg0.getArbitrableN() );
        imputationLockUpdateRequestDto.setArbitrableN1( arg0.getArbitrableN1() );
        imputationLockUpdateRequestDto.setArbitrableN2( arg0.getArbitrableN2() );
        imputationLockUpdateRequestDto.setValidatable( arg0.getValidatable() );
        imputationLockUpdateRequestDto.setIntegratable( arg0.getIntegratable() );

        return imputationLockUpdateRequestDto;
    }
}
