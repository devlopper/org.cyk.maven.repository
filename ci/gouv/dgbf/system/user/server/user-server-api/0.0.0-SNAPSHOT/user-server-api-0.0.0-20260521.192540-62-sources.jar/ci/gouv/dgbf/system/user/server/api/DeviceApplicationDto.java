package ci.gouv.dgbf.system.user.server.api;


import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un equipement d'application.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DeviceApplicationDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant {@link ApplicationDto}.
   */
  @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
  private String applicationIdentifier;


  /**
   * Identifiant json champ {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = "applicationIdentifier";

  /**
   * Représentation en chaine de caractères {@link ApplicationDto}.
   */
  @JsonbProperty(JSON_APPLICATION_AS_STRING)
  private String applicationAsString;


  /**
   * Identifiant json champ {@link #applicationAsString}.
   */
  public static final String JSON_APPLICATION_AS_STRING = "applicationAsString";


  /**
   * Identifiant {@link DeviceDto}.
   */
  @JsonbProperty(JSON_DEVICE_IDENTIFIER)
  private String deviceIdentifier;


  /**
   * Identifiant json champ {@link #deviceIdentifier}.
   */
  public static final String JSON_DEVICE_IDENTIFIER = "deviceIdentifier";

  /**
   * Représentation en chaine de caractères {@link DeviceDto}.
   */
  @JsonbProperty(JSON_DEVICE_AS_STRING)
  private String deviceAsString;


  /**
   * Identifiant json champ {@link #deviceAsString}.
   */
  public static final String JSON_DEVICE_AS_STRING = "deviceAsString";

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Identifiant json champ {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "registrationNumber";

  /**
   * Email.
   */
  @JsonbProperty(value = JSON_EMAIL)
  private String email;

  /**
   * Identifiant json champ {@link #email}.
   */
  public static final String JSON_EMAIL = "email";

  /**
   * Numéro de téléphone.
   */
  @JsonbProperty(value = JSON_PHONE_NUMBER)
  private String phoneNumber;

  /**
   * Identifiant json champ {@link #phoneNumber}.
   */
  public static final String JSON_PHONE_NUMBER = "phoneNumber";

  /**
   * Date de début.
   */
  @JsonbProperty(value = JSON_START_DATE)
  private LocalDate startDate;

  /**
   * Identifiant json champ {@link #startDate}.
   */
  public static final String JSON_START_DATE = "startDate";

  /**
   * Date de fin.
   */
  @JsonbProperty(value = JSON_END_DATE)
  private LocalDate endDate;

  /**
   * Identifiant json champ {@link #endDate}.
   */
  public static final String JSON_END_DATE = "endDate";


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEquipementApplication";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "equipementApplicationChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "equipement application";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "equipements applications";
}
