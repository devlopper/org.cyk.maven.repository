package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.UriQueryBuilder;
import jakarta.faces.application.ConfigurableNavigationHandler;
import jakarta.faces.application.NavigationCase;
import jakarta.faces.application.NavigationHandler;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un navigateur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class Navigator {

  public static final Logger LOGGER = Logger.getLogger(Navigator.class.getName());

  String url;

  String outcome;
  UriQueryBuilder uriQueryBuilder;

  boolean dispatch;

  /**
   * Cette méthode permet de naviguer.
   */
  public void navigate() {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    ConfigurableNavigationHandler navigationHandler =
        (ConfigurableNavigationHandler) facesContext.getApplication().getNavigationHandler();
    NavigationCase navigationCase =
        navigationHandler.getNavigationCase(facesContext, null, outcome);

    HttpServletRequest request =
        (HttpServletRequest) facesContext.getExternalContext().getRequest();
    String path = navigationCase.getToViewId(facesContext);
    String query = buildQuery();

    if (dispatch) {
      dispatch(path + query, facesContext, navigationHandler);
    } else {
      redirect(request.getContextPath() + path + query, facesContext);
    }
  }

  void redirect(String url, FacesContext facesContext) {
    try {
      facesContext.getExternalContext().redirect(url);
    } catch (IOException exception) {
      throw new Exception(exception);
    }
  }

  void dispatch(String url, FacesContext facesContext, NavigationHandler navigationHandler) {
    navigationHandler.handleNavigation(facesContext, null, url);
  }

  String buildQuery() {
    if (uriQueryBuilder == null) {
      return Constant.EMPTY_STRING;
    }
    return uriQueryBuilder.build();
  }

  /**
   * Cette méthode permet d'obtenir {@link UriQueryBuilder} non nul.
   *
   * @return {@link UriQueryBuilder} non nul
   */
  public UriQueryBuilder uriQueryBuilder() {
    if (uriQueryBuilder == null) {
      uriQueryBuilder = new UriQueryBuilder();
      uriQueryBuilder.setAppendQuestionMarkIfNotBlank(true);
    }
    return uriQueryBuilder;
  }

  /**
   * Cette classe représente une exception de navigation.
   *
   * @author Christian
   *
   */
  public static class Exception extends RuntimeException {

    public Exception(Throwable cause) {
      super(cause);
    }

  }
}
