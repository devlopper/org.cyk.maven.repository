package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PolicyVersionDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class PolicyVersionFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de la politique.
   */
  String policyIdentifier;

  /**
   * Est active.
   */
  Boolean isActive;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    policyIdentifier = getPolicyIdentifier(filter);
    isActive = getIsActive(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setPolicyIdentifier(filter, policyIdentifier);
    setIsActive(filter, isActive);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la politique.
   *
   * @param filter filtre
   * @param policyIdentifier identifiant de la politique
   */
  public static void setPolicyIdentifier(FilterDto filter, String policyIdentifier) {
    set(filter, JSON_POLICY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(policyIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la politique.
   *
   * @param filter filtre
   * @return identifiant de la politique
   */
  public static String getPolicyIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_POLICY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner si la version est active.
   *
   * @param filter filtre
   * @param isActive si la version est active
   */
  public static void setIsActive(FilterDto filter, Boolean isActive) {
    set(filter, JSON_IS_ACTIVE, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(isActive));
  }

  /**
   * Cette méthode permet d'obtenir si la version est active.
   *
   * @param filter filtre
   * @return si la version est active
   */
  public static Boolean getIsActive(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_ACTIVE));
  }

  /**
   * Identifiant json champ {@link #policyIdentifier}.
   */
  public static final String JSON_POLICY_IDENTIFIER = PolicyVersionDto.JSON_POLICY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #isActive}.
   */
  public static final String JSON_IS_ACTIVE = PolicyVersionDto.JSON_IS_ACTIVE;
}
