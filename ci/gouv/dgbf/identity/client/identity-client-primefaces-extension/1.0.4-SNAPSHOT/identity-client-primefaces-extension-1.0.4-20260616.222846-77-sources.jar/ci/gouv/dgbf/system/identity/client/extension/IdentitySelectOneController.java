package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentitySelectOneController
    extends AbstractSelectOneIdentifiableController<IdentityDto,
        IdentityGetManyResponseDto, IdentityClient> {

  @Inject
  @Getter
  IdentityClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected IdentitySelectOneController() {
    super(IdentityDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
