package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette classe représente les codes de {@link AdministrativeUnitEmployeeCategoryChart}.
 *
 * @author Christian
 *
 */
public class AdministrativeUnitEmployeeCategoryChartCode {

  private AdministrativeUnitEmployeeCategoryChartCode() {

  }

  /**
   * Éffectif.
   */
  public static final String EMPLOYEE_COUNT = "COMPTE_EMPLOYE";
  
  /**
   * Montant.
   */
  public static final String EMPLOYEE_AMOUNT = "MONTANT_EMPLOYE";
  
  /**
   * Situation du personnel.
   */
  public static final String EMPLOYEE_SITUATION = "SITUATION_EMPLOYE";
}
