package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets actuellement pris
 * en charge (statut PRIS_EN_CHARGE, en cours de traitement).
 *
 * @author Christian
 */
public interface HasActiveClaimedTicketCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de tickets actuellement pris en charge.
   *
   * @return le nombre de tickets actuellement pris en charge
   */
  Integer getActiveClaimedTicketCount();

  /**
   * Cette méthode permet d'assigner le nombre de tickets actuellement pris en charge.
   *
   * @param activeClaimedTicketCount le nombre de tickets actuellement pris en charge
   */
  void setActiveClaimedTicketCount(Integer activeClaimedTicketCount);

  /**
   * Identifiant java du nombre de tickets actuellement pris en charge.
   */
  String FIELD_ACTIVE_CLAIMED_TICKET_COUNT = "activeClaimedTicketCount";
}
