package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une saisie de texte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInputText extends AbstractInput<String> {

  protected String placeholder;

  public AbstractInputText computePlaceholderFromOutputLabelValue() {
    placeholder = "Saisir " + outputLabel().getValue();
    return this;
  }
}
