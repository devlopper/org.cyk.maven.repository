package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.PunctualMeasureService.PunctualMeasureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PunctualMeasureService.PunctualMeasureGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.PunctualMeasureService.PunctualMeasureUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PunctualMeasureService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PunctualMeasureClient extends AbstractClient<PunctualMeasureService>
    implements GetByIdentifier<PunctualMeasureDto>, GetMany<PunctualMeasureGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PunctualMeasureClient service(PunctualMeasureService service) {
    return (PunctualMeasureClient) super.service(service);
  }

  /**
   * {@link PunctualMeasureService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PunctualMeasureCreateRequestDto request) {
    return new CreateExecutor(PunctualMeasureService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PunctualMeasureService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PunctualMeasureGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PunctualMeasureGetManyResponseDto>(
        PunctualMeasureGetManyResponseDto.class, PunctualMeasureService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public PunctualMeasureGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PunctualMeasureService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PunctualMeasureDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PunctualMeasureDto>(PunctualMeasureDto.class,
        PunctualMeasureService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PunctualMeasureService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PunctualMeasureDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PunctualMeasureDto>(PunctualMeasureDto.class,
        PunctualMeasureService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public PunctualMeasureDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PunctualMeasureService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PunctualMeasureUpdateRequestDto request) {
    return new IdentifiableExecutor(PunctualMeasureService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PunctualMeasureService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PunctualMeasureService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
