package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de prise en
 * charge de ticket sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketClaimActionsCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'actions de prise en charge de ticket sous
   * forme de chaîne.
   *
   * @return le nombre cumulé d'actions de prise en charge de ticket sous forme de chaîne
   */
  String getTicketClaimActionsCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'actions de prise en charge de ticket sous
   * forme de chaîne.
   *
   * @param ticketClaimActionsCountAsString le nombre cumulé d'actions de prise en charge de
   *                                        ticket sous forme de chaîne
   */
  void setTicketClaimActionsCountAsString(String ticketClaimActionsCountAsString);

  /**
   * Identifiant java du nombre cumulé d'actions de prise en charge de ticket sous forme de
   * chaîne.
   */
  String FIELD_TICKET_CLAIM_ACTIONS_COUNT_AS_STRING = "ticketClaimActionsCountAsString";
}
