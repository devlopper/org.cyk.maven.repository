package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les étapes du circuit de validation d'une {@code ClaimedValueReview}
 * (RG_REP_RVR_01) -- {@link #VALIDATED} et {@link #REJECTED} sont les deux seules issues
 * terminales, {@link #REJECTED} étant unique quel que soit le palier (Visa, Contrôle, Validation
 * ou Validation Déléguée) où la décision négative survient (RG_REP_RVR_01, dernier paragraphe).
 *
 * @author akm
 *
 */
@Getter
public enum ClaimedValueReviewStatus {

  /**
   * Générée -- à l'Acceptation de la réclamation (RG_REP_PEC_08).
   */
  GENERATED(ClaimedValueReviewStatusCode.GENERATED, "Générée"),

  /**
   * Transmise pour Visa -- transmission manuelle et groupée par l'Agent de Traitement
   * (RG_REP_RVR_01 étape 2, RG_REP_PEC_02).
   */
  TRANSMITTED_TO_VISA(ClaimedValueReviewStatusCode.TRANSMITTED_TO_VISA, "Transmise pour Visa"),

  /**
   * Visée -- décision positive du Responsable au palier Visa (RG_REP_RVR_01 étape 2).
   */
  VISA_GRANTED(ClaimedValueReviewStatusCode.VISA_GRANTED, "Visée"),

  /**
   * Transmise pour Contrôle, depuis {@link #VISA_GRANTED} (RG_REP_RVR_01 étape 3).
   */
  TRANSMITTED_TO_CONTROL(ClaimedValueReviewStatusCode.TRANSMITTED_TO_CONTROL,
      "Transmise pour Contrôle"),

  /**
   * Contrôlée -- décision positive du Contrôleur au palier Contrôle (RG_REP_RVR_01 étape 3).
   */
  CONTROLLED(ClaimedValueReviewStatusCode.CONTROLLED, "Contrôlée"),

  /**
   * Transmise pour Validation, depuis {@link #CONTROLLED} (RG_REP_RVR_01 étape 4).
   */
  TRANSMITTED_TO_VALIDATION(ClaimedValueReviewStatusCode.TRANSMITTED_TO_VALIDATION,
      "Transmise pour Validation"),

  /**
   * Validation Déléguée -- le Responsable de Structure délègue sa décision à l'Agent Trésor
   * plutôt que de valider directement (RG_REP_RVR_01 étape 4, RG_REP_SOU_08) -- seulement
   * possible si le Type de Réclamation est Transmissible au Trésor ; jamais automatique.
   */
  VALIDATION_DELEGATED(ClaimedValueReviewStatusCode.VALIDATION_DELEGATED,
      "Validation Déléguée"),

  /**
   * Validée -- issue terminale positive (RG_REP_RVR_01 étapes 4/5), atteinte par le Responsable
   * de Structure directement ou par l'Agent Trésor après délégation -- dans les deux cas
   * seulement si l'Impact synchrone associé réussit effectivement (RG_REP_RVR_04) ; sinon la
   * Revue reste à son étape courante, sans aucun changement.
   */
  VALIDATED(ClaimedValueReviewStatusCode.VALIDATED, "Validée"),

  /**
   * Rejetée -- issue terminale négative, unique quel que soit le palier où la décision négative
   * survient ; n'invalide ni la réclamation ni la Valeur Réclamée (RG_REP_RVR_07).
   */
  REJECTED(ClaimedValueReviewStatusCode.REJECTED, "Rejetée");

  private ClaimedValueReviewStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;
  private Set<ClaimedValueReviewStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link ClaimedValueReviewStatus} par code.
   *
   * @param code code
   * @return {@link ClaimedValueReviewStatus}
   */
  public static ClaimedValueReviewStatus getByCode(String code) {
    return Stream.of(ClaimedValueReviewStatus.values())
        .filter(step -> step.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    GENERATED.previous = Collections.emptySet();
    TRANSMITTED_TO_VISA.previous = Core.getSet(List.of(GENERATED));
    VISA_GRANTED.previous = Core.getSet(List.of(TRANSMITTED_TO_VISA));
    TRANSMITTED_TO_CONTROL.previous = Core.getSet(List.of(VISA_GRANTED));
    CONTROLLED.previous = Core.getSet(List.of(TRANSMITTED_TO_CONTROL));
    TRANSMITTED_TO_VALIDATION.previous = Core.getSet(List.of(CONTROLLED));
    VALIDATION_DELEGATED.previous = Core.getSet(List.of(TRANSMITTED_TO_VALIDATION));
    VALIDATED.previous = Core.getSet(List.of(TRANSMITTED_TO_VALIDATION, VALIDATION_DELEGATED));
    REJECTED.previous = Core.getSet(List.of(TRANSMITTED_TO_VISA, TRANSMITTED_TO_CONTROL,
        TRANSMITTED_TO_VALIDATION, VALIDATION_DELEGATED));
  }
}
