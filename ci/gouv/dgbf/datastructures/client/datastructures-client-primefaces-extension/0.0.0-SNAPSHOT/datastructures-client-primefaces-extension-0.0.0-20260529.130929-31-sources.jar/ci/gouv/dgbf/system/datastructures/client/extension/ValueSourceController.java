package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.EnumerationCore;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRequestAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSelectorsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.ValueTypeSelectOneController;
import ci.gouv.dgbf.extension.primefaces.crud.HasListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ValueSourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSourceController extends AbstractController implements HasListController {

  @Inject
  ValueSourceClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  ValueSourceRequestMapper requestMapper;

  @Inject
  @Getter
  ValueSourceGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController attributeNameInputTextController;

  @Inject
  @Getter
  ValueTypeSelectOneController valueTypeSelectOneController;

  @Inject
  @Getter
  ValueSourceFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ValueSourceDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ValueSourceDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ValueSourceService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getGroupIdentifier(),
        HasGroupAsStringDto.JSON_GROUP_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        HasAttributeNameDto.JSON_ATTRIBUTE_NAME, HasValueTypeAsStringDto.JSON_VALUE_TYPE_AS_STRING,
        HasRequestAsStringDto.JSON_REQUEST_AS_STRING,
        HasValuesCountAsStringDto.JSON_VALUES_COUNT_AS_STRING,
        HasSelectorsCountAsStringDto.JSON_SELECTORS_COUNT_AS_STRING);

    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());
    listController.getCreateController().setFunction(entity -> {
      ValueSourceCreateRequestDto request = requestMapper.mapCreate((ValueSourceDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER, HasAttributeNameDto.JSON_ATTRIBUTE_NAME,
            ValueSourceDto.JSON_VALUE_TYPE));
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    groupSelectOneController
        .setRenderable(StringCore.isBlank(filterController.getFilter().getGroupIdentifier()));
    groupSelectOneController.getSelectOneMenu().addValueConsumer(groupIdentifierConsumer());

    attributeNameInputTextController.setOutputLableValue("Nom de l'attribut");
    attributeNameInputTextController.getInputText().addValueConsumer(attributeNameConsumer());

    valueTypeSelectOneController.getSelectOneMenu()
        .addValueConsumer(name -> listController
            .getCreateControllerOrUpdateControllerEntityAs(ValueSourceDto.class)
            .setValueType(EnumerationCore.getByName(ValueType.class, name)));
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
      ((ValueSourceDto) entity)
          .setGroupIdentifier(filterController.getFilter().getGroupIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((ValueSourceDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((ValueSourceDto) entity).getName());
      groupSelectOneController.getSelectOneMenu()
          .writeValue(((ValueSourceDto) entity).getGroupIdentifier());
      attributeNameInputTextController.getInputText()
          .writeValue(((ValueSourceDto) entity).getAttributeName());
      valueTypeSelectOneController.getSelectOneMenu()
          .writeValue(((ValueSourceDto) entity).getValueType().name());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceDto.class).setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceDto.class).setName(name);
  }

  Consumer<String> groupIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceDto.class)
        .setGroupIdentifier(identifier);
  }

  Consumer<String> attributeNameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSourceDto.class).setAttributeName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ValueSourceUpdateRequestDto request = requestMapper.mapUpdate((ValueSourceDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            groupSelectOneController.getSelectOneMenu(),
            attributeNameInputTextController.getInputText(),
            valueTypeSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
