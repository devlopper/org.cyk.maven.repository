package ci.gouv.dgbf.system.payrollelementrequest.server.api;

/**
 * Cette classe représente les codes de {@link ClaimedValueReviewStatus}.
 *
 * @author akm
 *
 */
public class ClaimedValueReviewStatusCode {

  private ClaimedValueReviewStatusCode() {

  }

  /**
   * Générée.
   */
  public static final String GENERATED = "GENEREE";

  /**
   * Transmise pour Visa.
   */
  public static final String TRANSMITTED_TO_VISA = "TRANSMISE_VISA";

  /**
   * Visée.
   */
  public static final String VISA_GRANTED = "VISEE";

  /**
   * Transmise pour Contrôle.
   */
  public static final String TRANSMITTED_TO_CONTROL = "TRANSMISE_CONTROLE";

  /**
   * Contrôlée.
   */
  public static final String CONTROLLED = "CONTROLEE";

  /**
   * Transmise pour Validation.
   */
  public static final String TRANSMITTED_TO_VALIDATION = "TRANSMISE_VALIDATION";

  /**
   * Validation Déléguée.
   */
  public static final String VALIDATION_DELEGATED = "VALIDATION_DELEGUEE";

  /**
   * Validée.
   */
  public static final String VALIDATED = "VALIDEE";

  /**
   * Rejetée.
   */
  public static final String REJECTED = "REJETEE";
}
