package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.input.InputDateController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputLocalDate;
import ci.gouv.dgbf.extension.primefaces.component.input.InputLocalDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link InputDateController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class InputDateControllerMocker {

  InputLocalDate inputLocalDate;

  InputLocalDateTime inputLocalDateTime;
  
  /**
   * Cette méthode permet d'instancier.
   *
   */
  public InputDateControllerMocker() {
    inputLocalDate = new InputLocalDate();
    inputLocalDateTime = new InputLocalDateTime();
  }

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link InputDateController}
   */
  public InputDateController mock() {
    InputDateController controller = Mockito.mock(InputDateController.class);
    Mockito.when(controller.getInputLocalDate()).thenReturn(inputLocalDate);
    Mockito.when(controller.getInputLocalDateTime()).thenReturn(inputLocalDateTime);
    return controller;
  }

}
