package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * programmation.
 *
 * @author Christian
 */
public interface HasProgrammingAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la programmation.
   *
   * @return représentation en chaine de caractères de la programmation
   */
  String getProgrammingAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de la programmation.
   *
   * @param asString représentation en chaine de caractères de la programmation
   */
  void setProgrammingAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de la programmation.
   */
  String FIELD_PROGRAMMING_AS_STRING = "programmingAsString";
}
