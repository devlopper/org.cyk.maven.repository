package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un emploi.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class JobDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasGroupIdentifierDto, HasGroupAsStringDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;
  
  @JsonbProperty(JSON_GRADE_IDENTIFIER)
  private String gradeIdentifier;

  @JsonbProperty(JSON_GRADE_AS_STRING)
  private String gradeAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEmploi";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "emploiChaine";

  /**
   * Identifiant json de {@link #gradeIdentifier}.
   */
  public static final String JSON_GRADE_IDENTIFIER = GradeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #gradeAsString}.
   */
  public static final String JSON_GRADE_AS_STRING = GradeDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "emploi";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
