package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et
 * {@link TriennialProgramActivityFundingTypeDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête
      et {@link TriennialProgramActivityFundingTypeDto}.
    
    @author Desysoft
    """)
public interface TriennialProgramActivityFundingTypeRequestMapper
    extends
    RequestMapper<TriennialProgramActivityFundingTypeDto,
        TriennialProgramActivityFundingTypeCreateRequestDto,
        TriennialProgramActivityFundingTypeUpdateRequestDto> {
}

