package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de recette.
 *
 * @author Christian
 */
public interface FilterHasRevenueIdentifier extends HasRevenueIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la recette.
   *
   * @param filter {@link FilterDto}
   */
  default void updateRevenueIdentifier(FilterDto filter) {
    setRevenueIdentifier(RevenueIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la recette de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterRevenueIdentifier(FilterDto filter) {
    RevenueIdentifierFilter.set(filter, getRevenueIdentifier());
  }

}
