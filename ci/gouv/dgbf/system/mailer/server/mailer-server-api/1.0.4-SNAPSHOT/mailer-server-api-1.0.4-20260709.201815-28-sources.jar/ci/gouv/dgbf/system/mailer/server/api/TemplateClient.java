package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.mailer.server.api.TemplateService.TemplateCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.TemplateService.TemplateGetManyResponseDto;
import ci.gouv.dgbf.system.mailer.server.api.TemplateService.TemplateUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link TemplateDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class TemplateClient extends AbstractClient<TemplateService>
    implements GetByIdentifier<TemplateDto>, GetMany<TemplateGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link TemplateService}
   * @return client {@link TemplateClient}
   */
  @Override
  public TemplateClient service(TemplateService service) {
    return (TemplateClient) super.service(service);
  }

  /**
   * {@link TemplateService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(TemplateCreateRequestDto request) {
    return new CreateExecutor(TemplateService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TemplateService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TemplateGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TemplateGetManyResponseDto>(
        TemplateGetManyResponseDto.class,
        TemplateService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link TemplateService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TemplateGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TemplateService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TemplateDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<TemplateDto>(TemplateDto.class,
        TemplateService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link TemplateService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TemplateDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<TemplateDto>(TemplateDto.class,
        TemplateService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TemplateService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(TemplateUpdateRequestDto request) {
    return new IdentifiableExecutor(TemplateService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TemplateService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TemplateService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
