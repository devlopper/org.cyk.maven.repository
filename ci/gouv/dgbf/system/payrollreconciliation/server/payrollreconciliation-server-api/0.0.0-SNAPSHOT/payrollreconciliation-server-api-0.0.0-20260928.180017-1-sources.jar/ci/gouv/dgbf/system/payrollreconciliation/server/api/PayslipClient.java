package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayslipService.PayslipGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayslipService}.
 *
 * @author desysoft
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayslipClient extends AbstractClient<PayslipService>
    implements GetByIdentifier<PayslipDto>, GetMany<PayslipGetManyResponseDto> {

  @Override
  public PayslipClient service(PayslipService service) {
    return (PayslipClient) super.service(service);
  }

  /**
   * {@link PayslipService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayslipGetManyResponseDto>(PayslipGetManyResponseDto.class,
        PayslipService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayslipService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayslipService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayslipDto>(PayslipDto.class,
        PayslipService.GET_ONE_IDENTIFIER)
          .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayslipService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayslipService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayslipDto>(PayslipDto.class,
        PayslipService.GET_BY_IDENTIFIER_IDENTIFIER)
          .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayslipService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayslipService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetOneExecutor<Long>(Long.class, PayslipService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayslipService#getCount}.
   *
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public Long getCount(FilterDto filter, String auditWho, String auditSession) {
    GetCountRequestDto request = new GetCountRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getCount(request);
  }

  /**
   * {@link PayslipService#getSummary}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipSummaryDto getSummary(GetCountRequestDto request) {
    return new GetOneExecutor<PayslipSummaryDto>(PayslipSummaryDto.class,
        PayslipService.GET_SUMMARY_IDENTIFIER)
          .execute(() -> service().getSummary(request));
  }

  /**
   * {@link PayslipService#getSummary}.
   *
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipSummaryDto getSummary(FilterDto filter, String auditWho,
      String auditSession) {
    GetCountRequestDto request = new GetCountRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getSummary(request);
  }

  /**
   * {@link PayslipService#refresh}.
   *
   * @param request requête
   * @return réponse
   */
  public String refresh(PayslipService.PayslipRefreshRequestDto request) {
    return new GetOneExecutor<String>(String.class, PayslipService.REFRESH_IDENTIFIER)
        .execute(() -> service().refresh(request));
  }

}
