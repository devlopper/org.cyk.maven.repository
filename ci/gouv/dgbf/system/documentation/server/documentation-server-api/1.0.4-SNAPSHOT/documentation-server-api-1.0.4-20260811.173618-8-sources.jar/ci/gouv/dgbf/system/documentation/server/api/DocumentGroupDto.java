package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de document.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentGroupDto extends AbstractIdentifiableAuditableDto
    implements HasProcessIdentifierDto, HasSourceIdentifierDto, HasRecordIdentifierDto,
    HasOperationIdentifierDto, HasTypeGroupIdentifierDto, HasTypeGroupAsStringDto {

  @JsonbProperty(JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  @JsonbProperty(JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(JSON_RECORD_IDENTIFIER)
  private String recordIdentifier;

  @JsonbProperty(JSON_OPERATION_IDENTIFIER)
  private String operationIdentifier;

  /**
   * Identifiant du type de groupe de document.
   */
  @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
  private String typeGroupIdentifier;

  /**
   * Libellé du type de groupe de document.
   */
  @JsonbProperty(JSON_TYPE_GROUP_AS_STRING)
  private String typeGroupAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeDocumentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de document";
}
