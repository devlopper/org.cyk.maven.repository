package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PolicyVersionDto}.
 *
 * <p>La création (publication) désactive automatiquement la version active précédente de la
 * même politique (RG_IDT_POL_01) sans jamais la supprimer (RG_IDT_POL_02). Une version dont la
 * date de publication ({@link PolicyVersionDto#JSON_PUBLICATION_DATE}) est renseignée est
 * immuable : ni mise à jour ni suppression ne sont possibles. Une version dont la date de
 * publication est nulle (brouillon, jamais publiée) peut en revanche être modifiée ou supprimée
 * (RG_IDT_POL_02).
 *
 * @author Desysoft
 *
 */
@Path(value = PolicyVersionService.PATH)
@Tag(name = "Gestion des Versions de Politique")
public interface PolicyVersionService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "versions-politique";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface PolicyVersionSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de la politique.
     *
     * @return identifiant de la politique
     */
    String getPolicyIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la politique.
     *
     * @param policyIdentifier identifiant de la politique
     */
    void setPolicyIdentifier(String policyIdentifier);

    /**
     * Cette méthode permet d'obtenir le numéro de version.
     *
     * @return numéro de version
     */
    Integer getVersion();

    /**
     * Cette méthode permet d'assigner le numéro de version.
     *
     * @param version numéro de version
     */
    void setVersion(Integer version);

    /**
     * Cette méthode permet d'obtenir la date de publication.
     *
     * @return date de publication
     */
    LocalDateTime getPublicationDate();

    /**
     * Cette méthode permet d'assigner la date de publication.
     *
     * @param publicationDate date de publication
     */
    void setPublicationDate(LocalDateTime publicationDate);

    /**
     * Cette méthode permet d'obtenir l'identifiant du fichier.
     *
     * @return identifiant du fichier
     */
    String getFileIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du fichier.
     *
     * @param fileIdentifier identifiant du fichier
     */
    void setFileIdentifier(String fileIdentifier);

    /**
     * Cette méthode permet d'obtenir si cette version est active.
     *
     * @return si cette version est active
     */
    Boolean getIsActive();

    /**
     * Cette méthode permet d'assigner si cette version est active.
     *
     * @param isActive si cette version est active
     */
    void setIsActive(Boolean isActive);

    /**
     * {@link PolicyVersionDto#JSON_POLICY_IDENTIFIER}.
     */
    String JSON_POLICY_IDENTIFIER = PolicyVersionDto.JSON_POLICY_IDENTIFIER;

    /**
     * {@link PolicyVersionDto#JSON_VERSION}.
     */
    String JSON_VERSION = PolicyVersionDto.JSON_VERSION;

    /**
     * {@link PolicyVersionDto#JSON_PUBLICATION_DATE}.
     */
    String JSON_PUBLICATION_DATE = PolicyVersionDto.JSON_PUBLICATION_DATE;

    /**
     * {@link PolicyVersionDto#JSON_FILE_IDENTIFIER}.
     */
    String JSON_FILE_IDENTIFIER = PolicyVersionDto.JSON_FILE_IDENTIFIER;

    /**
     * {@link PolicyVersionDto#JSON_IS_ACTIVE}.
     */
    String JSON_IS_ACTIVE = PolicyVersionDto.JSON_IS_ACTIVE;
  }

  /**
   * Identifiant du service de création unitaire de {@link PolicyVersionDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_VERSION_POLITIQUE";

  /**
   * Chemin du service de création unitaire de {@link PolicyVersionDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link PolicyVersionDto}. Cette création fait
   * office de publication : elle désactive automatiquement la version active précédente de la
   * même politique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Publication d'une version de politique",
      description = "Ce service permet de publier une nouvelle version de politique")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PolicyVersionCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link PolicyVersionDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyVersionCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PolicyVersionSaveRequestDto {

    /**
     * {@link PolicyVersionDto#getPolicyIdentifier()}.
     */
    @JsonbProperty(JSON_POLICY_IDENTIFIER)
    private String policyIdentifier;

    /**
     * {@link PolicyVersionDto#getVersion()}.
     */
    @JsonbProperty(JSON_VERSION)
    private Integer version;

    /**
     * {@link PolicyVersionDto#getPublicationDate()}.
     */
    @JsonbProperty(JSON_PUBLICATION_DATE)
    private LocalDateTime publicationDate;

    /**
     * {@link PolicyVersionDto#getFileIdentifier()}.
     */
    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;

    /**
     * {@link PolicyVersionDto#getIsActive()}.
     */
    @JsonbProperty(JSON_IS_ACTIVE)
    private Boolean isActive;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link PolicyVersionDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_VERSION_POLITIQUE";

  /**
   * Chemin du service d'obtention de plusieurs {@link PolicyVersionDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PolicyVersionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs versions de politique")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link PolicyVersionDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  public static class PolicyVersionGetManyResponseDto
      extends AbstractGetByPageResponseDto<PolicyVersionDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PolicyVersionDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link PolicyVersionDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_VERSION_POLITIQUE";

  /**
   * Chemin du service d'obtention unitaire de {@link PolicyVersionDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link PolicyVersionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une version de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyVersionDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link PolicyVersionDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_VERSION_POLITIQUE";

  /**
   * Chemin du service d'obtention par identifiant de {@link PolicyVersionDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PolicyVersionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une version de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyVersionDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link PolicyVersionDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_VERSION_POLITIQUE";

  /**
   * Chemin du service de mise à jour unitaire de {@link PolicyVersionDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link PolicyVersionDto}. Seule une
   * version dont la date de publication est nulle (brouillon) peut être mise à jour
   * (RG_IDT_POL_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une version de politique dont la date "
          + "de publication est nulle")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PolicyVersionUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link PolicyVersionDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyVersionUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PolicyVersionSaveRequestDto {

    /**
     * {@link PolicyVersionDto#getPolicyIdentifier()}.
     */
    @JsonbProperty(JSON_POLICY_IDENTIFIER)
    private String policyIdentifier;

    /**
     * {@link PolicyVersionDto#getVersion()}.
     */
    @JsonbProperty(JSON_VERSION)
    private Integer version;

    /**
     * {@link PolicyVersionDto#getPublicationDate()}.
     */
    @JsonbProperty(JSON_PUBLICATION_DATE)
    private LocalDateTime publicationDate;

    /**
     * {@link PolicyVersionDto#getFileIdentifier()}.
     */
    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;

    /**
     * {@link PolicyVersionDto#getIsActive()}.
     */
    @JsonbProperty(JSON_IS_ACTIVE)
    private Boolean isActive;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link PolicyVersionDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_VERSION_POLITIQUE";

  /**
   * Chemin du service de suppression unitaire de {@link PolicyVersionDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link PolicyVersionDto}. Seule une version
   * dont la date de publication est nulle (brouillon) peut être supprimée (RG_IDT_POL_02).
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une version de politique dont la date de "
          + "publication est nulle")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
