package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasRequestAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.HasListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ValueSelectorDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSelectorController extends AbstractController implements HasListController {

  @Inject
  ValueSelectorClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  ValueSelectorRequestMapper requestMapper;

  @Inject
  @Getter
  ValueSourceSelectOneController sourceSelectOneController;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController filterAttributeNameInputTextController;

  @Inject
  @Getter
  ValueSelectorFilterController filterController;

  @Inject
  @Getter
  ValueSelectorActionsController actionsController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ValueSelectorDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ValueSelectorDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ValueSelectorService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getSourceIdentifier(),
        HasSourceAsStringDto.JSON_SOURCE_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, HasNameDto.JSON_NAME,
        HasCodeDto.JSON_CODE, HasFilterAttributeNameDto.JSON_FILTER_ATTRIBUTE_NAME,
        HasRequestAsStringDto.JSON_REQUEST_AS_STRING);

    listController.getReadController().setProjection(projection);

    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());
    listController.getCreateController().setFunction(createControllerFunction());

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    sourceSelectOneController
        .setRenderable(StringCore.isBlank(filterController.getFilter().getSourceIdentifier()));
    sourceSelectOneController.getSelectOneMenu().addValueConsumer(sourceConsumer());

    filterAttributeNameInputTextController.setOutputLableValue("Nom de la colonne de filtre");
    filterAttributeNameInputTextController.getInputText()
        .addValueConsumer(filterAttributeNameConsumer());

    actionsController.listController = listController;
    actionsController.initialize();    
  }

  Consumer<String> codeConsumer() {
    return code -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSelectorDto.class).setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSelectorDto.class).setName(name);
  }

  Consumer<String> sourceConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSelectorDto.class)
        .setSourceIdentifier(identifier);
  }

  Consumer<String> filterAttributeNameConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(ValueSelectorDto.class)
        .setFilterAttributeName(name);
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
      ((ValueSelectorDto) entity)
          .setSourceIdentifier(filterController.getFilter().getSourceIdentifier());
    };
  }

  Function<Object, Object> createControllerFunction() {
    return entity -> {
      ValueSelectorCreateRequestDto request = requestMapper.mapCreate((ValueSelectorDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((ValueSelectorDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((ValueSelectorDto) entity).getName());
      sourceSelectOneController.getSelectOneMenu()
          .writeValue(((ValueSelectorDto) entity).getSourceIdentifier());
      filterAttributeNameInputTextController.getInputText()
          .writeValue(((ValueSelectorDto) entity).getFilterAttributeName());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ValueSelectorUpdateRequestDto request = requestMapper.mapUpdate((ValueSelectorDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            filterAttributeNameInputTextController.getInputText(),
            sourceSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
