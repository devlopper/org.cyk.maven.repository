package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Nature du Réclamable.
   */
  String nature;

  /**
   * Indique si le Réclamable existe encore dans payroll ({@code null} : tous).
   */
  Boolean isActivated;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    nature = getNature(filter);
    isActivated = IsActivatedFilter.get(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setNature(filter, nature);
    IsActivatedFilter.set(filter, isActivated);
  }

  /**
   * Cette méthode permet d'assigner la nature.
   *
   * @param filter filtre
   * @param nature nature
   */
  public static void setNature(FilterDto filter, String nature) {
    set(filter, JSON_NATURE, f -> f.getValueAsString(), f -> f.setValueAsString(nature));
  }

  /**
   * Cette méthode permet d'obtenir la nature.
   *
   * @param filter filtre
   * @return nature
   */
  public static String getNature(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NATURE));
  }

  /**
   * Identifiant json champ {@link #nature}.
   */
  public static final String JSON_NATURE = ClaimableDto.JSON_NATURE;
}
