package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une demande d'archivage ou de retrait de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileGroupArchivalSolicitationDto extends AbstractIdentifiableAuditableDto {

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "demande d'archivage de fichier de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

  /**
   * Identifiant du fichier de groupe maître.
   */
  @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
  private String fileGroupIdentifier;

  /**
   * Identifiant de l'archive effective ciblée par un retrait, NULL pour un archivage.
   */
  @JsonbProperty(JSON_ORIGIN_IDENTIFIER)
  private String originIdentifier;

  /**
   * Indique s'il s'agit d'une demande de retrait (calculé depuis l'origine).
   */
  @JsonbProperty(JSON_WITHDRAWAL)
  private Boolean withdrawal;

  /**
   * Statut de la demande.
   */
  @JsonbProperty(JSON_STATUS)
  private FileGroupArchivalStatus status;

  /**
   * Libellé du statut de la demande.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant du créateur réel immuable.
   */
  @JsonbProperty(JSON_CREATOR_IDENTIFIER)
  private String creatorIdentifier;

  /**
   * Date de création de la demande.
   */
  @JsonbProperty(JSON_CREATION_DATE)
  private LocalDateTime creationDate;

  /**
   * Motif de la demande.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Identifiant de l'auteur de la décision (acceptation ou refus).
   */
  @JsonbProperty(JSON_DECISION_AUTHOR_IDENTIFIER)
  private String decisionAuthorIdentifier;

  /**
   * Date de la décision.
   */
  @JsonbProperty(JSON_DECISION_DATE)
  private LocalDateTime decisionDate;

  /**
   * Motif du refus.
   */
  @JsonbProperty(JSON_REFUSAL_REASON)
  private String refusalReason;

  /**
   * Date d'annulation.
   */
  @JsonbProperty(JSON_CANCELLATION_DATE)
  private LocalDateTime cancellationDate;

  /**
   * Motif d'annulation.
   */
  @JsonbProperty(JSON_CANCELLATION_REASON)
  private String cancellationReason;

  /**
   * Indique si la demande peut être acceptée.
   */
  @JsonbProperty(JSON_ACCEPTABLE)
  private Boolean acceptable;

  /**
   * Indique si la demande peut être refusée.
   */
  @JsonbProperty(JSON_REFUSABLE)
  private Boolean refusable;

  /**
   * Indique si la demande peut être annulée.
   */
  @JsonbProperty(JSON_CANCELLABLE)
  private Boolean cancellable;

  /**
   * Indique si le motif de la demande peut être corrigé.
   */
  @JsonbProperty(JSON_CORRECTABLE)
  private Boolean correctable;

  /**
   * Clé JSON de l'identifiant du fichier de groupe maître.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER = "identifiantFichierGroupe";

  /**
   * Clé JSON de l'identifiant de l'archive d'origine.
   */
  public static final String JSON_ORIGIN_IDENTIFIER = "identifiantOrigine";

  /**
   * Clé JSON indiquant si c'est une demande de retrait.
   */
  public static final String JSON_WITHDRAWAL = "estRetrait";

  /**
   * Clé JSON du statut de la demande.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Clé JSON du libellé du statut de la demande.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Clé JSON de l'identifiant du créateur.
   */
  public static final String JSON_CREATOR_IDENTIFIER = "identifiantCreateur";

  /**
   * Clé JSON de la date de création.
   */
  public static final String JSON_CREATION_DATE = "dateCreation";

  /**
   * Clé JSON du motif de la demande.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Clé JSON de l'identifiant de l'auteur de décision.
   */
  public static final String JSON_DECISION_AUTHOR_IDENTIFIER = "identifiantAuteurDecision";

  /**
   * Clé JSON de la date de décision.
   */
  public static final String JSON_DECISION_DATE = "dateDecision";

  /**
   * Clé JSON du motif de refus.
   */
  public static final String JSON_REFUSAL_REASON = "motifRefus";

  /**
   * Clé JSON de la date d'annulation.
   */
  public static final String JSON_CANCELLATION_DATE = "dateAnnulation";

  /**
   * Clé JSON du motif d'annulation.
   */
  public static final String JSON_CANCELLATION_REASON = "motifAnnulation";

  /**
   * Clé JSON indiquant si la demande peut être acceptée.
   */
  public static final String JSON_ACCEPTABLE = "peutEtreAccepte";

  /**
   * Clé JSON indiquant si la demande peut être refusée.
   */
  public static final String JSON_REFUSABLE = "peutEtreRefuse";

  /**
   * Clé JSON indiquant si la demande peut être annulée.
   */
  public static final String JSON_CANCELLABLE = "peutEtreAnnule";

  /**
   * Clé JSON indiquant si le motif de la demande peut être corrigé.
   */
  public static final String JSON_CORRECTABLE = "peutEtreCorrige";
}
