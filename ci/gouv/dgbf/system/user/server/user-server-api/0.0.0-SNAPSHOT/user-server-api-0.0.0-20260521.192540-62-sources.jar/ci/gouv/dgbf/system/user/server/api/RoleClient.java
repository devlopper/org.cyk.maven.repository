package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignSystemAdministratorRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignSystemAdministratorResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleRevokeRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleRevokeResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link RoleService}.
 *
 * @author Aranud
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class RoleClient extends AbstractClient<RoleService> implements GetByIdentifier<RoleDto>,
    GetMany<RoleGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public RoleClient service(RoleService service) {
    return (RoleClient) super.service(service);
  }

  /**
   * {@link RoleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(RoleCreateRequestDto request) {
    return new CreateExecutor(RoleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link RoleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RoleGetManyResponseDto>(RoleGetManyResponseDto.class,
        RoleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link RoleService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RoleGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
                                        String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RoleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<RoleDto>(RoleDto.class, RoleService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link RoleService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RoleDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                        String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link RoleService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public RoleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<RoleDto>(RoleDto.class, RoleService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link RoleService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RoleDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
                                 String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link RoleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(RoleUpdateRequestDto request) {
    return new IdentifiableExecutor(RoleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link RoleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(RoleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link RoleService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link RoleService#assign}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleAssignResponseDto assign(RoleAssignRequestDto request) {
    return new GetOneExecutor<RoleAssignResponseDto>(RoleAssignResponseDto.class,
        RoleService.ASSIGN_IDENTIFIER).execute(() -> service().assign(request));

  }

  /**
   * {@link RoleService#revoke}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleRevokeResponseDto revoke(RoleRevokeRequestDto request) {
    return new GetOneExecutor<RoleRevokeResponseDto>(RoleRevokeResponseDto.class,
        RoleService.REVOKE_IDENTIFIER).execute(() -> service().revoke(request));
  }

  /**
   * {@link RoleService#assignSystemAdministrator}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleAssignSystemAdministratorResponseDto assignSystemAdministrator(
      RoleAssignSystemAdministratorRequestDto request) {
    return new GetOneExecutor<RoleAssignSystemAdministratorResponseDto>(
        RoleAssignSystemAdministratorResponseDto.class,
        RoleService.ASSIGN_SYSTEM_ADMINISTRATOR_IDENTIFIER).execute(() ->
        service().assignSystemAdministrator(request));
  }
}
