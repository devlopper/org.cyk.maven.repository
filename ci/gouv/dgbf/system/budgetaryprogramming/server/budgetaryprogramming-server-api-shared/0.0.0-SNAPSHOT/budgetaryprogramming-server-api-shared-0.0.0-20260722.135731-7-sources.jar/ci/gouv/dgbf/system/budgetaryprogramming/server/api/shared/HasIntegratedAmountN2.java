package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant intégré à l'horizon N2.
 *
 * @author Christian
 */
public interface HasIntegratedAmountN2 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant intégré à l'horizon N2.
   *
   * @return le montant intégré à l'horizon N2
   */
  Long getIntegratedAmountN2();

  /**
   * Cette méthode permet d'assigner le montant intégré à l'horizon N2.
   *
   * @param amount le montant intégré à l'horizon N2
   */
  void setIntegratedAmountN2(Long amount);

  /**
   * Identifiant java du montant intégré à l'horizon N2.
   */
  String FIELD_INTEGRATED_AMOUNT_N2 = "integratedAmountN2";
}
