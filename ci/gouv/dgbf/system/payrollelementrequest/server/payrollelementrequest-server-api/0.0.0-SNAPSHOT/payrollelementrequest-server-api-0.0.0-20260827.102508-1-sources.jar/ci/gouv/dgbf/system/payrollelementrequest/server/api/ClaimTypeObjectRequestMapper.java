package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeObjectService.ClaimTypeObjectCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeObjectService.ClaimTypeObjectUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimTypeObjectDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimTypeObjectDto}.

    @author akm
               """)
public interface ClaimTypeObjectRequestMapper extends
    RequestMapper<ClaimTypeObjectDto, ClaimTypeObjectCreateRequestDto,
        ClaimTypeObjectUpdateRequestDto> {

}
