package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant de groupe de type de
 * réclamation.
 *
 * @author akm
 *
 */
public interface HasClaimTypeGroupIdentifierDto {

  /**
   * Identifiant json de l'identifiant du groupe de type de réclamation.
   */
  String JSON_CLAIM_TYPE_GROUP_IDENTIFIER = "idGroupeTypeReclamation";

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de type de réclamation.
   *
   * @return identifiant du groupe de type de réclamation
   */
  String getClaimTypeGroupIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de type de réclamation.
   *
   * @param claimTypeGroupIdentifier identifiant du groupe de type de réclamation
   */
  void setClaimTypeGroupIdentifier(String claimTypeGroupIdentifier);
}
