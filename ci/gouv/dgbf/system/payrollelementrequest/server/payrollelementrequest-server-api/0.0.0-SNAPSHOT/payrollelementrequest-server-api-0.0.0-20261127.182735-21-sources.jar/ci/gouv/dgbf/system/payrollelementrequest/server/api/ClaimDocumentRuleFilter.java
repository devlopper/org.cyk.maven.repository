package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimDocumentRuleDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimDocumentRuleFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Code pièce du FUR.
   */
  String pieceCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimDocumentRuleFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimDocumentRuleFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    pieceCode = getPieceCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setPieceCode(filter, pieceCode);
  }

  /**
   * Cette méthode permet d'assigner le code pièce.
   *
   * @param filter filtre
   * @param pieceCode code pièce
   */
  public static void setPieceCode(FilterDto filter, String pieceCode) {
    set(filter, JSON_PIECE_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(pieceCode));
  }

  /**
   * Cette méthode permet d'obtenir le code pièce.
   *
   * @param filter filtre
   * @return code pièce
   */
  public static String getPieceCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PIECE_CODE));
  }

  /**
   * Identifiant json champ {@link #pieceCode}.
   */
  public static final String JSON_PIECE_CODE = ClaimDocumentRuleDto.JSON_PIECE_CODE;
}
