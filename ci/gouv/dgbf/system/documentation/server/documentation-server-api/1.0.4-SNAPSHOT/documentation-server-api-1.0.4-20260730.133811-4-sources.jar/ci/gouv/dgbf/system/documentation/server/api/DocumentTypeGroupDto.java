package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de type de document.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentTypeGroupDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasGroupIdentifierDto {

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeTypeDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeTypeDocumentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de type de document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de type de document";
}
