package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasGroupIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ConditionalValueDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ConditionalValueFilter extends AbstractIdentifiableFilter
    implements FilterHasGroupIdentifier {

  /**
   * Identifiant {@link ConditionalValueGroupDto}.
   */
  private String groupIdentifier;
  
  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ConditionalValueFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ConditionalValueFilter(FilterDto dto) {
    super(dto);
  }
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterGroupIdentifier(filter);
  }

}
