package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.PolicyTypeService.PolicyTypeCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyTypeService.PolicyTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PolicyTypeDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link PolicyTypeDto}.

    @author Desysoft
               """)
public interface PolicyTypeRequestMapper
    extends RequestMapper<PolicyTypeDto, PolicyTypeCreateRequestDto,
        PolicyTypeUpdateRequestDto> {

}
