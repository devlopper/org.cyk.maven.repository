package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.logging.server.api.AnomalyClient;
import ci.gouv.dgbf.system.logging.server.api.AnomalyDto;
import ci.gouv.dgbf.system.logging.server.api.AnomalyFilter;
import ci.gouv.dgbf.system.logging.server.api.AnomalyService;
import ci.gouv.dgbf.system.logging.server.api.AnomalyService.AnomalyTreatRequestDto;
import ci.gouv.dgbf.system.logging.server.api.HasTreatableDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Contrôleur de gestion des anomalies inter-modules.
 *
 * @author Christian
 *
 */
@Dependent
public class AnomalyController extends AbstractController {

  @Inject
  AnomalyClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  AnomalyFilterController filterController;

  @Inject
  @Getter
  InputTextController treatmentCommentInputTextController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Gestion des anomalies";
  }

  /**
   * Initialise le contrôleur et la liste des anomalies.
   */
  public void initialize() {
    listController.setEntityClass(AnomalyDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(AnomalyService.PATH);
    listController.setFilterController(filterController);

    listController.getReadController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AnomalyFilter.JSON_TYPE,
        "typeAsString",
        AnomalyFilter.JSON_MODULE,
        "context",
        AnomalyFilter.JSON_CONTAINS_MASKED_DATA,
        HasStatusDto.JSON_STATUS,
        HasStatusAsStringDto.JSON_STATUS_AS_STRING,
        HasTreatableDto.JSON_TREATABLE,
        "treatmentDate",
        "treatingAdministrator",
        "treatmentComment",
        AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING));

    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    // Configuration de l'action de workflow : Traitement d'anomalie
    treatmentCommentInputTextController.setOutputLableValue("Commentaire de traitement");
    treatmentCommentInputTextController.getInputText().setRequired(true);
    treatmentCommentInputTextController.getInputText().addValueConsumer(comment ->
        listController.getCreateControllerOrUpdateControllerEntityAs(AnomalyDto.class)
            .setTreatmentComment(comment));

    listController.getUpdateController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, "treatmentComment"));

    listController.getUpdateController().setFunction(entity -> {
      AnomalyDto dto = (AnomalyDto) entity;
      AnomalyTreatRequestDto request = new AnomalyTreatRequestDto();
      request.setIdentifier(dto.getIdentifier());
      request.setTreatmentComment(dto.getTreatmentComment());
      request.setAuditWho(userIdentifier);
      return client.treat(request);
    });

    if (listController.getUpdateDialog() != null) {
      listController.getUpdateDialog().setHeader("Traiter l'anomalie");
    }
    listController.getShowUpdateDialogButton().setValue("Traiter");
    listController.getShowUpdateDialogButton().setTitle("Traiter l'anomalie");
    listController.getShowUpdateDialogButton().setIcon("pi pi-check");
    if (listController.getShowUpdateDialogButtonController() != null) {
      listController.getShowUpdateDialogButtonController().setRenderedFunction(
          showUpdateDialogButtonRenderedFunction());
    }

    listController.getDataTable().getActionColumn().setRendered(true);
    listController.getDataTable().getActionColumn().setWidth("120");

    listController.getShowCreateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
  }

  java.util.function.Function<Object, Boolean> showUpdateDialogButtonRenderedFunction() {
    return record -> record instanceof AnomalyDto dto && Boolean.TRUE.equals(dto.getTreatable());
  }
}
