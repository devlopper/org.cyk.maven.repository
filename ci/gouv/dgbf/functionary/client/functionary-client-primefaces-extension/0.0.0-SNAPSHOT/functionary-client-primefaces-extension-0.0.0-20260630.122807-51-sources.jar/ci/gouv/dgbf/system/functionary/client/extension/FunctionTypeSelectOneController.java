package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.FunctionTypeClient;
import ci.gouv.dgbf.system.functionary.server.api.FunctionTypeDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionTypeService.FunctionTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FunctionTypeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FunctionTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    FunctionTypeDto, FunctionTypeGetManyResponseDto, FunctionTypeClient> {

  @Getter
  @Inject
  FunctionTypeClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FunctionTypeSelectOneController() {
    super(FunctionTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
