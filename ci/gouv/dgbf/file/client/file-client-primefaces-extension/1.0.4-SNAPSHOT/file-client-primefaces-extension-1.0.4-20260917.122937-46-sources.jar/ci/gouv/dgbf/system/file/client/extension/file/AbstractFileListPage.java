package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe abstraite représente une page de liste de fichiers s'appuyant sur
 * {@link FileController}, afin que ses sous-classes bénéficient du filtre sans avoir à le
 * recabler.
 *
 * @author Christian
 *
 */
public abstract class AbstractFileListPage extends AbstractPage {

  @Inject
  @Getter
  protected FileController controller;

  @Inject
  @Getter
  protected OpenFileViewerButtonController openViewerButtonController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste des fichiers";
  }
}
