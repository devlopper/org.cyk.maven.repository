package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentCorrespondenceDto}.
*
* @author desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-28T18:00:39+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentCorrespondenceRequestMapperImpl implements PayrollComponentCorrespondenceRequestMapper {

    @Override
    public PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceCreateRequestDto mapCreate(PayrollComponentCorrespondenceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceCreateRequestDto payrollComponentCorrespondenceCreateRequestDto = new PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceCreateRequestDto();

        payrollComponentCorrespondenceCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentCorrespondenceCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentCorrespondenceCreateRequestDto.setLegacyComponentCode( arg0.getLegacyComponentCode() );
        payrollComponentCorrespondenceCreateRequestDto.setLegacyCategoryCode( arg0.getLegacyCategoryCode() );
        payrollComponentCorrespondenceCreateRequestDto.setLegacyScaleCode( arg0.getLegacyScaleCode() );
        payrollComponentCorrespondenceCreateRequestDto.setPayrollComponentCode( arg0.getPayrollComponentCode() );
        payrollComponentCorrespondenceCreateRequestDto.setEarning( arg0.getEarning() );

        return payrollComponentCorrespondenceCreateRequestDto;
    }

    @Override
    public PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceUpdateRequestDto mapUpdate(PayrollComponentCorrespondenceDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceUpdateRequestDto payrollComponentCorrespondenceUpdateRequestDto = new PayrollComponentCorrespondenceService.PayrollComponentCorrespondenceUpdateRequestDto();

        payrollComponentCorrespondenceUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentCorrespondenceUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentCorrespondenceUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentCorrespondenceUpdateRequestDto.setLegacyComponentCode( arg0.getLegacyComponentCode() );
        payrollComponentCorrespondenceUpdateRequestDto.setLegacyCategoryCode( arg0.getLegacyCategoryCode() );
        payrollComponentCorrespondenceUpdateRequestDto.setLegacyScaleCode( arg0.getLegacyScaleCode() );
        payrollComponentCorrespondenceUpdateRequestDto.setPayrollComponentCode( arg0.getPayrollComponentCode() );
        payrollComponentCorrespondenceUpdateRequestDto.setEarning( arg0.getEarning() );

        return payrollComponentCorrespondenceUpdateRequestDto;
    }
}
