package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Path(AdministrativeUnitEmployeeService.PATH)
@Tag(name = "Gestion des employés d'unités administratives")
public interface AdministrativeUnitEmployeeService extends Service {

  /**
   * Chemin de base.
   */
  String PATH = "employes-unites-administratives";

  /**
   * Cette interface représente la base de requête d'enregistrement.
   */
  interface AdministrativeUnitEmployeeBaseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
     *
     * @return identifiant {@link BudgetDto}
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
     *
     * @param identifier identifiant {@link BudgetDto}
     */
    void setBudgetIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant unité administrative.
     *
     * @return identifiant unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant unité administrative.
     *
     * @param identifier identifiant unité administrative
     */
    void setAdministrativeUnitIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_BUDGET_IDENTIFIER}.
     */
    String JSON_BUDGET_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_BUDGET_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;
  }

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface AdministrativeUnitEmployeeSaveRequestDto
      extends AdministrativeUnitEmployeeBaseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant employé.
     *
     * @return identifiant employé
     */
    String getEmployeeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant employé.
     *
     * @param identifier identifiant employé
     */
    void setEmployeeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'emploi.
     *
     * @return identifiant de l'emploi
     */
    String getJobIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'emploi.
     *
     * @param identifier identifiant de l'emploi
     */
    void setJobIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'indice de paie.
     *
     * @return identifiant de l'indice de paie
     */
    String getPayIndexIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'indice de paie.
     *
     * @param identifier identifiant de l'indice de paie
     */
    void setPayIndexIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la fonction.
     *
     * @return identifiant de la fonction
     */
    String getFunctionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la fonction.
     *
     * @param identifier identifiant de la fonction
     */
    void setFunctionIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_EMPLOYEE_IDENTIFIER}.
     */
    String JSON_EMPLOYEE_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_EMPLOYEE_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_JOB_IDENTIFIER}.
     */
    String JSON_JOB_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_JOB_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_PAY_INDEX_IDENTIFIER}.
     */
    String JSON_PAY_INDEX_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_PAY_INDEX_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_FUNCTION_IDENTIFIER}.
     */
    String JSON_FUNCTION_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_FUNCTION_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(AdministrativeUnitEmployeeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements AdministrativeUnitEmployeeSaveRequestDto {

    /**
     * Alias local de la clé JSON homonyme sur {@link AdministrativeUnitEmployeeDto}.
     * Détail : symbole {@code JSON_BALANCE_TRANSFER_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    public static final String JSON_BALANCE_TRANSFER_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_BALANCE_TRANSFER_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER;

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
    String employeeIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;

    @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
    String payIndexIdentifier;

    @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
    String functionIdentifier;

    /**
     * Identifiant de l'unité administrative d'origine du solde lors d'un transfert en entrée.
     *
     * @see AdministrativeUnitEmployeeDto#balanceTransferOriginAdministrativeUnitIdentifier
     */
    @JsonbProperty(JSON_BALANCE_TRANSFER_ORIGIN_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String balanceTransferOriginAdministrativeUnitIdentifier;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_IS_FUNCTIONARY}.
     */
    @JsonbProperty(AdministrativeUnitEmployeeDto.JSON_IS_FUNCTIONARY)
    Boolean isFunctionary;
  }

  /**
   * Identifiant du service de création par fonctionnaire.
   */
  String CREATE_BY_FUNCTIONARY_IDENTIFIER =
      "CREATION_PAR_FONCTIONNAIRE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création par fonctionnaire.
   */
  String CREATE_BY_FUNCTIONARY_PATH = "creation-par-fonctionnaire";

  /**
   * Cette méthode permet de créer {@link AdministrativeUnitEmployeeDto} par fonctionnaire.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_FUNCTIONARY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_FUNCTIONARY_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByFunctionary(AdministrativeUnitEmployeeCreateByFunctionaryRequestDto request);

  /**
   * Cette classe représente la requête de création par fonctionnaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeCreateByFunctionaryRequestDto extends
      AbstractAuditedRequestJsonDto implements AdministrativeUnitEmployeeBaseSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    String functionaryIdentifier;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_FUNCTIONARY_IDENTIFIER}.
     */
    public static final String JSON_FUNCTIONARY_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_FUNCTIONARY_IDENTIFIER;
  }

  /**
   * Champs d'affectation EPN pour la création contractuelle (sans identifiant employé).
   */
  interface AdministrativeUnitEmployeeCreateContractualAssignmentRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'emploi.
     *
     * @return identifiant de l'emploi
     */
    String getJobIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'emploi.
     *
     * @param identifier identifiant de l'emploi
     */
    void setJobIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'indice de paie.
     *
     * @return identifiant de l'indice de paie
     */
    String getPayIndexIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'indice de paie.
     *
     * @param identifier identifiant de l'indice de paie
     */
    void setPayIndexIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la fonction.
     *
     * @return identifiant de la fonction
     */
    String getFunctionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la fonction.
     *
     * @param identifier identifiant de la fonction
     */
    void setFunctionIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_JOB_IDENTIFIER}.
     */
    String JSON_JOB_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_JOB_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_PAY_INDEX_IDENTIFIER}.
     */
    String JSON_PAY_INDEX_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_PAY_INDEX_IDENTIFIER;

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_FUNCTION_IDENTIFIER}.
     */
    String JSON_FUNCTION_IDENTIFIER = AdministrativeUnitEmployeeDto.JSON_FUNCTION_IDENTIFIER;
  }

  /**
   * Données employé transmises à la création contractuelle ({@code CREATION_EMPLOYE}).
   */
  interface AdministrativeUnitEmployeeCreateContractualEmployeeRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe de matricule.
     *
     * @return identifiant du groupe de matricule
     */
    String getRegistrationNumberGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe de matricule.
     *
     * @param identifier identifiant du groupe de matricule
     */
    void setRegistrationNumberGroupIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir si le groupe de matricule est fonction publique.
     *
     * @return est groupe de matricule fonction publique
     */
    Boolean getIsRegistrationNumberGroupPublicFunction();

    /**
     * Cette méthode permet d'assigner si le groupe de matricule est fonction publique.
     *
     * @param isRegistrationNumberGroupPublicFunction est groupe de matricule fonction publique
     */
    void setIsRegistrationNumberGroupPublicFunction(
        Boolean isRegistrationNumberGroupPublicFunction);

    /**
     * Cette méthode permet d'obtenir le matricule.
     *
     * @return matricule
     */
    String getRegistrationNumber();

    /**
     * Cette méthode permet d'assigner le matricule.
     *
     * @param registrationNumber matricule
     */
    void setRegistrationNumber(String registrationNumber);

    /**
     * Cette méthode permet d'obtenir le prénom.
     *
     * @return prénom
     */
    String getFirstName();

    /**
     * Cette méthode permet d'assigner le prénom.
     *
     * @param firstName prénom
     */
    void setFirstName(String firstName);

    /**
     * Cette méthode permet d'obtenir le nom.
     *
     * @return nom
     */
    String getLastNames();

    /**
     * Cette méthode permet d'assigner le nom.
     *
     * @param lastNames nom
     */
    void setLastNames(String lastNames);

    /**
     * Cette méthode permet d'obtenir l'adresse e-mail.
     *
     * @return adresse e-mail
     */
    String getEmailAddress();

    /**
     * Cette méthode permet d'assigner l'adresse e-mail.
     *
     * @param emailAddress adresse e-mail
     */
    void setEmailAddress(String emailAddress);

    /**
     * Cette méthode permet d'obtenir l'identifiant du genre.
     *
     * @return identifiant du genre
     */
    String getGenderIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du genre.
     *
     * @param identifier identifiant du genre
     */
    void setGenderIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir si le genre est masculin.
     *
     * @return est genre masculin
     */
    Boolean getIsGenderMasculine();

    /**
     * Cette méthode permet d'assigner si le genre est masculin.
     *
     * @param isGenderMasculine est genre masculin
     */
    void setIsGenderMasculine(Boolean isGenderMasculine);

    /**
     * Cette méthode permet d'obtenir la date de naissance.
     *
     * @return date de naissance
     */
    LocalDate getBirthDate();

    /**
     * Cette méthode permet d'assigner la date de naissance.
     *
     * @param birthDate date de naissance
     */
    void setBirthDate(LocalDate birthDate);

    /**
     * Cette méthode permet d'obtenir la date de première prise de service.
     *
     * @return date de première prise de service
     */
    LocalDate getFirstServiceStartDate();

    /**
     * Cette méthode permet d'assigner la date de première prise de service.
     *
     * @param firstServiceStartDate date de première prise de service
     */
    void setFirstServiceStartDate(LocalDate firstServiceStartDate);

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER = "idGroupeMatricule";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION =
        "estGroupeMatriculeFonctionPublique";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_REGISTRATION_NUMBER = "matricule";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_FIRST_NAME = "nom";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_LAST_NAMES = "prenoms";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_EMAIL_ADDRESS = "adresseEmail";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_GENDER_IDENTIFIER = "idGenre";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_IS_GENDER_MASCULINE = "estGenreMasculin";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_BIRTH_DATE = "dateNaissance";

    /**
     * Clé JSON alignée sur le module employé.
     */
    String JSON_FIRST_SERVICE_START_DATE = "datePremierePriseService";
  }

  /**
   * Identifiant du service de création d'un contractuel dans une unité administrative.
   */
  String CREATE_CONTRACTUAL_IDENTIFIER = "CREATION_CONTRACTUEL_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de création d'un contractuel dans une unité administrative.
   */
  String CREATE_CONTRACTUAL_PATH = "creation-contractuel";

  /**
   * Cette méthode permet de créer un employé contractuel puis son rattachement à une unité
   * administrative (EPN).
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_CONTRACTUAL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_CONTRACTUAL_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createContractual(AdministrativeUnitEmployeeCreateContractualRequestDto request);

  /**
   * Cette classe représente la requête de création d'un contractuel dans une unité
   * administrative. L'employé n'existe pas encore : son identifiant est produit par la création
   * côté serveur et n'apparaît pas dans cette requête.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeCreateContractualRequestDto extends AbstractAuditedRequestJsonDto
      implements AdministrativeUnitEmployeeBaseSaveRequestDto,
      AdministrativeUnitEmployeeCreateContractualAssignmentRequestDto,
      AdministrativeUnitEmployeeCreateContractualEmployeeRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;

    @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
    String payIndexIdentifier;

    @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
    String functionIdentifier;

    @JsonbProperty(JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
    String registrationNumberGroupIdentifier;

    @JsonbProperty(JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
    Boolean isRegistrationNumberGroupPublicFunction;

    @JsonbProperty(JSON_REGISTRATION_NUMBER)
    String registrationNumber;

    @JsonbProperty(JSON_FIRST_NAME)
    String firstName;

    @JsonbProperty(JSON_LAST_NAMES)
    String lastNames;

    @JsonbProperty(JSON_EMAIL_ADDRESS)
    String emailAddress;

    @JsonbProperty(JSON_GENDER_IDENTIFIER)
    String genderIdentifier;

    @JsonbProperty(JSON_IS_GENDER_MASCULINE)
    Boolean isGenderMasculine;

    @JsonbProperty(JSON_BIRTH_DATE)
    LocalDate birthDate;

    @JsonbProperty(JSON_FIRST_SERVICE_START_DATE)
    LocalDate firstServiceStartDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class AdministrativeUnitEmployeeGetManyResponseDto
      extends AbstractGetByPageResponseDto<AdministrativeUnitEmployeeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<AdministrativeUnitEmployeeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = AdministrativeUnitEmployeeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(AdministrativeUnitEmployeeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeUpdateRequestDto extends ByIdentifierRequestDto
      implements AdministrativeUnitEmployeeSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
    String employeeIdentifier;

    @JsonbProperty(JSON_JOB_IDENTIFIER)
    String jobIdentifier;

    @JsonbProperty(JSON_PAY_INDEX_IDENTIFIER)
    String payIndexIdentifier;

    @JsonbProperty(JSON_FUNCTION_IDENTIFIER)
    String functionIdentifier;

  }

  /**
   * Cette interface représente la requête d'entrée ou de sortie.
   */
  interface AdministrativeUnitEmployeeBoardRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link MovementTypeDto}.
     *
     * @return identifiant {@link MovementTypeDto}
     */
    String getMovementTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link MovementTypeDto}.
     *
     * @param identifier identifiant {@link MovementTypeDto}
     */
    void setMovementTypeIdentifier(String identifier);

    /**
     * {@link AdministrativeUnitEmployeeDto#JSON_MOVEMENT_TYPE_IDENTIFIER}.
     */
    String JSON_MOVEMENT_TYPE_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_MOVEMENT_TYPE_IDENTIFIER;
  }

  /**
   * Identifiant du service de sortie.
   */
  String OFFBOARD_IDENTIFIER = "SORTIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de sortie.
   */
  String OFFBOARD_PATH = "sortie";

  /**
   * Cette méthode permet de sortir {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(OFFBOARD_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = OFFBOARD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response offboard(AdministrativeUnitEmployeeOffboardRequestDto request);

  /**
   * Cette classe représente la requête de sortie.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitEmployeeOffboardRequestDto extends ByIdentifierRequestDto
      implements AdministrativeUnitEmployeeBoardRequestDto {

    @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
    String movementTypeIdentifier;

    /**
     * Genre de processus de sortie (définitive ou temporaire), à rapprocher du type de mouvement
     * sélectionné.
     *
     * @see AdministrativeUnitEmployeeDto#JSON_OFFBOARD_PROCESS_KIND
     * @see AdministrativeUnitEmployeeOffboardProcessKind
     */
    @JsonbProperty(AdministrativeUnitEmployeeDto.JSON_OFFBOARD_PROCESS_KIND)
    AdministrativeUnitEmployeeOffboardProcessKind offboardProcessKind;
  }

  /**
   * Identifiant du service d'annulation de sortie.
   */
  String CANCEL_OFFBOARD_IDENTIFIER = "ANNULATION_SORTIE_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service d'annulation de sortie.
   */
  String CANCEL_OFFBOARD_PATH = "annulation-sortie";

  /**
   * Cette méthode permet d'annuler une sortie de {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_OFFBOARD_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CANCEL_OFFBOARD_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response cancelOffboard(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link AdministrativeUnitEmployeeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de calcul.
   */
  String CALCULATE_IDENTIFIER = "CALCUL_POSTE_UNITE_ADMINISTRATIVE_EMPLOYE";

  /**
   * Chemin du service de calcul.
   */
  String CALCULATE_PATH = "calcul";

  /**
   * Cette méthode permet de calculer les projections de poste d'un AdministrativeUnitEmployee.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CALCULATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CALCULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response calculate(AdministrativeUnitEmployeeCalculateRequestDto request);

  /**
   * Cette classe représente la requête de calcul.
   *
   * @author Christian
   */
  class AdministrativeUnitEmployeeCalculateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Identifiant du service de saisie de mouvements.
   */
  String RECORD_PAYROLL_MOVEMENTS_IDENTIFIER = "SAISIE_MOUVEMENT_EMPLOYE_UNITE_ADMINISTRATIVE";

  /**
   * Chemin du service de saisie de mouvements.
   */
  String RECORD_PAYROLL_MOVEMENTS_PATH = "saisies-mouvements";

  /**
   * Saisie de mouvements de paie pour l'employé UA désigné par {@code identifier} dans la requête.
   *
   * @param request charge utile et audit ({@code auditWho}, {@code auditSession})
   * @return {@link IdentifiableResponseDto}
   */
  @Path(RECORD_PAYROLL_MOVEMENTS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = RECORD_PAYROLL_MOVEMENTS_IDENTIFIER,
      summary = "Saisie de mouvements pour un employé d'unité administrative",
      description = "Crée un ou plusieurs mouvements de paie à partir des instances d'éléments de "
          + "paie fournies, pour un employé UA donné et une date d'effet.")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response recordPayrollMovements(
      AdministrativeUnitEmployeeRecordPayrollMovementsRequestDto request);

  /**
   * Corps de requête REST pour {@link
   * #recordPayrollMovements(AdministrativeUnitEmployeeRecordPayrollMovementsRequestDto)}.
   * Hérite de {@link ByIdentifierRequestDto} : identifiant de
   * l'{@link AdministrativeUnitEmployeeDto} cible et champs d'audit transverses.
   *
   * @author Christian
   */
  @Getter
  @Setter
  @Schema(name = "AdministrativeUnitEmployeeRecordPayrollMovementsRequest",
      description = "Requête de saisie de mouvements de paie pour un employé d'unité "
          + "administrative")
  class AdministrativeUnitEmployeeRecordPayrollMovementsRequestDto
      extends ByIdentifierRequestDto {

    /**
     * Clé JSON : date d'effet du ou des mouvements ({@link MovementDto#JSON_EFFECTIVE_DATE}).
     */
    public static final String JSON_EFFECTIVE_DATE = MovementDto.JSON_EFFECTIVE_DATE;

    /**
     * Clé JSON : type de mouvement
     * ({@link AdministrativeUnitEmployeeDto#JSON_MOVEMENT_TYPE_IDENTIFIER}).
     */
    public static final String JSON_MOVEMENT_TYPE_IDENTIFIER =
        AdministrativeUnitEmployeeDto.JSON_MOVEMENT_TYPE_IDENTIFIER;

    /**
     * Clé JSON : liste des identifiants d'instances d'éléments de paie concernés par la saisie.
     */
    public static final String JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIERS =
        "idInstancesElementPaie";

    /**
     * Date d'effet du mouvement (référence métier commune aux instances créées).
     */
    @Schema(description = "Date d'effet du mouvement")
    @JsonbProperty(JSON_EFFECTIVE_DATE)
    LocalDate effectiveDate;

    /**
     * Identifiant du type de mouvement dans le référentiel du service paie (pas la table locale
     * {@code MovementType} de la masse salariale).
     */
    @Schema(description = "Identifiant du type de mouvement (référentiel paie)")
    @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
    String movementTypeIdentifier;

    /**
     * Identifiants des instances d'éléments de paie : une entrée peut donner lieu à un mouvement
     * distinct côté domaine paie.
     */
    @Schema(description = "Identifiants des instances d'éléments de paie à mouvementer")
    @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIERS)
    List<String> payrollElementInstanceIdentifiers;
  }
}
