package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import jakarta.enterprise.context.Dependent;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * Le contrôleur du bouton d'ouverture de la page de liste des rapports.
 */
@Dependent
public class ReadReportListButtonController extends AbstractController {

  @Getter
  @Setter
  Button button;

  @Getter
  @Setter
  Map<String, List<String>> parameters;

  /**
   * Le constructeur.
   */
  public ReadReportListButtonController() {
    button = new Button();
    button.setTitle("Edition des états");
    button.setValueFromTitle();
    button.setIcon("pi pi-print");
    button.setStyleClass("ui-button-success mr-2");
  }

  public void openDialog() {
    ReportEditOnlyListPage.openInDialog(parameters);
  }

}
