package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de constante.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ConstantGroupDto extends AbstractIdentifiableNamableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasFromDateDto<LocalDateTime>,
    HasToDateDto<LocalDateTime> {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_GROUP_NAME)
  private String groupName;
  
  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;

  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;
  
  /**
   * Identifiant json de {@link #groupName}.
   */
  public static final String JSON_GROUP_NAME = "nomGroupe";
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeConstante";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeConstanteChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de constante";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de constante";
}
