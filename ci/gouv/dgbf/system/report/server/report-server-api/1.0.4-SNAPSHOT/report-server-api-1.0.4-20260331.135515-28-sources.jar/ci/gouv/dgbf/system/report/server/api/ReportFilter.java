package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class ReportFilter extends AbstractIdentifiableFilter {

}

