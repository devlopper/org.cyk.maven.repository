package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentGroupService.PayrollComponentGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentGroupService.PayrollComponentGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollComponentGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollComponentGroupDto}.

    @author Arnaud
               """)
public interface PayrollComponentGroupRequestMapper
    extends RequestMapper<PayrollComponentGroupDto, 
            PayrollComponentGroupCreateRequestDto, PayrollComponentGroupUpdateRequestDto> {

}
