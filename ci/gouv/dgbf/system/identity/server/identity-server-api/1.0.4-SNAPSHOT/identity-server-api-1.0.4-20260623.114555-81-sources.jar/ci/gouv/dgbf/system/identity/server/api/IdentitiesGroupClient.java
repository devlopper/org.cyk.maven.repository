package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupUpdateIdentityRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupService.IdentitiesGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client de {@link IdentitiesGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class IdentitiesGroupClient extends AbstractClient<IdentitiesGroupService>
    implements GetByIdentifier<IdentitiesGroupDto>, GetMany<IdentitiesGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public IdentitiesGroupClient service(IdentitiesGroupService service) {
    return (IdentitiesGroupClient) super.service(service);
  }

  /**
   * {@link IdentitiesGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(IdentitiesGroupCreateRequestDto request) {
    return new CreateExecutor(IdentitiesGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link IdentitiesGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentitiesGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupGetManyResponseDto>(
        IdentitiesGroupGetManyResponseDto.class, IdentitiesGroupService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link IdentitiesGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentitiesGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link IdentitiesGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentitiesGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupDto>(IdentitiesGroupDto.class,
        IdentitiesGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link IdentitiesGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentitiesGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link IdentitiesGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public IdentitiesGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<IdentitiesGroupDto>(IdentitiesGroupDto.class,
        IdentitiesGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link IdentitiesGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentitiesGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link IdentitiesGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(IdentitiesGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(IdentitiesGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link IdentitiesGroupService#updateIdentity}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateIdentity(IdentitiesGroupUpdateIdentityRequestDto request) {
    return new IdentifiableExecutor(IdentitiesGroupService.UPDATE_IDENTITY_IDENTIFIER)
        .execute(() -> service().updateIdentity(request));
  }

  /**
   * {@link IdentitiesGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(IdentitiesGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link IdentitiesGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
