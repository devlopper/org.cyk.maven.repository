package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

/**
 * Cette énumération représente la phase de montant.
 */
public enum AmountPhase {

  /**
   * Saisie.
   */
  INPUTTED,
  
  /**
   * Arbitré.
   */
  ARBITRATED,
  
  /**
   * Validé.
   */
  VALIDATED,
  
  /**
   * Intégré.
   */
  INTEGRATED
  
  ;
}
