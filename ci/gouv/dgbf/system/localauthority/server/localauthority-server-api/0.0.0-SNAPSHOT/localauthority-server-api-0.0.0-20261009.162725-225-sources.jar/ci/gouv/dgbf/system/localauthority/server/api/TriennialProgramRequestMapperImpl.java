package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TriennialProgramDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-09T16:27:53+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TriennialProgramRequestMapperImpl implements TriennialProgramRequestMapper {

    @Override
    public TriennialProgramService.TriennialProgramCreateRequestDto mapCreate(TriennialProgramDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramService.TriennialProgramCreateRequestDto triennialProgramCreateRequestDto = new TriennialProgramService.TriennialProgramCreateRequestDto();

        triennialProgramCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        triennialProgramCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        triennialProgramCreateRequestDto.setApprovalNumber( arg0.getApprovalNumber() );

        return triennialProgramCreateRequestDto;
    }

    @Override
    public TriennialProgramService.TriennialProgramUpdateRequestDto mapUpdate(TriennialProgramDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramService.TriennialProgramUpdateRequestDto triennialProgramUpdateRequestDto = new TriennialProgramService.TriennialProgramUpdateRequestDto();

        triennialProgramUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        triennialProgramUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        triennialProgramUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        triennialProgramUpdateRequestDto.setMaxActionAmount( arg0.getMaxActionAmount() );
        triennialProgramUpdateRequestDto.setMaxOperationAmount( arg0.getMaxOperationAmount() );

        return triennialProgramUpdateRequestDto;
    }
}
