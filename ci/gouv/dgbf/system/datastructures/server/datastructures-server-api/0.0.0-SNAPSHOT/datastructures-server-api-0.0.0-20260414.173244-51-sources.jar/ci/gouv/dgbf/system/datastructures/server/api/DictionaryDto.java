package ci.gouv.dgbf.system.datastructures.server.api;


import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un dictionnaire.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DictionaryDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Les noms des entrées du {@link DictionaryDto}.
   */
  @JsonbProperty(JSON_ENTRIES_NAMES)
  private List<String> entriesNames;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDictionnaire";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "dictionnaireChaine";

  /**
   * identifiant json {@link DictionaryDto#entriesNames}.
   */
  public static final String JSON_ENTRIES_NAMES = "nomsEntrees";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dictionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
