package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateN2AsString {

  /**
   * Obtient le montant restant à valider pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant restant à valider pour l'année N+2 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToValidateN2AsString();

  /**
   * Définit le montant restant à valider pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToValidateN2AsString le montant restant à valider pour l'année N+2
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToValidateN2AsString(String remainingAmountToValidateN2AsString);

  /**
   * Identifiant java du montant restant à valider pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_VALIDATE_N2_AS_STRING =
      "remainingAmountToValidateN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName