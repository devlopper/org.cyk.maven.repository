package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente un filtre basé sur la notion de code de niveau de log.
 *
 * @author Christian
 */
public interface LevelCodeFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir le code de niveau de log.
   *
   * @param filter {@link FilterDto}
   * @return code de niveau de log
   */
  public static String get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner le code de niveau de log.
   *
   * @param filter {@link FilterDto}
   * @param logLevelCode code de niveau de log
   */
  public static void set(FilterDto filter, String logLevelCode) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsString(logLevelCode));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = HasLevelCodeDto.JSON_LEVEL_CODE;

}