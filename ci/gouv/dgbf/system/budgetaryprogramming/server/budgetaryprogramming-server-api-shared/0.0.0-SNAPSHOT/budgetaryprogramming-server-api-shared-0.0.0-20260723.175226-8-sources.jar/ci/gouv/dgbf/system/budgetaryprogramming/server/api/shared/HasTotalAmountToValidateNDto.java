package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToValidateNDto extends HasTotalAmountToValidateN {

  /**
   * Identifiant json du montant total à valider pour l'année N.
   */
  String JSON_TOTAL_AMOUNT_TO_VALIDATE_N = "montantTotalAValiderN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName