package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une sélection d'une valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectOne<T> extends AbstractSelect<T> {

  String nullChoiceLabel;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectOne() {
    nullChoiceLabel = "Aucune sélection";
  }

  /**
   * Cette méthode permet d'ajouter un choix de valeur nulle.
   *
   * @param label libellé
   * @return this
   */
  public AbstractSelectOne<T> addNullChoice(String label) {
    choiceBuilder().label(label).build();
    return this;
  }

  /**
   * Cette méthode permet d'ajouter un choix de valeur nulle.
   *
   * @return this
   */
  public AbstractSelectOne<T> addNullChoice() {
    addNullChoice(nullChoiceLabel);
    return this;
  }
}
