package ci.gouv.dgbf.system.logging.server.api;

import java.util.logging.Logger;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente le statut de la période.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
@Deprecated(forRemoval = true)
public enum Level {

  /**
   * {@link LevelName#ERROR}.
   */
  ERROR(LevelName.ERROR),

  /**
   * {@link LevelName#WARNING}.
   */
  WARNING(LevelName.WARNING),

  /**
   * {@link LevelName#INFORMATION}.
   */
  INFORMATION(LevelName.INFORMATION),

  /**
   * {@link LevelName#DEBUG}.
   */
  DEBUG(LevelName.DEBUG),

  /**
   * {@link LevelName#CONFIGURATION}.
   */
  CONFIGURATION(LevelName.CONFIGURATION),

  /**
   * {@link LevelName#TRACE}.
   */
  TRACE(LevelName.TRACE);

  /**
   * Nom.
   */
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir un nom par le niveau.
   *
   * @param level le niveau
   * @return le nom
   */
  public static String getName(Level level) {
    if (level == null) {
      return null;
    }
    return level.name;
  }

  /**
   * Cette méthode permet d'obtenir un niveau par le nom.
   *
   * @param name le nom du niveau
   * @return le niveau
   */
  public static Level getByName(String name) {
    if (name == null) {
      return null;
    }
    switch (name) {
      case LevelName.ERROR:
        return ERROR;
      case LevelName.WARNING:
        return WARNING;
      case LevelName.INFORMATION:
        return INFORMATION;
      case LevelName.CONFIGURATION:
        return CONFIGURATION;
      case LevelName.DEBUG:
        return DEBUG;
      case LevelName.TRACE:
        return TRACE;
      default:
        Logger.getLogger(java.util.logging.Level.class.getName())
            .log(java.util.logging.Level.WARNING, "{0} n''est pas un nom de niveau valide.", name);
        return null;
    }
  }
}
