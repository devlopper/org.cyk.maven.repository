package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.UserRoleClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleService.UserRoleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link UserRoleDto}.
 *
 * @author Christian
 */
@Dependent
public class UserRoleSelectOneController extends AbstractSelectOneIdentifiableController<
    UserRoleDto, UserRoleGetManyResponseDto, UserRoleClient> {

  @Getter
  @Inject
  UserRoleClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected UserRoleSelectOneController() {
    super(UserRoleDto.class, SelectItemLabelStrategy.NAME);
  }
}
