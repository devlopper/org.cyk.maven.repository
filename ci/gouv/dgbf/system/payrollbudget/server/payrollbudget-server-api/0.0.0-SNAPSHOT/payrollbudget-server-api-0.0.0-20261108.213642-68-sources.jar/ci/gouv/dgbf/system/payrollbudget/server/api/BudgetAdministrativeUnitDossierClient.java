package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitDossierService.BudgetAdministrativeUnitDossierGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitDossierService.BudgetAdministrativeUnitDossierTransitionRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des dossiers de masse salariale.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BudgetAdministrativeUnitDossierClient
    extends AbstractClient<BudgetAdministrativeUnitDossierService>
    implements OneRetrievable<BudgetAdministrativeUnitDossierDto>,
    GetByIdentifier<BudgetAdministrativeUnitDossierDto>,
    GetMany<BudgetAdministrativeUnitDossierGetManyResponseDto> {

  @Override
  public BudgetAdministrativeUnitDossierClient service(
      BudgetAdministrativeUnitDossierService service) {
    return (BudgetAdministrativeUnitDossierClient) super.service(service);
  }

  /**
   * Recherche multicritère des dossiers.
   *
   * @param request critères, projection et pagination
   * @return les dossiers correspondants
   */
  public BudgetAdministrativeUnitDossierGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitDossierGetManyResponseDto>(
        BudgetAdministrativeUnitDossierGetManyResponseDto.class,
        BudgetAdministrativeUnitDossierService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public BudgetAdministrativeUnitDossierGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Recherche d'un dossier unique.
   *
   * @param request critères et projection
   * @return le dossier correspondant
   */
  public BudgetAdministrativeUnitDossierDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitDossierDto>(
        BudgetAdministrativeUnitDossierDto.class,
        BudgetAdministrativeUnitDossierService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  @Override
  public BudgetAdministrativeUnitDossierDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Lecture d'un dossier par son identifiant.
   *
   * @param request identifiant et projection
   * @return le dossier correspondant
   */
  public BudgetAdministrativeUnitDossierDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitDossierDto>(
        BudgetAdministrativeUnitDossierDto.class,
        BudgetAdministrativeUnitDossierService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public BudgetAdministrativeUnitDossierDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Réceptionne un dossier transmis (CU01).
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto receive(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitDossierService.RECEIVE_IDENTIFIER)
        .execute(() -> service().receive(request));
  }

  /**
   * Valider le traitement d'un dossier : l'étape de validation de ses lignes s'ouvre.
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto validateProcessing(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(
        BudgetAdministrativeUnitDossierService.VALIDATE_PROCESSING_IDENTIFIER)
            .execute(() -> service().validateProcessing(request));
  }

  /**
   * Valider un dossier : il part en consolidation avec ses lignes.
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto validate(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitDossierService.VALIDATE_IDENTIFIER)
        .execute(() -> service().validate(request));
  }

  /**
   * Consolider un dossier de masse salariale.
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto consolidate(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitDossierService.CONSOLIDATE_IDENTIFIER)
        .execute(() -> service().consolidate(request));
  }

  /**
   * Prend un dossier en charge.
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto takeCharge(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(
        BudgetAdministrativeUnitDossierService.TAKE_CHARGE_IDENTIFIER)
            .execute(() -> service().takeCharge(request));
  }

  /**
   * Libère un dossier pris en charge.
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  public IdentifiableResponseDto release(
      BudgetAdministrativeUnitDossierTransitionRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitDossierService.RELEASE_IDENTIFIER)
        .execute(() -> service().release(request));
  }
}
