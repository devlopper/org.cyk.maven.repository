package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SalaryElementComponentDto}.
 *
 * @author akm
 *
 */
@Path(value = SalaryElementComponentService.PATH)
@Tag(name = "Gestion des postes d'éléments de salaires")
public interface SalaryElementComponentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "postes-elements-salaires";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface SalaryElementComponentSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link SalaryElementDto}.
     *
     * @return identifiant {@link SalaryElementDto}
     */
    String getSalaryElementIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link SalaryElementDto}.
     *
     * @param identifier identifiant {@link SalaryElementDto}
     */
    void setSalaryElementIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollComponentDto}.
     *
     * @return identifiant {@link PayrollComponentDto}
     */
    String getPayrollComponentIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollComponentDto}.
     *
     * @param identifier identifiant {@link PayrollComponentDto}
     */
    void setPayrollComponentIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir le taux employé.
     *
     * @return taux employé
     */
    Integer getEmployeeRate();

    /**
     * Cette méthode permet d'assigner le taux employé.
     *
     * @param employeeRate taux employé
     */
    void setEmployeeRate(Integer employeeRate);

    /**
     * Cette méthode permet d'obtenir le taux employeur.
     *
     * @return taux employeur
     */
    Integer getEmployerRate();

    /**
     * Cette méthode permet d'assigner le taux employeur.
     *
     * @param employerRate taux employeur
     */
    void setEmployerRate(Integer employerRate);

    /**
     * Cette méthode permet d'obtenir le montant plancher.
     *
     * @return montant plancher
     */
    Integer getFloor();

    /**
     * Cette méthode permet d'assigner le montant plancher.
     *
     * @param floor montant plancher
     */
    void setFloor(Integer floor);

    /**
     * Cette méthode permet d'obtenir le montant plafond.
     *
     * @return montant plafond
     */
    Integer getCap();

    /**
     * Cette méthode permet d'assigner le montant plafond.
     *
     * @param cap montant plafond
     */
    void setCap(Integer cap);

    /**
     * {@link SalaryElementComponentDto#JSON_SALARY_ELEMENT_IDENTIFIER}.
     */
    public static final String JSON_SALARY_ELEMENT_IDENTIFIER =
        SalaryElementComponentDto.JSON_SALARY_ELEMENT_IDENTIFIER;

    /**
     * {@link SalaryElementComponentDto#JSON_PAYROLL_COMPONENT_IDENTIFIER}.
     */
    public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
        SalaryElementComponentDto.JSON_PAYROLL_COMPONENT_IDENTIFIER;

    /**
     * {@link SalaryElementComponentDto#JSON_EMPLOYEE_RATE}.
     */
    public static final String JSON_EMPLOYEE_RATE = SalaryElementComponentDto.JSON_EMPLOYEE_RATE;

    /**
     * {@link SalaryElementComponentDto#JSON_EMPLOYER_RATE}.
     */
    public static final String JSON_EMPLOYER_RATE = SalaryElementComponentDto.JSON_EMPLOYER_RATE;

    /**
     * {@link SalaryElementComponentDto#JSON_FLOOR}.
     */
    public static final String JSON_FLOOR = SalaryElementComponentDto.JSON_FLOOR;

    /**
     * {@link SalaryElementComponentDto#JSON_CAP}.
     */
    public static final String JSON_CAP = SalaryElementComponentDto.JSON_CAP;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SalaryElementComponentCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class SalaryElementComponentCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SalaryElementComponentSaveRequestDto {
    /**
     * Identifiant de {@link SalaryElementDto}.
     */
    @JsonbProperty(JSON_SALARY_ELEMENT_IDENTIFIER)
    String salaryElementIdentifier;
    /**
     * Identifiant de {@link PayrollComponentDto}.
     */
    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    String payrollComponentIdentifier;
    /**
     * Taux employé.
     */
    @JsonbProperty(JSON_EMPLOYEE_RATE)
    Integer employeeRate;
    /**
     * Taux employeur.
     */
    @JsonbProperty(JSON_EMPLOYER_RATE)
    Integer employerRate;
    /**
     * Plancher.
     */
    @JsonbProperty(JSON_FLOOR)
    Integer floor;
    /**
     * Plafond.
     */
    @JsonbProperty(JSON_CAP)
    Integer cap;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = SalaryElementComponentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class SalaryElementComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<SalaryElementComponentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SalaryElementComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SalaryElementComponentDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SalaryElementComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SalaryElementComponentUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class SalaryElementComponentUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SalaryElementComponentSaveRequestDto {
    /**
     * Identifiant de {@link SalaryElementDto}.
     */
    @JsonbProperty(JSON_SALARY_ELEMENT_IDENTIFIER)
    String salaryElementIdentifier;
    /**
     * Identifiant de {@link PayrollComponentDto}.
     */
    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    String payrollComponentIdentifier;
    /**
     * Taux employé.
     */
    @JsonbProperty(JSON_EMPLOYEE_RATE)
    Integer employeeRate;
    /**
     * Taux employeur.
     */
    @JsonbProperty(JSON_EMPLOYER_RATE)
    Integer employerRate;
    /**
     * Montant employé.
     */
    @JsonbProperty(JSON_FLOOR)
    Integer floor;
    /**
     * Montant employeur.
     */
    @JsonbProperty(JSON_CAP)
    Integer cap;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_POSTE_ELEMENT_SALAIRE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SalaryElementComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
