package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationTypeFunctionService.RepresentationTypeFunctionCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationTypeFunctionService.RepresentationTypeFunctionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RepresentationTypeFunctionDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RepresentationTypeFunctionDto}.

    @author akm
               """)
public interface RepresentationTypeFunctionRequestMapper extends 
    RequestMapper<RepresentationTypeFunctionDto,
    RepresentationTypeFunctionCreateRequestDto, RepresentationTypeFunctionUpdateRequestDto> {

}
