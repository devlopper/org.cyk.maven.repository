package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'insatisfactions
 * constatées sur des tickets (indicateur qualité, compteur d'actions).
 *
 * @author Christian
 */
public interface HasTicketDissatisfactionActionsCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'insatisfactions constatées sur des
   * tickets.
   *
   * @return le nombre cumulé d'insatisfactions constatées sur des tickets
   */
  Integer getTicketDissatisfactionActionsCount();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'insatisfactions constatées sur des
   * tickets.
   *
   * @param ticketDissatisfactionActionsCount le nombre cumulé d'insatisfactions constatées sur
   *                                          des tickets
   */
  void setTicketDissatisfactionActionsCount(Integer ticketDissatisfactionActionsCount);

  /**
   * Identifiant java du nombre cumulé d'insatisfactions constatées sur des tickets.
   */
  String FIELD_TICKET_DISSATISFACTION_ACTIONS_COUNT = "ticketDissatisfactionActionsCount";
}
