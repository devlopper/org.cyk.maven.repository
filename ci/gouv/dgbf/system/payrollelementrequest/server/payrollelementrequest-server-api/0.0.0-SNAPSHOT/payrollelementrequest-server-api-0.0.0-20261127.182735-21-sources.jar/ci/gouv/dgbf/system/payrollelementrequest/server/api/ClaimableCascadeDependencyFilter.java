package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableCascadeDependencyDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableCascadeDependencyFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du Réclamable parent.
   */
  String parentClaimableIdentifier;

  /**
   * Identifiant du Réclamable enfant.
   */
  String childClaimableIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableCascadeDependencyFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableCascadeDependencyFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    parentClaimableIdentifier = getParentClaimableIdentifier(filter);
    childClaimableIdentifier = getChildClaimableIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setParentClaimableIdentifier(filter, parentClaimableIdentifier);
    setChildClaimableIdentifier(filter, childClaimableIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Réclamable parent.
   *
   * @param filter filtre
   * @param parentClaimableIdentifier identifiant du Réclamable parent
   */
  public static void setParentClaimableIdentifier(FilterDto filter,
      String parentClaimableIdentifier) {
    set(filter, JSON_PARENT_CLAIMABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(parentClaimableIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Réclamable parent.
   *
   * @param filter filtre
   * @return identifiant du Réclamable parent
   */
  public static String getParentClaimableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PARENT_CLAIMABLE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Réclamable enfant.
   *
   * @param filter filtre
   * @param childClaimableIdentifier identifiant du Réclamable enfant
   */
  public static void setChildClaimableIdentifier(FilterDto filter,
      String childClaimableIdentifier) {
    set(filter, JSON_CHILD_CLAIMABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(childClaimableIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Réclamable enfant.
   *
   * @param filter filtre
   * @return identifiant du Réclamable enfant
   */
  public static String getChildClaimableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHILD_CLAIMABLE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #parentClaimableIdentifier}.
   */
  public static final String JSON_PARENT_CLAIMABLE_IDENTIFIER =
      ClaimableCascadeDependencyDto.JSON_PARENT_CLAIMABLE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #childClaimableIdentifier}.
   */
  public static final String JSON_CHILD_CLAIMABLE_IDENTIFIER =
      ClaimableCascadeDependencyDto.JSON_CHILD_CLAIMABLE_IDENTIFIER;
}
