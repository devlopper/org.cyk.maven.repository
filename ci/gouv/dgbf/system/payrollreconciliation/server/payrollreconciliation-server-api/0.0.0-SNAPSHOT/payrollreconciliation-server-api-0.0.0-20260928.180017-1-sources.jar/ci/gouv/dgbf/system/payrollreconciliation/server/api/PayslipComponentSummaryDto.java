package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente les indicateurs de synthèse du Contrôle Détaillé (RG_RAP_CTR_10),
 * calculés sur l'intégralité du résultat filtré, pas seulement la page affichée.
 *
 * @author desysoft
 *
 */
@Getter
@Setter
public class PayslipComponentSummaryDto {

  @JsonbProperty(JSON_LINES_COUNT)
  private Long linesCount;

  @JsonbProperty(JSON_REMUNERABLES_COUNT)
  private Long remunerablesCount;

  @JsonbProperty(JSON_LEGACY_AMOUNT_TOTAL)
  private Long legacyAmountTotal;

  @JsonbProperty(JSON_CALO_AMOUNT_TOTAL)
  private Long caloAmountTotal;

  @JsonbProperty(JSON_VARIANCE_TOTAL)
  private Long varianceTotal;

  @JsonbProperty(JSON_VARIANCE_LINES_COUNT)
  private Long varianceLinesCount;

  public static final String JSON_LINES_COUNT = "nombreLignes";
  public static final String JSON_REMUNERABLES_COUNT = "nombreRemunerables";
  public static final String JSON_LEGACY_AMOUNT_TOTAL = "totalMontantSoldeAn2000";
  public static final String JSON_CALO_AMOUNT_TOTAL = "totalMontantCalo";
  public static final String JSON_VARIANCE_TOTAL = "totalEcart";
  public static final String JSON_VARIANCE_LINES_COUNT = "nombreLignesEnEcart";
}
