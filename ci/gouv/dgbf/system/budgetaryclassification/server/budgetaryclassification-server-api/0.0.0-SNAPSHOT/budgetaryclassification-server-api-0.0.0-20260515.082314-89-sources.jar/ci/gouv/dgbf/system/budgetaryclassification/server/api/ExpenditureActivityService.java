package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ExpenditureActivityDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ExpenditureActivityService.PATH)
@Tag(name = "Gestion des activités de dépense")
public interface ExpenditureActivityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites-depense";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface ExpenditureActivitySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le libelle court.
     *
     * @return le libelle court
     */
    String getShortName();

    /**
     * Cette méthode permet d'assigner le libelle court.
     *
     * @param shortName le libelle court
     */
    void setShortName(String shortName);

    /**
     * Cette méthode permet d'obtenir le statut.
     *
     * @return le statut
     */
    ExpenditureActivityStatus getStatus();

    /**
     * Cette méthode permet d'assigner le statut.
     *
     * @param status le statut
     */
    void setStatus(ExpenditureActivityStatus status);

    /**
     * Cette méthode permet d'obtenir le es projet.
     *
     * @return le libelle court
     */
    Boolean getIsProject();

    /**
     * Cette méthode permet d'assigner le es projet.
     *
     * @param isProject le es projet
     */
    void setIsProject(Boolean isProject);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ExpenditureNatureDto}.
     *
     * @return identifiant de {@link ExpenditureNatureDto}
     */
    String getNatureIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ExpenditureNatureDto}.
     *
     * @param natureIdentifier identifiant de {@link ExpenditureNatureDto}
     */
    void setNatureIdentifier(String natureIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto} bénéficiare.
     *
     * @return identifiant de {@link AdministrativeUnitDto} bénéficiare
     */
    String getBeneficiaryAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto} bénéficiare.
     *
     * @param beneficiaryAdministrativeUnitIdentifier identifiant de {@link AdministrativeUnitDto}
     *        bénéficiare
     */
    void setBeneficiaryAdministrativeUnitIdentifier(String beneficiaryAdministrativeUnitIdentifier);


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link LocalityDto}.
     *
     * @return identifiant de {@link LocalityDto}
     */
    String getLocalityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link LocalityDto}.
     *
     * @param localityIdentifier identifiant de {@link LocalityDto}
     */
    void setLocalityIdentifier(String localityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ExpenditureCategoryDto}.
     *
     * @return identifiant de {@link ExpenditureCategoryDto}
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ExpenditureCategoryDto}.
     *
     * @param categoryIdentifier identifiant de {@link ExpenditureCategoryDto}
     */
    void setCategoryIdentifier(String categoryIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionalAccountDto}.
     *
     * @return identifiant de {@link FunctionalAccountDto}
     */
    String getFunctionalAccountIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionalAccountDto}.
     *
     * @param functionalAccountIdentifier identifiant de {@link FunctionalAccountDto}
     */
    void setFunctionalAccountIdentifier(String functionalAccountIdentifier);


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ActionDto}.
     *
     * @return identifiant de {@link ActionDto}
     */
    String getActionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ActionDto}.
     *
     * @param actionIdentifier identifiant de {@link ActionDto}
     */
    void setActionIdentifier(String actionIdentifier);



    /**
     * {@link ExpenditureActivityDto#JSON_SHORT_NAME}.
     */
    String JSON_SHORT_NAME = ExpenditureActivityDto.JSON_SHORT_NAME;


    /**
     * Identifiant json identifiant de {@link ExpenditureNatureDto}.
     */
    String JSON_NATURE_IDENTIFIER = ExpenditureNatureDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de l'unité administrative beneficiare
     * {@link AdministrativeUnitDto}.
     */
    String JSON_BENEFICIARY_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link LocalityDto}.
     */
    String JSON_LOCALITY_IDENTIFIER = LocalityDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link ExpenditureCategoryDto}.
     */
    String JSON_CATEGORY_IDENTIFIER = ExpenditureCategoryDto.JSON_THIS_IDENTIFIER;

    /**
     * {@link ExpenditureActivityDto#JSON_STATUS}.
     */
    String JSON_STATUS = ExpenditureActivityDto.JSON_STATUS;

    /**
     * {@link ExpenditureActivityDto#JSON_IS_PROJECT}.
     */
    String JSON_IS_PROJECT = ExpenditureActivityDto.JSON_IS_PROJECT;

    /**
     * Identifiant json identifiant de {@link FunctionalAccountDto}.
     */
    String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER = FunctionalAccountDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link ActionDto}.
     */
    String JSON_ACTION_IDENTIFIER = ActionDto.JSON_THIS_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE_DEPENSE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ExpenditureActivityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ExpenditureActivityCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ExpenditureActivitySaveRequestDto {

    @JsonbProperty(JSON_SHORT_NAME)
    private String shortName;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;

    @JsonbProperty(JSON_BENEFICIARY_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String beneficiaryAdministrativeUnitIdentifier;


    @JsonbProperty(JSON_LOCALITY_IDENTIFIER)
    private String localityIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_STATUS)
    private ExpenditureActivityStatus status;

    @JsonbProperty(JSON_IS_PROJECT)
    private Boolean isProject;

    @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(JSON_ACTION_IDENTIFIER)
    private String actionIdentifier;

  }


  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE_DEPENSE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des activités de dépense")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ExpenditureActivityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ExpenditureActivityGetManyResponseDto
      extends AbstractGetByPageResponseDto<ExpenditureActivityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ExpenditureActivityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE_DEPENSE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ExpenditureActivityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE_DEPENSE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une activité de dépense")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ExpenditureActivityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);


  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE_DEPENSE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ExpenditureActivityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class ExpenditureActivityUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ExpenditureActivitySaveRequestDto {

    @JsonbProperty(JSON_SHORT_NAME)
    private String shortName;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;

    @JsonbProperty(JSON_BENEFICIARY_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String beneficiaryAdministrativeUnitIdentifier;

    @JsonbProperty(JSON_LOCALITY_IDENTIFIER)
    private String localityIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_STATUS)
    private ExpenditureActivityStatus status;

    @JsonbProperty(JSON_IS_PROJECT)
    private Boolean isProject;

    @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(JSON_ACTION_IDENTIFIER)
    private String actionIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE_DEPENSE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ExpenditureActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
