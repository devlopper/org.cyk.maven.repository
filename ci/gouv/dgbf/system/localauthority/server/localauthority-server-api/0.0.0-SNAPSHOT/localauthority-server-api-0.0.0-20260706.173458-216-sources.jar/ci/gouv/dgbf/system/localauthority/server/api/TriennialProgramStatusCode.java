package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette classe représente le code de {@link TriennialProgramStatus}.
 *
 * @author Christian
 *
 */
public class TriennialProgramStatusCode {

  private TriennialProgramStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";


  /**
   * Transmis.
   */
  public static final String TRANSMITTED = "TRANSMIS";

  /**
   * Accepté.
   */
  public static final String ACCEPTED = "ACCEPTE";
  /**
   * Retourné.
   */
  public static final String RETURNED = "RETOURNE";

  /**
   * Approuvé.
   */
  public static final String APPROVED = "APPROUVE";
}
