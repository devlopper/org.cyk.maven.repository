package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureService.ProcedureCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureService.ProcedureGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureService.ProcedureUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ProcedureService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ProcedureClient extends AbstractClient<ProcedureService>
    implements GetByIdentifier<ProcedureDto>, GetMany<ProcedureGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ProcedureClient service(ProcedureService service) {
    return (ProcedureClient) super.service(service);
  }

  /**
   * {@link ProcedureService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcedureCreateRequestDto request) {
    return new CreateExecutor(ProcedureService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }


  /**
   * {@link ProcedureService#createByModel}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByModel(
      ProcedureService.ProcedureCreateByModeleProcedureRequestDto request) {
    return new CreateExecutor(ProcedureService.CREATE_BY_MODEL_IDENTIFIER)
        .execute(() -> service().createByModel(request));
  }

  /**
   * {@link ProcedureService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcedureGetManyResponseDto>(
        ProcedureGetManyResponseDto.class, ProcedureService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcedureService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcedureService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ProcedureDto>(ProcedureDto.class,
        ProcedureService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProcedureService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcedureDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ProcedureService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ProcedureDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ProcedureDto>(ProcedureDto.class,
        ProcedureService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProcedureService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ProcedureService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcedureUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcedureService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcedureService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProcedureService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ProcedureService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
