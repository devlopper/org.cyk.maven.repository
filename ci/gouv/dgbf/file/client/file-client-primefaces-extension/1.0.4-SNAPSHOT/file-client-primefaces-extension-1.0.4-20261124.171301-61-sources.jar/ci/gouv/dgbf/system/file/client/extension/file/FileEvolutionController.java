package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.ClientRuntimeException;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileJournalFieldKindCode;
import ci.gouv.dgbf.system.file.server.api.FileService.FileBytesAddRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileInformationUpdateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FilePhysicalItemDeclareRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FilePhysicalItemUpdateRequestDto;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import ci.gouv.dgbf.system.file.server.api.PhysicalItemDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.application.FacesMessage;
import jakarta.inject.Inject;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur des évolutions d'un document hors archivage (DEC_FILE_01
 * bloc B2a, RG_FILE_FIC_20 à 23, TCH_FILE_627) : ajouter le scan d'un papier, déclarer le papier
 * d'un document numérique, modifier les informations, changer le Détenteur. Chaque action a sa
 * boîte de dialogue ; une réussite la ferme et rafraîchit la liste (la nature du Fichier, donc les
 * actions proposées, peut changer), un refus du serveur s'affiche dans la boîte, qui reste
 * ouverte.
 *
 * @author Christian
 *
 */
@Dependent
public class FileEvolutionController extends AbstractController {

  /** Widget de la boîte « Ajouter le scan ». */
  public static final String SCAN_WIDGET = "fileScanDialog";

  /** Widget de la boîte « Déclarer le papier ». */
  public static final String DECLARATION_WIDGET = "fileDeclarationDialog";

  /** Widget de la boîte « Modifier les informations ». */
  public static final String INFORMATION_WIDGET = "fileInformationDialog";

  /** Widget de la boîte « Changer le détenteur ». */
  public static final String HOLDER_WIDGET = "fileHolderDialog";

  static final int NOT_FOUND = 404;

  @Inject
  FileClient client;

  @Inject
  MessageManager messageManager;

  @Inject
  ComponentManager componentManager;

  @Setter
  ListController listController;

  @Getter
  String fileIdentifier;

  @Getter
  String fileName;

  @Getter
  String uploadedFileName;

  byte[] uploadedBytes;

  @Getter
  @Setter
  String holder;

  @Getter
  @Setter
  String name;

  @Getter
  @Setter
  String description;

  @Getter
  @Setter
  LocalDate productionDate;

  FileDto initialFile;

  /**
   * Cette méthode permet de savoir si le fichier est un document papier sans contenu, dont on peut
   * ajouter le scan.
   *
   * @param file Fichier
   * @return vrai si le scan peut être ajouté
   */
  public boolean scannable(FileDto file) {
    return file != null && MediumNature.PHYSICAL.equals(file.getMediumNature());
  }

  /**
   * Cette méthode permet de savoir si le papier d'un document numérique peut être déclaré.
   *
   * @param file Fichier
   * @return vrai si le papier peut être déclaré
   */
  public boolean declarable(FileDto file) {
    return file != null && MediumNature.DIGITAL.equals(file.getMediumNature());
  }

  /**
   * Cette méthode permet de savoir si le Détenteur du papier peut être changé.
   *
   * @param file Fichier
   * @return vrai si le Fichier a un exemplaire papier
   */
  public boolean holderChangeable(FileDto file) {
    return file != null && (MediumNature.PHYSICAL.equals(file.getMediumNature())
        || MediumNature.HYBRID.equals(file.getMediumNature()));
  }

  // --- Ajouter le scan ---

  /**
   * Cette méthode permet d'ouvrir la boîte d'ajout du scan.
   *
   * @param identifier identifiant du Fichier
   * @param fileName nom du Fichier
   */
  public void openScan(String identifier, String fileName) {
    start(identifier, fileName);
    uploadedBytes = null;
    uploadedFileName = null;
    show(SCAN_WIDGET);
  }

  /**
   * Cette méthode permet de mémoriser le scan déposé.
   *
   * @param event dépôt
   */
  public void handleScanUpload(FileUploadEvent event) {
    uploadedFileName = event.getFile().getFileName();
    uploadedBytes = event.getFile().getContent();
  }

  /**
   * Cette méthode permet de savoir si un scan est déposé.
   *
   * @return vrai si un contenu est déposé
   */
  public boolean hasUploadedScan() {
    return uploadedBytes != null && uploadedBytes.length > 0;
  }

  /**
   * Cette méthode permet de retirer le scan déposé.
   */
  public void removeUploadedScan() {
    uploadedBytes = null;
    uploadedFileName = null;
  }

  /**
   * Cette méthode permet d'ajouter le scan au Fichier.
   */
  public void addScan() {
    if (!hasUploadedScan()) {
      error("Déposez le scan du document.");
      return;
    }
    FileBytesAddRequestDto request = new FileBytesAddRequestDto();
    request.setIdentifier(fileIdentifier);
    request.setBytes(uploadedBytes);
    request.setAuditWho(userIdentifier);
    execute(SCAN_WIDGET, "Le scan est ajouté au fichier.", () -> client.addBytes(request));
  }

  // --- Déclarer le papier ---

  /**
   * Cette méthode permet d'ouvrir la boîte de déclaration du papier.
   *
   * @param identifier identifiant du Fichier
   * @param fileName nom du Fichier
   */
  public void openDeclaration(String identifier, String fileName) {
    start(identifier, fileName);
    holder = null;
    show(DECLARATION_WIDGET);
  }

  /**
   * Cette méthode permet de déclarer le papier du Fichier.
   */
  public void declare() {
    if (Core.isStringBlank(holder)) {
      error("Le détenteur du papier est obligatoire.");
      return;
    }
    FilePhysicalItemDeclareRequestDto request = new FilePhysicalItemDeclareRequestDto();
    request.setIdentifier(fileIdentifier);
    request.setHolder(holder);
    request.setAuditWho(userIdentifier);
    execute(DECLARATION_WIDGET, "Le papier est déclaré.",
        () -> client.declarePhysicalItem(request));
  }

  // --- Modifier les informations ---

  /**
   * Cette méthode permet d'ouvrir la boîte de modification des informations, préremplie des
   * valeurs actuelles.
   *
   * @param identifier identifiant du Fichier
   * @param fileName nom du Fichier
   */
  public void openInformation(String identifier, String fileName) {
    start(identifier, fileName);
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME, FileDto.JSON_DESCRIPTION,
        FileDto.JSON_PRODUCTION_DATE);
    initialFile = client.getByIdentifier(identifier, projection, userIdentifier, null);
    name = initialFile.getName();
    description = initialFile.getDescription();
    productionDate = initialFile.getProductionDate();
    show(INFORMATION_WIDGET);
  }

  /**
   * Cette méthode permet de modifier les informations : seuls les champs changés sont envoyés, un
   * champ facultatif vidé est envoyé comme effacé (un champ absent reste inchangé).
   */
  public void updateInformation() {
    if (Core.isStringBlank(name)) {
      error("Le nom est obligatoire.");
      return;
    }
    FileInformationUpdateRequestDto request = new FileInformationUpdateRequestDto();
    request.setIdentifier(fileIdentifier);
    request.setAuditWho(userIdentifier);
    Set<String> cleared = new HashSet<>();
    if (!Objects.equals(name.trim(), initialFile.getName())) {
      request.setName(name.trim());
    }
    String newDescription = trimToNull(description);
    String oldDescription = trimToNull(initialFile.getDescription());
    if (!Objects.equals(newDescription, oldDescription)) {
      if (newDescription == null) {
        cleared.add(FileJournalFieldKindCode.DESCRIPTION);
      } else {
        request.setDescription(newDescription);
      }
    }
    if (!Objects.equals(productionDate, initialFile.getProductionDate())) {
      if (productionDate == null) {
        cleared.add(FileJournalFieldKindCode.PRODUCTION_DATE);
      } else {
        request.setProductionDate(productionDate);
      }
    }
    if (!cleared.isEmpty()) {
      request.setClearedFields(cleared);
    }
    if (request.getName() == null && request.getDescription() == null
        && request.getProductionDate() == null && cleared.isEmpty()) {
      error("Aucune information n'a changé.");
      return;
    }
    execute(INFORMATION_WIDGET, "Les informations sont modifiées.",
        () -> client.updateInformation(request));
  }

  // --- Changer le détenteur ---

  /**
   * Cette méthode permet d'ouvrir la boîte de changement de Détenteur, préremplie du Détenteur
   * actuel.
   *
   * @param identifier identifiant du Fichier
   * @param fileName nom du Fichier
   */
  public void openHolder(String identifier, String fileName) {
    start(identifier, fileName);
    PhysicalItemDto physicalItem = readPhysicalItem(identifier);
    holder = physicalItem == null ? null : physicalItem.getHolder();
    show(HOLDER_WIDGET);
  }

  /**
   * Cette méthode lit l'Exemplaire physique. Seule une absence (404) signifie « pas
   * d'Exemplaire » ; toute autre erreur remonte.
   *
   * @param identifier identifiant du Fichier
   * @return Exemplaire physique, {@code null} si le Fichier n'en a pas
   */
  PhysicalItemDto readPhysicalItem(String identifier) {
    try {
      return client.getPhysicalItem(identifier, userIdentifier, null);
    } catch (ClientRuntimeException exception) {
      if (exception.getResponseCode() == NOT_FOUND) {
        return null;
      }
      throw exception;
    }
  }

  /**
   * Cette méthode permet de changer le Détenteur du papier.
   */
  public void changeHolder() {
    if (Core.isStringBlank(holder)) {
      error("Le détenteur du papier est obligatoire.");
      return;
    }
    FilePhysicalItemUpdateRequestDto request = new FilePhysicalItemUpdateRequestDto();
    request.setIdentifier(fileIdentifier);
    request.setHolder(holder.trim());
    request.setAuditWho(userIdentifier);
    execute(HOLDER_WIDGET, "Le détenteur est modifié.", () -> client.updatePhysicalItem(request));
  }

  // --- Commun ---

  static String trimToNull(String value) {
    return Core.isStringBlank(value) ? null : value.trim();
  }

  void start(String identifier, String fileName) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L'identifiant du fichier est obligatoire");
    }
    this.fileIdentifier = identifier;
    this.fileName = fileName;
  }

  /**
   * Exécute la commande ; un refus du serveur reste affiché dans la boîte, une réussite la ferme.
   */
  void execute(String widget, String successMessage, Runnable command) {
    try {
      command.run();
    } catch (ClientRuntimeException exception) {
      error(exception.getMessage());
      return;
    }
    hide(widget);
    refreshList();
    growl(new FacesMessage(FacesMessage.SEVERITY_INFO, successMessage, null));
  }

  void refreshList() {
    if (listController != null) {
      componentManager.update(listController.getDataTable());
    }
  }

  void error(String message) {
    growl(new FacesMessage(FacesMessage.SEVERITY_ERROR, message, null));
  }

  void growl(FacesMessage message) {
    messageManager.addGrowlMessage(message);
    componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
  }

  void show(String widget) {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      // Par le widgetVar : l'identifiant client du dialogue dépend du formulaire englobant.
      primeFaces.ajax().update("@widgetVar(" + widget + ")");
      primeFaces.executeScript("PF('" + widget + "').show();");
    }
  }

  void hide(String widget) {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      primeFaces.executeScript("PF('" + widget + "').hide();");
    }
  }

  /**
   * Obtient l'instance courante de PrimeFaces.
   *
   * @return instance {@link PrimeFaces}
   */
  PrimeFaces getPrimeFaces() {
    return PrimeFaces.current();
  }
}
