package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ActionDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ActionDto}.

    @author Arnaud
               """)
public interface ActionRequestMapper extends RequestMapper<ActionDto,
    ActionCreateRequestDto, ActionUpdateRequestDto> {

}
