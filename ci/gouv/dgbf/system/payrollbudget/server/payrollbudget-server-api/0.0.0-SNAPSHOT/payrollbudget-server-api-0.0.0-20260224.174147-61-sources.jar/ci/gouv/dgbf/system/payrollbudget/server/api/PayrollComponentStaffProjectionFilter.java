package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollComponentIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollPeriodGroupIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollComponentStaffProjectionDto}.
 *
 * @author parfait
 */
@Getter
@Setter
public class PayrollComponentStaffProjectionFilter extends AbstractIdentifiableFilter
    implements FilterHasBudgetAdministrativeUnitStaffIdentifier, 
    FilterHasPayrollComponentIdentifier, FilterHasPayrollPeriodGroupIdentifier {

  /**
   * Identifiant {@link BudgetAdministrativeUnitStaffDto}.
   */
  String budgetAdministrativeUnitStaffIdentifier;

  /**
   * Identifiant poste de paie.
   */
  String payrollComponentIdentifier;

  /**
   * Identifiant groupe de période de paie.
   */
  String payrollPeriodGroupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollComponentStaffProjectionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollComponentStaffProjectionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateHasBudgetAdministrativeUnitStaffIdentifier(filter);
    updatePayrollComponentIdentifier(filter);
    updatePayrollPeriodGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterHasBudgetAdministrativeUnitStaffIdentifier(filter);
    updateFilterPayrollComponentIdentifier(filter);
    updateFilterPayrollPeriodGroupIdentifier(filter);
  }
}
