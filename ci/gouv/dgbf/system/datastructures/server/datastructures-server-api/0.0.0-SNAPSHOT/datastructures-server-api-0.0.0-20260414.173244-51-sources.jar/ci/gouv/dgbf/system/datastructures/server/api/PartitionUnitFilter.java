package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasPartitionIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasPartitionTypeCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStringPartitionValueData;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PartitionUnitDto}.
 *
 * @author Arnaud
 */
@Getter
@Setter
public class PartitionUnitFilter extends AbstractIdentifiableFilter implements
    FilterHasPartitionIdentifier, FilterHasStringPartitionValueData, FilterHasPartitionTypeCode {

  private String partitionTypeCode;

  private String partitionIdentifier;

  private String partitionValueData;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PartitionUnitFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PartitionUnitFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePartitionTypeCode(filter);
    updatePartitionIdentifier(filter);
    updatePartitionValueData(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPartitionTypeCode(filter);
    updateFilterPartitionIdentifier(filter);
    updateFilterPartitionValueData(filter);
  }
}
