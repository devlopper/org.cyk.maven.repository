package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BudgetActivityFundingDto}.
 *
 * @author Donsylla
 */
@Path(value = BudgetActivityFundingService.PATH)
@Tag(name = "Gestion des financements d'activités de budgets")
public interface BudgetActivityFundingService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "financements-activites-budgets";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FINANCEMENT_ACTIVITE_BUDGET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'un financement d'activité de budget",
      description = "Ce service permet de créer un financement d'activité de budget")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BudgetActivityFundingCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetActivityFundingCreateRequestDto extends AbstractAuditedRequestJsonDto {
    @JsonbProperty(BudgetActivityFundingDto.JSON_BUDGET_ACTIVITY_IDENTIFIER)
    private String budgetActivityIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_AMOUNT)
    private Long amount;

    @JsonbProperty(BudgetActivityFundingDto.JSON_COMMENT)
    private String comment;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FINANCEMENTS_ACTIVITES_BUDGETS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des financements d'activités de budgets")
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = BudgetActivityFundingGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  public static class BudgetActivityFundingGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetActivityFundingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BudgetActivityFundingDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FINANCEMENT_ACTIVITE_BUDGET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un financement d'activité de budget")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = BudgetActivityFundingDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_FINANCEMENT_ACTIVITE_BUDGET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un financement d'activité de "
          + "budget")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = BudgetActivityFundingDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FINANCEMENT_ACTIVITE_BUDGET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un financement d'activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BudgetActivityFundingUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetActivityFundingUpdateRequestDto extends ByIdentifierRequestDto {
    @JsonbProperty(BudgetActivityFundingDto.JSON_BUDGET_ACTIVITY_IDENTIFIER)
    private String budgetActivityIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;

    @JsonbProperty(BudgetActivityFundingDto.JSON_AMOUNT)
    private Long amount;

    @JsonbProperty(BudgetActivityFundingDto.JSON_COMMENT)
    private String comment;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FINANCEMENT_ACTIVITE_BUDGET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link BudgetActivityFundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un financement d'activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
