package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.UriBuilder;
import ci.gouv.dgbf.extension.server.service.api.filter.IdentifierFilter;
import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import java.lang.reflect.Field;
import java.net.URI;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.lang3.reflect.FieldUtils;

/**
 * Cette classe représente la base d'un contrôleur.
 *
 * @author Christian
 *
 */
public abstract class AbstractController {

  @Getter
  @Setter
  protected String name;

  @Inject
  protected UserSession userSession;

  @Getter
  protected String userIdentifier;

  @Getter
  protected boolean userAuthenticated;

  @Getter
  protected String requestParameterIdentifierName;

  @Getter
  protected String requestParameterRedirectUrlValue;

  @Getter
  protected String requestParameterTargetOutcomeValue;

  @Inject
  protected RequestManager requestManager;

  /**
   * Cette méthode permet de construire l'uri de base de la requête courante. À appeler
   * explicitement et tôt (ex : dans {@code postConstruct()}/{@code initialize()}) pour les
   * traitements exécutés plus tard hors du thread de la requête JSF (ex : un chargement
   * asynchrone via {@code ContentLoaderController}), où {@link FacesContext#getCurrentInstance()}
   * ne serait plus disponible.
   *
   * @return uri de base de la requête courante
   */
  protected URI buildBaseUri() {
    return requestManager.buildBaseUri();
  }

  @PostConstruct
  void listenPostConstruct() {
    postConstruct();
  }

  protected void postConstruct() {
    if (userIdentifier == null) {
      userIdentifier = computeUserIdentifier();
      userAuthenticated = StringCore.isNotBlank(userIdentifier);
      if (!userAuthenticated) {
        setUserIdentifier(getIdentifierForUnauthenticatedAccess());
      }
      // On utilise la méthode set pour declencher la propagation
      setUserIdentifier(userIdentifier);
    }
    requestParameterIdentifierName = IdentifierFilter.JSON_KEY;
    setRequestParameterRedirectUrlValue();
    setRequestParameterTargetOutcomeValue();
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur.
   *
   * @param userIdentifier identifiant de l'utilisateur
   */
  public void setUserIdentifier(String userIdentifier) {
    this.userIdentifier = userIdentifier;
    propagateUserIdentifierToNestedControllers();
    getChildControllers().forEach(c -> c.setUserIdentifier(userIdentifier));
  }

  protected String computeUserIdentifier() {
    return userSession.getUserIdentifier();
  }

  protected void setRequestParameterRedirectUrlValue() {
    requestParameterRedirectUrlValue =
        requestManager == null ? null : requestManager.getParameterRedirectUrl();
  }

  protected void setRequestParameterTargetOutcomeValue() {
    requestParameterTargetOutcomeValue =
        requestManager == null ? null : requestManager.getParameterTargetOutcome();
  }

  protected Set<String> getRequestParameterValues(String key) {
    return Optional
        .ofNullable(FacesContext.getCurrentInstance().getExternalContext()
            .getRequestParameterValuesMap().get(key))
        .map(array -> Arrays.stream(array).collect(Collectors.toSet()))
        .orElse(Constant.EMPTY_STRINGS_LINKED_HASH_SET);
  }

  protected Set<String> getRequestParameterValuesOrNullIfEmpty(String key) {
    Set<String> set = getRequestParameterValues(key);
    if (CollectionCore.isEmpty(set)) {
      return Constant.NULL_STRINGS_SET;
    }
    return set;
  }

  protected String getRequestParameter(String key) {
    return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(key);
  }

  protected String getRequestParameterIdentifier() {
    return getRequestParameter(requestParameterIdentifierName);
  }

  protected Boolean getRequestParameterAsBoolean(String key) {
    return Core.getBooleanFromString(getRequestParameter(key));
  }

  protected boolean redirectIfUrlNotBlank() {
    if (Core.isStringBlank(requestParameterRedirectUrlValue)) {
      return false;
    }
    navigateByUrl(requestParameterRedirectUrlValue);
    return true;
  }

  protected boolean navigateByUrl(String url) {
    if (Core.isStringBlank(url)) {
      return false;
    }
    NavigationManager.navigateByUrl(url);
    return true;
  }

  protected String buildRequestRelativeUrl() {
    return new UriBuilder().relativeFromRequest(
        (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest())
        .build().toString();
  }

  protected boolean isUserInRole(Object role) {
    return User.hasRole(userSession.getUser(), role);
  }

  protected boolean isUserInAtLeastOneOfRoles(Object[] roles) {
    return User.hasAtLeastOneOfRoles(userSession.getUser(), roles);
  }

  /**
   * Retourne l'ensemble des {@link AbstractController} imbriqués (enfants) dans ce controller.
   * <br/>
   * <br/>
   * Cette méthode sert de point d'extension pour la propagation de certaines propriétés (comme
   * {@code userIdentifier}) depuis un controller parent vers ses controllers enfants. <br/>
   * <br/>
   * Par défaut, un controller n'a pas d'enfant : cette méthode retourne un ensemble vide. Les
   * sous-classes qui contiennent d'autres controllers (en champ simple, en liste, etc.) doivent
   * surcharger cette méthode pour les déclarer explicitement, sinon la propagation ne les atteindra
   * pas. <br/>
   * <br/>
   * Exemple de surcharge :
   * 
   * <pre>{@code
   * @Override
   * protected Set<AbstractController> getChildControllers() {
   *   return Set.of(monControllerEnfant, monAutreControllerEnfant);
   * }
   * }</pre>
   *
   * @return l'ensemble des controllers enfants de ce controller (jamais {@code null}, un ensemble
   *         vide si aucun enfant)
   */
  protected Set<AbstractController> getChildControllers() {
    return Set.of(); // par défaut, aucun enfant
  }

  void propagateUserIdentifierToNestedControllers() {
    for (Field field : FieldUtils.getAllFields(this.getClass())) {
      field.setAccessible(true);
      try {
        Object value = field.get(this);
        propagateUserIdentifierIfController(value);
      } catch (Exception exception) {
        throw new IllegalStateException("Impossible de propager userIdentifier sur " + field,
            exception);
      }
    }
  }

  void propagateUserIdentifierIfController(Object value) {
    if (value instanceof AbstractController controller) {
      controller.setUserIdentifier(this.userIdentifier);
    } else if (value instanceof Collection<?> collection) {
      collection.forEach(this::propagateUserIdentifierIfController);
    } else if (value instanceof Map<?, ?> map) {
      map.values().forEach(this::propagateUserIdentifierIfController);
    }
  }

  /**
   * Fournit l'identifiant "QUI" à utiliser lorsqu'aucune session authentifiée n'existe. Le sens
   * concret dépend du contexte métier de la sous-classe : - déclarant identifié par email vérifié
   * (ex: déclaration d'incident publique) - identifiant technique conventionnel (ex:
   * SYSTEM_ANONYMOUS pour un vrai accès anonyme)
   *
   * @return l'identifiant applicable, ou null si aucun n'est disponible
   */
  protected String getIdentifierForUnauthenticatedAccess() {
    return null;
  }
  
  protected static final String REQUEST_PARAMETER_CONTENT_TITLE = "titreContenu";
}
