package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une nature économique.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EconomicNatureDto extends AbstractIdentifiableCodableNamableAuditableDto {
  
  /**
   * {@link ActivityCategory}.
   */
  @JsonbProperty(value = JSON_ACTIVITY_CATEGORY)
  private ActivityCategory activityCategory;


  /**
   * Répresentation en chaine de caractère de l'opbjet avec la catégorie de naturde de dépense.
   */

  @JsonbProperty(value = JSON_AS_STRING_WITH_CATEGORY)
  private String asStringWithCategory;

  /**
   * Identifiant json de {@link EconomicNatureDto#activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = "categorieActivite";


  /**
   * Identifiant json de {@link EconomicNatureDto#asStringWithCategory}.
   */
  public static final String JSON_AS_STRING_WITH_CATEGORY = "chaineAvecCategorie";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "nature économique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "natures de dépense";
}
