package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'utilisateurs.
 *
 * @author Christian
 */
public interface HasUserCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'utilisateurs.
   *
   * @return le nombre d'utilisateurs
   */
  Integer getUserCount();

  /**
   * Cette méthode permet d'assigner le nombre d'utilisateurs.
   *
   * @param userCount le nombre d'utilisateurs
   */
  void setUserCount(Integer userCount);

  /**
   * Identifiant java du nombre d'utilisateurs.
   */
  String FIELD_USER_COUNT = "userCount";
}
