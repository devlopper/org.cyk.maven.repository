package ci.gouv.dgbf.system.datastructures.server.api;


import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente un type d'entité de donnée.
 *
 * @author Christian
 *
 */
@Getter
public enum DataEntityType {

  /**
   * {@link DataEntityTypeCode#TABLE}.
   */
  TABLE(DataEntityTypeCode.TABLE, "Table"),

  /**
   * {@link DataEntityTypeCode#VIEW}.
   */
  VIEW(DataEntityTypeCode.VIEW, "Vue"),

  /**
   * {@link DataEntityTypeCode#FILE}.
   */
  FILE(DataEntityTypeCode.FILE, "Fichier"),

  /**
   * {@link DataEntityTypeCode#API}.
   */
  API(DataEntityTypeCode.API, "API");

  /**
   * Code.
   */
  String code;
  
  /**
   * Libellé.
   */
  String name;

  /**
   * Cette méthode perme de construire.
   *
   * @param code code
   * @param name libellé
   */
  private DataEntityType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link DataEntityType} par code.
   *
   * @param code code
   * @return {@link DataEntityType}
   */
  public static DataEntityType getByCode(String code) {
    return Stream.of(DataEntityType.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }
}
