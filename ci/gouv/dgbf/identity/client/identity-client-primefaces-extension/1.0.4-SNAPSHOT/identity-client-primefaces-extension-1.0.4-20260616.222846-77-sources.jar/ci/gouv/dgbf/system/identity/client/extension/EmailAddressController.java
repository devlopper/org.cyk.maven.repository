package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressClient;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link EmailAddressDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class EmailAddressController extends AbstractController {

  @Inject
  EmailAddressClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  EmailAddressFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = EmailAddressDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(EmailAddressDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(EmailAddressService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();

    projection.addNames(HasValueDto.JSON_VALUE);

    listController.getReadController().setProjection(projection);

    listController.initialize();
  }
}
