package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.system.processing.server.api.ProcessingDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur des graphiques des {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingsChartsController extends AbstractController {

  @Inject
  @Getter
  ChartController controller;
  
  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    controller.pieChartBuilder().styleBuilder().value("height: 400px;");
    controller.buildPieChart();
    
    controller.barChartBuilder().styleBuilder().value("height: 400px;");
    controller.buildBarChart();
  }
}
