package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.JobService.JobCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.JobService.JobUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link JobDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link JobDto}.

    @author Christian
               """)
public interface JobRequestMapper
    extends RequestMapper<JobDto, JobCreateRequestDto, JobUpdateRequestDto> {

}
