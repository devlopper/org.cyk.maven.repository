package ci.gouv.dgbf.system.employee.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un employé.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EmployeeDto extends AbstractIdentifiableAuditableDto {

  /**
   * Représentation en chaine de caractères de l'identité.
   */
  @JsonbProperty(value = JSON_IDENTITY_AS_STRING)
  private String identityAsString;
  
  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Identifiant groupe de numéro matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
  private String registrationNumberGroupIdentifier;

  /**
   * Est groupe de numéro matricule fonction publique.
   */
  @JsonbProperty(value = JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
  private Boolean isRegistrationNumberGroupPublicFunction;

  /**
   * Numéro matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  private String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  private String lastNames;

  /**
   * Nom et prénoms.
   */
  @JsonbProperty(value = JSON_FIRST_NAME_AND_LAST_NAMES)
  private String firstNameAndLastNames;
  
  /**
   * Identifiant du genre.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  private String genderIdentifier;

  /**
   * Est du genre masculin.
   */
  @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
  private Boolean isGenderMasculine;

  /**
   * Date de naissance.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE)
  private LocalDate birthDate;

  /**
   * Représentation en chaine de caractères de {@link #birthDate}.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE_AS_STRING)
  private String birthDateAsString;

  /**
   * Date de première prise de service.
   */
  @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE)
  private LocalDate firstServiceStartDate;

  /**
   * Représentation en chaine de caractères de {@link #firstServiceStartDate}.
   */
  @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE_AS_STRING)
  private String firstServiceStartDateAsString;

  /**
   * Identifiant champ json {@link #identityAsString}.
   */
  public static final String JSON_IDENTITY_AS_STRING = "identiteChaine";
  
  /**
   * Identifiant champ json {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = "adresseEmail";
  
  /**
   * Identifiant champ json {@link #registrationNumberGroupIdentifier}.
   */
  public static final String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER = "idGroupeMatricule";
  
  /**
   * Identifiant champ json {@link #isRegistrationNumberGroupPublicFunction}.
   */
  public static final String JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION =
      "estGroupeMatriculeFonctionPublique";
  /**
   * Identifiant champ json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";
  
  /**
   * Identifiant champ json {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "nom";
  
  /**
   * Identifiant champ json {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = "prenoms";
  
  /**
   * Identifiant champ json {@link #firstNameAndLastNames}.
   */
  public static final String JSON_FIRST_NAME_AND_LAST_NAMES = "nomEtPrenoms";
  
  /**
   * Identifiant champ json {@link #genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = "idGenre";
  
  /**
   * Identifiant json {@link #isGenderMasculine}.
   */
  public static final String JSON_IS_GENDER_MASCULINE = "estGenreMasculin";
  
  /**
   * Identifiant champ json {@link #birthDate}.
   */
  public static final String JSON_BIRTH_DATE = "dateNaissance";
  
  /**
   * Identifiant champ json {@link #birthDateAsString}.
   */
  public static final String JSON_BIRTH_DATE_AS_STRING = "dateNaissanceChaine";
  
  /**
   * Identifiant champ json {@link #firstServiceStartDate}.
   */
  public static final String JSON_FIRST_SERVICE_START_DATE = "datePremierePriseService";
  
  /**
   * Identifiant champ json {@link #firstServiceStartDateAsString}.
   */
  public static final String JSON_FIRST_SERVICE_START_DATE_AS_STRING =
      "datePremierePriseServiceChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "employé";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
