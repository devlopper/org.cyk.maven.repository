package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a un exemple de valeurs de paramètres.
 *
 * @author Christian
 */
public interface HasParameterValuesExampleDto extends HasParameterValuesExample {

  /**
   * Identifiant json de l'exemple de valeurs de paramètres.
   */
  String JSON_PARAMETER_VALUES_EXAMPLE = "exempleValeursParametres";
}
