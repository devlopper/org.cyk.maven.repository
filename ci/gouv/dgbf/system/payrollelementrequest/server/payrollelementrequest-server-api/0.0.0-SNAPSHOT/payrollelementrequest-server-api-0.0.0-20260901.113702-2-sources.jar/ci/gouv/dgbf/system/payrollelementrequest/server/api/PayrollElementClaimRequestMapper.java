package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollElementClaimDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollElementClaimDto}.

    @author akm
               """)
public interface PayrollElementClaimRequestMapper extends
    RequestMapper<PayrollElementClaimDto, PayrollElementClaimCreateRequestDto,
    PayrollElementClaimUpdateRequestDto> {

}
