package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputDateController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.TypeIdentifierFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueService.ClaimableValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueSaveRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de choix des Éléments de Paie/Constantes de Paie
 * concernés par une réclamation, en Mode de Saisie FAE, avec leur nouvelle valeur (RG_REP_CIB_01
 * à 03, RG_REP_SOU_01). Le FAE ne raisonne pas en Réclamables de Type de Réclamation techniques :
 * chaque ligne porte le libellé métier du Réclamable (résolu via {@code TA_RECLAMABLE},
 * RG_REP_CIB_07) et le simple fait d'y renseigner une valeur vaut choix -- pas de case à cocher
 * séparée. La Date d'effet est unique pour tout le formulaire (RG_REP_CIB_02/03, les Constantes
 * n'en ont pas). Les Éléments et Constantes concernés partagent une seule {@link ClaimedValueDto}.
 *
 * @author akm
 *
 */
@Dependent
public class ClaimableController extends AbstractController {

  @Inject
  ClaimTypeClaimableClient claimTypeClaimableClient;

  @Inject
  ClaimableValueClient claimableValueClient;

  @Inject
  ClaimedValueClient claimedValueClient;

  @Getter
  List<ConcernedClaimable> concernedClaimables;

  /**
   * Mode <em>rétention</em> (RG_REP_PEC_11) : quand {@code true}, {@link #loadExistingValues} lit
   * et {@link #syncValues} écrit le jeu <em>retenu</em> de la Valeur Réclamée (déterminé ou
   * corrigé par l'Agent de Traitement pendant la Prise en charge), et non la saisie du FAE,
   * laissée intacte. En Mode Agent, toujours {@code true} (détermination, RG_REP_PEC_09) ; pour
   * les Cibles FAE, activé seulement quand la réclamation est Prise en charge et que l'Agent la
   * corrige.
   */
  @Getter
  @Setter
  boolean retentionMode;

  /**
   * Date d'effet commune à toutes les Valeurs Réclamées d'Élément de Paie du formulaire (le FAE
   * ne raisonne pas en Réclamables de Type de Réclamation distincts, il saisit une seule fois la
   * date -- les Constantes de Paie n'ont pas de date d'effet, RG_REP_CIB_02/03).
   */
  @Getter
  @Setter
  LocalDate sharedEffectiveDate;

  /**
   * Widget de saisie de {@link #sharedEffectiveDate}.
   */
  @Getter
  InputDateController sharedEffectiveDateInputController;

  /**
   * Cette méthode permet de constuire.
   */
  public ClaimableController() {
    concernedClaimables = new ArrayList<>();
    initializeSharedEffectiveDateInputController();
  }

  /**
   * Cette méthode permet de rafraichir la liste des Réclamables de Type de Réclamation en Mode de
   * Saisie FAE pour le Type de Réclamation choisi -- délègue à {@link #refresh(String, String)},
   * ceux en Mode Agent n'étant ni affichés ni demandés ici (cf.
   * {@code AbstractPayrollElementClaimReadDatasPage#agentModeClaimableController}, une instance
   * distincte de ce même contrôleur pour la Détermination Mode Agent, RG_REP_PEC_09).
   *
   * @param typeIdentifier identifiant du Type de Réclamation
   */
  public void refresh(String typeIdentifier) {
    refresh(typeIdentifier, ValueInputModeSelectOneController.VALUE_FAE);
  }

  /**
   * Cette méthode permet de rafraichir la liste des Réclamables de Type de Réclamation d'un Mode
   * de Saisie donné pour le Type de Réclamation choisi (RG_REP_CIB_01/04/05). Triés par ordre
   * d'affichage explicite (RG_REP_CIB_01), configuré par l'administrateur, plutôt que l'ordre de
   * retour du service, non garanti.
   *
   * @param typeIdentifier identifiant du Type de Réclamation
   * @param valueInputMode Mode de Saisie à charger ({@link
   *        ValueInputModeSelectOneController#VALUE_FAE} ou
   *        {@link ValueInputModeSelectOneController#VALUE_AGENT})
   */
  public void refresh(String typeIdentifier, String valueInputMode) {
    concernedClaimables.clear();
    sharedEffectiveDate = null;
    // Réinitialiser la seule valeur, sans reconstruire le widget : celui-ci doit rester la
    // même instance tout au long de la vue pour que le message de validation associé
    // (identifiant aléatoire, cf. AbstractWidget) reste celui enregistré une fois pour toutes
    // dans InputsGroupController par le contrôleur appelant.
    sharedEffectiveDateInputController.getInputLocalDate().writeValue(null);
    if (typeIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_NATURE, ClaimTypeClaimableDto.JSON_CLAIMABLE_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_CLAIMABLE_AS_STRING, ClaimTypeClaimableDto.JSON_CLAIMABLE_CODE,
        ClaimTypeClaimableDto.JSON_VALUE_INPUT_MODE, ClaimTypeClaimableDto.JSON_MOVEMENT_NATURE,
        ClaimTypeClaimableDto.JSON_RANK, ClaimTypeClaimableDto.JSON_MANDATORY_FOR_FAE);
    FilterDto filter = new FilterDto().addCriteria(TypeIdentifierFilter.JSON_KEY, typeIdentifier);
    ClaimTypeClaimableGetManyResponseDto response =
        claimTypeClaimableClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().stream()
        .filter(target -> valueInputMode.equals(target.getValueInputMode()))
        .forEach(target -> {
          ConcernedClaimable concernedClaimable = new ConcernedClaimable(target.getIdentifier(),
              target.getNature(), target.getClaimableIdentifier());
          concernedClaimable.setObjectLabel(target.getClaimableAsString() == null
              ? target.getClaimableIdentifier() : target.getClaimableAsString());
          concernedClaimable.setClaimableCode(target.getClaimableCode());
          concernedClaimable.setMovementNature(target.getMovementNature());
          concernedClaimable.setRank(target.getRank());
          // Défaut true si absent (rétro-compatibilité d'une projection qui ne le demanderait
          // pas) -- cohérent avec le défaut serveur (RG_REP_CIB_10).
          concernedClaimable.setMandatoryForFae(
              target.getMandatoryForFae() == null ? Boolean.TRUE : target.getMandatoryForFae());
          if (ELEMENT_PAIE.equals(target.getNature())) {
            Map<String, String> instanceCodes = new LinkedHashMap<>();
            concernedClaimable.setInstanceOptions(
                instanceOptionsOf(target.getClaimableIdentifier(), instanceCodes));
            concernedClaimable.setInstanceCodes(instanceCodes);
          }
          concernedClaimables.add(concernedClaimable);
        });
    concernedClaimables.sort(Comparator.comparing(ConcernedClaimable::getRank,
        Comparator.nullsLast(Integer::compareTo)));
    // Le composant de saisie de date ne lit que son propre indicateur "rendered" (cf.
    // datePicker.xhtml, extension) -- un "rendered" porté par l'appelant sur le <ui:include> qui
    // l'inclut n'a aucun effet, ce composant n'étant pas un UIComponent. Piloter l'affichage
    // depuis ici (RG_REP_CIB_02/03, sans objet pour un Type sans Cible Élément de Paie).
    sharedEffectiveDateInputController.getInputLocalDate().setRendered(hasElementTargets());
  }

  /**
   * Cette méthode permet de (re)construire le widget de saisie de {@link #sharedEffectiveDate}
   * (RG_REP_CIB_02/03). L'identifiant/widgetVar du widget restent ceux générés (aléatoires mais
   * stables pour toute la vue, ce contrôleur étant construit une seule fois) : plusieurs
   * instances de ce contrôleur peuvent coexister sur une même page (FAE et Mode Agent, cf.
   * {@code AbstractPayrollElementClaimReadDatasPage}) sans collision d'identifiant.
   */
  private void initializeSharedEffectiveDateInputController() {
    sharedEffectiveDateInputController = new InputDateController();
    sharedEffectiveDateInputController.setOutputLableValue("Date d'effet");
    sharedEffectiveDateInputController.getInputLocalDate().setRequired(true);
    sharedEffectiveDateInputController.getInputLocalDate()
        .addValueConsumer(value -> sharedEffectiveDate = value);
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Élément de Paie (RG_REP_CIB_01).
   *
   * @return les Cibles de nature Élément de Paie
   */
  public List<ConcernedClaimable> getElementTargets() {
    return concernedClaimables.stream().filter(target -> ELEMENT_PAIE.equals(target.getNature()))
        .toList();
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Constante de Paie -- voir
   * {@link #getElementTargets()}.
   *
   * @return les Cibles de nature Constante de Paie
   */
  public List<ConcernedClaimable> getConstantTargets() {
    return concernedClaimables.stream()
        .filter(target -> CONSTANTE_PAIE.equals(target.getNature())).toList();
  }

  /**
   * Cette méthode permet de savoir si la liste contient au moins une Cible Élément de Paie --
   * détermine si le champ Date d'effet (partagé, sans objet pour les Constantes seules) doit être
   * affiché.
   *
   * @return {@code true} si au moins une Cible est un Élément de Paie
   */
  public boolean hasElementTargets() {
    return concernedClaimables.stream()
        .anyMatch(target -> ELEMENT_PAIE.equals(target.getNature()));
  }

  /**
   * Nature Élément de Paie.
   */
  public static final String ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Nature Constante de Paie.
   */
  public static final String CONSTANTE_PAIE = "CONSTANTE_PAIE";

  /**
   * Type de {@link ConcernedClaimable#getValue()} pour la Valeur Réclamée d'une Constante de
   * Paie -- les montants saisis dans ce formulaire sont toujours décimaux ({@code ValueType},
   * {@code core-extension}).
   */
  private static final String VALUE_TYPE_FLOAT = "FLOAT";

  /**
   * Cette méthode permet d'obtenir les instances possibles d'un Élément de Paie, à partir de
   * l'identifiant de son {@code TA_RECLAMABLE} -- résolues via {@code TA_VALEUR_RECLAMABLE}
   * (synchronisées depuis {@code payroll} au même titre que les Éléments/Constantes eux-mêmes,
   * RG_REP_CIB_07), sans appel synchrone au module {@code payroll}.
   *
   * @param elementClaimableIdentifier identifiant {@code TA_RECLAMABLE} de l'Élément de Paie
   * @param instanceCodes rempli, en sortie, du code court de chaque instance retournée (clé
   *        {@link ClaimableValueDto#getIdentifier()}, valeur {@link ClaimableValueDto#getCode()})
   *        -- permet à l'appelant (qui seul connaît la structure du fonctionnaire) de faire
   *        correspondre ces options aux valeurs actuellement actives (RG_REP_IMP_01), sans
   *        second appel réseau
   * @return les instances possibles, en options de sélection
   */
  private List<SelectItem> instanceOptionsOf(String elementClaimableIdentifier,
      Map<String, String> instanceCodes) {
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimableValueDto.JSON_LABEL, ClaimableValueDto.JSON_CODE);
    FilterDto filter = new FilterDto();
    ClaimableValueFilter.setClaimableIdentifier(filter, elementClaimableIdentifier);
    ClaimableValueGetManyResponseDto response;
    try {
      response = claimableValueClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des instances de l'Élément de Paie " + elementClaimableIdentifier
              + " en échec.",
          exception);
      return List.of();
    }
    if (response == null || response.getDatas() == null) {
      return List.of();
    }
    response.getDatas().forEach(
        instance -> instanceCodes.put(instance.getIdentifier(), instance.getCode()));
    return response.getDatas().stream()
        .map(instance -> new SelectItem(instance.getIdentifier(), instance.getLabel())).toList();
  }

  /**
   * Cette méthode permet d'obtenir une instance d'Élément de Paie à partir de son identifiant
   * {@code TA_VALEUR_RECLAMABLE} -- résolue sans appel synchrone au module {@code payroll}
   * (RG_REP_CIB_07).
   *
   * @param instanceIdentifier identifiant {@code TA_VALEUR_RECLAMABLE} de l'instance
   * @return l'instance, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private ClaimableValueDto resolveClaimableValue(String instanceIdentifier) {
    if (instanceIdentifier == null || instanceIdentifier.isBlank()) {
      return null;
    }
    ProjectionDto projection = new ProjectionDto()
        .addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, ClaimableValueDto.JSON_LABEL);
    try {
      return claimableValueClient.getByIdentifier(instanceIdentifier, projection, userIdentifier,
          null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention de l'instance " + instanceIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de compléter la liste des Cibles concernées (déjà rafraîchie via
   * {@link #refresh(String)}) avec les Valeurs Réclamées déjà enregistrées pour une réclamation
   * existante -- utilisé à l'ouverture d'une réclamation existante en modification.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void loadExistingValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimedValueDto.JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER, ClaimedValueDto.JSON_NATURE,
        ClaimedValueDto.JSON_CLAIMABLE_VALUE_IDENTIFIER, ClaimedValueDto.JSON_EFFECTIVE_DATE,
        ClaimedValueDto.JSON_VALUE, ClaimedValueDto.JSON_RETAINED_CLAIMABLE_VALUE_IDENTIFIER,
        ClaimedValueDto.JSON_RETAINED_EFFECTIVE_DATE, ClaimedValueDto.JSON_RETAINED_VALUE,
        ClaimedValueDto.JSON_CORRECTED_BY);
    FilterDto filter =
        new FilterDto().addCriteria(ClaimedValueFilter.JSON_CLAIM_IDENTIFIER, claimIdentifier);
    ClaimedValueGetManyResponseDto response =
        claimedValueClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(value -> concernedClaimables.stream()
        .filter(target -> target.getClaimTypeClaimableIdentifier()
            .equals(value.getClaimTypeClaimableIdentifier()))
        .findFirst().ifPresent(target -> {
          target.setValueIdentifier(value.getIdentifier());
          target.setCorrectedBy(value.getCorrectedBy());
          if (ELEMENT_PAIE.equals(value.getNature())) {
            String claimableValueIdentifier = effectiveClaimableValueIdentifier(value);
            target.setClaimableValueIdentifier(claimableValueIdentifier);
            // En Suppression, la valeur retirée est portée par le champ « actuel » : sans cette
            // reprise, le champ relu reste vide alors que la valeur est enregistrée.
            if (target.isDeletionNature()) {
              target.setSelectedCurrentValueIdentifier(claimableValueIdentifier);
            }
            ClaimableValueDto instance = resolveClaimableValue(claimableValueIdentifier);
            target.setInstanceLabel(
                instance == null ? claimableValueIdentifier : instance.getLabel());
            LocalDate effectiveDate = effectiveDate(value);
            if (sharedEffectiveDate == null && effectiveDate != null) {
              sharedEffectiveDate = effectiveDate;
              sharedEffectiveDateInputController.getInputLocalDate().writeValue(effectiveDate);
            }
          } else if (CONSTANTE_PAIE.equals(value.getNature())) {
            String rawValue = effectiveValue(value);
            target.setValue(rawValue == null ? null : new BigDecimal(rawValue));
          }
        }));
  }

  private String effectiveClaimableValueIdentifier(ClaimedValueDto value) {
    return retentionMode && value.getRetainedClaimableValueIdentifier() != null
        ? value.getRetainedClaimableValueIdentifier() : value.getClaimableValueIdentifier();
  }

  private LocalDate effectiveDate(ClaimedValueDto value) {
    return retentionMode && value.getRetainedEffectiveDate() != null
        ? value.getRetainedEffectiveDate() : value.getEffectiveDate();
  }

  private String effectiveValue(ClaimedValueDto value) {
    return retentionMode && value.getRetainedValue() != null ? value.getRetainedValue()
        : value.getValue();
  }

  /**
   * Cette méthode permet de synchroniser les Valeurs Réclamées des Cibles concernées avec l'état
   * courant de la liste (valeur renseignée/vidée par l'utilisateur) : création de celles
   * nouvellement renseignées, mise à jour de celles dont la valeur a changé, et suppression de
   * celles vidées (RG_REP_CIB_02/03) -- utilisée aussi bien à la Création (aucune Cible n'a
   * encore de {@code valueIdentifier}, le comportement se réduit alors à une simple création) qu'à
   * la Modification d'une réclamation existante.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void syncValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    concernedClaimables.forEach(target -> {
      if (ELEMENT_PAIE.equals(target.getNature())) {
        syncElementValue(claimIdentifier, target);
      } else if (CONSTANTE_PAIE.equals(target.getNature())) {
        syncConstantValue(claimIdentifier, target);
      }
    });
  }

  private void syncElementValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, target);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      applyElementValue(request, target);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  private void syncConstantValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      applyConstantValue(request, target);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      applyConstantValue(request, target);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  /**
   * Cette méthode permet de porter la valeur d'un Élément de Paie sur la requête : dans le jeu
   * <em>retenu</em> en mode rétention (RG_REP_PEC_11), dans la saisie FAE sinon (RG_REP_CIB_02).
   *
   * @param request requête de création ou de mise à jour
   * @param target Cible concernée
   */
  private void applyElementValue(ClaimedValueSaveRequestDto request, ConcernedClaimable target) {
    if (retentionMode) {
      request.setRetainedClaimableValueIdentifier(target.getEffectiveClaimableValueIdentifier());
      request.setRetainedEffectiveDate(sharedEffectiveDate);
    } else {
      request.setClaimableValueIdentifier(target.getEffectiveClaimableValueIdentifier());
      request.setEffectiveDate(sharedEffectiveDate);
    }
  }

  /**
   * Cette méthode permet de porter la valeur d'une Constante de Paie sur la requête -- voir
   * {@link #applyElementValue(ClaimedValueSaveRequestDto, ConcernedClaimable)} (RG_REP_CIB_03).
   *
   * @param request requête de création ou de mise à jour
   * @param target Cible concernée
   */
  private void applyConstantValue(ClaimedValueSaveRequestDto request, ConcernedClaimable target) {
    if (retentionMode) {
      request.setRetainedValue(target.getValue().toString());
      request.setRetainedValueType(VALUE_TYPE_FLOAT);
    } else {
      request.setValue(target.getValue().toString());
      request.setValueType(VALUE_TYPE_FLOAT);
    }
  }

  /**
   * Cette classe représente un Réclamable de Type de Réclamation en Mode FAE, avec son éventuelle
   * Valeur Réclamée. Pas de case à cocher séparée : {@link #isConcerned()} se déduit directement
   * de la valeur renseignée (RG_REP_CIB_01) -- une instance choisie pour un Élément de Paie, une
   * valeur saisie pour une Constante de Paie.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ConcernedClaimable {

    String claimTypeClaimableIdentifier;
    String nature;
    String objectIdentifier;

    /**
     * Libellé métier du Réclamable ciblé (résolu via {@code TA_RECLAMABLE}), affiché au FAE à la
     * place de tout identifiant technique.
     */
    String objectLabel;

    /**
     * Code {@code payroll} du Réclamable ciblé (ex. {@code "010"} pour Fonction) --
     * {@link ClaimTypeClaimableDto#getClaimableCode()}. Détermine, côté page (qui seule connaît
     * la structure du fonctionnaire), quel attribut de {@code structures[i]} consulter pour
     * peupler {@link #currentValueOptions} (RG_REP_IMP_01).
     */
    String claimableCode;

    /**
     * Nature du Mouvement du Réclamable ({@link MovementNatureSelectOneController#VALUE_CREATION}/
     * {@code _MODIFICATION}/{@code _DELETION}) -- détermine le nombre de champs affichés et leur
     * rôle : Création n'affiche que {@link #instanceOptions} (« à attribuer ») ; Modification
     * affiche {@link #currentValueOptions} (« actuel ») puis {@link #instanceOptions}
     * (« nouveau ») ; Suppression n'affiche que {@link #currentValueOptions} (« à retirer »).
     */
    String movementNature;

    /**
     * Ordre d'affichage (RG_REP_CIB_01), configuré par l'administrateur -- sert à trier les
     * Cibles sur l'écran de saisie de la réclamation.
     */
    Integer rank;

    /**
     * Caractère obligatoire pour le FAE, à la Saisie comme à la Soumission (RG_REP_CIB_12) --
     * conditionne l'attribut {@code required} du champ de saisie FAE (movements.xhtml,
     * saveForm.xhtml) ; sans objet côté Mode Agent, toujours requis indépendamment de cet
     * indicateur (RG_REP_CIB_05).
     */
    Boolean mandatoryForFae;

    /**
     * Identifiant de la Valeur Réclamée déjà persistée (renseigné par
     * {@link #loadExistingValues(String)}), ou {@code null} si aucune n'existe encore.
     */
    String valueIdentifier;

    /**
     * Identifiant de l'Agent ayant corrigé la valeur FAE (RG_REP_PEC_11), ou {@code null} : la
     * valeur retenue reprend alors la saisie FAE, ou provient d'une détermination Mode Agent.
     */
    String correctedBy;

    /* Élément de Paie */

    /**
     * Catalogue complet des instances possibles -- champ « à attribuer »/« nouveau » (Création/
     * Modification), jamais affiché en Suppression (cf. {@link #movementNature}).
     */
    List<SelectItem> instanceOptions = List.of();

    /**
     * Code court de chaque option de {@link #instanceOptions} (clé : son identifiant), pour
     * correspondance avec les valeurs actuellement actives d'un fonctionnaire -- rempli par
     * {@link ClaimableController#refresh(String, String)}, jamais par le formulaire lui-
     * même.
     */
    Map<String, String> instanceCodes = Map.of();

    String claimableValueIdentifier;

    /**
     * Libellé métier de l'instance choisie (résolu via {@code TA_RECLAMABLE}), affiché en
     * consultation à la place de l'identifiant technique de {@link #claimableValueIdentifier}.
     */
    String instanceLabel;

    /**
     * Sous-ensemble de {@link #instanceOptions} correspondant aux valeurs actuellement actives du
     * fonctionnaire pour ce Réclamable (RG_REP_IMP_01) -- champ « actuel(le) »/« à retirer »
     * (Modification/Suppression), jamais affiché en Création. Peuplé par la page (seule à
     * connaître la structure du fonctionnaire, cf. javadoc de {@link #claimableCode}), pas par ce
     * contrôleur.
     */
    List<SelectItem> currentValueOptions = List.of();

    /**
     * Valeur actuelle choisie parmi {@link #currentValueOptions} -- présélectionnée par la page
     * quand celle-ci n'en compte qu'une (jamais de choix par défaut sinon, même principe que
     * {@code StructureSelectionController.selectedEmploiCode}).
     */
    String selectedCurrentValueIdentifier;

    /* Constante de Paie */

    BigDecimal value;

    /**
     * Cette méthode permet de constuire.
     *
     * @param claimTypeClaimableIdentifier identifiant du Réclamable de Type de Réclamation
     * @param nature nature de l'objet ciblé
     * @param objectIdentifier identifiant de l'objet ciblé
     */
    public ConcernedClaimable(String claimTypeClaimableIdentifier, String nature,
        String objectIdentifier) {
      this.claimTypeClaimableIdentifier = claimTypeClaimableIdentifier;
      this.nature = nature;
      this.objectIdentifier = objectIdentifier;
    }

    /**
     * Cette méthode permet de savoir si cette Cible est concernée par la réclamation -- vaut le
     * simple fait d'avoir renseigné une valeur, sans case à cocher séparée (RG_REP_CIB_01).
     *
     * @return {@code true} si une valeur est renseignée
     */
    public boolean isConcerned() {
      return ClaimableController.ELEMENT_PAIE.equals(nature)
          ? getEffectiveClaimableValueIdentifier() != null : value != null;
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_CREATION}.
     *
     * @return {@code true} si Création
     */
    public boolean isCreationNature() {
      return MovementNatureSelectOneController.VALUE_CREATION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_MODIFICATION}.
     *
     * @return {@code true} si Modification
     */
    public boolean isModificationNature() {
      return MovementNatureSelectOneController.VALUE_MODIFICATION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #movementNature} vaut
     * {@link MovementNatureSelectOneController#VALUE_DELETION}.
     *
     * @return {@code true} si Suppression
     */
    public boolean isDeletionNature() {
      return MovementNatureSelectOneController.VALUE_DELETION.equals(movementNature);
    }

    /**
     * Cette méthode indique si {@link #currentValueOptions} doit être affiché actif (sélecteur
     * ouvert) plutôt que grisé -- même principe que
     * {@code StructureSelectionController.isEmploiSelectionRendered()} : grisé et présélectionné
     * si un seul candidat, choix explicite requis sinon.
     *
     * @return {@code true} si {@link #currentValueOptions} en compte plus d'un
     */
    public boolean isCurrentValueSelectionRendered() {
      return currentValueOptions.size() > 1;
    }

    /**
     * Cette méthode permet de construire le libellé du champ unique affiché en Création --
     * jamais de mot technique (« Création ») affiché au FAE, le libellé porte l'action
     * elle-même. Locutions verbales/prépositionnelles volontairement invariables (pas d'accord de
     * genre avec {@link #objectLabel}, dont le genre n'est pas connu génériquement).
     *
     * @return libellé du champ unique en Création
     */
    public String getCreationFieldLabel() {
      return objectLabel + " à attribuer";
    }

    /**
     * Cette méthode permet de construire le libellé du champ "actuel" affiché en Modification --
     * voir {@link #getCreationFieldLabel()}.
     *
     * @return libellé du champ "actuel" en Modification
     */
    public String getCurrentFieldLabel() {
      return objectLabel + " actuellement en vigueur";
    }

    /**
     * Cette méthode permet de construire le libellé du champ "réclamé" affiché en Modification --
     * "Nouvelle valeur de X" reste grammaticalement correct quel que soit le genre de X (l'accord
     * porte sur "valeur", invariablement féminin), contrairement à "Nouveau/Nouvelle X".
     *
     * @return libellé du champ "réclamé" en Modification
     */
    public String getNewFieldLabel() {
      return "Nouvelle valeur de " + objectLabel;
    }

    /**
     * Cette méthode permet de construire le libellé du champ unique affiché en Suppression --
     * voir {@link #getCreationFieldLabel()}.
     *
     * @return libellé du champ unique en Suppression
     */
    public String getDeletionFieldLabel() {
      return objectLabel + " à retirer";
    }

    /**
     * Cette méthode permet d'obtenir l'identifiant {@code TA_VALEUR_RECLAMABLE} effectivement
     * soumis pour ce Réclamable : {@link #selectedCurrentValueIdentifier} en Suppression (seul
     * champ affiché, cf. {@link #movementNature}), {@link #claimableValueIdentifier} en Création
     * ou Modification (champ « à attribuer »/« nouveau »).
     *
     * @return identifiant effectivement soumis, ou {@code null} si rien n'est choisi
     */
    public String getEffectiveClaimableValueIdentifier() {
      return isDeletionNature() ? selectedCurrentValueIdentifier : claimableValueIdentifier;
    }

    /**
     * Cette méthode indique si la valeur retenue a été corrigée par l'Agent (RG_REP_PEC_11) --
     * pour un repère discret côté Agent, jamais affiché au FAE.
     *
     * @return {@code true} si {@link #correctedBy} est renseigné
     */
    public boolean isCorrected() {
      return correctedBy != null;
    }
  }
}
