package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets traités.
 *
 * @author Christian
 */
public interface HasProcessedTicketCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre de tickets traités.
   *
   * @return le nombre de tickets traités
   */
  Integer getProcessedTicketCount();

  /**
   * Cette méthode permet d'assigner le nombre de tickets traités.
   *
   * @param processedTicketCount le nombre de tickets traités
   */
  void setProcessedTicketCount(Integer processedTicketCount);

  /**
   * Identifiant java du nombre de tickets traités.
   */
  String FIELD_PROCESSED_TICKET_COUNT = "processedTicketCount";
}
