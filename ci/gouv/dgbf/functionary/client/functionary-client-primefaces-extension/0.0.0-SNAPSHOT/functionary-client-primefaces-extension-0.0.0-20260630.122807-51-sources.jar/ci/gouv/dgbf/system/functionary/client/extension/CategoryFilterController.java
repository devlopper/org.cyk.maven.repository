package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.functionary.server.api.CategoryDto;
import ci.gouv.dgbf.system.functionary.server.api.CategoryFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link CategoryDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class CategoryFilterController extends AbstractFilterController<CategoryFilter> {



  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public CategoryFilterController() {
    super(CategoryFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setCivilServiceStatusIdentifier(
        getRequestParameter(CategoryFilter.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));

    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setCivilServiceStatusIdentifier(identifier));
  }
}
