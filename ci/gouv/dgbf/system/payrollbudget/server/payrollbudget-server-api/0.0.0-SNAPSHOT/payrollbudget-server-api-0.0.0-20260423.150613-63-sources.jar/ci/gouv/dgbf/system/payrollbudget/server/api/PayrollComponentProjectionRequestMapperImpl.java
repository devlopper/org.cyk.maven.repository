package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentProjectionDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-23T15:06:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentProjectionRequestMapperImpl implements PayrollComponentProjectionRequestMapper {

    @Override
    public PayrollComponentProjectionService.PayrollComponentProjectionCreateRequestDto mapCreate(PayrollComponentProjectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentProjectionService.PayrollComponentProjectionCreateRequestDto payrollComponentProjectionCreateRequestDto = new PayrollComponentProjectionService.PayrollComponentProjectionCreateRequestDto();

        payrollComponentProjectionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentProjectionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentProjectionCreateRequestDto.setAdministrativeUnitEmployeeIdentifier( arg0.getAdministrativeUnitEmployeeIdentifier() );
        payrollComponentProjectionCreateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payrollComponentProjectionCreateRequestDto.setPayrollPeriodGroupIdentifier( arg0.getPayrollPeriodGroupIdentifier() );
        payrollComponentProjectionCreateRequestDto.setReferenceAmount( arg0.getReferenceAmount() );
        payrollComponentProjectionCreateRequestDto.setAmount( arg0.getAmount() );

        return payrollComponentProjectionCreateRequestDto;
    }

    @Override
    public PayrollComponentProjectionService.PayrollComponentProjectionUpdateRequestDto mapUpdate(PayrollComponentProjectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentProjectionService.PayrollComponentProjectionUpdateRequestDto payrollComponentProjectionUpdateRequestDto = new PayrollComponentProjectionService.PayrollComponentProjectionUpdateRequestDto();

        payrollComponentProjectionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentProjectionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentProjectionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentProjectionUpdateRequestDto.setAdministrativeUnitEmployeeIdentifier( arg0.getAdministrativeUnitEmployeeIdentifier() );
        payrollComponentProjectionUpdateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payrollComponentProjectionUpdateRequestDto.setPayrollPeriodGroupIdentifier( arg0.getPayrollPeriodGroupIdentifier() );
        payrollComponentProjectionUpdateRequestDto.setReferenceAmount( arg0.getReferenceAmount() );
        payrollComponentProjectionUpdateRequestDto.setAmount( arg0.getAmount() );

        return payrollComponentProjectionUpdateRequestDto;
    }
}
