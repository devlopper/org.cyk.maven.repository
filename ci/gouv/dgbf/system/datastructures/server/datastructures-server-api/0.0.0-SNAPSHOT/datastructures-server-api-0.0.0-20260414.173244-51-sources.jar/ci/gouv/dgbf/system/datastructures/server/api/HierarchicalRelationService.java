package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasChildIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasHierarchyIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasParentIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link HierarchicalRelationDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = HierarchicalRelationService.PATH)
@Tag(name = "Gestion des relations hiérarchiques")
public interface HierarchicalRelationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "relations-hierarchiques";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface HierarchicalRelationSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link HierarchyDto}.
     *
     * @return identifiant de {@link HierarchyDto}
     */
    String getHierarchyIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link HierarchyDto}.
     *
     * @param hierarchyIdentifier identifiant de {@link HierarchyDto}
     */
    void setHierarchyIdentifier(String hierarchyIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du parent.
     *
     * @return identifiant du parent
     */
    String getParentIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du parent.
     *
     * @param parentIdentifier identifiant du parent
     */
    void setParentIdentifier(String parentIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'enfant.
     *
     * @return identifiant de l'enfant
     */
    String getChildIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'enfant.
     *
     * @param childIdentifier identifiant de l'enfant
     */
    void setChildIdentifier(String childIdentifier);

    /**
     * {@link HasHierarchyIdentifierDto#JSON_HIERARCHY_IDENTIFIER}.
     */
    String JSON_HIERARCHY_IDENTIFIER = HasHierarchyIdentifierDto.JSON_HIERARCHY_IDENTIFIER;

    /**
     * {@link HasParentIdentifierDto#JSON_PARENT_IDENTIFIER}.
     */
    String JSON_PARENT_IDENTIFIER = HasParentIdentifierDto.JSON_PARENT_IDENTIFIER;

    /**
     * {@link HasChildIdentifierDto#JSON_CHILD_IDENTIFIER}.
     */
    String JSON_CHILD_IDENTIFIER = HasChildIdentifierDto.JSON_CHILD_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(HierarchicalRelationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class HierarchicalRelationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements HierarchicalRelationSaveRequestDto {

    @JsonbProperty(JSON_HIERARCHY_IDENTIFIER)
    private String hierarchyIdentifier;

    @JsonbProperty(JSON_PARENT_IDENTIFIER)
    private String parentIdentifier;

    @JsonbProperty(JSON_CHILD_IDENTIFIER)
    private String childIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = HierarchicalRelationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class HierarchicalRelationGetManyResponseDto
      extends AbstractGetByPageResponseDto<HierarchicalRelationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<HierarchicalRelationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = HierarchicalRelationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = HierarchicalRelationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(HierarchicalRelationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class HierarchicalRelationUpdateRequestDto extends ByIdentifierRequestDto
      implements HierarchicalRelationSaveRequestDto {

    @JsonbProperty(JSON_HIERARCHY_IDENTIFIER)
    private String hierarchyIdentifier;

    @JsonbProperty(JSON_PARENT_IDENTIFIER)
    private String parentIdentifier;

    @JsonbProperty(JSON_CHILD_IDENTIFIER)
    private String childIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_RELATION_HIERARCHIQUE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link HierarchicalRelationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
