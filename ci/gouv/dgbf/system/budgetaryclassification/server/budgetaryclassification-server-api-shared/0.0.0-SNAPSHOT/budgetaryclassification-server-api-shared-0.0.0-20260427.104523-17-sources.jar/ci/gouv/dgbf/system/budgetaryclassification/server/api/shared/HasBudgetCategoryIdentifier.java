package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de la catégorie de budget.
 *
 * @author arnaud
 */
public interface HasBudgetCategoryIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la catégorie de budget.
   *
   * @return identifiant de la catégorie de budget
   */
  String getBudgetCategoryIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la catégorie de budget.
   *
   * @param identifier identifiant de la catégorie de budget
   */

  void setBudgetCategoryIdentifier(String identifier);
  /**
   * Identifiant java de l'identifiant de la catégorie de budget.
   */

  String FIELD_BUDGET_CATEGORY_IDENTIFIER = "budgetCategoryIdentifier";
}