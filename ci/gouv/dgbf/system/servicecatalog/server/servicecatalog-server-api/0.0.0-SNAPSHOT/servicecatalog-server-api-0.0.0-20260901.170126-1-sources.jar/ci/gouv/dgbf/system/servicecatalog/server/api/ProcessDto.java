package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un processus, composant technique déployé d'un Module (le backend ou
 * l'un de ses frontends).
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcessDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Description du processus.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Nature du processus (Backend, Frontend Web, Frontend Mobile Flutter/Android/iOS, ...) —
   * champ libre, non contraint.
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * URL de base, adresse d'entrée du processus.
   */
  @JsonbProperty(JSON_BASE_URL)
  private String baseUrl;

  /**
   * Indique si le processus est présenté à tous les utilisateurs authentifiés dans le
   * catalogue. Faux par défaut.
   */
  @JsonbProperty(JSON_VISIBLE)
  private Boolean visible;

  /**
   * Identifiant du Module auquel ce processus est obligatoirement rattaché.
   */
  @JsonbProperty(JSON_MODULE_IDENTIFIER)
  private String moduleIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idProcessus";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "processusChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "processus";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "processus";

  /**
   * Identifiant json pour {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json pour {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json pour {@link #baseUrl}.
   */
  public static final String JSON_BASE_URL = "urlDeBase";

  /**
   * Identifiant json pour {@link #visible}.
   */
  public static final String JSON_VISIBLE = "visible";

  /**
   * Identifiant json pour {@link #moduleIdentifier}.
   */
  public static final String JSON_MODULE_IDENTIFIER = "idModule";
}
