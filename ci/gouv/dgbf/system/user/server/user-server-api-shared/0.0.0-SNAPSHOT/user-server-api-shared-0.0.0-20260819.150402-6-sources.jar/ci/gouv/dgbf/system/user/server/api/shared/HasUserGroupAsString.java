package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'utilisateur groupe.
 *
 * @author Christian
 */
public interface HasUserGroupAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'utilisateur
   * groupe.
   *
   * @return identifiant de l'utilisateur groupe
   */
  String getUserGroupAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'utilisateur
   * groupe.
   *
   * @param userGroupAsString identifiant de l'utilisateur groupe
   */
  void setUserGroupAsString(String userGroupAsString);

  /**
   * Identifiant java de représentation en chaine de caractères de l'utilisateur groupe.
   */
  String FIELD_USER_GROUP_AS_STRING = "userGroupAsString";
}
