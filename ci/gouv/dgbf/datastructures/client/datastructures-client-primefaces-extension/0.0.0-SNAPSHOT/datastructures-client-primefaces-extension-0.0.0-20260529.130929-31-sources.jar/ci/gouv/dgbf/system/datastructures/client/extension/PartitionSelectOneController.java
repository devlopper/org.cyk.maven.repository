package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService.PartitionGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PartitionDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionSelectOneController extends
    AbstractSelectOneIdentifiableController<PartitionDto, 
    PartitionGetManyResponseDto, PartitionClient> {

  @Getter
  @Inject
  PartitionClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PartitionSelectOneController() {
    super(PartitionDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
