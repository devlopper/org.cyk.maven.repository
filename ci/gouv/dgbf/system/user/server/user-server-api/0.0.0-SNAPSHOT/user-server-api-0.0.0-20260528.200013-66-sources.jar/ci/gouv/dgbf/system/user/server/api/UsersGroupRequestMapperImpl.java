package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UsersGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-28T20:00:36+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UsersGroupRequestMapperImpl implements UsersGroupRequestMapper {

    @Override
    public UsersGroupService.UsersGroupCreateRequestDto mapCreate(UsersGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UsersGroupService.UsersGroupCreateRequestDto usersGroupCreateRequestDto = new UsersGroupService.UsersGroupCreateRequestDto();

        usersGroupCreateRequestDto.setCode( arg0.getCode() );
        usersGroupCreateRequestDto.setName( arg0.getName() );

        return usersGroupCreateRequestDto;
    }

    @Override
    public UsersGroupService.UsersGroupUpdateRequestDto mapUpdate(UsersGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UsersGroupService.UsersGroupUpdateRequestDto usersGroupUpdateRequestDto = new UsersGroupService.UsersGroupUpdateRequestDto();

        usersGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        usersGroupUpdateRequestDto.setCode( arg0.getCode() );
        usersGroupUpdateRequestDto.setName( arg0.getName() );

        return usersGroupUpdateRequestDto;
    }
}
