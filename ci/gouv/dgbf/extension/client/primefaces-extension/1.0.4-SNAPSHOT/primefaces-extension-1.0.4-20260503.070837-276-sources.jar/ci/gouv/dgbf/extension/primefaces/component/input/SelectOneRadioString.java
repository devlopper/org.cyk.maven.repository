package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur chaine de caractères par des boutons radio.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectOneRadioString extends AbstractSelectOneString {

}
