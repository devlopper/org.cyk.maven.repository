package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de la catégorie de budget.
 *
 * @author Arnaud
 */
public interface HasBudgetCategoryAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères
   * de la catégorie de budget.
   *
   * @return représentation en chaine de caractères de la catégorie de budget
   */
  String getBudgetCategoryAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères
   * de la catégorie de budget.
   *
   * @param asString représentation en chaine de caractères de la catégorie de budget
   */
  void setBudgetCategoryAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de la catégorie de budget.
   */
  String FIELD_BUDGET_CATEGORY_AS_STRING = "budgetCategoryAsString";
}
