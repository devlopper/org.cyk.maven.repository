package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasFirstNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasLastNamesDto;
import ci.gouv.dgbf.extension.core.segregation.HasRegistrationNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fonctionnaire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryDto extends AbstractIdentifiableDto
    implements HasRegistrationNumberDto, HasFirstNameDto, HasLastNamesDto {

  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  @JsonbProperty(JSON_FIRST_NAME)
  private String firstName;

  @JsonbProperty(JSON_LAST_NAMES)
  private String lastNames;

  /**
   * Identifiant json de identifiant de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaire";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
