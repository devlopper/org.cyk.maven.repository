package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasName;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TaskDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = TaskService.PATH)
@Tag(name = "Gestion des tâches")
public interface TaskService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "taches";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TACHE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface TaskSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir le libellé.
     *
     * @return libellé
     */
    String getName();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description description
     */
    void setDescription(String description);


    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner le libellé.
     *
     * @param name libellé
     */
    void setName(String name);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ActivityDto}.
     *
     * @return identifiant de {@link ActivityDto}
     */
    String getActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ActivityDto}.
     *
     * @param activityIdentifier identifiant de {@link ActivityDto}
     */
    void setActivityIdentifier(String activityIdentifier);

    /**
     * Cette méthode permet d'obtenir la date de début.
     *
     * @return date de début
     */
    LocalDateTime getFromDate();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param fromDate date de début
     */
    void setFromDate(LocalDateTime fromDate);

    /**
     * Cette méthode permet d'obtenir la date de fin.
     *
     * @return date de fin
     */
    LocalDateTime getToDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param fromDate date de fin
     */
    void setToDate(LocalDateTime fromDate);

    /**
     * Cette méthode permet d'obtenir la date de création.
     *
     * @return date de création
     */
    LocalDateTime getCreationDate();

    /**
     * Cette méthode permet d'assigner la date de création.
     *
     * @param creationDate date de création
     */
    void setCreationDate(LocalDateTime creationDate);

    /**
     * Identifiant json champ nom.
     */
    String JSON_NAME = AbstractIdentifiableCodableNamableDto.JSON_NAME;


    /**
     * Identifiant json champ description.
     */
    String JSON_DESCRIPTION = TaskDto.JSON_DESCRIPTION;

    /**
     * Identifiant json champ identifiant de {@link ActivityDto}.
     */
    String JSON_ACTIVITY_IDENTIFIER = TaskDto.JSON_ACTIVITY_IDENTIFIER;

    /**
     * Identifiant json champ date de début.
     */
    String JSON_FROM_DATE = TaskDto.JSON_FROM_DATE;

    /**
     * Identifiant json champ date de creation.
     */
    String JSON_CREATION_DATE = TaskDto.JSON_PROCESSING_DATE;

    /**
     * Identifiant json champ date de fin.
     */
    String JSON_TO_DATE = TaskDto.JSON_TO_DATE;

    /**
     * Identifiant json champ identifiant de l'unité administrative d'exécution.
     */
    String JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER =
        TaskDto.JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER;
  }

  /**
   * Cette méthode permet de créer {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une tâche",
      description = "Ce service permet de créer une tâche")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TaskCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TaskCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements HasName, TaskSaveRequestDto {

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_CREATION_DATE)
    private LocalDateTime creationDate;

    @JsonbProperty(JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String executionAdministrativeUnitIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TACHE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des dossiers")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TaskGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class TaskGetManyResponseDto extends AbstractGetByPageResponseDto<TaskDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TaskDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TACHE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une tâche")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TaskDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TACHE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une tâche")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TaskDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TACHE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une tâche")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TaskUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TaskUpdateRequestDto extends ByIdentifierRequestDto
      implements HasName, TaskSaveRequestDto {
    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_CREATION_DATE)
    private LocalDateTime creationDate;

    @JsonbProperty(JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String executionAdministrativeUnitIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TACHE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TaskDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une tâche")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);


  /**
   * Identifiant du service de gérabilité des fichiers d'une tâche.
   */
  String UPDATE_FILE_MANAGEABLE_WHEN_TERMINATED_IDENTIFIER =
      "MISE_A_JOUR_GERABILITE_FICHIER_QUAND_TERMINEE_TACHE";

  /**
   * Chemin du service de gérabilité des fichiers d'une tâche.
   */
  String UPDATE_FILE_MANAGEABLE_WHEN_TERMINATED_PATH = "gerabilite-fichiers-quand-terminee";

  /**
   * Cette méthode permet de mettre à jour la gérabilité des fichiers d'une tâche {@link TaskDto}.
   *
   * @author Tito A. Coulibaly
   * @param request requête
   * @return réponse
   */

  @Path(UPDATE_FILE_MANAGEABLE_WHEN_TERMINATED_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_FILE_MANAGEABLE_WHEN_TERMINATED_IDENTIFIER,
      description = "Ce service permet de mettre à jour la gérabilité des fichiers d'une tâche")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateFileManageableWhenTerminated(
      TaskUpdateFileManageableWhenTerminatedRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de la gérabilité des fichiers d'une tâche.
   *
   * @author Tito A. Coulibaly
   */
  @Getter
  @Setter
  class TaskUpdateFileManageableWhenTerminatedRequestDto extends ByIdentifierRequestDto {
    @JsonbProperty(TaskDto.JSON_FILE_MANAGEABLE_WHEN_TERMINATED)
    private Boolean fileManageableWhenTerminated;
  }

  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_TACHE";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER,
      description = "Ce service permet d'obtenir un graphique")
  Response getChart(GetChartRequestDto request);
}
