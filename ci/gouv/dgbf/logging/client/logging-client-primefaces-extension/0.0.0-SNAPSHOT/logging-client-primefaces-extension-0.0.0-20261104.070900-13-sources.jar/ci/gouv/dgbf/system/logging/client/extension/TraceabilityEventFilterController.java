package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityActionType;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventCategory;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import lombok.Getter;

/** Contrôleur des filtres du journal transverse. */
@Dependent
public class TraceabilityEventFilterController
    extends AbstractFilterController<TraceabilityEventFilter> {

  @Inject @Getter InputTextController auditSessionInputTextController;
  @Inject @Getter InputTextController categoryInputTextController;
  @Inject @Getter InputTextController actionTypeInputTextController;
  @Inject @Getter InputTextController processIdentifierInputTextController;
  @Inject @Getter InputTextController messageSummaryInputTextController;
  @Inject @Getter InputTextController dateFromInputTextController;
  @Inject @Getter InputTextController dateToInputTextController;

  private static final DateTimeFormatter DATE_TIME_FORMATTER =
      DateTimeFormatter.ISO_LOCAL_DATE_TIME;

  public TraceabilityEventFilterController() {
    super(TraceabilityEventFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    auditSessionInputTextController.setOutputLableValue("Session d'audit");
    auditSessionInputTextController.getInputText().addValueConsumer(
        value -> filter.setAuditSession(value));
    categoryInputTextController.setOutputLableValue("Catégorie (code)");
    categoryInputTextController.getInputText().addValueConsumer(value -> filter.setCategory(
        value == null || value.isBlank() ? null : TraceabilityEventCategory.getByCode(value)));
    actionTypeInputTextController.setOutputLableValue("Action (code)");
    actionTypeInputTextController.getInputText().addValueConsumer(value -> filter.setActionType(
        value == null || value.isBlank() ? null : TraceabilityActionType.getByCode(value)));
    processIdentifierInputTextController.setOutputLableValue("Processus");
    processIdentifierInputTextController.getInputText().addValueConsumer(
        value -> filter.setProcessIdentifier(value));
    messageSummaryInputTextController.setOutputLableValue("Résumé");
    messageSummaryInputTextController.getInputText().addValueConsumer(
        value -> filter.setMessageSummary(value));
    dateFromInputTextController.setOutputLableValue("Date début (ISO)");
    dateFromInputTextController.getInputText().addValueConsumer(
        value -> filter.setDateFrom(parseDateTime(value)));
    dateToInputTextController.setOutputLableValue("Date fin exclue (ISO)");
    dateToInputTextController.getInputText().addValueConsumer(
        value -> filter.setDateTo(parseDateTime(value)));
  }

  private LocalDateTime parseDateTime(String value) {
    if (value == null || value.isBlank()) {
      return null;
    }
    try {
      return LocalDateTime.parse(value, DATE_TIME_FORMATTER);
    } catch (DateTimeParseException exception) {
      return null;
    }
  }
}
