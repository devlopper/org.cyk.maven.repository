package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollTypeDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollTypeDto, PayrollTypeGetManyResponseDto, PayrollTypeClient> {

  @Getter
  @Inject
  PayrollTypeClient client;

  protected PayrollTypeSelectOneController() {
    super(PayrollTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
