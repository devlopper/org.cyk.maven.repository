package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveAcceptanceRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveAcceptanceResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveCancellationRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveCancellationResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveRefusalRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveRefusalResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchiveService.FileGroupArchiveTerminateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service {@link FileGroupArchiveService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileGroupArchiveClient extends AbstractClient<FileGroupArchiveService>
    implements GetMany<FileGroupArchiveGetManyResponseDto>, GetByIdentifier<FileGroupArchiveDto> {

  @Override
  public FileGroupArchiveClient service(FileGroupArchiveService service) {
    return (FileGroupArchiveClient) super.service(service);
  }

  /**
   * {@link FileGroupArchiveService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FileGroupArchiveCreateRequestDto request) {
    return new CreateExecutor(FileGroupArchiveService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FileGroupArchiveService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchiveGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FileGroupArchiveGetManyResponseDto>(
        FileGroupArchiveGetManyResponseDto.class,
        FileGroupArchiveService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FileGroupArchiveService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupArchiveGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FileGroupArchiveService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchiveDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FileGroupArchiveDto>(FileGroupArchiveDto.class,
        FileGroupArchiveService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link FileGroupArchiveService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupArchiveDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FileGroupArchiveService#getByIdentifier}.
   *
   * @param request requête
   * @return {@link FileGroupArchiveDto}
   */
  public FileGroupArchiveDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FileGroupArchiveDto>(FileGroupArchiveDto.class,
        FileGroupArchiveService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FileGroupArchiveService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return {@link FileGroupArchiveDto}
   */
  @Override
  public FileGroupArchiveDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FileGroupArchiveService#terminate}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto terminate(FileGroupArchiveTerminateRequestDto request) {
    return new IdentifiableExecutor(FileGroupArchiveService.TERMINATE_IDENTIFIER)
        .execute(() -> service().terminate(request));
  }

  /**
   * {@link FileGroupArchiveService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchiveAcceptanceResponseDto accept(
      FileGroupArchiveAcceptanceRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchiveAcceptanceResponseDto.class,
        FileGroupArchiveService.ACCEPT_IDENTIFIER).execute(() -> service().accept(request));
  }

  /**
   * {@link FileGroupArchiveService#refuse}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchiveRefusalResponseDto refuse(FileGroupArchiveRefusalRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchiveRefusalResponseDto.class,
        FileGroupArchiveService.REFUSE_IDENTIFIER).execute(() -> service().refuse(request));
  }

  /**
   * {@link FileGroupArchiveService#cancel}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchiveCancellationResponseDto cancel(
      FileGroupArchiveCancellationRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchiveCancellationResponseDto.class,
        FileGroupArchiveService.CANCEL_IDENTIFIER).execute(() -> service().cancel(request));
  }

  /** Obtient le nombre de concepts. */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(FileGroupArchiveService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }
}
