package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipConstantService.PayslipConstantCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipConstantService.PayslipConstantUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipConstantDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipConstantDto}.

    @author Christian
               """)
public interface PayslipConstantRequestMapper extends RequestMapper<PayslipConstantDto,
    PayslipConstantCreateRequestDto, PayslipConstantUpdateRequestDto> {

}
