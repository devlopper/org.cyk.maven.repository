package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente un filtre basé sur la session d'audit (RG_LOG_TRA_07).
 *
 * @author Christian
 */
public interface AuditSessionFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir la session d'audit.
   *
   * @param filter {@link FilterDto}
   * @return session d'audit
   */
  public static String get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner la session d'audit.
   *
   * @param filter {@link FilterDto}
   * @param auditSession session d'audit
   */
  public static void set(FilterDto filter, String auditSession) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsString(auditSession));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   */
  String JSON_KEY = "auditSession";

}

