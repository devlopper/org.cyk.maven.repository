package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de l'unité de spécialisation du budget.
 *
 * @author Arnaud
 */
public interface HasBudgetSpecializationUnitAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'unité
   * de spécialisation du budget.
   *
   * @return représentation en chaine de caractères de l'unité de spécialisation du budget
   */
  String getBudgetSpecializationUnitAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'unité
   * de spécialisation du budget.
   *
   * @param asString représentation en chaine de caractères de l'unité de spécialisation du budget
   */
  void setBudgetSpecializationUnitAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'unité
   * de spécialisation du budget.
   */
  String FIELD_BUDGET_SPECIALIZATION_UNIT_AS_STRING = "unitSpecializationBudgetAsString";
}
