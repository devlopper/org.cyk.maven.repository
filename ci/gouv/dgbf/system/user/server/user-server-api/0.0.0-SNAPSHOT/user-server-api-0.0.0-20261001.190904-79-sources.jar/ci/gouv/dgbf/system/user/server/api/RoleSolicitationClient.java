package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationAcceptRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationAcceptResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationCancelRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationCancelResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationRefuseRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationRefuseResponseDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link RoleSolicitationDto}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
public class RoleSolicitationClient extends AbstractClient<RoleSolicitationService>
    implements GetByIdentifier<RoleSolicitationDto>, GetMany<RoleSolicitationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link RoleSolicitationService}
   * @return client {@link RoleSolicitationClient}
   */
  @Override
  public RoleSolicitationClient service(RoleSolicitationService service) {
    return (RoleSolicitationClient) super.service(service);
  }

  /**
   * {@link RoleSolicitationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(RoleSolicitationCreateRequestDto request) {
    return new CreateExecutor(RoleSolicitationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link RoleSolicitationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleSolicitationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RoleSolicitationGetManyResponseDto>(
        RoleSolicitationGetManyResponseDto.class,
        RoleSolicitationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link RoleSolicitationService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RoleSolicitationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RoleSolicitationService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RoleSolicitationDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    return new GetOneExecutor<RoleSolicitationDto>(RoleSolicitationDto.class,
        RoleSolicitationService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link RoleSolicitationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RoleSolicitationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    return new GetOneExecutor<RoleSolicitationDto>(RoleSolicitationDto.class,
        RoleSolicitationService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link RoleSolicitationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(RoleSolicitationUpdateRequestDto request) {
    return new IdentifiableExecutor(RoleSolicitationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link RoleSolicitationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(RoleSolicitationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link RoleSolicitationService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleSolicitationAcceptResponseDto accept(RoleSolicitationAcceptRequestDto request) {
    return new GetOneExecutor<>(RoleSolicitationAcceptResponseDto.class,
        RoleSolicitationService.ACCEPT_IDENTIFIER).execute(() -> service().accept(request));
  }

  /**
   * {@link RoleSolicitationService#refuse}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleSolicitationRefuseResponseDto refuse(RoleSolicitationRefuseRequestDto request) {
    return new GetOneExecutor<>(RoleSolicitationRefuseResponseDto.class,
        RoleSolicitationService.REFUSE_IDENTIFIER).execute(() -> service().refuse(request));
  }

  /**
   * {@link RoleSolicitationService#cancel}.
   *
   * @param request requête
   * @return réponse
   */
  public RoleSolicitationCancelResponseDto cancel(RoleSolicitationCancelRequestDto request) {
    return new GetOneExecutor<>(RoleSolicitationCancelResponseDto.class,
        RoleSolicitationService.CANCEL_IDENTIFIER).execute(() -> service().cancel(request));
  }
}
