package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.mailer.server.api.TemplateService.TemplateCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.TemplateService.TemplateUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TemplateDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link TemplateDto}.

    @author Christian
               """)
public interface TemplateRequestMapper
    extends RequestMapper<TemplateDto, TemplateCreateRequestDto,
        TemplateUpdateRequestDto> {

}
