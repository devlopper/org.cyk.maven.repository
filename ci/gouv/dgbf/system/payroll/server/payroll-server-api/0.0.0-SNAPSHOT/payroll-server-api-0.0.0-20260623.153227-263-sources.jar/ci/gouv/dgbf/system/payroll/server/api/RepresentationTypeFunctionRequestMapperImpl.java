package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RepresentationTypeFunctionDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T15:33:03+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RepresentationTypeFunctionRequestMapperImpl implements RepresentationTypeFunctionRequestMapper {

    @Override
    public RepresentationTypeFunctionService.RepresentationTypeFunctionCreateRequestDto mapCreate(RepresentationTypeFunctionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationTypeFunctionService.RepresentationTypeFunctionCreateRequestDto representationTypeFunctionCreateRequestDto = new RepresentationTypeFunctionService.RepresentationTypeFunctionCreateRequestDto();

        representationTypeFunctionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationTypeFunctionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        representationTypeFunctionCreateRequestDto.setTypeFunctionIdentifier( arg0.getTypeFunctionIdentifier() );
        representationTypeFunctionCreateRequestDto.setRepresentationIdentifier( arg0.getRepresentationIdentifier() );

        return representationTypeFunctionCreateRequestDto;
    }

    @Override
    public RepresentationTypeFunctionService.RepresentationTypeFunctionUpdateRequestDto mapUpdate(RepresentationTypeFunctionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationTypeFunctionService.RepresentationTypeFunctionUpdateRequestDto representationTypeFunctionUpdateRequestDto = new RepresentationTypeFunctionService.RepresentationTypeFunctionUpdateRequestDto();

        representationTypeFunctionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationTypeFunctionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        representationTypeFunctionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        representationTypeFunctionUpdateRequestDto.setTypeFunctionIdentifier( arg0.getTypeFunctionIdentifier() );
        representationTypeFunctionUpdateRequestDto.setRepresentationIdentifier( arg0.getRepresentationIdentifier() );

        return representationTypeFunctionUpdateRequestDto;
    }
}
