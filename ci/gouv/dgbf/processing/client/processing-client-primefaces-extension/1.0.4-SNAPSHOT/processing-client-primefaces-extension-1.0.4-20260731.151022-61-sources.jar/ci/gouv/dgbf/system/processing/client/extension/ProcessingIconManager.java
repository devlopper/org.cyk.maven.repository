package ci.gouv.dgbf.system.processing.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class ProcessingIconManager {

  String created;
  String started;
  String stopped;
  String canceled;
  String terminated;

  String late;
  String startWaiting;
  String running;
  String done;

  String situation;
  String all;

  /**
   * Cette méthode permet d'instancier.
   */
  public ProcessingIconManager() {
    situation = "pi pi-cloud";
    created = "pi pi-pencil";
    started = "pi pi-car";
    stopped = "pi pi-stop";
    canceled = "pi pi-ban";
    terminated = "pi pi-thumbs-up";

    late = "pi pi-question-circle";
    startWaiting = "pi pi-briefcase";
    running = "pi pi-money-bill";
    done = "pi pi-check";
    
    all = "pi pi-list";
  }
}
