package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.CommitmentService.CommitmentCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.CommitmentService.CommitmentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link CommitmentDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link CommitmentDto}.
    
    @author Desysoft
    """)
public interface CommitmentRequestMapper extends RequestMapper<CommitmentDto,
    CommitmentCreateRequestDto, CommitmentUpdateRequestDto> {

}
