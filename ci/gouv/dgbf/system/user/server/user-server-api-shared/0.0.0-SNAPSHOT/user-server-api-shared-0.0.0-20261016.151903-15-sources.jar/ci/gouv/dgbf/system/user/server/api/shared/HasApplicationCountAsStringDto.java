package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'applications sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasApplicationCountAsStringDto extends HasApplicationCountAsString {

  /**
   * Identifiant json du nombre d'applications sous forme de chaîne.
   */
  String JSON_APPLICATION_COUNT_AS_STRING = "nombreApplicationsChaine";
}
