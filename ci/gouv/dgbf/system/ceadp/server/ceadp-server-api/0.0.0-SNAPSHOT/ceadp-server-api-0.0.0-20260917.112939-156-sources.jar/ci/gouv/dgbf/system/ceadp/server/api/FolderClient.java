package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ceadp.server.api.FolderService.FolderCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderService.FolderGetManyResponseDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderService.FolderUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FolderService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FolderClient extends AbstractClient<FolderService>
    implements GetByIdentifier<FolderDto>, GetMany<FolderGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetChart<GetChartResponseDto> {

  @Override
  public FolderClient service(FolderService service) {
    return (FolderClient) super.service(service);
  }

  /**
   * {@link FolderService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FolderCreateRequestDto request) {
    return new CreateExecutor(FolderService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FolderService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FolderGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FolderGetManyResponseDto>(FolderGetManyResponseDto.class,
        FolderService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FolderService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FolderGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FolderService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FolderDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FolderDto>(FolderDto.class, FolderService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link FolderService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FolderDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FolderService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FolderDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FolderDto>(FolderDto.class,
        FolderService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FolderService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FolderDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FolderService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FolderUpdateRequestDto request) {
    return new IdentifiableExecutor(FolderService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FolderService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FolderService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FolderService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
  
  /**
   * {@link FolderService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        FolderService.GET_CHART_IDENTIFIER).execute(() -> service().getChart(request));
  }
  
  /**
   * {@link FolderService#getChart}.
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditWho, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getChart(request);
  }

  /**
   * {@link FolderService#start}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto start(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(FolderService.START_IDENTIFIER)
        .execute(() -> service().start(request));
  }

  /**
   * {@link FolderService#start}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto start(String identifier, String auditWho,
                                       String auditSession) {
    ByIdentifierRequestDto request = new ByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return start(request);
  }

  /**
   * {@link FolderService#stop}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto stop(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(FolderService.STOP_IDENTIFIER)
        .execute(() -> service().stop(request));
  }

  /**
   * {@link ActivityService#stop}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto stop(String identifier, String auditWho,
                                      String auditSession) {
    ByIdentifierRequestDto request = new ByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return stop(request);
  }
}
