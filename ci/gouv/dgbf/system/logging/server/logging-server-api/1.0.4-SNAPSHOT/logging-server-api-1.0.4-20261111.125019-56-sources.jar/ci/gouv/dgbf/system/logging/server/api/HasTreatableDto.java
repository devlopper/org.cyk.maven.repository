package ci.gouv.dgbf.system.logging.server.api;

/**
 * Cette interface représente une classe DTO avec une notion d'éligibilité au traitement.
 */
public interface HasTreatableDto extends HasTreatable {

  /**
   * Identifiant JSON de l'éligibilité au traitement.
   */
  String JSON_TREATABLE = "peutEtreTraite";
}

