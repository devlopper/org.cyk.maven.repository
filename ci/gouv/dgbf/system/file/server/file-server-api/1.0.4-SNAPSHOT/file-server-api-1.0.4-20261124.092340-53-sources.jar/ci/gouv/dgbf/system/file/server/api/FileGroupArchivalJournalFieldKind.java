package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Champs déclaratifs corrigibles du journal d'Archivage d'un fichier de groupe.
 */
@Getter
public enum FileGroupArchivalJournalFieldKind {

  /** Motif de la demande (Archivage ou Retrait). */
  SOLICITATION("DEMANDE", "Motif de la demande"),
  /** Motif de refus d'une demande. */
  REFUSAL("REFUS", "Motif de refus"),
  /** Motif d'annulation d'une demande. */
  CANCELLATION("ANNULATION", "Motif d'annulation"),
  /** Motif de début d'une Archive créée par voie directe. */
  DIRECT_ARCHIVING("ARCHIVAGE_DIRECT", "Motif de début (voie directe)"),
  /** Motif de fin d'une Archive terminée par voie directe. */
  DIRECT_UNARCHIVING("DESARCHIVAGE_DIRECT", "Motif de fin (voie directe)");

  private final String code;
  private final String name;

  private FileGroupArchivalJournalFieldKind(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Obtient le champ correspondant au code stocké.
   *
   * @param code code du champ
   * @return champ correspondant
   */
  public static FileGroupArchivalJournalFieldKind getByCode(String code) {
    return Stream.of(values()).filter(kind -> kind.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
