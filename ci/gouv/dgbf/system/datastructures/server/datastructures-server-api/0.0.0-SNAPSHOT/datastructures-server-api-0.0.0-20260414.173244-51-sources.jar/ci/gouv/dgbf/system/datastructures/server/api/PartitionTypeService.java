package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link HierarchyDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = PartitionTypeService.PATH)
@Tag(name = "Gestion des types de partition")
public interface PartitionTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "types-partitions";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface PartitionTypeSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
     *
     * @return identifiant de {@link DomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
     *
     * @param domainIdentifier identifiant de {@link DomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ValueSourceDto}.
     *
     * @return l'identifiant de {@link ValueSourceDto}
     */
    String getValueSourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ValueSourceDto}.
     *
     * @param valueSourceIdentifier l'identifiant de {@link ValueSourceDto}
     */
    void setValueSourceIdentifier(String valueSourceIdentifier);

    /**
     * {PartitionTypeDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = PartitionTypeDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * {PartitionTypeDto#JSON_VALUE_SOURCE_IDENTIFIER}.
     */
    String JSON_VALUE_SOURCE_IDENTIFIER = PartitionTypeDto.JSON_VALUE_SOURCE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TYPE_PARTITION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PartitionTypeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class PartitionTypeCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PartitionTypeSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_VALUE_SOURCE_IDENTIFIER)
    private String valueSourceIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_PARTITION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PartitionTypeGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class PartitionTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<PartitionTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PartitionTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TYPE_PARTITION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PartitionTypeDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TYPE_PARTITION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PartitionTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TYPE_PARTITION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PartitionTypeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class PartitionTypeUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PartitionTypeSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_VALUE_SOURCE_IDENTIFIER)
    private String valueSourceIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TYPE_PARTITION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PartitionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
