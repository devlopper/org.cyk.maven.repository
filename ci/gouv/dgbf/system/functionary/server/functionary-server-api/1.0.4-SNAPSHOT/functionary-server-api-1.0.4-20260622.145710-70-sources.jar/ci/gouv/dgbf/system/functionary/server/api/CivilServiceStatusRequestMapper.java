package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link CivilServiceStatusDto}.
 *
 * @author arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link CivilServiceStatusDto}.

    @author Arnaud
               """)
public interface CivilServiceStatusRequestMapper
    extends RequestMapper<CivilServiceStatusDto, CivilServiceStatusCreateRequestDto, 
                          CivilServiceStatusUpdateRequestDto> {

}
