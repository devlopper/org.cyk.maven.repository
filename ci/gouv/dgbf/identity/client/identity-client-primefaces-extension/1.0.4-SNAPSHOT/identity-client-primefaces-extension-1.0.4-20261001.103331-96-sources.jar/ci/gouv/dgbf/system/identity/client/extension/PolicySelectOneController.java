package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.PolicyClient;
import ci.gouv.dgbf.system.identity.server.api.PolicyDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PolicyDto}, utilisé pour choisir
 * la politique d'une version lors d'une création depuis la liste globale (toutes politiques
 * confondues).
 *
 * @author Desysoft
 *
 */
@Dependent
public class PolicySelectOneController extends AbstractSelectOneIdentifiableController<
    PolicyDto, PolicyGetManyResponseDto, PolicyClient> {

  @Getter
  @Inject
  PolicyClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PolicySelectOneController() {
    super(PolicyDto.class, SelectItemLabelStrategy.NAME);
  }
}
