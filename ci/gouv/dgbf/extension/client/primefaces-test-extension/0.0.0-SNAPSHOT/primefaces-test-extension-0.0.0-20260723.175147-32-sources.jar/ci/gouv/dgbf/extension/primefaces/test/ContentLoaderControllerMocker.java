package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.ContentLoader;
import ci.gouv.dgbf.extension.primefaces.ContentLoaderController;
import ci.gouv.dgbf.extension.primefaces.Text;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link ContentLoaderController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class ContentLoaderControllerMocker {

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link ContentLoaderController}
   */
  public ContentLoaderController mock() {
    ContentLoaderController controller = Mockito.mock(ContentLoaderController.class);
    ContentLoader loader = new ContentLoader();
    Mockito.when(controller.loader()).thenReturn(loader);
    Text text = new Text();
    Mockito.when(controller.getLoadingText()).thenReturn(text);
    text = new Text();
    Mockito.when(controller.getLoadedText()).thenReturn(text);
    return controller;
  }

}
