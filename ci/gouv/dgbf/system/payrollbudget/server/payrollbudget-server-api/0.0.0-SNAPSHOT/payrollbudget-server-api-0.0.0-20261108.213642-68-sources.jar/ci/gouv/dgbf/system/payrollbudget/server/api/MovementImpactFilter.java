package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des impacts d'un mouvement.
 *
 * <p>Le mouvement est le critère de loin le plus fréquent : l'écran de traitement ouvre un
 * dossier, puis demande « que coûte cette mesure, poste par poste ? ». Le poste de paie sert la
 * question inverse — « sur quels agents ce poste bouge-t-il ? » — que la consolidation pose une
 * fois le dossier instruit.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementImpactFilter extends AbstractIdentifiableFilter {

  /**
   * Mouvement dont on veut les impacts.
   */
  String movementIdentifier;

  /**
   * Poste de paie dont on veut les impacts.
   */
  String payrollComponentIdentifier;

  public MovementImpactFilter() {
    super();
  }

  public MovementImpactFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setMovementIdentifier(read(filter, MovementImpactDto.JSON_MOVEMENT_IDENTIFIER));
    setPayrollComponentIdentifier(
        read(filter, MovementImpactDto.JSON_PAYROLL_COMPONENT_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, MovementImpactDto.JSON_MOVEMENT_IDENTIFIER, getMovementIdentifier());
    write(filter, MovementImpactDto.JSON_PAYROLL_COMPONENT_IDENTIFIER,
        getPayrollComponentIdentifier());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
