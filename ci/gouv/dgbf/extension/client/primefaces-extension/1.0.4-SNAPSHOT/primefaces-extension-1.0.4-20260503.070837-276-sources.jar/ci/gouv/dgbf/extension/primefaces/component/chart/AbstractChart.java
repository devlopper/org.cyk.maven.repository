package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.ColorPalette;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartDataSet;
import org.primefaces.model.charts.ChartOptions;
import org.primefaces.model.charts.optionconfig.title.Title;

/**
 * Cette classe représente la base de graphique.
 *
 * @author Christian
 *
 * @param <T> Type de modèle
 */
public abstract class AbstractChart<T> extends AbstractWidget {

  @Setter
  @Getter
  protected T model;

  /**
   * Cette classe représentente la base de constructeur de modèle.
   *
   * @author Christian
   *
   * @param <P> Type de modèle
   * @param <O> Type d'options
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  protected abstract static class AbstractModelBuilder<M, O extends ChartOptions, P> {

    ChartDto chart;
    ColorPalette colorPalette;
    Consumer<O> optionsConsumer;

    public M build() {
      Core.doThrowIfNull(IllegalArgumentException.class, "graphique requis", chart);
      ChartData chartData = new ChartData();
      chartData.setLabels(new ArrayList<>(chart.getKeys()));

      Collection<ChartDataSet> charDataSets = getChartDataSets(chart.filterDataSets());

      charDataSets.forEach(chartData::addChartDataSet);

      return consume(chartData);
    }

    Collection<ChartDataSet> getChartDataSets(Set<ChartDataSetDto> dtos) {
      AtomicInteger dtoIndex = new AtomicInteger();
      int dtosCount = dtos.size();
      return dtos.stream().map(dto -> {
        ChartDataSet chartDataSet = instantiateCharDataSet(dto, dtosCount, dtoIndex);
        dtoIndex.incrementAndGet();
        return chartDataSet;
      }).toList();
    }

    abstract ChartDataSet instantiateCharDataSet(ChartDataSetDto dto, int dtosCount,
        AtomicInteger dtoIndex);

    public M consume(ChartData chartData) {
      M model = instantateModel();
      processModel(model, chartData);

      O options = instantateOptions();
      configureOptions(options, chart.getName());
      processOptions(model, chartData, options);
      return model;
    }

    abstract M instantateModel();

    abstract void processModel(M model, ChartData chartData);

    abstract O instantateOptions();

    abstract void processOptions(M model, ChartData chartData, O options);

    void configureOptions(ChartOptions options, String titleText) {
      options.setResponsive(true);
      options.setMaintainAspectRatio(false);
      Title title = new Title();
      title.setDisplay(true);
      title.setText(titleText);
      options.setTitle(title);
    }
  }

  /**
   * Cette classe représentente la base de constructeur.
   *
   * @author Christian
   *
   * @param <M> Type de modèle
   * @param <O> Type d'options
   * @param <B> type de constructeur de modèle
   * @param <T> Type de graphique
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public abstract static class AbstractBuilder<M, O extends ChartOptions,
      B extends AbstractModelBuilder<M, O, T>, T extends AbstractChart<M>>
      extends AbstractWidgetBuilder<T> {

    B modelBuilder;

    @Override
    protected void validate() {
      super.validate();
      Core.doThrowIfNull(IllegalArgumentException.class, "constructeur de modèle requis",
          modelBuilder);
    }
        
    @Override
    protected void processWidget(T chart) {
      super.processWidget(chart);
      chart.model = modelBuilder.build();
    }
  }
}
