package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et
* {@link PayrollFunctionaryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T15:06:37+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollFunctionaryRequestMapperImpl implements PayrollFunctionaryRequestMapper {

    @Override
    public PayrollFunctionaryService.PayrollFunctionaryCreateRequestDto mapCreate(PayrollFunctionaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollFunctionaryService.PayrollFunctionaryCreateRequestDto payrollFunctionaryCreateRequestDto = new PayrollFunctionaryService.PayrollFunctionaryCreateRequestDto();

        payrollFunctionaryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollFunctionaryCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollFunctionaryCreateRequestDto.setFunctionaryIdentifier( arg0.getFunctionaryIdentifier() );

        return payrollFunctionaryCreateRequestDto;
    }

    @Override
    public PayrollFunctionaryService.PayrollFunctionaryUpdateRequestDto mapUpdate(PayrollFunctionaryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollFunctionaryService.PayrollFunctionaryUpdateRequestDto payrollFunctionaryUpdateRequestDto = new PayrollFunctionaryService.PayrollFunctionaryUpdateRequestDto();

        payrollFunctionaryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollFunctionaryUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollFunctionaryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollFunctionaryUpdateRequestDto.setFunctionaryIdentifier( arg0.getFunctionaryIdentifier() );

        return payrollFunctionaryUpdateRequestDto;
    }
}
