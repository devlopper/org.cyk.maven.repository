package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevelCode;

/**
 * Cette interface représente une classe avec une notion {@link LogLevelCode}.
 *
 * @author Christian
 */
public interface HasLevelCodeDto extends HasLevelCode {
  
  /**
   * Identifiant json de {@link LogLevelCode}.
   */
  String JSON_LEVEL_CODE = "codeNiveau";
}
