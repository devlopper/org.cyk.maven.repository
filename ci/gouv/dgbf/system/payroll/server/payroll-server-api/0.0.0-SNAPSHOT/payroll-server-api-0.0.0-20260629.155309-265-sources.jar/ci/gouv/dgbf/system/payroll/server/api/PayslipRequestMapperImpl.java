package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipRequestMapperImpl implements PayslipRequestMapper {

    @Override
    public PayslipService.PayslipCreateRequestDto mapCreate(PayslipDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipService.PayslipCreateRequestDto payslipCreateRequestDto = new PayslipService.PayslipCreateRequestDto();

        payslipCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipCreateRequestDto.setCode( arg0.getCode() );
        payslipCreateRequestDto.setName( arg0.getName() );
        payslipCreateRequestDto.setPayrollIdentifier( arg0.getPayrollIdentifier() );
        payslipCreateRequestDto.setRemunerableIdentifier( arg0.getRemunerableIdentifier() );
        payslipCreateRequestDto.setIsComputeAmounts( arg0.getIsComputeAmounts() );

        return payslipCreateRequestDto;
    }

    @Override
    public PayslipService.PayslipUpdateRequestDto mapUpdate(PayslipDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipService.PayslipUpdateRequestDto payslipUpdateRequestDto = new PayslipService.PayslipUpdateRequestDto();

        payslipUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipUpdateRequestDto.setPayrollIdentifier( arg0.getPayrollIdentifier() );
        payslipUpdateRequestDto.setRemunerableIdentifier( arg0.getRemunerableIdentifier() );

        return payslipUpdateRequestDto;
    }
}
