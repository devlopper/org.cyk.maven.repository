package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link FunctionaryUnitSectionDto}.
 *
 * @author akm
 *
 */
@Path(value = FunctionaryUnitSectionService.PATH)
@Tag(name = "Gestion des unités de sections des fonctionnaires")
public interface FunctionaryUnitSectionService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "fonctionnaires-unites-sections";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface FunctionaryUnitSectionSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionaryDto}.
     *
     * @return identifiant {@link FunctionaryDto}
     */
    String getFunctionaryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionaryDto}.
     *
     * @param identifier identifiant {@link FunctionaryDto}
     */
    void setFunctionaryIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'unité de section.
     *
     * @return identifiant de l'unité de section
     */
    String getUnitSectionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'unité de section.
     *
     * @param identifier identifiant de l'unité de section
     */
    void setUnitSectionIdentifier(String identifier);

    /**
     * {@link FunctionaryUnitSectionDto#JSON_FUNCTIONARY_IDENTIFIER}.
     */
    public static final String JSON_FUNCTIONARY_IDENTIFIER =
        FunctionaryUnitSectionDto.JSON_FUNCTIONARY_IDENTIFIER;

    /**
     * {@link FunctionaryUnitSectionDto#JSON_UNIT_SECTION_IDENTIFIER}.
     */
    public static final String JSON_UNIT_SECTION_IDENTIFIER =
        FunctionaryUnitSectionDto.JSON_UNIT_SECTION_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FunctionaryUnitSectionCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FunctionaryUnitSectionCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements FunctionaryUnitSectionSaveRequestDto {
    /**
     * Identifiant de {@link FunctionaryDto}.
     */
    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    String functionaryIdentifier;
    /**
     * Identifiant de l'unité de section.
     */
    @JsonbProperty(JSON_UNIT_SECTION_IDENTIFIER)
    String unitSectionIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = FunctionaryUnitSectionGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class FunctionaryUnitSectionGetManyResponseDto
      extends AbstractGetByPageResponseDto<FunctionaryUnitSectionDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FunctionaryUnitSectionDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FunctionaryUnitSectionDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FunctionaryUnitSectionDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FunctionaryUnitSectionUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FunctionaryUnitSectionUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements FunctionaryUnitSectionSaveRequestDto {
    /**
     * Identifiant de {@link FunctionaryDto}.
     */
    @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
    String functionaryIdentifier;
    /**
     * Identifiant de l'unité de section.
     */
    @JsonbProperty(JSON_UNIT_SECTION_IDENTIFIER)
    String unitSectionIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FONCTIONNAIRE_UNITE_SECTION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FunctionaryUnitSectionDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
