package ci.gouv.dgbf.system.report.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ReportGroupsDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T13:26:17+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ReportsGroupRequestMapperImpl implements ReportsGroupRequestMapper {

    @Override
    public ReportsGroupService.ReportsGroupCreateRequestDto mapCreate(ReportsGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportsGroupService.ReportsGroupCreateRequestDto reportsGroupCreateRequestDto = new ReportsGroupService.ReportsGroupCreateRequestDto();

        reportsGroupCreateRequestDto.setCode( arg0.getCode() );
        reportsGroupCreateRequestDto.setName( arg0.getName() );

        return reportsGroupCreateRequestDto;
    }

    @Override
    public ReportsGroupService.ReportsGroupUpdateRequestDto mapUpdate(ReportsGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportsGroupService.ReportsGroupUpdateRequestDto reportsGroupUpdateRequestDto = new ReportsGroupService.ReportsGroupUpdateRequestDto();

        reportsGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        reportsGroupUpdateRequestDto.setCode( arg0.getCode() );
        reportsGroupUpdateRequestDto.setName( arg0.getName() );

        return reportsGroupUpdateRequestDto;
    }
}
