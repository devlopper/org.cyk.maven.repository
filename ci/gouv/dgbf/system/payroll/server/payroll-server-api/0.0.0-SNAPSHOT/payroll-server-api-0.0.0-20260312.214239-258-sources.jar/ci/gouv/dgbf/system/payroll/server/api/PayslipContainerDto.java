package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette interface représente un conteneur de {@link PayslipDto}.
 */
public interface PayslipContainerDto extends PayslipContainer {

  /**
   * Identifiant json du statut.
   */
  String JSON_STATUS = "statut";

  /**
   * Identifiant json de la représentation en chaine de caractères du statut.
   */
  String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant brut.
   */
  String JSON_GROSS_AMOUNT_AS_STRING = "montantBrutChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant brut précédent.
   */
  String JSON_PREVIOUS_GROSS_AMOUNT_AS_STRING = "montantBrutPrecedentChaine";

  /**
   * Identifiant json de la variation du montant brut.
   */
  String JSON_GROSS_AMOUNT_VARIATION = "variationMontantBrut";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation du montant brut.
   */
  String JSON_GROSS_AMOUNT_VARIATION_AS_STRING = "variationMontantBrutChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant brut imposable.
   */
  String JSON_TAXABLE_GROSS_AMOUNT_AS_STRING = "montantBrutImposableChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant brut imposable
   * précédent.
   */
  String JSON_PREVIOUS_TAXABLE_GROSS_AMOUNT_AS_STRING = "montantBrutImposablePrecedentChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation du montant brut
   * imposable.
   */
  String JSON_TAXABLE_GROSS_AMOUNT_VARIATION_AS_STRING = "variationMontantBrutImposableChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères des éléments non soumis.
   */
  String JSON_NON_TAXABLE_AMOUNT_AS_STRING = "montantElementsNonSoumisChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères des éléments non soumis
   * précédent.
   */
  String JSON_PREVIOUS_NON_TAXABLE_AMOUNT_AS_STRING = "montantElementsNonSoumisPrecedentChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation des éléments non
   * soumis.
   */
  String JSON_NON_TAXABLE_AMOUNT_VARIATION_AS_STRING = "variationMontantElementsNonSoumisChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères des retenues.
   */
  String JSON_DEDUCTIONS_AMOUNT_AS_STRING = "montantRetenuesChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères des retenues précédent.
   */
  String JSON_PREVIOUS_DEDUCTIONS_AMOUNT_AS_STRING = "montantRetenuesPrecedentChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation des retenues.
   */
  String JSON_DEDUCTIONS_AMOUNT_VARIATION_AS_STRING = "variationMontantRetenuesChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant net.
   */
  String JSON_NET_AMOUNT_AS_STRING = "montantNetChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant net précédent.
   */
  String JSON_PREVIOUS_NET_AMOUNT_AS_STRING = "montantNetPrecedentChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation du montant net.
   */
  String JSON_NET_AMOUNT_VARIATION_AS_STRING = "variationMontantNetChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant employeur.
   */
  String JSON_EMPLOYER_AMOUNT_AS_STRING = "montantEmployeurChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant employeur précédent.
   */
  String JSON_PREVIOUS_EMPLOYER_AMOUNT_AS_STRING = "montantEmployeurPrecedentChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation 
   * du montant employeur.
   */
  String JSON_EMPLOYER_AMOUNT_VARIATION_AS_STRING = "variationMontantEmployeurChaine";


  /**
   * Identifiant json de la représentation en chaine de caractères du montant initialisé.
   */
  String JSON_INITIALIZED_AMOUNT_AS_STRING = "montantInitialChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant controlé.
   */
  String JSON_CONTROLED_AMOUNT_AS_STRING = "montantControleChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation controlée.
   */
  String JSON_CONTROLED_AMOUNT_VARIATION_AS_STRING = "variationMontantControleChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du montant ajusté.
   */
  String JSON_AJUSTED_AMOUNT_AS_STRING = "montantAjusteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères de la variation ajustée.
   */
  String JSON_AJUSTED_AMOUNT_VARIATION_AS_STRING = "variationMontantAjusteChaine";

  // Counts

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipMovementDto}.
   */
  String JSON_MOVEMENT_COUNT_AS_STRING = "nombreMouvementChaine";

  /**
   * Identifiant json du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#DEFERRED_PROPOSED}.
   */
  public static final String JSON_MOVEMENT_DEFERRED_PROPOSED_COUNT_AS_STRING =
      "nombreMouvementDiffereProposeChaine";

  /**
   * Identifiant json du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#DEFERRED}.
   */
  public static final String JSON_MOVEMENT_DEFERRED_COUNT_AS_STRING =
      "nombreMouvementDiffereChaine";

  /**
   * Identifiant json du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#REJECTION_PROPOSED}.
   */
  public static final String JSON_MOVEMENT_REJECTION_PROPOSED_COUNT_AS_STRING =
      "nombreMouvementRejetProposeChaine";

  /**
   * Identifiant json du nombre de {@link PayslipMovementDto}
   * {@link PayslipMovementStatus#REJECTED}.
   */
  public static final String JSON_MOVEMENT_REJECTED_COUNT_AS_STRING = "nombreMouvementRejeteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipConstantDto}.
   */
  String JSON_CONSTANT_COUNT_AS_STRING = "nombreConstanteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto}.
   */
  String JSON_COMPONENT_COUNT_AS_STRING = "nombrePosteChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} en gain ayant un montant non zéro.
   */
  String JSON_EARNING_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING =
      "nombreGainMontantNonZeroChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} en déduction ayant un montant non zéro.
   */
  String JSON_DEDUCTION_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING =
      "nombreDeductionMontantNonZeroChaine";

  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de
   * {@link PayslipComponentDto} en déduction ayant un montant non zéro.
   */
  String JSON_COMPONENT_HAVING_NON_BLANK_MESSAGE_COUNT_AS_STRING =
      "nombrePosteMessageEvaluationFormuleNonBlancChaine";
 
  /**
   * Identifiant json de la représentation en chaine de caratères
   * de l'envoie au contentieux.
   */
  String JSON_IS_LITIGATABLE =
      "estAuContentieux";
  /**
   * Identifiant json de la représentation en chaine de caractères de la raison
   * de l'envoie au contentieux.
   */
  String JSON_LITIGATION_REASON =
      "raisonContentieux";
}
