package ci.gouv.dgbf.system.scripting.server.api.grpc;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler (version 1.60.0)",
    comments = "Source: script_service.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ScriptServiceGrpc {

  private ScriptServiceGrpc() {}

  public static final java.lang.String SERVICE_NAME = "ScriptService";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest,
      ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> getEvaluateManyMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "EvaluateMany",
      requestType = ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest.class,
      responseType = ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest,
      ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> getEvaluateManyMethod() {
    io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest, ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> getEvaluateManyMethod;
    if ((getEvaluateManyMethod = ScriptServiceGrpc.getEvaluateManyMethod) == null) {
      synchronized (ScriptServiceGrpc.class) {
        if ((getEvaluateManyMethod = ScriptServiceGrpc.getEvaluateManyMethod) == null) {
          ScriptServiceGrpc.getEvaluateManyMethod = getEvaluateManyMethod =
              io.grpc.MethodDescriptor.<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest, ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "EvaluateMany"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ScriptServiceMethodDescriptorSupplier("EvaluateMany"))
              .build();
        }
      }
    }
    return getEvaluateManyMethod;
  }

  private static volatile io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest,
      ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> getEvaluateManyAsIntegerPrimitiveMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "EvaluateManyAsIntegerPrimitive",
      requestType = ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest.class,
      responseType = ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest,
      ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> getEvaluateManyAsIntegerPrimitiveMethod() {
    io.grpc.MethodDescriptor<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest, ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> getEvaluateManyAsIntegerPrimitiveMethod;
    if ((getEvaluateManyAsIntegerPrimitiveMethod = ScriptServiceGrpc.getEvaluateManyAsIntegerPrimitiveMethod) == null) {
      synchronized (ScriptServiceGrpc.class) {
        if ((getEvaluateManyAsIntegerPrimitiveMethod = ScriptServiceGrpc.getEvaluateManyAsIntegerPrimitiveMethod) == null) {
          ScriptServiceGrpc.getEvaluateManyAsIntegerPrimitiveMethod = getEvaluateManyAsIntegerPrimitiveMethod =
              io.grpc.MethodDescriptor.<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest, ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "EvaluateManyAsIntegerPrimitive"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ScriptServiceMethodDescriptorSupplier("EvaluateManyAsIntegerPrimitive"))
              .build();
        }
      }
    }
    return getEvaluateManyAsIntegerPrimitiveMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ScriptServiceStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ScriptServiceStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ScriptServiceStub>() {
        @java.lang.Override
        public ScriptServiceStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ScriptServiceStub(channel, callOptions);
        }
      };
    return ScriptServiceStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ScriptServiceBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ScriptServiceBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ScriptServiceBlockingStub>() {
        @java.lang.Override
        public ScriptServiceBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ScriptServiceBlockingStub(channel, callOptions);
        }
      };
    return ScriptServiceBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ScriptServiceFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ScriptServiceFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ScriptServiceFutureStub>() {
        @java.lang.Override
        public ScriptServiceFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ScriptServiceFutureStub(channel, callOptions);
        }
      };
    return ScriptServiceFutureStub.newStub(factory, channel);
  }

  /**
   */
  public interface AsyncService {

    /**
     * <pre>
     * Service d'évaluation générique
     * </pre>
     */
    default void evaluateMany(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest request,
        io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getEvaluateManyMethod(), responseObserver);
    }

    /**
     * <pre>
     * Service spécialisé pour la performance brute (int32)
     * </pre>
     */
    default void evaluateManyAsIntegerPrimitive(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest request,
        io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getEvaluateManyAsIntegerPrimitiveMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service ScriptService.
   */
  public static abstract class ScriptServiceImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ScriptServiceGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service ScriptService.
   */
  public static final class ScriptServiceStub
      extends io.grpc.stub.AbstractAsyncStub<ScriptServiceStub> {
    private ScriptServiceStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ScriptServiceStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ScriptServiceStub(channel, callOptions);
    }

    /**
     * <pre>
     * Service d'évaluation générique
     * </pre>
     */
    public void evaluateMany(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest request,
        io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getEvaluateManyMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Service spécialisé pour la performance brute (int32)
     * </pre>
     */
    public void evaluateManyAsIntegerPrimitive(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest request,
        io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getEvaluateManyAsIntegerPrimitiveMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service ScriptService.
   */
  public static final class ScriptServiceBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ScriptServiceBlockingStub> {
    private ScriptServiceBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ScriptServiceBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ScriptServiceBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Service d'évaluation générique
     * </pre>
     */
    public ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse evaluateMany(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getEvaluateManyMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Service spécialisé pour la performance brute (int32)
     * </pre>
     */
    public ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse evaluateManyAsIntegerPrimitive(ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getEvaluateManyAsIntegerPrimitiveMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service ScriptService.
   */
  public static final class ScriptServiceFutureStub
      extends io.grpc.stub.AbstractFutureStub<ScriptServiceFutureStub> {
    private ScriptServiceFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ScriptServiceFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ScriptServiceFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Service d'évaluation générique
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse> evaluateMany(
        ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getEvaluateManyMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Service spécialisé pour la performance brute (int32)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse> evaluateManyAsIntegerPrimitive(
        ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getEvaluateManyAsIntegerPrimitiveMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_EVALUATE_MANY = 0;
  private static final int METHODID_EVALUATE_MANY_AS_INTEGER_PRIMITIVE = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_EVALUATE_MANY:
          serviceImpl.evaluateMany((ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest) request,
              (io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse>) responseObserver);
          break;
        case METHODID_EVALUATE_MANY_AS_INTEGER_PRIMITIVE:
          serviceImpl.evaluateManyAsIntegerPrimitive((ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest) request,
              (io.grpc.stub.StreamObserver<ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getEvaluateManyMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyRequest,
              ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyResponse>(
                service, METHODID_EVALUATE_MANY)))
        .addMethod(
          getEvaluateManyAsIntegerPrimitiveMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveRequest,
              ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptEvaluateManyAsIntegerPrimitiveResponse>(
                service, METHODID_EVALUATE_MANY_AS_INTEGER_PRIMITIVE)))
        .build();
  }

  private static abstract class ScriptServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ScriptServiceBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return ci.gouv.dgbf.system.scripting.server.api.grpc.ScriptingServiceProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ScriptService");
    }
  }

  private static final class ScriptServiceFileDescriptorSupplier
      extends ScriptServiceBaseDescriptorSupplier {
    ScriptServiceFileDescriptorSupplier() {}
  }

  private static final class ScriptServiceMethodDescriptorSupplier
      extends ScriptServiceBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ScriptServiceMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ScriptServiceGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ScriptServiceFileDescriptorSupplier())
              .addMethod(getEvaluateManyMethod())
              .addMethod(getEvaluateManyAsIntegerPrimitiveMethod())
              .build();
        }
      }
    }
    return result;
  }
}
