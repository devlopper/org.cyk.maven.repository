package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Statuts des demandes d'archivage et de retrait d'un fichier de groupe.
 */
@Getter
public enum FileGroupArchivalStatus {

  /** Demande créée. */
  CREATED("CREE", "Créé"),
  /** Demande acceptée. */
  ACCEPTED("ACCEPTE", "Accepté"),
  /** Demande refusée. */
  REFUSED("REFUSE", "Refusé"),
  /** Demande annulée. */
  CANCELLED("ANNULE", "Annulé");

  private final String code;
  private final String name;

  private FileGroupArchivalStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Obtient le statut correspondant au code stocké.
   *
   * @param code code du statut
   * @return statut correspondant
   */
  public static FileGroupArchivalStatus getByCode(String code) {
    return Stream.of(values()).filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
