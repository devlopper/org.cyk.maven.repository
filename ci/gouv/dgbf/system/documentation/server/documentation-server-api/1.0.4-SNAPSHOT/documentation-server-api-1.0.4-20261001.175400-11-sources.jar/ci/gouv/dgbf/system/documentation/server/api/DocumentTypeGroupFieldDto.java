package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de groupe de type de document : champ additionnel à saisir sur
 * les pièces d'une combinaison précise type de document + groupe de types de document.
 *
 * @author si.kimou
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentTypeGroupFieldDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasTypeGroupIdentifierDto, HasTypeGroupAsStringDto, HasValueTypeDto,
    HasValueTypeAsStringDto {

  @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
  private String typeGroupIdentifier;

  @JsonbProperty(JSON_TYPE_GROUP_AS_STRING)
  private String typeGroupAsString;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  @JsonbProperty(JSON_REQUIRED)
  private Boolean required;

  /**
   * Identifiant json champ {@link #required}.
   */
  public static final String JSON_REQUIRED = "obligatoire";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idChampGroupeTypeDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "champGroupeTypeDocumentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "champ de groupe de type de document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "champs de groupe de type de document";
}
