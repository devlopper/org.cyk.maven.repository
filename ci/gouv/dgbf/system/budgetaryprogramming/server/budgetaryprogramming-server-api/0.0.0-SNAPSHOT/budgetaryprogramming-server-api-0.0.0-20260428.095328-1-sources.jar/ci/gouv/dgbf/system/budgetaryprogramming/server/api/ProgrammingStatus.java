package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link ProgrammingDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum ProgrammingStatus {

  /**
   * {@link ProgrammingStatusCode#CREATED}.
   */
  CREATED(ProgrammingStatusCode.CREATED, "Créé", "Création"),
  
  /**
   * {@link ProgrammingStatusCode#INPUTTED}.
   */
  INPUTTED(ProgrammingStatusCode.INPUTTED, "Saisi", "Saisie"),
  
  /**
   * {@link ProgrammingStatusCode#TRANSMITTED_FOR_ARBITRATION}.
   */
  TRANSMITTED_FOR_ARBITRATION(ProgrammingStatusCode.TRANSMITTED_FOR_ARBITRATION, 
  "Transmis pour arbitrage", "Transmission pour arbitrage"),
  
  /**
   * {@link ProgrammingStatusCode#ARBITRATED}.
   */
  ARBITRATED(ProgrammingStatusCode.ARBITRATED, "Arbitré", "Arbitrage"),
  
  /**
   * {@link ProgrammingStatusCode#TRANSMITTED_FOR_VALIDATION}.
   */
  TRANSMITTED_FOR_VALIDATION(ProgrammingStatusCode.TRANSMITTED_FOR_VALIDATION, 
  "Transmis pour validation", "Transmission pour validation"),
  
  /**
   * {@link ProgrammingStatusCode#VALIDATED}.
   */
  VALIDATED(ProgrammingStatusCode.VALIDATED, "Validé", "Validation"),
  
  /**
   * {@link ProgrammingStatusCode#TRANSMITTED_FOR_INTEGRATION}.
   */
  TRANSMITTED_FOR_INTEGRATION(ProgrammingStatusCode.TRANSMITTED_FOR_INTEGRATION, 
  "Transmis pour intégration", "Transmission pour intégration"),
  
  /**
   * {@link ProgrammingStatusCode#INTEGRATED}.
   */
  INTEGRATED(ProgrammingStatusCode.INTEGRATED, "Intégré", "Intégration"),

  ;

  private ProgrammingStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<ProgrammingStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le statut par code.
   *
   * @param code code
   * @return statut
   */
  public static ProgrammingStatus getByCode(String code) {
    return Stream.of(ProgrammingStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    INPUTTED.previous = Core.getSet(List.of(CREATED, INPUTTED));
    
    TRANSMITTED_FOR_ARBITRATION.previous = Core.getSet(List.of(INPUTTED));
    ARBITRATED.previous = Core.getSet(List.of(TRANSMITTED_FOR_ARBITRATION, ARBITRATED));
    
    TRANSMITTED_FOR_VALIDATION.previous = Core.getSet(List.of(ARBITRATED));
    VALIDATED.previous = Core.getSet(List.of(TRANSMITTED_FOR_VALIDATION, VALIDATED));
    
    TRANSMITTED_FOR_INTEGRATION.previous = Core.getSet(List.of(VALIDATED));
    INTEGRATED.previous = Core.getSet(List.of(TRANSMITTED_FOR_INTEGRATION));
  }
}
