package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ExpertiseDomainService.ExpertiseDomainCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ExpertiseDomainService.ExpertiseDomainUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ExpertiseDomainDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ExpertiseDomainDto}.
    
    @author Desysoft
    """)
public interface ExpertiseDomainRequestMapper
    extends
    RequestMapper<ExpertiseDomainDto, ExpertiseDomainCreateRequestDto,
        ExpertiseDomainUpdateRequestDto> {

}
