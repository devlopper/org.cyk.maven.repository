package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class UserFilter extends AbstractIdentifiableFilter {

  /**
   * Nom.
   */
  String name;

  /**
   * Identifiant {@link AdministrativeUnitDto} de compte de {@link FolderDto}.
   */
  String foldersCountsAdministrativeUnitIdentifier;

  /**
   * Identifiant {@link AdministrativeUnitDto} de compte de {@link ActivityDto}.
   */
  String activitiesCountsAdministrativeUnitIdentifier;

  /**
   * Identifiant {@link AdministrativeUnitDto} de compte de {@link TaskDto}.
   */
  String tasksCountsAdministrativeUnitIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public UserFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public UserFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
    foldersCountsAdministrativeUnitIdentifier =
        getFoldersCountsAdministrativeUnitIdentifier(filter);
    activitiesCountsAdministrativeUnitIdentifier =
        getActivitiesCountsAdministrativeUnitIdentifier(filter);
    tasksCountsAdministrativeUnitIdentifier = getTasksCountsAdministrativeUnitIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
    setFoldersCountsAdministrativeUnitIdentifier(filter, foldersCountsAdministrativeUnitIdentifier);
    setActivitiesCountsAdministrativeUnitIdentifier(filter,
        activitiesCountsAdministrativeUnitIdentifier);
    setTasksCountsAdministrativeUnitIdentifier(filter, tasksCountsAdministrativeUnitIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param userName nom
   */
  public static void setName(FilterDto filter, String userName) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link FolderDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto} de compte de {@link FolderDto}
   */
  public static String getFoldersCountsAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_FOLDERS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link FolderDto}.
   *
   * @param filter filtre
   * @param identifier identifiant de {@link AdministrativeUnitDto} de compte de {@link FolderDto}
   */
  public static void setFoldersCountsAdministrativeUnitIdentifier(FilterDto filter,
      String identifier) {
    set(filter, JSON_FOLDERS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link ActivityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto} de compte de {@link ActivityDto}
   */
  public static String getActivitiesCountsAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_ACTIVITIES_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link ActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant de {@link AdministrativeUnitDto} de compte de {@link ActivityDto}
   */
  public static void setActivitiesCountsAdministrativeUnitIdentifier(FilterDto filter,
      String identifier) {
    set(filter, JSON_ACTIVITIES_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link TaskDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto} de compte de {@link TaskDto}
   */
  public static String getTasksCountsAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_TASKS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto} de compte de
   * {@link TaskDto}.
   *
   * @param filter filtre
   * @param identifier identifiant de {@link AdministrativeUnitDto} de compte de {@link TaskDto}
   */
  public static void setTasksCountsAdministrativeUnitIdentifier(FilterDto filter,
      String identifier) {
    set(filter, JSON_TASKS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  /**
   * Identifiant json champ {@link #foldersCountsAdministrativeUnitIdentifier}.
   */
  public static final String JSON_FOLDERS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER =
      FolderDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER + "CompteDossier";

  /**
   * Identifiant json champ {@link #activitiesCountsAdministrativeUnitIdentifier}.
   */
  public static final String JSON_ACTIVITIES_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER =
      FolderDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER + "CompteActivite";

  /**
   * Identifiant json champ {@link #tasksCountsAdministrativeUnitIdentifier}.
   */
  public static final String JSON_TASKS_COUNTS_ADMINISTRATIVE_UNIT_IDENTIFIER =
      FolderDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER + "CompteTache";
}

