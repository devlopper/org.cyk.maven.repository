package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ReportGroupDto}.
 *
 * @author Desysoft
 */
@Path(value = ReportGroupService.PATH)
@Tag(name = "Gestion des rapports groupes")
public interface ReportGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "rapports-groupes";


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RAPPORT_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";
  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RAPPORT_GROUPE";
  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";
  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RAPPORT_GROUPE";
  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";
  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_RAPPORT_GROUPE";
  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";
  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RAPPORT_GROUPE";
  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";
  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_RAPPORT_GROUPE";
  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ReportGroupCreateRequestDto request);

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation =
              ReportGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette méthode permet d'obtenir {@link ReportGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = ReportGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Cette méthode permet d'obtenir par identrifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = ReportGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ReportGroupUpdateRequestDto request);

  /**
   * Cette méthode permet de supprimer {@link ReportGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Desysoft
   */
  interface ReportGroupSaveRequestDto {

    /**
     * Identifiant JSON {@link ReportDto}.
     */
    String JSON_REPORT_IDENTIFIER = ReportGroupDto
        .JSON_REPORT_IDENTIFIER;
    /**
     * Identifiant JSON {@link ReportGroupDto}.
     */
    String JSON_GROUP_IDENTIFIER = ReportGroupDto
        .JSON_GROUP_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ReportDto}.
     *
     * @return identifiant de {@link ReportDto}
     */
    String getReportIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ReportDto}.
     *
     * @param reportIdentifier identifiant de {@link ReportDto}
     */
    void setReportIdentifier(String reportIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ReportsGroupDto}.
     *
     * @return identifiant de {@link ReportsGroupDto}
     */
    String getReportsGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ReportsGroupDto}.
     *
     * @param reportsGroupIdentifier identifiant de {@link ReportsGroupDto}
     */
    void setReportsGroupIdentifier(String reportsGroupIdentifier);
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReportGroupCreateRequestDto extends AbstractCodableCreateRequestJsonDto
      implements ReportGroupSaveRequestDto {

    @JsonbProperty(JSON_REPORT_IDENTIFIER)
    private String reportIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String reportsGroupIdentifier;

  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReportGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ReportGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ReportGroupDto> datas;
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ReportGroupUpdateRequestDto extends
      AbstractCodableNamableUpdateRequestJsonDto
      implements ReportGroupSaveRequestDto {

    @JsonbProperty(JSON_REPORT_IDENTIFIER)
    private String reportIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String reportsGroupIdentifier;

  }
}

