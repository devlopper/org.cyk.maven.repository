package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityGetManyResponseDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/** Client REST de la confidentialite par ressource. */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ResourceConfidentialityClient extends AbstractClient<ResourceConfidentialityService>
    implements GetByIdentifier<ResourceConfidentialityDto>,
    GetMany<ResourceConfidentialityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /** Configure le service REST. */
  @Override
  public ResourceConfidentialityClient service(ResourceConfidentialityService service) {
    return (ResourceConfidentialityClient) super.service(service);
  }

  /** Cree une confidentialite. */
  public CreateResponseDto create(ResourceConfidentialityCreateRequestDto request) {
    return new CreateExecutor("CREATION_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().create(request));
  }

  /** Obtient une page de confidentialites. */
  public ResourceConfidentialityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ResourceConfidentialityGetManyResponseDto>(
        ResourceConfidentialityGetManyResponseDto.class,
        "OBTENTION_PLUSIEURS_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().getMany(request));
  }

  /** Obtient une page de confidentialites avec ses parametres. */
  @Override
  public ResourceConfidentialityGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /** Obtient une confidentialite selon un filtre. */
  public ResourceConfidentialityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ResourceConfidentialityDto>(ResourceConfidentialityDto.class,
        "OBTENTION_UN_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().getOne(request));
  }

  /** Obtient une confidentialite par identifiant. */
  public ResourceConfidentialityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ResourceConfidentialityDto>(ResourceConfidentialityDto.class,
        "OBTENTION_PAR_IDENTIFIANT_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().getByIdentifier(request));
  }

  /** Obtient une confidentialite par identifiant avec ses parametres. */
  @Override
  public ResourceConfidentialityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /** Met a jour une confidentialite. */
  public IdentifiableResponseDto update(ResourceConfidentialityUpdateRequestDto request) {
    return new IdentifiableExecutor("MISE_A_JOUR_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().update(request));
  }

  /** Supprime une confidentialite. */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor("SUPPRESSION_RESSOURCE_CONFIDENTIALITE")
        .execute(() -> service().delete(request));
  }

  /** Supprime une confidentialite par identifiant. */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
