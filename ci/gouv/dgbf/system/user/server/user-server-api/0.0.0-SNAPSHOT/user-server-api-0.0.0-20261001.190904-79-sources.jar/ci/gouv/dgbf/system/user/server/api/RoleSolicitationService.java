package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RoleSolicitationDto}.
 *
 * @author BoobaCool
 */
@Path(value = RoleSolicitationService.PATH)
@Tag(name = "Gestion des Demandes de Rôle")
public interface RoleSolicitationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "demandes-role";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface RoleSolicitationSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'utilisateur demandeur.
     *
     * @return identifiant de l'utilisateur demandeur
     */
    String getUserIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'utilisateur demandeur.
     *
     * @param userIdentifier identifiant de l'utilisateur demandeur
     */
    void setUserIdentifier(String userIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du rôle demandé.
     *
     * @return identifiant du rôle demandé
     */
    String getRoleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du rôle demandé.
     *
     * @param roleIdentifier identifiant du rôle demandé
     */
    void setRoleIdentifier(String roleIdentifier);

    /**
     * Cette méthode permet d'obtenir le motif de la demande.
     *
     * @return motif de la demande
     */
    String getReason();

    /**
     * Cette méthode permet d'assigner le motif de la demande.
     *
     * @param reason motif de la demande
     */
    void setReason(String reason);

    /**
     * {@link RoleSolicitationDto#JSON_USER_IDENTIFIER}.
     */
    String JSON_USER_IDENTIFIER = RoleSolicitationDto.JSON_USER_IDENTIFIER;

    /**
     * {@link RoleSolicitationDto#JSON_ROLE_IDENTIFIER}.
     */
    String JSON_ROLE_IDENTIFIER = RoleSolicitationDto.JSON_ROLE_IDENTIFIER;

    /**
     * {@link RoleSolicitationDto#JSON_REASON}.
     */
    String JSON_REASON = RoleSolicitationDto.JSON_REASON;
  }

  /**
   * Identifiant du service de création unitaire de {@link RoleSolicitationDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_DEMANDE_ROLE";

  /**
   * Chemin du service de création unitaire de {@link RoleSolicitationDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RoleSolicitationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements RoleSolicitationSaveRequestDto {

    @JsonbProperty(JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

    @JsonbProperty(JSON_REASON)
    private String reason;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link RoleSolicitationDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DEMANDE_ROLE";

  /**
   * Chemin du service d'obtention de plusieurs {@link RoleSolicitationDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RoleSolicitationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class RoleSolicitationGetManyResponseDto
      extends AbstractGetByPageResponseDto<RoleSolicitationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RoleSolicitationDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link RoleSolicitationDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_DEMANDE_ROLE";

  /**
   * Chemin du service d'obtention unitaire de {@link RoleSolicitationDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleSolicitationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link RoleSolicitationDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DEMANDE_ROLE";

  /**
   * Chemin du service d'obtention par identifiant de {@link RoleSolicitationDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleSolicitationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link RoleSolicitationDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DEMANDE_ROLE";

  /**
   * Chemin du service de mise à jour unitaire de {@link RoleSolicitationDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RoleSolicitationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationUpdateRequestDto extends ByIdentifierRequestDto
      implements RoleSolicitationSaveRequestDto {

    @JsonbProperty(JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;

    @JsonbProperty(JSON_REASON)
    private String reason;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link RoleSolicitationDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DEMANDE_ROLE";

  /**
   * Chemin du service de suppression unitaire de {@link RoleSolicitationDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link RoleSolicitationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette classe représente la base des réponses de traitement de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<RoleSolicitationStatus> {

    @JsonbProperty(JSON_STATUS)
    private RoleSolicitationStatus status;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link RoleSolicitationStatus}
     */
    public void initialize(RoleSolicitationStatus status) {
      this.status = status;
    }
  }

  /**
   * Identifiant du service d'acceptation de {@link RoleSolicitationDto}.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_DEMANDE_ROLE";

  /**
   * Chemin du service d'acceptation de {@link RoleSolicitationDto}.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet d'accepter une demande de rôle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ACCEPT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RoleSolicitationAcceptResponseDto.class))})
  Response accept(RoleSolicitationAcceptRequestDto request);

  /**
   * Cette classe représente la requête d'acceptation de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationAcceptRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse d'acceptation de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationAcceptResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de refus de {@link RoleSolicitationDto}.
   */
  String REFUSE_IDENTIFIER = "REFUS_DEMANDE_ROLE";

  /**
   * Chemin du service de refus de {@link RoleSolicitationDto}.
   */
  String REFUSE_PATH = "refus";

  /**
   * Cette méthode permet de refuser une demande de rôle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REFUSE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REFUSE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RoleSolicitationRefuseResponseDto.class))})
  Response refuse(RoleSolicitationRefuseRequestDto request);

  /**
   * Cette classe représente la requête de refus de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationRefuseRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif du refus.
     */
    @JsonbProperty(RoleSolicitationDto.JSON_STATUS_COMMENT)
    private String statusComment;
  }

  /**
   * Cette classe représente la réponse de refus de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationRefuseResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service d'annulation de {@link RoleSolicitationDto}.
   */
  String CANCEL_IDENTIFIER = "ANNULATION_DEMANDE_ROLE";

  /**
   * Chemin du service d'annulation de {@link RoleSolicitationDto}.
   */
  String CANCEL_PATH = "annulation";

  /**
   * Cette méthode permet au demandeur d'annuler sa demande de rôle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CANCEL_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RoleSolicitationCancelResponseDto.class))})
  Response cancel(RoleSolicitationCancelRequestDto request);

  /**
   * Cette classe représente la requête d'annulation de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationCancelRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse d'annulation de {@link RoleSolicitationDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleSolicitationCancelResponseDto extends ProcessResponseDto {

  }
}
