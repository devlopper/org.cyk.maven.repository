package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ColorPalette;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartOptions;
import org.primefaces.model.charts.axes.cartesian.CartesianScales;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearAxes;
import org.primefaces.model.charts.bar.BarChartDataSet;
import org.primefaces.model.charts.bar.BarChartModel;
import org.primefaces.model.charts.bar.BarChartOptions;
import org.primefaces.model.charts.line.LineChartDataSet;
import org.primefaces.model.charts.line.LineChartModel;
import org.primefaces.model.charts.line.LineChartOptions;
import org.primefaces.model.charts.optionconfig.title.Title;
import org.primefaces.model.charts.pie.PieChartDataSet;
import org.primefaces.model.charts.pie.PieChartModel;
import org.primefaces.model.charts.pie.PieChartOptions;

/**
 * Cette classe représente le contrôleur de graphique.
 *
 * @author Christian
 *
 */
@Dependent
@Deprecated(forRemoval = true)
public class ChartController extends AbstractController {

  @Getter
  @Setter
  Object client;

  @Getter
  @Setter
  Object filter;

  @Getter
  ChartDto chart;

  @Getter
  @Setter
  String keyName;

  @Getter
  @Setter
  String valueName;

  @Getter
  @Setter
  String variationName;

  @Getter
  LineChartModel lineModel;

  @Getter
  PieChartModel pieModel;

  @Getter
  BarChartModel barModel;
  
  @Getter
  @Setter
  Consumer<Object> consumer;

  @Getter
  @Setter
  Supplier<GetChartResponseDto> supplier;

  @Getter
  @Setter
  Supplier<Object> filterSupplier;

  @Inject
  FilterDtoGetter filterDtoGetter;

  @Getter
  @Setter
  ColorPalette colorPalette;

  @Inject
  ChartManager manager;

  /**
   * Cette méthode est le constructeur par défaut.
   */
  public ChartController() {
    variationName = "Variation";
    colorPalette = new ColorPalette();
  }

  void prepareColors() {
    colorPalette.getRgbList().addAll(manager.getColors());
    colorPalette.getRgbaList().addAll(manager.getColorsWithReducedAlpha());
  }

  /**
   * Cette méthode permet de construire une courbe.
   *
   * @return this
   */
  public ChartController buildLineModel() {
    return buildModel(() -> {
      ChartData data = new ChartData();
      data.setLabels(new ArrayList<>(chart.getKeys()));

      AtomicInteger colorIndex = new AtomicInteger();
      chart.filterDataSets().forEach(dataSet -> {
        LineChartDataSet lineChartDataSet = new LineChartDataSet();
        data.addChartDataSet(lineChartDataSet);
        lineChartDataSet.setLabel(dataSet.getName());
        lineChartDataSet
            .setData(dataSet.getDatas().stream().map(i -> (Object) i.getValue()).toList());
        // Style
        lineChartDataSet.setFill(false);
        lineChartDataSet.setBorderColor(colorPalette.getRgbAt(colorIndex.intValue()));
        lineChartDataSet.setTension(0.1);
        colorIndex.incrementAndGet();
      });

      LineChartOptions options = new LineChartOptions();
      configureOptions(options, chart.getName());

      lineModel = new LineChartModel();
      lineModel.setData(data);
      lineModel.setOptions(options);
      return lineModel;
    });
  }
  
  /**
   * Cette méthode permet de construire un histogramme.
   *
   * @return this
   */
  public ChartController buildBarModel(Consumer<BarChartOptions> optionsConsumer) {
    return buildModel(() -> {
      ChartData data = new ChartData();
      data.setLabels(new ArrayList<>(chart.getKeys()));

      AtomicInteger colorIndex = new AtomicInteger();
      LinkedHashSet<ChartDataSetDto> dataSets = chart.filterDataSets();
      int size = dataSets.size();
      dataSets.forEach(dataSet -> {
        BarChartDataSet barChartDataSet = new BarChartDataSet();
        data.addChartDataSet(barChartDataSet);
        barChartDataSet.setLabel(dataSet.getName());
        barChartDataSet
            .setData(dataSet.getDatas().stream().map(i -> (Number) i.getValue()).toList());
        // Style
        if (size == 1) {
          barChartDataSet.setBorderColor(colorPalette.getRgbList());
          barChartDataSet.setBackgroundColor(colorPalette.getRgbaList());
        } else {
          barChartDataSet.setBorderColor(colorPalette.getRgbAt(colorIndex.intValue()));
          barChartDataSet.setBackgroundColor(colorPalette.getRgbaAt(colorIndex.intValue()));
          colorIndex.incrementAndGet();
        }

        barChartDataSet.setBorderWidth(1);
      });

      BarChartOptions options = new BarChartOptions();
      configureOptions(options, chart.getName());
      Core.acceptConsumer(optionsConsumer, options);

      barModel = new BarChartModel();
      barModel.setData(data);
      barModel.setOptions(options);

      return barModel;
    });
  }

  public ChartController buildBarModel() {
    return buildBarModel(null);
  }

  /**
   * Cette méthode permet de construire un gateau.
   *
   * @return this
   */
  public ChartController buildPieModel() {
    return buildModel(() -> {
      ChartData data = new ChartData();

      data.setLabels(new ArrayList<>(chart.getKeys()));

      chart.filterDataSets().forEach(dataSet -> {
        PieChartDataSet pieChartDataSet = new PieChartDataSet();
        data.addChartDataSet(pieChartDataSet);
        pieChartDataSet
            .setData(dataSet.getDatas().stream().map(i -> (Number) i.getValue()).toList());
        // Style
        pieChartDataSet.setBackgroundColor(colorPalette.getRgbaList());
        pieChartDataSet.setBorderColor(colorPalette.getRgbList());
      });

      PieChartOptions options = new PieChartOptions();
      configureOptions(options, chart.getName());

      pieModel = new PieChartModel();
      pieModel.setData(data);
      pieModel.setOptions(options);
      return pieModel;
    });
  }
  
  ChartController buildModel(Supplier<Object> supplier) {
    GetChartResponseDto response = supply();
    if (GetChartResponseDto.isDatasEmpty(response)) {
      chart = null;
      lineModel = null;
      pieModel = null;
      barModel = null;
    } else {
      prepareColors();
      chart = response.getChart();
      Object result = supplier.get();
      consume(result);
    }
    return this;
  }

  GetChartResponseDto supply() {
    FilterDto dto = filterDtoGetter.get(filter, filterSupplier);
    if (client instanceof GetChart<?> getter) {
      supplier = () -> (GetChartResponseDto) getter.getChart(dto, userIdentifier, null);
    }
    if (supplier == null) {
      throw new IllegalStateException(
          "Le fournisseur de réponse d'obtention de graphique ne doit pas être nul.");
    }
    return new ActionExecutor<GetChartResponseDto>(this, "Obtention graphique",
        () -> supplier.get()).execute();
  }

  void configureOptions(ChartOptions options, String titleText) {
    options.setResponsive(true);
    options.setMaintainAspectRatio(false);
    Title title = new Title();
    title.setDisplay(true);
    title.setText(titleText);
    options.setTitle(title);
  }

  /**
   * Cette méthode permet de configurer un histogramme empilé.
   *
   * @param options options
   */
  public static void configureStackedBar(BarChartOptions options) {
    CartesianScales cartesianScales = new CartesianScales();
    CartesianLinearAxes cartesianLinearAxes = new CartesianLinearAxes();
    cartesianLinearAxes.setStacked(true);
    cartesianLinearAxes.setOffset(true);
    cartesianScales.addXAxesData(cartesianLinearAxes);
    cartesianScales.addYAxesData(cartesianLinearAxes);
    options.setScales(cartesianScales);
  }

  void consume(Object chart) {
    if (chart != null && consumer != null) {
      consumer.accept(chart);
    }
  }


}
