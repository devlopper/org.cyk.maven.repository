package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link SharingDto}.
 *
 * @author AKM
 *
 */
@Named
@ViewScoped
public class SharingListPage extends AbstractSharingListPage  {

  /**
   * Cette constante est le cas de navigation.
   */
  public static final String OUTCOME = "sharingListPage";
}
