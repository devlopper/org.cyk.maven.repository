package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une classe.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class GradeClassDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link GradeClassDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idClasse";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link GradeClassDto}.
   */
  public static final String JSON_THIS_AS_STRING = "classeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "classe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
