package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AccountDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AccountFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link DomainDto}.
   */
  private String domainIdentifier;
  
  /**
   * Nom.
   */
  private String name;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AccountFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public AccountFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
    domainIdentifier = getDomainIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
    setDomainIdentifier(filter, domainIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
   *
   * @param filter filtre
   * @param domainIdentifier identifiant de {@link DomainDto}
   */
  public static void setDomainIdentifier(FilterDto filter, String domainIdentifier) {
    set(filter, JSON_DOMAIN_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(domainIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link DomainDto}
   */
  public static String getDomainIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_DOMAIN_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param name nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Identifiant json champ {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = AccountDto.JSON_DOMAIN_IDENTIFIER;

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;
}
