package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypesGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypesGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypesGroupService.DocumentTypesGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DocumentTypesGroupDto}.
 *
 * @author akm
 *
 */
@Dependent
public class DocumentTypesGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    DocumentTypesGroupDto, DocumentTypesGroupGetManyResponseDto, DocumentTypesGroupClient> {

  @Getter
  @Inject
  DocumentTypesGroupClient client;

  protected DocumentTypesGroupSelectOneController() {
    super(DocumentTypesGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
