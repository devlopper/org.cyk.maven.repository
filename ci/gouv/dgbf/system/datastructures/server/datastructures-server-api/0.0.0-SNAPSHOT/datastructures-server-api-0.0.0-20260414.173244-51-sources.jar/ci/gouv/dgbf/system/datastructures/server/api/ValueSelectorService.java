package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDataEntityCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasDataEntityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterAttributeValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueSelectorDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ValueSelectorService.PATH)
@Tag(name = "Gestion de sélecteur de valeur")
public interface ValueSelectorService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "selecteurs-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueSelectorSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de la source de valeur.
     *
     * @return l'identifiant de la source de valeur
     */
    String getSourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la source de valeur.
     *
     * @param sourceIdentifier l'identifiant de la source de valeur
     */
    void setSourceIdentifier(String sourceIdentifier);

    /**
     * Cette méthode permet d'obtenir le nom de l'attribut de filtre.
     *
     * @return le nom de l'attribut de filtre
     */
    String getFilterAttributeName();

    /**
     * Cette méthode permet d'assigner le nom de la colonne de filtre.
     *
     * @param filterAttributeName le nom de la colonne de filtre
     */
    void setFilterAttributeName(String filterAttributeName);

    /**
     * {@link HasSourceIdentifierDto#JSON_SOURCE_IDENTIFIER}.
     */
    String JSON_SOURCE_IDENTIFIER = HasSourceIdentifierDto.JSON_SOURCE_IDENTIFIER;

    /**
     * {@link HasFilterAttributeNameDto#JSON_FILTER_ATTRIBUTE_NAME}.
     */
    String JSON_FILTER_ATTRIBUTE_NAME = HasFilterAttributeNameDto.JSON_FILTER_ATTRIBUTE_NAME;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SELECTEUR_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueSelectorCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ValueSelectorSaveRequestDto {

    @JsonbProperty(JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(JSON_FILTER_ATTRIBUTE_NAME)
    private String filterAttributeName;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSelectorGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueSelectorGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueSelectorDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueSelectorDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSelectorDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSelectorDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SELECTEUR_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueSelectorUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ValueSelectorSaveRequestDto {

    @JsonbProperty(JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(JSON_FILTER_ATTRIBUTE_NAME)
    private String filterAttributeName;
  }

  /**
   * Identifiant du service d'évaluation.
   */
  String EVALUATE_IDENTIFIER = "EVALUATION_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'évaluation.
   */
  String EVALUATE_PATH = "evaluation";

  /**
   * Cette méthode permet d'évaluer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSelectorEvaluateResponseDto.class))})
  Response evaluate(ValueSelectorEvaluateRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorEvaluateRequestDto extends ByIdentifierRequestDto
      implements HasFilterAttributeValueDto, HasDataEntityCodeDto, HasDataEntityIdentifierDto {

    @JsonbProperty(JSON_FILTER_ATTRIBUTE_VALUE)
    private String filterAttributeValue;

    @JsonbProperty(JSON_DATA_ENTITY_CODE)
    private String dataEntityCode;

    @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
    private String dataEntityIdentifier;
  }

  /**
   * Cette classe représente la réponse d'évaluation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorEvaluateResponseDto extends IdentifiableResponseDto
      implements HasStringValueDto {

    @JsonbProperty(JSON_VALUE)
    private String value;
  }

  /**
   * Identifiant du service d'évaluation interne.
   */
  String EVALUATE_INTERNAL_IDENTIFIER = "EVALUATION_INTERNE_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'évaluation interne.
   */
  String EVALUATE_INTERNAL_PATH = "evaluation-interne";

  /**
   * Cette méthode permet d'évaluer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_INTERNAL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_INTERNAL_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSelectorEvaluateResponseDto.class))})
  Response evaluateInternal(ValueSelectorEvaluateRequestDto request);
  
  /**
   * Identifiant du service d'évaluation de plusieurs.
   */
  String EVALUATE_MANY_IDENTIFIER = "EVALUATIONS_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'évaluation de plusieurs.
   */
  String EVALUATE_MANY_PATH = "evaluations";

  /**
   * Cette méthode permet d'évaluer plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSelectorEvaluateManyResponseDto.class))})
  Response evaluateMany(ValueSelectorEvaluateManyRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorEvaluateManyRequestDto extends AbstractAuditedRequestJsonDto
      implements HasDataEntityCodeDto, HasDataEntityIdentifierDto {

    @JsonbProperty("valeurs-attribut-filtre")
    private Map<String, String> filterAttributeValues;

    @JsonbProperty(JSON_DATA_ENTITY_CODE)
    private String dataEntityCode;

    @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
    private String dataEntityIdentifier;
  }

  /**
   * Cette classe représente la réponse d'évaluation de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorEvaluateManyResponseDto extends AbstractResponseDto {

    @JsonbProperty("valeurs")
    private Map<String, String> values;
  }
  
  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SELECTEUR_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueSelectorDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
