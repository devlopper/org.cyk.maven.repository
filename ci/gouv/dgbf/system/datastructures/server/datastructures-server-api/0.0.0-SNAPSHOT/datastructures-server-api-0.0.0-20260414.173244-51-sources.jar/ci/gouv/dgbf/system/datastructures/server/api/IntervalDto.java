package ci.gouv.dgbf.system.datastructures.server.api;


import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un intervalle.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IntervalDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasMinValueDto<Integer>, HasMinValueAsStringDto, HasMaxValueDto<Integer>,
    HasMaxValueAsStringDto, HasValueTypeDto, HasValueTypeAsStringDto {

  private Integer minValue;
  
  private String minValueAsString;
  
  private Integer maxValue;
  
  private String maxValueAsString;
  
  private ValueType valueType;
  
  private String valueTypeAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idIntervalle";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "intervalleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "intervalle";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
