package ci.gouv.dgbf.extension.primefaces.template;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette class représente le gestionnaire du conteneur.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Getter
@Setter
@Named
public class ContainerManager {

  private String sidebar;
  private String layout;
  private String topbar;
  private String sidebarSize;
  private String sidebarImage;
  private String preloader;
  private String theme;
  private String themeColors;
  private String sidebarVisibility;
  private String layoutStyle;
  private String bsTheme;
  private String layoutWidth;
  private String layoutPosition;
  private String bodyImage;
  private String sidebarUserShow;
  private String styleContentColorManager;

  /**
   * Active l'identité visuelle DGBF (la charte graphique, constitution-ui.md §3.4) sur les écrans
   * privés. Faux par défaut : chaque module l'active par {@value #BRAND_ENABLED_PROPERTY} dans sa
   * configuration.
   */
  @ConfigProperty(name = BRAND_ENABLED_PROPERTY, defaultValue = "false")
  boolean brandEnabled;

  /**
   * Ancien nom de {@value #BRAND_ENABLED_PROPERTY}, lu tant que les configurations de déploiement
   * ne sont pas migrées. À retirer à la prochaine version majeure.
   *
   * @deprecated utiliser {@value #BRAND_ENABLED_PROPERTY}
   */
  @Deprecated
  @ConfigProperty(name = LEGACY_CHARTE_ENABLED_PROPERTY, defaultValue = "false")
  boolean legacyCharteEnabled;

  /**
   * Charge le socle de style de la disposition (Bootstrap, app.css, position.css,
   * menu.css et header.css) depuis ce jar au lieu des copies embarquées par l'application dans
   * {@code resources/assets/global}. Faux par défaut : chaque module l'active par
   * {@value #BASE_STYLE_FROM_JAR_PROPERTY} après avoir retiré ses copies.
   */
  @ConfigProperty(name = BASE_STYLE_FROM_JAR_PROPERTY, defaultValue = "false")
  boolean baseStyleFromJar;

  /**
   * Charge {@code resources/assets/global/global-import.css} de l'application. Vrai par défaut :
   * tant qu'un module y garde des feuilles (boutons, tableaux, dialogues), il doit rester chargé.
   * Un module dont ce fichier ne contient plus rien le désactive par
   * {@value #GLOBAL_IMPORT_PROPERTY} et peut alors le supprimer.
   */
  @ConfigProperty(name = GLOBAL_IMPORT_PROPERTY, defaultValue = "true")
  boolean globalImport;

  /**
   * Indique si l'identité visuelle est active : la propriété courante ou, à défaut, l'ancienne.
   *
   * @return vrai si l'une des deux propriétés est vraie
   */
  public boolean isBrandEnabled() {
    return brandEnabled || legacyCharteEnabled;
  }

  /**
   * Cette méthode permet de construire.
   */
  public ContainerManager() {
    layout = "semibox";
    topbar = "light";
    sidebar = "dark";
    sidebarSize = "lg";
    sidebarImage = "none";
    preloader = "disable";
    theme = "saas";
    themeColors = "default";
    sidebarVisibility = "show";
    layoutStyle = "default";
    bsTheme = "";
    layoutWidth = "fluid";
    layoutPosition = "fixed";
    bodyImage = "none";
    sidebarUserShow = "";
    styleContentColorManager = "";
  }

  static final String BRAND_ENABLED_PROPERTY = "dgbf.brand.enabled";
  static final String LEGACY_CHARTE_ENABLED_PROPERTY = "dgbf.charte.enabled";
  static final String BASE_STYLE_FROM_JAR_PROPERTY = "dgbf.template.base-style-from-jar";
  static final String GLOBAL_IMPORT_PROPERTY = "dgbf.template.global-import";
}
