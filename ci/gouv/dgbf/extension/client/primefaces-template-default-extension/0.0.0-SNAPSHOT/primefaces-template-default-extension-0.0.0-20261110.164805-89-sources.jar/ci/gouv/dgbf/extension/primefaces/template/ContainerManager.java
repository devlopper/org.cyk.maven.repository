package ci.gouv.dgbf.extension.primefaces.template;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.net.URI;
import java.util.Arrays;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette class représente le gestionnaire du conteneur.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Getter
@Setter
@Named
public class ContainerManager {

  private String sidebar;
  private String layout;
  private String topbar;
  private String sidebarSize;
  private String sidebarImage;
  private String preloader;
  private String theme;
  private String themeColors;
  private String sidebarVisibility;
  private String layoutStyle;
  private String bsTheme;
  private String layoutWidth;
  private String layoutPosition;
  private String bodyImage;
  private String sidebarUserShow;
  private String styleContentColorManager;

  /**
   * Active l'identité visuelle DGBF (la charte graphique, constitution-ui.md §3.4) sur les écrans
   * privés. Faux par défaut : chaque module l'active par {@value #BRAND_ENABLED_PROPERTY} dans sa
   * configuration.
   */
  @ConfigProperty(name = BRAND_ENABLED_PROPERTY, defaultValue = "false")
  boolean brandEnabled;

  /**
   * Charge le socle de style de la disposition (Bootstrap, app.css, position.css,
   * menu.css et header.css) depuis ce jar au lieu des copies embarquées par l'application dans
   * {@code resources/assets/global}. Faux par défaut : chaque module l'active par
   * {@value #BASE_STYLE_FROM_JAR_PROPERTY} après avoir retiré ses copies.
   */
  @ConfigProperty(name = BASE_STYLE_FROM_JAR_PROPERTY, defaultValue = "false")
  boolean baseStyleFromJar;

  /**
   * Charge {@code resources/assets/global/global-import.css} de l'application. Vrai par défaut :
   * tant qu'un module y garde des feuilles (boutons, tableaux, dialogues), il doit rester chargé.
   * Un module dont ce fichier ne contient plus rien le désactive par
   * {@value #GLOBAL_IMPORT_PROPERTY} et peut alors le supprimer.
   */
  @ConfigProperty(name = GLOBAL_IMPORT_PROPERTY, defaultValue = "true")
  boolean globalImport;

  /**
   * Adresse de « Mon profil » (module user). Absente : déduite de l'adresse de la requête et de
   * {@value #USER_CONTEXT_PATH_PROPERTY} (constitution-client-quarkus-primefaces.md §5.5).
   */
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = USER_PROFILE_URL_PROPERTY)
  Optional<String> userProfileUrl = Optional.empty();

  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = USER_CONTEXT_PATH_PROPERTY, defaultValue = "/utilisateur")
  String userContextPath = "/utilisateur";

  /**
   * Adresse de « Mon activité » (module logging). Absente : déduite comme pour le profil, avec
   * {@value #LOGGING_CONTEXT_PATH_PROPERTY}.
   */
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = LOGGING_ACTIVITY_URL_PROPERTY)
  Optional<String> loggingActivityUrl = Optional.empty();

  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = LOGGING_CONTEXT_PATH_PROPERTY, defaultValue = "/logging")
  String loggingContextPath = "/logging";

  /**
   * Liste blanche des origines autorisées pour le lien « Retour à l'application ». Vide par
   * défaut, elle désactive cette fonction. Les origines sont séparées par des virgules et doivent
   * être renseignées dans chaque application hébergeuse, notamment user et logging.
   */
  @ConfigProperty(name = RETURN_ALLOWED_ORIGINS_PROPERTY)
  Optional<String> returnAllowedOrigins = Optional.empty();

  /**
   * Cette méthode donne le lien vers « Mon profil ».
   *
   * @return l'adresse configurée, sinon celle du module user sur l'hôte de la requête
   */
  public String getUserProfileLink() {
    return linkWithReturn(userProfileUrl, userContextPath, USER_PROFILE_PATH);
  }

  /**
   * Cette méthode donne le lien vers « Mon activité ».
   *
   * @return l'adresse configurée, sinon celle du module logging sur l'hôte de la requête
   */
  public String getActivityLink() {
    return linkWithReturn(loggingActivityUrl, loggingContextPath, ACTIVITY_PATH);
  }

  /**
   * Indique si une adresse de retour validée est présente dans la requête.
   *
   * @return vrai si le lien de retour peut être affiché
   */
  public boolean isReturnToApplicationVisible() {
    return getReturnToApplicationLink() != null;
  }

  /**
   * Donne l'adresse de retour validée vers l'application appelante.
   *
   * @return l'adresse autorisée ou null
   */
  public String getReturnToApplicationLink() {
    Object request = currentRequest();
    if (!(request instanceof HttpServletRequest servletRequest)) {
      return null;
    }
    String candidate = servletRequest.getParameter(RETURN_PARAMETER);
    HttpSession session = servletRequest.getSession(false);
    if (candidate != null && !candidate.isBlank() && isAllowedOrigin(candidate.strip())) {
      String validCandidate = candidate.strip();
      session = session == null ? servletRequest.getSession(true) : session;
      session.setAttribute(RETURN_SESSION_ATTRIBUTE, validCandidate);
      return validCandidate;
    }
    return session == null ? null : (String) session.getAttribute(RETURN_SESSION_ATTRIBUTE);
  }

  String link(Optional<String> configured, String targetContextPath, String targetPath) {
    Object request = currentRequest();
    if (request instanceof HttpServletRequest servletRequest) {
      return AccountLinks.resolve(configured.orElse(null), publicScheme(servletRequest),
          servletRequest.getServerName(), publicPort(servletRequest),
          servletRequest.getContextPath(), targetContextPath, targetPath);
    }
    return configured.orElse(targetContextPath + targetPath);
  }

  String linkWithReturn(Optional<String> configured, String targetContextPath, String targetPath) {
    Object request = currentRequest();
    if (request instanceof HttpServletRequest servletRequest) {
      return AccountLinks.resolveWithReturn(configured.orElse(null), publicScheme(servletRequest),
          servletRequest.getServerName(), publicPort(servletRequest),
          servletRequest.getContextPath(), targetContextPath, targetPath);
    }
    return link(configured, targetContextPath, targetPath);
  }

  /**
   * Protocole vu par le navigateur : derrière un proxy qui termine le TLS, la requête arrive en
   * http et seul l'en-tête X-Forwarded-Proto porte le https public.
   */
  static String publicScheme(HttpServletRequest request) {
    String forwarded = firstValue(request.getHeader("X-Forwarded-Proto"));
    if ("https".equalsIgnoreCase(forwarded) || "http".equalsIgnoreCase(forwarded)) {
      return forwarded.toLowerCase(Locale.ROOT);
    }
    return request.getScheme();
  }

  /** Port vu par le navigateur ; 0 (défaut du protocole) si seul le protocole est transmis. */
  static int publicPort(HttpServletRequest request) {
    String forwardedPort = firstValue(request.getHeader("X-Forwarded-Port"));
    if (forwardedPort != null) {
      try {
        return Integer.parseInt(forwardedPort);
      } catch (NumberFormatException exception) {
        return request.getServerPort();
      }
    }
    return firstValue(request.getHeader("X-Forwarded-Proto")) == null ? request.getServerPort() : 0;
  }

  private static String firstValue(String header) {
    if (header == null || header.isBlank()) {
      return null;
    }
    return header.split(",")[0].strip();
  }

  boolean isAllowedOrigin(String candidate) {
    try {
      URI uri = URI.create(candidate);
      if (uri.getScheme() == null || uri.getHost() == null || uri.getRawQuery() != null
          || uri.getRawFragment() != null) {
        return false;
      }
      String origin = uri.getScheme() + "://" + uri.getRawAuthority();
      Set<String> allowed = Arrays.stream(returnAllowedOrigins.orElse("").split(","))
          .map(String::strip).filter(value -> !value.isEmpty()).collect(Collectors.toSet());
      return allowed.contains(origin);
    } catch (IllegalArgumentException exception) {
      return false;
    }
  }

  Object currentRequest() {
    FacesContext context = FacesContext.getCurrentInstance();
    return context == null ? null : context.getExternalContext().getRequest();
  }

  /**
   * Indique si l'identité visuelle est active.
   *
   * @return la valeur de {@value #BRAND_ENABLED_PROPERTY}
   */
  public boolean isBrandEnabled() {
    return brandEnabled;
  }

  /**
   * Cette méthode calcule les initiales de l'avatar d'un utilisateur.
   *
   * @param names le nom et les prénoms
   * @return les initiales, vides si le nom ne contient aucune lettre
   */
  public String avatarInitials(String names) {
    return UserAvatar.initials(names);
  }

  /**
   * Cette méthode calcule la teinte de l'avatar d'un utilisateur.
   *
   * @param names le nom et les prénoms
   * @return l'indice de teinte, stable pour un même nom
   */
  public int avatarTone(String names) {
    return UserAvatar.tone(names);
  }

  /**
   * Cette méthode permet de construire.
   */
  public ContainerManager() {
    layout = "semibox";
    topbar = "light";
    sidebar = "dark";
    sidebarSize = "lg";
    sidebarImage = "none";
    preloader = "disable";
    theme = "saas";
    themeColors = "default";
    sidebarVisibility = "show";
    layoutStyle = "default";
    bsTheme = "";
    layoutWidth = "fluid";
    layoutPosition = "fixed";
    bodyImage = "none";
    sidebarUserShow = "";
    styleContentColorManager = "";
  }

  static final String BRAND_ENABLED_PROPERTY = "dgbf.brand.enabled";
  static final String BASE_STYLE_FROM_JAR_PROPERTY = "dgbf.template.base-style-from-jar";
  static final String GLOBAL_IMPORT_PROPERTY = "dgbf.template.global-import";
  static final String USER_PROFILE_URL_PROPERTY = "dgbf.user.profile.url";
  static final String USER_CONTEXT_PATH_PROPERTY = "dgbf.user.context-path";
  static final String LOGGING_ACTIVITY_URL_PROPERTY = "dgbf.logging.activity.url";
  static final String LOGGING_CONTEXT_PATH_PROPERTY = "dgbf.logging.context-path";
  static final String RETURN_ALLOWED_ORIGINS_PROPERTY = "dgbf.account.return.allowed-origins";
  static final String RETURN_PARAMETER = "return";
  static final String RETURN_SESSION_ATTRIBUTE = ContainerManager.class.getName() + ".return";
  static final String USER_PROFILE_PATH = "/private/connecteduser/read/applications.jsf";
  static final String ACTIVITY_PATH = "/private/activity/user/index.jsf";
}
