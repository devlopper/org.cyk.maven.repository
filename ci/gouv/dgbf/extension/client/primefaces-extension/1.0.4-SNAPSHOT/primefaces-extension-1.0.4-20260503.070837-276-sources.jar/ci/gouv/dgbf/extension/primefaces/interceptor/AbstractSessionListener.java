package ci.gouv.dgbf.extension.primefaces.interceptor;

import ci.gouv.dgbf.extension.core.UriPathBuilder;
import ci.gouv.dgbf.extension.primefaces.ApplicationManager;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.HttpSessionEvent;
import jakarta.servlet.http.HttpSessionListener;
import java.util.Set;

/**
 * Cette classe représente la base d'écouteur de session.
 *
 * @author Christian
 *
 */
public abstract class AbstractSessionListener implements HttpSessionListener {

  @Inject
  ApplicationManager applicationManager;

  @Override
  public void sessionCreated(HttpSessionEvent event) {
    HttpSessionListener.super.sessionCreated(event);
    setHomePageUrl(event.getSession());
    onSessionCreated(event);
  }
  
  protected void setHomePageUrl(HttpSession session) {
    UriPathBuilder uriPathBuilder = new UriPathBuilder();
    uriPathBuilder.list().add(session.getServletContext().getContextPath());
    String path = applicationManager.getRoleHomePagePathOrHomePagePath(getRolesCodes());
    uriPathBuilder.list().add(path);
    session.setAttribute(UserHomePageRedirectionFilter.HOME_PAGE_URL_ATTRIBUTE_NAME,
        uriPathBuilder.build());
  }

  protected abstract Set<String> getRolesCodes();
  
  protected void onSessionCreated(HttpSessionEvent event) {
    
  }
}
