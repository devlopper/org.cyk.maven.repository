package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifier;
import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.List;
import java.util.Optional;

/**
 * Cette classe représente un ensemble de fonctions à être utiliser dans le language d'expression
 * EL.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Named("elFunctions")
public class ExpressionLanguageFunctions {

  /**
   * {@link StringCore#capitalizeFirstLetter}.
   *
   * @param string chaine de caractères
   * @return chaine de caractères avec la première lettre en majuscule
   */
  public String capitalizeFirstLetter(String string) {
    return StringCore.capitalizeFirstLetter(string);
  }

  /**
   * {@link StringCore#getListElementAt}.
   *
   * @param list liste
   * @param index index
   * @return l'élément a l'index donné
   */
  public Object getListElementAt(List<?> list, Integer index) {
    return CollectionCore.getListElementAt(list, index);
  }

  /**
   * Cette méthode permet d'obtenir un identifiant ou d'en générer un si blanc.
   *
   * @param object objet
   * @return identifiant
   */
  public String getIdentifierOrGenerateIfBlank(Object object) {
    return Optional.ofNullable(object).filter(HasIdentifier.class::isInstance)
        .map(HasIdentifier.class::cast).map(HasIdentifier::getIdentifier)
        .filter(StringCore::isNotBlank).orElseGet(AbstractWidget::generateIdentifier);
  }
}
