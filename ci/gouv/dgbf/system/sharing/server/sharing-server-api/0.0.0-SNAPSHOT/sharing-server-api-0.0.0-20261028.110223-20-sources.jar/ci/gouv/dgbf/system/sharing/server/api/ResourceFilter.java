package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasIsLocalAuthority;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasIsNationalPublicInstitution;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ResourceFilter extends AbstractResourceOrReceiverFilter
    implements FilterHasTypeCode, FilterHasUserName, FilterHasIsNationalPublicInstitution,
    FilterHasIsLocalAuthority {

  /**
   * {@link ResourceType}.
   */
  ResourceType type;

  /**
   * Code {@link ResourceType}.
   */
  String typeCode;

  /**
   * Nom d'utilisateur.
   */
  String userName;

  /**
   * Code du domaine de {@link #userName} (realm Keycloak). Le nom n'est unique que dans son
   * domaine. Absent : domaine par défaut du serveur (transition, TCH_SHA_070).
   */
  String userDomainCode;

  /**
   * Est EPN.
   */
  Boolean isNationalPublicInstitution;

  /**
   * Est Collectivité.
   */
  Boolean isLocalAuthority;

  /**
   * Nom de l'utilisateur pour lequel calculer le niveau de visibilité effectif. Ne filtre pas :
   * à ne pas confondre avec {@link #userName} (ressources de l'utilisateur).
   */
  String visibilityLevelUserName;

  /**
   * Code du domaine de {@link #visibilityLevelUserName} (realm Keycloak). Obligatoire avec lui :
   * le nom n'est unique que dans son domaine.
   */
  String visibilityLevelUserDomainCode;

  /**
   * Codes des niveaux de visibilité effectifs à conserver. Exige {@link #visibilityLevelUserName}.
   *
   * @see VisibilityLevelCode
   */
  Set<String> visibilityLevelCodes;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ResourceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ResourceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    type = getType(filter);
    updateTypeCode(filter);
    updateUserName(filter);
    userDomainCode = getUserDomainCode(filter);
    updateIsNationalPublicInstitution(filter);
    updateIsLocalAuthority(filter);
    visibilityLevelUserName = getVisibilityLevelUserName(filter);
    visibilityLevelUserDomainCode = getVisibilityLevelUserDomainCode(filter);
    visibilityLevelCodes = getVisibilityLevelCodes(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setType(filter, type);
    updateFilterTypeCode(filter);
    updateFilterUserName(filter);
    setUserDomainCode(filter, userDomainCode);
    updateFilterIsNationalPublicInstitution(filter);
    updateFilterIsLocalAuthority(filter);
    setVisibilityLevelUserName(filter, visibilityLevelUserName);
    setVisibilityLevelUserDomainCode(filter, visibilityLevelUserDomainCode);
    setVisibilityLevelCodes(filter, visibilityLevelCodes);
  }

  /**
   * Cette méthode permet d'assigner le nom de l'utilisateur pour lequel calculer le niveau de
   * visibilité.
   *
   * @param filter filtre
   * @param visibilityLevelUserName nom d'utilisateur
   */
  public static void setVisibilityLevelUserName(FilterDto filter, String visibilityLevelUserName) {
    set(filter, JSON_VISIBILITY_LEVEL_USER_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(visibilityLevelUserName));
  }

  /**
   * Cette méthode permet d'obtenir le nom de l'utilisateur pour lequel calculer le niveau de
   * visibilité.
   *
   * @param filter filtre
   * @return nom d'utilisateur
   */
  public static String getVisibilityLevelUserName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_VISIBILITY_LEVEL_USER_NAME));
  }

  /**
   * Cette méthode permet d'assigner le code du domaine de l'utilisateur pour lequel calculer le
   * niveau de visibilité.
   *
   * @param filter filtre
   * @param visibilityLevelUserDomainCode code du domaine
   */
  public static void setVisibilityLevelUserDomainCode(FilterDto filter,
      String visibilityLevelUserDomainCode) {
    set(filter, JSON_VISIBILITY_LEVEL_USER_DOMAIN_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(visibilityLevelUserDomainCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du domaine de l'utilisateur pour lequel calculer le
   * niveau de visibilité.
   *
   * @param filter filtre
   * @return code du domaine
   */
  public static String getVisibilityLevelUserDomainCode(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_VISIBILITY_LEVEL_USER_DOMAIN_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code du domaine de l'utilisateur ({@link #userName}).
   *
   * @param filter filtre
   * @param userDomainCode code du domaine
   */
  public static void setUserDomainCode(FilterDto filter, String userDomainCode) {
    set(filter, JSON_USER_DOMAIN_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(userDomainCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du domaine de l'utilisateur ({@link #userName}).
   *
   * @param filter filtre
   * @return code du domaine
   */
  public static String getUserDomainCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_DOMAIN_CODE));
  }

  /**
   * Cette méthode permet d'assigner les codes des niveaux de visibilité effectifs à conserver.
   *
   * @param filter filtre
   * @param codes codes {@link VisibilityLevelCode}
   */
  public static void setVisibilityLevelCodes(FilterDto filter, Set<String> codes) {
    set(filter, JSON_VISIBILITY_LEVEL_CODES, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(codes));
  }

  /**
   * Cette méthode permet d'obtenir les codes des niveaux de visibilité effectifs à conserver.
   *
   * @param filter filtre
   * @return codes {@link VisibilityLevelCode}
   */
  public static Set<String> getVisibilityLevelCodes(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_VISIBILITY_LEVEL_CODES));
  }

  /**
   * Cette méthode permet d'assigner la {@link ResourceType}.
   *
   * @param filter filtre
   * @param type {@link ResourceType}
   */
  public static void setType(FilterDto filter, ResourceType type) {
    set(filter, JSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ResourceType}.
   *
   * @param filter filtre
   * @return {@link ResourceType}
   */
  public static ResourceType getType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, ResourceType.class));
  }

  /**
   * Identifiant json champ {@link #visibilityLevelUserName}.
   */
  public static final String JSON_VISIBILITY_LEVEL_USER_NAME = "nomUtilisateurNiveauVisibilite";

  /**
   * Identifiant json champ {@link #visibilityLevelUserDomainCode}.
   */
  public static final String JSON_VISIBILITY_LEVEL_USER_DOMAIN_CODE =
      "codeDomaineUtilisateurNiveauVisibilite";

  /**
   * Identifiant json champ {@link #userDomainCode}.
   */
  public static final String JSON_USER_DOMAIN_CODE = SharingFilter.JSON_USER_DOMAIN_CODE;

  /**
   * Identifiant json champ {@link #visibilityLevelCodes}.
   */
  public static final String JSON_VISIBILITY_LEVEL_CODES = "codesNiveauxVisibilite";
}
