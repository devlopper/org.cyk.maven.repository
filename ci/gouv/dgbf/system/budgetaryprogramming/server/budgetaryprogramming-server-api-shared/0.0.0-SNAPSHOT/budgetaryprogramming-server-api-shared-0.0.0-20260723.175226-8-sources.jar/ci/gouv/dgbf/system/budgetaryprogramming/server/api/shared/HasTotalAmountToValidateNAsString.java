package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToValidateNAsString {

  /**
   * Obtient le montant total à valider pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant total à valider pour l'année N sous forme de chaîne de caractères
   */
  String getTotalAmountToValidateNAsString();

  /**
   * Définit le montant total à valider pour l'année N, sous forme de chaîne de caractères.
   *
   * @param totalAmountToValidateNAsString le montant total à valider pour l'année N sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToValidateNAsString(String totalAmountToValidateNAsString);

  /**
   * Identifiant java du montant total à valider pour l'année N, sous forme de chaîne de caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N_AS_STRING = "totalAmountToValidateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName