package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PhaseDto}.
*
* @author Stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-29T18:07:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PhaseRequestMapperImpl implements PhaseRequestMapper {

    @Override
    public PhaseService.PhaseCreateRequestDto mapCreate(PhaseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PhaseService.PhaseCreateRequestDto phaseCreateRequestDto = new PhaseService.PhaseCreateRequestDto();

        phaseCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        phaseCreateRequestDto.setCode( arg0.getCode() );
        phaseCreateRequestDto.setName( arg0.getName() );
        phaseCreateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        phaseCreateRequestDto.setTriennialProgramActivityAsString( arg0.getTriennialProgramActivityAsString() );
        phaseCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );
        phaseCreateRequestDto.setComment( arg0.getComment() );
        phaseCreateRequestDto.setStartDate( arg0.getStartDate() );
        phaseCreateRequestDto.setEndDate( arg0.getEndDate() );

        return phaseCreateRequestDto;
    }

    @Override
    public PhaseService.PhaseUpdateRequestDto mapUpdate(PhaseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PhaseService.PhaseUpdateRequestDto phaseUpdateRequestDto = new PhaseService.PhaseUpdateRequestDto();

        phaseUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        phaseUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        phaseUpdateRequestDto.setCode( arg0.getCode() );
        phaseUpdateRequestDto.setName( arg0.getName() );
        phaseUpdateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        phaseUpdateRequestDto.setTriennialProgramActivityAsString( arg0.getTriennialProgramActivityAsString() );
        phaseUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );
        phaseUpdateRequestDto.setComment( arg0.getComment() );
        phaseUpdateRequestDto.setStartDate( arg0.getStartDate() );
        phaseUpdateRequestDto.setEndDate( arg0.getEndDate() );

        return phaseUpdateRequestDto;
    }
}
