package ci.gouv.dgbf.system.identity.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'identité.
 *
 * @author Christian
 */
public interface HasIdentityAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'identité.
   *
   * @return identifiant de l'identité
   */
  String getIdentityAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'identité.
   *
   * @param identityAsString identifiant de l'identité
   */
  void setIdentityAsString(String identityAsString);

  /**
   * Identifiant java de représentation en chaine de caractères de l'identité.
   */
  String FIELD_IDENTITY_AS_STRING = "identityAsString";
}
