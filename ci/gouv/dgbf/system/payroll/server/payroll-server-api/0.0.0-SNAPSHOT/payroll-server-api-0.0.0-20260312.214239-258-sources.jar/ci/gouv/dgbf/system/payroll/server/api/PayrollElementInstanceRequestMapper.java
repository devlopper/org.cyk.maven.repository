package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollElementInstanceDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollElementInstanceDto}.

    @author stephane
               """)
public interface PayrollElementInstanceRequestMapper
    extends RequestMapper<PayrollElementInstanceDto, 
            PayrollElementInstanceCreateRequestDto, PayrollElementInstanceUpdateRequestDto> {

}
