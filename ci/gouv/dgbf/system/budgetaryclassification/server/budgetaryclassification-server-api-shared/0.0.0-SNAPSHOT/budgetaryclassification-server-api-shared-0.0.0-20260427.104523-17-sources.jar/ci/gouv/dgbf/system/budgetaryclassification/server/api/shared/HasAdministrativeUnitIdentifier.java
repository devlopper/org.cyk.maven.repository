package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de unité administrative.
   *
   * @return identifiant de unité administrative
   */
  String getAdministrativeUnitIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de unité administrative.
   *
   * @param identifier identifiant de unité administrative
   */
  void setAdministrativeUnitIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de l'unité administrative.
   */
  String FIELD_ADMINISTRATIVE_UNIT_IDENTIFIER = "administrativeUnitIdentifier";
}
