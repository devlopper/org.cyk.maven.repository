package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ProcessingFilter extends AbstractIdentifiableFilter {

  /**
   * {@link ProcessingStatus}.
   */
  ProcessingStatus status;

  /**
   * Code {@link ProcessingStatus}.
   */
  String statusCode;

  /**
   * Est en retard.
   */
  Boolean isLate;

  /**
   * Cette méthode permet d'instancier.
   *
   * @param filter filtre
   */
  public ProcessingFilter(FilterDto filter) {
    super(filter);
  }

  /**
   * Cette méthode permet d'instancier.
   *
   */
  public ProcessingFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    status = getStatus(filter);
    statusCode = getStatusCode(filter);
    isLate = getIsLate(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setStatus(filter, status);
    setStatusCode(filter, statusCode);
    setIsLate(filter, isLate);
  }

  /**
   * Cette méthode permet d'assigner {@link ProcessingStatus} au filtre.
   *
   * @param filter filtre
   * @param status {@link ProcessingStatus}
   */
  public static void setStatus(FilterDto filter, ProcessingStatus status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsEnum(status));
  }

  /**
   * Cette méthode permet d'obtenir {@link ProcessingStatus} du filtre.
   *
   * @param filter filtre
   * @return {@link ProcessingStatus}
   */
  public static ProcessingStatus getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_STATUS, ProcessingStatus.class));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link ProcessingStatus}.
   *
   * @param filter filtre
   * @return le code de {@link ProcessingStatus}
   */
  public static String getStatusCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link ProcessingStatus}.
   *
   * @param filter filtre
   * @param statusCode code de {@link ProcessingStatus}
   */
  public static void setStatusCode(FilterDto filter, String statusCode) {
    set(filter, JSON_STATUS_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(statusCode));
  }

  /**
   * Cette méthode permet d'obtenir est en retard.
   *
   * @param filter filtre
   * @return est en retard
   */
  public static Boolean getIsLate(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LATE));
  }

  /**
   * Cette méthode permet d'assigner est en retard.
   *
   * @param filter filtre
   * @param isLate est en retard
   */
  public static void setIsLate(FilterDto filter, Boolean isLate) {
    set(filter, JSON_IS_LATE, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isLate));
  }

  /**
   * {@link ProcessingDto#JSON_STATUS}.
   */
  public static final String JSON_STATUS = ProcessingDto.JSON_STATUS;

  /**
   * {@link ProcessingDto#JSON_STATUS_CODE}.
   */
  public static final String JSON_STATUS_CODE = ProcessingDto.JSON_STATUS_CODE;

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = ProcessingDto.JSON_IS_LATE;
}
