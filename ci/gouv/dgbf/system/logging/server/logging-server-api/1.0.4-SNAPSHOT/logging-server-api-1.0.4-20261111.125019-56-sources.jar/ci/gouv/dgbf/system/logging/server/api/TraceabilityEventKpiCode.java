package ci.gouv.dgbf.system.logging.server.api;

/**
 * Codes des indicateurs du jeu de données {@link TraceabilityEventChartCode#KPIS}.
 *
 * @author Christian
 *
 */
public interface TraceabilityEventKpiCode {

  /**
   * Nombre total d'événements de la période.
   */
  String TOTAL = "TOTAL";

  /**
   * Nombre d'événements de niveau erreur.
   */
  String ERROR = "ERREUR";

  /**
   * Nombre d'événements rattachés à une session.
   */
  String CORRELATION = "CORRELATION";

  /**
   * Nombre d'événements contenant des données masquées.
   */
  String MASKING = "MASQUAGE";
}
