package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.AbstractLazyDataModel;
import ci.gouv.dgbf.extension.primefaces.FilterDtoGetter;
import ci.gouv.dgbf.extension.server.service.api.AbstractFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.inject.Inject;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur de lecture de données.
 *
 * @author Christian
 *
 */
public abstract class AbstractDataController<T extends AbstractIdentifiableDto,
    R extends AbstractGetByPageResponseDto<T>, F extends AbstractFilter>
    extends AbstractController {

  @Getter
  @Setter
  protected String dataName;
  
  @Getter
  protected LazyDataModel model;

  @Getter
  @Setter
  protected F filter;

  @Getter
  @Setter
  protected Supplier<Object> filterSupplier;

  @Inject
  FilterDtoGetter filterDtoGetter;

  /**
   * Cette méthode permet de construire une instance.
   *
   */
  protected AbstractDataController(String dataName) {
    model = new LazyDataModel();
    this.dataName = dataName;
  }

  protected abstract Object getClient();
  
  /**
   * Cette classe représente la source de données.
   *
   * @author Christian
   *
   */
  class LazyDataModel extends AbstractLazyDataModel<T, R> {

    protected LazyDataModel() {
      super(dataName);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected R serve(PageDto page) {
      FilterDto filterDto = filterDtoGetter.get(filter, filterSupplier);
      if (getClient() instanceof GetMany<?> c) {
        return (R) c.getMany(null, filterDto, page, userIdentifier, null);
      }
      throw new IllegalStateException("L'obtention de données n'a pas été implémentée.");
    }
  }
}
