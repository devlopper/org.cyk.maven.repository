package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasIsActivatedDto;

/**
 * Cette interface représente le filtre sur l'interrupteur d'activation (R48, RG_REP_SOU_15) de
 * {@link HasIsActivatedDto}.
 *
 * @author akm
 *
 */
public interface IsActivatedFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir l'interrupteur d'activation d'un filtre.
   *
   * @param filter filtre
   * @return interrupteur d'activation
   */
  static Boolean get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsBooleanByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner l'interrupteur d'activation d'un filtre.
   *
   * @param filter filtre
   * @param isActivated interrupteur d'activation
   */
  static void set(FilterDto filter, Boolean isActivated) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isActivated));
  }

  /**
   * Identifiant json du filtre.
   */
  String JSON_KEY = HasIsActivatedDto.JSON_IS_ACTIVATED;
}
