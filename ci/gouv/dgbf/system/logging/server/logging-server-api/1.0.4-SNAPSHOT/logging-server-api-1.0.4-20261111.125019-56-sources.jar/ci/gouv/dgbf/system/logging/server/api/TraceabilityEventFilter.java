package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeFromDate;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeToDate;
import ci.gouv.dgbf.extension.server.service.api.filter.LocalDateTimeFromDateFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.LocalDateTimeToDateFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import lombok.Getter;
import lombok.Setter;

/** Filtre de recherche transverse des événements de traçabilité. */
@Getter
@Setter
public class TraceabilityEventFilter extends AbstractIdentifiableFilter
    implements FilterHasLocalDateTimeFromDate, FilterHasLocalDateTimeToDate {

  /** Durée maximale autorisée pour une période en jours (RG_LOG_TRA_11). */
  public static final long MAX_PERIOD_DAYS = 90L;

  private TraceabilityEventCategory category;
  private String auditSession;
  private TraceabilityActionType actionType;
  private String messageSummary;
  private String processIdentifier;
  private String source;
  private String record;
  private String operation;
  private LocalDateTime dateFrom;
  private LocalDateTime dateTo;
  private String chartCode;

  public TraceabilityEventFilter() {}

  public TraceabilityEventFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  public LocalDateTime getFromDate() {
    return dateFrom;
  }

  @Override
  public void setFromDate(LocalDateTime fromDate) {
    this.dateFrom = fromDate;
  }

  @Override
  public LocalDateTime getToDate() {
    return dateTo;
  }

  @Override
  public void setToDate(LocalDateTime toDate) {
    this.dateTo = toDate;
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    category = get(filter,
        d -> d.getFieldValueAsEnum(JSON_CATEGORY, TraceabilityEventCategory.class));
    actionType = get(filter,
        d -> d.getFieldValueAsEnum(JSON_ACTION_TYPE, TraceabilityActionType.class));
    auditSession = get(filter, d -> d.getFieldValueAsStringByName(JSON_AUDIT_SESSION));
    messageSummary = get(filter, d -> d.getFieldValueAsStringByName(JSON_MESSAGE_SUMMARY));
    processIdentifier = get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESS_IDENTIFIER));
    source = get(filter, d -> d.getFieldValueAsStringByName(JSON_SOURCE));
    record = get(filter, d -> d.getFieldValueAsStringByName(JSON_RECORD));
    operation = get(filter, d -> d.getFieldValueAsStringByName(JSON_OPERATION));
    dateFrom = get(filter, d -> d.getFieldValueAsDateTimeByName(JSON_DATE_FROM));
    if (dateFrom == null) {
      dateFrom = LocalDateTimeFromDateFilter.get(filter);
    }
    dateTo = get(filter, d -> d.getFieldValueAsDateTimeByName(JSON_DATE_TO));
    if (dateTo == null) {
      dateTo = LocalDateTimeToDateFilter.get(filter);
    }
    chartCode = getChartCode(filter);
  }

  @Override
  public FilterDto toDto() {
    FilterDto filter = new FilterDto();
    super.toDto(filter);
    filter.addCriteria(JSON_CATEGORY, category);
    filter.addCriteria(JSON_ACTION_TYPE, actionType);
    filter.addCriteria(JSON_AUDIT_SESSION, auditSession);
    filter.addCriteria(JSON_MESSAGE_SUMMARY, messageSummary);
    filter.addCriteria(JSON_PROCESS_IDENTIFIER, processIdentifier);
    filter.addCriteria(JSON_SOURCE, source);
    filter.addCriteria(JSON_RECORD, record);
    filter.addCriteria(JSON_OPERATION, operation);
    set(filter, JSON_DATE_FROM, f -> f.getValueAsDateTime(), f -> f.setValueAsDateTime(dateFrom));
    LocalDateTimeFromDateFilter.set(filter, dateFrom);
    set(filter, JSON_DATE_TO, f -> f.getValueAsDateTime(), f -> f.setValueAsDateTime(dateTo));
    LocalDateTimeToDateFilter.set(filter, dateTo);
    setChartCode(filter, chartCode);
    return filter;
  }

  /**
   * Valide la période selon les exigences de RG_LOG_TRA_11.
   *
   * @param from date de début
   * @param to date de fin
   * @throws IllegalArgumentException si la période est invalide ou dépasse 90 jours
   */
  public static void validatePeriod(LocalDateTime from, LocalDateTime to) {
    if (from == null || to == null) {
      throw new IllegalArgumentException(
          "La période est obligatoire (dateDebut et dateFin requises)");
    }
    if (from.isAfter(to)) {
      throw new IllegalArgumentException(
          "La date de début doit être antérieure ou égale à la date de fin");
    }
    long days = ChronoUnit.DAYS.between(from, to);
    if (days > MAX_PERIOD_DAYS) {
      throw new IllegalArgumentException(
          String.format("La période (%d jours) dépasse la durée maximale autorisée (%d jours)",
              days, MAX_PERIOD_DAYS));
    }
  }

  /**
   * Obtient le code du graphique.
   *
   * @param filter filtre
   * @return code graphique
   */
  public static String getChartCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHART_CODE));
  }

  /**
   * Assigne le code du graphique.
   *
   * @param filter filtre
   * @param chartCode code graphique
   */
  public static void setChartCode(FilterDto filter, String chartCode) {
    set(filter, JSON_CHART_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(chartCode));
  }

  public static final String JSON_CATEGORY = "category";
  public static final String JSON_ACTION_TYPE = "actionType";
  public static final String JSON_AUDIT_SESSION = "auditSession";
  public static final String JSON_MESSAGE_SUMMARY = "messageSummary";
  public static final String JSON_PROCESS_IDENTIFIER = "processIdentifier";
  public static final String JSON_SOURCE = "source";
  public static final String JSON_RECORD = "record";
  public static final String JSON_OPERATION = "operation";
  public static final String JSON_DATE_FROM = "dateFrom";
  public static final String JSON_DATE_TO = "dateTo";
  public static final String JSON_CHART_CODE = "chartCode";
}
