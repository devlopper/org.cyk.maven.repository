package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'une date.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInputOneDate<T> extends AbstractInputDate<T> {

}
