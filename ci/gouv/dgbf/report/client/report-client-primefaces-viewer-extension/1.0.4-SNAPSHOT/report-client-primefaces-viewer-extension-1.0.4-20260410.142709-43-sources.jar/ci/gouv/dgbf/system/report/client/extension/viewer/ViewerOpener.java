package ci.gouv.dgbf.system.report.client.extension.viewer;

import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente un ouvreur de visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerOpener {
  private static final Logger LOGGER = Logger.getLogger(ViewerOpener.class.getName());

  @Inject
  ViewerOpenerScriptBuilder scriptBuilder;

  /**
   * Cette méthode permet permet d'ouvrir un visualisateur de rapport.
   *
   */
  public void open() {
    if (scriptBuilder == null) {
      throw new IllegalArgumentException(
          "Le constructeur du script d'ouverture du visualisateur de rapport est obligatoire");
    }
    String script = scriptBuilder.build();
    PrimeFaces.current().executeScript(script);
    System.out.println("ViewerOpener.open() ########### EXECUTED NEW ############### : " + script);
    LOGGER.log(Level.FINER, "Visualisateur de rapport ouvert. {0}", script);
  }

  /**
   * Cette méthode permet d'obtenir un constructeur de script d'ouverture de visualisateur.
   *
   * @return constructeur de script d'ouverture de visualisateur
   */
  public ViewerOpenerScriptBuilder scriptBuilder() {
    if (scriptBuilder == null) {
      scriptBuilder = new ViewerOpenerScriptBuilder();
    }
    return scriptBuilder;
  }
}
