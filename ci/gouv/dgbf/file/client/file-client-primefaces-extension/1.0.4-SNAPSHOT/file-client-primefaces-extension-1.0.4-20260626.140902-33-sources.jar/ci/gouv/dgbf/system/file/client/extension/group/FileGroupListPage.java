package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste des fichiers de groupe.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FileGroupListPage extends AbstractPage {

  @Inject
  @Getter
  FileGroupController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste des fichiers de groupe";
    controller.initialize();
  }
  
  public static final String OUTCOME = "fileGroupListPage";
  public static final String OUTCOME_WITHOUT_TEMPLATE = "fileGroupListWithoutTemplatePage";
}
