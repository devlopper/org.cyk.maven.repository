package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de consultation de {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityGroupReadPage extends AbstractPage {

  @Inject
  IdentityGroupClient client;

  IdentityGroupDto identityGroup;

  @Inject
  @Getter
  IdentityGroupRoleController identityGroupRoleController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture " + IdentityGroupDto.NAME;

    identityGroup = client.getByIdentifier(getRequestParameterIdentifier(),
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER), userIdentifier,
        null);

    identityGroupRoleController.getFilterController().getFilter()
        .setIdentityGroupIdentifier(identityGroup.getIdentifier());
    identityGroupRoleController.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "identityGroupReadPage";
}
