package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.RoleClient;
import ci.gouv.dgbf.system.identity.server.api.RoleDto;
import ci.gouv.dgbf.system.identity.server.api.RoleRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.RoleService;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link RoleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class RoleController extends AbstractController {

  @Inject
  RoleClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  RoleRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = RoleDto.NAME;

    listController.setEntityClass(RoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(RoleService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      RoleCreateRequestDto request = requestMapper.mapCreate((RoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
    
    listController.getUpdateController().setFunction(entity -> {
      RoleUpdateRequestDto request = requestMapper.mapUpdate((RoleDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
  }
}
