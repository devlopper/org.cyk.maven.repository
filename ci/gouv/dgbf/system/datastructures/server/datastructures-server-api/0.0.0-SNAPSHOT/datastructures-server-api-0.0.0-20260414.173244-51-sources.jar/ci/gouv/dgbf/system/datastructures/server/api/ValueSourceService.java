package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasLongTotalDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueSourceDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ValueSourceService.PATH)
@Tag(name = "Gestion des sources de valeur")
public interface ValueSourceService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "sources-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueSourceSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe.
     *
     * @return l'identifiant du groupe
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe.
     *
     * @param groupIdentifier l'identifiant du groupe
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir le nom de l'attribut.
     *
     * @return le nom de l'attribut
     */
    String getAttributeName();

    /**
     * Cette méthode permet d'assigner le nom de l'attribut.
     *
     * @param attributeName le nom de l'attribut
     */
    void setAttributeName(String attributeName);

    /**
     * Cette méthode permet d'obtenir le type de valeur.
     *
     * @return le type de valeur
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner le type de valeur.
     *
     * @param valueType le type de valeur
     */
    void setValueType(ValueType valueType);

    /**
     * {@link HasGroupIdentifierDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link HasAttributeNameDto#JSON_ATTRIBUTE_NAME}.
     */
    String JSON_ATTRIBUTE_NAME = HasAttributeNameDto.JSON_ATTRIBUTE_NAME;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SOURCE_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueSourceCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ValueSourceSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_ATTRIBUTE_NAME)
    private String attributeName;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSourceGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueSourceGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueSourceDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueSourceDto> datas;
  }

  /**
   * Identifiant du service d'obtention des valeurs.
   */
  String GET_VALUES_IDENTIFIER = "OBTENTION_VALEURS_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention des valeurs.
   */
  String GET_VALUES_PATH = "obtention/valeurs";

  /**
   * Cette méthode permet d'obtenir les valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSourceGetValuesResponseDto.class))})
  Response getValues(ValueSourceGetValuesRequestDto request);

  /**
   * Cette classe représente la requête d'obtention des valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGetValuesRequestDto extends ByIdentifierRequestDto {
    /**
     * Page.
     */
    @JsonbProperty(JSON_PAGE)
    PageDto page;

    /**
     * Identifiant json {@link #page}.
     */
    public static final String JSON_PAGE = "page";
  }

  /**
   * Cette classe représente la réponse d'obtention des valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGetValuesResponseDto extends IdentifiableResponseDto implements HasLongTotalDto {

    @JsonbProperty("valeurs")
    private List<String> values;

    @JsonbProperty(JSON_TOTAL)
    private Long total;
  }

  /**
   * Identifiant du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_VALEURS_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_PATH = "obtention/nombre-valeurs";

  /**
   * Cette méthode permet d'obtenir le nombre de valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSourceGetValuesCountResponseDto.class))})
  Response getValuesCount(ByIdentifierRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention du nombre de valeurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceGetValuesCountResponseDto extends IdentifiableResponseDto
      implements HasLongTotalDto {

    @JsonbProperty(JSON_TOTAL)
    private Long total;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSourceDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SOURCE_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSourceDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SOURCE_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueSourceUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSourceUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ValueSourceSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_ATTRIBUTE_NAME)
    private String attributeName;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SOURCE_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueSourceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
