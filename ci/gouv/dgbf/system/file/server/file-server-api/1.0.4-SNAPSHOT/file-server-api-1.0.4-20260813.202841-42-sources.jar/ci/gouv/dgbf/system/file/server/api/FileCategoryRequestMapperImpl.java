package ci.gouv.dgbf.system.file.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FileCategoryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-13T20:29:04+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FileCategoryRequestMapperImpl implements FileCategoryRequestMapper {

    @Override
    public FileCategoryService.FileCategoryCreateRequestDto mapCreate(FileCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileCategoryService.FileCategoryCreateRequestDto fileCategoryCreateRequestDto = new FileCategoryService.FileCategoryCreateRequestDto();

        fileCategoryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileCategoryCreateRequestDto.setCode( arg0.getCode() );
        fileCategoryCreateRequestDto.setName( arg0.getName() );

        return fileCategoryCreateRequestDto;
    }

    @Override
    public FileCategoryService.FileCategoryUpdateRequestDto mapUpdate(FileCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileCategoryService.FileCategoryUpdateRequestDto fileCategoryUpdateRequestDto = new FileCategoryService.FileCategoryUpdateRequestDto();

        fileCategoryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileCategoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fileCategoryUpdateRequestDto.setCode( arg0.getCode() );
        fileCategoryUpdateRequestDto.setName( arg0.getName() );

        return fileCategoryUpdateRequestDto;
    }
}
