package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une phase.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PhaseDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant de {@link TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
  private String triennialProgramActivityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING)
  private String triennialProgramActivityAsString;
  
  /**
   * Numéro de la phase {@link PhaseDto}.
   */
  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;
  
  /**
   * Commentaire {@link PhaseDto}.
   */
  @JsonbProperty(JSON_COMMENT)
  private String comment;


  /**
   * Commentaire {@link PhaseDto}.
   */
  @JsonbProperty(JSON_REDUCED_COMMENT)
  private String reducedComment;
  
  /**
   * Date de début {@link PhaseDto}.
   */
  @JsonbProperty(JSON_START_DATE)
  private LocalDate startDate;
  
  /**
   * Date de fin {@link PhaseDto}.
   */
  @JsonbProperty(JSON_END_DATE)
  private LocalDate endDate;

  /**
   * Identitiant json {@link PhaseDto#triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER = "idActiviteBudget";

  /**
   * Identitiant json {@link PhaseDto#triennialProgramActivityAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING = "activiteBudgetChaine";

  /**
   * Identitiant json {@link PhaseDto#orderNumber}.
   */
  public static final String JSON_ORDER_NUMBER = "numero";
  /**
   * Identitiant json {@link PhaseDto#startDate}.
   */
  public static final String JSON_START_DATE = "dateDebut";
  /**
   * Identitiant json {@link PhaseDto#endDate}.
   */
  public static final String JSON_END_DATE = "dateFin";
  /**
   * Identitiant json {@link PhaseDto#comment}.
   */
  public static final String JSON_COMMENT = "commentaire";

  /**
   * Identitiant json {@link PhaseDto#reducedComment}.
   */
  public static final String JSON_REDUCED_COMMENT = "commentaireReduit";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "phase";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "phases";
}
