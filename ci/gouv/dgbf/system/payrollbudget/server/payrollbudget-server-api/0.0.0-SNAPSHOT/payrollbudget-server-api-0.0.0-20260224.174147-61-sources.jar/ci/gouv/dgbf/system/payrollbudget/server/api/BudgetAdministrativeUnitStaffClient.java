package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link BudgetAdministrativeUnitStaffService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BudgetAdministrativeUnitStaffClient 
    extends AbstractClient<BudgetAdministrativeUnitStaffService>
    implements GetByIdentifier<BudgetAdministrativeUnitStaffDto>, 
        GetMany<BudgetAdministrativeUnitStaffGetManyResponseDto>,
        DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public BudgetAdministrativeUnitStaffClient service(BudgetAdministrativeUnitStaffService service) {
    return (BudgetAdministrativeUnitStaffClient) super.service(service);
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(BudgetAdministrativeUnitStaffCreateRequestDto request) {
    return new CreateExecutor(BudgetAdministrativeUnitStaffService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetAdministrativeUnitStaffGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitStaffGetManyResponseDto>(
            BudgetAdministrativeUnitStaffGetManyResponseDto.class,
        BudgetAdministrativeUnitStaffService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetAdministrativeUnitStaffGetManyResponseDto getMany(ProjectionDto projection, 
          FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetAdministrativeUnitStaffDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitStaffDto>(
        BudgetAdministrativeUnitStaffDto.class,
        BudgetAdministrativeUnitStaffService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetAdministrativeUnitStaffDto getOne(ProjectionDto projection, FilterDto filter, 
          String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public BudgetAdministrativeUnitStaffDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitStaffDto>(
        BudgetAdministrativeUnitStaffDto.class,
        BudgetAdministrativeUnitStaffService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetAdministrativeUnitStaffDto getByIdentifier(String identifier, 
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(BudgetAdministrativeUnitStaffUpdateRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitStaffService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(BudgetAdministrativeUnitStaffService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link BudgetAdministrativeUnitStaffService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
