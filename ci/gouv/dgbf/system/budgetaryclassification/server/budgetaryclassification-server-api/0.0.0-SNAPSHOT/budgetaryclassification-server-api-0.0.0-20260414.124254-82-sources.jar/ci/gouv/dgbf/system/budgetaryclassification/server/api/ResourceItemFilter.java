package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ResourceItemDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ResourceItemFilter extends AbstractExpenditureOrResourceItemFilter {

  /**
   * Identifiant de {@link ResourceActivityDto}.
   */
  String activityIdentifier;
  
  /**
   * Code de {@link ResourceActivityDto}.
   */
  String activityCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ResourceItemFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ResourceItemFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    activityIdentifier = getActivityIdentifier(filter);
    activityCode = getActivityCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setActivityIdentifier(filter, activityIdentifier);
    setActivityCode(filter, activityCode);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ResourceActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ResourceActivityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ResourceActivityDto}
   */
  public static String getActivityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link ResourceActivityDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setActivityCode(FilterDto filter, String code) {
    set(filter, JSON_ACTIVITY_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link ResourceActivityDto}.
   *
   * @param filter filtre
   * @return code de {@link ResourceActivityDto}
   */
  public static String getActivityCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_CODE));
  }
  
  /**
   * Identifiant json champ {@link ResourceItemFilter#activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ResourceItemDto.JSON_ACTIVITY_IDENTIFIER;
}
