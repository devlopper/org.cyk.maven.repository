package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TriennialProgramDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TriennialProgramDto}.

    @author Christian
               """)
public interface TriennialProgramRequestMapper extends RequestMapper<TriennialProgramDto,
    TriennialProgramCreateRequestDto, TriennialProgramUpdateRequestDto> {

}
