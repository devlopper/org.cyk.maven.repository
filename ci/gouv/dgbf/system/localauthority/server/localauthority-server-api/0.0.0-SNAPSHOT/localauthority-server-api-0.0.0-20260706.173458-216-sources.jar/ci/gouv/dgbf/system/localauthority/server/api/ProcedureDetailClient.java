package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailService.ProcedureDetailCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailService.ProcedureDetailGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailService.ProcedureDetailUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ProcedureDetailService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ProcedureDetailClient extends AbstractClient<ProcedureDetailService>
    implements GetByIdentifier<ProcedureDetailDto>, GetMany<ProcedureDetailGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ProcedureDetailClient service(ProcedureDetailService service) {
    return (ProcedureDetailClient) super.service(service);
  }

  /**
   * {@link ProcedureDetailService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcedureDetailCreateRequestDto request) {
    return new CreateExecutor(ProcedureDetailService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProcedureDetailService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureDetailGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcedureDetailGetManyResponseDto>(
        ProcedureDetailGetManyResponseDto.class, ProcedureDetailService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcedureDetailService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureDetailGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcedureDetailService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcedureDetailDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ProcedureDetailDto>(ProcedureDetailDto.class,
        ProcedureDetailService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProcedureDetailService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcedureDetailDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ProcedureDetailService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ProcedureDetailDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ProcedureDetailDto>(ProcedureDetailDto.class,
        ProcedureDetailService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProcedureDetailService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcedureDetailDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ProcedureDetailService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcedureDetailUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcedureDetailService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcedureDetailService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProcedureDetailService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ProcedureDetailService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
