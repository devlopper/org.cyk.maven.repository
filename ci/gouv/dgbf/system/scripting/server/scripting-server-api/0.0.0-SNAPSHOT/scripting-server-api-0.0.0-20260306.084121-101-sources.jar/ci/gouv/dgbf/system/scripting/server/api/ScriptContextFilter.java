package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasGroupIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptContextDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class ScriptContextFilter extends AbstractIdentifiableFilter
    implements FilterHasGroupIdentifier {

  /**
   * Identifiant {@link ScriptContextGroupDto}.
   */
  private String groupIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptContextFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ScriptContextFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterGroupIdentifier(filter);
  }

}
