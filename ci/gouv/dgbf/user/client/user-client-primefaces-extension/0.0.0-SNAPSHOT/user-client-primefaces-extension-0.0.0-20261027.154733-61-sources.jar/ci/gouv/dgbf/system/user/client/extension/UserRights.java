package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.ReservedRolesHolder;
import ci.gouv.dgbf.system.user.server.api.UserRole;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.inject.Instance;
import jakarta.inject.Inject;

/**
 * Cette classe évalue, pour l'Utilisateur connecté, les Droits du module sur un objet (un Domaine,
 * une Application) à partir de ses Rôles réservés, par la règle commune
 * {@link UserRole#isGrantedTo(ReservedRolesHolder, String, String)} (RG_UTI_ROL_16). Les Rôles
 * réservés sont fournis par l'application hôte (lus dans le jeton) ; sans eux, aucun Droit.
 *
 * @author Christian Yao Komenan
 */
@ApplicationScoped
public class UserRights {

  @Inject
  Instance<ReservedRolesHolder> holder;

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit sur un objet.
   *
   * @param right           Droit
   * @param domainCode      Code du Domaine de l'objet
   * @param applicationCode Code de l'Application de l'objet, null pour un Domaine
   * @return vrai s'il l'a
   */
  public boolean isGranted(UserRole right, String domainCode, String applicationCode) {
    return holder.isResolvable() && right.isGrantedTo(holder.get(), domainCode, applicationCode);
  }

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit sur son propre Domaine (ex. créer
   * une Application).
   *
   * @param right Droit
   * @return vrai s'il l'a
   */
  public boolean isGrantedOnOwnDomain(UserRole right) {
    return holder.isResolvable()
        && right.isGrantedTo(holder.get(), holder.get().getDomainCode(), null);
  }

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit pour au moins une Application de
   * son Domaine (ex. « Ajouter plusieurs » sans contexte d'Application précis, TCH_UTI_773).
   *
   * @param right Droit
   * @return vrai s'il l'a pour au moins une Application
   */
  public boolean isGrantedForAny(UserRole right) {
    return holder.isResolvable() && holder.get().holdsAny(right.getReservedRole());
  }
}
