package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamService.SupportTeamCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamService.SupportTeamGetManyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamService.SupportTeamUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SupportTeamService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupportTeamClient extends AbstractClient<SupportTeamService>
    implements GetByIdentifier<SupportTeamDto>,
               GetMany<SupportTeamGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SupportTeamClient service(SupportTeamService service) {
    return (SupportTeamClient) super.service(service);
  }

  /**
   * {@link SupportTeamService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SupportTeamCreateRequestDto request) {
    return new CreateExecutor(SupportTeamService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SupportTeamService#create}.
   *
   * @param usersGroupIdentifier identifiant du groupe d'utilisateurs
   * @param maxClaimsPerSupport plafond de prise en charge
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String usersGroupIdentifier, Integer maxClaimsPerSupport,
      String auditWho, String auditSession) {
    SupportTeamCreateRequestDto request = new SupportTeamCreateRequestDto();
    request.setUsersGroupIdentifier(usersGroupIdentifier);
    request.setMaxClaimsPerSupport(maxClaimsPerSupport);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link SupportTeamService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SupportTeamGetManyResponseDto>(
      SupportTeamGetManyResponseDto.class,
        SupportTeamService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SupportTeamService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SupportTeamService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SupportTeamDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupportTeamDto>(SupportTeamDto.class,
        SupportTeamService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SupportTeamService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SupportTeamDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SupportTeamService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SupportTeamDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupportTeamDto>(SupportTeamDto.class,
        SupportTeamService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SupportTeamService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupportTeamDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SupportTeamService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SupportTeamUpdateRequestDto request) {
    return new IdentifiableExecutor(SupportTeamService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SupportTeamService#update}.
   *
   * @param identifier identifiant
   * @param usersGroupIdentifier identifiant du groupe d'utilisateurs
   * @param maxClaimsPerSupport plafond de prise en charge
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String usersGroupIdentifier,
      Integer maxClaimsPerSupport, String auditWho, String auditSession) {
    SupportTeamUpdateRequestDto request = new SupportTeamUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setUsersGroupIdentifier(usersGroupIdentifier);
    request.setMaxClaimsPerSupport(maxClaimsPerSupport);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link SupportTeamService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SupportTeamService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SupportTeamService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
