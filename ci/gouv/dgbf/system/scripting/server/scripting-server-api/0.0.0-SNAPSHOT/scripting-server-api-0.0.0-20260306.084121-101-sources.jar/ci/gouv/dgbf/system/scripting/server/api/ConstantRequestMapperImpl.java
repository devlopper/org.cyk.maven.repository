package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ConstantDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ConstantRequestMapperImpl implements ConstantRequestMapper {

    @Override
    public ConstantService.ConstantCreateRequestDto mapCreate(ConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantService.ConstantCreateRequestDto constantCreateRequestDto = new ConstantService.ConstantCreateRequestDto();

        constantCreateRequestDto.setCode( arg0.getCode() );
        constantCreateRequestDto.setName( arg0.getName() );
        constantCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        constantCreateRequestDto.setValue( arg0.getValue() );
        constantCreateRequestDto.setValueType( arg0.getValueType() );

        return constantCreateRequestDto;
    }

    @Override
    public ConstantService.ConstantUpdateRequestDto mapUpdate(ConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConstantService.ConstantUpdateRequestDto constantUpdateRequestDto = new ConstantService.ConstantUpdateRequestDto();

        constantUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        constantUpdateRequestDto.setCode( arg0.getCode() );
        constantUpdateRequestDto.setName( arg0.getName() );
        constantUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        constantUpdateRequestDto.setValue( arg0.getValue() );
        constantUpdateRequestDto.setValueType( arg0.getValueType() );

        return constantUpdateRequestDto;
    }
}
