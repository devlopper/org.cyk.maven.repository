package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.FolderPriorityService.FolderPriorityCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderPriorityService.FolderPriorityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FolderPriorityDto}.
 *
 * @author Dahoud
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link FolderPriorityDto}.

    @author Dahoud
               """)
public interface FolderPriorityRequestMapper
    extends RequestMapper<
        FolderPriorityDto, FolderPriorityCreateRequestDto, FolderPriorityUpdateRequestDto> {}
