package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasContextsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierDto;
import ci.gouv.dgbf.extension.core.segregation.HasScriptIdentifiersDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.math.BigDecimal;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de contextes de script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptContextGroupDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasMultiplierDto<BigDecimal>, HasMultiplierAsStringDto, HasMinValueDto<Integer>,
    HasMinValueAsStringDto, HasMaxValueDto<Integer>, HasMaxValueAsStringDto,
    HasScriptIdentifiersDto, HasContextsCountAsStringDto {

  @JsonbProperty(value = JSON_MULTIPLIER)
  private BigDecimal multiplier;

  @JsonbProperty(value = JSON_MULTIPLIER_AS_STRING)
  private String multiplierAsString;

  @JsonbProperty(value = JSON_MIN_VALUE)
  private Integer minValue;

  @JsonbProperty(value = JSON_MIN_VALUE_AS_STRING)
  private String minValueAsString;

  @JsonbProperty(value = JSON_MAX_VALUE)
  private Integer maxValue;

  @JsonbProperty(value = JSON_MAX_VALUE_AS_STRING)
  private String maxValueAsString;

  @JsonbProperty(value = JSON_SCRIPT_IDENTIFIERS)
  private Set<String> scriptIdentifiers;

  @JsonbProperty(value = JSON_CONTEXTS_COUNT_AS_STRING)
  private String contextsCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeContexteScript";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeContexteScriptChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de contexte de script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de contextes de script";

}
