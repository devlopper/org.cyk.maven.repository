package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDependencyService.ClaimableDependencyCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDependencyService.ClaimableDependencyGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDependencyService.ClaimableDependencyUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableDependencyService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableDependencyClient extends AbstractClient<ClaimableDependencyService>
    implements GetByIdentifier<ClaimableDependencyDto>,
    GetMany<ClaimableDependencyGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimableDependencyClient service(ClaimableDependencyService service) {
    return (ClaimableDependencyClient) super.service(service);
  }

  /**
   * {@link ClaimableDependencyService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableDependencyGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableDependencyGetManyResponseDto>(
        ClaimableDependencyGetManyResponseDto.class,
        ClaimableDependencyService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableDependencyService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableDependencyGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableDependencyService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimableDependencyCreateRequestDto request) {
    return new CreateExecutor(ClaimableDependencyService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimableDependencyService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimableDependencyUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimableDependencyService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimableDependencyService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableDependencyDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimableDependencyDto>(ClaimableDependencyDto.class,
        ClaimableDependencyService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimableDependencyService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableDependencyDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimableDependencyService#getByIdentifier}.
   *
   * @param request requête
   * @return dépendance entre réclamables
   */
  public ClaimableDependencyDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableDependencyDto>(ClaimableDependencyDto.class,
        ClaimableDependencyService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableDependencyService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableDependencyDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimableDependencyService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimableDependencyService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimableDependencyService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
