package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentNatureService.SupportingDocumentNatureCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.SupportingDocumentNatureService.SupportingDocumentNatureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Passage du {@link SupportingDocumentNatureDto} de l'écran aux requêtes du service.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Passage du {@link SupportingDocumentNatureDto} de l'écran aux requêtes du service.

    @author Christian
               """)
public interface SupportingDocumentNatureRequestMapper
    extends RequestMapper<SupportingDocumentNatureDto, SupportingDocumentNatureCreateRequestDto,
        SupportingDocumentNatureUpdateRequestDto> {

}
