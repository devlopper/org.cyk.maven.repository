package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de service de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollServiceTypeDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link PayrollServiceTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeServicePaie";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayrollServiceTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeServicePaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de service de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de service de paie";
  
  /**
   * Cette classe représente les codes de {@link PayrollServiceTypeDto}.
   *
   * @author Christian
   *
   */
  public static class Code {

    private Code() {
      
    }
      
    /**
     * EPN(Établissement Public National).
     */
    public static final String NATIONAL_PUBLIC_INSTITUTION = "EPN";
    
    /**
     * RNE(Représentation Nationale à l'Étranger).
     */
    public static final String NATIONAL_REPRESENTATION_ABROAD = "RNE";
    
    /**
     * POLICE.
     */
    public static final String POLICE = "POLICE";
    
    /**
     * CDA(Administration centrale et déconcentrée).
     */
    public static final String CENTRAL_AND_DECENTRALIZED_ADMINISTRATION = "ACD";
  }

}
