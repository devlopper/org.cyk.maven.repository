package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.JobGroupService.JobGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link JobGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link JobGroupDto}.

    @author Arnaud
               """)
public interface JobGroupRequestMapper
    extends RequestMapper<JobGroupDto, JobGroupCreateRequestDto, JobGroupUpdateRequestDto> {

}
