package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasName;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link FolderDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FolderService.PATH)
@Tag(name = "Gestion des dossiers")
public interface FolderService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "dossiers";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_DOSSIER";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un dossier",
      description = "Ce service permet de créer un dossier")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FolderCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface SaveRequestDto {
    /**
     * Cette méthode permet d'obtenir le libellé.
     *
     * @return libellé
     */
    String getName();

    /**
     * Cette méthode permet d'assigner le libellé.
     *
     * @param name libellé
     */
    void setName(String name);

    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description description
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FolderTypeDto}.
     *
     * @return identifiant de {@link FolderTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FolderTypeDto}.
     *
     * @param typeIdentifier identifiant de {@link FolderTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'unité administrative.
     *
     * @return identifiant de l'unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'unité administrative.
     *
     * @param typeIdentifier identifiant de l'unité administrative
     */
    void setAdministrativeUnitIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité du responsable.
     *
     * @return identifiant de l'identité du responsable
     */
    String getResponsibleIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité du responsable.
     *
     * @param responsibleIdentityIdentifier identifiant de l'identité du responsable
     */
    void setResponsibleIdentityIdentifier(String responsibleIdentityIdentifier);

    /**
     * Cette méthode permet d'obtenir la priorité.
     *
     * @return priorityIdentifier
     */
    String getPriorityIdentifier();

    /**
     * Cette méthode permet d'assigner la priorité.
     *
     * @param priorityIdentifier priorité.
     */
    void setPriorityIdentifier(String priorityIdentifier);

    /**
     * Identifiant json champ nom.
     */
    String JSON_NAME = AbstractIdentifiableCodableNamableDto.JSON_NAME;

    /**
     * Identifiant json champ description.
     */
    String JSON_DESCRIPTION = FolderDto.JSON_DESCRIPTION;

    /**
     * Identifiant json champ identifiant de {@link FolderTypeDto}.
     */
    String JSON_TYPE_IDENTIFIER = FolderDto.JSON_TYPE_IDENTIFIER;

    /**
     * Identifiant json de la priorité du dossier.
     */
    String JSON_PRIORITY_IDENTIFIER = FolderDto.JSON_PRIORITY_IDENTIFIER;

    /**
     * Identifiant json champ identifiant de l'unité administrative.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = FolderDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

    /**
     * Identifiant json champ identifiant de l'identité du responsable.
     */
    String JSON_RESPONSIBLE_IDENTITY_IDENTIFIER = FolderDto.JSON_RESPONSIBLE_IDENTITY_IDENTIFIER;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FolderCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements HasName, SaveRequestDto {

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
    private String priorityIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
    private String responsibleIdentityIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DOSSIER";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des dossiers")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FolderGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FolderGetManyResponseDto extends AbstractGetByPageResponseDto<FolderDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FolderDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DOSSIER";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FolderDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DOSSIER";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FolderDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DOSSIER";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FolderUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FolderUpdateRequestDto extends ByIdentifierRequestDto implements HasName, SaveRequestDto {
    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
    private String priorityIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String administrativeUnitIdentifier;

    @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
    private String responsibleIdentityIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DOSSIER";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_DOSSIER";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER,
      description = "Ce service permet d'obtenir un graphique")
  Response getChart(GetChartRequestDto request);

  /**
   * Identifiant du service de démarrage.
   */
  String START_IDENTIFIER = "DEMARRAGE_DOSSIER";

  /**
   * Chemin du service de démarrage.
   */
  String START_PATH = "demarrage";

  /**
   * Cette méthode permet de démarrer {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(START_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = START_IDENTIFIER,
      description = "Ce service permet de démarrer un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response start(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'arrêt.
   */
  String STOP_IDENTIFIER = "ARRET_DOSSIER";

  /**
   * Chemin du service d'arrêt.
   */
  String STOP_PATH = "arret";

  /**
   * Cette méthode permet d'arrêter {@link FolderDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(STOP_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = STOP_IDENTIFIER, description = "Ce service permet d'arrêter un dossier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response stop(ByIdentifierRequestDto request);
}
