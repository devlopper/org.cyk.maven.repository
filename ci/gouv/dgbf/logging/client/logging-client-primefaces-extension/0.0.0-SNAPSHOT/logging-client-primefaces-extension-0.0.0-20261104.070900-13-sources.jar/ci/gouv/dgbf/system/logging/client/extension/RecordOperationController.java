package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.segregation.HasArgumentsDto;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasResultDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatArgumentsFormatDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatResultFormatDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationClient;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationDto;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationRequestMapper;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationService;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationService.RecordOperationCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link RecordOperationDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RecordOperationController extends AbstractController {

  @Inject
  RecordOperationClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  RecordOperationRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController processInputTextController;

  @Inject
  @Getter
  InputTextController recordInputTextController;

  @Inject
  @Getter
  InputTextController sourceInputTextController;

  @Inject
  @Getter
  InputTextController operationInputTextController;

  @Inject
  @Getter
  InputTextController argumentsInputTextController;

  @Inject
  @Getter
  InputTextController argumentsFormatInputTextController;

  @Inject
  @Getter
  InputTextController resultInputTextController;

  @Inject
  @Getter
  InputTextController resultFormatInputTextController;

  @Inject
  @Getter
  RecordOperationFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = RecordOperationDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(RecordOperationDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(RecordOperationService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfStringBlank(filterController.getFilter().getProcessIdentifier(),
        HasProcessAsStringDto.JSON_PROCESS_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getSourceIdentifier(),
        HasSourceAsStringDto.JSON_SOURCE_AS_STRING);
    projection.addNamesIfStringBlank(filterController.getFilter().getRecordIdentifier(),
        HasRecordAsStringDto.JSON_RECORD_AS_STRING);

    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        HasOperationAsStringDto.JSON_OPERATION_AS_STRING, HasArgumentsDto.JSON_ARGUMENTS,
        HasStringFormatArgumentsFormatDto.JSON_ARGUMENTS_FORMAT, HasResultDto.JSON_RESULT,
        HasStringFormatResultFormatDto.JSON_RESULT_FORMAT, HasMessageDto.JSON_MESSAGE,
        AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING);

    listController.getReadController().setProjection(projection);

    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      RecordOperationCreateRequestDto request =
          requestMapper.mapCreate((RecordOperationDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    processInputTextController.setOutputLableValue("Processus");
    processInputTextController.getInputText().addValueConsumer(processConsumer());

    recordInputTextController.setOutputLableValue("Enregistrement");
    recordInputTextController.getInputText().addValueConsumer(recordConsumer());

    operationInputTextController.setOutputLableValue("Opération");
    operationInputTextController.getInputText().addValueConsumer(operationConsumer());

    sourceInputTextController.setOutputLableValue("Source");
    sourceInputTextController.getInputText().addValueConsumer(sourceConsumer());

    argumentsInputTextController.setOutputLableValue("Arguments");
    argumentsInputTextController.getInputText().addValueConsumer(argumentsConsumer());

    resultInputTextController.setOutputLableValue("Résultat");
    resultInputTextController.getInputText().addValueConsumer(resultConsumer());

    resultFormatInputTextController.setOutputLableValue("Format de résultat");
    resultFormatInputTextController.getInputText().addValueConsumer(resultFormatConsumer());

    argumentsFormatInputTextController.setOutputLableValue("Format d'arguments");
    argumentsFormatInputTextController.getInputText().addValueConsumer(argumentsFormatConsumer());

    listController.getDataTable().getActionColumn().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
  }

  Consumer<String> processConsumer() {
    return processIdentifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setProcessIdentifier(processIdentifier);
  }

  Consumer<String> recordConsumer() {
    return recordIdentifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setRecordIdentifier(recordIdentifier);
  }

  Consumer<String> operationConsumer() {
    return operationIdentifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setOperationIdentifier(operationIdentifier);
  }

  Consumer<String> sourceConsumer() {
    return sourceIdentifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setSourceIdentifier(sourceIdentifier);
  }

  Consumer<String> argumentsConsumer() {
    return arguments -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setArguments(arguments);
  }

  Consumer<String> resultConsumer() {
    return result -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class).setResult(result);
  }

  // Consumer pour modifier le champ resultFormat dans le DTO
  Consumer<String> resultFormatConsumer() {
    return name -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setResultFormat(Core.getEnumerationValueByName(StringFormat.class, name));
  }

  // Consumer pour modifier le champ argumentsFormat dans le DTO
  Consumer<String> argumentsFormatConsumer() {
    return argumentsFormat -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RecordOperationDto.class)
        .setArgumentsFormat(Core.getEnumerationValueByName(StringFormat.class, argumentsFormat));
  }

  /**
   * Cette méthode permet d'obtenir la concaténation des identifiants des messages.
   *
   * @return concaténation des identifiants des messages séparés par une virgule
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(processInputTextController.getInputText(), sourceInputTextController.getInputText(),
            recordInputTextController.getInputText(), operationInputTextController.getInputText(),
            argumentsInputTextController.getInputText(), resultInputTextController.getInputText(),
            argumentsFormatInputTextController.getInputText(),
            resultFormatInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }

}
