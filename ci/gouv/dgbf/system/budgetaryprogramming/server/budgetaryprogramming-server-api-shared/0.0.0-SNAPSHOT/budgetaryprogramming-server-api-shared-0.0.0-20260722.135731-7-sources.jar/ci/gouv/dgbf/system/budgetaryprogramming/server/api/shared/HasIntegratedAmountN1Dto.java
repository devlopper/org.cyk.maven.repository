package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasIntegratedAmountN1}.
 *
 * @author Christian
 */
public interface HasIntegratedAmountN1Dto extends HasIntegratedAmountN1 {

  /**
   * Identifiant json du montant intégré à l'horizon N1.
   */
  String JSON_INTEGRATED_AMOUNT_N1 = "montantIntegreN1";
}
