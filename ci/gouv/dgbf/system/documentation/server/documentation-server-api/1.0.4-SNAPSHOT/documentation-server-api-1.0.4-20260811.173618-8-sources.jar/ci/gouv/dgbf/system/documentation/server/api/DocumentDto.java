package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFileIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un document.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto, HasGroupIdentifierDto,
    HasGroupAsStringDto, HasFileIdentifierDto, HasTypeGroupIdentifierDto,
    HasTypeGroupAsStringDto {

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_FILE_IDENTIFIER)
  private String fileIdentifier;

  @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
  private String typeGroupIdentifier;

  @JsonbProperty(JSON_TYPE_GROUP_AS_STRING)
  private String typeGroupAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "documentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "documents";
}
