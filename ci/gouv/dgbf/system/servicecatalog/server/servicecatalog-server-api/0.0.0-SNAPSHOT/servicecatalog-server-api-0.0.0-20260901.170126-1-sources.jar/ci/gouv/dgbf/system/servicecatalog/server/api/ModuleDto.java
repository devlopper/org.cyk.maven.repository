package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un module du système d'information DGBF, unité de
 * conception/architecture pouvant exposer plusieurs Processus.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ModuleDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Description du module.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Classification stratégique (Core Domain / Supporting Subdomain / Generic Subdomain),
   * reflétée depuis apparchidoc, jamais éditée depuis ce module.
   */
  @JsonbProperty(JSON_STRATEGIC_CLASSIFICATION)
  private String strategicClassification;

  /**
   * Indique si le module est présenté à tous les utilisateurs authentifiés dans le catalogue.
   * Faux par défaut.
   */
  @JsonbProperty(JSON_VISIBLE)
  private Boolean visible;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idModule";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "moduleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "module";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modules";

  /**
   * Identifiant json pour {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json pour {@link #strategicClassification}.
   */
  public static final String JSON_STRATEGIC_CLASSIFICATION = "classificationStrategique";

  /**
   * Identifiant json pour {@link #visible}.
   */
  public static final String JSON_VISIBLE = "visible";
}
