package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Page de gestion des anomalies inter-modules.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class AnomalyListPage extends AbstractPage {

  @Inject
  @Getter
  AnomalyController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Gestion des anomalies";
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "anomalyListPage";
}

