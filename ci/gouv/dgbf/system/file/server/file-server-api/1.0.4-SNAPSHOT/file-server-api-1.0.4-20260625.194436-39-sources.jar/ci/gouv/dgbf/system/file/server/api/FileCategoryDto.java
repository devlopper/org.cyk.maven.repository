package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie de fichier.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileCategoryDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie de fichier";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
