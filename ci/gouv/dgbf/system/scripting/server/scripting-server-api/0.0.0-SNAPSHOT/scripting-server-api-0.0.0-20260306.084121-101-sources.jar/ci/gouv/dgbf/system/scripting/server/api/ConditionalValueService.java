package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasBooleanValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ConditionalValueDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ConditionalValueService.PATH)
@Tag(name = "Gestion des valeurs conditionnées")
public interface ConditionalValueService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "valeurs-conditionnees";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ConditionalValueSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant de {@link ConditionalValueGroupDto}.
     *
     * @return identifiant de {@link ConditionalValueGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant de {@link ConditionalValueGroupDto}.
     *
     * @param groupIdentifier identifiant de {@link ConditionalValueGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir valeur.
     *
     * @return valeur
     */
    String getValue();

    /**
     * Cette méthode permet d'assigner valeur.
     *
     * @param value valeur
     */
    void setValue(String value);

    /**
     * Cette méthode permet d'obtenir {@link ValueType}.
     *
     * @return {@link ValueType}
     */
    ValueType getValueType();

    /**
     * Cette méthode permet d'assigner {@link ValueType}.
     *
     * @param valueType {@link ValueType}
     */
    void setValueType(ValueType valueType);

    /**
     * {@link HasGroupIdentifierDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link HasValueDto#JSON_VALUE}.
     */
    String JSON_VALUE = HasValueDto.JSON_VALUE;

    /**
     * {@link HasValueTypeDto#JSON_VALUE_TYPE}.
     */
    String JSON_VALUE_TYPE = HasValueTypeDto.JSON_VALUE_TYPE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ConditionalValueCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ConditionalValueSaveRequestDto {

    /**
     * Identifiant {@link ConditionalValueGroupDto}.
     */
    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ConditionalValueGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ConditionalValueGetManyResponseDto
      extends AbstractGetByPageResponseDto<ConditionalValueDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ConditionalValueDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConditionalValueDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConditionalValueDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ConditionalValueUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ConditionalValueSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }

  /**
   * Identifiant du service de vérification d'applicabilité.
   */
  String CHECK_APPLICABILITY_IDENTIFIER = "VERIFICATION_APPLICABILITE_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de vérification d'applicabilité.
   */
  String CHECK_APPLICABILITY_PATH = "verification-applicabilite";

  /**
   * Cette méthode permet de vérifier l'applicabilité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CHECK_APPLICABILITY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CHECK_APPLICABILITY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = ConditionalValueCheckApplicabilityResponseDto.class))})
  Response checkApplicability(ConditionalValueCheckApplicabilityRequestDto request);

  /**
   * Cette classe représente la requête de vérification d'applicabilité.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueCheckApplicabilityRequestDto extends ByIdentifierRequestDto
      implements HasValuesMapDto<String, Object> {

    /**
     * Valeur de filtre.
     */
    @JsonbProperty(JSON_FILTER_VALUE)
    private String filterValue;

    @JsonbProperty(JSON_VALUES_MAP)
    private Map<String, Object> valuesMap;

    /**
     * Identifiant json {@link #filterValue}.
     */
    public static final String JSON_FILTER_VALUE = "filterValue";
  }

  /**
   * Cette classe représente la réponse de vérification d'applicabilité.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConditionalValueCheckApplicabilityResponseDto extends IdentifiableResponseDto
      implements HasBooleanValueDto {

    @JsonbProperty(JSON_VALUE)
    private Boolean value;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_VALEUR_CONDITIONNEE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConditionalValueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
