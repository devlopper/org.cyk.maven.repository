package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des types confiés aux membres.
 *
 * <p>Deux questions, et elles ne se posent pas au même endroit. L'écran d'équipe demande « que
 * confie-t-on à ce membre ? » et filtre sur le membre. L'écran de traitement demande « qu'a-t-on
 * confié à l'agent qui regarde ? » et filtre sur l'identifiant de connexion, car il ne connaît
 * de lui que celui-là — il ne sait pas de quelle équipe il relève, ni s'il en relève d'une.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ArbitrationTeamMemberMovementTypeFilter extends AbstractIdentifiableFilter {

  /**
   * Membre dont on veut les types de mouvement.
   */
  String memberIdentifier;

  /**
   * Identifiant de connexion du membre, quand on ne tient pas le sien.
   */
  String memberUser;

  /**
   * Type de mouvement dont on veut les membres.
   */
  String movementTypeIdentifier;

  public ArbitrationTeamMemberMovementTypeFilter() {
    super();
  }

  public ArbitrationTeamMemberMovementTypeFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setMemberIdentifier(
        read(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MEMBER_IDENTIFIER));
    setMemberUser(read(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MEMBER_USER));
    setMovementTypeIdentifier(
        read(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MOVEMENT_TYPE_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MEMBER_IDENTIFIER,
        getMemberIdentifier());
    write(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MEMBER_USER, getMemberUser());
    write(filter, ArbitrationTeamMemberMovementTypeDto.JSON_MOVEMENT_TYPE_IDENTIFIER,
        getMovementTypeIdentifier());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
