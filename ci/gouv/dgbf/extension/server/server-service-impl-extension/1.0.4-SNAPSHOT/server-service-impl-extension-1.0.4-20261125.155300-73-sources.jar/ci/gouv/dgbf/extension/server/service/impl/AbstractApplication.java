package ci.gouv.dgbf.extension.server.service.impl;

import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;

/**
 * Cette classe repérsente le point d'entrée du processus.
 *
 * @author Christian
 *
 */
public abstract class AbstractApplication extends jakarta.ws.rs.core.Application {
  private static final Logger LOGGER = Logger.getLogger(AbstractApplication.class.getName());

  @Getter
  private String timeZoneIdentifier = "UTC";

  /**
   * Ce méthode permet de construire une instance de l'application.
   */
  protected AbstractApplication() {
    super();
    java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone(timeZoneIdentifier));
    LOGGER.log(Level.CONFIG, "Fuseau horaire : {0}", java.util.TimeZone.getDefault());
  }
}
