package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasOperationAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTextDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesCountAsStringDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une documentation.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentationDto extends AbstractIdentifiableAuditableDto
    implements HasProcessIdentifierDto, HasProcessAsStringDto, HasSourceIdentifierDto,
    HasSourceAsStringDto, HasRecordIdentifierDto, HasRecordAsStringDto, HasOperationIdentifierDto,
    HasOperationAsStringDto, HasTextDto, HasFilesGroupIdentifierDto, HasFilesCountAsStringDto {

  /* Business Identification Part */
  
  // Process

  @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  @JsonbProperty(value = JSON_PROCESS_AS_STRING)
  private String processAsString;

  // Source

  @JsonbProperty(value = JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(value = JSON_SOURCE_AS_STRING)
  private String sourceAsString;

  // Record

  @JsonbProperty(value = JSON_RECORD_IDENTIFIER)
  private String recordIdentifier;

  @JsonbProperty(value = JSON_RECORD_AS_STRING)
  private String recordAsString;

  // Operation

  @JsonbProperty(value = JSON_OPERATION_IDENTIFIER)
  private String operationIdentifier;

  @JsonbProperty(value = JSON_OPERATION_AS_STRING)
  private String operationAsString;

  /* Data Part */
  
  // Text

  @JsonbProperty(JSON_TEXT)
  private String text;

  // Files

  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  @JsonbProperty(JSON_FILES_COUNT_AS_STRING)
  private String filesCountAsString;


  /**
   * Identifiant json de identifiant de {@link DocumentationDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDocumentation";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link DocumentationDto}.
   */
  public static final String JSON_THIS_AS_STRING = "documentationChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "documentation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
