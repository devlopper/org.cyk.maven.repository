package ci.gouv.dgbf.extension.primefaces.component.input;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un {@link LocalDate}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputLocalDate extends AbstractInputOneDate<LocalDate> {

}
