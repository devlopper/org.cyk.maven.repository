package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.system.report.server.api.ReportDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
@Named
@ViewScoped
public class ReportListPage extends AbstractReportListPage {

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ReportDto.NAME;
  }

  public static final String OUTCOME = "reportListPage";
}

