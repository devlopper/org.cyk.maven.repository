package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link PartitionDto}.
 *
 * @author Christian
 */
@Dependent
public class PartitionFilterController extends AbstractFilterController<PartitionFilter> {

  @Inject
  @Getter
  InputTextController typeCodeInputTextController;

  @Inject
  @Getter
  InputTextController valueDataInputTextController;

  /**
   * Cette méthode permet d'instantier.
   */
  public PartitionFilterController() {
    super(PartitionFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    typeCodeInputTextController.setOutputLableValue("Code du type");
    typeCodeInputTextController.getInputText().addValueConsumer(code -> filter.setTypeCode(code));

    valueDataInputTextController.setOutputLableValue("Donnée de la valeur");
    valueDataInputTextController.getInputText().addValueConsumer(data -> filter.setValueData(data));
  }

}
