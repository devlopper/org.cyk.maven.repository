package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur booléenne.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectOneBoolean extends AbstractSelectOne<Boolean> {

  String falseChoiceLabel;
  String trueChoiceLabel;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectOneBoolean() {
    nullChoiceLabel = "Néant";
    falseChoiceLabel = "Non";
    trueChoiceLabel = "Oui";
  }

  /**
   * Cette méthode permet d'ajouter des choix vrai, faux et néant.
   *
   * @param nullLabel libellé néant
   * @param falseLabel libellé faux
   * @param trueLabel libellé vrai
   */
  public AbstractSelectOneBoolean addTrueOrFalseChoices(String nullLabel, String falseLabel,
      String trueLabel) {
    addNullChoice(nullLabel);
    choiceBuilder().label(falseLabel).value(false).build();
    choiceBuilder().label(trueLabel).value(true).build();
    return this;
  }

  public AbstractSelectOneBoolean addTrueOrFalseChoices(boolean nullChoicable) {
    return addTrueOrFalseChoices(nullChoicable ? nullChoiceLabel : null, falseChoiceLabel,
        trueChoiceLabel);
  }

  public AbstractSelectOneBoolean addTrueOrFalseChoices() {
    return addTrueOrFalseChoices(false);
  }
}
