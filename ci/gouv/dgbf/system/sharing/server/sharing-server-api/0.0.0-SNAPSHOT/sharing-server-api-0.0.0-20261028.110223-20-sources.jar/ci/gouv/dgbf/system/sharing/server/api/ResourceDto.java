package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une ressource.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceDto extends AbstractResourceOrReceiverDto {
  
  /**
   * {@link ResourceType}.
   */
  @JsonbProperty(JSON_TYPE)
  private ResourceType type;

  /**
   * {@link VisibilityLevel} effectif de l'utilisateur demandé sur cette ressource (nul si aucun
   * utilisateur n'est demandé).
   */
  @JsonbProperty(JSON_EFFECTIVE_VISIBILITY_LEVEL)
  private VisibilityLevel effectiveVisibilityLevel;

  /**
   * Représentation en chaine de caractères de {@link #effectiveVisibilityLevel}.
   */
  @JsonbProperty(JSON_EFFECTIVE_VISIBILITY_LEVEL_AS_STRING)
  private String effectiveVisibilityLevelAsString;

  /**
   * Niveau de visibilité par défaut de la ressource. {@link VisibilityLevel#FULL} en l'absence de
   * paramétrage.
   */
  @JsonbProperty(JSON_DEFAULT_VISIBILITY_LEVEL)
  private VisibilityLevel defaultVisibilityLevel;

  /**
   * Représentation en chaîne de caractères de {@link #defaultVisibilityLevel}.
   */
  @JsonbProperty(JSON_DEFAULT_VISIBILITY_LEVEL_AS_STRING)
  private String defaultVisibilityLevelAsString;

  /**
   * Nom d'utilisateur du créateur de la ressource dans son module (nul si la source ne le
   * connaît pas). Informatif : ne confère aucun droit (RG_SHA_14, RG_SHA_19).
   */
  @JsonbProperty(JSON_CREATOR)
  private String creator;

  /**
   * Date de création de la ressource dans son module (nulle si la source ne la connaît pas).
   * Informative.
   */
  @JsonbProperty(JSON_CREATION_DATE)
  private LocalDateTime creationDate;

  /**
   * Identifiant json champ {@link #creator}.
   */
  public static final String JSON_CREATOR = "createur";

  /**
   * Identifiant json champ {@link #creationDate}.
   */
  public static final String JSON_CREATION_DATE = "dateCreation";

  /**
   * Identifiant json champ {@link #effectiveVisibilityLevel}.
   */
  public static final String JSON_EFFECTIVE_VISIBILITY_LEVEL = "niveauVisibiliteEffectif";

  /**
   * Identifiant json champ {@link #effectiveVisibilityLevelAsString}.
   */
  public static final String JSON_EFFECTIVE_VISIBILITY_LEVEL_AS_STRING =
      "niveauVisibiliteEffectifChaine";

  /**
   * Identifiant json champ {@link #defaultVisibilityLevel}.
   */
  public static final String JSON_DEFAULT_VISIBILITY_LEVEL = "niveauVisibiliteParDefaut";

  /**
   * Identifiant json champ {@link #defaultVisibilityLevelAsString}.
   */
  public static final String JSON_DEFAULT_VISIBILITY_LEVEL_AS_STRING =
      "niveauVisibiliteParDefautChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ressource";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
