package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre du journal du Fichier : identifiant du Fichier (obligatoire à
 * la lecture) et types d'événement (codes de {@link FileJournalEventType}, facultatifs).
 *
 * @author Christian
 */
@Getter
@Setter
public class FileJournalEntryFilter extends AbstractIdentifiableFilter {

  private String fileIdentifier;
  private Set<String> eventTypes;

  public FileJournalEntryFilter() {
    super();
  }

  public FileJournalEntryFilter(FilterDto filter) {
    super(filter);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    fileIdentifier = getFileIdentifier(filter);
    eventTypes = getEventTypes(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFileIdentifier(filter, fileIdentifier);
    setEventTypes(filter, eventTypes);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du Fichier.
   *
   * @param filter filtre
   * @param fileIdentifier identifiant du Fichier
   */
  public static void setFileIdentifier(FilterDto filter, String fileIdentifier) {
    set(filter, JSON_FILE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(fileIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du Fichier.
   *
   * @param filter filtre
   * @return identifiant du Fichier
   */
  public static String getFileIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FILE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les types d'événement.
   *
   * @param filter filtre
   * @param eventTypes codes des types d'événement
   */
  public static void setEventTypes(FilterDto filter, Set<String> eventTypes) {
    set(filter, JSON_EVENT_TYPES, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet((LinkedHashSet<String>) Core
            .getOrNullifyIfCollectionEmpty(Core.getLinkedHashSet(eventTypes))));
  }

  /**
   * Cette méthode permet d'obtenir les types d'événement.
   *
   * @param filter filtre
   * @return codes des types d'événement
   */
  public static Set<String> getEventTypes(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_EVENT_TYPES));
  }

  public static final String JSON_FILE_IDENTIFIER = FileJournalEntryDto.JSON_FILE_IDENTIFIER;
  public static final String JSON_EVENT_TYPES = "typesEvenement";
}
