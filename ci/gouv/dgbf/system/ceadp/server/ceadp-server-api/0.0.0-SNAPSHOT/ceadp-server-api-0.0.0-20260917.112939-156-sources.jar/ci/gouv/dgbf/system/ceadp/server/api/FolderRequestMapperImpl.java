package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FolderDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FolderRequestMapperImpl implements FolderRequestMapper {

    @Override
    public FolderService.FolderCreateRequestDto mapCreate(FolderDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderService.FolderCreateRequestDto folderCreateRequestDto = new FolderService.FolderCreateRequestDto();

        folderCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderCreateRequestDto.setName( arg0.getName() );
        folderCreateRequestDto.setDescription( arg0.getDescription() );
        folderCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        folderCreateRequestDto.setPriorityIdentifier( arg0.getPriorityIdentifier() );
        folderCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        folderCreateRequestDto.setResponsibleIdentityIdentifier( arg0.getResponsibleIdentityIdentifier() );

        return folderCreateRequestDto;
    }

    @Override
    public FolderService.FolderUpdateRequestDto mapUpdate(FolderDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderService.FolderUpdateRequestDto folderUpdateRequestDto = new FolderService.FolderUpdateRequestDto();

        folderUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        folderUpdateRequestDto.setName( arg0.getName() );
        folderUpdateRequestDto.setDescription( arg0.getDescription() );
        folderUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        folderUpdateRequestDto.setPriorityIdentifier( arg0.getPriorityIdentifier() );
        folderUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        folderUpdateRequestDto.setResponsibleIdentityIdentifier( arg0.getResponsibleIdentityIdentifier() );

        return folderUpdateRequestDto;
    }
}
