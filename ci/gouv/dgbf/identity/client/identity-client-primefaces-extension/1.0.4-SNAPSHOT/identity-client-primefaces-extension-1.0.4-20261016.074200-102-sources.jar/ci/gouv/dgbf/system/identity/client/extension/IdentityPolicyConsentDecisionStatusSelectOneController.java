package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentStatus;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection du statut de décision d'un
 * {@link IdentityPolicyConsentStatus} : Accepté ou Refusé uniquement, Périmé restant réservé au
 * système (RG_IDT_CST_06). Utilisé par le formulaire d'administration des consentements
 * (dérogation temporaire, TCH_IDT_749).
 *
 * @author Christian Yao Komenan
 *
 */
@Dependent
public class IdentityPolicyConsentDecisionStatusSelectOneController
    extends AbstractSelectOneEnumerationController<IdentityPolicyConsentStatus> {

  protected IdentityPolicyConsentDecisionStatusSelectOneController() {
    super(new IdentityPolicyConsentStatus[] {IdentityPolicyConsentStatus.ACCEPTED,
        IdentityPolicyConsentStatus.REFUSED});
    outputLableValue = "Statut";
  }

  @Override
  protected String computeSelectItemLabel(IdentityPolicyConsentStatus status) {
    return status.getName();
  }
}
