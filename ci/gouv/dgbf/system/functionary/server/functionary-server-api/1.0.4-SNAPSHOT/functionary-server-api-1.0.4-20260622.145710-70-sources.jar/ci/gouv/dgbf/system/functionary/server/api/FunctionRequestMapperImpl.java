package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionDto}.
*
* @author AKM
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FunctionRequestMapperImpl implements FunctionRequestMapper {

    @Override
    public FunctionService.FunctionCreateRequestDto mapCreate(FunctionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionService.FunctionCreateRequestDto functionCreateRequestDto = new FunctionService.FunctionCreateRequestDto();

        functionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionCreateRequestDto.setCode( arg0.getCode() );
        functionCreateRequestDto.setName( arg0.getName() );
        functionCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        functionCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return functionCreateRequestDto;
    }

    @Override
    public FunctionService.FunctionUpdateRequestDto mapUpdate(FunctionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionService.FunctionUpdateRequestDto functionUpdateRequestDto = new FunctionService.FunctionUpdateRequestDto();

        functionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionUpdateRequestDto.setCode( arg0.getCode() );
        functionUpdateRequestDto.setName( arg0.getName() );
        functionUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        functionUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return functionUpdateRequestDto;
    }
}
