package ci.gouv.dgbf.extension.primefaces.error;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page d'erreur de code 404.
 *
 * @author Christian
 */
@Named
@RequestScoped
public class Error404Page extends AbstractPage {

  public Error404Page() {
    title = "Page non trouvée (404)";
    contentTitle = "Page non trouvée";
  }
}
