package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la valeur saisie pour un {@link DocumentTypeGroupFieldDto} sur un
 * {@link DocumentDto}.
 *
 * <p>Ce concept n'a pas de service CRUD autonome : les valeurs sont créées/mises à jour en
 * cascade avec le {@link DocumentDto} auquel elles appartiennent (voir
 * {@link DocumentService.DocumentSaveRequestDto}).
 *
 * @author si.kimou
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DocumentFieldValueDto extends AbstractIdentifiableAuditableDto
    implements HasValueDto<String> {

  /**
   * Identifiant du {@link DocumentDto} auquel la valeur est rattachée.
   */
  @JsonbProperty(JSON_DOCUMENT_IDENTIFIER)
  private String documentIdentifier;

  /**
   * Identifiant du {@link DocumentTypeGroupFieldDto} configurant cette valeur.
   */
  @JsonbProperty(JSON_FIELD_IDENTIFIER)
  private String fieldIdentifier;

  /**
   * Valeur saisie, sous forme de chaine -- interprétée selon le
   * {@link DocumentTypeGroupFieldDto#getValueType()} du champ.
   */
  @JsonbProperty(JSON_VALUE)
  private String value;

  /**
   * Identifiant json champ {@link #documentIdentifier}.
   */
  public static final String JSON_DOCUMENT_IDENTIFIER = "idDocument";

  /**
   * Identifiant json champ {@link #fieldIdentifier}.
   */
  public static final String JSON_FIELD_IDENTIFIER =
      DocumentTypeGroupFieldDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idValeurChampDocument";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "valeurChampDocumentChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "valeur de champ de document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "valeurs de champ de document";
}
