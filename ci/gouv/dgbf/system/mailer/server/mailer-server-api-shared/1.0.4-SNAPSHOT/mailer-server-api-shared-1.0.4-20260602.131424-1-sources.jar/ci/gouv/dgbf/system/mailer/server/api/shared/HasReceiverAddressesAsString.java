package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères des
 * adresses des destinataires.
 *
 * @author Christian
 */
public interface HasReceiverAddressesAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir les adresses des destinataires.
   *
   * @return adresses des destinataires
   */
  String getReceiverAddressesAsString();

  /**
   * Cette méthode permet d'assigner les adresses des destinataires.
   *
   * @param string adresses des destinataires
   */
  void setReceiverAddressesAsString(String string);

  /**
   * Identifiant java des adresses des destinataires.
   */
  String FIELD_RECEIVER_ADDRESSES_AS_STRING = "receiverAddressesAsString";
}
