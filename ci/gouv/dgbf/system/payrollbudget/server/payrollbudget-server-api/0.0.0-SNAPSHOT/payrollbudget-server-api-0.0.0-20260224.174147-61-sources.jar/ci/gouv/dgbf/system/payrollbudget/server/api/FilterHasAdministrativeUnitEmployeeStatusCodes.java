package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasAdministrativeUnitEmployeeStatusCodes
    extends HasAdministrativeUnitEmployeeStatusCodes {

  /**
   * Cette méthode permet de mettre à jour les codes de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAdministrativeUnitEmployeeStatusCodes(FilterDto filter) {
    setAdministrativeUnitEmployeeStatusCodes(
        AdministrativeUnitEmployeeStatusCodesFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour les codes de {@link AdministrativeUnitEmployeeStatus} de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAdministrativeUnitEmployeeStatusCodes(FilterDto filter) {
    AdministrativeUnitEmployeeStatusCodesFilter.set(filter,
        getAdministrativeUnitEmployeeStatusCodes());
  }

}
