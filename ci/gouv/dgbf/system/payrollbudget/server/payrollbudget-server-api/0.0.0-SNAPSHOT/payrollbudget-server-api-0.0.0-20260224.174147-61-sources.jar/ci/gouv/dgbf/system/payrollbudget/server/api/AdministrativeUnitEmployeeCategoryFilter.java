package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasChartCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasCategoryIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitEmployeeCategoryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitEmployeeCategoryFilter extends AbstractIdentifiableFilter implements
    FilterHasBudgetAdministrativeUnitIdentifier, FilterHasCategoryIdentifier, FilterHasChartCode {

  private String budgetAdministrativeUnitIdentifier;
  private String categoryIdentifier;
  private String chartCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitEmployeeCategoryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public AdministrativeUnitEmployeeCategoryFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetAdministrativeUnitIdentifier(filter);
    updateCategoryIdentifier(filter);
    updateChartCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetAdministrativeUnitIdentifier(filter);
    updateFilterCategoryIdentifier(filter);
    updateFilterChartCode(filter);
  }
}

