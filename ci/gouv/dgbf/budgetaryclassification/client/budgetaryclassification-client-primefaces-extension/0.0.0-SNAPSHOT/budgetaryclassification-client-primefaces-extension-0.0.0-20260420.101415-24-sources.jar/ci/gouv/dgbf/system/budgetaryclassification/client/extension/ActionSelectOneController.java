package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ActionService.ActionGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ActionDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ActionSelectOneController extends AbstractSelectOneIdentifiableController<
    ActionDto, ActionGetManyResponseDto, ActionClient> {

  @Inject
  @Getter
  ActionClient client;

  protected ActionSelectOneController() {
    super(ActionDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
