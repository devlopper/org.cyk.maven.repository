package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de prise en
 * charge de ticket.
 *
 * @author Christian
 */
public interface HasTicketClaimActionsCountDto extends HasTicketClaimActionsCount {

  /**
   * Identifiant json du nombre cumulé d'actions de prise en charge de ticket.
   */
  String JSON_TICKET_CLAIM_ACTIONS_COUNT = "nombreActionsPriseEnChargeTicket";
}
