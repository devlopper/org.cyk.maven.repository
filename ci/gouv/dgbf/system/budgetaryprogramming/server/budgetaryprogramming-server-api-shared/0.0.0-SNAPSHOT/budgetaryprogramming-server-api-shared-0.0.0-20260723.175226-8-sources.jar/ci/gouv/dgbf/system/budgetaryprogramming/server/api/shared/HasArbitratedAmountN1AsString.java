package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant arbitré pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountN1AsString {

  /**
   * Obtient le montant arbitré pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant arbitré pour l'année N+1 sous forme de chaîne de caractères
   */
  String getArbitratedAmountN1AsString();

  /**
   * Définit le montant arbitré pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param arbitratedAmountN1AsString le montant arbitré pour l'année N+1 sous forme de chaîne de
   *        caractères
   */
  void setArbitratedAmountN1AsString(String arbitratedAmountN1AsString);

  /**
   * Identifiant java du montant arbitré pour l'année N+1, sous forme de chaîne de caractères.
   */
  String FIELD_ARBITRATED_AMOUNT_N1_AS_STRING =
      "arbitratedAmountN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName