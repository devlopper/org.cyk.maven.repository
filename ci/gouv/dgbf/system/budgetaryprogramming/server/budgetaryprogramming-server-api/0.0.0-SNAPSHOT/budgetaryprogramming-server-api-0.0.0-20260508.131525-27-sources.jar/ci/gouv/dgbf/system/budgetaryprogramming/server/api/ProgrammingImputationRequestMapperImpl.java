package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingImputationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-08T13:15:44+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingImputationRequestMapperImpl implements ProgrammingImputationRequestMapper {

    @Override
    public ProgrammingImputationService.ProgrammingImputationCreateRequestDto mapCreate(ProgrammingImputationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingImputationService.ProgrammingImputationCreateRequestDto programmingImputationCreateRequestDto = new ProgrammingImputationService.ProgrammingImputationCreateRequestDto();

        programmingImputationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingImputationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingImputationCreateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingImputationCreateRequestDto.setImputationIdentifier( arg0.getImputationIdentifier() );
        programmingImputationCreateRequestDto.setExpenditure( arg0.getExpenditure() );
        programmingImputationCreateRequestDto.setInputtedAmountN( arg0.getInputtedAmountN() );
        programmingImputationCreateRequestDto.setInputtedAmountN1( arg0.getInputtedAmountN1() );
        programmingImputationCreateRequestDto.setInputtedAmountN2( arg0.getInputtedAmountN2() );
        programmingImputationCreateRequestDto.setArbitratedAmountN( arg0.getArbitratedAmountN() );
        programmingImputationCreateRequestDto.setArbitratedAmountN1( arg0.getArbitratedAmountN1() );
        programmingImputationCreateRequestDto.setArbitratedAmountN2( arg0.getArbitratedAmountN2() );
        programmingImputationCreateRequestDto.setValidatedAmountN( arg0.getValidatedAmountN() );
        programmingImputationCreateRequestDto.setValidatedAmountN1( arg0.getValidatedAmountN1() );
        programmingImputationCreateRequestDto.setValidatedAmountN2( arg0.getValidatedAmountN2() );
        programmingImputationCreateRequestDto.setIntegratedAmountN( arg0.getIntegratedAmountN() );
        programmingImputationCreateRequestDto.setIntegratedAmountN1( arg0.getIntegratedAmountN1() );
        programmingImputationCreateRequestDto.setIntegratedAmountN2( arg0.getIntegratedAmountN2() );

        return programmingImputationCreateRequestDto;
    }

    @Override
    public ProgrammingImputationService.ProgrammingImputationUpdateRequestDto mapUpdate(ProgrammingImputationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingImputationService.ProgrammingImputationUpdateRequestDto programmingImputationUpdateRequestDto = new ProgrammingImputationService.ProgrammingImputationUpdateRequestDto();

        programmingImputationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingImputationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingImputationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingImputationUpdateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingImputationUpdateRequestDto.setImputationIdentifier( arg0.getImputationIdentifier() );
        programmingImputationUpdateRequestDto.setExpenditure( arg0.getExpenditure() );
        programmingImputationUpdateRequestDto.setInputtedAmountN( arg0.getInputtedAmountN() );
        programmingImputationUpdateRequestDto.setInputtedAmountN1( arg0.getInputtedAmountN1() );
        programmingImputationUpdateRequestDto.setInputtedAmountN2( arg0.getInputtedAmountN2() );
        programmingImputationUpdateRequestDto.setArbitratedAmountN( arg0.getArbitratedAmountN() );
        programmingImputationUpdateRequestDto.setArbitratedAmountN1( arg0.getArbitratedAmountN1() );
        programmingImputationUpdateRequestDto.setArbitratedAmountN2( arg0.getArbitratedAmountN2() );
        programmingImputationUpdateRequestDto.setValidatedAmountN( arg0.getValidatedAmountN() );
        programmingImputationUpdateRequestDto.setValidatedAmountN1( arg0.getValidatedAmountN1() );
        programmingImputationUpdateRequestDto.setValidatedAmountN2( arg0.getValidatedAmountN2() );
        programmingImputationUpdateRequestDto.setIntegratedAmountN( arg0.getIntegratedAmountN() );
        programmingImputationUpdateRequestDto.setIntegratedAmountN1( arg0.getIntegratedAmountN1() );
        programmingImputationUpdateRequestDto.setIntegratedAmountN2( arg0.getIntegratedAmountN2() );

        return programmingImputationUpdateRequestDto;
    }
}
