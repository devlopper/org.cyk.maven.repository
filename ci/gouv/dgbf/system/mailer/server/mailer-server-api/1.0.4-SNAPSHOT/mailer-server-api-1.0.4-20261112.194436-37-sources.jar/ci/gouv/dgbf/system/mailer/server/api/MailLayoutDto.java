package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasBodyHtmlDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyTextDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un gabarit d'e-mail.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MailLayoutDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasBodyHtmlDto, HasBodyTextDto {

  @JsonbProperty(JSON_BODY_HTML)
  private String bodyHtml;

  @JsonbProperty(JSON_BODY_TEXT)
  private String bodyText;

  @JsonbProperty(JSON_IS_DEFAULT)
  private Boolean isDefault;

  public static final String JSON_BODY_HTML = HasBodyHtmlDto.JSON_BODY_HTML;
  public static final String JSON_BODY_TEXT = HasBodyTextDto.JSON_BODY_TEXT;
  public static final String JSON_IS_DEFAULT = "estParDefaut";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGabarit";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "gabaritChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "gabarit de mail";

  /**
   * Nom pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "gabarits de mail";
}
