package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupClient;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link RegistrationNumberGroupDto}.
 *
 * @author arnaud
 *
 */
@Dependent
public class RegistrationNumberGroupController extends AbstractController {

  @Inject
  RegistrationNumberGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  RegistrationNumberGroupRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = RegistrationNumberGroupDto.NAME;

    listController.setEntityClass(RegistrationNumberGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(RegistrationNumberGroupService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            RegistrationNumberGroupDto.JSON_REGISTRATION_NUMBER_PATTERN));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      RegistrationNumberGroupCreateRequestDto request = requestMapper
          .mapCreate((RegistrationNumberGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().setFunction(entity -> {
      RegistrationNumberGroupUpdateRequestDto request = requestMapper
          .mapUpdate((RegistrationNumberGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
  }
}
