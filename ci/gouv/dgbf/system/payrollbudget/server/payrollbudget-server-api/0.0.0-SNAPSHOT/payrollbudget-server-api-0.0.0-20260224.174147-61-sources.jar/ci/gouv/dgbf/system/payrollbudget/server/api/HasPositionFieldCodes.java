package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;
import java.util.Set;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasPositionFieldCodes extends HasField {

  /**
   * Cette méthode permet d'obtenir les codes de {@link PositionField}.
   *
   * @return codes de {@link PositionField}
   */
  Set<String> getPositionFieldCodes();

  /**
   * Cette méthode permet d'assigner les codes de {@link PositionField}.
   *
   * @param codes codes de {@link PositionField}
   */
  void setPositionFieldCodes(Set<String> codes);

}
