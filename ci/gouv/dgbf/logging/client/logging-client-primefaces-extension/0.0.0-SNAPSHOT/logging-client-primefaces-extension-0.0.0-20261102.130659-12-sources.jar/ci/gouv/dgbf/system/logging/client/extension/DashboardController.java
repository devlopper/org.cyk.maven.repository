package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventChartCode;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventClient;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.time.LocalDateTime;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du tableau de bord administrateur.
 *
 * @author Christian
 *
 */
@Dependent
public class DashboardController extends AbstractController {

  @Inject
  TraceabilityEventClient client;

  @Inject
  @Getter
  ChartController levelChartController;

  @Inject
  @Getter
  ChartController volumeByDayChartController;

  @Inject
  @Getter
  ChartController processChartController;

  @Inject
  @Getter
  ChartController actionTypeChartController;

  @Inject
  @Getter
  ChartController userChartController;

  @Getter
  @Setter
  int periodDays = 30;

  @Getter
  long totalEvents;

  @Getter
  long errorLogs;

  @Getter
  String errorRate = "0,0 %";

  @Getter
  long correlatedEvents;

  @Getter
  String correlationRate = "0,0 %";

  @Getter
  long maskedEvents;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Tableau de bord Administrateur";
  }

  /**
   * Cette méthode permet d'initialiser les métriques et graphiques du tableau de bord.
   */
  public void initialize() {
    TraceabilityEventFilter filter = new TraceabilityEventFilter();
    filter.setChartCode(TraceabilityEventChartCode.DASHBOARD);
    LocalDateTime now = LocalDateTime.now();
    filter.setDateFrom(now.minusDays(periodDays));
    filter.setDateTo(now);

    GetChartResponseDto response = client.getChart(filter.toDto(), userIdentifier, null);
    ChartDto fullChart = response == null ? null : response.getChart();

    processKpis(fullChart);
    processCharts(fullChart);
  }

  void processKpis(ChartDto chart) {
    totalEvents = 0;
    errorLogs = 0;
    errorRate = "0,0 %";
    correlatedEvents = 0;
    correlationRate = "0,0 %";
    maskedEvents = 0;

    if (chart == null || chart.getDataSets() == null) {
      return;
    }

    ChartDataSetDto kpiDataSet = findDataSet(chart, "KPI");
    if (kpiDataSet != null && kpiDataSet.getDatas() != null) {
      for (ChartDataDto data : kpiDataSet.getDatas()) {
        if ("TOTAL".equals(data.getKey())) {
          totalEvents = data.getValue() != null ? data.getValue() : 0;
        } else if ("ERREURS".equals(data.getKey())) {
          errorLogs = data.getValue() != null ? data.getValue() : 0;
        } else if ("CORRELEES".equals(data.getKey())) {
          correlatedEvents = data.getValue() != null ? data.getValue() : 0;
        } else if ("MASQUEES".equals(data.getKey())) {
          maskedEvents = data.getValue() != null ? data.getValue() : 0;
        }
      }
    }

    if (totalEvents > 0) {
      errorRate = String.format(Locale.FRANCE, "%.1f %%", (errorLogs * 100.0) / totalEvents);
      correlationRate = String.format(Locale.FRANCE, "%.1f %%",
          (correlatedEvents * 100.0) / totalEvents);
    }
  }

  void processCharts(ChartDto chart) {
    ChartDataSetDto levelDataSet = findDataSet(chart, "LEVEL");
    levelChartController.setSupplier(
        () -> buildResponse("Répartition par niveau", levelDataSet));
    levelChartController.buildPieChart();

    ChartDataSetDto volumeDataSet = findDataSet(chart, "VOLUME_BY_DAY");
    volumeByDayChartController.setSupplier(
        () -> buildResponse("Volume par jour", volumeDataSet));
    volumeByDayChartController.buildLineChart();

    ChartDataSetDto processDataSet = findDataSet(chart, "PROCESS");
    processChartController.setSupplier(
        () -> buildResponse("Événements par processus", processDataSet));
    processChartController.buildBarChart();

    ChartDataSetDto actionTypeDataSet = findDataSet(chart, "ACTION_TYPE");
    actionTypeChartController.setSupplier(
        () -> buildResponse("Répartition par type d'action", actionTypeDataSet));
    actionTypeChartController.buildBarChart();

    ChartDataSetDto userDataSet = findDataSet(chart, "USER");
    userChartController.setSupplier(
        () -> buildResponse("Activité par utilisateur", userDataSet));
    userChartController.buildBarChart();
  }

  ChartDataSetDto findDataSet(ChartDto chart, String name) {
    if (chart == null || chart.getDataSets() == null) {
      return null;
    }
    return chart.getDataSets().stream()
        .filter(ds -> name.equals(ds.getName()))
        .findFirst()
        .orElse(null);
  }

  GetChartResponseDto buildResponse(String title, ChartDataSetDto dataSet) {
    ChartDto chart = new ChartDto();
    chart.setName(title);
    if (dataSet != null && dataSet.getDatas() != null && !dataSet.getDatas().isEmpty()) {
      chart.addDataSet(dataSet);
      LinkedHashSet<String> keys = dataSet.getDatas().stream()
          .map(ChartDataDto::getKey)
          .collect(Collectors.toCollection(LinkedHashSet::new));
      chart.setKeys(keys);
    }
    GetChartResponseDto response = new GetChartResponseDto();
    response.setChart(chart);
    return response;
  }

  /**
   * Cette méthode permet d'appliquer une période en jours et de rafraîchir les données.
   *
   * @param days nombre de jours
   */
  public void applyPeriod(int days) {
    this.periodDays = days;
    initialize();
  }
}
