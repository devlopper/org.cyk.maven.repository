package ci.gouv.dgbf.system.budgetaryclassification.client.extension.act;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link ExpenditureItemDto}.
 *
 * @author AKM
 *
 */
@Named
@ViewScoped
public class ExpenditureItemListPage extends AbstractPage {

  @Inject
  @Getter
  ExpenditureItemController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ExpenditureItemDto.NAME;
    controller.initialize();
  }

  public static final String OUTCOME = "expenditureItemListPage";
}
