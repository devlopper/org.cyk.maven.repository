package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de fichier.
 *
 * @author Christian
 */
public interface FilterHasFileIdentifier extends HasFileIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du fichier.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFileIdentifier(FilterDto filter) {
    setFileIdentifier(FileIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du fichier de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterFileIdentifier(FilterDto filter) {
    FileIdentifierFilter.set(filter, getFileIdentifier());
  }

}
