package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimableCascadeHopDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T18:12:39+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimableCascadeHopRequestMapperImpl implements ClaimableCascadeHopRequestMapper {

    @Override
    public ClaimableCascadeHopService.ClaimableCascadeHopCreateRequestDto mapCreate(ClaimableCascadeHopDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableCascadeHopService.ClaimableCascadeHopCreateRequestDto claimableCascadeHopCreateRequestDto = new ClaimableCascadeHopService.ClaimableCascadeHopCreateRequestDto();

        claimableCascadeHopCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableCascadeHopCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableCascadeHopCreateRequestDto.setCascadeDependencyIdentifier( arg0.getCascadeDependencyIdentifier() );
        claimableCascadeHopCreateRequestDto.setRank( arg0.getRank() );
        claimableCascadeHopCreateRequestDto.setClientKey( arg0.getClientKey() );
        claimableCascadeHopCreateRequestDto.setFilterFieldKey( arg0.getFilterFieldKey() );
        claimableCascadeHopCreateRequestDto.setOutputFieldKey( arg0.getOutputFieldKey() );

        return claimableCascadeHopCreateRequestDto;
    }

    @Override
    public ClaimableCascadeHopService.ClaimableCascadeHopUpdateRequestDto mapUpdate(ClaimableCascadeHopDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimableCascadeHopService.ClaimableCascadeHopUpdateRequestDto claimableCascadeHopUpdateRequestDto = new ClaimableCascadeHopService.ClaimableCascadeHopUpdateRequestDto();

        claimableCascadeHopUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimableCascadeHopUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimableCascadeHopUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimableCascadeHopUpdateRequestDto.setCascadeDependencyIdentifier( arg0.getCascadeDependencyIdentifier() );
        claimableCascadeHopUpdateRequestDto.setRank( arg0.getRank() );
        claimableCascadeHopUpdateRequestDto.setClientKey( arg0.getClientKey() );
        claimableCascadeHopUpdateRequestDto.setFilterFieldKey( arg0.getFilterFieldKey() );
        claimableCascadeHopUpdateRequestDto.setOutputFieldKey( arg0.getOutputFieldKey() );

        return claimableCascadeHopUpdateRequestDto;
    }
}
