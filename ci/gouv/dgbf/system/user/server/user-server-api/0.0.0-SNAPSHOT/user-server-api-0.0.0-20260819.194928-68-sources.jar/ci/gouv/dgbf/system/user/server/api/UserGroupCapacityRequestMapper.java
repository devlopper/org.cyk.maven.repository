package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserGroupCapacityService.UserGroupCapacityCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupCapacityService.UserGroupCapacityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UserGroupCapacityDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link UserGroupCapacityDto}.

    @author BoobaCool
               """)
public interface UserGroupCapacityRequestMapper
    extends RequestMapper<UserGroupCapacityDto, UserGroupCapacityCreateRequestDto,
        UserGroupCapacityUpdateRequestDto> {

}
