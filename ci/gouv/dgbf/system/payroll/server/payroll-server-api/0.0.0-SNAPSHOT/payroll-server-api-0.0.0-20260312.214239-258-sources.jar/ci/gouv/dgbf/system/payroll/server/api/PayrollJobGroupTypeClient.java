package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupTypeService.PayrollJobGroupTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollJobGroupTypeService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollJobGroupTypeClient extends AbstractClient<PayrollJobGroupTypeService>
    implements GetByIdentifier<PayrollJobGroupTypeDto>,
    GetMany<PayrollJobGroupTypeGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollJobGroupTypeClient service(PayrollJobGroupTypeService service) {
    return (PayrollJobGroupTypeClient) super.service(service);
  }

  /**
   * {@link PayrollJobGroupTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollJobGroupTypeCreateRequestDto request) {
    return new CreateExecutor(PayrollJobGroupTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollJobGroupTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollJobGroupTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupTypeGetManyResponseDto>(
        PayrollJobGroupTypeGetManyResponseDto.class, PayrollJobGroupTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }


  /**
   * {@link PayrollJobGroupTypeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public PayrollJobGroupTypeGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollJobGroupTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollJobGroupTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupTypeDto>(PayrollJobGroupTypeDto.class,
        PayrollJobGroupTypeService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollJobGroupTypeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollJobGroupTypeDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollJobGroupTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollJobGroupTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupTypeDto>(PayrollJobGroupTypeDto.class,
        PayrollJobGroupTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollJobGroupTypeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollJobGroupTypeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollJobGroupTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollJobGroupTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollJobGroupTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollJobGroupTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollJobGroupTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollJobGroupTypeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
