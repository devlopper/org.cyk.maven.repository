package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de est collectivité.
 *
 * @author Christian
 */
public interface HasIsLocalAuthority extends HasField {

  /**
   * Cette méthode permet d'obtenir est collectivité.
   *
   * @return est collectivité
   */
  Boolean getIsLocalAuthority();

  /**
   * Cette méthode permet d'assigner est collectivité.
   *
   * @param isLocalAuthority est collectivité
   */
  void setIsLocalAuthority(Boolean isLocalAuthority);

  /**
   * Identifiant java de est collectivité.
   */
  String FIELD_IS_LOCAL_AUTHORITY = "isLocalAuthority";
}
