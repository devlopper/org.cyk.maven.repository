package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ExpectedEffectDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-27T10:25:25+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ExpectedEffectRequestMapperImpl implements ExpectedEffectRequestMapper {

    @Override
    public ExpectedEffectService.ExpectedEffectCreateRequestDto mapCreate(ExpectedEffectDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpectedEffectService.ExpectedEffectCreateRequestDto expectedEffectCreateRequestDto = new ExpectedEffectService.ExpectedEffectCreateRequestDto();

        expectedEffectCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        expectedEffectCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        expectedEffectCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        expectedEffectCreateRequestDto.setObjectNature( arg0.getObjectNature() );
        expectedEffectCreateRequestDto.setObjectIdentifier( arg0.getObjectIdentifier() );
        expectedEffectCreateRequestDto.setRank( arg0.getRank() );

        return expectedEffectCreateRequestDto;
    }

    @Override
    public ExpectedEffectService.ExpectedEffectUpdateRequestDto mapUpdate(ExpectedEffectDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpectedEffectService.ExpectedEffectUpdateRequestDto expectedEffectUpdateRequestDto = new ExpectedEffectService.ExpectedEffectUpdateRequestDto();

        expectedEffectUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        expectedEffectUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        expectedEffectUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        expectedEffectUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        expectedEffectUpdateRequestDto.setObjectNature( arg0.getObjectNature() );
        expectedEffectUpdateRequestDto.setObjectIdentifier( arg0.getObjectIdentifier() );
        expectedEffectUpdateRequestDto.setRank( arg0.getRank() );

        return expectedEffectUpdateRequestDto;
    }
}
