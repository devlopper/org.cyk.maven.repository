package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantCategoryService.ConstantCategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ConstantCategoryDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ConstantCategoryDto}.

    @author Christian
               """)
public interface ConstantCategoryRequestMapper extends RequestMapper<ConstantCategoryDto,
    ConstantCategoryCreateRequestDto, ConstantCategoryUpdateRequestDto> {

}
