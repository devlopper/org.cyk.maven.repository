package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UserCapacityDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link UserCapacityDto}.

    @author BoobaCool
               """)
public interface UserCapacityRequestMapper
    extends RequestMapper<UserCapacityDto, UserCapacityCreateRequestDto,
        UserCapacityUpdateRequestDto> {

}
