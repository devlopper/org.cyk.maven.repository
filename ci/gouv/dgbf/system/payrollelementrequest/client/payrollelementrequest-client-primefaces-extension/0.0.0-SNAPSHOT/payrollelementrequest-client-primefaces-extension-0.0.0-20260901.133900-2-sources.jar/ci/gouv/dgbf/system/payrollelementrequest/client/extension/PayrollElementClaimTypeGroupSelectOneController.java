package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeGroupService.PayrollElementClaimTypeGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollElementClaimTypeGroupDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementClaimTypeGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<PayrollElementClaimTypeGroupDto,
        PayrollElementClaimTypeGroupGetManyResponseDto, PayrollElementClaimTypeGroupClient> {

  @Getter
  @Inject
  PayrollElementClaimTypeGroupClient client;

  protected PayrollElementClaimTypeGroupSelectOneController() {
    super(PayrollElementClaimTypeGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
