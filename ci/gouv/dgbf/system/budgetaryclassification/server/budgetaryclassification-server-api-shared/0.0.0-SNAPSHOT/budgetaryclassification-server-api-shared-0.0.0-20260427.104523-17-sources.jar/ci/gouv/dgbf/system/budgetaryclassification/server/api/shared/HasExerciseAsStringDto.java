package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseAsStringDto extends HasExerciseAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'exercice.
   */
  String JSON_EXERCISE_AS_STRING = "exerciceChaine";
}
