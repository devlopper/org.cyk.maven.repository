package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link IdentityEmailAddressStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class IdentityEmailAddressStatusManager
    extends AbstractStatusManager<IdentityEmailAddressStatus> {

  /**
   * Cette méthode permet d'instanctier.
   */
  public IdentityEmailAddressStatusManager() {
    super(IdentityEmailAddressStatus.class, e -> e.getName());
  }
}
