package ci.gouv.dgbf.system.ceadp.server.api;


import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une activité.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ActivityDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements TaskContainerableDto {

  /**
   * Identifiant de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Identifiant {@link ActivityTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caratères de {@link ActivityTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant {@link FolderDto}.
   */
  @JsonbProperty(JSON_FOLDER_IDENTIFIER)
  private String folderIdentifier;

  /**
   * Représentation en chaine de caratères de {@link FolderDto}.
   */
  @JsonbProperty(JSON_FOLDER_AS_STRING)
  private String folderAsString;

  /**
   * Identifiant de l'identité du responsable.
   */
  @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
  private String responsibleIdentityIdentifier;

  /**
   * Représentation en chaine de caratères de l'identité du responsable.
   */
  @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_AS_STRING)
  private String responsibleIdentityAsString;

  /**
   * Identifiant groupe de fichiers.
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Identifiant groupe d'identités.
   */
  @JsonbProperty(JSON_IDENTITIES_GROUP_IDENTIFIER)
  private String identitiesGroupIdentifier;

  /**
   * Statut.
   */
  @JsonbProperty(JSON_STATUS)
  private String status;

  /**
   * Description.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Est en retard.
   */
  @JsonbProperty(JSON_IS_LATE)
  private Boolean isLate;

  /**
   * Identifiant de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Représentation en chaîne de caractères de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant de la sous unité administrative.
   */
  @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String subAdministrativeUnitIdentifier;

  /**
   * Représentation en chaîne de caractères de la sous unité administrative.
   */
  @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_AS_STRING)
  private String subAdministrativeUnitAsString;

  /* Task container */

  @JsonbProperty(JSON_CREATED_TASK_COUNT_AS_STRING)
  private String createdTaskCountAsString;

  @JsonbProperty(JSON_SUSPENDED_TASK_COUNT_AS_STRING)
  private String suspendedTaskCountAsString;

  @JsonbProperty(JSON_STARTED_TASK_COUNT)
  private Integer startedTaskCount;

  @JsonbProperty(JSON_STARTED_TASK_COUNT_AS_STRING)
  private String startedTaskCountAsString;

  @JsonbProperty(JSON_STOPPED_TASK_COUNT_AS_STRING)
  private String stoppedTaskCountAsString;

  @JsonbProperty(JSON_REALIZED_TASK_COUNT)
  private Integer realizedTaskCount;

  @JsonbProperty(JSON_REALIZED_TASK_COUNT_AS_STRING)
  private String realizedTaskCountAsString;

  @JsonbProperty(JSON_LATE_TASK_COUNT)
  private Integer lateTaskCount;

  @JsonbProperty(JSON_LATE_TASK_COUNT_AS_STRING)
  private String lateTaskCountAsString;

  @JsonbProperty(JSON_NOT_LATE_TASK_COUNT_AS_STRING)
  private String notLateTaskCountAsString;

  @JsonbProperty(JSON_TASK_EARLIEST_FROM_DATE_AS_STRING)
  private String taskEarliestFromDateAsString;

  @JsonbProperty(JSON_TASK_LATEST_TO_DATE_AS_STRING)
  private String taskLatestToDateAsString;

  @JsonbProperty(JSON_TASK_COUNT)
  private Integer taskCount;

  @JsonbProperty(JSON_TASK_COUNT_AS_STRING)
  private String taskCountAsString;

  @JsonbProperty(JSON_DONE_TASK_COUNT)
  private Integer doneTaskCount;

  @JsonbProperty(JSON_DONE_TASK_COUNT_AS_STRING)
  private String doneTaskCountAsString;

  @JsonbProperty(JSON_NOT_DONE_TASK_COUNT_AS_STRING)
  private String notDoneTaskCountAsString;

  @JsonbProperty(JSON_PENDING_START_TASK_COUNT)
  private Integer pendingStartTaskCount;

  @JsonbProperty(JSON_PENDING_START_TASK_COUNT_AS_STRING)
  private String pendingStartTaskCountAsString;

  /**
   * Identifiant json de identifiant de {@link ActivityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idActivite";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ActivityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "activiteChaine";

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      AdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = "idType";

  /**
   * Identifiant json {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = "typeChaine";

  /**
   * Identifiant json {@link #folderIdentifier}.
   */
  public static final String JSON_FOLDER_IDENTIFIER = FolderDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #folderAsString}.
   */
  public static final String JSON_FOLDER_AS_STRING = FolderDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #responsibleIdentityIdentifier}.
   */
  public static final String JSON_RESPONSIBLE_IDENTITY_IDENTIFIER = "idIdentiteResponsable";

  /**
   * Identifiant json {@link #responsibleIdentityAsString}.
   */
  public static final String JSON_RESPONSIBLE_IDENTITY_AS_STRING = "identiteResponsableChaine";

  /**
   * Identifiant json champ {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "idGroupeFichiers";

  /**
   * Identifiant json champ {@link #identitiesGroupIdentifier}.
   */
  public static final String JSON_IDENTITIES_GROUP_IDENTIFIER = "idGroupeIdentites";

  /**
   * Identifiant json {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json du champ {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = "estEnRetard";

  /**
   * Identifiant json de l'identifiant de l'exercice budgétaire.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = "idExercice";

  /**
   * Identifiant json de la représentation en chaîne de caractères de l'exercice budgétaire.
   */
  public static final String JSON_EXERCISE_AS_STRING = "exerciceChaine";

  /**
   * Identifiant json de l'identifiant de la sous unité administrative.
   */
  public static final String JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER =
      "idSousUniteAdministrative";

  /**
   * Identifiant json de la représentation en chaîne de caractères de la sous unité administrative.
   */
  public static final String JSON_SUB_ADMINISTRATIVE_UNIT_AS_STRING =
      "sousUniteAdministrativeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "activité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
