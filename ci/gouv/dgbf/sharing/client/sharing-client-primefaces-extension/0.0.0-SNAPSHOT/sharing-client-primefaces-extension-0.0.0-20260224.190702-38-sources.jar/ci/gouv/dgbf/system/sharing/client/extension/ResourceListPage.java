package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ResourceListPage extends AbstractResourceListPage {

  /**
   * Cas de navigation.
   */
  public static final String OUTCOME = "resourceListPage";
}
