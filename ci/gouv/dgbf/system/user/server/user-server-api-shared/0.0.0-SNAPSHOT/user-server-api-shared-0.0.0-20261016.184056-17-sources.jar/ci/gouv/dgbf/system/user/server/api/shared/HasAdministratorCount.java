package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'administrateurs.
 *
 * @author Christian Yao Komenan
 */
public interface HasAdministratorCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'administrateurs.
   *
   * @return le nombre d'administrateurs
   */
  Integer getAdministratorCount();

  /**
   * Cette méthode permet d'assigner le nombre d'administrateurs.
   *
   * @param administratorCount le nombre d'administrateurs
   */
  void setAdministratorCount(Integer administratorCount);

  /**
   * Identifiant java du nombre d'administrateurs.
   */
  String FIELD_ADMINISTRATOR_COUNT = "administratorCount";
}
