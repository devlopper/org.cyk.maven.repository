package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SupportTeamMemberDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class SupportTeamMemberFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  private String supportTeamIdentifier;

  /**
   * Identifiant utilisateur.
   */
  private String userIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public SupportTeamMemberFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public SupportTeamMemberFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    supportTeamIdentifier = getSupportTeamIdentifier(filter);
    userIdentifier = getUserIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setSupportTeamIdentifier(filter, supportTeamIdentifier);
    setUserIdentifier(filter, userIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link SupportTeamDto}.
   *
   * @param filter                filtre
   * @param supportTeamIdentifier identifiant de {@link SupportTeamDto}
   */
  public static void setSupportTeamIdentifier(FilterDto filter, String supportTeamIdentifier) {
    set(filter, JSON_SUPPORT_TEAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(supportTeamIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link SupportTeamDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link SupportTeamDto}
   */
  public static String getSupportTeamIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SUPPORT_TEAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant utilisateur.
   *
   * @param filter         filtre
   * @param userIdentifier identifiant utilisateur
   */
  public static void setUserIdentifier(FilterDto filter, String userIdentifier) {
    set(filter, JSON_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(userIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant utilisateur.
   *
   * @param filter filtre
   * @return identifiant utilisateur
   */
  public static String getUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #supportTeamIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_IDENTIFIER =
      SupportTeamMemberDto.JSON_SUPPORT_TEAM_IDENTIFIER;

  /**
   * Identifiant json champ {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER =
      SupportTeamMemberDto.JSON_USER_IDENTIFIER;

}
