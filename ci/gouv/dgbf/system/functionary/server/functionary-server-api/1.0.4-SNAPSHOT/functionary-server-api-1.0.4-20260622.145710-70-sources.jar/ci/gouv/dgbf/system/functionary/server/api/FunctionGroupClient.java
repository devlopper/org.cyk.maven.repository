package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupGetManyResponseDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FunctionGroupService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FunctionGroupClient extends AbstractClient<FunctionGroupService>
    implements GetByIdentifier<FunctionGroupDto>, GetMany<FunctionGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FunctionGroupClient service(FunctionGroupService service) {
    return (FunctionGroupClient) super.service(service);
  }

  

  /**
   * {@link FunctionGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FunctionGroupCreateRequestDto request) {
    return new CreateExecutor(FunctionGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FunctionGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FunctionGroupGetManyResponseDto>(
      FunctionGroupGetManyResponseDto.class,
        FunctionGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }


  /**
   * {@link FunctionGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public FunctionGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FunctionGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FunctionGroupDto>(FunctionGroupDto.class,
        FunctionGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FunctionGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FunctionGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FunctionGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FunctionGroupDto>(FunctionGroupDto.class,
        FunctionGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FunctionGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionGroupDto getByIdentifier(String identifier, 
         ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FunctionGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FunctionGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(FunctionGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FunctionGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FunctionGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FunctionGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
