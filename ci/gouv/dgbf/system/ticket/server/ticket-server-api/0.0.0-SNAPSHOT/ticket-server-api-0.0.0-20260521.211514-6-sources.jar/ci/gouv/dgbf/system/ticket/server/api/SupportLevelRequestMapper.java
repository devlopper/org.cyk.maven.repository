package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.SupportLevelService.SupportLevelCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportLevelService.SupportLevelUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SupportLevelDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SupportLevelDto}.

    @author Arnaud
               """)
public interface SupportLevelRequestMapper
    extends RequestMapper<SupportLevelDto, SupportLevelCreateRequestDto,
     SupportLevelUpdateRequestDto> {

}
