package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimCircuitService.PayrollElementClaimCircuitRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimCircuitService.PayrollElementClaimCircuitResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollElementClaimCircuitService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollElementClaimCircuitClient
    extends AbstractClient<PayrollElementClaimCircuitService> {

  @Override
  public PayrollElementClaimCircuitClient service(PayrollElementClaimCircuitService service) {
    return (PayrollElementClaimCircuitClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimCircuitService#grantVisa}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto grantVisa(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.GRANT_VISA_IDENTIFIER)
            .execute(() -> service().grantVisa(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#transmitToControl}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto transmitToControl(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.TRANSMIT_TO_CONTROL_IDENTIFIER)
            .execute(() -> service().transmitToControl(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#control}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto control(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.CONTROL_IDENTIFIER)
            .execute(() -> service().control(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#transmitToValidation}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto transmitToValidation(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.TRANSMIT_TO_VALIDATION_IDENTIFIER)
            .execute(() -> service().transmitToValidation(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#validate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto validate(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.VALIDATE_IDENTIFIER)
            .execute(() -> service().validate(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#delegateToTreasury}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto delegateToTreasury(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.DELEGATE_TO_TREASURY_IDENTIFIER)
            .execute(() -> service().delegateToTreasury(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#treasuryValidate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto treasuryValidate(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.TREASURY_VALIDATE_IDENTIFIER)
            .execute(() -> service().treasuryValidate(request));
  }

  /**
   * {@link PayrollElementClaimCircuitService#reject}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimCircuitResponseDto reject(
      PayrollElementClaimCircuitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimCircuitResponseDto>(
        PayrollElementClaimCircuitResponseDto.class,
        PayrollElementClaimCircuitService.REJECT_IDENTIFIER)
            .execute(() -> service().reject(request));
  }
}
