package ci.gouv.dgbf.system.file.server.api;

/**
 * Codes des graphiques du tableau de bord du module Fichier (RG_FILE_UI_05).
 *
 * @author Christian
 *
 */
public interface FileDashboardChartCode {

  /**
   * Indicateurs clés (compteurs), dans l'ordre actionnable-en-premier de RG_FILE_UI_05.
   */
  String KPIS = "KPIS";

  /**
   * Évolution des archivages et désarchivages dans le temps.
   */
  String EVOLUTION = "EVOLUTION";

  /**
   * Répartition des Demandes d'archivage par Nature (Archivage/Retrait).
   */
  String DISTRIBUTION = "REPARTITION";

  /**
   * Évolution des créations de fichiers dans le temps.
   */
  String FILES_EVOLUTION = "EVOLUTION_FICHIERS";

  /**
   * Répartition des fichiers par nature du support (Numérique, Physique, Hybride).
   */
  String FILES_BY_MEDIUM_NATURE = "REPARTITION_SUPPORTS";
}
