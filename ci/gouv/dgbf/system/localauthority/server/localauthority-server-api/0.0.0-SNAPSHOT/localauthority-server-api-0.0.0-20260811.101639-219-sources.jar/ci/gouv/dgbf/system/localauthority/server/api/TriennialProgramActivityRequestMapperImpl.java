package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TriennialProgramActivityDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-11T10:17:05+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TriennialProgramActivityRequestMapperImpl implements TriennialProgramActivityRequestMapper {

    @Override
    public TriennialProgramActivityService.TriennialProgramActivityCreateRequestDto mapCreate(TriennialProgramActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramActivityService.TriennialProgramActivityCreateRequestDto triennialProgramActivityCreateRequestDto = new TriennialProgramActivityService.TriennialProgramActivityCreateRequestDto();

        triennialProgramActivityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramActivityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        triennialProgramActivityCreateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        triennialProgramActivityCreateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        triennialProgramActivityCreateRequestDto.setAmount( arg0.getAmount() );
        triennialProgramActivityCreateRequestDto.setJustification( arg0.getJustification() );
        triennialProgramActivityCreateRequestDto.setPriority( arg0.getPriority() );

        return triennialProgramActivityCreateRequestDto;
    }

    @Override
    public TriennialProgramActivityService.TriennialProgramActivityUpdateRequestDto mapUpdate(TriennialProgramActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramActivityService.TriennialProgramActivityUpdateRequestDto triennialProgramActivityUpdateRequestDto = new TriennialProgramActivityService.TriennialProgramActivityUpdateRequestDto();

        triennialProgramActivityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramActivityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        triennialProgramActivityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        triennialProgramActivityUpdateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        triennialProgramActivityUpdateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        triennialProgramActivityUpdateRequestDto.setAmount( arg0.getAmount() );
        triennialProgramActivityUpdateRequestDto.setJustification( arg0.getJustification() );
        triennialProgramActivityUpdateRequestDto.setPriority( arg0.getPriority() );

        return triennialProgramActivityUpdateRequestDto;
    }
}
