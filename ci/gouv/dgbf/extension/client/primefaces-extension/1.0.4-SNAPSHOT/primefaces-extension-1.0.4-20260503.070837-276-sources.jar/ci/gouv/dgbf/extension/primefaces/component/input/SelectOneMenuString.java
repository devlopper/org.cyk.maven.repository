package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une chaine de caratère par menu.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectOneMenuString extends AbstractSelectOneMenu<String> {

}
