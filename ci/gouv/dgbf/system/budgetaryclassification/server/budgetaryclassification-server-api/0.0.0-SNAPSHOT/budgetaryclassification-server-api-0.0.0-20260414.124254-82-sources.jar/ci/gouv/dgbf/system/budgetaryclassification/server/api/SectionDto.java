package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sectione.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SectionDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link SectionDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSection";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link SectionDto}.
   */
  public static final String JSON_THIS_AS_STRING = "sectionChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "section";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sections";
}
