package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UserCapacityDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-26T08:52:30+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UserCapacityRequestMapperImpl implements UserCapacityRequestMapper {

    @Override
    public UserCapacityService.UserCapacityCreateRequestDto mapCreate(UserCapacityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserCapacityService.UserCapacityCreateRequestDto userCapacityCreateRequestDto = new UserCapacityService.UserCapacityCreateRequestDto();

        userCapacityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        userCapacityCreateRequestDto.setCode( arg0.getCode() );
        userCapacityCreateRequestDto.setName( arg0.getName() );

        return userCapacityCreateRequestDto;
    }

    @Override
    public UserCapacityService.UserCapacityUpdateRequestDto mapUpdate(UserCapacityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserCapacityService.UserCapacityUpdateRequestDto userCapacityUpdateRequestDto = new UserCapacityService.UserCapacityUpdateRequestDto();

        userCapacityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        userCapacityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        userCapacityUpdateRequestDto.setCode( arg0.getCode() );
        userCapacityUpdateRequestDto.setName( arg0.getName() );

        return userCapacityUpdateRequestDto;
    }
}
