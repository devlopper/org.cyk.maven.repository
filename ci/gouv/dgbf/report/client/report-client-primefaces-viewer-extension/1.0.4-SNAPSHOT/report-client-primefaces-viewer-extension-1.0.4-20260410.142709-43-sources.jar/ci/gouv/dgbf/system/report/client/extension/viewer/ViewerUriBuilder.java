package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.ConfigurationHelper;
import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.JsonBuilder;
import ci.gouv.dgbf.extension.core.Jsonifier;
import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.core.UriBuilder;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService;
import ci.gouv.dgbf.system.report.server.api.ReportService.GetBytesByIdentifierRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un constructeur d'URI de visualisateur de rapport.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerUriBuilder {
  private static final Logger LOGGER = Logger.getLogger(ViewerUriBuilder.class.getName());

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private String reportIdentifier;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private String fileType;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private String windowName;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private Boolean customisable;
  /*
   * @Getter
   * 
   * @Setter
   * 
   * @Accessors(chain = true, fluent = true) private Boolean optionable;
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private String auditWho;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  private String auditSession;

  JsonBuilder reportParametersAsJsonBuilder;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  String reportParametersAsJson;

  @Inject
  StringHelper stringHelper;

  @Inject
  ConfigurationHelper configurationHelper;

  void validate() {
    if (stringHelper().isBlank(reportIdentifier)) {
      throw new IllegalArgumentException("L'identifiant du rapport est obligatoire");
    }
  }

  /**
   * Cette méthode permet de construire l'URI du visualisateur de rapport.
   *
   * @return URI
   */
  public URI build() {
    validate();
    FacesContext facesContext = FacesContext.getCurrentInstance();
    UriBuilder uriBuilder = new UriBuilder();
    HttpServletRequest request =
        (HttpServletRequest) facesContext.getExternalContext().getRequest();

    String scheme = request.getScheme();
    String host = request.getServerName();
    int port = request.getServerPort();
    String contextPath = facesContext.getExternalContext().getRequestContextPath();

    System.out.println("ViewerUriBuilder.build() +++ +++ +++ : %s://%s:%s/%s".formatted(scheme,
        host, port, contextPath));
    
    uriBuilder
        .scheme(configurationHelper().getValue(String.class,
            CONFIGURATION_PROPERTY_NAME_VIEWER_SCHEME, scheme))
        .host(configurationHelper().getValue(String.class, CONFIGURATION_PROPERTY_NAME_VIEWER_HOST,
            host))
        .port(configurationHelper().getValue(Integer.class, CONFIGURATION_PROPERTY_NAME_VIEWER_PORT,
            port));

    uriBuilder.pathBuilder().list().add(configurationHelper().getValue(String.class,
        CONFIGURATION_PROPERTY_NAME_VIEWER_PATH, contextPath));

    uriBuilder.queryBuilder().map().add(ByIdentifierRequestDto.JSON_IDENTIFIER, reportIdentifier);
    if (stringHelper.isBlank(reportParametersAsJson)) {
      String parametersAsJson = buildParameters();
      uriBuilder.queryBuilder().map().add(GetBytesByIdentifierRequestDto.JSON_PARAMETERS,
          URLEncoder.encode(parametersAsJson, StandardCharsets.UTF_8));
    } else {
      uriBuilder.queryBuilder().map().add(GetBytesByIdentifierRequestDto.JSON_PARAMETERS,
          reportParametersAsJson);
    }

    String localFileType =
        stringHelper().defaultToIfBlank(fileType, ReportService.DEFAULT_FILE_TYPE);
    uriBuilder.queryBuilder().map().add(GetBytesByIdentifierRequestDto.JSON_FILE_TYPE,
        localFileType);
    /*
     * if (optionable != null) { uriBuilder.queryBuilder().map().add(QUERY_PARAMETER_OPTIONABLE,
     * optionable.toString()); }
     */
    uriBuilder.queryBuilder().map().add(AbstractRequestDto.JSON_AUDIT_WHO, auditWho);
    uriBuilder.queryBuilder().map().add(AbstractAuditedRequestJsonDto.JSON_AUDIT_SESSION,
        auditSession);
    customise(uriBuilder);
    URI uri = uriBuilder.build();
    LOGGER.log(Level.FINER, "Uri du rapport construit. {0}", uri);
    return uri;
  }

  String buildParameters() {
    String string;
    if (reportParametersAsJsonBuilder == null) {
      string = Constant.EMPTY_STRING;
    } else {
      string = reportParametersAsJsonBuilder.build(new Jsonifier());
    }
    LOGGER.log(Level.FINER, "Paramètres construits. {0}", string);
    return string;
  }

  void customise(UriBuilder uriBuilder) {
    if (Boolean.TRUE.equals(customisable)) {
      uriBuilder.pathBuilder().list().add(configurationHelper().getValue(String.class,
          CONFIGURATION_PROPERTY_NAME_VIEWER_FILE, FILE));
      uriBuilder.queryBuilder().map().add(QUERY_PARAMETER_CUSTOMISABLE, Boolean.TRUE.toString());
    } else {
      uriBuilder.pathBuilder().list().add(PATH);
    }
  }

  /**
   * Cette méthode permet d'obtenir le constructeur json.
   *
   * @return constructeur json
   */
  public JsonBuilder reportParametersAsJsonBuilder() {
    if (reportParametersAsJsonBuilder == null) {
      reportParametersAsJsonBuilder = new JsonBuilder();
    }
    return reportParametersAsJsonBuilder;
  }

  StringHelper stringHelper() {
    if (stringHelper == null) {
      stringHelper = new StringHelper();
    }
    return stringHelper;
  }

  ConfigurationHelper configurationHelper() {
    if (configurationHelper == null) {
      configurationHelper = new ConfigurationHelper();
    }
    return configurationHelper;
  }

  static String buildConfigurationPropertyName(String value) {
    return String.format("%s.%s", "dgbf.system.report.viewer", value);
  }

  static final String PATH = "visualisateur";
  static final String FILE = "visualisateur.xhtml";

  static final String CONFIGURATION_PROPERTY_NAME_VIEWER_SCHEME =
      buildConfigurationPropertyName("scheme");
  static final String CONFIGURATION_PROPERTY_NAME_VIEWER_HOST =
      buildConfigurationPropertyName("host");
  static final String CONFIGURATION_PROPERTY_NAME_VIEWER_PORT =
      buildConfigurationPropertyName("port");
  static final String CONFIGURATION_PROPERTY_NAME_VIEWER_PATH =
      buildConfigurationPropertyName("path");
  static final String CONFIGURATION_PROPERTY_NAME_VIEWER_FILE =
      buildConfigurationPropertyName("file");

  /**
   * Personnalisable.
   */
  public static final String QUERY_PARAMETER_CUSTOMISABLE = "personnalisable";
}
