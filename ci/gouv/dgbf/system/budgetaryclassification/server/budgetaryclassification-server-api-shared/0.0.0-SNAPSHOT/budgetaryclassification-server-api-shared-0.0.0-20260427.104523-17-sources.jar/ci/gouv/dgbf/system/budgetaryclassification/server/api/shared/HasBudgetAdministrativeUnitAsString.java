package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'unité
 * administrative de budget.
 *
 * @author Christian
 */
public interface HasBudgetAdministrativeUnitAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'unité
   * administrative de budget.
   *
   * @return représentation en chaine de caractères de l'unité administrative de budget
   */
  String getBudgetAdministrativeUnitAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'unité
   * administrative de budget.
   *
   * @param asString représentation en chaine de caractères de l'unité administrative de budget
   */
  void setBudgetAdministrativeUnitAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'unité administrative de
   * budget.
   */
  String FIELD_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING = "budgetAdministrativeUnitAsString";
}
