package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobGroupService.PayrollJobGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollJobGroupService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollJobGroupClient extends AbstractClient<PayrollJobGroupService>
    implements GetByIdentifier<PayrollJobGroupDto>, 
               GetMany<PayrollJobGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollJobGroupClient service(PayrollJobGroupService service) {
    return (PayrollJobGroupClient) super.service(service);
  }

  /**
   * {@link PayrollJobGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollJobGroupCreateRequestDto request) {
    return new CreateExecutor(PayrollJobGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollJobGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollJobGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupGetManyResponseDto>(
        PayrollJobGroupGetManyResponseDto.class,
        PayrollJobGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollJobGroupService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */

  @Override
  public PayrollJobGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollJobGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollJobGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupDto>(PayrollJobGroupDto.class,
        PayrollJobGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollJobGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollJobGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollJobGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollJobGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollJobGroupDto>(PayrollJobGroupDto.class,
        PayrollJobGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollJobGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollJobGroupDto getByIdentifier(String identifier, 
             ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollJobGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollJobGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollJobGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollJobGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollJobGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollJobGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
