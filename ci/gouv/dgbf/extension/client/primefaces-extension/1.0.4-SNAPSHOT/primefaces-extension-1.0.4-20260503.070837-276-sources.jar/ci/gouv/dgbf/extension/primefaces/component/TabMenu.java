package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuModel;

/**
 * Cette classe représente un menu en onglet.
 *
 * @author Christian
 *
 */
public class TabMenu {

  @Getter
  @Setter
  Map<Object, String> outcomesMap;

  @Getter
  @Setter
  String selectedTabIndexParameterName;

  @Getter
  @Setter
  String menuItemStyleClassFormat;

  @Getter
  @Setter
  String menuItemStyleClassPrefix;

  Map<String, List<String>> menuItemParameters;
  
  int index;

  Collection<Tab> tabs;

  @Getter
  MenuModel model;

  /**
   * Cette méthode permet d'instantier.
   */
  public TabMenu() {
    outcomesMap = new HashMap<>();
    selectedTabIndexParameterName = "sti";
    menuItemStyleClassPrefix = "data";
    menuItemStyleClassFormat = "%s-tab-menu-item-%s";
  }

  protected Collection<Tab> tabs() {
    Core.runIfNull(tabs, () -> tabs = new ArrayList<>());
    return tabs;
  }
  
  public Map<String, List<String>> menuItemParameters() {
    Core.runIfNull(menuItemParameters, () -> menuItemParameters = new LinkedHashMap<>());
    return menuItemParameters;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    Optional.ofNullable(tabs).orElse(Collections.emptySet()).forEach(tab -> {
      tab.initialize(outcomesMap.get(tab.type));
      model().getElements().add(tab.model);
    });
  }

  MenuModel model() {
    Core.runIfNull(model, () -> model = new DefaultMenuModel());
    return model;
  }

  public TabBuilder tabBuilder() {
    return new TabBuilder();
  }

  /**
   * Cette classe représente un onglet.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class Tab {
    MenuItem menuItem;
    String count;
    Object type;
    Integer index;

    DefaultMenuItem model;

    void initialize(String outcome) {
      menuItem.setOutcome(outcome);
      menuItem.setValue(String.format("%s%s", menuItem.getValue(),
          Optional.ofNullable(count).map(c -> " - " + c).orElse(Constant.EMPTY_STRING)));
      model = menuItem.builder().build();
    }
  }

  /**
   * Cette class représente le constructeur de {@link Tab}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public class TabBuilder {
    String menuItemValue;
    String menuItemIcon;
    boolean menuItemEscape;
    String menuItemStyleClassSuffix;
    Map<String, List<String>> menuItemParameters;
    String count;
    Object type;
    Integer index;

    public TabBuilder() {
      menuItemEscape = true;
    }
    
    /**
     * Cette méthode permet d'aasigner une valeur et de ne pas echapper.
     *
     * @param value valeur
     * @return this
     */
    public TabBuilder menuItemNotEscapedValue(String value) {
      menuItemValue = value;
      menuItemEscape = false;
      return this;
    }
    
    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Tab}
     */
    public Tab build() {
      Tab tab = new Tab();
      tab.menuItem = new MenuItem();
      tab.menuItem.value = menuItemValue;
      tab.menuItem.icon = menuItemIcon;
      tab.menuItem.escape = menuItemEscape;

      addMenuItemParameter(selectedTabIndexParameterName,
          Optional.ofNullable(tabs).map(l -> l.size()).orElse(0));

      tab.menuItem.addParameters(menuItemParameters);
      tab.menuItem.addParameters(TabMenu.this.menuItemParameters);
      
      tab.menuItem.addStyleClass(
          menuItemStyleClassFormat.formatted(menuItemStyleClassPrefix, menuItemStyleClassSuffix));
      tab.type = type;
      tab.count = count;
      tab.index = index;
      tabs().add(tab);
      return tab;
    }
    
    /**
     * Cette méthode permet d'ajouter un paramètre d'élément de menu.
     *
     * @param name nom
     * @param value valeur
     * @param condition condition
     * @return this
     */
    public TabBuilder addMenuItemParameter(String name, Object value, Boolean condition) {
      if (condition != null && !condition) {
        return this;
      }
      if (Core.isStringBlank(name) || value == null) {
        return this;
      }
      String valueAsString = value.toString();
      if (Core.isStringBlank(valueAsString)) {
        return this;
      }
      List<String> list = menuItemParameters().get(name);
      if (list == null) {
        list = new ArrayList<>();
        menuItemParameters().put(name, list);
      }
      list.add(valueAsString);
      return this;
    }
    
    /**
     * Cette méthode permet d'ajouter un paramètre d'élément de menu.
     *
     * @param name nom
     * @param value valeur
     * @return this
     */
    public TabBuilder addMenuItemParameter(String name, Object value) {
      return addMenuItemParameter(name, value, null);
    }

    Map<String, List<String>> menuItemParameters() {
      Core.runIfNull(menuItemParameters, () -> menuItemParameters = new LinkedHashMap<>());
      return menuItemParameters;
    }
  }
}
