package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIsCompletedDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToInputNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToInputNAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants pour un regroupement de lignes de
 * dépense ou de recettes (par exemple : activité, action, unité de spécialisation du budget, unité
 * administrative, section).
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public abstract class AbstractGroupedAmountsContainerDto extends AbstractAmountsContainerDto
    implements HasTotalAmountToInputNAsStringDto, HasRemainingAmountToInputNAsStringDto,
    HasIsCompletedDto {

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INPUT_N_AS_STRING)
  protected String totalAmountToInputNAsString;

  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INPUT_N_AS_STRING)
  protected String remainingAmountToInputNAsString;

  @JsonbProperty(JSON_IS_COMPLETED)
  protected Boolean isCompleted;
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
