package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de lecture des {@link IdentityEmailAddressDto} d'une identité.
 *
 * @author Christian
 */
@Named
@ViewScoped
public class IdentityReadEmailAddressesPage extends AbstractIdentityReadEmailAddressesPage {

  public static final String OUTCOME = "identityReadEmailAddressesPage";
}
