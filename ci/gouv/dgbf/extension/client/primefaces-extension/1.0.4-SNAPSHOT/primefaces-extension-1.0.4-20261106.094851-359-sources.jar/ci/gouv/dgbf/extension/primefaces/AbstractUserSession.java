package ci.gouv.dgbf.extension.primefaces;

import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente la base des utilisateurs.
 *
 * @author Christian
 *
 */
public abstract class AbstractUserSession implements UserSession {

  @Getter
  protected User user;

  @PostConstruct
  void postConstruct() {
    initializeUser();
    deriveUserNullValues();
  }

  void deriveUserNullValues() {
    if (user.getNames() == null) {
      user.setNames(computeNames(user.getFirstName(), user.getLastNames(), user.getIdentifier()));
    }
  }

  /**
   * Cette méthode construit le nom affiché dans l'ordre « NOM Prénoms ».
   *
   * @param firstName nom de la personne
   * @param lastNames prénoms de la personne
   * @param identifier identifiant d'authentification, utilisé si ni le nom ni les prénoms ne sont
   *        renseignés
   * @return le nom affiché
   */
  static String computeNames(String firstName, String lastNames, String identifier) {
    String names = Stream.of(firstName, lastNames).filter(s -> s != null && !s.isBlank())
        .map(String::strip).collect(Collectors.joining(" "));
    return names.isEmpty() ? identifier : names;
  }

  protected void initializeUser() {
    user = new User();
    user.setIdentifier(getUserIdentifier());
    user.setFirstName(getUserFirstName());
    user.setLastNames(getUserLastNames());
    Set<String> roles = new LinkedHashSet<>(getUserRoles());
    roles.removeAll(List.of("offline_access", "uma_authorization"));
    user.setRoles(roles);
    Logger.getLogger(getClass().getName()).log(Level.INFO, "Utilisateur initialisé. {0}|Roles:{1}",
        new Object[] {user.getIdentifier(),
            user.getRoles().stream().collect(Collectors.joining(","))});
  }

  public String getUserIdentifier() {
    User u = getUser();
    return u == null ? null : u.getIdentifier();
  }

  /**
   * Cette méthode donne le nom de la personne (revendication OIDC {@code family_name}).
   *
   * @return le nom, ou null s'il n'est pas connu
   */
  protected String getUserFirstName() {
    return null;
  }

  /**
   * Cette méthode donne les prénoms de la personne (revendication OIDC {@code given_name}).
   *
   * @return les prénoms, ou null s'ils ne sont pas connus
   */
  protected String getUserLastNames() {
    return null;
  }

  protected abstract Set<String> getUserRoles();

  protected abstract String getOidcAuthServerUrl();

  /**
   * Cette méthode permet de déconnecter l'utilisateur.
   *
   * @return navigation
   */
  public String logout() {
    HttpServletRequest request =
        (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
    HttpServletResponse response =
        (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext().getResponse();
    try {
      logout(request);
      deleteCookies(request, response);
      gotoIndexPage(request);
    } catch (Exception exception) {
      throw new LogoutException(exception);
    }
    return null;
  }

  void logout(HttpServletRequest request) throws ServletException {
    request.getSession().invalidate();
    request.logout();
  }

  void deleteCookies(HttpServletRequest request, HttpServletResponse response) {
    Cookie[] cookies = request.getCookies();
    if (cookies != null) {
      for (Cookie cookie : cookies) {
        cookie.setMaxAge(0);
        cookie.setPath("/"); // Assurez-vous que le chemin du cookie correspond au chemin d'origine
        response.addCookie(cookie);
      }
    }
  }

  void gotoIndexPage(HttpServletRequest request) throws IOException {
    FacesContext.getCurrentInstance().getExternalContext()
        .redirect(getOidcAuthServerUrl() + String.format(
            "/protocol/openid-connect/logout?redirect_uri=%s://%s:%s/%s", request.getScheme(),
            request.getServerName(), request.getServerPort(), request.getContextPath()));
  }
}
