package ci.gouv.dgbf.system.file.client.extension.dashboard;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page du tableau de bord administrateur du module Fichier.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class AdministratorDashboardPage extends AbstractPage {

  @Inject
  @Getter
  FileDashboardController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Tableau de bord";
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "administratorDashboardPage";
}
