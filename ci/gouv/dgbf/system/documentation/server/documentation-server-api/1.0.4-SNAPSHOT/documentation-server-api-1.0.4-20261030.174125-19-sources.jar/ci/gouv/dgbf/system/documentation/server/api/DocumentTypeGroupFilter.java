package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les groupes de type de document.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentTypeGroupFilter extends AbstractIdentifiableFilter
    implements HasGroupIdentifier, HasTypeIdentifier {

  /**
   * Identifiant du groupe de types de document ({@link DocumentTypesGroupDto}) auquel le type de
   * document est rattaché.
   */
  String groupIdentifier;

  /**
   * Identifiant du type de document ({@link DocumentTypeDto}) rattaché au groupe de types de
   * document -- utilisé par le client pour résoudre le {@link DocumentTypeGroupDto} exact à partir
   * du type et du groupe de types choisis au dépôt d'un {@link DocumentDto}.
   */
  String typeIdentifier;

  /**
   * Caractère obligatoire du dépôt d'un document de ce type -- permet au client de ne lire que les
   * pièces obligatoires (ou facultatives) d'un groupe de types de document.
   */
  Boolean required;

  /**
   * Identifiant du groupe de documents ({@link DocumentGroupDto}), le dossier, auquel se rapporte
   * le critère {@link #deposited}. Seul, il ne filtre rien.
   */
  String documentGroupIdentifier;

  /**
   * Présence d'un document pour le rattachement dans le groupe de documents
   * {@link #documentGroupIdentifier} : {@code true} pour les rattachements ayant au moins un
   * document déposé, {@code false} pour ceux qui n'en ont aucun, {@code null} pour ne pas
   * contraindre. Sans {@link #documentGroupIdentifier}, il est sans effet. Combiné à
   * {@link #required}, permet au client de lire directement les pièces obligatoires manquantes
   * (ou déjà fournies) d'un dossier.
   */
  Boolean deposited;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DocumentTypeGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DocumentTypeGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
    typeIdentifier = getTypeIdentifier(filter);
    required = getRequired(filter);
    documentGroupIdentifier = getDocumentGroupIdentifier(filter);
    deposited = getDeposited(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setTypeIdentifier(filter, typeIdentifier);
    setRequired(filter, required);
    setDocumentGroupIdentifier(filter, documentGroupIdentifier);
    setDeposited(filter, deposited);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de types de document.
   *
   * @param filter filtre
   * @param groupIdentifier identifiant du groupe de types de document
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de types de document -- sans elle, le
   * critère envoyé par le client (ex. {@code DocumentGroupExpectedDocumentController.refresh})
   * serait silencieusement ignoré : {@code DocumentTypeGroupClient.getMany(...)} retournerait
   * tous les rattachements type/groupe, et non les seuls types attendus du groupe de types
   * sélectionné.
   *
   * @param filter filtre
   * @return identifiant du groupe de types de document
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type de document.
   *
   * @param filter filtre
   * @param typeIdentifier identifiant du type de document
   */
  public static void setTypeIdentifier(FilterDto filter, String typeIdentifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(typeIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de document -- utilisé par le client pour
   * résoudre le {@link DocumentTypeGroupDto} exact à partir du type et du groupe de types choisis
   * au dépôt d'un {@link DocumentDto}.
   *
   * @param filter filtre
   * @return identifiant du type de document
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le caractère obligatoire du dépôt.
   *
   * @param filter filtre
   * @param required obligatoire ou non
   */
  public static void setRequired(FilterDto filter, Boolean required) {
    set(filter, JSON_REQUIRED, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(required));
  }

  /**
   * Cette méthode permet d'obtenir le caractère obligatoire du dépôt.
   *
   * @param filter filtre
   * @return obligatoire ou non
   */
  public static Boolean getRequired(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_REQUIRED));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de documents (le dossier) auquel se
   * rapporte le critère de présence de document.
   *
   * @param filter filtre
   * @param documentGroupIdentifier identifiant du groupe de documents
   */
  public static void setDocumentGroupIdentifier(FilterDto filter, String documentGroupIdentifier) {
    set(filter, JSON_DOCUMENT_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(documentGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de documents (le dossier) auquel se
   * rapporte le critère de présence de document.
   *
   * @param filter filtre
   * @return identifiant du groupe de documents
   */
  public static String getDocumentGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_DOCUMENT_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner la présence de document pour le rattachement dans le groupe de
   * documents.
   *
   * @param filter filtre
   * @param deposited true pour les rattachements avec document, false pour ceux sans document
   */
  public static void setDeposited(FilterDto filter, Boolean deposited) {
    set(filter, JSON_DEPOSITED, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(deposited));
  }

  /**
   * Cette méthode permet d'obtenir la présence de document pour le rattachement dans le groupe de
   * documents.
   *
   * @param filter filtre
   * @return true pour les rattachements avec document, false pour ceux sans document
   */
  public static Boolean getDeposited(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_DEPOSITED));
  }

  /**
   * Identifiant json champ {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = HasTypeIdentifierDto.JSON_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #required}.
   */
  public static final String JSON_REQUIRED = DocumentTypeGroupDto.JSON_REQUIRED;

  /**
   * Identifiant json champ {@link #documentGroupIdentifier}.
   */
  public static final String JSON_DOCUMENT_GROUP_IDENTIFIER = "idGroupeDocuments";

  /**
   * Identifiant json champ {@link #deposited}.
   */
  public static final String JSON_DEPOSITED = "depose";
}
