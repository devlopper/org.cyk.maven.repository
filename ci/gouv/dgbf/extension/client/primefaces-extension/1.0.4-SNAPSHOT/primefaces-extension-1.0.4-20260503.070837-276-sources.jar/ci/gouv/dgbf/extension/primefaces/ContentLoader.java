package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un chargeur de contenu.
 *
 * @author Christian
 */
public class ContentLoader {

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  String name;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  Runnable loader;

  @Getter
  boolean loaded;

  /**
   * Cette méthode permet de charger.
   */
  public void load() {
    Core.doThrowIfNull(IllegalArgumentException.class,
        "Fonction de chargement de contenu <<%s>> requise".formatted(name), loader);
    if (!loaded) {
      loader.run();
      loaded = true;
    }
  }
}
