package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être redirigé.
 *
 * @author Christian
 */
public interface HasRedirectableDto extends HasRedirectable {

  /**
   * Identifiant json de peut être redirigé.
   */
  String JSON_REDIRECTABLE = "peutEtreRedirige";
}