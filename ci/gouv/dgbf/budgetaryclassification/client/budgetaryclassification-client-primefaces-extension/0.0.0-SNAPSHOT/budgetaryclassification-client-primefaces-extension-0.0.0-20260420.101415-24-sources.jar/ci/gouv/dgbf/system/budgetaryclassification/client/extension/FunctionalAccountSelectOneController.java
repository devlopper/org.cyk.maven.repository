package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FunctionalAccountClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FunctionalAccountDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FunctionalAccountService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FunctionalAccountDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class FunctionalAccountSelectOneController extends AbstractSelectOneIdentifiableController<
    FunctionalAccountDto, GetManyResponseDto, FunctionalAccountClient> {

  @Inject
  @Getter
  FunctionalAccountClient client;

  protected FunctionalAccountSelectOneController() {
    super(FunctionalAccountDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
