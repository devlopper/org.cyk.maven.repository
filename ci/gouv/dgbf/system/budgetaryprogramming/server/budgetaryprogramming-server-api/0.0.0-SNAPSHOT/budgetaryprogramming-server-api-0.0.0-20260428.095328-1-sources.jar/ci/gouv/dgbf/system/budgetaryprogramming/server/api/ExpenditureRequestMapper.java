package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ExpenditureService.ExpenditureCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ExpenditureService.ExpenditureUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ExpenditureDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ExpenditureDto}.

    @author Christian
               """)
public interface ExpenditureRequestMapper
    extends RequestMapper<ExpenditureDto, ExpenditureCreateRequestDto,
        ExpenditureUpdateRequestDto> {

}
