package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationIdentifierDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une dépense ou d'une recette de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractProgrammingExpenditureOrRevenueDto
    extends AbstractImputationAmountsContainerDto
    implements HasImputationIdentifierDto, HasImputationAsStringDto {

}
