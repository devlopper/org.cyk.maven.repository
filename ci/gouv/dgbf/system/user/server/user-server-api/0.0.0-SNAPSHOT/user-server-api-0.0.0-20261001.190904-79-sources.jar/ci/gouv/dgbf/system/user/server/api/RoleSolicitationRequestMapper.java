package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationService.RoleSolicitationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RoleSolicitationDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link RoleSolicitationDto}.

    @author BoobaCool
               """)
public interface RoleSolicitationRequestMapper
    extends RequestMapper<RoleSolicitationDto, RoleSolicitationCreateRequestDto,
      RoleSolicitationUpdateRequestDto> {

}
