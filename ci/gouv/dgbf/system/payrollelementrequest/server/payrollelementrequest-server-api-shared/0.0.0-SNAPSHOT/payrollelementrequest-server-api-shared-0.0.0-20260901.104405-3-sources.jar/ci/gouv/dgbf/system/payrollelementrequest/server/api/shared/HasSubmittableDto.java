package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action
 * Soumission (RG_REP_STA_01) sur une réponse de traitement (motif R44/R45).
 *
 * @author akm
 *
 */
public interface HasSubmittableDto {

  /**
   * Identifiant json de {@link #getSubmittable()}.
   */
  String JSON_SUBMITTABLE = "soumissible";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Soumission.
   *
   * @return indicateur de disponibilité de l'action Soumission
   */
  Boolean getSubmittable();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Soumission.
   *
   * @param submittable indicateur de disponibilité de l'action Soumission
   */
  void setSubmittable(Boolean submittable);
}
