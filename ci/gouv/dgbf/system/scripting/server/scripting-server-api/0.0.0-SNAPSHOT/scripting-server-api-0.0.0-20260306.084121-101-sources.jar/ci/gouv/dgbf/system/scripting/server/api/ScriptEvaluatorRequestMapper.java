package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluatorService.ScriptEvaluatorCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluatorService.ScriptEvaluatorUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptEvaluatorDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptEvaluatorDto}.

    @author Christian
               """)
public interface ScriptEvaluatorRequestMapper extends RequestMapper<ScriptEvaluatorDto,
    ScriptEvaluatorCreateRequestDto, ScriptEvaluatorUpdateRequestDto> {

}
