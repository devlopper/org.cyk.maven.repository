package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ColorCore;
import ci.gouv.dgbf.extension.core.ColorPalette;
import ci.gouv.dgbf.extension.core.Core;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.ApplicationScoped;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de graphique.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ChartManager {

  @Getter
  ColorPalette colorPalette;
  
  @Getter
  List<String> colors;

  @Getter
  List<String> colorsWithReducedAlpha;

  int alpha;

  @Getter
  @Setter
  Color nullColor;

  public ChartManager() {
    alpha = 30;
    colorPalette = new ColorPalette();
  }

  @PostConstruct
  protected void postConstruct() {
    initialiseColors();
  }

  /**
   * Cette méthode permet d'initialiser les couleurs.
   */
  public void initialiseColors() {    
    Core.runIfNull(nullColor, () -> nullColor = new Color(0, 0, 0));
    Core.runIfNull(colors, () -> {
      colors = new ArrayList<>();
      colors.add("rgb(0, 102, 204)");
      colors.add("rgb(255, 165, 0)");
      colors.add("rgb(0, 128, 0)");
      colors.add("rgb(139, 69, 19)");
      colors.add("rgb(128, 0, 128)");
      colors.add("rgb(0, 255, 255)");
      colors.add("rgb(255, 255, 0)");
      colors.add("rgb(255, 69, 0)");
      colors.add("rgb(0, 204, 102)");
      colors.add("rgb(160, 82, 45)");
      colors.add("rgb(75, 0, 130)");
      colors.add("rgb(255, 140, 0)");
      colors.add("rgb(0, 139, 139)");
      colors.add("rgb(255, 215, 0)");
      colors.add("rgb(139, 0, 0)");
      colors.add("rgb(0, 128, 128)");
      colors.add("rgb(255, 20, 147)");
      colors.add("rgb(0, 128, 128)");
      colors.add("rgb(70, 130, 180)");
      colors.add("rgb(255, 182, 193)");
      colors.add("rgb(34, 139, 34)");
      colors.add("rgb(255, 69, 0)");
      colors.add("rgb(128, 128, 0)");
      colors.add("rgb(255, 0, 255)");
      colors.add("rgb(0, 0, 139)");

      colorsWithReducedAlpha =
          ColorCore.encodeRgbaColorsFromDecodedRgbColors(colors, alpha, nullColor);
      Logger.getLogger(getClass().getName()).log(Level.CONFIG,
          "Colors initialized. alpha={0}, count={1}", new Object[] {alpha, colors.size()});
    });
  }
}
