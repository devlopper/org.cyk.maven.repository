package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une adresse de destinataire.
 *
 * @author Christian
 */
public interface HasReceiverAddress extends HasField {

  /**
   * Cette méthode permet d'obtenir l'adresse du destinataire.
   *
   * @return l'adresse du destinataire
   */
  String getReceiverAddress();

  /**
   * Cette méthode permet d'assigner l'adresse du destinataire.
   *
   * @param receiverAddress l'adresse du destinataire
   */
  void setReceiverAddress(String receiverAddress);

  /**
   * Identifiant java de l'adresse du destinataire.
   */
  String FIELD_RECEIVER_ADDRESS = "receiverAddress";
}
