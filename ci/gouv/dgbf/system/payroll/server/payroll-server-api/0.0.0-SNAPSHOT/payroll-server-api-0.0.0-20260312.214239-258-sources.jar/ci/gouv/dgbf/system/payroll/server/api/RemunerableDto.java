package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConstantGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEnabledAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsEnabledDto;
import ci.gouv.dgbf.extension.core.segregation.HasRegistrationNumberDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTemplateAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTemplateIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTypeAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipTypeIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rémunérable.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RemunerableDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasFunctionaryIdentifierDto, HasFunctionaryAsStringDto, HasRegistrationNumberDto,
    HasPayslipTypeIdentifierDto, HasPayslipTypeAsStringDto, HasPayslipTemplateIdentifierDto,
    HasPayslipTemplateAsStringDto, HasConstantGroupIdentifierDto, HasConstantGroupAsStringDto,
    HasIsEnabledDto, HasIsEnabledAsStringDto {

  @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
  private String functionaryIdentifier;

  @JsonbProperty(JSON_FUNCTIONARY_AS_STRING)
  private String functionaryAsString;

  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  @JsonbProperty(JSON_PAYSLIP_TYPE_IDENTIFIER)
  private String payslipTypeIdentifier;

  @JsonbProperty(JSON_PAYSLIP_TYPE_AS_STRING)
  private String payslipTypeAsString;

  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
  private String payslipTemplateIdentifier;

  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_AS_STRING)
  private String payslipTemplateAsString;

  @JsonbProperty(JSON_CONSTANT_GROUP_IDENTIFIER)
  private String constantGroupIdentifier;

  @JsonbProperty(JSON_CONSTANT_GROUP_AS_STRING)
  private String constantGroupAsString;
  
  @JsonbProperty(JSON_IS_ENABLED)
  private Boolean isEnabled;

  @JsonbProperty(JSON_IS_ENABLED_AS_STRING)
  private String isEnabledAsString;


  /**
   * Identifiant json de identifiant de {@link RemunerableDto}.
   */
  public static final String JSON_THIS_IDENTIFIER =
      HasRemunerableIdentifierDto.JSON_REMUNERABLE_IDENTIFIER;

  /**
   * Identifiant json de représentation en chaine de caractères de {@link RemunerableDto}.
   */
  public static final String JSON_THIS_AS_STRING =
      HasRemunerableAsStringDto.JSON_REMUNERABLE_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rémunérable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
