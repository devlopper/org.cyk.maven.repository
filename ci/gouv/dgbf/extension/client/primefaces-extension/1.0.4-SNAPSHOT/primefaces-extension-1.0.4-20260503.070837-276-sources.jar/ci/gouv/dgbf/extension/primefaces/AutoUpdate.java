package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.Core.ConcatenateArguments;
import ci.gouv.dgbf.extension.core.NonBlankStringList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un mise à jour automatique.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AutoUpdate {

  String on;
  
  boolean disabled;

  public AutoUpdate() {
    disabled = false;
  }

  /**
   * Cette méthode permet d'ajouter des évènement.
   *
   * @param ons évènements
   * @return this
   */
  public AutoUpdate addOns(List<String> ons) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(on).add(ons);
    on = Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(","));
    return this;
  }

  public AutoUpdate addOns(String... ons) {
    return addOns(Arrays.stream(Optional.ofNullable(ons).orElse(new String[] {})).toList());
  }

  public AutoUpdate addOn(String on) {
    return addOns(on);
  }
}
