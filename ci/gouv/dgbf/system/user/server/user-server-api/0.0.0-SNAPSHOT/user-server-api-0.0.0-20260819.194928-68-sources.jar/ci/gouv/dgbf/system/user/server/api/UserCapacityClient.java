package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link UserCapacityDto}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
public class UserCapacityClient extends AbstractClient<UserCapacityService>
    implements GetByIdentifier<UserCapacityDto>, GetMany<UserCapacityGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link UserCapacityService}
   * @return client {@link UserCapacityClient}
   */
  @Override
  public UserCapacityClient service(UserCapacityService service) {
    return (UserCapacityClient) super.service(service);
  }

  /**
   * {@link UserCapacityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(UserCapacityCreateRequestDto request) {
    return new CreateExecutor(UserCapacityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link UserCapacityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public UserCapacityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<UserCapacityGetManyResponseDto>(UserCapacityGetManyResponseDto.class,
        UserCapacityService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link UserCapacityService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserCapacityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link UserCapacityService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public UserCapacityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    return new GetOneExecutor<UserCapacityDto>(UserCapacityDto.class,
        UserCapacityService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link UserCapacityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserCapacityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    return new GetOneExecutor<UserCapacityDto>(UserCapacityDto.class,
        UserCapacityService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link UserCapacityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(UserCapacityUpdateRequestDto request) {
    return new IdentifiableExecutor(UserCapacityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link UserCapacityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(UserCapacityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link UserCapacityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
