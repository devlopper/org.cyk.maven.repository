package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un poste de ressource.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceItemDto extends AbstractExpenditureOrResourceItemDto {

  /*
   * Identifiant {@link ResourceActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /*
   * Code {@link ResourceActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_CODE)
  private String activityCode;

  /*
   * Réprésentation en chaine de caractère {@link ResourceActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Identifiant json champ {@link ResourceItemDto#activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link ResourceItemDto#activityCode}.
   */
  public static final String JSON_ACTIVITY_CODE =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_CODE;

  /**
   * Identifiant json champ {@link ResourceItemDto#activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING =
      AbstractExpenditureOrResourceItemDto.JSON_ACTIVITY_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de ressource";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de ressource";
}
