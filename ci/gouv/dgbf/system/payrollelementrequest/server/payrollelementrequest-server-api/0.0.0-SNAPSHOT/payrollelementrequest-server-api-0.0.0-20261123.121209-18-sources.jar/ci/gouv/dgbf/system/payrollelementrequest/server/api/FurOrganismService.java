package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link FurOrganismDto}. N'étend
 * pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link FurOrganismDto} n'a ni code ni nom propres : l'organisme est identifié par son code
 * organisme du FUR.
 *
 * @author akm
 *
 */
@Path(FurOrganismService.PATH)
@Tag(name = "Gestion des organismes du FUR")
public interface FurOrganismService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "organismes-fur";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface FurOrganismSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le code organisme du FUR.
     *
     * @return le code organisme du FUR
     */
    String getOrganismCode();

    /**
     * Cette méthode permet d'assigner le code organisme du FUR.
     *
     * @param organismCode le code organisme du FUR
     */
    void setOrganismCode(String organismCode);

    /**
     * Cette méthode permet d'obtenir le code de l'organisme de tutelle.
     *
     * @return le code de l'organisme de tutelle
     */
    String getGuardianOrganismCode();

    /**
     * Cette méthode permet d'assigner le code de l'organisme de tutelle.
     *
     * @param guardianOrganismCode le code de l'organisme de tutelle
     */
    void setGuardianOrganismCode(String guardianOrganismCode);

    /**
     * Cette méthode permet d'obtenir le code du service par défaut.
     *
     * @return le code du service par défaut
     */
    String getServiceCode();

    /**
     * Cette méthode permet d'assigner le code du service par défaut.
     *
     * @param serviceCode le code du service par défaut
     */
    void setServiceCode(String serviceCode);

    /**
     * Cette méthode permet d'obtenir le code de la section CALO.
     *
     * @return le code de la section CALO
     */
    String getCaloSectionCode();

    /**
     * Cette méthode permet d'assigner le code de la section CALO.
     *
     * @param caloSectionCode le code de la section CALO
     */
    void setCaloSectionCode(String caloSectionCode);

    /**
     * Cette méthode permet d'obtenir le code du service par défaut CALO.
     *
     * @return le code du service par défaut CALO
     */
    String getCaloServiceCode();

    /**
     * Cette méthode permet d'assigner le code du service par défaut CALO.
     *
     * @param caloServiceCode le code du service par défaut CALO
     */
    void setCaloServiceCode(String caloServiceCode);

    /**
     * {@link FurOrganismDto#JSON_ORGANISM_CODE}.
     */
    String JSON_ORGANISM_CODE = FurOrganismDto.JSON_ORGANISM_CODE;

    /**
     * {@link FurOrganismDto#JSON_GUARDIAN_ORGANISM_CODE}.
     */
    String JSON_GUARDIAN_ORGANISM_CODE = FurOrganismDto.JSON_GUARDIAN_ORGANISM_CODE;

    /**
     * {@link FurOrganismDto#JSON_SERVICE_CODE}.
     */
    String JSON_SERVICE_CODE = FurOrganismDto.JSON_SERVICE_CODE;

    /**
     * {@link FurOrganismDto#JSON_CALO_SECTION_CODE}.
     */
    String JSON_CALO_SECTION_CODE = FurOrganismDto.JSON_CALO_SECTION_CODE;

    /**
     * {@link FurOrganismDto#JSON_CALO_SERVICE_CODE}.
     */
    String JSON_CALO_SERVICE_CODE = FurOrganismDto.JSON_CALO_SERVICE_CODE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ORGANISME_FUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FurOrganismDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FurOrganismCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurOrganismCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements FurOrganismSaveRequestDto {

    @JsonbProperty(JSON_ORGANISM_CODE)
    private String organismCode;

    @JsonbProperty(JSON_GUARDIAN_ORGANISM_CODE)
    private String guardianOrganismCode;

    @JsonbProperty(JSON_SERVICE_CODE)
    private String serviceCode;

    @JsonbProperty(JSON_CALO_SECTION_CODE)
    private String caloSectionCode;

    @JsonbProperty(JSON_CALO_SERVICE_CODE)
    private String caloServiceCode;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ORGANISME_FUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class FurOrganismGetManyResponseDto
      extends AbstractGetByPageResponseDto<FurOrganismDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FurOrganismDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ORGANISME_FUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ORGANISME_FUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link FurOrganismDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FurOrganismDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ORGANISME_FUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FurOrganismDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FurOrganismUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurOrganismUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements FurOrganismSaveRequestDto {

    @JsonbProperty(JSON_ORGANISM_CODE)
    private String organismCode;

    @JsonbProperty(JSON_GUARDIAN_ORGANISM_CODE)
    private String guardianOrganismCode;

    @JsonbProperty(JSON_SERVICE_CODE)
    private String serviceCode;

    @JsonbProperty(JSON_CALO_SECTION_CODE)
    private String caloSectionCode;

    @JsonbProperty(JSON_CALO_SERVICE_CODE)
    private String caloServiceCode;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ORGANISME_FUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FurOrganismDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
