package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SupportTeamExpertiseDto}.
 *
 * @author kimou
 *
 */
@Getter
@Setter
public class SupportTeamExpertiseFilter extends AbstractIdentifiableFilter {

}

