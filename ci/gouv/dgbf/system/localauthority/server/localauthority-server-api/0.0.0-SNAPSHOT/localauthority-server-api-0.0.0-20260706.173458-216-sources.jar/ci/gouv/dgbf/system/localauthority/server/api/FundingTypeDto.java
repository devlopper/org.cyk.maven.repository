package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;

/**
 * Cette classe représente un type de financement.
 *
 * @author Christian
 *
 */
public class FundingTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de financement";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de financement";
}
