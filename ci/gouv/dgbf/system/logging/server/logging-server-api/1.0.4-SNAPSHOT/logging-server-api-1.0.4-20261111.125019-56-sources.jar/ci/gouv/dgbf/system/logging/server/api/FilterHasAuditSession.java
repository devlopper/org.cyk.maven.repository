package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente un filtre ayant une notion de session d'audit.
 *
 * @author Christian
 */
public interface FilterHasAuditSession {

  /**
   * Cette méthode permet d'obtenir la session d'audit.
   *
   * @return session d'audit
   */
  String getAuditSession();

  /**
   * Cette méthode permet d'assigner la session d'audit.
   *
   * @param auditSession session d'audit
   */
  void setAuditSession(String auditSession);

  /**
   * Cette méthode permet de mettre à jour la session d'audit depuis le filtre.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAuditSession(FilterDto filter) {
    setAuditSession(AuditSessionFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour le filtre avec la session d'audit.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAuditSession(FilterDto filter) {
    AuditSessionFilter.set(filter, getAuditSession());
  }

}

