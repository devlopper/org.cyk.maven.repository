package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.segregation.Componentable;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de contrôleur d'action.
 *
 * @author Christian
 *
 */
public abstract class AbstractActionController<R> extends AbstractController {

  @Getter
  @Setter
  protected String eventIdentifier;
  
  @Getter
  @Setter
  protected Consumer<R> responseConsumer;

  @Inject
  @Getter
  @Setter
  protected NotificationPublishController notificationPublishController;

  @Getter
  @Setter
  protected Function<Object, Boolean> isEnabledFunction;

  @Inject
  protected ComponentManager componentManager;

  /**
   * Collection de {@link Componentable} à mettre à jour après une exécution sans exception de
   * l'action.
   */
  protected Collection<Componentable> updatablesComponents;

  /**
   * Collection d'expression à mettre à jour après une exécution sans exception de
   * l'action.
   */
  protected Set<String> updatablesExpressions;
    
  /**
   * Cette méthode permet d'ajouter un consommateur de réponse.
   *
   * @param consumer consommateur
   */
  public void addResponseConsumer(Consumer<R> consumer) {
    if (consumer != null) {
      if (responseConsumer == null) {
        responseConsumer = consumer;
      } else {
        responseConsumer = responseConsumer.andThen(consumer);
      }
    }
  }

  /**
   * Cette méthode permet d'obtenir la collection de {@link Componentable} à mettre a jour.
   *
   * @return collection de {@link Componentable} à mettre a jour
   */
  public Collection<Componentable> updatablesComponents() {
    updatablesComponents = Core.getOrInstantiateIfNull(updatablesComponents, ArrayList::new);
    return updatablesComponents;
  }
  
  /**
   * Cette méthode permet d'obtenir la collection d'expression à mettre a jour.
   *
   * @return collection d'expression à mettre a jour
   */
  public Set<String> updatablesExpressions() {
    updatablesExpressions = Core.getOrInstantiateIfNull(updatablesExpressions, HashSet::new);
    return updatablesExpressions;
  }

  /**
   * Cette méthode permet de mettre à jour {@link #updatablesComponents}.
   */
  public void updateComponents() {
    componentManager.update(updatablesComponents);
    componentManager.updateByExpressions(updatablesExpressions);
  }

  protected void processResponse(R response) {
    if (response == null) {
      processResponseWhenNull();
    } else {
      processResponseWhenNotNull(response);
    }
  }

  protected void processResponseWhenNull() {}

  protected void processResponseWhenNotNull(R response) {
    if (responseConsumer != null) {
      responseConsumer.accept(response);
    }
  }

  protected void publishNotification(R response) {
    String notificationMessage = buildNotificationMessage(response);
    notificationPublishController.publish(notificationMessage);
  }

  protected String buildNotificationMessage(R response) {
    return name;
  }

  protected String navigate(R response) {
    return null;
  }
}
