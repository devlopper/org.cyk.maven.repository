package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat des natures de pièces justificatives : ce que la réglementation exige, et par qui il se
 * paramètre.
 *
 * <p>Le référentiel s'administre depuis l'application (TCH_PRB_ARB_21). Il ne l'a pas toujours
 * fait : je l'avais voulu en lecture seule, son contenu évoluant par script avec la
 * réglementation qu'il transcrit. Mais une exigence de pièce n'est pas une loi : elle se décide
 * à la DCB, elle change d'un exercice à l'autre, et faire dépendre ce changement d'une
 * livraison logicielle revenait à le rendre impossible.</p>
 *
 * <p>Une nature ne se supprime pas à la légère : les dossiers déjà contrôlés l'ont opposée aux
 * EPN. C'est ce que l'indicateur <em>actif</em> permet — abroger une exigence sans effacer
 * l'histoire de celles qu'on a fait valoir.</p>
 *
 * @author Christian
 *
 */
@Path(value = SupportingDocumentNatureService.PATH)
@Tag(name = "Gestion des natures de pièces justificatives")
public interface SupportingDocumentNatureService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "natures-pieces-justificatives";

  /**
   * Ce qu'une nature porte au-delà de son code et de son libellé, à la création comme à la
   * modification.
   *
   * <p>Une seule déclaration pour les deux requêtes : une exigence qui pourrait se créer avec un
   * attribut que la modification ne saurait pas reprendre serait un piège.</p>
   */
  interface SupportingDocumentNatureSaveRequestDto {

    /**
     * Retourne la famille de lignes concernée.
     *
     * @return mouvement ou mesure ponctuelle
     */
    String getElementType();

    /**
     * Assigne la famille de lignes concernée.
     *
     * @param elementType mouvement ou mesure ponctuelle
     */
    void setElementType(String elementType);

    /**
     * Retourne le type de mouvement visé.
     *
     * @return le code du type, nul pour une exigence commune
     */
    String getMovementTypeCode();

    /**
     * Assigne le type de mouvement visé.
     *
     * @param movementTypeCode code du type, nul pour une exigence commune
     */
    void setMovementTypeCode(String movementTypeCode);

    /**
     * Indique si la pièce conditionne l'admissibilité.
     *
     * @return vrai si elle est obligatoire
     */
    Boolean getMandatory();

    /**
     * Assigne le caractère obligatoire.
     *
     * @param mandatory vrai si la pièce conditionne l'admissibilité
     */
    void setMandatory(Boolean mandatory);

    /**
     * Indique si l'exigence est en vigueur.
     *
     * @return vrai si elle est active
     */
    Boolean getActive();

    /**
     * Assigne la mise en vigueur.
     *
     * @param active vrai si l'exigence est en vigueur
     */
    void setActive(Boolean active);

    /**
     * {@link SupportingDocumentNatureDto#JSON_ELEMENT_TYPE}.
     */
    String JSON_ELEMENT_TYPE = SupportingDocumentNatureDto.JSON_ELEMENT_TYPE;

    /**
     * {@link SupportingDocumentNatureDto#JSON_MOVEMENT_TYPE_CODE}.
     */
    String JSON_MOVEMENT_TYPE_CODE = SupportingDocumentNatureDto.JSON_MOVEMENT_TYPE_CODE;

    /**
     * {@link SupportingDocumentNatureDto#JSON_MANDATORY}.
     */
    String JSON_MANDATORY = SupportingDocumentNatureDto.JSON_MANDATORY;

    /**
     * {@link SupportingDocumentNatureDto#JSON_ACTIVE}.
     */
    String JSON_ACTIVE = SupportingDocumentNatureDto.JSON_ACTIVE;
  }

  /**
   * Identifiant du service de création unitaire de {@link SupportingDocumentNatureDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service de création unitaire de {@link SupportingDocumentNatureDto}.
   */
  String CREATE_PATH = "";

  /**
   * Création d'une nature de pièce.
   *
   * @param request la nature à créer
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une nature de pièce justificative")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SupportingDocumentNatureCreateRequestDto request);

  /**
   * Requête de création d'une nature de pièce.
   */
  @Getter
  @Setter
  class SupportingDocumentNatureCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SupportingDocumentNatureSaveRequestDto {

    @JsonbProperty(JSON_ELEMENT_TYPE)
    private String elementType;

    @JsonbProperty(JSON_MOVEMENT_TYPE_CODE)
    private String movementTypeCode;

    @JsonbProperty(JSON_MANDATORY)
    private Boolean mandatory;

    @JsonbProperty(JSON_ACTIVE)
    private Boolean active;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link SupportingDocumentNatureDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service d'obtention de plusieurs {@link SupportingDocumentNatureDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des natures de pièces.
   *
   * @param request critères, projection et pagination
   * @return les natures correspondantes
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation des natures de pièces")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(
          implementation = SupportingDocumentNatureGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de natures de pièces justificatives.
   */
  @Getter
  @Setter
  public static class SupportingDocumentNatureGetManyResponseDto
      extends AbstractGetByPageResponseDto<SupportingDocumentNatureDto> {
    @JsonbProperty(JSON_DATAS)
    private List<SupportingDocumentNatureDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link SupportingDocumentNatureDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service d'obtention unitaire de {@link SupportingDocumentNatureDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Recherche d'une nature unique.
   *
   * @param request critères et projection
   * @return la nature correspondante
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = SupportingDocumentNatureDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de
   * {@link SupportingDocumentNatureDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service d'obtention par identifiant de {@link SupportingDocumentNatureDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'une nature par son identifiant.
   *
   * @param request identifiant et projection
   * @return la nature correspondante
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = SupportingDocumentNatureDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link SupportingDocumentNatureDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service de mise à jour unitaire de {@link SupportingDocumentNatureDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Modification d'une nature de pièce.
   *
   * @param request la nature modifiée
   * @return l'identifiant touché
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      summary = "Modification d'une nature de pièce justificative")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SupportingDocumentNatureUpdateRequestDto request);

  /**
   * Requête de modification d'une nature de pièce.
   */
  @Getter
  @Setter
  class SupportingDocumentNatureUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SupportingDocumentNatureSaveRequestDto {

    @JsonbProperty(JSON_ELEMENT_TYPE)
    private String elementType;

    @JsonbProperty(JSON_MOVEMENT_TYPE_CODE)
    private String movementTypeCode;

    @JsonbProperty(JSON_MANDATORY)
    private Boolean mandatory;

    @JsonbProperty(JSON_ACTIVE)
    private Boolean active;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link SupportingDocumentNatureDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_NATURE_PIECE_JUSTIFICATIVE";

  /**
   * Chemin du service de suppression unitaire de {@link SupportingDocumentNatureDto}.
   */
  String DELETE_PATH = "";

  /**
   * Suppression d'une nature de pièce.
   *
   * <p>À réserver aux exigences jamais opposées à un EPN. Pour les autres, l'indicateur
   * <em>actif</em> abroge sans effacer.</p>
   *
   * @param request l'identifiant à supprimer
   * @return l'identifiant supprimé
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      summary = "Suppression d'une nature de pièce justificative")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
