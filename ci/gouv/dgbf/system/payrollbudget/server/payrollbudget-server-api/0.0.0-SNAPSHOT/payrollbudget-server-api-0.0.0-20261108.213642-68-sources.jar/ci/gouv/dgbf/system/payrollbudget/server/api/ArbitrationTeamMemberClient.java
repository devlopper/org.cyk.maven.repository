package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamMemberService.ArbitrationTeamMemberCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamMemberService.ArbitrationTeamMemberGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des membres d'équipe.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ArbitrationTeamMemberClient extends AbstractClient<ArbitrationTeamMemberService>
    implements GetMany<ArbitrationTeamMemberGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ArbitrationTeamMemberClient service(ArbitrationTeamMemberService service) {
    return (ArbitrationTeamMemberClient) super.service(service);
  }

  /**
   * Inscription d'un agent dans une équipe.
   *
   * @param request l'agent et son rôle
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(ArbitrationTeamMemberCreateRequestDto request) {
    return new CreateExecutor(ArbitrationTeamMemberService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des membres.
   *
   * @param request critères, projection et pagination
   * @return les membres correspondants
   */
  public ArbitrationTeamMemberGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamMemberGetManyResponseDto>(
        ArbitrationTeamMemberGetManyResponseDto.class,
        ArbitrationTeamMemberService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public ArbitrationTeamMemberGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Retrait d'un membre.
   *
   * @param request l'identifiant à retirer
   * @return l'identifiant retiré
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ArbitrationTeamMemberService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
