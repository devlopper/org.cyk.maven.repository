package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Statut de la réclamation.
   */
  String status;

  /**
   * Identifiant de l'émetteur de la réclamation.
   */
  String issuerIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementClaimFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementClaimFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    status = getStatus(filter);
    issuerIdentifier = getIssuerIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setStatus(filter, status);
    setIssuerIdentifier(filter, issuerIdentifier);
  }

  /**
   * Cette méthode permet d'assigner le statut.
   *
   * @param filter filtre
   * @param status statut
   */
  public static void setStatus(FilterDto filter, String status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsString(status));
  }

  /**
   * Cette méthode permet d'obtenir le statut.
   *
   * @param filter filtre
   * @return statut
   */
  public static String getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'émetteur.
   *
   * @param filter filtre
   * @param issuerIdentifier identifiant de l'émetteur
   */
  public static void setIssuerIdentifier(FilterDto filter, String issuerIdentifier) {
    set(filter, JSON_ISSUER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(issuerIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'émetteur.
   *
   * @param filter filtre
   * @return identifiant de l'émetteur
   */
  public static String getIssuerIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ISSUER_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = PayrollElementClaimDto.JSON_STATUS;

  /**
   * Identifiant json champ {@link #issuerIdentifier}.
   */
  public static final String JSON_ISSUER_IDENTIFIER = PayrollElementClaimDto.JSON_ISSUER_IDENTIFIER;
}
