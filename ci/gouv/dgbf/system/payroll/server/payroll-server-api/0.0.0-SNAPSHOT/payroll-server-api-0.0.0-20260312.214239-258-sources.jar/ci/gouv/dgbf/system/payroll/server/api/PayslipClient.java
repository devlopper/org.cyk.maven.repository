package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByFilterRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipCalculateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipGetSumsRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipGetSumsResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipReintegrateFromLitigationRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipTransmitLitigationRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.PayslipUpdateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.ProcessResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayslipService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayslipClient extends AbstractClient<PayslipService>
    implements GetByIdentifier<PayslipDto>, GetMany<PayslipGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayslipClient service(PayslipService service) {
    return (PayslipClient) super.service(service);
  }

  /**
   * {@link PayslipService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayslipCreateRequestDto request) {
    return new CreateExecutor(PayslipService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayslipService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayslipGetManyResponseDto>(PayslipGetManyResponseDto.class,
        PayslipService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PayslipService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayslipService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayslipDto>(PayslipDto.class, PayslipService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayslipService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayslipService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(PayslipService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayslipService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayslipDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayslipDto>(PayslipDto.class,
        PayslipService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayslipService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayslipService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayslipUpdateRequestDto request) {
    return new IdentifiableExecutor(PayslipService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayslipService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayslipService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayslipService#calculate}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto calculate(PayslipCalculateRequestDto request) {
    return new IdentifiableExecutor(PayslipService.CALCULATE_IDENTIFIER)
        .execute(() -> service().calculate(request));
  }

  /**
   * {@link PayslipService#initialize}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto initialize(ByFilterRequestDto request) {
    return new ProcessExecutor(PayslipService.INITIALIZE_IDENTIFIER)
        .execute(() -> service().initialize(request));
  }

  /**
   * {@link PayslipService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link PayslipService#control}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto control(ByFilterRequestDto request) {
    return new ProcessExecutor(PayslipService.CONTROL_IDENTIFIER)
        .execute(() -> service().control(request));
  }

  /**
   * {@link PayslipService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto accept(ByFilterRequestDto request) {
    return new ProcessExecutor(PayslipService.ACCEPT_IDENTIFIER)
        .execute(() -> service().accept(request));
  }

  /**
   * {@link PayslipService#recalculate}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto recalculate(ByFilterRequestDto request) {
    return new ProcessExecutor(PayslipService.RECALCULATE_IDENTIFIER)
        .execute(() -> service().recalculate(request));
  }

  /**
   * {@link PayslipService#validate}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto validate(ByFilterRequestDto request) {
    return new ProcessExecutor(PayslipService.VALIDATE_IDENTIFIER)
        .execute(() -> service().validate(request));
  }

  /**
   * {@link PayslipService#transmitToLitigation}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto transmitToLitigation(PayslipTransmitLitigationRequestDto request) {
    return new ProcessExecutor(PayslipService.TRANSMIT_TO_LITIGATION_IDENTIFIER)
        .execute(() -> service().transmitToLitigation(request));
  }

  /**
   * {@link PayslipService#reintegrateFromLitigation}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto reintegrateFromLitigation(
          PayslipReintegrateFromLitigationRequestDto request) {
    return new ProcessExecutor(PayslipService.REINTEGRATE_FROM_LITIGATION_IDENTIFIER)
        .execute(() -> service().reintegrateFromLitigation(request));
  }

  /**
   * {@link PayslipService#getSums}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayslipGetSumsResponseDto getSums(PayslipGetSumsRequestDto request) {
    return new GetOneExecutor<>(PayslipGetSumsResponseDto.class, PayslipService.GET_SUMS_IDENTIFIER)
        .execute(() -> service().getSums(request));
  }

  /**
   * Cette classe représente un exécuteur de {@link PayslipDto}.
   *
   * @author akm
   *
   */
  public class ProcessExecutor extends Executor<ProcessResponseDto> {

    /**
     * Cette méthode permet d'instancier.
     *
     * @param identifier identifiant
     */
    public ProcessExecutor(String identifier) {
      super(ProcessResponseDto.class, identifier);
    }

  }
}
