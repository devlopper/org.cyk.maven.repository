package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link PayrollElementClaimDto} (RG_REP_STA_01).
 *
 * @author akm
 *
 */
@Getter
public enum PayrollElementClaimStatus {

  /**
   * Créée -- brouillon librement modifiable, avant toute Soumission (RG_REP_SOU_00).
   */
  CREATED("CREEE", "Créée"),

  /**
   * Soumise -- première Soumission depuis Créée, ou nouvelle Soumission depuis Différée après
   * complément du dossier (RG_REP_PEC_06).
   */
  SUBMITTED("SOUMISE", "Soumise"),

  /**
   * Prise en charge par un Agent de Traitement.
   */
  IN_CHARGE("PRISE_EN_CHARGE", "Prise en charge"),

  /**
   * Rejetée par l'Agent de Traitement (RG_REP_PEC_05), motif obligatoire.
   */
  REJECTED("REJETEE", "Rejetée"),

  /**
   * Différée par l'Agent de Traitement (RG_REP_PEC_06), en attente de complément.
   */
  DEFERRED("DIFFEREE", "Différée"),

  /**
   * Acceptée -- état terminal positif, atteint immédiatement à la Décision, indépendamment du
   * circuit des Traitements qui en découlent (RG_REP_STA_02/03).
   */
  ACCEPTED("ACCEPTEE", "Acceptée");

  private PayrollElementClaimStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;
  private Set<PayrollElementClaimStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link PayrollElementClaimStatus} par code.
   *
   * @param code code
   * @return {@link PayrollElementClaimStatus}
   */
  public static PayrollElementClaimStatus getByCode(String code) {
    return Stream.of(PayrollElementClaimStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    SUBMITTED.previous = Core.getSet(List.of(CREATED, DEFERRED));
    IN_CHARGE.previous = Core.getSet(List.of(SUBMITTED));
    REJECTED.previous = Core.getSet(List.of(IN_CHARGE));
    DEFERRED.previous = Core.getSet(List.of(IN_CHARGE));
    ACCEPTED.previous = Core.getSet(List.of(IN_CHARGE));
  }
}
