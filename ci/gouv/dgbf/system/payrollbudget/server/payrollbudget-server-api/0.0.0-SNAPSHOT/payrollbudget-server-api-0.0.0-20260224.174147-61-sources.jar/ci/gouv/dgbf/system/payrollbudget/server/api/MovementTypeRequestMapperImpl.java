package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MovementTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-02-24T17:42:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MovementTypeRequestMapperImpl implements MovementTypeRequestMapper {

    @Override
    public MovementTypeService.MovementTypeCreateRequestDto mapCreate(MovementTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementTypeService.MovementTypeCreateRequestDto movementTypeCreateRequestDto = new MovementTypeService.MovementTypeCreateRequestDto();

        movementTypeCreateRequestDto.setCode( arg0.getCode() );
        movementTypeCreateRequestDto.setName( arg0.getName() );
        movementTypeCreateRequestDto.setAdministrativeUnitEmployeeStatus( arg0.getAdministrativeUnitEmployeeStatus() );

        return movementTypeCreateRequestDto;
    }

    @Override
    public MovementTypeService.MovementTypeUpdateRequestDto mapUpdate(MovementTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementTypeService.MovementTypeUpdateRequestDto movementTypeUpdateRequestDto = new MovementTypeService.MovementTypeUpdateRequestDto();

        movementTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        movementTypeUpdateRequestDto.setCode( arg0.getCode() );
        movementTypeUpdateRequestDto.setName( arg0.getName() );
        movementTypeUpdateRequestDto.setAdministrativeUnitEmployeeStatus( arg0.getAdministrativeUnitEmployeeStatus() );

        return movementTypeUpdateRequestDto;
    }
}
