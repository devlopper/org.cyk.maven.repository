package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentationDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DocumentationDto}.

    @author Christian
               """)
public interface DocumentationRequestMapper extends
    RequestMapper<DocumentationDto, DocumentationCreateRequestDto, DocumentationUpdateRequestDto> {

}
