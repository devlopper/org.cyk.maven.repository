package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService.EchelonCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService.EchelonUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link EchelonDto}.
 *
 * @author A.K.M
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link EchelonDto}.

    @author AKM
               """)
public interface EchelonRequestMapper
    extends RequestMapper<EchelonDto, EchelonCreateRequestDto, EchelonUpdateRequestDto> {

}
