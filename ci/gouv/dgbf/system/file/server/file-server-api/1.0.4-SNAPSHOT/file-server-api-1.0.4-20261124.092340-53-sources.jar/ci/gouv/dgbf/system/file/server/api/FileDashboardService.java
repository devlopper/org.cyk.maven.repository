package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente le service de lecture du tableau de bord du module Fichier
 * (RG_FILE_UI_05, SC_FILE_19). Service de lecture pure d'agrégats : un seul graphique par
 * appel, sélectionné par {@link FileDashboardFilter#getChartCode()}
 * ({@link FileDashboardChartCode}), réutilisant les objets de transfert génériques
 * {@link GetChartRequestDto}/{@link GetChartResponseDto}/{@link ChartDto} sans en redéfinir
 * d'équivalents.
 *
 * @author Christian
 *
 */
@Path(value = FileDashboardService.PATH)
@Tag(name = "Tableau de bord du module Fichier")
public interface FileDashboardService extends SpecificService {

  /**
   * Chemin des services.
   */
  String PATH = "tableau-de-bord";

  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_TABLEAU_BORD_FICHIER";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique du tableau de bord.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = GetChartResponseDto.class))})
  Response getChart(GetChartRequestDto request);
}
