package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.EvaluateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ConstantGroupDto}.
 *
 * @author Christian
 *
 */
@Path(value = ConstantGroupService.PATH)
@Tag(name = "Gestion des groupes de constante")
public interface ConstantGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-constantes";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ConstantGroupSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant du domaine.
     *
     * @return l'identifiant du domaine
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du domaine.
     *
     * @param domainIdentifier l'identifiant du domaine
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * {@link HasDomainIdentifierDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_CONSTANTE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ConstantGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ConstantGroupSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_CONSTANTE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ConstantGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ConstantGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ConstantGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ConstantGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_CONSTANTE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_CONSTANTE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_CONSTANTE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ConstantGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ConstantGroupSaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_CONSTANTE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConstantGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'évaluation des constantes contextuelles.
   */
  String EVALUATE_CONTEXTUAL_CONSTANTS_IDENTIFIER = "EVALUATION_CONSTANTES_CONTEXTUELLES";

  /**
   * Chemin du service d'évaluation des constantes contextuelles.
   */
  String EVALUATE_CONTEXTUAL_CONSTANTS_PATH = "evaluation-constantes-contextuelles";

  /**
   * Cette méthode permet d'évaluer des constantes contextuelles.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_CONTEXTUAL_CONSTANTS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_CONTEXTUAL_CONSTANTS_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = ConstantGroupEvaluateContextualConstantsResponseDto.class))})
  Response evaluateContextualConstants(ConstantGroupEvaluateContextualConstantsRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation des constantes contextuelles.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupEvaluateContextualConstantsRequestDto extends EvaluateRequestDto
      implements HasFromDateDto<LocalDateTime>, HasToDateDto<LocalDateTime> {

    /**
     * Nom du groupe.
     */
    @JsonbProperty(JSON_GROUP_NAME)
    private String groupName;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    /**
     * Identifiant json de {@link #groupName}.
     */
    public static final String JSON_GROUP_NAME = ConstantGroupDto.JSON_GROUP_NAME;
  }

  /**
   * Cette classe représente la réponse d'évaluation des constantes contextuelles.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupEvaluateContextualConstantsResponseDto extends IdentifiableResponseDto {

    /**
     * Identifiant {@link ContextualConstantEvaluationGroupDto}.
     */
    @JsonbProperty(JSON_CONTEXTUAL_CONSTANT_EVALUATION_GROUP_IDENTIFIER)
    private String contextualConstantEvaluationGroupIdentifier;

    /**
     * Identifiant json {@link #contextualConstantEvaluationGroupIdentifier}.
     */
    public static final String JSON_CONTEXTUAL_CONSTANT_EVALUATION_GROUP_IDENTIFIER =
        ContextualConstantEvaluationGroupDto.JSON_THIS_IDENTIFIER;
  }

  /**
   * Identifiant du service d'évaluation des constantes contextuelles.
   */
  String EVALUATE_MANY_CONTEXTUAL_CONSTANTS_IDENTIFIER =
      "EVALUATION_PLUSIEURS_CONSTANTES_CONTEXTUELLES";

  /**
   * Chemin du service d'évaluation des constantes contextuelles.
   */
  String EVALUATE_MANY_CONTEXTUAL_CONSTANTS_PATH = "evaluations-constantes-contextuelles";

  /**
   * Cette méthode permet d'évaluer des constantes contextuelles.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_MANY_CONTEXTUAL_CONSTANTS_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_MANY_CONTEXTUAL_CONSTANTS_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(schema = @Schema(
      implementation = ConstantGroupEvaluateManyContextualConstantsResponseDto.class))})
  Response evaluateManyContextualConstants(
      ConstantGroupEvaluateManyContextualConstantsRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation des constantes contextuelles.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupEvaluateManyContextualConstantsRequestDto extends AbstractAuditedRequestJsonDto
      implements HasFromDateDto<LocalDateTime>, HasToDateDto<LocalDateTime> {

    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty("groupes")
    private Collection<GroupDto> groups;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param identifier identifiant
     * @param name nom
     * @return {@link GroupDto}
     */
    public GroupDto addGroup(String identifier, String name) {
      GroupDto group = new GroupDto();
      group.identifier = identifier;
      group.name = name;
      groups().add(group);
      return group;
    }
    
    /**
     * Cette méthode permet d'obtenir une collection de groupe non nulle.
     *
     * @return collection de groupe non nulle
     */
    public Collection<GroupDto> groups() {
      groups = Optional.ofNullable(groups).orElseGet(ArrayList::new);
      return groups;
    }

    /**
     * Cette méthode permet d'obtenir {@link GroupDto} par identifiant.
     *
     * @param identifier identifiant
     * @return {@link GroupDto}
     */
    public GroupDto getGroupByIdentifier(String identifier) {
      return Optional.ofNullable(groups).orElse(Collections.emptyList()).stream()
          .filter(group -> Objects.equals(group.identifier, identifier)).findFirst().orElse(null);
    }

    /**
     * Cette classe représente un groupe de constante.
     *
     * @author Christian
     */
    @Getter
    @Setter
    public static class GroupDto implements HasIdentifierDto, HasNameDto {

      @JsonbProperty(JSON_IDENTIFIER)
      private String identifier;

      @JsonbProperty(JSON_NAME)
      private String name;
    }
  }

  /**
   * Cette classe représente la réponse d'évaluation des constantes contextuelles.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantGroupEvaluateManyContextualConstantsResponseDto extends AbstractResponseDto {

    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty("groupes")
    private Collection<GroupDto> groups;

    /**
     * Cette classe représente un groupe de constante.
     *
     * @author Christian
     */
    @Getter
    @Setter
    public static class GroupDto implements HasIdentifierDto {

      @JsonbProperty(JSON_IDENTIFIER)
      private String identifier;

      /**
       * Identifiant {@link ContextualConstantEvaluationGroupDto}.
       */
      @JsonbProperty(JSON_CONTEXTUAL_CONSTANT_EVALUATION_GROUP_IDENTIFIER)
      private String contextualConstantEvaluationGroupIdentifier;

      /**
       * Identifiant json {@link #contextualConstantEvaluationGroupIdentifier}.
       */
      public static final String JSON_CONTEXTUAL_CONSTANT_EVALUATION_GROUP_IDENTIFIER =
          ContextualConstantEvaluationGroupDto.JSON_THIS_IDENTIFIER;
    }
  }
}
