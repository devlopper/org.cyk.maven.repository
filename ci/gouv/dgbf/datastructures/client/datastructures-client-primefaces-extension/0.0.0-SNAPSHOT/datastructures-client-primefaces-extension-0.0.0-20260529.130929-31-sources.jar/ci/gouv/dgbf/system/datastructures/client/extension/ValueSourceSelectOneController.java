package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueSourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSourceSelectOneController extends AbstractSelectOneIdentifiableController<
    ValueSourceDto, ValueSourceGetManyResponseDto, ValueSourceClient> {

  @Getter
  @Inject
  ValueSourceClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected ValueSourceSelectOneController() {
    super(ValueSourceDto.class, SelectItemLabelStrategy.NAME);
  }
}
