package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un exercice.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExerciseDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Année.
   */
  @JsonbProperty(JSON_YEAR)
  private Integer year;

  /**
   * Élaborable.
   */
  @JsonbProperty(JSON_BUDGET_PREPARABLE)
  private Boolean budgetPreparable;

  /**
   * Exécutable.
   */
  @JsonbProperty(JSON_BUDGET_EXECUTABLE)
  private Boolean budgetExecutable;

  @Override
  public String toString() {
    return Core.getOrDefaultIfBlank(super.toString(), String.valueOf(year));
  }

  /**
   * Identifiant json champ {@link ExerciseDto#year}.
   */
  public static final String JSON_YEAR = "annee";

  /**
   * Identifiant json champ {@link ExerciseDto#budgetPreparable}.
   */
  public static final String JSON_BUDGET_PREPARABLE = "budgetPreparable";

  /**
   * Identifiant json champ {@link ExerciseDto#budgetExecutable}.
   */
  public static final String JSON_BUDGET_EXECUTABLE = "budgetExecutable";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exercice";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
