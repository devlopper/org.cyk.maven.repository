package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de d'activité.
 *
 * @author Arnaud
 */
public interface FilterHasActivityIdentifier extends HasActivityIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'activité.
   *
   * @param filter {@link FilterDto}
   */
  default void updateActivityIdentifier(FilterDto filter) {
    setActivityIdentifier(ActivityIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'activité de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterActivityIdentifier(FilterDto filter) {
    ActivityIdentifierFilter.set(filter, getActivityIdentifier());
  }

}
