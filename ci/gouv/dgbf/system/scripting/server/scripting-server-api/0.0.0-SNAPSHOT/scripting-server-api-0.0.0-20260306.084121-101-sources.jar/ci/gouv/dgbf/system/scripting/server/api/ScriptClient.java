package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateManyAsIntegerPrimitiveRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateManyAsIntegerPrimitiveResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateManyRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptEvaluateResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptUpdateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptService.ScriptUpdateTextRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ScriptService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ScriptClient extends AbstractClient<ScriptService>
    implements GetByIdentifier<ScriptDto>, GetMany<ScriptGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ScriptClient service(ScriptService service) {
    return (ScriptClient) super.service(service);
  }

  /**
   * {@link ScriptService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ScriptCreateRequestDto request) {
    return new CreateExecutor(ScriptService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ScriptService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ScriptGetManyResponseDto>(ScriptGetManyResponseDto.class,
        ScriptService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ScriptService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ScriptService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ScriptDto>(ScriptDto.class, ScriptService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ScriptService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ScriptDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ScriptService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ScriptDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ScriptDto>(ScriptDto.class,
        ScriptService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ScriptService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ScriptService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ScriptUpdateRequestDto request) {
    return new IdentifiableExecutor(ScriptService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ScriptService#updateText}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateText(ScriptUpdateTextRequestDto request) {
    return new IdentifiableExecutor(ScriptService.UPDATE_TEXT_IDENTIFIER)
        .execute(() -> service().updateText(request));
  }

  /**
   * {@link ScriptService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ScriptService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ScriptService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ScriptService#evaluate}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluateResponseDto evaluate(ScriptEvaluateRequestDto request) {
    return new GetOneExecutor<>(ScriptEvaluateResponseDto.class, ScriptService.EVALUATE_IDENTIFIER)
        .execute(() -> service().evaluate(request));
  }

  /**
   * {@link ScriptService#evaluateMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluateManyResponseDto evaluateMany(ScriptEvaluateManyRequestDto request) {
    return new GetOneExecutor<>(ScriptEvaluateManyResponseDto.class,
        ScriptService.EVALUATE_MANY_IDENTIFIER).execute(() -> service().evaluateMany(request));
  }

  /**
   * {@link ScriptService#evaluateManyAsIntegerPrimitive}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluateManyAsIntegerPrimitiveResponseDto evaluateManyAsIntegerPrimitive(
      ScriptEvaluateManyAsIntegerPrimitiveRequestDto request) {
    return new GetOneExecutor<>(ScriptEvaluateManyAsIntegerPrimitiveResponseDto.class,
        ScriptService.EVALUATE_MANY_AS_INTEGER_PRIMITIVE_IDENTIFIER)
            .execute(() -> service().evaluateManyAsIntegerPrimitive(request));
  }
}
