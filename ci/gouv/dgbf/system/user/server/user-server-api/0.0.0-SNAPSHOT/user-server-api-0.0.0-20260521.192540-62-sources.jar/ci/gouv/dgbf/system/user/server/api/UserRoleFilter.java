package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserRoleDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class UserRoleFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link UserDto}.
   */
  private String userIdentifier;

  /**
   * Identifiant {@link RoleDto}.
   */
  private String roleIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public UserRoleFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public UserRoleFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    userIdentifier = getUserIdentifier(filter);
    roleIdentifier = getRoleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setUserIdentifier(filter, userIdentifier);
    setRoleIdentifier(filter, roleIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link UserDto}.
   *
   * @param filter         filtre
   * @param userIdentifier identifiant de {@link UserDto}
   */
  public static void setUserIdentifier(FilterDto filter, String userIdentifier) {
    set(filter, JSON_USER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(userIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link UserDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link UserDto}
   */
  public static String getUserIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_USER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link RoleDto}.
   *
   * @param filter         filtre
   * @param roleIdentifier identifiant de {@link RoleDto}
   */
  public static void setRoleIdentifier(FilterDto filter, String roleIdentifier) {
    set(filter, JSON_ROLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(roleIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link RoleDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link RoleDto}
   */
  public static String getRoleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ROLE_IDENTIFIER));
  }




  /**
   * Identifiant json champ {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = UserRoleDto.JSON_USER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = UserRoleDto.JSON_ROLE_IDENTIFIER;


}
