package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.client.extension.file.FileCategorySelectOneController;
import ci.gouv.dgbf.system.file.client.extension.file.OpenFileViewerButtonController;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileGroupService;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateRequestDto;
import ci.gouv.dgbf.system.sharing.client.extension.ReceiverSelectOneController;
import ci.gouv.dgbf.system.sharing.client.extension.SharingListWithoutTemplatePage;
import ci.gouv.dgbf.system.sharing.server.api.SharingClient;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import org.primefaces.PrimeFaces;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.DialogFrameworkOptions;

/**
 * Cette classe représente le contrôleur de CRUD de fichier de groupe.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupController extends AbstractController {

  @Inject
  FileGroupClient client;

  @Inject
  FileGroupRequestMapper requestMapper;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  FilesGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  FileCategorySelectOneController categorySelectOneController;

  @Inject
  FileClient fileClient;

  @Inject
  SharingClient sharingClient;

  @Inject
  @Getter
  OpenFileViewerButtonController openFileViewerButtonController;

  @Getter
  Button downloadButton;

  @Inject
  @Getter
  FileGroupFilterController filterController;

  @Inject
  @Getter
  FileGroupUpdateCategoriesController updateCategoriesController;

  @Inject
  @Getter
  IdentifiableProcessingController shareProcessingController;

  @Inject
  @Getter
  ReceiverSelectOneController receiverSelectOneController;

  @Getter
  private List<SharingDto> sharings = new ArrayList<>();

  @Getter
  private String currentResourceName;

  /**
   * Cette méthode permet d'instantier.
   */
  public FileGroupController() {
    downloadButton = new Button();
    downloadButton.setTitle("Télécharger");
    downloadButton.setIcon("pi pi-cloud-download");
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Fichier de groupe";
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FileGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileGroupService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileGroupDto.JSON_FILE_IDENTIFIER,
        FileGroupDto.JSON_FILE_AS_STRING, FileGroupDto.JSON_FILE_OWNER_IDENTIFIER,
        AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING,
        FileGroupDto.JSON_CATEGORIES_AS_STRING);

    processGroupIdentifier(projection, filterController.getFilter().getGroupIdentifier());

    categorySelectOneController.getSelectOneRadio()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(FileGroupDto.class)
            .setCategoriesIdentifiersFrom(identifier));

    listController.getReadController().setProjection(projection);

    listController.getDataTable().getAuditColumn().setRendered(true);

    listController.initialize();

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(4);

    listController.getCreateController().addEntityConsumer(entity -> ((FileGroupDto) entity)
        .setGroupIdentifier(filterController.getFilter().getGroupIdentifier()));

    listController.getCreateController().setFunction(entity -> {
      String fileIdentifier =
          fileClient.getIdentifierByBytesOrByCreate(((FileGroupDto) entity).getFileName(),
              ((FileGroupDto) entity).getFileBytes(), userIdentifier, null);
      FileGroupCreateRequestDto request = requestMapper.mapCreate((FileGroupDto) entity);
      request.setFileIdentifier(fileIdentifier);
      request.setUpdateCategoriesIdentifiers(true);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });


    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            FileGroupDto.JSON_FILE_IDENTIFIER, FileGroupDto.JSON_GROUP_IDENTIFIER,
            FileGroupDto.JSON_CATEGORIES_IDENTIFIERS));

    listController.getUpdateController().addEntityConsumer(entity -> {
      groupSelectOneController.getSelectOneMenu()
          .writeValue(((FileGroupDto) entity).getGroupIdentifier());

      categorySelectOneController.getSelectOneRadio()
          .writeValue(((FileGroupDto) entity).getFirstCategoriesIdentifiers());
    });

    listController.getUpdateController().setFunction(entity -> {
      FileGroupUpdateRequestDto request = requestMapper.mapUpdate((FileGroupDto) entity);
      request.setUpdateCategoriesIdentifiers(true);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    updateCategoriesController.initialize(listController);
  }

  void processGroupIdentifier(ProjectionDto projection, String groupIdentifier) {
    if (Core.isStringBlank(groupIdentifier)) {
      projection.addNames(FileGroupDto.JSON_GROUP_AS_STRING);
      groupSelectOneController.getSelectOneMenu()
          .addValueConsumer(identifier -> listController
              .getCreateControllerOrUpdateControllerEntityAs(FileGroupDto.class)
              .setGroupIdentifier(identifier));
    } else {
      groupSelectOneController.setRenderable(false);
    }
  }

  /**
   * Ouvre la page complète des partages via Dialog Framework.
   *
   * @param resourceIdentifier identifiant du FileGroup
   */
  public void openSharingListDialog(String resourceIdentifier) {
    DialogFrameworkOptions options =
        DialogFrameworkOptions.builder()
            .modal(true)
            .fitViewport(true)
            .responsive(true)
            .width("900px")
            .contentWidth("100%")
            .resizeObserver(true)
            .resizeObserverCenter(true)
            .resizable(false)
            .styleClass("max-w-screen")
            .iframeStyleClass("max-w-screen")
            .build();
    PrimeFaces.current().dialog()
        .openDynamic(SharingListWithoutTemplatePage.OUTCOME, options, Map.of(
            SharingFilter.JSON_RESOURCE_IDENTIFIER, List.of(resourceIdentifier)
        ));
  }

  /**
   * Cette méthode permet de réagir au téléchargement.
   *
   * @param event évènement
   */
  public void handleFileUpload(FileUploadEvent event) {
    ((FileGroupDto) listController.getCreateController().getEntity())
        .setFileName(event.getFile().getFileName());
    ((FileGroupDto) listController.getCreateController().getEntity())
        .setFileBytes(event.getFile().getContent());
  }
}
