package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierDto;
import ci.gouv.dgbf.extension.core.segregation.HasScriptIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.EvaluateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.EvaluateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.math.BigDecimal;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ScriptContextDto}.
 *
 * @author Christian
 *
 */
@Path(value = ScriptContextService.PATH)
@Tag(name = "Gestion des contextes de scripts")
public interface ScriptContextService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "contextes-scripts";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface ScriptContextSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ScriptContextGroupDto}.
     *
     * @return identifiant de {@link ScriptContextGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ScriptContextGroupDto}.
     *
     * @param groupIdentifier identifiant de {@link ScriptContextGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ScriptDto}.
     *
     * @return identifiant de {@link ScriptDto}
     */
    String getScriptIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ScriptDto}.
     *
     * @param scriptIdentifier identifiant de {@link ScriptDto}
     */
    void setScriptIdentifier(String scriptIdentifier);
    
    /**
     * Cette méthode permet d'obtenir le multiplicateur.
     *
     * @return le multiplicateur
     */
    BigDecimal getMultiplier();

    /**
     * Cette méthode permet d'assigner le multiplicateur.
     *
     * @param multiplier le multiplicateur
     */
    void setMultiplier(BigDecimal multiplier);
    
    /**
     * Cette méthode permet d'obtenir la valeur minimale.
     *
     * @return la valeur minimale
     */
    Integer getMinValue();

    /**
     * Cette méthode permet d'assigner la valeur minimale.
     *
     * @param minValue la valeur minimale
     */
    void setMinValue(Integer minValue);

    /**
     * Cette méthode permet d'obtenir la valeur maximale.
     *
     * @return la valeur maximale
     */
    Integer getMaxValue();

    /**
     * Cette méthode permet d'assigner la valeur maximale.
     *
     * @param maxValue la valeur maximale
     */
    void setMaxValue(Integer maxValue);

    /**
     * {@link HasScriptIdentifierDto#JSON_SCRIPT_IDENTIFIER}.
     */
    String JSON_SCRIPT_IDENTIFIER = HasScriptIdentifierDto.JSON_SCRIPT_IDENTIFIER;

    /**
     * {@link HasGroupIdentifierDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;
    
    /**
     * {@link HasMultiplierDto#JSON_MULTIPLIER}.
     */
    String JSON_MULTIPLIER = HasMultiplierDto.JSON_MULTIPLIER;
    
    /**
     * {@link HasMinValueDto#JSON_MIN_VALUE}.
     */
    String JSON_MIN_VALUE = HasMinValueDto.JSON_MIN_VALUE;

    /**
     * {@link HasMaxValueDto#JSON_MAX_VALUE}.
     */
    String JSON_MAX_VALUE = HasMaxValueDto.JSON_MAX_VALUE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ScriptContextCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ScriptContextCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ScriptContextSaveRequestDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
    private String scriptIdentifier;
    
    @JsonbProperty(JSON_MULTIPLIER)
    private BigDecimal multiplier;
    
    @JsonbProperty(JSON_MIN_VALUE)
    private Integer minValue;

    @JsonbProperty(JSON_MAX_VALUE)
    private Integer maxValue;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ScriptContextGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class ScriptContextGetManyResponseDto
      extends AbstractGetByPageResponseDto<ScriptContextDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ScriptContextDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptContextDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptContextDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ScriptContextUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ScriptContextUpdateRequestDto extends ByIdentifierRequestDto
      implements ScriptContextSaveRequestDto {
    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
    private String scriptIdentifier;
    
    @JsonbProperty(JSON_MULTIPLIER)
    private BigDecimal multiplier;
    
    @JsonbProperty(JSON_MIN_VALUE)
    private Integer minValue;

    @JsonbProperty(JSON_MAX_VALUE)
    private Integer maxValue;
  }

  /**
   * Identifiant du service d'évaluation.
   */
  String EVALUATE_IDENTIFIER = "EVALUATION_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String EVALUATE_PATH = "evaluation";

  /**
   * Cette méthode permet d'évaluer {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = EvaluateResponseDto.class))})
  Response evaluate(EvaluateRequestDto request);

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ScriptContextDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
