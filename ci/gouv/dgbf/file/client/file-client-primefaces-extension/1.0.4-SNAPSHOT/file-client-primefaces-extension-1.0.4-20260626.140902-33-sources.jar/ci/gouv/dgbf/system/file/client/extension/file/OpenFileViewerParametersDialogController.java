package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ViewerOpener;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du dialogue de paramètres d'ouverture du visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class OpenFileViewerParametersDialogController extends AbstractController {

  @Getter
  @Setter
  String widgetVar;

  @Setter
  Consumer<ViewerOpener> viewerOpenerConsumer;

  @Inject
  ViewerOpener opener;
  
  /**
   * Cette méthode permet de construire une instance.
   */
  public OpenFileViewerParametersDialogController() {
    name = "Paramètres d'ouverture";
    widgetVar = "openParametersDialog";
  }

  /**
   * Cette méthode permet d'ouvrir la vue du rapport.
   *
   */
  public void open() {
    if (viewerOpenerConsumer == null) {
      throw new IllegalStateException(
          "Le consommateur de l'ouvreur du visualisateur ne doit pas être null");
    }
    viewerOpenerConsumer.accept(opener);
    opener.open();
  }
}
