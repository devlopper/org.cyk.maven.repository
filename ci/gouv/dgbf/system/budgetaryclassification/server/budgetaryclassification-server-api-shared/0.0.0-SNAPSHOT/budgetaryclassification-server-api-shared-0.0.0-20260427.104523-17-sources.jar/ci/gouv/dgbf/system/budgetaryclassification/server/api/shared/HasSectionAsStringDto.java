package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de
 * section.
 *
 * @author Christian
 */
public interface HasSectionAsStringDto extends HasSectionAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de section.
   */
  String JSON_SECTION_AS_STRING = "sectionChaine";
}
