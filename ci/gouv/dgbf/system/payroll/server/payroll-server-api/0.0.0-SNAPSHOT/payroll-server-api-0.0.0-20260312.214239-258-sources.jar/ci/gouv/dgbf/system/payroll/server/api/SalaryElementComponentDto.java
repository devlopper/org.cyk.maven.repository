package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link PayrollComponentDto} de {@link SalaryElementDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SalaryElementComponentDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link SalaryElementDto}.
   */
  @JsonbProperty(JSON_SALARY_ELEMENT_IDENTIFIER)
  private String salaryElementIdentifier;
  
  /**
   * Représentation en chaine de caractères de l'élément de salaire.
   */
  @JsonbProperty(JSON_SALARY_ELEMENT_AS_STRING)
  private String salaryElementAsString;

  /**
   * Identifiant {@link PayrollComponentDto}.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  /**
   * Représentation en chaine de caractères du poste de bulletin.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  private String payrollComponentAsString;

  /**
   * Taux employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_RATE)
  private Integer employeeRate;

  /**
   * Taux employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_RATE)
  private Integer employerRate;

  /**
   * Plancher.
   */
  @JsonbProperty(JSON_FLOOR)
  private Integer floor;

  /**
   * Représentation en chaine de caractères de {@link #floor}.
   */
  @JsonbProperty(JSON_FLOOR_AS_STRING)
  private String floorAsString;

  /**
   * Plafond.
   */
  @JsonbProperty(JSON_CAP)
  private Integer cap;

  /**
   * Représentation en chaine de caractères de {@link #cap}.
   */
  @JsonbProperty(JSON_CAP_AS_STRING)
  private String capAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPosteElementSalaire";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "posteElementSalaireChaine";

  /**
   * Identifiant json {@link #salaryElementIdentifier}.
   */
  public static final String JSON_SALARY_ELEMENT_IDENTIFIER = SalaryElementDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #payrollComponentIdentifier}.
   */
  public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
      PayrollComponentDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #payrollComponentAsString}.
   */
  public static final String JSON_PAYROLL_COMPONENT_AS_STRING = PayrollComponentDto
      .JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json {@link #salaryElementAsString}.
   */
  public static final String JSON_SALARY_ELEMENT_AS_STRING = SalaryElementDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #employeeRate}.
   */
  public static final String JSON_EMPLOYEE_RATE = "tauxEmploye";

  /**
   * Identifiant json {@link #employerRate}.
   */
  public static final String JSON_EMPLOYER_RATE = "tauxEmployeur";

  /**
   * Identifiant json {@link #floor}.
   */
  public static final String JSON_FLOOR = "plancher";

  /**
   * Identifiant json {@link #floorAsString}.
   */
  public static final String JSON_FLOOR_AS_STRING = JSON_FLOOR + "Chaine";

  /**
   * Identifiant json {@link #cap}.
   */
  public static final String JSON_CAP = "plafond";

  /**
   * Identifiant json {@link #capAsString}.
   */
  public static final String JSON_CAP_AS_STRING = JSON_CAP + "Chaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste d'élément de salaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes d'éléments de salaires";
}
