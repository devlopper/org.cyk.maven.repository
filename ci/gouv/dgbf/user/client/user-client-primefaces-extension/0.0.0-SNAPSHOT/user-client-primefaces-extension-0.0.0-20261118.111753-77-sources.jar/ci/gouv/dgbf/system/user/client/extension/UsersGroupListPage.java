package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UsersGroupDto}.
 *
 * @author Arnaud
 *
 */
@Named
@ViewScoped
public class UsersGroupListPage extends AbstractPage {

  @Inject
  @Getter
  protected UsersGroupController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + UsersGroupDto.NAME;
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "usersGroupListPage";
}
