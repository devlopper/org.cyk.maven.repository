package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTypedTabMenuController;
import ci.gouv.dgbf.system.user.server.api.RoleSolicitationDto;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de la consultation de {@link UserDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class UserTabMenuController extends AbstractTypedTabMenuController<UserDto, IconManager> {

  @Inject
  @Getter
  IconManager iconManager;

  /**
   * Cette méthode permet de construire.
   */
  public UserTabMenuController() {
    super(UserDto.class);
    addPage(UserReadRolesPage.class, UserReadRolesPage.OUTCOME);
    addPage(RoleSolicitationDto.class, "userReadRoleSolicitationsPage");
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();
    menu.tabBuilder().menuItemValue("Rôles").type(UserReadRolesPage.class)
        .menuItemIcon(iconManager.getRole())
        .addMenuItemParameter(requestParameterIdentifierName, instance.getIdentifier()).build();

    menu.tabBuilder().menuItemValue("Demandes").type(RoleSolicitationDto.class)
        .menuItemIcon(iconManager.getRoleSolicitation())
        .addMenuItemParameter(requestParameterIdentifierName, instance.getIdentifier()).build();
  }
}
