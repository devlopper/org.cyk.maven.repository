package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FurGradeDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FurGradeFilter extends AbstractIdentifiableFilter {

  /**
   * Code du grade Solde AN 2000.
   */
  String gradeCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FurGradeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FurGradeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    gradeCode = getGradeCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGradeCode(filter, gradeCode);
  }

  /**
   * Cette méthode permet d'assigner le code du grade.
   *
   * @param filter filtre
   * @param gradeCode code du grade
   */
  public static void setGradeCode(FilterDto filter, String gradeCode) {
    set(filter, JSON_GRADE_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(gradeCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du grade.
   *
   * @param filter filtre
   * @return code du grade
   */
  public static String getGradeCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GRADE_CODE));
  }

  /**
   * Identifiant json champ {@link #gradeCode}.
   */
  public static final String JSON_GRADE_CODE = FurGradeDto.JSON_GRADE_CODE;
}
