package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPeriodGroupService.PayrollPeriodGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollPeriodGroupDto}.
 *
 * @author stephane
 *
 */
@Dependent
public class PayrollPeriodGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollPeriodGroupDto, PayrollPeriodGroupGetManyResponseDto, PayrollPeriodGroupClient> {

  @Getter
  @Inject
  PayrollPeriodGroupClient client;

  protected PayrollPeriodGroupSelectOneController() {
    super(PayrollPeriodGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
