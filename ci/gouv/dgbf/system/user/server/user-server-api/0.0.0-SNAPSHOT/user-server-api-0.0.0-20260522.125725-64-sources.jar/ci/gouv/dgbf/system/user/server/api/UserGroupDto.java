package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserGroupDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link UsersGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link UsersGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Identifiant de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUtilisateurGroupe";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "utilisateurGroupeChaine";

  /**
   * Identifiant champ java {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = UserGroupDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = UserGroupDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #userAsString}.
   */
  public static final String JSON_USER_AS_STRING = UserDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "utilisateur de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "utilisateurs de groupes";
}
