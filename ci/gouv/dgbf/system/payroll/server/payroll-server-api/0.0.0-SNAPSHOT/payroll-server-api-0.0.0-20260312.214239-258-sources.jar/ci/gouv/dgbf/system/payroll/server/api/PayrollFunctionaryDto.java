package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link FunctionaryDto} de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollFunctionaryDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link FunctionaryDto}.
   */
  @JsonbProperty(JSON_FUNCTIONARY_IDENTIFIER)
  private String functionaryIdentifier;

  /**
   * Représentation en chaine de caractères {@link FunctionaryDto}.
   */
  @JsonbProperty(JSON_FUNCTIONARY_AS_STRING)
  private String functionaryAsString;

  /**
   * Matricule.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nombre d'enfants.
   */
  @JsonbProperty(JSON_CHILDREN_COUNT)
  private Integer childrenCount;
  
  /**
   * Marié.
   */
  @JsonbProperty(JSON_MARRIED)
  private Boolean married;
  
  /**
   * Identifiant json de identifiant de {@link PayrollFunctionaryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnairePaie";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayrollFunctionaryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnairePaieChaine";

  /**
   * Identifiant json de {@link #functionaryIdentifier}.
   */
  public static final String JSON_FUNCTIONARY_IDENTIFIER = FunctionaryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #functionaryAsString}.
   */
  public static final String JSON_FUNCTIONARY_AS_STRING =
      FunctionaryBudgetarySectionUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = FunctionaryDto.JSON_REGISTRATION_NUMBER;

  /**
   * Identifiant json de {@link #childrenCount}.
   */
  @Deprecated(forRemoval = true)
  public static final String JSON_CHILDREN_COUNT = "nombreEnfant";
  
  /**
   * Identifiant json de {@link #married}.
   */
  @Deprecated(forRemoval = true)
  public static final String JSON_MARRIED = "marie";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "fonctionnaires de paie";
}
