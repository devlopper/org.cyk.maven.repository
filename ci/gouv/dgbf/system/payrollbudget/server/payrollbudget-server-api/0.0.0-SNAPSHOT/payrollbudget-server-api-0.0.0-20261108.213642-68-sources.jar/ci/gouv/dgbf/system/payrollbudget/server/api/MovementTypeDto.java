package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Code {@code STATUT_EMPLOYE_UNITE_ADMINISTRATIVE} : champ utilisé pour type de sortie.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS)
  private String administrativeUnitEmployeeStatusCode;

  /**
   * Représentation en chaine de caractères de {@link #EmployeeStatus}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS_AS_STRING)
  private String administrativeUnitEmployeeStatusAsString;

  /**
   * Le droit qu'il faut détenir pour instruire une ligne de ce type.
   *
   * <p><strong>Le droit est déclaré, non déduit.</strong> Il se déduisait de la forme de la
   * ligne — mouvement projeté, mesure ponctuelle, transfert — et cette forme n'est pas ce que
   * le métier répartit. Chaque type dit désormais lui-même qui l'instruit, et la répartition
   * se change à l'écran de paramétrage au lieu de se recompiler.</p>
   *
   * <p>Vide, le type retombe sur {@code TRAITER_MOUVEMENT_A_VENIR} : c'est le cas général, et
   * un type qu'on vient d'ajouter doit être instruisible avant d'être paramétré, non muet.</p>
   */
  @JsonbProperty(JSON_PROCESSING_ROLE)
  private String processingRole;

  /**
   * Identifiant json de identifiant de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeMouvementChaine";

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeStatusCode}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS =
      "statutEmployeUniteAdministrative";

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeStatusAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS_AS_STRING =
      "statutEmployeUniteAdministrativeChaine";

  /**
   * Identifiant json de {@link #processingRole}.
   */
  public static final String JSON_PROCESSING_ROLE = "roleTraitement";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de mouvement";
}
