package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@NoArgsConstructor
public class DictionaryEntryFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link DictionaryDto}.
   */
  String dictionaryIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DictionaryEntryFilter(FilterDto dto) {
    super(dto);
  }


  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    dictionaryIdentifier = getDictionaryIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setDictionaryIdentifier(filter, dictionaryIdentifier);
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link DictionaryDto}.
   *
   * @param filter filtre
   * @return identifiant {@link DictionaryDto}
   */
  public static String getDictionaryIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_DICTIONARY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link DictionaryDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link DictionaryDto}
   */
  public static void setDictionaryIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_DICTIONARY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #dictionaryIdentifier}.
   */
  public static final String JSON_DICTIONARY_IDENTIFIER =
      DictionaryEntryDto.JSON_DICTIONARY_IDENTIFIER;


}

