package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.Ajax;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputsGroupController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup.DocumentTypeGroupUploadController;
import ci.gouv.dgbf.system.documentation.client.extension.documenttypesgroup.DocumentTypesGroupSelectOneController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupRequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentGroupController extends AbstractController {

  @Inject
  DocumentGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  DocumentGroupRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController processInputTextController;

  @Inject
  @Getter
  InputTextController sourceInputTextController;

  @Inject
  @Getter
  InputTextController recordInputTextController;

  @Inject
  @Getter
  InputTextController operationInputTextController;

  @Inject
  @Getter
  DocumentTypesGroupSelectOneController typeGroupSelectOneController;

  @Inject
  @Getter
  InputsGroupController inputsGroupController;

  @Inject
  @Getter
  DocumentGroupFilterController filterController;

  @Inject
  @Getter
  DocumentTypeGroupUploadController uploadController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DocumentGroupDto.NAME;

    listController.setEntityClass(DocumentGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DocumentGroupService.PATH);
    listController.setFilterController(filterController);
    listController.getDataTable().getFilterButton().setRendered(true);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER,
        HasSourceIdentifierDto.JSON_SOURCE_IDENTIFIER,
        HasRecordIdentifierDto.JSON_RECORD_IDENTIFIER,
        HasOperationIdentifierDto.JSON_OPERATION_IDENTIFIER,
        DocumentGroupDto.JSON_TYPE_GROUP_IDENTIFIER,
        HasTypeGroupAsStringDto.JSON_TYPE_GROUP_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(DocumentGroupReadIndexPage.OUTCOME);

    listController.initialize();

    listController.getCreateController().setFunction(createControllerFunction());

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController().setFunction(updateControllerFunction());

    initializeInputText(processInputTextController, "Identifiant du processus",
        processConsumer());
    initializeInputText(sourceInputTextController, "Identifiant de la source", sourceConsumer());
    initializeInputText(recordInputTextController, "Identifiant de l'enregistrement",
        recordConsumer());
    initializeInputText(operationInputTextController, "Identifiant de l'opération",
        operationConsumer());

    typeGroupSelectOneController.getSelectOneMenu().addValueConsumer(typeGroupConsumer());

    // À chaque changement de groupe de types, on reconstruit les pièces attendues et on
    // redessine leur panneau. Le composant selectOneMenu d'extension désactive son ajax par
    // défaut : on l'active ici.
    Ajax typeGroupAjax = typeGroupSelectOneController.getSelectOneMenu().valueChangeAjax();
    typeGroupAjax.setEvent("valueChange");
    typeGroupAjax.setUpdate(DocumentTypeGroupUploadController.PANEL_SELECTOR);
    typeGroupAjax.setConsumer(event -> refreshUploads());
    typeGroupAjax.setDisabled(false);

    inputsGroupController.add(processInputTextController.getInputText(),
        sourceInputTextController.getInputText(), recordInputTextController.getInputText(),
        operationInputTextController.getInputText(),
        typeGroupSelectOneController.getSelectOneMenu());
  }

  void initializeInputText(InputTextController inputTextController, String label,
      Consumer<String> valueConsumer) {
    inputTextController.setOutputLableValue(label);
    inputTextController.getInputText().addValueConsumer(valueConsumer);
    inputTextController.getInputText().setRequired(true);
  }

  Consumer<String> processConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
        .setProcessIdentifier(identifier);
  }

  Consumer<String> sourceConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
        .setSourceIdentifier(identifier);
  }

  Consumer<String> recordConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
        .setRecordIdentifier(identifier);
  }

  Consumer<String> operationConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
        .setOperationIdentifier(identifier);
  }

  Consumer<String> typeGroupConsumer() {
    return identifier -> {
      listController.getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
          .setTypeGroupIdentifier(identifier);
      uploadController.refresh(identifier);
    };
  }

  /**
   * Cette méthode reconstruit les pièces attendues à partir du groupe de types actuellement
   * sélectionné. Appelée par l'ajax du sélecteur de groupe de types.
   */
  void refreshUploads() {
    uploadController.refresh(
        listController.getCreateControllerOrUpdateControllerEntityAs(DocumentGroupDto.class)
            .getTypeGroupIdentifier());
  }

  // Create

  Function<Object, Object> createControllerFunction() {
    return entity -> {
      DocumentGroupCreateRequestDto request = requestMapper.mapCreate((DocumentGroupDto) entity);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = client.create(request);
      uploadController.createDocuments(response.getIdentifier());
      return response;
    };
  }

  // Update

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      DocumentGroupDto documentGroup = (DocumentGroupDto) entity;
      processInputTextController.getInputText().writeValue(documentGroup.getProcessIdentifier());
      sourceInputTextController.getInputText().writeValue(documentGroup.getSourceIdentifier());
      recordInputTextController.getInputText().writeValue(documentGroup.getRecordIdentifier());
      operationInputTextController.getInputText()
          .writeValue(documentGroup.getOperationIdentifier());
      typeGroupSelectOneController.getSelectOneMenu()
          .writeValue(documentGroup.getTypeGroupIdentifier());

      // Ce consommateur n'est invoqué qu'à l'ouverture du formulaire : on repart d'un état
      // vierge, sinon refresh(...) court-circuiterait pour deux groupes partageant le même
      // groupe de types et afficherait les pièces du groupe précédent.
      uploadController.reset();
      // L'ajax valueChange du selectOneMenu ne se déclenche que sur une interaction utilisateur,
      // pas sur le writeValue ci-dessus : sans cela, le panneau des pièces attendues resterait
      // vide à l'ouverture du formulaire de modification.
      uploadController.refresh(documentGroup.getTypeGroupIdentifier());
      uploadController.loadExistingDocuments(documentGroup.getIdentifier());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      DocumentGroupDto documentGroup = (DocumentGroupDto) entity;
      DocumentGroupUpdateRequestDto request = requestMapper.mapUpdate(documentGroup);
      request.setAuditWho(userIdentifier);
      Object response = client.update(request);
      uploadController.syncDocuments(documentGroup.getIdentifier());
      return response;
    };
  }
}
