package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-21T21:15:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketRequestMapperImpl implements TicketRequestMapper {

    @Override
    public TicketService.TicketCreateRequestDto mapCreate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketCreateRequestDto ticketCreateRequestDto = new TicketService.TicketCreateRequestDto();

        ticketCreateRequestDto.setCode( arg0.getCode() );
        ticketCreateRequestDto.setName( arg0.getName() );
        ticketCreateRequestDto.setDescription( arg0.getDescription() );

        return ticketCreateRequestDto;
    }

    @Override
    public TicketService.TicketUpdateRequestDto mapUpdate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketUpdateRequestDto ticketUpdateRequestDto = new TicketService.TicketUpdateRequestDto();

        ticketUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketUpdateRequestDto.setDescription( arg0.getDescription() );

        return ticketUpdateRequestDto;
    }
}
