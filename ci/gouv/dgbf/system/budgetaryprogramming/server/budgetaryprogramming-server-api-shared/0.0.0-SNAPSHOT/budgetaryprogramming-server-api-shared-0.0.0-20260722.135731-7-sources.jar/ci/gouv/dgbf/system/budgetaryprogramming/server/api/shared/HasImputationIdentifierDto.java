package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'imputation.
 *
 * @author Christian
 */
public interface HasImputationIdentifierDto extends HasImputationIdentifier {

  /**
   * Identifiant json de l'identifiant de l'imputation.
   */
  String JSON_IMPUTATION_IDENTIFIER = "idImputation";
}