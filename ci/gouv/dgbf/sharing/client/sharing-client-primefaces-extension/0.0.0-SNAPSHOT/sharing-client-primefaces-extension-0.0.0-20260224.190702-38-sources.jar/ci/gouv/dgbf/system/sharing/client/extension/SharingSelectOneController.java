package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.sharing.server.api.SharingClient;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SharingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class SharingSelectOneController extends AbstractSelectOneIdentifiableController<
    SharingDto, SharingGetManyResponseDto, SharingClient> {

  @Inject
  @Getter
  SharingClient client;

  /**
   * Cette methode permet de construire.
   */
  protected SharingSelectOneController() {
    super(SharingDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
