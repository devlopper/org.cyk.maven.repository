package ci.gouv.dgbf.extension.primefaces.component.input;

import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un {@link LocalDateTime}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputLocalDateTime extends AbstractInputOneDate<LocalDateTime> {

}
