package ci.gouv.dgbf.extension.primefaces.interceptor;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;

/**
 * Cette classe représente le filtre de redirection à la page d'accueil de l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public class UserHomePageRedirectionFilter implements Filter {

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    HttpSession session = ((HttpServletRequest) request).getSession(false);
    if (session == null) {
      chain.doFilter(request, response);
      return;
    }
    String url = (String) session.getAttribute(HOME_PAGE_URL_ATTRIBUTE_NAME);
    if (Core.isStringBlank(url)) {
      chain.doFilter(request, response);
      return;
    }
    session.removeAttribute(HOME_PAGE_URL_ATTRIBUTE_NAME); // Avoid looping
    ((HttpServletResponse) response).sendRedirect(url);
  }

  public static final String HOME_PAGE_URL_ATTRIBUTE_NAME = "urlPageAccueil";
}
