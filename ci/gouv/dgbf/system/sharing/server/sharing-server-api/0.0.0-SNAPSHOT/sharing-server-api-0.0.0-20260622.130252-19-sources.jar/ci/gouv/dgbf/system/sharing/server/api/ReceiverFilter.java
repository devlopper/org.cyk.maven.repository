package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ReceiverFilter extends AbstractResourceOrReceiverFilter {
  
  private ReceiverType type;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ReceiverFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ReceiverFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    type = getType(filter);
  }
  
  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setType(filter, type);
  }

  /**
   * Cette méthode permet d'assigner le {@link ReceiverType}.
   *
   * @param filter filtre
   * @param type {@link ReceiverType}
   */
  public static void setType(FilterDto filter, ReceiverType type) {
    set(filter, JSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ReceiverType}.
   *
   * @param filter filtre
   * @return {@link ReceiverType}
   */
  public static ReceiverType getType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, ReceiverType.class));
  }
}
