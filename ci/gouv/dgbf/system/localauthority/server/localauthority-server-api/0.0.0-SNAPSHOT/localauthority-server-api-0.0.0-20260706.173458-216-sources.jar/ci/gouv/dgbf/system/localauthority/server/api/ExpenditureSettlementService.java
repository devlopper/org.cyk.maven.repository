package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ExpenditureSettlementDto}.
 *
 * @author Desysoft
 */
@Path(value = ExpenditureSettlementService.PATH)
@Tag(name = "Gestion des liquidations")
public interface ExpenditureSettlementService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "liquidations";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_LIQUIDATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une liquidation",
      description = "Ce service permet de créer une liquidation")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ExpenditureSettlementCreateRequestDto request);

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Desysoft
   */
  interface ExpenditureSettlementSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link LocalAuthorityDto}.
     *
     * @return identifiant de {@link LocalAuthorityDto}
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
     *
     * @param identifier identifiant de {@link LocalAuthorityDto}
     */
    void setLocalAuthorityIdentifier(String identifier);


    /**
     * Représentation en chaine de caractères de {@link SupplierDto}.
     *
     * @param supplierIdentifier identifiant de fournisseur
     */
    void setSupplierIdentifier(String supplierIdentifier);

    /**
     * Identifiant {@link SupplierDto}.
     *
     * @return supplier identifier
     */
    String getSupplierIdentifier();


    /**
     * Cette méthode permet d'obtenir le code du fournisseur.
     *
     * @return supplierCode
     */
    String getSupplierCode();

    /**
     * Cette méthode permet d'assigner le code du fournisseur.
     *
     * @param supplierCode code fournisseur
     */

    void setSupplierCode(String supplierCode);


    /**
     * Cette méthode permet d'obtenir le libellé du fournisseur.
     *
     * @return supplierName
     */
    String getSupplierName();

    /**
     * Cette méthode permet d'assigner le libellé du fournisseur.
     *
     * @param supplierName nom fournisseur
     */
    void setSupplierName(String supplierName);

    /**
     * Représentation en chaine de caractères de {@link EconomicNatureDto}.
     *
     * @param economicNatureIdentifier identifiant de nature economique
     */
    void setEconomicNatureIdentifier(String economicNatureIdentifier);

    /**
     * Identifiant {@link EconomicNatureDto}.
     *
     * @return economicNature identifier
     */
    String getEconomicNatureIdentifier();


    /**
     * Cette méthode permet d'obtenir le code de la nature économique.
     *
     * @return economicNatureCode
     */
    String getEconomicNatureCode();

    /**
     * Cette méthode permet d'assigner le code de la nature économique.
     *
     * @param economicNatureCode code nature économique
     */

    void setEconomicNatureCode(String economicNatureCode);


    /**
     * Cette méthode permet d'obtenir le libellé de la nature économique.
     *
     * @return economicNatureName libellé nature économique
     */
    String getEconomicNatureName();

    /**
     * Cette méthode permet d'assigner le libellé de la nature économique.
     *
     * @param economicNatureName libellé nature économique
     */
    void setEconomicNatureName(String economicNatureName);


    /**
     * Cette methode permet d'obtenir le sujet de la liquidation.
     *
     * @return subject
     */
    String getSubject();

    /**
     * Cette méthode permet d'assigner le sujet.
     *
     * @param subject sujet
     */
    void setSubject(String subject);

    /**
     * Cette methode permet d'obtenir la référence de la liquidation.
     *
     * @return commitmentReference La référence de l'engagememnt
     */
    String getCommitmentReference();

    /**
     * Cette méthode permet d'assigner la référence de la liquidation.
     *
     * @param commitmentReference référence facture
     */
    void setCommitmentReference(String commitmentReference);

    /**
     * Cette methode permet d'obtenir le numéro de la facture décompte.
     *
     * @return numéro de la facture décompte
     */
    String getInvoiceReferenceNumber();

    /**
     * Cette méthode permet d'assigner le numéro de la facture décompte.
     *
     * @param invoiceReferenceNumber numéro facture décompte
     */
    void setInvoiceReferenceNumber(String invoiceReferenceNumber);

    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    long getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(long amount);


    /**
     * Cette méthode permet d'obtenir le montant mandaté.
     *
     * @return montant mandaté
     */
    long getAuthorizedAmount();

    /**
     * Cette méthode permet d'assigner le montant mandaté.
     *
     * @param authorizedAmount montant mandaté
     */
    void setAuthorizedAmount(long authorizedAmount);

    /**
     * Cette méthode permet d'assigner le montant restant à payér.
     *
     * @param remainingAmountToAuthorize montant restant à payér
     */
    void setRemainingAmountToAuthorize(long remainingAmountToAuthorize);


    /**
     * Cette méthode permet d'obtenir le montant restant à payér.
     *
     * @return remainingAmountToAuthorize restant à payér
     */
    long getRemainingAmountToAuthorize();


    /**
     * Cette méthode permet d'obtenir la date de la liquidation.
     *
     * @return date
     */
    LocalDate getDate();

    /**
     * Cette méthode permet d'assigner la date de la liquidation.
     *
     * @param date date
     */
    void setDate(LocalDate date);


    /**
     * Reprensentaion json de l'identifiant d'un fournisseur'.
     */
    String JSON_SUPPLIER_IDENTIFIER = "idFournisseur";

    /**
     * Representaion json du code d'un fournisseur.
     */
    String JSON_SUPPLIER_CODE = "codeFournisseur";

    /**
     * Representaion json du nom du fournisseur.
     */
    String JSON_SUPPLIER_NAME = "nomfournisseur";

    /**
     * Representaion chaine du fournisseur.
     */
    String JSON_SUPPLIER_AS_STRING = "fournisseurChaine";

    /**
     * Reprensentaion json de l'identifiant de la nature économique'.
     */
    String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureEconomique";

    /**
     * Representaion json du code de la nature économique.
     */
    String JSON_ECONOMIC_NATURE_CODE = "codeNatureEconomique";

    /**
     * Representaion json du nom du fournisseur.
     */
    String JSON_ECONOMIC_NATURE_NAME = "nomfournisseur";


    /**
     * Identifiant json du champ de l'identitant de {@link LocalAuthorityDto}.
     */
    String JSON_LOCAL_AUTHORITY_IDENTIFIER =
        ExpenditureSettlementDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;


    /**
     * Identifiant json du champ sujet de {@link ExpenditureSettlementDto}.
     */
    String JSON_SUBJECT = ExpenditureSettlementDto.JSON_SUBJECT;


    /**
     * Identifiant json du champ référence de liquidation de {@link ExpenditureSettlementDto}.
     */
    String JSON_COMMITMENT_REFERENCE = ExpenditureSettlementDto.JSON_COMMITMENT_REFERENCE;


    /**
     * Identifiant json du champ numéro facture décompte de {@link ExpenditureSettlementDto}.
     */
    String JSON_INVOICE_REFERENCE_NUMBER = ExpenditureSettlementDto.JSON_INVOICE_REFERENCE_NUMBER;


    /**
     * Identifiant json du champ date.
     */
    String JSON_DATE = ExpenditureSettlementDto.JSON_DATE;

    /**
     * Identifiant json du champ de montant.
     */
    String JSON_AMOUNT = ExpenditureSettlementDto.JSON_AMOUNT;


    /**
     * Identifiant json du champ de montant mandaté.
     */
    String JSON_AUTHORIZED_AMOUNT = ExpenditureSettlementDto.JSON_AUTHORIZED_AMOUNT;


    /**
     * Identifiant json du champ de montant  restant à payer.
     */
    String JSON_REMAINING_AMOUNT_TO_AUTHORIZE =
        ExpenditureSettlementDto.JSON_REMAINING_AMOUNT_TO_AUTHORIZE;

  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ExpenditureSettlementCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ExpenditureSettlementSaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
    private String supplierIdentifier;

    @JsonbProperty(JSON_SUPPLIER_CODE)
    private String supplierCode;

    @JsonbProperty(JSON_SUPPLIER_NAME)
    private String supplierName;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_CODE)
    private String economicNatureCode;

    @JsonbProperty(JSON_ECONOMIC_NATURE_NAME)
    private String economicNatureName;

    @JsonbProperty(JSON_SUBJECT)
    private String subject;

    @JsonbProperty(JSON_COMMITMENT_REFERENCE)
    private String commitmentReference;

    @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
    private String invoiceReferenceNumber;

    @JsonbProperty(JSON_DATE)
    private LocalDate date;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;


    @JsonbProperty(JSON_AUTHORIZED_AMOUNT)
    private long authorizedAmount;

    @JsonbProperty(JSON_REMAINING_AMOUNT_TO_AUTHORIZE)
    private long remainingAmountToAuthorize;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_LIQUIDATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des activités")
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation =
              ExpenditureSettlementGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ExpenditureSettlementGetManyResponseDto
      extends AbstractGetByPageResponseDto<ExpenditureSettlementDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ExpenditureSettlementDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_LIQUIDATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une liquidation")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ExpenditureSettlementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_LIQUIDATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une liquidation")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ExpenditureSettlementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_LIQUIDATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une liquidation")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ExpenditureSettlementUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ExpenditureSettlementUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ExpenditureSettlementSaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUBJECT)
    private String subject;

    @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
    private String supplierIdentifier;

    @JsonbProperty(JSON_SUPPLIER_CODE)
    private String supplierCode;

    @JsonbProperty(JSON_SUPPLIER_NAME)
    private String supplierName;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_CODE)
    private String economicNatureCode;

    @JsonbProperty(JSON_ECONOMIC_NATURE_NAME)
    private String economicNatureName;

    @JsonbProperty(JSON_COMMITMENT_REFERENCE)
    private String commitmentReference;

    @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
    private String invoiceReferenceNumber;

    @JsonbProperty(JSON_DATE)
    private LocalDate date;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    @JsonbProperty(JSON_AUTHORIZED_AMOUNT)
    private long authorizedAmount;

    @JsonbProperty(JSON_REMAINING_AMOUNT_TO_AUTHORIZE)
    private long remainingAmountToAuthorize;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_LIQUIDATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ExpenditureSettlementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une liquidation")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

