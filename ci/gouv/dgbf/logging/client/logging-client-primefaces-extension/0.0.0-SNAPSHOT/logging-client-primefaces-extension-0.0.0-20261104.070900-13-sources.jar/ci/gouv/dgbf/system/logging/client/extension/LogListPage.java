package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.logging.server.api.LogDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link LogDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class LogListPage extends AbstractPage {

  @Inject
  @Getter
  LogController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + LogDto.NAME;
    controller.initialize();
  }
  
  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "logListPage";
}
