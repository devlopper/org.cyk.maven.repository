package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des dossiers confiés aux équipes.
 *
 * <p>Le périmètre d'un agent se lit en deux temps, et non d'un critère : ses équipes d'abord,
 * leurs dossiers ensuite. Un agent appartient à une équipe, deux au plus — la boucle coûte
 * moins qu'une sous-requête que le constructeur de prédicats ne sait pas écrire.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ArbitrationTeamDossierFilter extends AbstractIdentifiableFilter {

  /**
   * Équipe dont on veut les dossiers.
   */
  String teamIdentifier;

  /**
   * Dossier dont on veut l'équipe.
   */
  String dossierIdentifier;

  public ArbitrationTeamDossierFilter() {
    super();
  }

  public ArbitrationTeamDossierFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setTeamIdentifier(ArbitrationMovementFilter.read(filter,
        ArbitrationTeamDossierDto.JSON_TEAM_IDENTIFIER));
    setDossierIdentifier(ArbitrationMovementFilter.read(filter,
        ArbitrationTeamDossierDto.JSON_DOSSIER_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    ArbitrationMovementFilter.write(filter, ArbitrationTeamDossierDto.JSON_TEAM_IDENTIFIER,
        getTeamIdentifier());
    ArbitrationMovementFilter.write(filter, ArbitrationTeamDossierDto.JSON_DOSSIER_IDENTIFIER,
        getDossierIdentifier());
  }
}
