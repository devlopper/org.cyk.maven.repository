package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryService.DictionaryEntryCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryService.DictionaryEntryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DictionaryEntryDto}.
    
    @author Christian
    """)
public interface DictionaryEntryRequestMapper
    extends
    RequestMapper<DictionaryEntryDto, DictionaryEntryCreateRequestDto,
        DictionaryEntryUpdateRequestDto> {

}

