package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/** Filtre de confidentialité d'une ressource. */
@Getter
@Setter
public class ResourceConfidentialityFilter extends AbstractIdentifiableFilter {

  private String resourceIdentifier;
  private ConfidentialityLevel confidentialityLevel;

  public ResourceConfidentialityFilter() {
  }

  public ResourceConfidentialityFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    resourceIdentifier = getResourceIdentifier(filter);
    confidentialityLevel = getConfidentialityLevel(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    set(filter, JSON_RESOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(resourceIdentifier));
    set(filter, JSON_CONFIDENTIALITY_LEVEL, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(confidentialityLevel));
  }

  /** Obtient l'identifiant de ressource depuis un filtre JSON. */
  public static String getResourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_RESOURCE_IDENTIFIER));
  }

  /** Obtient le niveau depuis un filtre JSON. */
  public static ConfidentialityLevel getConfidentialityLevel(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_CONFIDENTIALITY_LEVEL,
        ConfidentialityLevel.class));
  }

  /** Nom JSON de l'identifiant de ressource. */
  public static final String JSON_RESOURCE_IDENTIFIER =
      ResourceConfidentialityDto.JSON_RESOURCE_IDENTIFIER;

  /** Nom JSON du niveau. */
  public static final String JSON_CONFIDENTIALITY_LEVEL =
      ResourceConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL;
}
