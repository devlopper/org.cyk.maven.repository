package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.ClassHelper;
import jakarta.inject.Inject;

/**
 * Cette classe représente la base de contrôleur de création.
 *
 * @author Christian
 *
 */
public abstract class AbstractCreateController<T, R>
    extends AbstractCreateOrUpdateController<T, R> {

  protected Class<T> entityClass;

  @Inject
  ClassHelper classHelper;

  protected AbstractCreateController(Class<T> entityClass) {
    this.entityClass = entityClass;
    name = "Création";
  }

  protected void validateEntityClass() {
    if (entityClass == null) {
      throw new IllegalStateException("La classe de l'entité ne doit pas être nulle");
    }
  }

  @Override
  public boolean isCreate() {
    return true;
  }
}
