package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.OffsetDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Transition d'état d'un dossier de masse salariale : qui, quand, vers quel état et pourquoi.
 *
 * <p>Une ligne d'historique est écrite à chaque changement d'état et n'est jamais modifiée. C'est
 * ce journal qui permet, en fin de parcours, de reconstituer le chemin d'un dossier dont la masse
 * salariale aura été façonnée par une succession de décisions.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class BudgetAdministrativeUnitHistoryDto extends AbstractIdentifiableDto {

  /**
   * Dossier de masse salariale dont l'état change.
   */
  @JsonbProperty(JSON_DOSSIER_IDENTIFIER)
  private String dossierIdentifier;

  /**
   * État atteint par la transition.
   */
  @JsonbProperty(JSON_STATUS_CODE)
  private String statusCode;

  /**
   * Motif de la transition. Obligatoire pour tout rejet (RG_PRB_ARB_06), libre ailleurs.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Utilisateur à l'origine de la transition.
   */
  @JsonbProperty(JSON_ACTOR)
  private String actor;

  /**
   * Horodatage de la transition.
   */
  @JsonbProperty(JSON_STATUS_DATE)
  private OffsetDateTime statusDate;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTransitionEtatDossier";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "transitionEtatDossierChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "transition d'état de dossier";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "transitions d'état de dossier";

  /**
   * Identifiant json pour {@link #dossierIdentifier}.
   */
  public static final String JSON_DOSSIER_IDENTIFIER =
      BudgetAdministrativeUnitDossierDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "statut";

  /**
   * Identifiant json pour {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json pour {@link #actor}.
   */
  public static final String JSON_ACTOR = "acteur";

  /**
   * Identifiant json pour {@link #statusDate}.
   */
  public static final String JSON_STATUS_DATE = "dateEtat";
}
