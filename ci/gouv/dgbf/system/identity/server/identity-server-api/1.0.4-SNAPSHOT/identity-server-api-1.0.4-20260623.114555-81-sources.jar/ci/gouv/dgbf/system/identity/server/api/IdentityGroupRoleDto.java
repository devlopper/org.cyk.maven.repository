package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rôle d'identité de groupe.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityGroupRoleDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link IdentityGroupDto}.
   */
  @JsonbProperty(JSON_IDENTITY_GROUP_IDENTIFIER)
  private String identityGroupIdentifier;

  /**
   * Représentation en chaine de caractères {@link IdentityGroupDto}.
   */
  @JsonbProperty(JSON_IDENTITY_GROUP_AS_STRING)
  private String identityGroupAsString;

  /**
   * Représentation en chaine de caractères {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;

  /**
   * Identifiant {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_IDENTIFIER)
  private String roleIdentifier;

  /**
   * Représentation en chaine de caractères {@link RoleDto}.
   */
  @JsonbProperty(JSON_ROLE_AS_STRING)
  private String roleAsString;

  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Représentation en chaine de caractères {@link IdentityGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Identifiant JSON {@link #identityGroupIdentifier}.
   */
  public static final String JSON_IDENTITY_GROUP_IDENTIFIER = "idIdentiteGroupe";
  
  /**
   * Identifiant JSON {@link #identityGroupAsString}.
   */
  public static final String JSON_IDENTITY_GROUP_AS_STRING = "identiteGroupeChaine";
  
  /**
   * Identifiant JSON {@link #roleIdentifier}.
   */
  public static final String JSON_ROLE_IDENTIFIER = "idRole";
  
  /**
   * Identifiant JSON {@link #roleAsString}.
   */
  public static final String JSON_IDENTITY_AS_STRING = "identiteChaine";
  
  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";
  
  /**
   * Identifiant JSON {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";
  
  /**
   * Identifiant JSON {@link #roleAsString}.
   */
  public static final String JSON_ROLE_AS_STRING = "roleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rôle d'identité de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "rôles d'identité de groupe";
}
