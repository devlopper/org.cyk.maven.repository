package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant validé pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountN1AsString {

  /**
   * Obtient le montant validé pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant validé pour l'année N+1 sous forme de chaîne de caractères
   */
  String getValidatedAmountN1AsString();

  /**
   * Définit le montant validé pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param validatedAmountN1AsString le montant validé pour l'année N+1 sous forme de chaîne de
   *        caractères
   */
  void setValidatedAmountN1AsString(String validatedAmountN1AsString);

  /**
   * Identifiant java du montant validé pour l'année N+1, sous forme de chaîne de caractères.
   */
  String FIELD_VALIDATED_AMOUNT_N1_AS_STRING =
      "validatedAmountN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName