package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant intégré pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountN1AsString {

  /**
   * Obtient le montant intégré pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant intégré pour l'année N+1 sous forme de chaîne de caractères
   */
  String getIntegratedAmountN1AsString();

  /**
   * Définit le montant intégré pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param integratedAmountN1AsString le montant intégré pour l'année N+1 sous forme de chaîne de
   *        caractères
   */
  void setIntegratedAmountN1AsString(String integratedAmountN1AsString);

  /**
   * Identifiant java du montant intégré pour l'année N+1, sous forme de chaîne de caractères.
   */
  String FIELD_INTEGRATED_AMOUNT_N1_AS_STRING =
      "integratedAmountN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName