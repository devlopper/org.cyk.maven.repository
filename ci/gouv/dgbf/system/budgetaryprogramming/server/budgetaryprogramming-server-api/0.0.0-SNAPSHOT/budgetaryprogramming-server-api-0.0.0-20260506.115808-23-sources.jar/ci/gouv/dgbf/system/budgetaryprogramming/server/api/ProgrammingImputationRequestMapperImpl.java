package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingImputationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-06T11:58:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingImputationRequestMapperImpl implements ProgrammingImputationRequestMapper {

    @Override
    public ProgrammingImputationService.ProgrammingImputationCreateRequestDto mapCreate(ProgrammingImputationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingImputationService.ProgrammingImputationCreateRequestDto programmingImputationCreateRequestDto = new ProgrammingImputationService.ProgrammingImputationCreateRequestDto();

        programmingImputationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingImputationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingImputationCreateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingImputationCreateRequestDto.setImputationIdentifier( arg0.getImputationIdentifier() );
        programmingImputationCreateRequestDto.setExpenditure( arg0.getExpenditure() );

        return programmingImputationCreateRequestDto;
    }

    @Override
    public ProgrammingImputationService.ProgrammingImputationUpdateRequestDto mapUpdate(ProgrammingImputationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingImputationService.ProgrammingImputationUpdateRequestDto programmingImputationUpdateRequestDto = new ProgrammingImputationService.ProgrammingImputationUpdateRequestDto();

        programmingImputationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingImputationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingImputationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingImputationUpdateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingImputationUpdateRequestDto.setImputationIdentifier( arg0.getImputationIdentifier() );
        programmingImputationUpdateRequestDto.setExpenditure( arg0.getExpenditure() );

        return programmingImputationUpdateRequestDto;
    }
}
