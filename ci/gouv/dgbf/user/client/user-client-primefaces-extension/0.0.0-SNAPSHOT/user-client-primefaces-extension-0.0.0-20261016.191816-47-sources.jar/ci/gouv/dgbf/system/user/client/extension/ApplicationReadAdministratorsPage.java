package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ReservedRole;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.RoleService;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserService;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente l'onglet Administrateurs de la fiche d'une {@link ApplicationDto}
 * (RU_UTI_027) : une ligne par Rôle réservé — Applicatif, Technique, Fonctionnel —, ses
 * détenteurs, et le bouton de désignation de l'acteur habilité, selon les Droits calculés
 * (RG_UTI_ROL_08, RG_UTI_ROL_16, RG_UTI_ROL_17).
 *
 * @author Christian Yao Komenan
 */
@Named
@ViewScoped
public class ApplicationReadAdministratorsPage extends AbstractApplicationReadDatasPage {

  @Inject
  @Getter
  ApplicationController applicationController;

  @Inject
  RoleClient roleClient;

  @Inject
  UserClient userClient;

  @Getter
  List<AdministratorRow> rows;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    applicationController.initialize();
    rows = List.of(
        row("Administrateur Applicatif", ReservedRole.APPLICATION_ADMINISTRATOR,
            applicationController.getAssignAdministratorProcessingController()),
        row("Administrateur Technique", ReservedRole.TECHNICAL_ADMINISTRATOR,
            applicationController.getAssignTechnicalAdministratorProcessingController()),
        row("Administrateur Fonctionnel", ReservedRole.FUNCTIONAL_ADMINISTRATOR,
            applicationController.getAssignFunctionalAdministratorProcessingController()));
  }

  AdministratorRow row(String label, String code, IdentifiableProcessingController controller) {
    // Après une désignation, la fiche est rechargée pour montrer le nouveau détenteur (la liste
    // du contrôleur n'est pas affichée sur la fiche)
    controller.setReloadPageOnSuccess(true);
    return new AdministratorRow(label, readHolders(code), controller);
  }

  /**
   * Cette méthode lit les détenteurs d'un Rôle réservé de l'Application.
   *
   * @param code code du Rôle réservé
   * @return leurs noms, « Aucun » si personne ne le détient
   */
  String readHolders(String code) {
    GetManyRequestDto roleRequest = new GetManyRequestDto();
    RoleFilter roleFilter = new RoleFilter();
    roleFilter.setApplicationIdentifier(application.getIdentifier());
    roleFilter.setCode(code);
    roleRequest.useFilter(roleFilter);
    roleRequest.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    roleRequest.setAuditWho(userIdentifier);
    List<RoleDto> roles = RoleService.RoleGetManyResponseDto.getDatas(RoleDto.class,
        roleClient.getMany(roleRequest));
    if (roles.isEmpty()) {
      return NONE;
    }
    GetManyRequestDto userRequest = new GetManyRequestDto();
    UserFilter userFilter = new UserFilter();
    userFilter.setAssignedRoleIdentifier(roles.get(0).getIdentifier());
    userRequest.useFilter(userFilter);
    userRequest.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME);
    userRequest.setAuditWho(userIdentifier);
    List<UserDto> users = UserService.UserGetManyResponseDto.getDatas(UserDto.class,
        userClient.getMany(userRequest));
    return users.isEmpty() ? NONE
        : users.stream().map(UserDto::getName).sorted().collect(Collectors.joining(", "));
  }

  /**
   * Cette classe représente une ligne de l'onglet : un Rôle réservé et ses détenteurs.
   */
  @Getter
  public static class AdministratorRow {

    /**
     * Libellé du Rôle réservé.
     */
    private final String label;

    /**
     * Noms des détenteurs.
     */
    private final String holders;

    /**
     * Désignation correspondante (bouton et boîte de dialogue).
     */
    private final IdentifiableProcessingController controller;

    AdministratorRow(String label, String holders, IdentifiableProcessingController controller) {
      this.label = label;
      this.holders = holders;
      this.controller = controller;
    }
  }

  /**
   * Texte affiché quand personne ne détient le Rôle réservé.
   */
  static final String NONE = "Aucun";

  public static final String OUTCOME = "applicationReadAdministratorsPage";
}
