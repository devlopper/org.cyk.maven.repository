package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.component.CommandUpdatePropertyValueBuilder;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.application.FacesMessage;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur des actions de {@link ValueSelectorDto}.
 *
 * @author Christian
 */
@Dependent
public class ValueSelectorActionsController extends AbstractController {

  @Inject
  ValueSelectorClient client;

  @Inject
  ValueSelectorRequestMapper requestMapper;

  @Inject
  @Getter
  IdentifiableProcessingController evaluateProcessingController;

  @Getter
  ValueSelectorDto valueSelector;

  @Getter
  @Setter
  ListController listController;

  @Inject
  MessageManager messageManager;

  // Evaluate

  @Inject
  @Getter
  InputTextController evaluateFilterAttributeValueInputTextController;

  @Inject
  @Getter
  DataEntitySelectOneController dataEntitySelectOneController;

  @Getter
  @Setter
  String evaluatedEvent;

  /**
   * Cette méthode permet de construire.
   */
  public ValueSelectorActionsController() {
    evaluatedEvent = "evaluatedEvent";
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    evaluateProcessingController.setListController(listController);
    evaluateProcessingController.prepareDialog(ValueSelectorDto.class, "Évaluer", "pi pi-filter",
        evaluateFunction(), "evaluateForm", client);
    evaluateProcessingController.submitButton().setValue("Évaluer");
    evaluateProcessingController.submitButton()
        .setActionFunction(i -> evaluateProcessingController.getController().execute());

    evaluateProcessingController.submitButton()
        .addUpdates(CommandUpdatePropertyValueBuilder.formatObserver(evaluatedEvent));

    evaluateProcessingController.initialize();

    evaluateFilterAttributeValueInputTextController.setOutputLableValue("Valeur de filtrage");
    evaluateFilterAttributeValueInputTextController.getInputText()
        .addValueConsumer(evaluateFilterAttributeValueConsumer());

    dataEntitySelectOneController.getSelectOneMenu()
        .addValueConsumer(dataEntityConsumer());
  }

  UnaryOperator<Object> evaluateFunction() {
    return entity -> {
      ValueSelectorEvaluateRequestDto request =
          requestMapper.mapEvaluate((ValueSelectorDto) entity);
      request.setAuditWho(userIdentifier);
      ValueSelectorEvaluateResponseDto response = client.evaluate(request);
      messageManager.showMessage(new FacesMessage(response.getValue()));
      return response;
    };
  }

  Consumer<String> evaluateFilterAttributeValueConsumer() {
    return value -> ((ValueSelectorDto) evaluateProcessingController.getController().getEntity())
        .setFilterAttributeValue(value);
  }

  Consumer<String> dataEntityConsumer() {
    return identifier -> ((ValueSelectorDto) evaluateProcessingController.getController()
        .getEntity()).setDataEntityIdentifier(identifier);
  }
}
