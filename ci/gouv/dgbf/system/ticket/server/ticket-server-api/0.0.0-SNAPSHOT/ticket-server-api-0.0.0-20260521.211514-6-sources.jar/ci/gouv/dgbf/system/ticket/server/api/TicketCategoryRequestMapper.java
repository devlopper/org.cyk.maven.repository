package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.TicketCategoryService.TicketCategoryCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketCategoryService.TicketCategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TicketCategoryDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TicketCategoryDto}.

    @author Arnaud
               """)
public interface TicketCategoryRequestMapper
    extends RequestMapper<TicketCategoryDto, TicketCategoryCreateRequestDto,
     TicketCategoryUpdateRequestDto> {

}
