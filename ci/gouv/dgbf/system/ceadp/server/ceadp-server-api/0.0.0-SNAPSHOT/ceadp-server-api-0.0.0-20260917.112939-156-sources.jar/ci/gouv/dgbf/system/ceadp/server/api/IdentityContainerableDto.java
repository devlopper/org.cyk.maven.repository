package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
public interface IdentityContainerableDto extends IdentityContainerable {

  /**
   * Identifiant json {@link IdentityContainerableDto#getIdentityCountAsString()}.
   */
  String JSON_IDENTITY_COUNT_AS_STRING = "nombreIdentite";
}
