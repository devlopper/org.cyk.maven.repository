package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link MovementDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = MovementService.PATH)
@Tag(name = "Gestion des mouvements")
public interface MovementService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "mouvements";

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface MovementSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link AdministrativeUnitEmployeeDto}.
     *
     * @return identifiant {@link AdministrativeUnitEmployeeDto}
     */
    String getAdministrativeUnitEmployeeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link AdministrativeUnitEmployeeDto}.
     *
     * @param identifier identifiant {@link AdministrativeUnitEmployeeDto}
     */
    void setAdministrativeUnitEmployeeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link MovementTypeDto}.
     *
     * @return identifiant {@link MovementTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link MovementTypeDto}.
     *
     * @param identifier identifiant {@link MovementTypeDto}
     */
    void setTypeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir la date d'effet.
     *
     * @return date d'effet
     */
    LocalDate getEffectiveDate();

    /**
     * Cette méthode permet d'assigner la date d'effet.
     *
     * @param effectiveDate date d'effet
     */
    void setEffectiveDate(LocalDate effectiveDate);
    
    /**
     * {@link MovementDto#JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER =
        MovementDto.JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER;

    /**
     * {@link MovementDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = MovementDto.JSON_TYPE_IDENTIFIER;
    
    /**
     * {@link MovementDto#JSON_EFFECTIVE_DATE}.
     */
    String JSON_EFFECTIVE_DATE = MovementDto.JSON_EFFECTIVE_DATE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MOUVEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MovementCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class MovementCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements MovementSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
    String administrativeUnitEmployeeIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    String typeIdentifier;
    
    @JsonbProperty(JSON_EFFECTIVE_DATE)
    LocalDate effectiveDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class MovementGetManyResponseDto extends AbstractGetByPageResponseDto<MovementDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MovementDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MOUVEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MOUVEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(MovementUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class MovementUpdateRequestDto extends ByIdentifierRequestDto implements MovementSaveRequestDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
    String administrativeUnitEmployeeIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    String typeIdentifier;
    
    @JsonbProperty(JSON_EFFECTIVE_DATE)
    LocalDate effectiveDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MOUVEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
