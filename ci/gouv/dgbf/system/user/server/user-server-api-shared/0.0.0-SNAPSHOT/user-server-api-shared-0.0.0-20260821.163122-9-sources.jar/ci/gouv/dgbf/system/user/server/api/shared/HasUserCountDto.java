package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'utilisateurs.
 *
 * @author Christian
 */
public interface HasUserCountDto extends HasUserCount {

  /**
   * Identifiant json du nombre d'utilisateurs.
   */
  String JSON_USER_COUNT = "nombreUtilisateurs";
}
