package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SsoApplicationDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-21T07:24:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SsoApplicationRequestMapperImpl implements SsoApplicationRequestMapper {

    @Override
    public SsoApplicationService.SsoApplicationCreateRequestDto mapCreate(SsoApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoApplicationService.SsoApplicationCreateRequestDto ssoApplicationCreateRequestDto = new SsoApplicationService.SsoApplicationCreateRequestDto();

        ssoApplicationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        ssoApplicationCreateRequestDto.setCode( arg0.getCode() );
        ssoApplicationCreateRequestDto.setName( arg0.getName() );

        return ssoApplicationCreateRequestDto;
    }

    @Override
    public SsoApplicationService.SsoApplicationUpdateRequestDto mapUpdate(SsoApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoApplicationService.SsoApplicationUpdateRequestDto ssoApplicationUpdateRequestDto = new SsoApplicationService.SsoApplicationUpdateRequestDto();

        ssoApplicationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        ssoApplicationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );

        return ssoApplicationUpdateRequestDto;
    }
}
