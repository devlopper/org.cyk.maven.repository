package ci.gouv.dgbf.extension.server.service.impl.converter;

import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.inject.Inject;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Cette classe représente le convertisseur du type Set.
 *
 * @author Christian
 *
 */
public class StringSetParamConverter
    implements jakarta.ws.rs.ext.ParamConverter<Set<String>> {
  private static final Logger LOGGER = Logger.getLogger(StringSetParamConverter.class.getName());

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet de construire un convertisseur de type Set.
   *
   * @param stringHelper l'aide du type chaine de caractère
   */
  public StringSetParamConverter(StringHelper stringHelper) {
    this.stringHelper = stringHelper;
  }
  
  @Override
  public Set<String> fromString(String string) {
    if (Boolean.TRUE.equals(stringHelper.isBlank(string))) {
      return Collections.emptySet();
    }
    Set<String> set = new LinkedHashSet<>(Arrays.stream(string.split(",")).toList());
    LOGGER.log(Level.FINE, "Chaine de caractère convertie en Set. {0}", set);
    return set;
  }

  @Override
  public String toString(Set<String> collection) {
    if (collection == null) {
      return null;
    }
    String string = collection.stream().map(Object::toString).collect(Collectors.joining(","));
    LOGGER.log(Level.FINE, "Set convertie en chaine de caractère. {0}", string);
    return string;
  }
}
