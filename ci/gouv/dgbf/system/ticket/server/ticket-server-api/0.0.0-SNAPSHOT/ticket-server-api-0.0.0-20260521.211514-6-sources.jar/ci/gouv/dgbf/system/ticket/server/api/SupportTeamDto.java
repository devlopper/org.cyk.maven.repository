package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un equipe support.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idServiceSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "serviceSupportChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "service support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "services support";

}

