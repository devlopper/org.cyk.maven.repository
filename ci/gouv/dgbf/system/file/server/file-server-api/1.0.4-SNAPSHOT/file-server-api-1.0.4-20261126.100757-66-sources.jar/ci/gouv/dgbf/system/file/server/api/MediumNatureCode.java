package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link MediumNature}.
 *
 * @author Christian
 *
 */
public class MediumNatureCode {

  private MediumNatureCode() {

  }

  /**
   * Numérique.
   */
  public static final String DIGITAL = "NUMERIQUE";

  /**
   * Physique.
   */
  public static final String PHYSICAL = "PHYSIQUE";

  /**
   * Hybride.
   */
  public static final String HYBRID = "HYBRIDE";
}
