package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/** Filtre de confidentialité par type de ressource. */
@Getter
@Setter
public class ResourceTypeConfidentialityFilter extends AbstractIdentifiableFilter {

  private ResourceType resourceType;
  private ConfidentialityLevel confidentialityLevel;

  public ResourceTypeConfidentialityFilter() {
  }

  public ResourceTypeConfidentialityFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    resourceType = getResourceType(filter);
    confidentialityLevel = getConfidentialityLevel(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setResourceType(filter, resourceType);
    setConfidentialityLevel(filter, confidentialityLevel);
  }

  /** Definit le type de ressource dans le filtre. */
  public static void setResourceType(FilterDto filter, ResourceType resourceType) {
    set(filter, JSON_RESOURCE_TYPE, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(resourceType));
  }

  public static final String JSON_RESOURCE_TYPE = ResourceTypeConfidentialityDto.JSON_RESOURCE_TYPE;
  public static final String JSON_CONFIDENTIALITY_LEVEL =
      ResourceTypeConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL;

  /** Obtient le type de ressource filtre. */
  public static ResourceType getResourceType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_RESOURCE_TYPE, ResourceType.class));
  }

  /** Definit le niveau de confidentialite dans le filtre. */
  public static void setConfidentialityLevel(FilterDto filter,
      ConfidentialityLevel confidentialityLevel) {
    set(filter, JSON_CONFIDENTIALITY_LEVEL, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(confidentialityLevel));
  }

  /** Obtient le niveau de confidentialite filtre. */
  public static ConfidentialityLevel getConfidentialityLevel(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_CONFIDENTIALITY_LEVEL,
        ConfidentialityLevel.class));
  }
}
