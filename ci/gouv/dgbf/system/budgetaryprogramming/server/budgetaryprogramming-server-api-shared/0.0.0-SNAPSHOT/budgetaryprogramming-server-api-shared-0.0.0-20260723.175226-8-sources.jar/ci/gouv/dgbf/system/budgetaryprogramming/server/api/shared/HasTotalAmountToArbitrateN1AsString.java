package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN1AsString {

  /**
   * Obtient le montant total à arbitrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant total à arbitrer pour l'année N+1 sous forme de chaîne de caractères
   */
  String getTotalAmountToArbitrateN1AsString();

  /**
   * Définit le montant total à arbitrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param totalAmountToArbitrateN1AsString le montant total à arbitrer pour l'année N+1 sous forme
   *        de chaîne de caractères
   */
  void setTotalAmountToArbitrateN1AsString(String totalAmountToArbitrateN1AsString);

  /**
   * Identifiant java du montant total à arbitrer pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N1_AS_STRING = "totalAmountToArbitrateN1AsString";
}
