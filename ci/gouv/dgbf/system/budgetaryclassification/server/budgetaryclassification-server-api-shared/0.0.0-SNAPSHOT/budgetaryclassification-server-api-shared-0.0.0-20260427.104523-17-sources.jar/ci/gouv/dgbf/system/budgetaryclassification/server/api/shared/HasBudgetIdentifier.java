package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de budget.
 *
 * @author Christian
 */
public interface HasBudgetIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de budget.
   *
   * @return identifiant de budget
   */
  String getBudgetIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de budget.
   *
   * @param identifier identifiant de budget
   */
  void setBudgetIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de budget.
   */
  String FIELD_BUDGET_IDENTIFIER = "budgetIdentifier";
}