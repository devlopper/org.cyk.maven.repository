package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FolderTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FolderTypeRequestMapperImpl implements FolderTypeRequestMapper {

    @Override
    public FolderTypeService.FolderTypeCreateRequestDto mapCreate(FolderTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderTypeService.FolderTypeCreateRequestDto folderTypeCreateRequestDto = new FolderTypeService.FolderTypeCreateRequestDto();

        folderTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderTypeCreateRequestDto.setCode( arg0.getCode() );
        folderTypeCreateRequestDto.setName( arg0.getName() );

        return folderTypeCreateRequestDto;
    }

    @Override
    public FolderTypeService.FolderTypeUpdateRequestDto mapUpdate(FolderTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderTypeService.FolderTypeUpdateRequestDto folderTypeUpdateRequestDto = new FolderTypeService.FolderTypeUpdateRequestDto();

        folderTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        folderTypeUpdateRequestDto.setCode( arg0.getCode() );
        folderTypeUpdateRequestDto.setName( arg0.getName() );

        return folderTypeUpdateRequestDto;
    }
}
