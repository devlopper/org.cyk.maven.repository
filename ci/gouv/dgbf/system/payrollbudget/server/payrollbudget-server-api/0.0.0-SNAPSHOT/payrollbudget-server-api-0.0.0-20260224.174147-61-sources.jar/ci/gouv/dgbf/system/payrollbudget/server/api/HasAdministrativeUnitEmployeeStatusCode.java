package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeStatusCode extends HasField {

  /**
   * Cette méthode permet d'obtenir le code de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @return code de {@link AdministrativeUnitEmployeeStatus}
   */
  String getAdministrativeUnitEmployeeStatusCode();

  /**
   * Cette méthode permet d'assigner le code de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param code code de {@link AdministrativeUnitEmployeeStatus}
   */
  void setAdministrativeUnitEmployeeStatusCode(String code);

}
