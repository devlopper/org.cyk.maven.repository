package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountCreateByUserRequestDto;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.AccountService.AccountUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link AccountService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class AccountClient extends AbstractClient<AccountService>
    implements GetByIdentifier<AccountDto>, GetMany<AccountGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public AccountClient service(AccountService service) {
    return (AccountClient) super.service(service);
  }

  /**
   * {@link AccountService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(AccountCreateRequestDto request) {
    return new CreateExecutor(AccountService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }
  
  /**
   * {@link AccountService#createByUser}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createByUser(AccountCreateByUserRequestDto request) {
    return new CreateExecutor(AccountService.CREATE_BY_USER_IDENTIFIER)
        .execute(() -> service().createByUser(request));
  }

  /**
   * {@link AccountService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AccountGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AccountGetManyResponseDto>(AccountGetManyResponseDto.class,
        AccountService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link AccountService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AccountGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AccountService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AccountDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AccountDto>(AccountDto.class, AccountService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link AccountService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AccountDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AccountService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AccountDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AccountDto>(AccountDto.class,
        AccountService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AccountService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AccountDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link AccountService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(AccountUpdateRequestDto request) {
    return new IdentifiableExecutor(AccountService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link AccountService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(AccountService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link AccountService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
