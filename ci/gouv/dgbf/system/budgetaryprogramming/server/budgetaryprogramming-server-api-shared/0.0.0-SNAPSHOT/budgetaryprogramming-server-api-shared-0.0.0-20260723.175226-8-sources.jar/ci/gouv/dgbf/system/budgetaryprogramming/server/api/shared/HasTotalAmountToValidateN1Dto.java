package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN1Dto extends HasTotalAmountToValidateN1 {

  /**
   * Identifiant json du montant total à valider pour l'année N+1.
   */
  String JSON_TOTAL_AMOUNT_TO_VALIDATE_N1 = "montantTotalAValiderN1";
}
