package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste de {@link ResourceDto} de l'utilisateur connecté.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ConnectedUserResourceListPage extends AbstractResourceListPage {

  @Override
  protected void postConstruct() {
    super.postConstruct();
    requestParameterRedirectUrlValue = requestManager.getParameterRedirectUrl();
  }

  @Override
  void initializeController() {
    controller.getFilterController().getFilter().setUserName(userIdentifier);
    super.initializeController();
  }

  /**
   * Cas de navigation.
   */
  public static final String OUTCOME = "resourceListPage";

  /**
   * Chemin.
   */
  public static final String PATH = "/private/resource/connecteduser/list/index.xhtml";
}
