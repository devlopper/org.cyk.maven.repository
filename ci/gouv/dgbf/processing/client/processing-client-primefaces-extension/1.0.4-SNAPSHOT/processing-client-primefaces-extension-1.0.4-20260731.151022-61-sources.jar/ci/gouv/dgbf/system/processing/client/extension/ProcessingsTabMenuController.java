package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu.TabBuilder;
import ci.gouv.dgbf.system.processing.server.api.ProcessingDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingFilter;
import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.BiConsumer;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le menu onglet des {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingsTabMenuController extends AbstractController {

  @Getter
  TabMenu menu;

  @Getter
  @Setter
  Object listPageTabMenuType;

  @Getter
  @Setter
  String listPageTabMenuOutcome;

  @Getter
  @Setter
  Object dashboardPageTabMenuType;

  @Getter
  @Setter
  String dashboardPageTabMenuOutcome;

  @Inject
  ProcessingIconManager iconManager;

  @Getter
  @Setter
  String requestParameterStatusName;

  @Getter
  @Setter
  String requestParameterLateName;

  @Setter
  @Getter
  BiConsumer<TabType, TabBuilder> tabBuilderConsumer;

  /**
   * Cette méthode permet d'instantier.
   */
  public ProcessingsTabMenuController() {
    requestParameterStatusName = ProcessingFilter.JSON_STATUS_CODE;
    requestParameterLateName = ProcessingFilter.JSON_IS_LATE;
    menu = new TabMenu();
    menu.setMenuItemStyleClassPrefix("processing");
    listPageTabMenuType = LIST;
    dashboardPageTabMenuType = DASHBOARD;
  }

  void addTab(ProcessingStatus status, String menuItemIcon, String count) {
    addTab(status.getName(), menuItemIcon, status.getCode(), null, status.name().toLowerCase(),
        count, TabType.valueOf(status.name()));
  }

  void addTab(String menuItemValue, String menuItemIcon, String requestParameterStatus,
      Boolean requestParameterLate, String menuItemStyleClassSuffix, String count,
      TabType tabType) {
    TabBuilder tabBuilder = menu.tabBuilder().menuItemValue(menuItemValue)
        .menuItemIcon(menuItemIcon).type(tabType.getOutcomeIdentifier())
        .addMenuItemParameter(requestParameterStatusName, requestParameterStatus)
        .addMenuItemParameter(requestParameterLateName, requestParameterLate)
        .menuItemStyleClassSuffix(menuItemStyleClassSuffix).count(count);
    Core.acceptConsumer(tabBuilderConsumer, tabType, tabBuilder);
    tabBuilder.build();
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    menu.getOutcomesMap().put(listPageTabMenuType, listPageTabMenuOutcome);
    menu.getOutcomesMap().put(dashboardPageTabMenuType, dashboardPageTabMenuOutcome);

    addTab("Situation", iconManager.getSituation(), null, null, null, null, TabType.DASHBOARD);
    addTab("En retard", iconManager.getLate(), null, true, null, null, TabType.LATE);
    
    addTab(ProcessingStatus.STOPPED, iconManager.getStopped(), "0");
    addTab(ProcessingStatus.CANCELLED, iconManager.getCanceled(), "0");
    addTab(ProcessingStatus.CREATED, iconManager.getCreated(), "0");
    addTab(ProcessingStatus.STARTED, iconManager.getStarted(), "0");
    addTab(ProcessingStatus.TERMINATED, iconManager.getTerminated(), "0");

    addTab("Tous", iconManager.getAll(), null, null, null, null, TabType.ALL);
    menu.initialize();
  }

  /**
   * Cette énumération représente les types d'onglets.
   *
   * @author Christian
   *
   */
  @AllArgsConstructor
  @Getter
  public enum TabType {
    /**
     * Tableau de bord.
     */
    DASHBOARD(ProcessingsTabMenuController.DASHBOARD),
    /**
     * En retard.
     */
    LATE(ProcessingsTabMenuController.LIST),
    /**
     * Arrêté.
     */
    STOPPED(ProcessingsTabMenuController.LIST),
    /**
     * Annulé.
     */
    CANCELLED(ProcessingsTabMenuController.LIST),
    /**
     * Créé.
     */
    CREATED(ProcessingsTabMenuController.LIST),
    /**
     * Démarré.
     */
    STARTED(ProcessingsTabMenuController.LIST),
    /**
     * Terminé.
     */
    TERMINATED(ProcessingsTabMenuController.LIST),
    /**
     * Tout.
     */
    ALL(ProcessingsTabMenuController.LIST);

    private String outcomeIdentifier;
  }

  private static final String LIST = "liste";
  private static final String DASHBOARD = "dashboard";
}
