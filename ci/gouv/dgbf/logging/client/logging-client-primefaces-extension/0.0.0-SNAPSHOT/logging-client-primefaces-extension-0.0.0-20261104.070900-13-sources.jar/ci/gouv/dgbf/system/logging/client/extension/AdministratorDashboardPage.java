package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page du tableau de bord administrateur.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class AdministratorDashboardPage extends AbstractPage {

  @Inject
  @Getter
  DashboardController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Tableau de bord Administrateur";
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "administratorDashboardPage";
}

