package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.Form;
import ci.gouv.dgbf.extension.primefaces.IdentifiableActionController;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Confirm;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.DataTable.RecordComponentController;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import ci.gouv.dgbf.extension.primefaces.component.MenuButton;
import ci.gouv.dgbf.extension.primefaces.component.MenuItem;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur de liste.
 *
 * @author Christian
 *
 */
@Dependent
public class ListController extends AbstractController {

  @Getter
  @Setter
  Object client;

  @Getter
  @Setter
  Class<?> entityClass;

  @Getter
  @Setter
  String entityName;

  @Getter
  @Setter
  String entityPluralName;

  @Getter
  @Setter
  String rootFolderName;

  @Getter
  @Setter
  String entityFolderName;

  Class<?> getManyResponseDtoClass;

  @Getter
  @Setter
  Form form;

  /* Creation */

  @Getter
  @Setter
  CreateUserInterface createUserInterface;

  @Inject
  @Getter
  CreateController createController;

  @Getter
  @Setter
  Button showCreateDialogButton;

  @Getter
  @Setter
  Button createButton;

  @Getter
  @Setter
  Dialog createDialog;

  /* Read */

  @Inject
  @Getter
  ReadController readController;

  @Getter
  @Setter
  DataTable dataTable;

  @Getter
  @Setter
  Button gotoReadPageButton;

  @Getter
  @Setter
  DataTable.RecordComponentController gotoReadPageButtonController;

  /* Update */

  @Inject
  @Getter
  UpdateController updateController;

  @Getter
  @Setter
  Dialog updateDialog;

  @Getter
  @Setter
  Button showUpdateDialogButton;

  @Getter
  @Setter
  DataTable.RecordComponentController showUpdateDialogButtonController;

  /* Delete */

  @Inject
  @Getter
  DeleteController deleteController;

  @Getter
  @Setter
  Button deleteButton;

  @Getter
  @Setter
  DataTable.RecordComponentController deleteButtonController;

  /* Filter */

  @Getter
  @Setter
  AbstractFilterController<?> filterController;

  /* Managers */

  @Inject
  ScriptManager scriptManager;

  @Inject
  ComponentManager componentManager;

  /* Notification */

  @Inject
  MessageManager messageManager;

  @Getter
  @Setter
  String notificationChannel;


  Dialog currentShowingDialog;

  @Getter
  @Setter
  String moreContentFilePath;

  @Getter
  @Setter
  String dataTableContentFileName;

  @Getter
  @Setter
  MenuButton recordMenuButton;

  /**
   * Cette méthode est le constructeur par défaut.
   */
  public ListController() {
    name = "Liste";

    form = new Form();
    form.setIdentifier("form");

    dataTable = new DataTable();
    dataTable.setIdentifier("dataTable");
    dataTable.setForm(form);
    dataTable.setStyleClass(dataTable.getStyleClass() + " crud-list");
    dataTable.getActionsOutputPanel().setForm(form);
    dataTable.getFilterDialog().setStyleClass("crud-list-dialog crud-list-dialog-filter");

    dataTable.getActionColumn().setRendered(true);

    gotoReadPageButton = new Button();
    gotoReadPageButton.setTitle("Consulter");
    gotoReadPageButton.setIcon("pi pi-eye");
    gotoReadPageButton.setRendered(false);
    gotoReadPageButtonController = new RecordComponentController();

    showCreateDialogButton = new Button();
    showCreateDialogButton.setValue("Ajouter");
    showCreateDialogButton.setIcon("pi pi-plus");
    createDialog = new Dialog();
    createDialog.setIdentifier("createDialog");
    createDialog.setWidgetVar("createDialogWidgetVar");
    createDialog.setStyleClass("crud-list-dialog crud-list-dialog-create");
    createButton = new Button();
    createButton.setValue("Ajouter");
    createButton.setIcon("pi pi-plus");
    createButton.addStylesClasses("crud-list-button-create");

    showUpdateDialogButton = new Button();
    showUpdateDialogButton.setTitle("Mettre à jour");
    showUpdateDialogButton.setIcon("pi pi-pencil");
    showUpdateDialogButtonController = new RecordComponentController();
    updateDialog = new Dialog();
    updateDialog.setIdentifier("updateDialog");
    updateDialog.setWidgetVar("updateDialogWidgetVar");
    updateDialog.setHeader("Mise à jour");
    updateDialog.setStyleClass("crud-list-dialog crud-list-dialog-update");

    deleteButton = new Button();
    deleteButton.setTitle("Supprimer");
    deleteButton.setIcon("pi pi-trash");
    deleteButtonController = new RecordComponentController();

    rootFolderName = "/private";

    moreContentFilePath = "/extension/empty.xhtml";
  }

  /**
   * Cette méthode permet de calculer les identifiants complets à aprtir de l'identifiant d'un
   * conteneur.
   *
   * @param identifier identifiant du conteneur.
   */
  public void computeCompleteIdentifiersFromContainer(String identifier) {
    dataTable.setCompleteIdentifier(
        identifier + ":" + dataTable.getForm().getIdentifier() + ":" + dataTable.getIdentifier());
    createDialog.setCompleteIdentifier(identifier + ":" + createDialog.getIdentifier());
    updateDialog.setCompleteIdentifier(identifier + ":" + updateDialog.getIdentifier());
  }

  /**
   * Cette méthode permet d'iitialiser.
   *
   */
  public void initialize() {
    /*
     * Les notifications seront désactivées car nous sommes dans le même conteneur.
     */

    dataTable.setScriptManager(scriptManager);
    dataTable.setComponentManager(componentManager);

    entityName =
        Optional.ofNullable(entityName).orElse(Core.getHumanReadableClassName(entityClass));
    entityPluralName = Optional.ofNullable(entityPluralName)
        .orElse(Core.getHumanReadableClassPluralName(entityClass));
    entityFolderName = buildEntityFolderName();

    /* Lecture */

    readController.setName(readController.getName() + " " + entityName);
    readController.setClient(client);
    Core.runIfNull(readController.getFilter(), () -> readController.setFilter(filterController));
    readController.initializeModel(entityClass, getManyResponseDtoClass);
    dataTable.setContentFilePath(buildPathFromFolder("%s/%s/" + computeDataTableContentFileName()));
    dataTable.setValue(readController.getModel());
    dataTable.addStyleClass(entityFolderName + "-datatable");

    buildDataTableTitle();

    /* Création */

    createController.setName(createController.getName() + " " + entityName);
    createController.getNotificationPublishController().setEnabled(false);
    createController.addResponseConsumer(response -> {
      createController.setEntity(null);
      scriptManager.hide(createDialog);
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
    createController.setEntityClass(entityClass);

    prepareCreate();

    /* Mise à jour */

    /*
     * Le nom du contrôleur est mis à nul pour forcer son recalcul dans la configuration de
     * l'action.
     */
    updateController.setName(null);
    configureAction(updateDialog, "saveForm", updateController);

    /* Suppression */

    deleteController.setName(deleteController.getName() + " " + entityName);
    deleteController.setClient(client);
    deleteController.getNotificationPublishController().setEnabled(false);
    deleteController.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });

    /* Filtre */

    dataTable.getFilterDialog().setContentFilePath(buildPathFromFolder(computeFilterFormPath()));
    buildDataTableFilterDialogHeader();

    dataTable.getActionColumn().computeWithForButtonsWithIconOnly(countVisibleActionsButtons());
  }

  String computeDataTableContentFileName() {
    return Optional.ofNullable(dataTableContentFileName).orElse("columns.xhtml");
  }

  void prepareCreate() {
    if (CreateUserInterface.NONE.equals(createUserInterface)) {
      Core.runIfStringBlank(createButton.confirm().getMessage(),
          () -> createButton.confirm().setMessageAreYouSureTo(createController.getName()));
      createButton.setActionFunction(argument -> {
        prepareCreateController();
        createController.execute();
        return null;
      });
      showCreateDialogButton.setRendered(false);
    } else {
      createDialog.setContentFilePath(buildPathFromFolder("%s/%s/component/saveForm.xhtml"));
      createDialog.setHeader(createController.getName());
      createButton.setRendered(false);
    }
  }

  String computeFilterFormPath() {
    return dataTable.getFilterButton().isRendered() ? "%s/%s/component/filterForm.xhtml"
        : "/extension/empty.xhtml";
  }

  int countVisibleActionsButtons() {
    int count = 0;
    if (gotoReadPageButton.isRendered()) {
      count++;
    }
    if (showUpdateDialogButton.isRendered()) {
      count++;
    }
    if (deleteButton.isRendered()) {
      count++;
    }
    return count;
  }

  void buildDataTableTitle() {
    if (Core.isStringBlank(dataTable.getTitle())) {
      dataTable.setTitle("Tableau de " + entityPluralName);
    }
  }

  void buildDataTableFilterDialogHeader() {
    if (Core.isStringBlank(dataTable.getFilterDialog().getHeader())) {
      String header = filterController == null ? null : filterController.getName();
      dataTable.getFilterDialog()
          .setHeader(Core.getOrDefaultIfBlank(header, "Filtre " + entityName));
    }
  }

  String buildEntityFolderName() {
    return Optional.ofNullable(entityClass).map(clazz -> {
      String name = clazz.getSimpleName().toLowerCase();
      return buildEntityFolderName(name);
    }).orElse(null);
  }

  String buildEntityFolderName(String name) {
    if (name.endsWith("dto")) {
      name = name.substring(0, name.length() - 3);
    }
    return name;
  }

  String buildPathFromFolder(String format) {
    return Optional.ofNullable(Core.getOrNullifyIfStringBlank(format))
        .map(value -> String.format(format, rootFolderName, entityFolderName)).orElse(null);
  }

  /**
   * Cette méthode permet de préparer la création.
   */
  public void showCreateDialog() {
    validateEntityClass();
    prepareCreateController();
    componentManager.update(createDialog);
    scriptManager.show(createDialog);
    currentShowingDialog = createDialog;
  }

  void prepareCreateController() {
    createController.instantiateEntity();
  }

  /**
   * Cette méthode permet de préparer la mise à jour.
   *
   * @param identifier identifiant
   */
  public void showUpdateDialog(String identifier) {
    showUpdateDialog(identifier, updateDialog, updateController);
  }

  /**
   * Cette méthode permet de préparer la mise à jour.
   *
   * @param identifier identifiant
   */
  public void showUpdateDialog(String identifier, Dialog dialog, UpdateController controller) {
    validateEntityClass();
    controller.setEntity(new ActionExecutor<Object>(this,
        String.format("Obtention %s par identifiant %s", entityClass.getSimpleName(), identifier),
        () -> getByIdentifier(identifier, controller.projection)).execute());
    if (controller.getEntity() == null) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE, "{0} identifié par {1} introuvable",
          new Object[] {entityClass.getSimpleName(), identifier});
    } else {
      controller.consumeEntity();
      componentManager.update(dialog);
      scriptManager.show(dialog);
      currentShowingDialog = dialog;
    }
  }

  void validateEntityClass() {
    if (entityClass == null) {
      throw new IllegalStateException("La classe de l'entité ne doit pas être nulle");
    }
  }

  Object getByIdentifier(String identifier, ProjectionDto projection) {
    if (client instanceof GetByIdentifier<?> c) {
      return c.getByIdentifier(identifier, projection, userIdentifier, null);
    }
    throw new IllegalStateException("L'obtention par identifiant n'a pas été implémentée");
  }

  public boolean isReadControllerHasProjectionName(String name) {
    return readController.hasProjectionName(name);
  }

  /**
   * Cette méthode permet de configurer un bouton d'action sur un enregistrement.
   *
   * @param dialog dialogue
   * @param formFileName nom du fichier
   * @param controller contrôleur de l'action
   */
  public void configureAction(Dialog dialog, String formFileName, UpdateController controller) {
    Core.runIfStringBlank(controller.getName(),
        () -> controller.setName(controller.getName() + " " + entityName));
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      scriptManager.hide(dialog);
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
    Core.runIfNull(controller.getProjection(),
        () -> controller.setProjection(readController.getProjectionDto()));
    dialog.setContentFilePath(buildPathFromFolder("%s/%s/component/" + formFileName + ".xhtml"));
    Core.runIfStringBlank(dialog.getHeader(), () -> dialog.setHeader(controller.getName()));
  }

  /**
   * Cette méthode permet de configurer un bouton d'action.
   *
   * @param controller contrôleur de l'action
   */
  public void configureAction(IdentifiableActionController controller) {
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
  }

  /**
   * Cette méthode permet de configurer un bouton d'action.
   *
   * @param controller contrôleur de l'action
   */
  public void configureAction(UpdateController controller) {
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
  }

  /**
   * Cette méthode permet de filter.
   */
  public void filter() {
    if (filterController != null) {
      filterController.filter();
    }
    scriptManager.hide(dataTable.getFilterDialog());
    componentManager.update(dataTable);
  }

  /**
   * Cette méthode permet d'obtenir l'entité en création ou en modification.
   *
   * @return entité en création ou en modification.
   */
  public Object getCreateControllerOrUpdateControllerEntity() {
    if (currentShowingDialog == createDialog) {
      return createController.getEntity();
    }
    if (currentShowingDialog == updateDialog) {
      return updateController.getEntity();
    }
    return null;
  }

  /**
   * Cette méthode permet d'obtenir l'entité en création ou en modification.
   *
   * @param <T> type
   * @param clazz classe
   * @return entité en création ou en modification.
   */
  @SuppressWarnings("unchecked")
  public <T> T getCreateControllerOrUpdateControllerEntityAs(Class<T> clazz) {
    return (T) getCreateControllerOrUpdateControllerEntity();
  }

  public boolean isCurrentShowingDialogCreate() {
    return isCurrentShowingDialog(createDialog);
  }

  public boolean isCurrentShowingDialogUpdate() {
    return isCurrentShowingDialog(updateDialog);
  }

  boolean isCurrentShowingDialog(Dialog dialog) {
    return currentShowingDialog == dialog;
  }

  public boolean getGotoReadPageButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, gotoReadPageButton,
        gotoReadPageButtonController);
  }

  public boolean getShowUpdateDialogButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, showUpdateDialogButton,
        showUpdateDialogButtonController);
  }

  public boolean getDeleteButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, deleteButton, deleteButtonController);
  }

  /**
   * Cette méthode permet d'obtenir {@link MenuButton} d'enregistrement.
   *
   * @return {@link MenuButton} d'enregistrement
   */
  public MenuButton recordMenuButton() {
    if (recordMenuButton == null) {
      recordMenuButton = new MenuButton();
      recordMenuButton.setIcon("pi pi-ellipsis-v");
    }
    return recordMenuButton;
  }

  /**
   * Cette méthode permet de construire {@ink #recordMenuButton}.
   */
  public void buildRecordMenuButton() {
    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().outcome(gotoReadPageButton.getOutcome())
                .value(gotoReadPageButton.getTitle()).icon(gotoReadPageButton.getIcon()))
        .build();

    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().actionFunction(showUpdateDialogFunction())
                .value(showUpdateDialogButton.getTitle()).icon(showUpdateDialogButton.getIcon()))
        .build();

    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().actionFunction(deleteByIdentifierFunction())
                .value(deleteButton.getTitle()).icon(deleteButton.getIcon())
                .confirmBuilder(Confirm.builder().action(deleteButton.getTitle())))
        .build();
  }

  Function<Object, String> showUpdateDialogFunction() {
    return identifier -> {
      showUpdateDialog((String) identifier);
      return null;
    };
  }

  Function<Object, String> deleteByIdentifierFunction() {
    return identifier -> {
      deleteController.deleteByIdentifier((String) identifier);
      return null;
    };
  }

  /**
   * Cette méthode permet la lecture seule.
   */
  public void useAsReadOnly() {
    showCreateDialogButton.setRendered(false);
    showUpdateDialogButton.setRendered(false);
    deleteButton.setRendered(false);
    dataTable.getFilterButton().setRendered(false);
  }

  /**
   * Cette énumération représente les interfaces utilisateurs de création.
   *
   * @author Christian
   *
   */
  public enum CreateUserInterface {
    DIALOG, PAGE, NONE
  }
}
