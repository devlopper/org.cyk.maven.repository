package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollComponentDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayrollComponentFilter extends AbstractIdentifiableFilter {

  /**
   * Est un poste de gain.
   */
  Boolean isEarning;
  
  /**
    * Identifiant de la catégorie de poste de paie.
    */
  String categoryIdentifier;
  
  /**
   * Identifiant de la nature de poste de paie.
   */
  String natureIdentifier;

  /**
   * Identifiant du modèle pour avoir les postes rattachés.
   */
  private String boundPayslipTemplateIdentifier;

  /**
   * Identifiant du modèle pour avoir les postes non encore rattachés.
   */
  private String unboundPayslipTemplateIdentifier;


  /**
   * Cette méthode permet d'instantier.
   *
   * @param dto {@link FilterDto}
   */
  public PayrollComponentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier.
   *
   */
  public PayrollComponentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isEarning = getIsEarning(filter);
    categoryIdentifier = getCategoryIdentifier(filter);
    natureIdentifier = getNatureIdentifier(filter);
    boundPayslipTemplateIdentifier = getBoundPayslipTemplateIdentifier(filter);
    unboundPayslipTemplateIdentifier = getUnboundPayslipTemplateIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsEarning(filter, isEarning);
    setCategoryIdentifier(filter, categoryIdentifier);
    setNatureIdentifier(filter, natureIdentifier);
    setBoundPayslipTemplateIdentifier(filter, boundPayslipTemplateIdentifier);
    setUnboundPayslipTemplateIdentifier(filter, unboundPayslipTemplateIdentifier);
  }
  
  /**
   * Cette méthode permet d'assigner est gain.
   *
   * @param filter {@link FilterDto}
   * @param isEarning est gain
   */
  public static void setIsEarning(FilterDto filter, Boolean isEarning) {
    set(filter, JSON_IS_EARNING, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isEarning));
  }

  /**
   * Cette méthode permet d'obtenir est gain.
   *
   * @param filter {@link FilterDto}
   * @return vrai si est gain sinon faux
   */
  public static Boolean getIsEarning(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_EARNING));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la catégorie de poste de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setCategoryIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_CATEGORY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la catégorie de poste de paie.
   *
   * @param filter filtre
   * @return identifiant de la catégorie de poste de paie
   */
  public static String getCategoryIdentifier(FilterDto filter) {
    return get(filter, d ->
            d.getFieldValueAsStringByName(JSON_CATEGORY_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant de la nature de poste de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setNatureIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_NATURE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la nature de poste de paie.
   *
   * @param filter filtre
   * @return identifiant de la nature de poste de paie
   */
  public static String getNatureIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_NATURE_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant du modèle de bulletin de paie 
   * pour les postes de paie rattachés.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setBoundPayslipTemplateIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BOUND_PAYSLIP_TEMPLATE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du modèle de bulletin de paie 
   * pour les postes de paie rattachés.
   *
   * @param filter filtre
   * @return identifiant du modèle de bulletin de paie pour les postes de paie rattachés
   */
  public static String getBoundPayslipTemplateIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_BOUND_PAYSLIP_TEMPLATE_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant du modèle de bulletin de paie pour les postes 
   * de paie non encore rattachés.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setUnboundPayslipTemplateIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_UNBOUND_PAYSLIP_TEMPLATE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du modèle de bulletin de paie pour les postes 
   * de paie non encore rattachés.
   *
   * @param filter filtre
   * @return identifiant du modèle de bulletin de paie pour les postes de paie non encore rattachés
   */
  public static String getUnboundPayslipTemplateIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_UNBOUND_PAYSLIP_TEMPLATE_IDENTIFIER));
  }

  /**
   * Identifiant json {@link #isEarning}.
   */
  public static final String JSON_IS_EARNING = PayrollComponentDto.JSON_IS_EARNING;

  /**
   * Identifiant json champ {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = 
      PayrollComponentCategoryDto.JSON_IDENTIFIER;

  /**
   * Identifiant json champ {@link #natureIdentifier}.
   */
  public static final String JSON_NATURE_IDENTIFIER = 
      PayrollComponentNatureDto.JSON_IDENTIFIER;

  /**
   * Identifiant json champ {@link #boundPayslipTemplateIdentifier}.
   */
  public static final String JSON_BOUND_PAYSLIP_TEMPLATE_IDENTIFIER = 
      "identifiantModeleBulletinRattache";

  /**
   * Identifiant json champ {@link #unboundPayslipTemplateIdentifier}.
   */
  public static final String JSON_UNBOUND_PAYSLIP_TEMPLATE_IDENTIFIER = 
      "identifiantModeleBulletinNonRattache";
}
