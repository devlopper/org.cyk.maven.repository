package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessResponseDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingCreateRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingGetManyResponseDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingProcessRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingRegisterHeartbeatRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingUpdateCompletedWorkVolumeRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ProcessingService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ProcessingClient extends AbstractClient<ProcessingService>
    implements GetByIdentifier<ProcessingDto>, GetMany<ProcessingGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetChart<GetChartResponseDto> {

  @Override
  public ProcessingClient service(ProcessingService service) {
    return (ProcessingClient) super.service(service);
  }

  /**
   * {@link ProcessingService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcessingCreateRequestDto request) {
    return new CreateExecutor(ProcessingService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProcessingService#create}.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String auditWho, String auditSession) {
    ProcessingCreateRequestDto request = new ProcessingCreateRequestDto();
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link ProcessingService#start}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto start(ProcessingProcessRequestDto request) {
    return new ProcessExecutor(ProcessingService.START_IDENTIFIER)
        .execute(() -> service().start(request));
  }

  /**
   * {@link ProcessingService#start}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return message
   */
  public ProcessResponseDto start(String identifier, String auditWho, String auditSession) {
    ProcessingProcessRequestDto request = new ProcessingProcessRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return start(request);
  }

  /**
   * {@link ProcessingService#stop}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto stop(ProcessingProcessRequestDto request) {
    return new ProcessExecutor(ProcessingService.STOP_IDENTIFIER)
        .execute(() -> service().stop(request));
  }

  /**
   * {@link ProcessingService#stop}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return message
   */
  public ProcessResponseDto stop(String identifier, String auditWho, String auditSession) {
    ProcessingProcessRequestDto request = new ProcessingProcessRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return stop(request);
  }

  /**
   * {@link ProcessingService#cancel}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto cancel(ProcessingProcessRequestDto request) {
    return new ProcessExecutor(ProcessingService.CANCEL_IDENTIFIER)
        .execute(() -> service().cancel(request));
  }

  /**
   * {@link ProcessingService#cancel}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return message
   */
  public ProcessResponseDto cancel(String identifier, String auditWho, String auditSession) {
    ProcessingProcessRequestDto request = new ProcessingProcessRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return cancel(request);
  }

  /**
   * {@link ProcessingService#terminate}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto terminate(ProcessingProcessRequestDto request) {
    return new ProcessExecutor(ProcessingService.TERMINATE_IDENTIFIER)
        .execute(() -> service().terminate(request));
  }

  /**
   * {@link ProcessingService#terminate}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return message
   */
  public ProcessResponseDto terminate(String identifier, String auditWho, String auditSession) {
    ProcessingProcessRequestDto request = new ProcessingProcessRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return terminate(request);
  }

  /**
   * {@link ProcessingService#reset}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto reset(ProcessingProcessRequestDto request) {
    return new ProcessExecutor(ProcessingService.RESET_IDENTIFIER)
        .execute(() -> service().reset(request));
  }
  
  /**
   * {@link ProcessingService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessingGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcessingGetManyResponseDto>(ProcessingGetManyResponseDto.class,
        ProcessingService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcessingService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessingGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcessingService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessingDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ProcessingDto>(ProcessingDto.class,
        ProcessingService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProcessingService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessingDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ProcessingService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessingDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ProcessingDto>(ProcessingDto.class,
        ProcessingService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProcessingService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessingDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ProcessingService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcessingUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcessingService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcessingService#updateCompletedWorkVolume}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateCompletedWorkVolume(
      ProcessingUpdateCompletedWorkVolumeRequestDto request) {
    return new IdentifiableExecutor(ProcessingService.UPDATE_COMPLETED_WORK_VOLUME_IDENTIFIER)
        .execute(() -> service().updateCompletedWorkVolume(request));
  }
  
  /**
   * {@link ProcessingService#registerHeartbeat}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto registerHeartbeat(
      ProcessingRegisterHeartbeatRequestDto request) {
    return new IdentifiableExecutor(ProcessingService.REGISTER_HEARTBEAT_IDENTIFIER)
        .execute(() -> service().registerHeartbeat(request));
  }

  /**
   * {@link ProcessingService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProcessingService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ProcessingService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ProcessingService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        ProcessingService.GET_CHART_IDENTIFIER).execute(() -> service().getChart(request));
  }

  /**
   * {@link ProcessingService#getChart}.
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditWho, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getChart(request);
  }

  /**
   * Cette classe représente un exécuteur de traitement .
   *
   * @author Christian
   *
   */
  public class ProcessExecutor extends Executor<ProcessResponseDto> {

    /**
     * Cette méthode permet d'instancier.
     *
     * @param identifier identifiant
     */
    public ProcessExecutor(String identifier) {
      super(ProcessResponseDto.class, identifier);
    }

  }

}
