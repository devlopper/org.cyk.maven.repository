package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entité traitante.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcessingEntityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Nature de l'entité traitante : Centrale ou Régionale (RG_REP_SOU_06).
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json de identifiant de {@link ProcessingEntityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEntiteTraitante";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ProcessingEntityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "entiteTraitanteChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "entité traitante";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "entités traitantes";
}
