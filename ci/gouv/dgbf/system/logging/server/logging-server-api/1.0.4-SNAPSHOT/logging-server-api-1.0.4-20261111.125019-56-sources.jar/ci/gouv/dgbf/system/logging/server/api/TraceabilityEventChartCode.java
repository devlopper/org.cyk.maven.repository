package ci.gouv.dgbf.system.logging.server.api;

/**
 * Codes des graphiques des événements de traçabilité.
 *
 * @author Christian
 *
 */
public interface TraceabilityEventChartCode {

  /**
   * Répartition par catégorie (Log, Opération d'enregistrement).
   */
  String CATEGORY = "CATEGORY";

  /**
   * Répartition par type d'action métier.
   */
  String ACTION_TYPE = "ACTION_TYPE";

  /**
   * Répartition par niveau de log.
   */
  String LEVEL = "LEVEL";

  /**
   * Volume temporel par jour.
   */
  String VOLUME_BY_DAY = "VOLUME_BY_DAY";

  /**
   * Top des processus émetteurs.
   */
  String PROCESS = "PROCESS";

  /**
   * Répartition par fonctionnalité auditée.
   */
  String FUNCTIONALITY = "FUNCTIONALITY";

  /**
   * Répartition par utilisateur.
   */
  String USER = "USER";

  /**
   * Synthèse des indicateurs clés (KPIs).
   */
  String KPIS = "KPIS";

  /**
   * Ensemble des graphiques du tableau de bord.
   */
  String DASHBOARD = "DASHBOARD";

  /**
   * Tableau de bord d'activité d'un utilisateur (« Mon activité »).
   */
  String USER_ACTIVITY = "USER_ACTIVITY";

  /**
   * Date de dernière activité de l'utilisateur.
   */
  String LAST_ACTIVITY = "LAST_ACTIVITY";

  /**
   * Objets les plus consultés ou traités (Top Source / Enregistrement).
   */
  String TOP_RECORDS = "TOP_RECORDS";

  /**
   * Activité par session.
   */
  String SESSIONS = "SESSIONS";

  /**
   * Erreurs récentes de l'utilisateur.
   */
  String RECENT_ERRORS = "RECENT_ERRORS";

  /**
   * Recherche d'utilisateurs avec comptage d'activité (vue Administrateur).
   */
  String USER_SEARCH = "USER_SEARCH";
}

