package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AbstractIdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractIdentityFilter extends AbstractIdentifiableFilter {

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  String emailAddress;

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  String registrationNumber;

  /**
   * Identifiant {@link RegistrationNumberGroupDto}.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER)
  String registrationNumberGroupIdentifier;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  String lastNames;

  /**
   * Identifiant {@link GenderDto}.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  String genderIdentifier;

  /**
   * Identifiant unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Le matricule appartient au groupe de la fonction publique.
   */
  @JsonbProperty(value = JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION)
  private Boolean isRegistrationNumberGroupPublicFunction;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    emailAddress = getEmailAddress(filter);
    registrationNumber = getRegistrationNumber(filter);
    registrationNumberGroupIdentifier = getRegistrationNumberGroupIdentifier(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    isRegistrationNumberGroupPublicFunction = getIsRegistrationNumberGroupPublicFunction(filter);
    firstName = getFirstName(filter);
    lastNames = getLastNames(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setEmailAddress(filter, emailAddress);
    setRegistrationNumber(filter, registrationNumber);
    setRegistrationNumberGroupIdentifier(filter, registrationNumberGroupIdentifier);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setIsRegistrationNumberGroupPublicFunction(filter, isRegistrationNumberGroupPublicFunction);
    setFirstName(filter, firstName);
    setLastNames(filter, lastNames);
  }

  /**
   * Cette méthode permet d'assigner {@link #emailAddress}.
   *
   * @param filter filtre
   * @param emailAddress {@link #emailAddress}
   */
  public static void setEmailAddress(FilterDto filter, String emailAddress) {
    set(filter, JSON_EMAIL_ADDRESS, f -> f.getValueAsString(),
        f -> f.setValueAsString(emailAddress));
  }

  /**
   * Cette méthode permet d'obtenir {@link #emailAddress}.
   *
   * @param filter filtre
   * @return {@link #emailAddress}
   */
  public static String getEmailAddress(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EMAIL_ADDRESS));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumberGroupIdentifier}.
   *
   * @param filter filtre
   * @param registrationNumberGroupIdentifier {@link #registrationNumberGroupIdentifier}
   */
  public static void setRegistrationNumberGroupIdentifier(FilterDto filter,
      String registrationNumberGroupIdentifier) {
    set(filter, JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(registrationNumberGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumberGroupIdentifier}.
   *
   * @param filter filtre
   * @return {@link #registrationNumberGroupIdentifier}
   */
  public static String getRegistrationNumberGroupIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner {@link #registrationNumber}.
   *
   * @param filter filtre
   * @param registrationNumber {@link #registrationNumber}
   */
  public static void setRegistrationNumber(FilterDto filter, String registrationNumber) {
    set(filter, JSON_REGISTRATION_NUMBER, f -> f.getValueAsString(),
        f -> f.setValueAsString(registrationNumber));
  }

  /**
   * Cette méthode permet d'obtenir {@link #registrationNumber}.
   *
   * @param filter filtre
   * @return {@link #registrationNumber}
   */
  public static String getRegistrationNumber(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REGISTRATION_NUMBER));
  }

  /**
   * Cette méthode permet d'assigner {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @param administrativeUnitIdentifier {@link #administrativeUnitIdentifier}
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter,
      String administrativeUnitIdentifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(administrativeUnitIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #administrativeUnitIdentifier}.
   *
   * @param filter filtre
   * @return {@link #administrativeUnitIdentifier}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner {@link #isRegistrationNumberGroupPublicFunction}.
   *
   * @param filter filtre
   * @param isRegistrationNumberGroupPublicFunction {@link #isRegistrationNumberGroupPublicFunction}
   */
  public static void setIsRegistrationNumberGroupPublicFunction(FilterDto filter,
      Boolean isRegistrationNumberGroupPublicFunction) {
    set(filter, JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION, f -> f.getValueAsString(),
        f -> f.setValueAsBoolean(isRegistrationNumberGroupPublicFunction));
  }

  /**
   * Cette méthode permet d'obtenir {@link #isRegistrationNumberGroupPublicFunction}.
   *
   * @param filter filtre
   * @return {@link #isRegistrationNumberGroupPublicFunction}
   */
  public static Boolean getIsRegistrationNumberGroupPublicFunction(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsBooleanByName(JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION));
  }

  /**
   * Cette méthode permet d'assigner {@link #firstName}.
   *
   * @param filter filtre
   * @param firstName {@link #firstName}
   */
  public static void setFirstName(FilterDto filter, String firstName) {
    set(filter, JSON_FIRST_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(firstName));
  }

  /**
   * Cette méthode permet d'obtenir {@link #firstName}.
   *
   * @param filter filtre
   * @return {@link #firstName}
   */
  public static String getFirstName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FIRST_NAME));
  }

  /**
   * Cette méthode permet d'assigner {@link #lastNames}.
   *
   * @param filter filtre
   * @param lastNames {@link #lastNames}
   */
  public static void setLastNames(FilterDto filter, String lastNames) {
    set(filter, JSON_LAST_NAMES, f -> f.getValueAsString(), f -> f.setValueAsString(lastNames));
  }

  /**
   * Cette méthode permet d'obtenir {@link #lastNames}.
   *
   * @param filter filtre
   * @return {@link #lastNames}
   */
  public static String getLastNames(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LAST_NAMES));
  }

  /**
   * Identifiant JSON {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = HasEmailAddressDto.JSON_EMAIL_ADDRESS;

  /**
   * Identifiant JSON {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER =
      AbstractIdentityDto.JSON_REGISTRATION_NUMBER;

  /**
   * Identifiant JSON {@link #registrationNumberGroupIdentifier}.
   */
  public static final String JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER =
      AbstractIdentityDto.JSON_REGISTRATION_NUMBER_GROUP_IDENTIFIER;

  /**
   * Identifiant JSON {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = AbstractIdentityDto.JSON_FIRST_NAME;

  /**
   * Identifiant JSON {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = AbstractIdentityDto.JSON_LAST_NAMES;

  /**
   * Identifiant JSON {@link #genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = AbstractIdentityDto.JSON_GENDER_IDENTIFIER;

  /**
   * Identifiant JSON {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AbstractIdentityDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant JSON {@link #isRegistrationNumberGroupPublicFunction}.
   */
  public static final String JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION =
      AbstractIdentityDto.JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION;
}

