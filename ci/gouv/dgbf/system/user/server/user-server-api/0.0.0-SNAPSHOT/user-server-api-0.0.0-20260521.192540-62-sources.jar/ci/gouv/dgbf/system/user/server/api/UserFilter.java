package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class UserFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du role pour filtrer les utilisateurs NON assignés.
   * Si renseigné, retourne uniquement les utilisateurs que cet role n'a pas.
   */
  private String unassignedRoleIdentifier;

  /**
   * Identifiant de role pour filtrer les utilisateurs assignés.
   * Si renseigné, retourne uniquement les utilisateurs que cet role possède.
   */
  private String assignedRoleIdentifier;


  /**
   * Identifiant {@link DomainDto}.
   */
  private String domainIdentifier;

  /**
   * Identifiant {@link DomainDto} du compte.
   */
  private String accountDomainIdentifier;
  
  /**
   * Nom.
   */
  private String name;

  /**
   * Chaîne de caractères pour filtrer les utilisateurs par nom.
   */
  private String nameContains;

  /**
   * Identifiant de l'application pour filtrer les utilisateurs.
   */
  private String applicationIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public UserFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public UserFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
    domainIdentifier = getDomainIdentifier(filter);
    unassignedRoleIdentifier = getUnassignedRoleIdentifier(filter);
    assignedRoleIdentifier = getAssignedRoleIdentifier(filter);
    nameContains = getNameContains(filter);
    applicationIdentifier = getApplicationIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
    setDomainIdentifier(filter, domainIdentifier);
    setUnassignedRoleIdentifier(filter, unassignedRoleIdentifier);
    setAssignedRoleIdentifier(filter, assignedRoleIdentifier);
    setNameContains(filter, nameContains);
    setApplicationIdentifier(filter, applicationIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link DomainDto}.
   *
   * @param filter filtre
   * @param domainIdentifier identifiant de {@link DomainDto}
   */
  public static void setDomainIdentifier(FilterDto filter, String domainIdentifier) {
    set(filter, JSON_DOMAIN_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(domainIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link DomainDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link DomainDto}
   */
  public static String getDomainIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_DOMAIN_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param name nom
   */
  public static void setName(FilterDto filter, String name) {
    set(filter, JSON_NAME, f -> f.getValueAsString(),
        f -> f.setValueAsString(name));
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur pour les rôles NON assignés.
   *
   * @param filter                   filtre
   * @param unassignedRoleIdentifier identifiant du role
   */
  public static void setUnassignedRoleIdentifier(FilterDto filter,
                                                 String unassignedRoleIdentifier) {
    set(filter, JSON_UNASSIGNED_ROLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(unassignedRoleIdentifier));
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant du role pour les utilisateurs non assignés.
   *
   * @param filter filtre
   * @return identifiant de role
   */
  public static String getUnassignedRoleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_UNASSIGNED_ROLE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du role pour les utilisateurs assignés.
   *
   * @param filter filtre
   * @param assignedRoleIdentifier identifiant du role
   */

  public static void setAssignedRoleIdentifier(FilterDto filter, String assignedRoleIdentifier) {
    set(filter, JSON_ASSIGNED_ROLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(assignedRoleIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du role pour les utilisateurs assignés.
   *
   * @param filter filtre
   * @return identifiant du role
   */
  public static String getAssignedRoleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ASSIGNED_ROLE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner la chaîne de caractères pour filtrer les utilisateurs par nom.
   *
   * @param filter filtre
   * @param nameLike chaîne de caractères
   */
  public static void setNameContains(FilterDto filter, String nameLike) {
    set(filter, JSON_NAME_CONTAINS, f -> f.getValueAsString(), f -> f.setValueAsString(nameLike));
  }

  /**
   * Cette méthode permet d'obtenir la chaîne de caractères pour filtrer les utilisateurs par nom.
   *
   * @param filter filtre
   * @return chaîne de caractères
   */
  public static String getNameContains(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME_CONTAINS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'application.
   *
   * @param filter filtre
   * @param applicationIdentifier identifiant de l'application
   */
  public static void setApplicationIdentifier(FilterDto filter, String applicationIdentifier) {
    set(filter, JSON_APPLICATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(applicationIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'application.
   *
   * @param filter filtre
   * @return identifiant de l'application
   */
  public static String getApplicationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_APPLICATION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = UserDto.JSON_DOMAIN_IDENTIFIER;

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;

  
  /**
   * Identifiant json champ {@link #unassignedRoleIdentifier}.
   */
  public static final String JSON_UNASSIGNED_ROLE_IDENTIFIER =
      UserDto.JSON_UNASSIGNED_ROLE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #assignedRoleIdentifier}.
   */
  public static final String JSON_ASSIGNED_ROLE_IDENTIFIER =
      UserDto.JSON_ASSIGNED_ROLE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #nameContains}.
   */
  public static final String JSON_NAME_CONTAINS = "nomContient";

  /**
   * Identifiant json champ {@link #applicationIdentifier}.
   */
  public static final String JSON_APPLICATION_IDENTIFIER = ApplicationDto.JSON_THIS_IDENTIFIER;

}
