package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressFilter;
import ci.gouv.dgbf.system.identity.server.api.shared.IdentityIdentifierFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link IdentityEmailAddressDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityEmailAddressFilterController
    extends AbstractFilterController<IdentityEmailAddressFilter> {

  /**
   * Cette méthode permet d'instantier.
   */
  public IdentityEmailAddressFilterController() {
    super(IdentityEmailAddressFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setIdentityIdentifier(getRequestParameter(IdentityIdentifierFilter.JSON_KEY));
    filter.setEmailAddress(getRequestParameter(EmailAddressFilter.JSON_KEY));
  }
}

