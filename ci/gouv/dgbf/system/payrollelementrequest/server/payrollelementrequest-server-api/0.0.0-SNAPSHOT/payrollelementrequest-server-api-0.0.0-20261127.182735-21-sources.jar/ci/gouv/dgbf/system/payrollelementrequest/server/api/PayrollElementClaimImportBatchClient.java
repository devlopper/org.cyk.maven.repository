package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchControlPeriodRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchDeletePeriodRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchDeletePeriodResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchForceRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchGenerateBatchRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchGenerationResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchPeriodSummariesRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchPeriodSummariesResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchSimulationRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchService.PayrollElementClaimImportBatchSimulationResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollElementClaimImportBatchService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollElementClaimImportBatchClient
    extends AbstractClient<PayrollElementClaimImportBatchService>
    implements GetMany<PayrollElementClaimImportBatchGetManyResponseDto> {

  @Override
  public PayrollElementClaimImportBatchClient service(
      PayrollElementClaimImportBatchService service) {
    return (PayrollElementClaimImportBatchClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimImportBatchService#simulate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchSimulationResponseDto simulate(
      PayrollElementClaimImportBatchSimulationRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchSimulationResponseDto>(
        PayrollElementClaimImportBatchSimulationResponseDto.class,
        PayrollElementClaimImportBatchService.SIMULATE_IDENTIFIER)
            .execute(() -> service().simulate(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#generate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto generate(
      PayrollElementClaimImportBatchSimulationRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.GENERATE_IDENTIFIER)
            .execute(() -> service().generate(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#completeNewAgents}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto completeNewAgents(
      ByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.COMPLETE_NEW_AGENTS_IDENTIFIER)
            .execute(() -> service().completeNewAgents(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#deposit}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto deposit(
      PayrollElementClaimImportBatchSimulationRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.DEPOSIT_IDENTIFIER)
            .execute(() -> service().deposit(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#simulateBatch}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchSimulationResponseDto simulateBatch(
      ByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchSimulationResponseDto>(
        PayrollElementClaimImportBatchSimulationResponseDto.class,
        PayrollElementClaimImportBatchService.SIMULATE_BATCH_IDENTIFIER)
            .execute(() -> service().simulateBatch(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#generatePeriod}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto generatePeriod(
      PayrollElementClaimImportBatchControlPeriodRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.GENERATE_PERIOD_IDENTIFIER)
            .execute(() -> service().generatePeriod(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#controlPeriod}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchSimulationResponseDto controlPeriod(
      PayrollElementClaimImportBatchControlPeriodRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchSimulationResponseDto>(
        PayrollElementClaimImportBatchSimulationResponseDto.class,
        PayrollElementClaimImportBatchService.CONTROL_PERIOD_IDENTIFIER)
            .execute(() -> service().controlPeriod(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#registerPeriod}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto registerPeriod(
      PayrollElementClaimImportBatchControlPeriodRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.REGISTER_PERIOD_IDENTIFIER)
            .execute(() -> service().registerPeriod(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#periodSummaries}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchPeriodSummariesResponseDto periodSummaries(
      PayrollElementClaimImportBatchPeriodSummariesRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchPeriodSummariesResponseDto>(
        PayrollElementClaimImportBatchPeriodSummariesResponseDto.class,
        PayrollElementClaimImportBatchService.PERIOD_SUMMARIES_IDENTIFIER)
            .execute(() -> service().periodSummaries(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#deletePeriod}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchDeletePeriodResponseDto deletePeriod(
      PayrollElementClaimImportBatchDeletePeriodRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchDeletePeriodResponseDto>(
        PayrollElementClaimImportBatchDeletePeriodResponseDto.class,
        PayrollElementClaimImportBatchService.DELETE_PERIOD_IDENTIFIER)
            .execute(() -> service().deletePeriod(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#generateBatch}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto generateBatch(
      PayrollElementClaimImportBatchGenerateBatchRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.GENERATE_BATCH_IDENTIFIER)
            .execute(() -> service().generateBatch(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#force}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto force(
      PayrollElementClaimImportBatchForceRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.FORCE_IDENTIFIER)
            .execute(() -> service().force(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#progress}.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  public PayrollElementClaimImportBatchGenerationResponseDto progress(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGenerationResponseDto>(
        PayrollElementClaimImportBatchGenerationResponseDto.class,
        PayrollElementClaimImportBatchService.PROGRESS_IDENTIFIER)
            .execute(() -> service().progress(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#getCount}.
   *
   * @param request requête
   * @return nombre
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(PayrollElementClaimImportBatchService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchGetManyResponseDto>(
        PayrollElementClaimImportBatchGetManyResponseDto.class,
        PayrollElementClaimImportBatchService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimImportBatchGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementClaimImportBatchService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchDto>(
        PayrollElementClaimImportBatchDto.class,
        PayrollElementClaimImportBatchService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchDto>(
        PayrollElementClaimImportBatchDto.class,
        PayrollElementClaimImportBatchService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }
}
