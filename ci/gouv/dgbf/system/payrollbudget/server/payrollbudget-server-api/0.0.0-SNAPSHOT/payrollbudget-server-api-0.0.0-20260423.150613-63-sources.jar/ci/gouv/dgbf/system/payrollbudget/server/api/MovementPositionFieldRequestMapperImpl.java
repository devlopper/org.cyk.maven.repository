package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MovementPositionFieldDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-23T15:06:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MovementPositionFieldRequestMapperImpl implements MovementPositionFieldRequestMapper {

    @Override
    public MovementPositionFieldService.MovementPositionFieldCreateRequestDto mapCreate(MovementPositionFieldDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementPositionFieldService.MovementPositionFieldCreateRequestDto movementPositionFieldCreateRequestDto = new MovementPositionFieldService.MovementPositionFieldCreateRequestDto();

        movementPositionFieldCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementPositionFieldCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementPositionFieldCreateRequestDto.setMovementIdentifier( arg0.getMovementIdentifier() );
        movementPositionFieldCreateRequestDto.setPositionField( arg0.getPositionField() );
        movementPositionFieldCreateRequestDto.setReference( arg0.getReference() );

        return movementPositionFieldCreateRequestDto;
    }

    @Override
    public MovementPositionFieldService.MovementPositionFieldUpdateRequestDto mapUpdate(MovementPositionFieldDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementPositionFieldService.MovementPositionFieldUpdateRequestDto movementPositionFieldUpdateRequestDto = new MovementPositionFieldService.MovementPositionFieldUpdateRequestDto();

        movementPositionFieldUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementPositionFieldUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementPositionFieldUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        movementPositionFieldUpdateRequestDto.setMovementIdentifier( arg0.getMovementIdentifier() );
        movementPositionFieldUpdateRequestDto.setPositionField( arg0.getPositionField() );
        movementPositionFieldUpdateRequestDto.setReference( arg0.getReference() );

        return movementPositionFieldUpdateRequestDto;
    }
}
