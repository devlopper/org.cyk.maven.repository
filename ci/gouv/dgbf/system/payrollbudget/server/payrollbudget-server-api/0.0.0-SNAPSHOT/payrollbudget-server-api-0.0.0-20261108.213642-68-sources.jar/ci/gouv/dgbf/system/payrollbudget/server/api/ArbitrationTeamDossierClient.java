package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamDossierService.ArbitrationTeamDossierCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamDossierService.ArbitrationTeamDossierGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur du service des dossiers d'équipe.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ArbitrationTeamDossierClient extends AbstractClient<ArbitrationTeamDossierService>
    implements GetMany<ArbitrationTeamDossierGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ArbitrationTeamDossierClient service(ArbitrationTeamDossierService service) {
    return (ArbitrationTeamDossierClient) super.service(service);
  }

  /**
   * Confie un dossier à une équipe.
   *
   * @param request l'équipe et le dossier
   * @return l'identifiant attribué
   */
  public CreateResponseDto create(ArbitrationTeamDossierCreateRequestDto request) {
    return new CreateExecutor(ArbitrationTeamDossierService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Recherche multicritère des rattachements.
   *
   * @param request critères, projection et pagination
   * @return les rattachements correspondants
   */
  public ArbitrationTeamDossierGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ArbitrationTeamDossierGetManyResponseDto>(
        ArbitrationTeamDossierGetManyResponseDto.class,
        ArbitrationTeamDossierService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public ArbitrationTeamDossierGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Retire un dossier d'une équipe.
   *
   * @param request l'identifiant à retirer
   * @return l'identifiant retiré
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ArbitrationTeamDossierService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
