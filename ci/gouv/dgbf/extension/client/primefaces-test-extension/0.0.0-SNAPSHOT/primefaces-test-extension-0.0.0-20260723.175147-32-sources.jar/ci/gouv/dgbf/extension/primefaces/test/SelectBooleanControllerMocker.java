package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneBooleanButton;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneRadioBoolean;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link SelectBooleanController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class SelectBooleanControllerMocker {

  SelectOneRadioBoolean selectOneRadioBoolean;

  SelectOneBooleanButton selectOneBooleanButton;
  
  /**
   * Cette méthode permet d'instancier.
   *
   */
  public SelectBooleanControllerMocker() {
    selectOneRadioBoolean = new SelectOneRadioBoolean();
    selectOneBooleanButton = new SelectOneBooleanButton();
  }

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link SelectBooleanController}
   */
  public SelectBooleanController mock() {
    SelectBooleanController controller = Mockito.mock(SelectBooleanController.class);
    Mockito.when(controller.getSelectOneRadioBoolean()).thenReturn(selectOneRadioBoolean);
    Mockito.when(controller.getSelectOneBooleanButton()).thenReturn(selectOneBooleanButton);
    return controller;
  }

}
