package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link UserDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UserFilterController extends AbstractFilterController<UserFilter> {

  @Inject
  @Getter
  InputTextController nameInputTextController;

  /**
   * Cette méthode permet de construire.
   */
  public UserFilterController() {
    super(UserFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setName(getRequestParameter(UserFilter.JSON_NAME));

    nameInputTextController.setOutputLableValue("Nom");
    nameInputTextController.getInputText().addValueConsumer(name -> filter.setName(name));

  }
}
