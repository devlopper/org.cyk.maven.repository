package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un exercice.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExerciseDto extends AbstractIdentifiableCodableNamableDto {

  @JsonbProperty(JSON_YEAR)
  private Integer year;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING)
  private String triennialProgramCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_CREATED_COUNT_AS_STRING)
  private String triennialProgramCreatedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_CREATED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramCreatedFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_TRANSMITTED_COUNT_AS_STRING)
  private String triennialProgramTransmittedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_TRANSMITTED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramTransmittedFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_RETURNED_COUNT_AS_STRING)
  private String triennialProgramReturnedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_RETURNED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramReturnedFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACCEPTED_COUNT_AS_STRING)
  private String triennialProgramAcceptedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_ACCEPTED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramAcceptedFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_APPROVED_COUNT_AS_STRING)
  private String triennialProgramApprovedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_APPROVED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramApprovedFundingAmount1AsString;

  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_NOT_APPROVED_COUNT_AS_STRING)
  private String triennialProgramNotApprovedCountAsString;

  @JsonbProperty(JSON_TOTAL_TRIENNIAL_PROGRAM_NOT_APPROVED_FUNDING_AMOUNT1_AS_STRING)
  private String totalTriennialProgramNotApprovedFundingAmount1AsString;

  /**
   * Identifiant json de identifiant de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idExercice";

  /**
   * Identifiant json de année de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_YEAR = "anneeExercice";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_AS_STRING = "exerciceChaine";

  /**
   * Identifiant json {@link #year}.
   */
  public static final String JSON_YEAR = "annee";

  /**
   * Identifiant json {@link #triennialProgramCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING = "nombreProgrammeTriennal";

  /**
   * Identifiant json {@link #totalTriennialProgramFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING =
      "totalMontant1FinancementProgrammeTriennal";

  /**
   * Identifiant json {@link #triennialProgramCreatedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_CREATED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "Cree";

  /**
   * Identifiant json {@link #totalTriennialProgramCreatedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_CREATED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "Cree";

  /**
   * Identifiant json {@link #triennialProgramTransmittedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_TRANSMITTED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "Transmis";

  /**
   * Identifiant json {@link #totalTriennialProgramTransmittedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_TRANSMITTED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "Transmis";

  /**
   * Identifiant json {@link #triennialProgramReturnedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_RETURNED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "Retourne";

  /**
   * Identifiant json {@link #totalTriennialProgramReturnedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_RETURNED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "Retourne";

  /**
   * Identifiant json {@link #triennialProgramAcceptedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACCEPTED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "Accepte";

  /**
   * Identifiant json {@link #totalTriennialProgramAcceptedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_ACCEPTED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "Accepte";

  /**
   * Identifiant json {@link #triennialProgramApprovedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_APPROVED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "Approuve";

  /**
   * Identifiant json {@link #totalTriennialProgramApprovedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_APPROVED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "Approuve";

  /**
   * Identifiant json {@link #triennialProgramNotApprovedCountAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_NOT_APPROVED_COUNT_AS_STRING =
      JSON_TRIENNIAL_PROGRAM_COUNT_AS_STRING + "NonApprouve";

  /**
   * Identifiant json {@link #totalTriennialProgramNotApprovedFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_TRIENNIAL_PROGRAM_NOT_APPROVED_FUNDING_AMOUNT1_AS_STRING =
      JSON_TOTAL_TRIENNIAL_PROGRAM_FUNDING_AMOUNT1_AS_STRING + "NonApprouve";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exercice";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
