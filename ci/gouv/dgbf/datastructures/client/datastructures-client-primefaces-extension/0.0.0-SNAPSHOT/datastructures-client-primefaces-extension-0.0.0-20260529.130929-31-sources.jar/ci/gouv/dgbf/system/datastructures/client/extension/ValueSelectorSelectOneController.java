package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueSelectorDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSelectorSelectOneController extends AbstractSelectOneIdentifiableController<
    ValueSelectorDto, ValueSelectorGetManyResponseDto, ValueSelectorClient> {

  @Getter
  @Inject
  ValueSelectorClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected ValueSelectorSelectOneController() {
    super(ValueSelectorDto.class, SelectItemLabelStrategy.NAME);
  }
}
