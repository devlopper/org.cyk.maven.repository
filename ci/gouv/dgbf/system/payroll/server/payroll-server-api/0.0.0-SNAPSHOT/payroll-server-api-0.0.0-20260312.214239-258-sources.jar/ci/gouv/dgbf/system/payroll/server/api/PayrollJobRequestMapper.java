package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobService.PayrollJobCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollJobService.PayrollJobUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollJobDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollJobDto}.

    @author Arnaud
               """)
public interface PayrollJobRequestMapper
    extends RequestMapper<PayrollJobDto, 
            PayrollJobCreateRequestDto, PayrollJobUpdateRequestDto> {

}
