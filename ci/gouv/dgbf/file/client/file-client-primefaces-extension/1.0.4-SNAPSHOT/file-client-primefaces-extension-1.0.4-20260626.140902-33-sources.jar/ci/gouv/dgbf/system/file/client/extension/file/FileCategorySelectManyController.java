package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.system.file.server.api.FileCategoryClient;
import ci.gouv.dgbf.system.file.server.api.FileCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de plusieurs {@link FileCategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileCategorySelectManyController extends AbstractSelectManyIdentifiableController<
    FileCategoryDto, FileCategoryGetManyResponseDto, FileCategoryClient> {

  @Inject
  @Getter
  FileCategoryClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FileCategorySelectManyController() {
    super(FileCategoryDto.class, SelectItemLabelStrategy.NAME);
  }
}
