package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FundingSourceClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FundingSourceDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.FundingSourceService.FundingSourceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FundingSourceDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class FundingSourceSelectOneController extends AbstractSelectOneIdentifiableController<
    FundingSourceDto, FundingSourceGetManyResponseDto, FundingSourceClient> {

  @Inject
  @Getter
  FundingSourceClient client;

  protected FundingSourceSelectOneController() {
    super(FundingSourceDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
