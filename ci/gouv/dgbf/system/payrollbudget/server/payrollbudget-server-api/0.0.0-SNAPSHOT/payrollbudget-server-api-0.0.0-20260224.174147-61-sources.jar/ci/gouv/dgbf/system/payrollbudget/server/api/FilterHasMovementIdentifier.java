package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasMovementIdentifier extends HasMovementIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de {@link MovementDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateMovementIdentifier(FilterDto filter) {
    setMovementIdentifier(MovementIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de {@link MovementDto} de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterMovementIdentifier(FilterDto filter) {
    MovementIdentifierFilter.set(filter, getMovementIdentifier());
  }

}
