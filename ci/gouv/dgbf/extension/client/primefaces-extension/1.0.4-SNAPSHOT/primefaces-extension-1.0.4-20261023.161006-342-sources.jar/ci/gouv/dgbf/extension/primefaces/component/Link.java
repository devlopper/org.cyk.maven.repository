package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un lien de navigation GET (modèle de p:link). Pour déclencher une
 * action, utiliser {@link Button}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Link extends AbstractWidget {

  String value;
  String icon;
  String title;
  String outcome;
  Map<String, List<String>> parameters;

  /**
   * Cette méthode permet de construire un lien.
   *
   * @param value libellé
   * @param outcome cible JSF
   * @return lien
   */
  public static Link of(String value, String outcome) {
    return of(value, outcome, null);
  }

  /**
   * Cette méthode permet de construire un lien avec des paramètres de requête.
   *
   * @param value libellé
   * @param outcome cible JSF
   * @param parameters paramètres
   * @return lien
   */
  public static Link of(String value, String outcome, Map<String, List<String>> parameters) {
    if (value == null || value.isBlank() || outcome == null || outcome.isBlank()) {
      throw new IllegalArgumentException("Libellé et outcome de navigation requis");
    }
    Link link = new Link();
    link.value = value;
    link.outcome = outcome;
    link.addParameters(parameters);
    return link;
  }

  /**
   * Cette méthode permet d'ajouter des paramètres de requête, rendus avec le lien.
   *
   * @param map paramètres
   */
  public void addParameters(Map<String, List<String>> map) {
    if (map == null || map.isEmpty()) {
      return;
    }
    Core.runIfNull(parameters, () -> parameters = new LinkedHashMap<>());
    parameters.putAll(map);
  }
}
