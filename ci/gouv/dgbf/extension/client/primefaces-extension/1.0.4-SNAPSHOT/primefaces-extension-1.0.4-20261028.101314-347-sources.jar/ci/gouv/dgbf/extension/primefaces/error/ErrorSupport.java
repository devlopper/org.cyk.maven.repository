package ci.gouv.dgbf.extension.primefaces.error;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.Optional;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette classe donne le moyen de joindre le support, affiché sur la page d'erreur 500.
 *
 * <p>Le contact vient de la propriété {@code dgbf.error.support-contact} de l'application : une
 * adresse électronique (affichée en lien) ou un texte libre (numéro, service). Sans valeur, rien
 * n'est affiché. La classe ne dépend de rien d'autre que de la configuration, pour que la page
 * d'erreur reste affichable quand l'erreur vient des autres composants.
 *
 * @author Christian
 */
@Named
@ApplicationScoped
public class ErrorSupport {
  @ConfigProperty(name = "dgbf.error.support-contact")
  Optional<String> contact = Optional.empty();

  /**
   * Cette méthode donne le contact du support.
   *
   * @return le contact, ou une chaîne vide s'il n'est pas configuré
   */
  public String getContact() {
    return contact == null ? "" : contact.orElse("").trim();
  }

  /**
   * Cette méthode indique si un contact est configuré.
   *
   * @return vrai si le contact n'est pas vide
   */
  public boolean isAvailable() {
    return !getContact().isEmpty();
  }

  /**
   * Cette méthode indique si le contact est une adresse électronique, à afficher en lien.
   *
   * @return vrai si le contact ressemble à une adresse électronique
   */
  public boolean isEmail() {
    return getContact().matches("[^\\s@]+@[^\\s@]+\\.[^\\s@]+");
  }
}
