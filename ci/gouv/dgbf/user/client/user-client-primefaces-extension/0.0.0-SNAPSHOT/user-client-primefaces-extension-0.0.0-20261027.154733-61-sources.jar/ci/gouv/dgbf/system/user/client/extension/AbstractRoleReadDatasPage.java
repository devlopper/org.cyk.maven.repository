package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.layout.ListDetailLayoutController;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiablePage;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiablePageMode;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiableResolution;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.ExcludedCodesFilter;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.user.server.api.ReservedRole;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la classe dont herite les autres classes.
 *
 * @author Arnaud
 *
 */
public abstract class AbstractRoleReadDatasPage extends AbstractPage
    implements IdentifiablePage<RoleDto, RoleFilter> {

  @Inject
  protected RoleClient client;

  @Getter
  protected RoleDto role;

  protected IdentifiableResolution identifiableResolution = new IdentifiableResolution()
      .addNavigation("Retour à la liste", getListPageOutcome());
  private boolean identifiablePageInitialized;

  @Override
  public IdentifiableResolution getIdentifiableResolution() {
    if (!identifiablePageInitialized) {
      identifiablePageInitialized = true;
      initialize();
    }
    return identifiableResolution;
  }

  @Inject
  @Getter
  protected RoleTabMenuController tabMenuController;

  /**
   * Panneau des autres Rôles, à droite de la fiche (maître-détail, RU_UTI_027) : simple
   * objet de présentation, sans dépendance à injecter.
   */
  @Getter
  protected ListDetailLayoutController listDetailLayoutController =
      new ListDetailLayoutController();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + RoleDto.NAME;
  }

  /** Initialise la lecture pendant la phase metadata JSF, après la création de la vue. */
  public void initialize() {
    instantiateAndGetFilter();
  }

  @Override
  public IdentifiablePageMode getIdentifiablePageMode() {
    return IdentifiablePageMode.DISPLAY_STATE;
  }

  @Override
  public boolean isIdentifierFallbackEnabled() {
    return false;
  }

  @Override
  public void processFilterWhenIdentifierBlank(RoleFilter filter) {
    clearIdentifiablePageContent();
  }

  @Override
  public OneRetrievable<RoleDto> getIdentifiableRetriever() {
    return (projection, filter, actor, session) -> client.getByIdentifier(
        AbstractIdentifiableFilter.getIdentifier(filter), projection, actor, session);
  }

  @Override
  public void clearIdentifiablePageContent() {
    role = null;
  }

  @Override
  public Class<RoleFilter> getIdentifiableFilterClass() {
    return RoleFilter.class;
  }

  @Override
  public Class<RoleDto> getIdentifiableDtoClass() {
    return RoleDto.class;
  }

  @Override
  public String getConnectedUserSharedSelectionPageOutcome() {
    return getListPageOutcome();
  }

  protected abstract String getListPageOutcome();

  @Override
  public ProjectionDto getIdentifiableProjection() {
    return instantiateProjection();
  }

  @Override
  public void initializeWhenIdentifiableNull() {
    role = null;
  }

  @Override
  public void initializeWhenIdentifiableNotNull(RoleDto instance) {
    role = instance;

    tabMenuController.role = role;
    tabMenuController.initialize();

    // Rôles métier seulement, comme la liste des Rôles (RG_UTI_ROL_17)
    listDetailLayoutController.setLinkValueName("code ou libellé");
    listDetailLayoutController
        .setFilterConsumer(filter -> ExcludedCodesFilter.set(filter, ReservedRole.CODES));
    listDetailLayoutController.instantiateDetailsAsLazyDataModel(RoleDto.class, client,
        userIdentifier);
    listDetailLayoutController.initialize();
  }

  /**
   * Cette méthode permet d'instancier {@link ProjectionDto}.
   *
   * @return {@link ProjectionDto}
   */
  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        RoleDto.JSON_DESCRIPTION, RoleDto.JSON_APPLICATION_AS_STRING,
        // Nombres de la fiche (RU_UTI_027)
        HasUserCountAsStringDto.JSON_USER_COUNT_AS_STRING,
        HasPendingRoleSolicitationCountAsStringDto.JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING);
  }
}
