package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FunctionGroupRequestMapperImpl implements FunctionGroupRequestMapper {

    @Override
    public FunctionGroupService.FunctionGroupCreateRequestDto mapCreate(FunctionGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionGroupService.FunctionGroupCreateRequestDto functionGroupCreateRequestDto = new FunctionGroupService.FunctionGroupCreateRequestDto();

        functionGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionGroupCreateRequestDto.setCode( arg0.getCode() );
        functionGroupCreateRequestDto.setName( arg0.getName() );
        functionGroupCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return functionGroupCreateRequestDto;
    }

    @Override
    public FunctionGroupService.FunctionGroupUpdateRequestDto mapUpdate(FunctionGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionGroupService.FunctionGroupUpdateRequestDto functionGroupUpdateRequestDto = new FunctionGroupService.FunctionGroupUpdateRequestDto();

        functionGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionGroupUpdateRequestDto.setCode( arg0.getCode() );
        functionGroupUpdateRequestDto.setName( arg0.getName() );
        functionGroupUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return functionGroupUpdateRequestDto;
    }
}
