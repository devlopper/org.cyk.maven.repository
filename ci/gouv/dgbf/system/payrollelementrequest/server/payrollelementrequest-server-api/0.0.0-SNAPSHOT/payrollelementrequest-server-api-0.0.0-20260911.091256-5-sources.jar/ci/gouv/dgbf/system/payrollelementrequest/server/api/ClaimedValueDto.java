package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la valeur réclamée pour un Élément de Paie ou une Constante de Paie
 * concerné(e) par une réclamation (RG_REP_CIB_02/03) -- couplage faible sur {@link #nature}.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimedValueDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link PayrollElementClaimDto}.
   */
  @JsonbProperty(JSON_CLAIM_IDENTIFIER)
  private String claimIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimIdentifier}.
   */
  @JsonbProperty(JSON_CLAIM_AS_STRING)
  private String claimAsString;

  /**
   * Identifiant {@link ClaimTypeClaimableDto} -- l'Élément de Paie ou la Constante de Paie
   * effectivement concerné(e), éligible pour le Type de la réclamation (RG_REP_CIB_01).
   */
  @JsonbProperty(JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER)
  private String claimTypeClaimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimTypeClaimableIdentifier}.
   */
  @JsonbProperty(JSON_CLAIM_TYPE_CLAIMABLE_AS_STRING)
  private String claimTypeClaimableAsString;

  /**
   * Toujours {@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE} -- discriminant technique de la FK
   * composite (RECLAMABLE_PARAMETRE, NATURE) vers {@code TA_TYPE_RECLAMATION_RECLAMABLE}.
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Valeur réclamée sous forme de chaine -- pour {@code ELEMENT_PAIE} : non utilisée directement,
   * voir {@link #claimableValueIdentifier} ; pour {@code CONSTANTE_PAIE} sans liste fermée : la
   * valeur elle-même, interprétée selon {@link #valueType} (peut représenter un nombre négatif,
   * ajustement contentieux).
   */
  @JsonbProperty(JSON_VALUE)
  private String value;

  /**
   * Type de {@link #value} ({@code ValueType}, core-extension) -- pertinent pour
   * {@code CONSTANTE_PAIE} uniquement, {@code null} pour {@code ELEMENT_PAIE}.
   */
  @JsonbProperty(JSON_VALUE_TYPE)
  private String valueType;

  /**
   * Identifiant {@code ClaimableValueDto} : pour {@code ELEMENT_PAIE}, l'instance synchronisée
   * revendiquée ({@code null} pour un Retrait, aucune nouvelle valeur) ; pour
   * {@code CONSTANTE_PAIE}, la Valeur Réclamable retenue quand le Réclamable concerné possède une
   * liste fermée (RG_REP_CIB_09), {@code null} sinon.
   */
  @JsonbProperty(JSON_CLAIMABLE_VALUE_IDENTIFIER)
  private String claimableValueIdentifier;

  /**
   * {@code ELEMENT_PAIE} uniquement : identifiant d'un {@code Mouvement} existant du FAE, module
   * {@code payroll} -- sans FK (couplage faible) ; renseigné uniquement quand le Type de
   * Réclamation exige de désigner une instance déjà détenue parmi plusieurs (cas Fonction), pour
   * une correction de date d'effet ou un retrait ; {@code null} pour {@code CONSTANTE_PAIE}.
   */
  @JsonbProperty(JSON_CURRENT_MOVEMENT_IDENTIFIER)
  private String currentMovementIdentifier;

  /**
   * {@code ELEMENT_PAIE} uniquement : date d'effet de la valeur réclamée, ou date de fin d'effet
   * pour un Retrait ; {@code null} pour {@code CONSTANTE_PAIE}.
   */
  @JsonbProperty(JSON_EFFECTIVE_DATE)
  private LocalDate effectiveDate;

  /**
   * Jeu <em>retenu</em> (RG_REP_PEC_11) -- équivalent de {@link #value} pour la valeur qui fait
   * foi : déterminée par l'Agent en Mode Agent (RG_REP_PEC_09), corrigée ou recopiée depuis la
   * saisie FAE à l'Acceptation en Mode FAE. Base de la Revue de Valeur Réclamée (RG_REP_PEC_08).
   */
  @JsonbProperty(JSON_RETAINED_VALUE)
  private String retainedValue;

  /**
   * Jeu retenu -- équivalent de {@link #valueType}.
   */
  @JsonbProperty(JSON_RETAINED_VALUE_TYPE)
  private String retainedValueType;

  /**
   * Jeu retenu -- équivalent de {@link #claimableValueIdentifier}.
   */
  @JsonbProperty(JSON_RETAINED_CLAIMABLE_VALUE_IDENTIFIER)
  private String retainedClaimableValueIdentifier;

  /**
   * Jeu retenu -- équivalent de {@link #currentMovementIdentifier}.
   */
  @JsonbProperty(JSON_RETAINED_CURRENT_MOVEMENT_IDENTIFIER)
  private String retainedCurrentMovementIdentifier;

  /**
   * Jeu retenu -- équivalent de {@link #effectiveDate}.
   */
  @JsonbProperty(JSON_RETAINED_EFFECTIVE_DATE)
  private LocalDate retainedEffectiveDate;

  /**
   * Identifiant {@code User} (module {@code user}, sans FK) de l'Agent de Traitement ayant
   * corrigé la valeur FAE (RG_REP_PEC_11) ; {@code null} si le jeu retenu reprend la saisie FAE
   * ou provient d'une détermination Mode Agent.
   */
  @JsonbProperty(JSON_CORRECTED_BY)
  private String correctedBy;

  /**
   * Date de la dernière correction Agent d'une valeur FAE (RG_REP_PEC_11) ; {@code null}, ou
   * {@code non null} avec {@link #correctedBy}.
   */
  @JsonbProperty(JSON_CORRECTION_DATE)
  private LocalDate correctionDate;

  /**
   * Toujours {@code ELEMENT_PAIE} (RG_REP_CIB_02).
   */
  public static final String NATURE_ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Toujours {@code CONSTANTE_PAIE} (RG_REP_CIB_03).
   */
  public static final String NATURE_CONSTANTE_PAIE = "CONSTANTE_PAIE";

  /**
   * Identifiant json {@link #claimIdentifier}.
   */
  public static final String JSON_CLAIM_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json {@link #claimAsString}.
   */
  public static final String JSON_CLAIM_AS_STRING = "reclamationChaine";

  /**
   * Identifiant json {@link #claimTypeClaimableIdentifier}.
   */
  public static final String JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER = "idReclamableTypeReclamation";

  /**
   * Identifiant json {@link #claimTypeClaimableAsString}.
   */
  public static final String JSON_CLAIM_TYPE_CLAIMABLE_AS_STRING =
      "reclamableTypeReclamationChaine";

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #value}.
   */
  public static final String JSON_VALUE = "valeur";

  /**
   * Identifiant json {@link #valueType}.
   */
  public static final String JSON_VALUE_TYPE = "typeValeur";

  /**
   * Identifiant json {@link #claimableValueIdentifier}.
   */
  public static final String JSON_CLAIMABLE_VALUE_IDENTIFIER = "idValeurReclamable";

  /**
   * Identifiant json {@link #currentMovementIdentifier}.
   */
  public static final String JSON_CURRENT_MOVEMENT_IDENTIFIER = "idMouvementActuel";

  /**
   * Identifiant json {@link #effectiveDate}.
   */
  public static final String JSON_EFFECTIVE_DATE = "dateEffet";

  /**
   * Identifiant json {@link #retainedValue}.
   */
  public static final String JSON_RETAINED_VALUE = "valeurRetenue";

  /**
   * Identifiant json {@link #retainedValueType}.
   */
  public static final String JSON_RETAINED_VALUE_TYPE = "typeValeurRetenue";

  /**
   * Identifiant json {@link #retainedClaimableValueIdentifier}.
   */
  public static final String JSON_RETAINED_CLAIMABLE_VALUE_IDENTIFIER = "idValeurReclamableRetenue";

  /**
   * Identifiant json {@link #retainedCurrentMovementIdentifier}.
   */
  public static final String JSON_RETAINED_CURRENT_MOVEMENT_IDENTIFIER = "idMouvementActuelRetenue";

  /**
   * Identifiant json {@link #retainedEffectiveDate}.
   */
  public static final String JSON_RETAINED_EFFECTIVE_DATE = "dateEffetRetenue";

  /**
   * Identifiant json {@link #correctedBy}.
   */
  public static final String JSON_CORRECTED_BY = "corrigeePar";

  /**
   * Identifiant json {@link #correctionDate}.
   */
  public static final String JSON_CORRECTION_DATE = "dateCorrection";

  /**
   * Identifiant json de identifiant de {@link ClaimedValueDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idValeurReclamee";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimedValueDto}.
   */
  public static final String JSON_THIS_AS_STRING = "valeurReclameeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "valeur réclamée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "valeurs réclamées";
}
