package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de traitement d'élément de liste.
 *
 * @author Christian
 *
 */
@Dependent
public class ListRecordProcessingController extends AbstractController {

  @Inject
  @Getter
  UpdateController controller;

  @Getter
  @Setter
  Dialog dialog;

  @Getter
  @Setter
  Button showDialogButton;

  ListController listController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    dialog = new Dialog();
    showDialogButton = new Button();
  }

  /**
   * Cette méthode permet d'initialiser le contrôleur.
   *
   * @param listController contrôleur de liste
   */
  public void initialize(ListController listController, String name, String formFileName) {
    this.listController = listController;
    listController.configureAction(dialog, formFileName, controller);
    showDialogButton.setValue(name);
    dialog.setIdentifier(formFileName + "Dialog");
    dialog.setWidgetVar(dialog.getIdentifier() + "WidgetVar");
    dialog.setHeader(showDialogButton.getValue());
    controller.setName("Mise à jour " + name);
  }

  public void showDialog(String identifier) {
    listController.showUpdateDialog(identifier, dialog, controller);
  }
}
