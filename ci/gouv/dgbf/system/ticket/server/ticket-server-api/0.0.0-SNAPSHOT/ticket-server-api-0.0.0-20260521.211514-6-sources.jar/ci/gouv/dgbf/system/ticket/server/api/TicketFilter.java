package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasReference;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TicketDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class TicketFilter extends AbstractIdentifiableFilter implements FilterHasReference {

  /**
   * Reference.
   */
  private String reference;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TicketFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TicketFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateReference(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterReference(filter);
  }
}
