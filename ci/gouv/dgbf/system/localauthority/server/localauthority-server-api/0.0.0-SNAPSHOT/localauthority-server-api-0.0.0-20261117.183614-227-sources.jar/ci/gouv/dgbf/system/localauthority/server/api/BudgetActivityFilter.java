package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 */
@Getter
@Setter
public class BudgetActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link BudgetDto}.
   */
  String budgetIdentifier;

  /**
   * {@link BudgetActivityType}.
   */
  BudgetActivityType type;

  /**
   * {@link BudgetSection}.
   */
  BudgetSection section;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetActivityFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    budgetIdentifier = getBudgetIdentifier(filter);
    type = getType(filter);
    section = getSection(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setBudgetIdentifier(filter, budgetIdentifier);
    setType(filter, type);
    setSection(filter, section);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
   *
   * @param filter filtre
   * @return identifiant {@link BudgetDto}
   */
  public static String getBudgetIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_BUDGET_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link BudgetDto}
   */
  public static void setBudgetIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BUDGET_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir le {@link BudgetActivityType}.
   *
   * @param filter filtre
   * @return {@link BudgetActivityType}
   */
  public static BudgetActivityType getType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, BudgetActivityType.class));
  }

  /**
   * Cette méthode permet d'assigner le {@link BudgetActivityType}.
   *
   * @param filter filtre
   * @param type   {@link BudgetActivityType}
   */
  public static void setType(FilterDto filter, BudgetActivityType type) {
    set(filter, JSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir le {@link BudgetSection}.
   *
   * @param filter filtre
   * @return {@link BudgetSection}
   */
  public static BudgetSection getSection(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_SECTION, BudgetSection.class));
  }

  /**
   * Cette méthode permet d'assigner le {@link BudgetSection}.
   *
   * @param filter  filtre
   * @param section {@link BudgetSection}
   */
  public static void setSection(FilterDto filter, BudgetSection section) {
    set(filter, JSON_SECTION, f -> f.getValueAsString(), f -> f.setValueAsEnum(section));
  }

  /**
   * Identifiant json champ {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER =
      BudgetActivityDto.JSON_BUDGET_IDENTIFIER;

  /**
   * Identifiant json champ {@link #type}.
   */
  public static final String JSON_TYPE = BudgetActivityDto.JSON_TYPE;

  /**
   * Identifiant json champ {@link #section}.
   */
  public static final String JSON_SECTION = BudgetActivityDto.JSON_SECTION;
}
