package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un zone géographique.
 *
 * @author arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class GeographicZoneDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant json de identifiant de {@link GeographicZoneDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idZoneGeographique";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link GeographicZoneDto}.
   */
  public static final String JSON_THIS_AS_STRING = "zoneGeographiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "zone géographique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "zones géographiques";
}
