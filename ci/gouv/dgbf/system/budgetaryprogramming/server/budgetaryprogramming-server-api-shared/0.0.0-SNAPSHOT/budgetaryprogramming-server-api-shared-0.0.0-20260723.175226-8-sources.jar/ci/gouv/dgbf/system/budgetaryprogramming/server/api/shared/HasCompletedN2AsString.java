package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+2 est complétée,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN2AsString {

  /**
   * Obtient l'indicateur indiquant si l'année N+2 est complétée,
   * sous forme de chaîne de caractères.
   *
   * @return l'indicateur indiquant si l'année N+2 est complétée sous forme de chaîne de caractères
   */
  String getCompletedN2AsString();

  /**
   * Définit l'indicateur indiquant si l'année N+2 est complétée,
   * sous forme de chaîne de caractères.
   *
   * @param completedN2AsString indicateur indiquant si l'année N+2 est complétée
   *        sous forme de chaîne de caractères
   */
  void setCompletedN2AsString(String completedN2AsString);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N+2 est complétée,
   * sous forme de chaîne de caractères.
   */
  String FIELD_COMPLETED_N2_AS_STRING = "completedN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName