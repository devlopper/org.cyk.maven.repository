package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link MediumNature}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class MediumNatureManager extends AbstractStatusManager<MediumNature> {

  /**
   * Cette méthode permet d'instancier.
   */
  public MediumNatureManager() {
    super(MediumNature.class, e -> e.getName());
  }
}
