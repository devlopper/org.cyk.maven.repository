package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ConstantService.ConstantCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantService.ConstantUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ConstantDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ConstantDto}.

    @author Christian
               """)
public interface ConstantRequestMapper extends RequestMapper<ConstantDto,
    ConstantCreateRequestDto, ConstantUpdateRequestDto> {

}
