package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsConfirmedDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente un service de gestion de fichier de groupe.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FileGroupService.PATH)
@Tag(name = "Gestion des fichiers de groupe")
public interface FileGroupService extends SpecificService {

  /**
   * Chemin du service.
   */
  String PATH = "fichiers-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FICHIER_GROUPE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Christian
   *
   */
  interface FileGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FileDto}.
     *
     * @return identifiant de {@link FileDto}
     */
    String getFileIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FileDto}.
     *
     * @param identityIdentifier identifiant de {@link FileDto}
     */
    void setFileIdentifier(String identityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FilesGroupDto}.
     *
     * @return identifiant de {@link FilesGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de @link FilesGroupDto}.
     *
     * @param groupIdentifier identifiant de @link FilesGroupDto}
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'odre de mise à jour des identifiants de
     * {@link FileCategoryDto}.
     *
     * @return odre de mise à jour des identifiants de {@link FileCategoryDto}
     */
    Boolean getUpdateCategoriesIdentifiers();

    /**
     * Cette méthode permet d'assigner l'odre de mise à jour des identifiants de
     * {@link FileCategoryDto}.
     *
     * @param updateCategoriesIdentifiers odre de mise à jour des identifiants de
     *        {@link FileCategoryDto}
     */
    void setUpdateCategoriesIdentifiers(Boolean updateCategoriesIdentifiers);

    /**
     * Cette méthode permet d'obtenir les identifiants de {@link FileCategoryDto}.
     *
     * @return identifiants de {@link FileCategoryDto}
     */
    Set<String> getCategoriesIdentifiers();

    /**
     * Cette méthode permet d'assigner les identifiants de @link FileCategoryDto}.
     *
     * @param categoriesIdentifiers identifiants de @link FileCategoryDto}
     */
    void setCategoriesIdentifiers(Set<String> categoriesIdentifiers);

    /**
     * {@link FileGroupDto#JSON_FILE_IDENTIFIER}.
     */
    String JSON_FILE_IDENTIFIER = FileGroupDto.JSON_FILE_IDENTIFIER;

    /**
     * {@link FileGroupDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = FileGroupDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link FileGroupDto#JSON_CATEGORIES_IDENTIFIERS}.
     */
    String JSON_CATEGORIES_IDENTIFIERS = FileGroupDto.JSON_CATEGORIES_IDENTIFIERS;

    /**
     * {@link FileGroupDto#JSON_UPDATE_CATEGORIES_IDENTIFIERS}.
     */
    String JSON_UPDATE_CATEGORIES_IDENTIFIERS = FileGroupDto.JSON_UPDATE_CATEGORIES_IDENTIFIERS;
  }

  /**
   * Cette méthode permet de créer un fichier de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création de fichier de groupe",
      description = "Ce service permet de créer un fichier de groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements FileGroupSaveRequestDto, HasIsConfirmedDto {
    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CATEGORIES_IDENTIFIERS)
    private Set<String> categoriesIdentifiers;

    @JsonbProperty(JSON_UPDATE_CATEGORIES_IDENTIFIERS)
    private Boolean updateCategoriesIdentifiers;

    @JsonbProperty(JSON_IS_CONFIRMED)
    private Boolean isConfirmed;

    /**
     * Nom dans le Groupe, facultatif ; une valeur identique au nom du Fichier est enregistrée
     * {@code null} (RG_FILE_CAT_09).
     */
    @JsonbProperty(JSON_NAME)
    private String name;

    /**
     * Description dans le Groupe, facultative ; même règle que {@link #name}.
     */
    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    /**
     * Champ JSON {@link #name}.
     */
    public static final String JSON_NAME = FileGroupDto.JSON_NAME;

    /**
     * Champ JSON {@link #description}.
     */
    public static final String JSON_DESCRIPTION = FileGroupDto.JSON_DESCRIPTION;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des fichiers de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FileGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<FileGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un fichier de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FICHIER_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FileGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FICHIER_GROUPE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FileGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FileGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupUpdateRequestDto extends ByIdentifierRequestDto
      implements FileGroupSaveRequestDto {
    @JsonbProperty(JSON_FILE_IDENTIFIER)
    private String fileIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CATEGORIES_IDENTIFIERS)
    private Set<String> categoriesIdentifiers;

    @JsonbProperty(JSON_UPDATE_CATEGORIES_IDENTIFIERS)
    private Boolean updateCategoriesIdentifiers;
  }

  /**
   * Identifiant du service de mise à jour les {@link FileCategoryDto}.
   */
  String UPDATE_CATEGORIES_IDENTIFIER = "MISE_A_JOUR_CATEGORIES_FICHIER_GROUPE";

  /**
   * Chemin du service de mise à jour les {@link FileCategoryDto}.
   */
  String UPDATE_CATEGORIES_PATH = "roles";

  /**
   * Cette méthode permet de mettre à jour les {@link FileCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_CATEGORIES_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_CATEGORIES_IDENTIFIER,
      description = "Ce service permet de mettre à jour les catégories d'un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateCategories(FileGroupUpdateCategoriesRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour des {@link FileCategoryDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupUpdateCategoriesRequestDto extends ByIdentifierRequestDto {
    /**
     * Identifiants {@link FileCategoryDto}.
     */
    @JsonbProperty(JSON_CATEGORIES_IDENTIFIERS)
    private Set<String> categoriesIdentifiers;

    /**
     * Champ JSON {@link #categoriesIdentifiers}.
     */
    public static final String JSON_CATEGORIES_IDENTIFIERS =
        FileGroupDto.JSON_CATEGORIES_IDENTIFIERS;
  }

  /**
   * Identifiant du service de modification des informations du rattachement (RG_FILE_CAT_10).
   */
  String UPDATE_INFORMATION_IDENTIFIER = "MODIFICATION_INFORMATION_FICHIER_GROUPE";

  /**
   * Chemin du service de modification des informations du rattachement.
   */
  String UPDATE_INFORMATION_PATH = "informations/modification";

  /**
   * Cette méthode permet de modifier le Nom dans le Groupe et la Description dans le Groupe,
   * sans justification. Un champ absent n'est pas modifié ; une valeur s'efface en la citant dans
   * {@code champsEffaces} (le rattachement reprend alors celle du Fichier). Refus (400) : aucun
   * changement effectif, Nom vide, longueur dépassée, {@code champsEffaces} incohérent,
   * rattachement gelé par l'archivage (RG_FILE_ARC_04). Rattachement inconnu : 404. Le Fichier
   * n'est jamais modifié.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_INFORMATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_INFORMATION_IDENTIFIER,
      summary = "Modification des informations d'un fichier de groupe",
      description = "Ce service permet de modifier le nom et la description propres à un "
          + "fichier de groupe, sans modifier le fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateInformation(FileGroupUpdateInformationRequestDto request);

  /**
   * Cette classe représente la requête de modification des informations du rattachement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupUpdateInformationRequestDto extends ByIdentifierRequestDto {
    /**
     * Nouveau Nom dans le Groupe, facultatif ; jamais vide s'il est fourni.
     */
    @JsonbProperty(JSON_NAME)
    private String name;

    /**
     * Nouvelle Description dans le Groupe, facultative.
     */
    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    /**
     * Champs à effacer : codes {@link FileJournalFieldKindCode#NAME} et
     * {@link FileJournalFieldKindCode#DESCRIPTION} seulement (JSON-B ne distingue pas un champ
     * absent d'un champ nul).
     */
    @JsonbProperty(JSON_CLEARED_FIELDS)
    private Set<String> clearedFields;

    /**
     * Champ JSON {@link #name}.
     */
    public static final String JSON_NAME = FileGroupDto.JSON_NAME;

    /**
     * Champ JSON {@link #description}.
     */
    public static final String JSON_DESCRIPTION = FileGroupDto.JSON_DESCRIPTION;

    /**
     * Champ JSON {@link #clearedFields}.
     */
    public static final String JSON_CLEARED_FIELDS = "champsEffaces";
  }

  /**
   * Identifiant du service de confirmation.
   */
  String CONFIRM_IDENTIFIER = "CONFIRMATION_FICHIER_GROUPE";

  /**
   * Chemin du service de confirmation.
   */
  String CONFIRM_PATH = "confirmation";

  /**
   * Cette méthode permet de confirmer {@link FileGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONFIRM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONFIRM_IDENTIFIER,
      description = "Ce service permet de confirmer un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupConfirmResponseDto.class))})
  Response confirm(FileGroupConfirmRequestDto request);

  /**
   * Cette classe représente la requête de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupConfirmRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<FileGroupStatus>, HasConfirmableDto {

    @JsonbProperty(JSON_STATUS)
    private FileGroupStatus status;

    @JsonbProperty(JSON_CONFIRMABLE)
    private Boolean confirmable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link FileGroupStatus}
     */
    public void initialize(FileGroupStatus status) {
      this.status = status;
    }
  }

  /**
   * Cette classe représente la réponse de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupConfirmResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FICHIER_GROUPE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un fichier de groupe")
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'archivage.
   */
  String ARCHIVE_IDENTIFIER = "ARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service d'archivage.
   */
  String ARCHIVE_PATH = "archivage";

  /**
   * Cette méthode permet d'archiver {@link FileGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ARCHIVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ARCHIVE_IDENTIFIER,
      summary = "Archivage d'un fichier de groupe",
      description = "Ce service permet d'archiver un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupArchiveResponseDto.class))})
  Response archive(FileGroupArchiveRequestDto request);

  /**
   * Cette classe représente la requête d'archivage de fichier de groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire de l'archivage.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif.
     */
    public static final String JSON_REASON = "motif";
  }

  /**
   * Cette classe représente la réponse d'archivage de fichier de groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupArchiveResponseDto extends AbstractResponseDto {

    /**
     * Archive effective créée.
     */
    @JsonbProperty(JSON_ARCHIVE)
    private FileGroupArchiveDto archive;

    /**
     * Clé JSON de l'archive.
     */
    public static final String JSON_ARCHIVE = "archive";
  }

  /**
   * Identifiant du service de désarchivage.
   */
  String UNARCHIVE_IDENTIFIER = "DESARCHIVAGE_FICHIER_GROUPE";

  /**
   * Chemin du service de désarchivage.
   */
  String UNARCHIVE_PATH = "desarchivage";

  /**
   * Cette méthode permet de désarchiver {@link FileGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UNARCHIVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UNARCHIVE_IDENTIFIER,
      summary = "Désarchivage d'un fichier de groupe",
      description = "Ce service permet de désarchiver un fichier de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileGroupUnarchiveResponseDto.class))})
  Response unarchive(FileGroupUnarchiveRequestDto request);

  /**
   * Cette classe représente la requête de désarchivage de fichier de groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupUnarchiveRequestDto extends ByIdentifierRequestDto {

    /**
     * Motif obligatoire du désarchivage.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * Clé JSON du motif.
     */
    public static final String JSON_REASON = "motif";
  }

  /**
   * Cette classe représente la réponse de désarchivage de fichier de groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileGroupUnarchiveResponseDto extends AbstractResponseDto {

    /**
     * Archive effective terminée.
     */
    @JsonbProperty(JSON_ARCHIVE)
    private FileGroupArchiveDto archive;

    /**
     * Clé JSON de l'archive.
     */
    public static final String JSON_ARCHIVE = "archive";
  }

  /** Identifiant du service d'obtention du compte. */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_FICHIER_GROUPE";
  String GET_COUNT_PATH = "obtention/compte";

  /** Obtient le nombre de concepts correspondant aux filtres. */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);
}
