package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RegistrationNumberGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T18:27:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RegistrationNumberGroupRequestMapperImpl implements RegistrationNumberGroupRequestMapper {

    @Override
    public RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto mapCreate(RegistrationNumberGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto registrationNumberGroupCreateRequestDto = new RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto();

        registrationNumberGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        registrationNumberGroupCreateRequestDto.setCode( arg0.getCode() );
        registrationNumberGroupCreateRequestDto.setName( arg0.getName() );
        registrationNumberGroupCreateRequestDto.setRegistrationNumberPattern( arg0.getRegistrationNumberPattern() );

        return registrationNumberGroupCreateRequestDto;
    }

    @Override
    public RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto mapUpdate(RegistrationNumberGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto registrationNumberGroupUpdateRequestDto = new RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto();

        registrationNumberGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        registrationNumberGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        registrationNumberGroupUpdateRequestDto.setCode( arg0.getCode() );
        registrationNumberGroupUpdateRequestDto.setName( arg0.getName() );
        registrationNumberGroupUpdateRequestDto.setRegistrationNumberPattern( arg0.getRegistrationNumberPattern() );

        return registrationNumberGroupUpdateRequestDto;
    }
}
