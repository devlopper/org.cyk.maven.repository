package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCompletedDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasCompletedN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasCompletedN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasCompletedNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputProgressPercentageNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToArbitrateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToArbitrateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToArbitrateNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToInputN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToInputN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToInputNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToIntegrateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToIntegrateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToIntegrateNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToValidateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToValidateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRemainingAmountToValidateNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToArbitrateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToArbitrateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToArbitrateNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToInputN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToInputN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToInputNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToIntegrateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToIntegrateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToIntegrateNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToValidateN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToValidateN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasTotalAmountToValidateNAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants pour un regroupement de lignes de
 * dépense ou de recettes (par exemple : activité, action, unité de spécialisation du budget, unité
 * administrative, section).
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public abstract class AbstractGroupedAmountsContainerDto extends AbstractAmountsContainerDto
    implements
    // ToInput
    HasTotalAmountToInputNAsStringDto, HasRemainingAmountToInputNAsStringDto,
    HasTotalAmountToInputN1AsStringDto, HasRemainingAmountToInputN1AsStringDto,
    HasTotalAmountToInputN2AsStringDto, HasRemainingAmountToInputN2AsStringDto,
    // ToArbitrate
    HasTotalAmountToArbitrateNAsStringDto, HasRemainingAmountToArbitrateNAsStringDto,
    HasTotalAmountToArbitrateN1AsStringDto, HasRemainingAmountToArbitrateN1AsStringDto,
    HasTotalAmountToArbitrateN2AsStringDto, HasRemainingAmountToArbitrateN2AsStringDto,
    // ToValidate
    HasTotalAmountToValidateNAsStringDto, HasRemainingAmountToValidateNAsStringDto,
    HasTotalAmountToValidateN1AsStringDto, HasRemainingAmountToValidateN1AsStringDto,
    HasTotalAmountToValidateN2AsStringDto, HasRemainingAmountToValidateN2AsStringDto,
    // ToIntegrate
    HasTotalAmountToIntegrateNAsStringDto, HasRemainingAmountToIntegrateNAsStringDto,
    HasTotalAmountToIntegrateN1AsStringDto, HasRemainingAmountToIntegrateN1AsStringDto,
    HasTotalAmountToIntegrateN2AsStringDto, HasRemainingAmountToIntegrateN2AsStringDto,
    // Completed
    HasCompletedDto, HasCompletedNDto, HasCompletedN1Dto, HasCompletedN2Dto,
    // Progress
    HasInputProgressPercentageNAsStringDto {

  // ToInput

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INPUT_N_AS_STRING)
  protected String totalAmountToInputNAsString;

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INPUT_N1_AS_STRING)
  protected String totalAmountToInputN1AsString;
  
  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INPUT_N2_AS_STRING)
  protected String totalAmountToInputN2AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INPUT_N_AS_STRING)
  protected String remainingAmountToInputNAsString;

  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INPUT_N1_AS_STRING)
  protected String remainingAmountToInputN1AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INPUT_N2_AS_STRING)
  protected String remainingAmountToInputN2AsString;
  
  // ToArbitrate

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_ARBITRATE_N_AS_STRING)
  protected String totalAmountToArbitrateNAsString;

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_ARBITRATE_N1_AS_STRING)
  protected String totalAmountToArbitrateN1AsString;
  
  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_ARBITRATE_N2_AS_STRING)
  protected String totalAmountToArbitrateN2AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_ARBITRATE_N_AS_STRING)
  protected String remainingAmountToArbitrateNAsString;

  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_ARBITRATE_N1_AS_STRING)
  protected String remainingAmountToArbitrateN1AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_ARBITRATE_N2_AS_STRING)
  protected String remainingAmountToArbitrateN2AsString;
  
  // ToValidate

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_VALIDATE_N_AS_STRING)
  protected String totalAmountToValidateNAsString;

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_VALIDATE_N1_AS_STRING)
  protected String totalAmountToValidateN1AsString;
  
  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_VALIDATE_N2_AS_STRING)
  protected String totalAmountToValidateN2AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_VALIDATE_N_AS_STRING)
  protected String remainingAmountToValidateNAsString;

  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_VALIDATE_N1_AS_STRING)
  protected String remainingAmountToValidateN1AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_VALIDATE_N2_AS_STRING)
  protected String remainingAmountToValidateN2AsString;
  
  // ToIntegrate

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INTEGRATE_N_AS_STRING)
  protected String totalAmountToIntegrateNAsString;

  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INTEGRATE_N1_AS_STRING)
  protected String totalAmountToIntegrateN1AsString;
  
  @JsonbProperty(JSON_TOTAL_AMOUNT_TO_INTEGRATE_N2_AS_STRING)
  protected String totalAmountToIntegrateN2AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INTEGRATE_N_AS_STRING)
  protected String remainingAmountToIntegrateNAsString;

  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INTEGRATE_N1_AS_STRING)
  protected String remainingAmountToIntegrateN1AsString;
  
  @JsonbProperty(JSON_REMAINING_AMOUNT_TO_INTEGRATE_N2_AS_STRING)
  protected String remainingAmountToIntegrateN2AsString;
  
  // Completed

  @JsonbProperty(JSON_COMPLETED)
  protected Boolean completed;

  @JsonbProperty(JSON_COMPLETED_N)
  protected Boolean completedN;

  @JsonbProperty(JSON_COMPLETED_N1)
  protected Boolean completedN1;

  @JsonbProperty(JSON_COMPLETED_N2)
  protected Boolean completedN2;
  
  // Progress
  
  @JsonbProperty(JSON_INPUT_PROGRESS_PERCENTAGE_N_AS_STRING)
  protected String inputProgressPercentageNAsString;
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
