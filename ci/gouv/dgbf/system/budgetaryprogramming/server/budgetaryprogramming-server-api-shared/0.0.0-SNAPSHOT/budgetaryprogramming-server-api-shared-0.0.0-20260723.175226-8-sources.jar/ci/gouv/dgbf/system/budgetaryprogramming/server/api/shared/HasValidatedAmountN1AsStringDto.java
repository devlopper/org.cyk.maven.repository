package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant validé pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountN1AsStringDto extends HasValidatedAmountN1AsString {

  /**
   * Identifiant json du montant validé pour l'année N+1.
   */
  String JSON_VALIDATED_AMOUNT_N1_AS_STRING = "montantValideN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName