package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassClient;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeClassService.GradeClassGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link GradeClassDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class GradeClassSelectOneController extends AbstractSelectOneIdentifiableController<
    GradeClassDto, GradeClassGetManyResponseDto, GradeClassClient> {

  @Getter
  @Inject
  GradeClassClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected GradeClassSelectOneController() {
    super(GradeClassDto.class, SelectItemLabelStrategy.NAME);
  }
}
