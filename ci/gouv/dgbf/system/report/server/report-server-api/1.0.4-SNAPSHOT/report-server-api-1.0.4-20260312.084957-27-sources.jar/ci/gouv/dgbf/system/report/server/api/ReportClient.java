package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.AbstractExecutableReturningResponse;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.report.server.api.ReportService.GetBytesByIdentifierRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ParameterDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportCreateRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportGetManyResponseDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Setter;

/**
 * Cette classe représente le client du service ReportService.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
@Setter
public class ReportClient extends AbstractClient<ReportService>
    implements GetByIdentifier<ReportDto>, GetMany<ReportGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ReportClient service(ReportService service) {
    return (ReportClient) super.service(service);
  }


  /**
   * {@link ReportService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ReportCreateRequestDto request) {
    return new CreateExecutor(ReportService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ReportService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportService.ReportGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ReportGetManyResponseDto>(
        ReportService.ReportGetManyResponseDto.class, ReportService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ReportService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReportService.ReportGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ReportService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ReportDto>(ReportDto.class, ReportService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ReportService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReportDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Cette méthode permet d'obtenir les octets par identifiant.
   *
   * @param request requête
   * @return octets
   */
  public byte[] getBytesByIdentifier(GetBytesByIdentifierRequestDto request) {
    return new GetBytesByIdentifierService().execute(() -> service().getBytesByIdentifier(request));
  }

  /**
   * Cette méthode permet d'obtenir les octets par identifiant.
   *
   * @param identifier identifiant
   * @param fileType type de fichier
   * @param parameters paramètres
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return octets
   */
  public byte[] getBytesByIdentifier(String identifier, String fileType,
      List<ParameterDto> parameters, String auditWho, String auditSession) {
    GetBytesByIdentifierRequestDto request = new GetBytesByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setFileType(fileType);
    request.setParameters(parameters);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getBytesByIdentifier(request);
  }

  class GetBytesByIdentifierService extends AbstractExecutableReturningResponse<byte[]> {

    GetBytesByIdentifierService() {
      super(ReportService.GET_BYTES_BY_IDENTIFIER_IDENTIFIER);
    }

    @Override
    protected byte[] processWhenExpectedResponseStatus(Response response) {
      return response.readEntity(byte[].class);
    }
  }

  /**
   * {@link ReportService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ReportDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ReportDto>(ReportDto.class,
        ReportService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ReportService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReportDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ReportService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ReportUpdateRequestDto request) {
    return new IdentifiableExecutor(ReportService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ReportService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ReportService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ReportService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
