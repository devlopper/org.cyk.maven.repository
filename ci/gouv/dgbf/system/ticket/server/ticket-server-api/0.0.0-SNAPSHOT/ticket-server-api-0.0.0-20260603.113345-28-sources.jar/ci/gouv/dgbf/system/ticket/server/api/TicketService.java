package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusCommentDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasContestableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasDiagnosticDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasResolvableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSatisfiableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSolutionDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Path(value = TicketService.PATH)
@Tag(name = "Gestion des tickets")
public interface TicketService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "tickets";


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   */
  interface TicketSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return la description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description la description
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FunctionalDomainDto}.
     *
     * @return identifiant de {@link FunctionalDomainDto}
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionalDomainDto}.
     *
     * @param domainIdentifier identifiant de {@link FunctionalDomainDto}
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe de fichiers.
     *
     * @return identifiant du groupe de fichiers
     */
    String getFilesGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe de fichiers.
     *
     * @param filesGroupIdentifier identifiant du groupe de fichiers
     */
    void setFilesGroupIdentifier(String filesGroupIdentifier);

    /**
     * Identifiant json identifiant de la description.
     */
    String JSON_DESCRIPTION = HasDescriptionDto.JSON_DESCRIPTION;

    /**
     * Identifiant json identifiant de {@link FunctionalDomainDto}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * Identifiant json identifiant du groupe de fichiers.
     */
    String JSON_FILES_GROUP_IDENTIFIER = HasFilesGroupIdentifierDto.JSON_FILES_GROUP_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TICKET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TicketCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements TicketSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TICKET";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class TicketGetManyResponseDto extends AbstractGetByPageResponseDto<TicketDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TicketDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TICKET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TICKET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_TICKET";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir compte {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TICKET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TicketUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketUpdateRequestDto extends ByIdentifierRequestDto implements TicketSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TICKET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TicketDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto implements HasStatusDto<TicketStatus>,
      HasClaimableDto, HasResolvableDto, HasSatisfiableDto, HasContestableDto {

    @JsonbProperty(JSON_STATUS)
    private TicketStatus status;

    @JsonbProperty(JSON_CLAIMABLE)
    private Boolean claimable;

    @JsonbProperty(JSON_RESOLVABLE)
    private Boolean resolvable;

    @JsonbProperty(JSON_SATISFIABLE)
    private Boolean satisfiable;

    @JsonbProperty(JSON_CONTESTABLE)
    private Boolean contestable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link TicketStatus}
     */
    public void initialize(TicketStatus status) {
      this.status = status;
    }
  }

  /**
   * Identifiant du service de prise en charge .
   */
  String CLAIM_IDENTIFIER = "PRISE_EN_CHARGE_TICKET";

  /**
   * Chemin du service prise en charge .
   */
  String CLAIM_PATH = "prise-en-charge";

  /**
   * Cette méthode permet de prendre en charge .
   *
   * @param request requête
   * @return réponse
   */
  @Path(CLAIM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CLAIM_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketClaimResponseDto.class))})
  Response claim(TicketClaimRequestDto request);

  /**
   * Cette classe représente la requête de prise en charge.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketClaimRequestDto extends ByIdentifierRequestDto
      implements HasUserIdentifierDto, HasCategoryIdentifierDto, HasPriorityIdentifierDto {

    @JsonbProperty(JSON_USER_IDENTIFIER)
    private String userIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
    private String priorityIdentifier;
  }

  /**
   * Cette classe représente la réponse de prise en charge.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketClaimResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de la resolution.
   */
  String RESOLVE_IDENTIFIER = "RESOLUTION_TICKET";

  /**
   * Chemin du service de résolution.
   */
  String RESOLVE_PATH = "resolution";

  /**
   * Cette méthode permet de résoudre .
   *
   * @param request requête
   * @return réponse
   */

  @Path(RESOLVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = RESOLVE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketResolveResponseDto.class))})
  Response resolve(TicketResolveRequestDto request);

  /**
   * Cette classe représente la requête de la resolution.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketResolveRequestDto extends ByIdentifierRequestDto
      implements HasDiagnosticDto, HasSolutionDto {

    @JsonbProperty(JSON_DIAGNOSTIC)
    private String diagnostic;

    @JsonbProperty(JSON_SOLUTION)
    private String solution;
  }

  /**
   * Cette classe représente la réponse de la résolution.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketResolveResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de la satisfaction.
   */
  String SATISFY_IDENTIFIER = "SATISFACTION_TICKET";

  /**
   * Chemin du service de satisfaction.
   */
  String SATISFY_PATH = "satisfaction";

  /**
   * Cette méthode permet de satisfaire .
   *
   * @param request requête
   * @return réponse
   */

  @Path(SATISFY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = SATISFY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketSatisfyResponseDto.class))})
  Response satisfy(TicketSatisfyRequestDto request);

  /**
   * Cette classe représente la requête de satisfaction.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketSatisfyRequestDto extends ByIdentifierRequestDto
      implements HasStatusCommentDto, HasFilesGroupIdentifierDto {

    @JsonbProperty(JSON_STATUS_COMMENT)
    private String statusComment;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Cette classe représente la réponse de la satisfaction.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketSatisfyResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de l'insatisfaction.
   */
  String DISSATISFY_IDENTIFIER = "INSATISFACTION_TICKET";

  /**
   * Chemin du service de l'insatisfaction.
   */
  String DISSATISFY_PATH = "insatisfaction";

  /**
   * Cette méthode permet d'insatisfaire .
   *
   * @param request requête
   * @return réponse
   */

  @Path(DISSATISFY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DISSATISFY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketDissatisfyResponseDto.class))})
  Response dissatisfy(TicketDissatisfyRequestDto request);

  /**
   * Cette classe représente la requête de l'insatisfaction.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketDissatisfyRequestDto extends ByIdentifierRequestDto
      implements HasStatusCommentDto, HasFilesGroupIdentifierDto {
    @JsonbProperty(JSON_STATUS_COMMENT)
    private String statusComment;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Cette classe représente la réponse de l'insatisfaction.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketDissatisfyResponseDto extends ProcessResponseDto {

  }
  
  /**
   * Identifiant du service de redirection.
   */
  String REDIRECT_IDENTIFIER = "REDIRECTION_TICKET";

  /**
   * Chemin du service de redirection.
   */
  String REDIRECT_PATH = "redirection";

  /**
   * Cette méthode permet de rediriger .
   *
   * @param request requête
   * @return réponse
   */

  @Path(REDIRECT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = REDIRECT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketRedirectResponseDto.class))})
  Response redirect(TicketRedirectRequestDto request);

  /**
   * Cette classe représente la requête de redirection.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketRedirectRequestDto extends ByIdentifierRequestDto
      implements HasStatusCommentDto, HasFilesGroupIdentifierDto {
    @JsonbProperty(JSON_STATUS_COMMENT)
    private String statusComment;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Cette classe représente la réponse de redirection.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketRedirectResponseDto extends ProcessResponseDto {

  }
  
  /**
   * Identifiant du service d'escalade.
   */
  String ESCALATE_IDENTIFIER = "ESCALADE_TICKET";

  /**
   * Chemin du service de redirection.
   */
  String ESCALATE_PATH = "escalade";

  /**
   * Cette méthode permet de d'escalader .
   *
   * @param request requête
   * @return réponse
   */
  @Path(ESCALATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = ESCALATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TicketEscalateResponseDto.class))})
  Response escalate(TicketEscalateRequestDto request);

  /**
   * Cette classe représente la requête d'escalade.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketEscalateRequestDto extends ByIdentifierRequestDto
      implements HasStatusCommentDto, HasFilesGroupIdentifierDto {
    @JsonbProperty(JSON_STATUS_COMMENT)
    private String statusComment;

    @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
    private String filesGroupIdentifier;
  }

  /**
   * Cette classe représente la réponse d'escalade.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TicketEscalateResponseDto extends ProcessResponseDto {

  }
}
