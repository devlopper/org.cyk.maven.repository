package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link ClaimableCascadeDependencyDto}.
 * N'étend pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais
 * {@link SpecificService} -- {@link ClaimableCascadeDependencyDto} n'a ni code ni nom propres.
 *
 * @author akm
 *
 */
@Path(ClaimableCascadeDependencyService.PATH)
@Tag(name = "Gestion des cascades de réclamables")
public interface ClaimableCascadeDependencyService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "cascades-reclamables";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface ClaimableCascadeDependencySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du Réclamable parent.
     *
     * @return l'identifiant du Réclamable parent
     */
    String getParentClaimableIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du Réclamable parent.
     *
     * @param parentClaimableIdentifier l'identifiant du Réclamable parent
     */
    void setParentClaimableIdentifier(String parentClaimableIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du Réclamable enfant.
     *
     * @return l'identifiant du Réclamable enfant
     */
    String getChildClaimableIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du Réclamable enfant.
     *
     * @param childClaimableIdentifier l'identifiant du Réclamable enfant
     */
    void setChildClaimableIdentifier(String childClaimableIdentifier);

    /**
     * {@link ClaimableCascadeDependencyDto#JSON_PARENT_CLAIMABLE_IDENTIFIER}.
     */
    String JSON_PARENT_CLAIMABLE_IDENTIFIER =
        ClaimableCascadeDependencyDto.JSON_PARENT_CLAIMABLE_IDENTIFIER;

    /**
     * {@link ClaimableCascadeDependencyDto#JSON_CHILD_CLAIMABLE_IDENTIFIER}.
     */
    String JSON_CHILD_CLAIMABLE_IDENTIFIER =
        ClaimableCascadeDependencyDto.JSON_CHILD_CLAIMABLE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ClaimableCascadeDependencyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ClaimableCascadeDependencyCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableCascadeDependencyCreateRequestDto
      extends AbstractCodableNamableCreateRequestJsonDto
      implements ClaimableCascadeDependencySaveRequestDto {

    @JsonbProperty(JSON_PARENT_CLAIMABLE_IDENTIFIER)
    private String parentClaimableIdentifier;

    @JsonbProperty(JSON_CHILD_CLAIMABLE_IDENTIFIER)
    private String childClaimableIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimableCascadeDependencyGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimableCascadeDependencyDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimableCascadeDependencyDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimableCascadeDependencyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimableCascadeDependencyDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ClaimableCascadeDependencyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ClaimableCascadeDependencyUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableCascadeDependencyUpdateRequestDto
      extends AbstractCodableNamableUpdateRequestJsonDto
      implements ClaimableCascadeDependencySaveRequestDto {

    @JsonbProperty(JSON_PARENT_CLAIMABLE_IDENTIFIER)
    private String parentClaimableIdentifier;

    @JsonbProperty(JSON_CHILD_CLAIMABLE_IDENTIFIER)
    private String childClaimableIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ClaimableCascadeDependencyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
