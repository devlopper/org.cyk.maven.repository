package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExerciseDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ExerciseFilter extends AbstractIdentifiableFilter {

  
}

