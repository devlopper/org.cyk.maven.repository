package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link FileGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupFilterController extends AbstractFilterController<FileGroupFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public FileGroupFilterController() {
    super(FileGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setGroupIdentifier(getRequestParameter(FileGroupFilter.JSON_GROUP_IDENTIFIER));
    filter.setGroupsIdentifiers(getRequestParameterValues(FileGroupFilter.JSON_GROUPS_IDENTIFIERS));
  }
}
