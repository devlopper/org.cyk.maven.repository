package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un nom de pièce jointe.
 *
 * @author Christian
 */
public interface HasAttachmentName extends HasField {

  /**
   * Cette méthode permet d'obtenir le nom de la pièce jointe.
   *
   * @return le nom de la pièce jointe
   */
  String getAttachmentName();

  /**
   * Cette méthode permet d'assigner le nom de la pièce jointe.
   *
   * @param attachmentName le nom de la pièce jointe
   */
  void setAttachmentName(String attachmentName);

  /**
   * Identifiant java du nom de la pièce jointe.
   */
  String FIELD_ATTACHMENT_NAME = "attachmentName";
}
