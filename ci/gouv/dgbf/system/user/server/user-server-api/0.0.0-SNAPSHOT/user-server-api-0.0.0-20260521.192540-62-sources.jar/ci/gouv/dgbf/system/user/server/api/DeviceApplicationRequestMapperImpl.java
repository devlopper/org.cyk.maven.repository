package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DeviceApplicationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-21T19:26:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DeviceApplicationRequestMapperImpl implements DeviceApplicationRequestMapper {

    @Override
    public DeviceApplicationService.DeviceApplicationCreateRequestDto mapCreate(DeviceApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeviceApplicationService.DeviceApplicationCreateRequestDto deviceApplicationCreateRequestDto = new DeviceApplicationService.DeviceApplicationCreateRequestDto();

        deviceApplicationCreateRequestDto.setName( arg0.getName() );
        deviceApplicationCreateRequestDto.setApplicationIdentifier( arg0.getApplicationIdentifier() );
        deviceApplicationCreateRequestDto.setDeviceIdentifier( arg0.getDeviceIdentifier() );
        deviceApplicationCreateRequestDto.setRegistrationNumber( arg0.getRegistrationNumber() );
        deviceApplicationCreateRequestDto.setEmail( arg0.getEmail() );
        deviceApplicationCreateRequestDto.setPhoneNumber( arg0.getPhoneNumber() );

        return deviceApplicationCreateRequestDto;
    }

    @Override
    public DeviceApplicationService.DeviceApplicationUpdateRequestDto mapUpdate(DeviceApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeviceApplicationService.DeviceApplicationUpdateRequestDto deviceApplicationUpdateRequestDto = new DeviceApplicationService.DeviceApplicationUpdateRequestDto();

        deviceApplicationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        deviceApplicationUpdateRequestDto.setName( arg0.getName() );
        deviceApplicationUpdateRequestDto.setApplicationIdentifier( arg0.getApplicationIdentifier() );
        deviceApplicationUpdateRequestDto.setDeviceIdentifier( arg0.getDeviceIdentifier() );
        deviceApplicationUpdateRequestDto.setRegistrationNumber( arg0.getRegistrationNumber() );
        deviceApplicationUpdateRequestDto.setEmail( arg0.getEmail() );
        deviceApplicationUpdateRequestDto.setPhoneNumber( arg0.getPhoneNumber() );

        return deviceApplicationUpdateRequestDto;
    }
}
