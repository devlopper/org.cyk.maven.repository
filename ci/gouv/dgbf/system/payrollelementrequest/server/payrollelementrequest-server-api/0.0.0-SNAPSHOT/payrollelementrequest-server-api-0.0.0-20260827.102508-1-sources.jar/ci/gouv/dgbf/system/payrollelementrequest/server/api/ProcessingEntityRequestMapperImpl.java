package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcessingEntityDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-27T10:25:24+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcessingEntityRequestMapperImpl implements ProcessingEntityRequestMapper {

    @Override
    public ProcessingEntityService.ProcessingEntityCreateRequestDto mapCreate(ProcessingEntityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessingEntityService.ProcessingEntityCreateRequestDto processingEntityCreateRequestDto = new ProcessingEntityService.ProcessingEntityCreateRequestDto();

        processingEntityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        processingEntityCreateRequestDto.setCode( arg0.getCode() );
        processingEntityCreateRequestDto.setName( arg0.getName() );
        processingEntityCreateRequestDto.setNature( arg0.getNature() );

        return processingEntityCreateRequestDto;
    }

    @Override
    public ProcessingEntityService.ProcessingEntityUpdateRequestDto mapUpdate(ProcessingEntityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessingEntityService.ProcessingEntityUpdateRequestDto processingEntityUpdateRequestDto = new ProcessingEntityService.ProcessingEntityUpdateRequestDto();

        processingEntityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        processingEntityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        processingEntityUpdateRequestDto.setCode( arg0.getCode() );
        processingEntityUpdateRequestDto.setName( arg0.getName() );
        processingEntityUpdateRequestDto.setNature( arg0.getNature() );

        return processingEntityUpdateRequestDto;
    }
}
