package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente un filtre ayant une notion de code de niveau de log.
 *
 * @author Christian
 */
public interface FilterHasLevelCode extends HasLevelCode {

  /**
   * Cette méthode permet mettre à jour le code de niveau de log.
   *
   * @param filter {@link FilterDto}
   */
  default void updateLevelCode(FilterDto filter) {
    setLevelCode(LevelCodeFilter.get(filter));
  }

  /**
   * Cette méthode permet mettre à jour le code de niveau de log du filtre.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterLevelCode(FilterDto filter) {
    LevelCodeFilter.set(filter, getLevelCode());
  }

}
