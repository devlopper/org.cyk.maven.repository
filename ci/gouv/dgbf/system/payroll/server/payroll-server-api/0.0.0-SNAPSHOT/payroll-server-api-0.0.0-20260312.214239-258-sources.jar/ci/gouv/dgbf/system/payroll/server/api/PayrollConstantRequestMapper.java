package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollConstantService.PayrollConstantCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollConstantService.PayrollConstantUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollConstantDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollConstantDto}.

    @author Christian
               """)
public interface PayrollConstantRequestMapper extends RequestMapper<PayrollConstantDto,
    PayrollConstantCreateRequestDto, PayrollConstantUpdateRequestDto> {

}
