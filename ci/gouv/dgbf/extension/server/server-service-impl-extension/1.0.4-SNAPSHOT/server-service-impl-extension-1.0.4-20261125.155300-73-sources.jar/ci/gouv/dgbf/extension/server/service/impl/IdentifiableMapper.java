package ci.gouv.dgbf.extension.server.service.impl;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import java.util.List;

/**
 * Cette interface représente le mappage entre deux dto.
 *
 * @author Christian
 *
 * @param <S> Source
 * @param <D> Destination
 */
public interface IdentifiableMapper<S extends AbstractIdentifiableDto,
    D extends AbstractIdentifiableDto> {

  D mapToDestination(S identifiable);
  
  List<D> mapToDestination(List<S> identifiables);
}

