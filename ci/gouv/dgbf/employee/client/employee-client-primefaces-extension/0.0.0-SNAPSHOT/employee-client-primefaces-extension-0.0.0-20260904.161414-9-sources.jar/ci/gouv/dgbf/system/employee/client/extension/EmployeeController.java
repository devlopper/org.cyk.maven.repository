package ci.gouv.dgbf.system.employee.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeClient;
import ci.gouv.dgbf.system.employee.server.api.EmployeeDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeImportAllRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link EmployeeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class EmployeeController extends AbstractController {

  @Inject
  EmployeeClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  EmployeeFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = EmployeeDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(EmployeeDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(EmployeeService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        EmployeeDto.JSON_REGISTRATION_NUMBER, EmployeeDto.JSON_EMAIL_ADDRESS,
        EmployeeDto.JSON_FIRST_NAME_AND_LAST_NAMES,
        EmployeeDto.JSON_FIRST_SERVICE_START_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getDataTable().getFilterButton().setRendered(true);
    
    listController.initialize();

    listController.getDataTable().getOrderNumberColumn().setWidth("50");
    listController.getDataTable().setHeaderRendered(false);
    listController.getDataTable().getExportButton().setRendered(false);
    listController.getDataTable().getColumnsButton().setRendered(false);
    listController.getShowCreateDialogButton().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(1);
  }

  /**
   * Cette méthode permet d'importer.
   */
  public void importAll() {
    EmployeeImportAllRequestDto request = new EmployeeImportAllRequestDto();
    request.setAuditWho(userIdentifier);
    new ActionExecutor<>(this, "Importation", () -> client.importAll(request)).execute();
  }
}
