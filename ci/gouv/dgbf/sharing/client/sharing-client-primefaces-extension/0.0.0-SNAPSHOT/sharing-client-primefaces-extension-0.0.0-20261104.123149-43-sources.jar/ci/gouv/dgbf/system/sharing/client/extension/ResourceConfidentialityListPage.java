package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/** Page d'administration de la confidentialite par ressource. */
@Named
@ViewScoped
public class ResourceConfidentialityListPage extends AbstractPage {
  @Inject @Getter ResourceConfidentialityController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ResourceConfidentialityDto.PLURAL_NAME;
    controller.initialize();
  }

  public static final String OUTCOME = "resourceConfidentialityListPage";
}
