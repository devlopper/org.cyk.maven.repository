package ci.gouv.dgbf.extension.primefaces.page;

import ci.gouv.dgbf.extension.primefaces.component.Link;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** Modèle de présentation stable, détenu par le bean de page. */
public final class IdentifiableResolution {
  private IdentifiableResolutionStatus status = IdentifiableResolutionStatus.INITIAL;
  private IdentifiableResolutionStatus presentationStatus = IdentifiableResolutionStatus.INITIAL;
  private String message;
  private String title;
  private String resourceName;
  private final List<Link> navigations = new ArrayList<>();

  public IdentifiableResolutionStatus getStatus() {
    return status;
  }

  public String getMessage() {
    return message;
  }

  public String getTitle() {
    return title;
  }

  /** Titre contextualisé facultatif ; null conserve le titre générique de la vue. */
  public void setTitle(String title) {
    this.title = title;
  }

  /** Libellé métier affiché en surtitre ; null lorsque seul le libellé générique existe. */
  public String getResourceName() {
    return resourceName;
  }

  public void setResourceName(String resourceName) {
    this.resourceName = resourceName;
  }

  public IdentifiableResolutionStatus getPresentationStatus() {
    return presentationStatus;
  }

  public boolean isAvailable() {
    return status == IdentifiableResolutionStatus.AVAILABLE;
  }

  public boolean isLoading() {
    return status == IdentifiableResolutionStatus.LOADING;
  }

  /** Indique si la page doit afficher le panneau de message et de navigation. */
  public boolean isUnavailable() {
    return status == IdentifiableResolutionStatus.MISSING_IDENTIFIER
        || status == IdentifiableResolutionStatus.NO_RESOURCE_AVAILABLE
        || status == IdentifiableResolutionStatus.NOT_FOUND
        || status == IdentifiableResolutionStatus.ACCESS_DENIED
        || status == IdentifiableResolutionStatus.ERROR;
  }

  public List<Link> getNavigations() {
    return List.copyOf(navigations);
  }

  /** Cas courant : ajoute un lien de navigation GET (libellé, outcome JSF). */
  public IdentifiableResolution addNavigation(String value, String outcome) {
    return addNavigation(Link.of(value, outcome));
  }

  /** Cas courant avec paramètres. */
  public IdentifiableResolution addNavigation(String value, String outcome,
      Map<String, List<String>> parameters) {
    return addNavigation(Link.of(value, outcome, parameters));
  }

  /** Cas particulier : ajoute un lien GET ; le premier est présenté comme principal. */
  public IdentifiableResolution addNavigation(Link navigation) {
    Objects.requireNonNull(navigation);
    navigation.setStyleClass("dgbf-resource__link dgbf-resource__link--"
        + (navigations.isEmpty() ? "primary" : "secondary"));
    navigations.add(navigation);
    return this;
  }

  public void update(IdentifiableResolutionStatus status, String message) {
    update(status, message, false);
  }

  /** Sépare la cause interne de sa présentation publique lorsque l'accès doit être masqué. */
  public void update(IdentifiableResolutionStatus status, String message,
      boolean hideAccessDenied) {
    this.status = Objects.requireNonNull(status);
    presentationStatus = hideAccessDenied && status == IdentifiableResolutionStatus.ACCESS_DENIED
        ? IdentifiableResolutionStatus.NOT_FOUND : status;
    this.message = message;
    title = null;
  }

  /** Vérifie la présence d'une issue de navigation avant la résolution. */
  public void validate() {
    if (navigations.isEmpty()) {
      throw new IllegalStateException("Au moins une navigation de page de ressource est requise");
    }
  }
}
