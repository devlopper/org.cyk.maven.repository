package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementService.PayrollElementGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollElementDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollElementDto, PayrollElementGetManyResponseDto, PayrollElementClient> {

  @Getter
  @Inject
  PayrollElementClient client;

  protected PayrollElementSelectOneController() {
    super(PayrollElementDto.class, SelectItemLabelStrategy.NAME);
  }
}
