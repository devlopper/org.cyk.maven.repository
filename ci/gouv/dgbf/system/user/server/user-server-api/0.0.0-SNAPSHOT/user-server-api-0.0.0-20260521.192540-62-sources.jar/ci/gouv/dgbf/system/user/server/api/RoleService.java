package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RoleDto}.
 *
 * @author Christian
 */
@Path(value = RoleService.PATH)
@Tag(name = "Gestion des roles")
public interface RoleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "roles";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface RoleSaveRequestDto {


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ApplicationDto}.
     *
     * @return identifiant de {@link ApplicationDto}
     */
    String getApplicationIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ApplicationDto}.
     *
     * @param applicationIdentifier identifiant de {@link ApplicationDto}
     */
    void setApplicationIdentifier(String applicationIdentifier);

    /**
     * Identifiant json identifiant de {@link ApplicationDto}.
     */
    String JSON_APPLICATION_IDENTIFIER = ApplicationDto.JSON_THIS_IDENTIFIER;

    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return la description
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description la description
     */
    void setDescription(String description);

    /**
     * {@link RoleDto#JSON_DESCRIPTION}.
     */
    String JSON_DESCRIPTION = RoleDto.JSON_DESCRIPTION;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ROLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RoleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class RoleCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements RoleSaveRequestDto {

    @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
    private String applicationIdentifier;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ROLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  public static class RoleGetManyResponseDto extends AbstractGetByPageResponseDto<RoleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RoleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ROLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ROLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ROLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RoleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class RoleUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements RoleSaveRequestDto {

    @JsonbProperty(JSON_APPLICATION_IDENTIFIER)
    private String applicationIdentifier;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UN_ROLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link RoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'attribution.
   */
  String ASSIGN_IDENTIFIER = "ATTRIBUTION_ROLE";

  /**
   * Chemin du service d'attribution.
   */
  String ASSIGN_ROLE_PATH = "attribution";

  /**
   * Cette méthode permet d'attribuer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ASSIGN_ROLE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ASSIGN_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleAssignResponseDto.class))})
  Response assign(RoleAssignRequestDto request);

  /**
   * Cette classe représente la requête d'attribution.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class RoleAssignRequestDto extends ByIdentifierRequestDto {

    /**
     * Liste des identifiants des utilisateurs.
     */
    @JsonbProperty(JSON_USER_IDENTIFIERS)
    private Set<String> userIdentifiers;

    /**
     * Identifiant json {@link #userIdentifiers}.
     */
    public static final String JSON_USER_IDENTIFIERS = "idUtilisateurs";

  }

  /**
   * Cette classe représente la réponse d'attribution.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class RoleAssignResponseDto extends IdentifiableResponseDto {

    /**
     * Nombre total d'utilisateurs traités.
     */
    @JsonbProperty(JSON_CREATED_COUNT)
    private Integer createdCount;

    /**
     * Nombre d'attributions réussies.
     */
    @JsonbProperty(JSON_EXISTING_COUNT)
    private Integer existingCount;

    /**
     * Identifiant json {@link #createdCount}.
     */
    public static final String JSON_CREATED_COUNT = "nombreCree";

    /**
     * Identifiant json {@link #existingCount}.
     */
    public static final String JSON_EXISTING_COUNT = "nombreExistant";
  }

  /**
   * Identifiant du service de retrait.
   */
  String REVOKE_IDENTIFIER = "RETRAIT_ROLE";

  /**
   * Chemin du service de retrait.
   */
  String REVOKE_ROLE_PATH = "retrait";

  /**
   * Cette méthode permet de retirer un rôle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REVOKE_ROLE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REVOKE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RoleRevokeResponseDto.class))})
  Response revoke(RoleRevokeRequestDto request);

  /**
   * Cette classe représente la requête de retrait.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleRevokeRequestDto extends ByIdentifierRequestDto {

    /**
     * Liste des identifiants des utilisateurs.
     */
    @JsonbProperty(JSON_USER_IDENTIFIERS)
    private Set<String> userIdentifiers;

    /**
     * Identifiant json {@link #userIdentifiers}.
     */
    public static final String JSON_USER_IDENTIFIERS = "idUtilisateurs";

  }

  /**
   * Cette classe représente la réponse de retrait.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleRevokeResponseDto extends IdentifiableResponseDto {

    /**
     * Nombre de retraits réussis.
     */
    @JsonbProperty(JSON_REVOKED_COUNT)
    private Integer revokedCount;

    /**
     * Nombre d'utilisateurs n'ayant pas le rôle.
     */
    @JsonbProperty(JSON_NOT_FOUND_COUNT)
    private Integer notFoundCount;

    /**
     * Identifiant json {@link #revokedCount}.
     */
    public static final String JSON_REVOKED_COUNT = "nombreRetire";

    /**
     * Identifiant json {@link #notFoundCount}.
     */
    public static final String JSON_NOT_FOUND_COUNT = "nombreNonTrouve";
  }

  /**
   * Identifiant du service d'attribution administrateur.
   */
  String ASSIGN_SYSTEM_ADMINISTRATOR_IDENTIFIER = "ATTRIBUTION_ADMINISTRATEUR_SYSTEME_ROLE";

  /**
   * Chemin du service d'attribution administrateur.
   */
  String ASSIGN_SYSTEM_ADMINISTRATOR_PATH = "attribution/administrateur-systeme";

  /**
   * Cette méthode permet d'attribuer d'un rôle.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ASSIGN_SYSTEM_ADMINISTRATOR_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ASSIGN_SYSTEM_ADMINISTRATOR_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RoleAssignSystemAdministratorResponseDto.class))})
  Response assignSystemAdministrator(RoleAssignSystemAdministratorRequestDto request);

  /**
   * Cette classe représente la requête d'attribution administrateur.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleAssignSystemAdministratorRequestDto extends AbstractRequestDto {

    /**
     * Liste des identifiants des utilisateurs.
     */
    @JsonbProperty(JSON_USER_IDENTIFIERS)
    private Set<String> userIdentifiers;

    /**
     * Identifiant json {@link #userIdentifiers}.
     */
    public static final String JSON_USER_IDENTIFIERS = "idUtilisateurs";

  }

  /**
   * Cette classe représente la réponse d'attribution administrateur.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class RoleAssignSystemAdministratorResponseDto extends AbstractResponseDto {

    /**
     * Nombre d'attributions administrateur réussies.
     */
    @JsonbProperty(JSON_ASSIGNED_ADMIN_COUNT)
    private Integer assignedAdminCount;

    /**
     * Identifiant json {@link #assignedAdminCount}.
     */
    public static final String JSON_ASSIGNED_ADMIN_COUNT = "nombreAdministrateurAttribue";
  }
}