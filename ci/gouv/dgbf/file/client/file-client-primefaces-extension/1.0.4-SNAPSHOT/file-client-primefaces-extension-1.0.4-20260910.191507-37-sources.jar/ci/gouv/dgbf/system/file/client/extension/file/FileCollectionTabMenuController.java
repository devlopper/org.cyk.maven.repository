package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTabMenuController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileFilter;
import ci.gouv.dgbf.system.file.server.api.OwnerClient;
import ci.gouv.dgbf.system.file.server.api.OwnerDto;
import ci.gouv.dgbf.system.file.server.api.OwnerService.OwnerGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de collection de {@link FileDto},
 * un onglet par {@link OwnerDto} (Propriétaire) déjà utilisateur de fichiers.
 *
 * @author Christian
 */
@Dependent
public class FileCollectionTabMenuController extends AbstractTabMenuController {

  @Inject
  OwnerClient ownerClient;

  @Getter
  String ownerIdentifierParameterName;

  /**
   * Cette méthode permet de construire.
   */
  public FileCollectionTabMenuController() {
    menu.setMenuItemStyleClassPrefix("file");
    addPage(FileListPage.class, FileListPage.OUTCOME);
    ownerIdentifierParameterName = FileFilter.JSON_OWNER_IDENTIFIER;
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();

    menu.tabBuilder().menuItemValue("Tout").type(FileListPage.class).build();

    addMenuTabsFromOwners();
  }

  void addMenuTabsFromOwners() {
    owners().forEach(this::addMenuTabFromOwner);
  }

  List<OwnerDto> owners() {
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableNamableDto.JSON_NAME);
    OwnerGetManyResponseDto response =
        ownerClient.getMany(projection, null, new PageDto(0, 200), userIdentifier, null);
    return Optional.ofNullable(response).map(r -> r.getDatas())
        .orElse(Collections.emptyList());
  }

  void addMenuTabFromOwner(OwnerDto owner) {
    menu.tabBuilder().menuItemValue(owner.getName()).type(FileListPage.class)
        .addMenuItemParameter(ownerIdentifierParameterName, owner.getIdentifier()).build();
  }
}
