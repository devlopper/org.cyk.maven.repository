package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N, sous forme
 * de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountNAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant saisi à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @return le montant saisi à l'horizon N, sous forme de chaîne de caractères
   */
  String getInputtedAmountNAsString();

  /**
   * Cette méthode permet d'assigner le montant saisi à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @param amount le montant saisi à l'horizon N, sous forme de chaîne de caractères
   */
  void setInputtedAmountNAsString(String amount);

  /**
   * Identifiant java du montant saisi à l'horizon N, sous forme de chaîne de caractères.
   */
  String FIELD_INPUTTED_AMOUNT_N_AS_STRING = "inputtedAmountNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
