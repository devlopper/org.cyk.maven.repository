package ci.gouv.dgbf.extension.primefaces.template;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.context.FacesContext;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import java.util.Optional;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette class représente le gestionnaire du conteneur.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Getter
@Setter
@Named
public class ContainerManager {

  private String sidebar;
  private String layout;
  private String topbar;
  private String sidebarSize;
  private String sidebarImage;
  private String preloader;
  private String theme;
  private String themeColors;
  private String sidebarVisibility;
  private String layoutStyle;
  private String bsTheme;
  private String layoutWidth;
  private String layoutPosition;
  private String bodyImage;
  private String sidebarUserShow;
  private String styleContentColorManager;

  /**
   * Active l'identité visuelle DGBF (la charte graphique, constitution-ui.md §3.4) sur les écrans
   * privés. Faux par défaut : chaque module l'active par {@value #BRAND_ENABLED_PROPERTY} dans sa
   * configuration.
   */
  @ConfigProperty(name = BRAND_ENABLED_PROPERTY, defaultValue = "false")
  boolean brandEnabled;

  /**
   * Charge le socle de style de la disposition (Bootstrap, app.css, position.css,
   * menu.css et header.css) depuis ce jar au lieu des copies embarquées par l'application dans
   * {@code resources/assets/global}. Faux par défaut : chaque module l'active par
   * {@value #BASE_STYLE_FROM_JAR_PROPERTY} après avoir retiré ses copies.
   */
  @ConfigProperty(name = BASE_STYLE_FROM_JAR_PROPERTY, defaultValue = "false")
  boolean baseStyleFromJar;

  /**
   * Charge {@code resources/assets/global/global-import.css} de l'application. Vrai par défaut :
   * tant qu'un module y garde des feuilles (boutons, tableaux, dialogues), il doit rester chargé.
   * Un module dont ce fichier ne contient plus rien le désactive par
   * {@value #GLOBAL_IMPORT_PROPERTY} et peut alors le supprimer.
   */
  @ConfigProperty(name = GLOBAL_IMPORT_PROPERTY, defaultValue = "true")
  boolean globalImport;

  /**
   * Adresse de « Mon profil » (module user). Absente : déduite de l'adresse de la requête et de
   * {@value #USER_CONTEXT_PATH_PROPERTY} (constitution-client-quarkus-primefaces.md §5.5).
   */
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = USER_PROFILE_URL_PROPERTY)
  Optional<String> userProfileUrl = Optional.empty();

  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = USER_CONTEXT_PATH_PROPERTY, defaultValue = "/utilisateur")
  String userContextPath = "/utilisateur";

  /**
   * Adresse de « Mon activité » (module logging). Absente : déduite comme pour le profil, avec
   * {@value #LOGGING_CONTEXT_PATH_PROPERTY}.
   */
  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = LOGGING_ACTIVITY_URL_PROPERTY)
  Optional<String> loggingActivityUrl = Optional.empty();

  @Getter(AccessLevel.NONE)
  @Setter(AccessLevel.NONE)
  @ConfigProperty(name = LOGGING_CONTEXT_PATH_PROPERTY, defaultValue = "/logging")
  String loggingContextPath = "/logging";

  /**
   * Cette méthode donne le lien vers « Mon profil ».
   *
   * @return l'adresse configurée, sinon celle du module user sur l'hôte de la requête
   */
  public String getUserProfileLink() {
    return link(userProfileUrl, userContextPath, USER_PROFILE_PATH);
  }

  /**
   * Cette méthode donne le lien vers « Mon activité ».
   *
   * @return l'adresse configurée, sinon celle du module logging sur l'hôte de la requête
   */
  public String getActivityLink() {
    return link(loggingActivityUrl, loggingContextPath, ACTIVITY_PATH);
  }

  String link(Optional<String> configured, String targetContextPath, String targetPath) {
    Object request = currentRequest();
    if (request instanceof HttpServletRequest servletRequest) {
      return AccountLinks.resolve(configured.orElse(null), servletRequest.getScheme(),
          servletRequest.getServerName(), servletRequest.getServerPort(),
          servletRequest.getContextPath(), targetContextPath, targetPath);
    }
    return configured.orElse(targetContextPath + targetPath);
  }

  Object currentRequest() {
    FacesContext context = FacesContext.getCurrentInstance();
    return context == null ? null : context.getExternalContext().getRequest();
  }

  /**
   * Indique si l'identité visuelle est active.
   *
   * @return la valeur de {@value #BRAND_ENABLED_PROPERTY}
   */
  public boolean isBrandEnabled() {
    return brandEnabled;
  }

  /**
   * Cette méthode calcule les initiales de l'avatar d'un utilisateur.
   *
   * @param names le nom et les prénoms
   * @return les initiales, vides si le nom ne contient aucune lettre
   */
  public String avatarInitials(String names) {
    return UserAvatar.initials(names);
  }

  /**
   * Cette méthode calcule la teinte de l'avatar d'un utilisateur.
   *
   * @param names le nom et les prénoms
   * @return l'indice de teinte, stable pour un même nom
   */
  public int avatarTone(String names) {
    return UserAvatar.tone(names);
  }

  /**
   * Cette méthode permet de construire.
   */
  public ContainerManager() {
    layout = "semibox";
    topbar = "light";
    sidebar = "dark";
    sidebarSize = "lg";
    sidebarImage = "none";
    preloader = "disable";
    theme = "saas";
    themeColors = "default";
    sidebarVisibility = "show";
    layoutStyle = "default";
    bsTheme = "";
    layoutWidth = "fluid";
    layoutPosition = "fixed";
    bodyImage = "none";
    sidebarUserShow = "";
    styleContentColorManager = "";
  }

  static final String BRAND_ENABLED_PROPERTY = "dgbf.brand.enabled";
  static final String BASE_STYLE_FROM_JAR_PROPERTY = "dgbf.template.base-style-from-jar";
  static final String GLOBAL_IMPORT_PROPERTY = "dgbf.template.global-import";
  static final String USER_PROFILE_URL_PROPERTY = "dgbf.user.profile.url";
  static final String USER_CONTEXT_PATH_PROPERTY = "dgbf.user.context-path";
  static final String LOGGING_ACTIVITY_URL_PROPERTY = "dgbf.logging.activity.url";
  static final String LOGGING_CONTEXT_PATH_PROPERTY = "dgbf.logging.context-path";
  static final String USER_PROFILE_PATH = "/private/connecteduser/read/applications.jsf";
  static final String ACTIVITY_PATH = "/private/activity/user/index.jsf";
}
