package ci.gouv.dgbf.system.datastructures.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'intervalle de période.
 *
 * @author Christian
 */
public interface HasPeriodIntervalIdentifierDto extends HasPeriodIntervalIdentifier {

  /**
   * Identifiant json de l'identifiant de l'intervalle de période.
   */
  String JSON_PERIOD_INTERVAL_IDENTIFIER = "idIntervallePeriode";
}