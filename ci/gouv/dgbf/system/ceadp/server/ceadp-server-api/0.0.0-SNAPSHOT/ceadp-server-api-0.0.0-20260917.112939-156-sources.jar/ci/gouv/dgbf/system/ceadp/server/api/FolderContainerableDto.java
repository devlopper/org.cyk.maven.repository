package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link FolderDto}.
 *
 * @author Christian
 *
 */
public interface FolderContainerableDto extends FolderContainerable {

  /**
   * Identifiant json {@link FolderContainerableDto#getFolderCount()}.
   */
  String JSON_FOLDER_COUNT = "nombreDossier";
  
  /**
   * Identifiant json {@link FolderContainerableDto#getFolderCountAsString()}.
   */
  String JSON_FOLDER_COUNT_AS_STRING = JSON_FOLDER_COUNT + "Chaine";
}
