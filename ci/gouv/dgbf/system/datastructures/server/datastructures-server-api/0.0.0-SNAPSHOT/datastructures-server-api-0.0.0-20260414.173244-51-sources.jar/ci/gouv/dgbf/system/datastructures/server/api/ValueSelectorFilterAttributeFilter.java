package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasValueSelectorIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ValueSelectorFilterAttributeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ValueSelectorFilterAttributeFilter extends AbstractIdentifiableFilter
    implements FilterHasValueSelectorIdentifier {

  private String valueSelectorIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ValueSelectorFilterAttributeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ValueSelectorFilterAttributeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateValueSelectorIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterValueSelectorIdentifier(filter);
  }

}
