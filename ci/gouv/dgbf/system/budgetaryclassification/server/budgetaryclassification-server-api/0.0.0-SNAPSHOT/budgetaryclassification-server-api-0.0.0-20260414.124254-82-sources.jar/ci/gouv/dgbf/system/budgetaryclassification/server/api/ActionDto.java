package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une action.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ActionDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER)
  private String budgetSpecializationUnitIdentifier;

  @JsonbProperty(JSON_BUDGET_SPECIALIZATION_UNIT_AS_STRING)
  private String budgetSpecializationUnitAsString;


  /**
   * Identifiant json champ {@link #budgetSpecializationUnitIdentifier}.
   */
  public static final String JSON_BUDGET_SPECIALIZATION_UNIT_IDENTIFIER =
      BudgetSpecializationUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #budgetSpecializationUnitAsString}.
   */
  public static final String JSON_BUDGET_SPECIALIZATION_UNIT_AS_STRING =
      BudgetSpecializationUnitDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant json de identifiant de {@link ActionDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idAction";

  /**
   * Identifiant json de représentation en chaine de caractères de.
   * {@link ActionDto}.
   */
  public static final String JSON_THIS_AS_STRING = "actionChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "action";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}

