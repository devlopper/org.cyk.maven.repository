package ci.gouv.dgbf.system.ticket.server.api;


import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasSupportTeamIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DomainLevelDto}.
 *
 * @author kimou
 *
 */
@Getter
@Setter
public class DomainLevelFilter extends AbstractIdentifiableFilter
    implements FilterHasSupportTeamIdentifier {

  private String supportTeamIdentifier;

  /**
   * Cette méthode permet de construire.
   *
   * @param dto {@link FilterDto}
   */
  public DomainLevelFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet de construire.
   */
  public DomainLevelFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateSupportTeamIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterSupportTeamIdentifier(filter);
  }

}

