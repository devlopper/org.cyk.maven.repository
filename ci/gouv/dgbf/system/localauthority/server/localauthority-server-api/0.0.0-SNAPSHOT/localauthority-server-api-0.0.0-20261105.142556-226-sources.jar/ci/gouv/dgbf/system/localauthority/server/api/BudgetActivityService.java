package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 */
@Path(value = BudgetActivityService.PATH)
@Tag(name = "Gestion des activités de budgets")
public interface BudgetActivityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites-budgets";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Donsylla
   */
  interface BudgetActivitySaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant du budget.
     *
     * @return identifiant du budget
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du budget.
     *
     * @param budgetIdentifier identifiant du budget
     */
    void setBudgetIdentifier(String budgetIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'activité.
     *
     * @return identifiant de l'activité
     */
    String getActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'activité.
     *
     * @param activityIdentifier identifiant de l'activité
     */
    void setActivityIdentifier(String activityIdentifier);

    /**
     * {@link BudgetActivityDto#JSON_BUDGET_IDENTIFIER}.
     */
    String JSON_BUDGET_IDENTIFIER = BudgetActivityDto.JSON_BUDGET_IDENTIFIER;

    /**
     * {@link BudgetActivityDto#JSON_ACTIVITY_IDENTIFIER}.
     */
    String JSON_ACTIVITY_IDENTIFIER = BudgetActivityDto.JSON_ACTIVITY_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE_BUDGET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une activité de budget",
      description = "Ce service permet de créer une activité de budget")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BudgetActivityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetActivityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements BudgetActivitySaveRequestDto {
    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    private String budgetIdentifier;

    /**
     * Identifiant d'une activité existante. Lorsqu'il n'est pas renseigné, l'activité est créée
     * à partir des éléments ci-dessous.
     */
    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_ACTION_IDENTIFIER)
    private String actionIdentifier;

    @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;

    /**
     * Identifiant json champ {@link #name}.
     */
    public static final String JSON_NAME = AbstractIdentifiableCodableNamableDto.JSON_NAME;

    /**
     * Identifiant json champ {@link #actionIdentifier}.
     */
    public static final String JSON_ACTION_IDENTIFIER = ActivityDto.JSON_ACTION_IDENTIFIER;

    /**
     * Identifiant json champ {@link #functionalAccountIdentifier}.
     */
    public static final String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER =
        ActivityDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER;

    /**
     * Identifiant json champ {@link #natureIdentifier}.
     */
    public static final String JSON_NATURE_IDENTIFIER = ActivityDto.JSON_NATURE_IDENTIFIER;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITES_BUDGETS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des activités de budgets")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = BudgetActivityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  public static class BudgetActivityGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetActivityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BudgetActivityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE_BUDGET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetActivityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE_BUDGET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetActivityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE_BUDGET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BudgetActivityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetActivityUpdateRequestDto extends ByIdentifierRequestDto
      implements BudgetActivitySaveRequestDto {
    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    private String budgetIdentifier;

    /**
     * Identifiant de l'activité. Lorsqu'il n'est pas renseigné, l'activité rattachée est
     * conservée.
     */
    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(BudgetActivityCreateRequestDto.JSON_NAME)
    private String name;

    @JsonbProperty(BudgetActivityCreateRequestDto.JSON_ACTION_IDENTIFIER)
    private String actionIdentifier;

    @JsonbProperty(BudgetActivityCreateRequestDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(BudgetActivityCreateRequestDto.JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE_BUDGET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link BudgetActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une activité de budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
