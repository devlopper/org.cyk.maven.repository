package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link IdentityEmailAddressDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum IdentityEmailAddressStatus {

  /**
   * #{@link IdentityEmailAddressStatusCode#CREATED}.
   */
  CREATED(IdentityEmailAddressStatusCode.CREATED, "Créé", "Création"),

  /**
   * #{@link IdentityEmailAddressStatusCode#VERIFIED}.
   */
  VERIFIED(IdentityEmailAddressStatusCode.VERIFIED, "Vérifié", "Vérification"),

  /**
   * #{@link IdentityEmailAddressStatusCode#REVOKED}.
   */
  REVOKED(IdentityEmailAddressStatusCode.REVOKED, "Revoqué", "Revocation");


  private IdentityEmailAddressStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<IdentityEmailAddressStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link IdentityEmailAddressStatus} par code.
   *
   * @param code code
   * @return {@link IdentityEmailAddressStatus}
   */
  public static IdentityEmailAddressStatus getByCode(String code) {
    return Stream.of(IdentityEmailAddressStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }

  static {
    CREATED.previous = Collections.emptySet();
    VERIFIED.previous = Core.getSet(List.of(CREATED));
    REVOKED.previous = Core.getSet(List.of(CREATED));
  }
}
