package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasFundingSourceAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasFundingSourceIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasLessorAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasLessorIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépense.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureDto extends AbstractIdentifiableAuditableDto
    implements HasExerciseIdentifierDto, HasExerciseAsStringDto, HasActivityIdentifierDto,
    HasActivityAsStringDto, HasEconomicNatureIdentifierDto, HasEconomicNatureAsStringDto,
    HasFundingSourceAsStringDto, HasFundingSourceIdentifierDto, HasLessorIdentifierDto,
    HasLessorAsStringDto {

  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;
  
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;
  
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;
  
  @JsonbProperty(JSON_FUNDING_SOURCE_IDENTIFIER)
  private String fundingSourceIdentifier;

  @JsonbProperty(JSON_FUNDING_SOURCE_AS_STRING)
  private String fundingSourceAsString;
  
  @JsonbProperty(JSON_LESSOR_IDENTIFIER)
  private String lessorIdentifier;

  @JsonbProperty(JSON_LESSOR_AS_STRING)
  private String lessorAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDepense";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "depenseChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dépense";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "dépenses";
}
