package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FundingDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FundingFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;

  /**
   * Identifiant {@link TriennialProgramActivityDto}.
   */
  String triennialProgramActivityIdentifier;

  /**
   * {@link ActivityCategory}.
   */
  ActivityCategory activityCategory;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FundingFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FundingFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
    triennialProgramActivityIdentifier = getTriennialProgramActivityIdentifier(filter);
    activityCategory = getActivityCategory(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
    setTriennialProgramActivityIdentifier(filter, triennialProgramActivityIdentifier);
    setActivityCategory(filter, activityCategory);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramActivityDto}
   */
  public static String getTriennialProgramActivityIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link TriennialProgramActivityDto}
   */
  public static void setTriennialProgramActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner la {@link ActivityCategory}.
   *
   * @param filter filtre
   * @param category {@link ActivityCategory}
   */
  public static void setActivityCategory(FilterDto filter, ActivityCategory category) {
    set(filter, JSON_ACTIVITY_CATEGORY, f -> f.getValueAsString(), f -> f.setValueAsEnum(category));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityCategory}.
   *
   * @param filter filtre
   * @return {@link ActivityCategory}
   */
  public static ActivityCategory getActivityCategory(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_ACTIVITY_CATEGORY, ActivityCategory.class));
  }

  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      FundingDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

  /**
   * Identifiant json champ {@link #triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
      FundingDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link FundingFilter#activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = FundingDto.JSON_ACTIVITY_CATEGORY;
}
