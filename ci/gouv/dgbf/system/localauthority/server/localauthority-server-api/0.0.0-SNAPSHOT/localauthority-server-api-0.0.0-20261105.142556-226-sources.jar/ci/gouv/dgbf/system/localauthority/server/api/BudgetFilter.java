package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetDto}.
 *
 * @author Donsylla
 */
@Getter
@Setter
public class BudgetFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ExerciseDto}.
   */
  String exerciseIdentifier;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;

  /**
   * {@link BudgetType}.
   */
  BudgetType type;

  /**
   * {@link BudgetStatus}.
   */
  BudgetStatus status;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    exerciseIdentifier = getExerciseIdentifier(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    type = getType(filter);
    status = getStatus(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setExerciseIdentifier(filter, exerciseIdentifier);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setType(filter, type);
    setStatus(filter, status);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ExerciseDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ExerciseDto}
   */
  public static String getExerciseIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXERCISE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ExerciseDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link ExerciseDto}
   */
  public static void setExerciseIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_EXERCISE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir le {@link BudgetType}.
   *
   * @param filter filtre
   * @return {@link BudgetType}
   */
  public static BudgetType getType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, BudgetType.class));
  }

  /**
   * Cette méthode permet d'assigner le {@link BudgetType}.
   *
   * @param filter filtre
   * @param type   {@link BudgetType}
   */
  public static void setType(FilterDto filter, BudgetType type) {
    set(filter, JSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir le {@link BudgetStatus}.
   *
   * @param filter filtre
   * @return {@link BudgetStatus}
   */
  public static BudgetStatus getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_STATUS, BudgetStatus.class));
  }

  /**
   * Cette méthode permet d'assigner le {@link BudgetStatus}.
   *
   * @param filter filtre
   * @param status {@link BudgetStatus}
   */
  public static void setStatus(FilterDto filter, BudgetStatus status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsEnum(status));
  }

  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = BudgetDto.JSON_EXERCISE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      BudgetDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #type}.
   */
  public static final String JSON_TYPE = BudgetDto.JSON_TYPE;

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = BudgetDto.JSON_STATUS;
}
