package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryUnitSectionService.FunctionaryUnitSectionCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryUnitSectionService.FunctionaryUnitSectionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionaryUnitSectionDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionaryUnitSectionDto}.

    @author akm
               """)
public interface FunctionaryUnitSectionRequestMapper
    extends RequestMapper<FunctionaryUnitSectionDto, FunctionaryUnitSectionCreateRequestDto,
       FunctionaryUnitSectionUpdateRequestDto> {

}
