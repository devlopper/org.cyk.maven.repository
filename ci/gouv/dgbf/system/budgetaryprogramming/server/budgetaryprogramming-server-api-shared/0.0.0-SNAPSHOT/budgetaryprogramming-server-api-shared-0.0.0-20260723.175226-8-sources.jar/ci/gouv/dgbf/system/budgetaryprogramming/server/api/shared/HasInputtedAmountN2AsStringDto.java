package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant saisi pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountN2AsStringDto extends HasInputtedAmountN2AsString {

  /**
   * Identifiant json du montant saisi pour l'année N+2.
   */
  String JSON_INPUTTED_AMOUNT_N2_AS_STRING = "montantSaisiN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName