package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonString;
import jakarta.json.JsonValue;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cette classe convertit une {@link JsonValue} JSON-P en structure Java native
 * ({@link LinkedHashMap}/{@link ArrayList}/{@link String}), en préservant l'ordre des clés du
 * document JSON source -- contrairement à la désérialisation JSON-B générique d'un {@code Map},
 * qui ne le garantit pas. Utilisée à la fois par la lecture de
 * {@code VA_FONCTIONNAIRE.STRUCTURES_JSON} côté serveur et par {@link StructuresJsonbDeserializer}
 * côté client, pour que l'ordre affiché de la Situation administrative reste celui produit par la
 * vue, à chaque point de désérialisation.
 *
 * @author akm
 *
 */
public final class OrderedJsonValues {

  private OrderedJsonValues() {
  }

  /**
   * Cette méthode convertit récursivement une {@link JsonValue} JSON-P en valeur Java équivalente.
   *
   * @param value valeur JSON-P source
   * @return valeur Java équivalente, {@code null} pour {@link JsonValue#NULL}
   */
  public static Object toJavaValue(JsonValue value) {
    switch (value.getValueType()) {
      case OBJECT:
        Map<String, Object> map = new LinkedHashMap<>();
        ((JsonObject) value).forEach((key, nested) -> map.put(key, toJavaValue(nested)));
        return map;
      case ARRAY:
        List<Object> list = new ArrayList<>();
        ((JsonArray) value).forEach(nested -> list.add(toJavaValue(nested)));
        return list;
      case STRING:
        return ((JsonString) value).getString();
      case NUMBER:
      case TRUE:
      case FALSE:
        return value.toString();
      case NULL:
      default:
        return null;
    }
  }
}
