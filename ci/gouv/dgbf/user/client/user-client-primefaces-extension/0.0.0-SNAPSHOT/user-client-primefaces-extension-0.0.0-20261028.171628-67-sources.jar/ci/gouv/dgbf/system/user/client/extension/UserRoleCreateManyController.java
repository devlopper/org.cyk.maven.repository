package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.Set;
import lombok.Getter;

/**
 * Cette classe permet de créer plusieurs rôles pour plusieurs utilisateurs.
 *
 * @author BoobaCool
 */
@Dependent
public class UserRoleCreateManyController extends AbstractController {

  @Getter
  Button button;
  @Getter
  Dialog dialog;

  @Inject
  @Getter
  UserSelectManyController userSelectManyController;
  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;


  @Inject
  ScriptManager scriptManager;

  @Inject
  UserClient userClient;

  @Inject
  RoleClient roleClient;

  @Inject
  UserRoleClient client;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    button = new Button();
    button.setValue("Ajouter plusieurs");
    button.setIcon("pi pi-plus");
    button.setOnClick("PF('createManyUserRoleDialog').show();");
    button.setUpdate("@form");
    button.setRendered(true);
    button.setType("button");

    dialog = new Dialog();
    dialog.setHeader("Ajouter plusieurs rôles aux utilisateurs");
    dialog.setWidgetVar("createManyUserRoleDialog");
    Dialog.configureForStackedForm(dialog);
    UserController.prepareSelectManyController(userSelectManyController, userClient,
        userIdentifier);
    userSelectManyController.getAutoComplete().setRequired(true);
    userSelectManyController.getAutoComplete().outputLabel().setValue("Utilisateurs");
    RoleController.prepareSelectManyController(roleSelectManyController, roleClient,
        userIdentifier);
    roleSelectManyController.getAutoComplete().setRequired(true);
    roleSelectManyController.getAutoComplete().outputLabel().setValue("Rôles");
  }

  /**
   * Cette méthode permet de créer plusieurs rôles pour plusieurs utilisateurs.
   */
  public void createMany() {
    Set<String> selectedUserIds =
        new HashSet<>(userSelectManyController.getAutoComplete().getValue());
    Set<String> selectedRoleIds =
        new HashSet<>(roleSelectManyController.getAutoComplete().getValue());
    UserRoleService.UserRoleCreateManyRequestDto request =
        new UserRoleService.UserRoleCreateManyRequestDto();
    request.setUserIdentifiers(selectedUserIds);
    request.setRoleIdentifiers(selectedRoleIds);
    request.setAuditWho(userIdentifier);
    client.createMany(request);
    scriptManager.hide(dialog);
  }
}
