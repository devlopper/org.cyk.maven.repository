package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDomainIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasReporterIdentityIdentifier;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasSupportTeamIdentifier;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUserIdentifier;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TicketFilter extends AbstractIdentifiableFilter implements FilterHasStatusCode,
    FilterHasStatusCodes, FilterHasDomainIdentifier, FilterHasReporterIdentityIdentifier,
    FilterHasUserIdentifier, FilterHasAdministrativeUnitIdentifier, FilterHasUserName,
    FilterHasSupportTeamIdentifier {

  private String statusCode;
  private Set<String> statusCodes;
  private String domainIdentifier;
  private String userName;

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  private String supportTeamIdentifier;

  /**
   * Identifiants des domaines fonctionnels.
   */
  private Set<String> domainIdentifiers;

  /**
   * Identifiant de {@link SupportTeamMemberDto}.
   */
  private String supportTeamMemberIdentifier;

  private String reporterIdentityIdentifier;

  private String userIdentifier;

  private String administrativeUnitIdentifier;



  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TicketFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TicketFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
    updateDomainIdentifier(filter);
    domainIdentifiers = getDomainIdentifiers(filter);
    updateReporterIdentityIdentifier(filter);
    updateUserIdentifier(filter);
    updateAdministrativeUnitIdentifier(filter);
    updateUserName(filter);
    updateSupportTeamIdentifier(filter);
    supportTeamMemberIdentifier = getSupportTeamMemberIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
    updateFilterDomainIdentifier(filter);
    setDomainIdentifiers(filter, domainIdentifiers);
    updateFilterReporterIdentityIdentifier(filter);
    updateFilterUserIdentifier(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    updateFilterUserName(filter);
    updateFilterSupportTeamIdentifier(filter);
    setSupportTeamMemberIdentifier(filter, supportTeamMemberIdentifier);
  }

  /**
   * Cette méthode permet d'assigner les identifiants des domaines fonctionnels.
   *
   * @param filter filtre
   * @param domainIdentifiers identifiants des domaines fonctionnels
   */
  public static void setDomainIdentifiers(FilterDto filter, Set<String> domainIdentifiers) {
    set(filter, JSON_DOMAIN_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(domainIdentifiers));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants des domaines fonctionnels.
   *
   * @param filter filtre
   * @return identifiants des domaines fonctionnels
   */
  public static Set<String> getDomainIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_DOMAIN_IDENTIFIERS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link SupportTeamMemberDto}.
   *
   * @param filter filtre
   * @param supportTeamMemberIdentifier identifiant de {@link SupportTeamMemberDto}
   */
  public static void setSupportTeamMemberIdentifier(FilterDto filter,
      String supportTeamMemberIdentifier) {
    set(filter, JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(supportTeamMemberIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link SupportTeamMemberDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link SupportTeamMemberDto}
   */
  public static String getSupportTeamMemberIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #domainIdentifiers}.
   */
  public static final String JSON_DOMAIN_IDENTIFIERS = "idDomaines";

  /**
   * Identifiant JSON {@link #supportTeamMemberIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER = "idMembreEquipeSupport";
}
