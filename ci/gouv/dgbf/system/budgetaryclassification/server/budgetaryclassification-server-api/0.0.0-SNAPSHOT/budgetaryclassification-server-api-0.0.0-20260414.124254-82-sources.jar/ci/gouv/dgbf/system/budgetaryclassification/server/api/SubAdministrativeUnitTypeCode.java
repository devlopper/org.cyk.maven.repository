package ci.gouv.dgbf.system.budgetaryclassification.server.api;

/**
 * Cette classe représente les codes de {@link SubAdministrativeUnitType}.
 *
 * @author stephane
 *
 */
public class SubAdministrativeUnitTypeCode {

  private SubAdministrativeUnitTypeCode() {
    
  }
  
  /**
   * Organisationnel.
   */
  public static final String ORGANIZATIONAL = "ORGANISATIONNEL";
  
  /**
   * Fonctionnel.
   */
  public static final String FUNCTIONAL = "FONCTIONNEL";

}
