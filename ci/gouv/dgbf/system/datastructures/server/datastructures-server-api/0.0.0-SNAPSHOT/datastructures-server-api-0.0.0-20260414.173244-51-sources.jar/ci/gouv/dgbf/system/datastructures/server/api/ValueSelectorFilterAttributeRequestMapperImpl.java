package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueSelectorFilterAttributeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-14T17:33:09+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueSelectorFilterAttributeRequestMapperImpl implements ValueSelectorFilterAttributeRequestMapper {

    @Override
    public ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeCreateRequestDto mapCreate(ValueSelectorFilterAttributeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeCreateRequestDto valueSelectorFilterAttributeCreateRequestDto = new ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeCreateRequestDto();

        valueSelectorFilterAttributeCreateRequestDto.setCode( arg0.getCode() );
        valueSelectorFilterAttributeCreateRequestDto.setName( arg0.getName() );
        valueSelectorFilterAttributeCreateRequestDto.setValueSelectorIdentifier( arg0.getValueSelectorIdentifier() );

        return valueSelectorFilterAttributeCreateRequestDto;
    }

    @Override
    public ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeUpdateRequestDto mapUpdate(ValueSelectorFilterAttributeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeUpdateRequestDto valueSelectorFilterAttributeUpdateRequestDto = new ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeUpdateRequestDto();

        valueSelectorFilterAttributeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueSelectorFilterAttributeUpdateRequestDto.setCode( arg0.getCode() );
        valueSelectorFilterAttributeUpdateRequestDto.setName( arg0.getName() );
        valueSelectorFilterAttributeUpdateRequestDto.setValueSelectorIdentifier( arg0.getValueSelectorIdentifier() );

        return valueSelectorFilterAttributeUpdateRequestDto;
    }
}
