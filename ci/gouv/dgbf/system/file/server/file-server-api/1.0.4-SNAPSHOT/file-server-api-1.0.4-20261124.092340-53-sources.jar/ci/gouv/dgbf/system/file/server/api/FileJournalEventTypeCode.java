package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileJournalEventType} : valeurs stockées dans
 * {@code TA_JOURNAL_FICHIER.TYPE_EVENEMENT} ({@code CK_TJF_TYPE}, script 013).
 *
 * @author Christian
 */
public class FileJournalEventTypeCode {

  private FileJournalEventTypeCode() {}

  /**
   * Ajout d'un contenu binaire à un Fichier qui n'en avait pas (RG_FILE_FIC_20).
   */
  public static final String BYTES_ADDITION = "AJOUT_CONTENU_BINAIRE";

  /**
   * Déclaration de l'Exemplaire physique d'un Fichier qui n'en avait pas (RG_FILE_FIC_20).
   */
  public static final String PHYSICAL_ITEM_DECLARATION = "DECLARATION_EXEMPLAIRE";

  /**
   * Modification des informations du Fichier (RG_FILE_FIC_21).
   */
  public static final String INFORMATION_UPDATE = "MODIFICATION_INFORMATION";

  /**
   * Modification de l'Exemplaire physique (RG_FILE_FIC_22).
   */
  public static final String PHYSICAL_ITEM_UPDATE = "MODIFICATION_EXEMPLAIRE";
}
