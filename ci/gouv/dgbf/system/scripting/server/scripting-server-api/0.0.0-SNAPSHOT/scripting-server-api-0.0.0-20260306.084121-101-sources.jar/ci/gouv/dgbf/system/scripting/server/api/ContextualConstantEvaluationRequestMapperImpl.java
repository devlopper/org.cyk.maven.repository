package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ContextualConstantEvaluationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ContextualConstantEvaluationRequestMapperImpl implements ContextualConstantEvaluationRequestMapper {

    @Override
    public ContextualConstantEvaluationService.ContextualConstantEvaluationCreateRequestDto mapCreate(ContextualConstantEvaluationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantEvaluationService.ContextualConstantEvaluationCreateRequestDto contextualConstantEvaluationCreateRequestDto = new ContextualConstantEvaluationService.ContextualConstantEvaluationCreateRequestDto();

        contextualConstantEvaluationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        contextualConstantEvaluationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        contextualConstantEvaluationCreateRequestDto.setValue( arg0.getValue() );
        contextualConstantEvaluationCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        contextualConstantEvaluationCreateRequestDto.setContextualConstantIdentifier( arg0.getContextualConstantIdentifier() );

        return contextualConstantEvaluationCreateRequestDto;
    }

    @Override
    public ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateRequestDto mapUpdate(ContextualConstantEvaluationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateRequestDto contextualConstantEvaluationUpdateRequestDto = new ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateRequestDto();

        contextualConstantEvaluationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        contextualConstantEvaluationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        contextualConstantEvaluationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        contextualConstantEvaluationUpdateRequestDto.setValue( arg0.getValue() );
        contextualConstantEvaluationUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        contextualConstantEvaluationUpdateRequestDto.setContextualConstantIdentifier( arg0.getContextualConstantIdentifier() );

        return contextualConstantEvaluationUpdateRequestDto;
    }
}
