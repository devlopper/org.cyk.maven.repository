package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.file.server.api.FileCategoryDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link FileCategoryDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FileCategoryListPage extends AbstractPage {

  @Inject
  @Getter
  FileCategoryController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + FileCategoryDto.NAME;
    controller.initialize();
  }
  
  public static final String OUTCOME = "roleListPage";
}
