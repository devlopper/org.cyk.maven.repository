package ci.gouv.dgbf.extension.server.service.impl;

import ci.gouv.dgbf.extension.core.RestHelper;
import ci.gouv.dgbf.extension.server.service.api.Service;
import jakarta.inject.Inject;
import jakarta.ws.rs.core.Response;
import java.util.concurrent.Callable;

/**
 * Cette classe représente la base des implémentations de service.
 *
 * @author Christian
 *
 */
public abstract class AbstractServiceImpl implements Service {

  /**
   * instance {@link RestHelper}.
   */
  @Inject
  protected RestHelper restHelper;
  
  /**
   * Cette méthode permet d'exécuter un service.
   *
   * @param service service
   * @return réponse
   */
  protected Response serve(Callable<Response> service) {
    return restHelper.serve(service);
  }
}
