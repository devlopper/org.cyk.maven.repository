package ci.gouv.dgbf.system.report.client.extension;

import ci.gouv.dgbf.system.report.server.api.ReportDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;
import java.util.List;
import java.util.Map;
import org.primefaces.PrimeFaces;
import org.primefaces.model.DialogFrameworkOptions;

/**
 * Cette classe représente la page de liste de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
@Named
@ViewScoped
public class ReportEditOnlyListPage extends AbstractReportListPage {

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ReportDto.NAME;
  }

  @Override
  protected void initializeController() {
    controller.getListController().getDataTable().getColumnsButton().setRendered(false);
    controller.getListController().getDataTable().getExportButton().setRendered(false);
    controller.getListController().getShowCreateDialogButton().setRendered(false);
    controller.getListController().getShowUpdateDialogButton().setRendered(false);
    controller.getListController().getDeleteButton().setRendered(false);
    controller.getListController().getDataTable().getFilterButton().setRendered(false);
    super.initializeController();
  }

  /**
   * Ouverture du dialogue de liste des rapports.
   *
   */
  public static void openInDialog() {
    openInDialog(null);
  }

  /**
   * Ouverture du dialogue de liste des rapports avec paramètres.
   *
   */
  public static void openInDialog(Map<String, List<String>> params) {
    DialogFrameworkOptions options = buildDefaultDialogOptions();
    PrimeFaces.current().dialog().openDynamic(OUTCOME, options, params);
  }

  static DialogFrameworkOptions buildDefaultDialogOptions() {
    return DialogFrameworkOptions.builder()
        .modal(true)
        .fitViewport(true)
        .responsive(true)
        .width("1200").height("600")
        .contentWidth("100%")
        .resizeObserver(true)
        .resizeObserverCenter(true)
        .resizable(true)
        .styleClass("max-w-screen")
        .iframeStyleClass("max-w-screen")
        .build();
  }

  public static final String OUTCOME = "reportEditOnlyListPage";
}

