package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTypedTabMenuController;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class DocumentTypeGroupTabMenuController
    extends AbstractTypedTabMenuController<DocumentTypeGroupDto, DocumentationIconManager> {

  @Inject
  @Getter
  DocumentationIconManager iconManager;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentTypeGroupTabMenuController() {
    super(DocumentTypeGroupDto.class);
  }

}
