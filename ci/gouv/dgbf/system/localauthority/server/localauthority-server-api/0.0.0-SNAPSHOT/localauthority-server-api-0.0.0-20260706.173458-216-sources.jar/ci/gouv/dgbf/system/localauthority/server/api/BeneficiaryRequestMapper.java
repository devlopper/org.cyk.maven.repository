package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BeneficiaryDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BeneficiaryDto}.
    
    @author Christian
    """)
public interface BeneficiaryRequestMapper
    extends
    RequestMapper<BeneficiaryDto,
        BeneficiaryService.BeneficiaryCreateRequestDto,
        BeneficiaryService.BeneficiaryUpdateRequestDto> {

}

