package ci.gouv.dgbf.system.identity.server.api;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une identité importable.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ImportableIdentityDto extends AbstractIdentityDto {

  /**
   * Identifiant json d'un attribut de type {@link ImportableIdentityDto}.
   */
  public static final String JSON_THIS = "identiteImportable";
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "identité importable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "identités importables";
}
