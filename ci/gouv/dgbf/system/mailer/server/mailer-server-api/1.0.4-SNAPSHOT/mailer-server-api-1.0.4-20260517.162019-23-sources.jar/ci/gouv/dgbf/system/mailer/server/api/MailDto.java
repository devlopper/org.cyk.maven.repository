package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasBodyDto;
import ci.gouv.dgbf.extension.core.segregation.HasSubjectDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un mail.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MailDto extends AbstractIdentifiableAuditableDto
    implements HasSubjectDto, HasBodyDto<String>, HasFilesGroupIdentifierDto {

  @JsonbProperty(value = JSON_SUBJECT)
  public String subject;

  @JsonbProperty(value = JSON_BODY)
  public String body;

  @JsonbProperty(value = JSON_RECEIVERS_ADDRESSES_AS_STRING)
  private String receiversAddressesAsString;

  @JsonbProperty(value = JSON_FILES_GROUP_IDENTIFIER)
  public String filesGroupIdentifier;

  public static final String JSON_RECEIVERS_ADDRESSES_AS_STRING = "adressesDestinatairesChaine";
}
