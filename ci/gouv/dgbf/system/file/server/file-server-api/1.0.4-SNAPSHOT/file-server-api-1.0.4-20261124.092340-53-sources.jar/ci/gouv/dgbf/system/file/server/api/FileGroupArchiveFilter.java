package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre d'archive de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileGroupArchiveFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du fichier de groupe maître.
   */
  private String fileGroupIdentifier;

  /**
   * Indicateur d'archive applicable (sans date de fin).
   */
  private Boolean applicable;

  /**
   * Identifiant de la demande de début d'archivage.
   */
  private String startSolicitationIdentifier;

  /**
   * Identifiant de la demande de fin d'archivage.
   */
  private String endSolicitationIdentifier;

  /**
   * Identifiant de l'auteur de début d'archivage.
   */
  private String startAuthorIdentifier;

  /**
   * Indicateur de début direct (sans demande de début).
   */
  private Boolean directStart;

  /**
   * Indicateur de fin directe (terminée sans demande de fin).
   */
  private Boolean directEnd;

  /**
   * Cette méthode permet de construire.
   */
  public FileGroupArchiveFilter() {
    super();
  }

  /**
   * Cette méthode permet de construire avec un filtre.
   *
   * @param filter filtre
   */
  public FileGroupArchiveFilter(FilterDto filter) {
    super(filter);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    fileGroupIdentifier = getFileGroupIdentifier(filter);
    applicable = getApplicable(filter);
    startSolicitationIdentifier = getStartSolicitationIdentifier(filter);
    endSolicitationIdentifier = getEndSolicitationIdentifier(filter);
    startAuthorIdentifier = getStartAuthorIdentifier(filter);
    directStart = getDirectStart(filter);
    directEnd = getDirectEnd(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFileGroupIdentifier(filter, fileGroupIdentifier);
    setApplicable(filter, applicable);
    setStartSolicitationIdentifier(filter, startSolicitationIdentifier);
    setEndSolicitationIdentifier(filter, endSolicitationIdentifier);
    setStartAuthorIdentifier(filter, startAuthorIdentifier);
    setDirectStart(filter, directStart);
    setDirectEnd(filter, directEnd);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du fichier de groupe maître.
   *
   * @param filter filtre
   * @param fileGroupIdentifier identifiant du fichier de groupe maître
   */
  public static void setFileGroupIdentifier(FilterDto filter, String fileGroupIdentifier) {
    set(filter, JSON_FILE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(fileGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du fichier de groupe maître.
   *
   * @param filter filtre
   * @return identifiant du fichier de groupe maître
   */
  public static String getFileGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FILE_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur d'archive applicable.
   *
   * @param filter filtre
   * @param applicable indicateur d'archive applicable
   */
  public static void setApplicable(FilterDto filter, Boolean applicable) {
    set(filter, JSON_APPLICABLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(applicable));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur d'archive applicable.
   *
   * @param filter filtre
   * @return indicateur d'archive applicable
   */
  public static Boolean getApplicable(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_APPLICABLE));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la demande de début.
   *
   * @param filter filtre
   * @param startSolicitationIdentifier identifiant de la demande de début
   */
  public static void setStartSolicitationIdentifier(FilterDto filter,
      String startSolicitationIdentifier) {
    set(filter, JSON_START_SOLICITATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(startSolicitationIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la demande de début.
   *
   * @param filter filtre
   * @return identifiant de la demande de début
   */
  public static String getStartSolicitationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_START_SOLICITATION_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la demande de fin.
   *
   * @param filter filtre
   * @param endSolicitationIdentifier identifiant de la demande de fin
   */
  public static void setEndSolicitationIdentifier(FilterDto filter,
      String endSolicitationIdentifier) {
    set(filter, JSON_END_SOLICITATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(endSolicitationIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la demande de fin.
   *
   * @param filter filtre
   * @return identifiant de la demande de fin
   */
  public static String getEndSolicitationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_END_SOLICITATION_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'auteur de début.
   *
   * @param filter filtre
   * @param startAuthorIdentifier identifiant de l'auteur de début
   */
  public static void setStartAuthorIdentifier(FilterDto filter,
      String startAuthorIdentifier) {
    set(filter, JSON_START_AUTHOR_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(startAuthorIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'auteur de début.
   *
   * @param filter filtre
   * @return identifiant de l'auteur de début
   */
  public static String getStartAuthorIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_START_AUTHOR_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur de début direct.
   *
   * @param filter filtre
   * @param directStart indicateur de début direct
   */
  public static void setDirectStart(FilterDto filter, Boolean directStart) {
    set(filter, JSON_DIRECT_START, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(directStart));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur de début direct.
   *
   * @param filter filtre
   * @return indicateur de début direct
   */
  public static Boolean getDirectStart(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_DIRECT_START));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur de fin directe.
   *
   * @param filter filtre
   * @param directEnd indicateur de fin directe
   */
  public static void setDirectEnd(FilterDto filter, Boolean directEnd) {
    set(filter, JSON_DIRECT_END, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(directEnd));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur de fin directe.
   *
   * @param filter filtre
   * @return indicateur de fin directe
   */
  public static Boolean getDirectEnd(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_DIRECT_END));
  }

  /**
   * Clé JSON de l'identifiant du fichier de groupe maître.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER =
      FileGroupArchiveDto.JSON_FILE_GROUP_IDENTIFIER;

  /**
   * Clé JSON de l'indicateur applicable.
   */
  public static final String JSON_APPLICABLE = FileGroupArchiveDto.JSON_APPLICABLE;

  /**
   * Clé JSON de l'identifiant de la demande de début.
   */
  public static final String JSON_START_SOLICITATION_IDENTIFIER =
      FileGroupArchiveDto.JSON_START_SOLICITATION_IDENTIFIER;

  /**
   * Clé JSON de l'identifiant de la demande de fin.
   */
  public static final String JSON_END_SOLICITATION_IDENTIFIER =
      FileGroupArchiveDto.JSON_END_SOLICITATION_IDENTIFIER;

  /**
   * Clé JSON de l'identifiant de l'auteur de début.
   */
  public static final String JSON_START_AUTHOR_IDENTIFIER =
      FileGroupArchiveDto.JSON_START_AUTHOR_IDENTIFIER;

  /**
   * Clé JSON de l'indicateur de début direct.
   */
  public static final String JSON_DIRECT_START = "estDebutDirect";

  /**
   * Clé JSON de l'indicateur de fin directe.
   */
  public static final String JSON_DIRECT_END = "estFinDirecte";
}
