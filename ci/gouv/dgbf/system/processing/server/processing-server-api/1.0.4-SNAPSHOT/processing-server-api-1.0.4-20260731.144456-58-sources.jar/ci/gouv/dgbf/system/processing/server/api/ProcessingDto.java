package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un traitement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcessingDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Descriptif.
   */
  @JsonbProperty(JSON_DESCRIPTIVE)
  private String descriptive;

  /**
   * Date de début.
   */
  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;

  /**
   * Représentation en chaine de caractères de la date de début.
   */
  @JsonbProperty(JSON_FROM_DATE_AS_STRING)
  private String fromDateAsString;

  /**
   * Date de fin.
   */
  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;

  /**
   * Représentation en chaine de caractères de la date de fin.
   */
  @JsonbProperty(JSON_TO_DATE_AS_STRING)
  private String toDateAsString;

  /**
   * {@link ProcessingStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private ProcessingStatus status;

  /**
   * Code {@link ProcessingStatus}.
   */
  @JsonbProperty(JSON_STATUS_CODE)
  private String statusCode;

  /**
   * Représentation en chaine de caractères de {@link ProcessingStatus}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Raison.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Date.
   */
  @JsonbProperty(JSON_DATE)
  private LocalDateTime date;

  /**
   * Représentation en chaine de caractères de la date.
   */
  @JsonbProperty(JSON_DATE_AS_STRING)
  private String dateAsString;

  /**
   * Volume de travail total.
   */
  @JsonbProperty(JSON_TOTAL_WORK_VOLUME)
  private Integer totalWorkVolume;

  /**
   * Représentation en chaine de caractères de {@link #totalWorkVolume}.
   */
  @JsonbProperty(JSON_TOTAL_WORK_VOLUME_AS_STRING)
  private String totalWorkVolumeAsString;

  /**
   * Volume de travail réalisé.
   */
  @JsonbProperty(JSON_COMPLETED_WORK_VOLUME)
  private Integer completedWorkVolume;

  /**
   * Représentation en chaine de caractères de {@link #totalWorkVolume}.
   */
  @JsonbProperty(JSON_COMPLETED_WORK_VOLUME_AS_STRING)
  private String completedWorkVolumeAsString;

  /**
   * Volume de travail réalisé sur une base de 100.
   */
  @JsonbProperty(JSON_WORK_COMPLETION_RATE)
  private Integer workCompletionRate;

  /**
   * Indique si le volume de travail total a été réalisé.
   */
  @JsonbProperty(JSON_IS_WORK_COMPLETED)
  private Boolean isWorkCompleted;

  /**
   * Représentation en chaine de caractères de {@link #isWorkCompleted}.
   */
  @JsonbProperty(JSON_IS_WORK_COMPLETED_AS_STRING)
  private String isWorkCompletedAsString;

  /**
   * Taille du lot. Définit le nombre d'éléments à traiter dans un seul lot.
   */
  @JsonbProperty(JSON_BATCH_SIZE)
  private Integer batchSize;

  /**
   * Représentation en chaine de caractères de {@link #batchSize}.
   */
  @JsonbProperty(JSON_BATCH_SIZE_AS_STRING)
  private String batchSizeAsString;

  /**
   * Nombre de thread. Définit le nombre de threads concurrents pour le traitement des lots.
   */
  @JsonbProperty(JSON_THREAD_COUNT)
  private Integer threadCount;

  /**
   * Représentation en chaine de caractères de {@link #threadCount}.
   */
  @JsonbProperty(JSON_THREAD_COUNT_AS_STRING)
  private String threadCountAsString;

  /**
   * Identifiant de {@link ProcessingDto} précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_IDENTIFIER)
  private String previousIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ProcessingDto} précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_AS_STRING)
  private String previousAsString;

  /**
   * Démarrable.
   */
  @JsonbProperty(JSON_STARTABLE)
  private Boolean startable;

  /**
   * Arrêtable.
   */
  @JsonbProperty(JSON_STOPPABLE)
  private Boolean stoppable;

  /**
   * Annulable.
   */
  @JsonbProperty(JSON_CANCELABLE)
  private Boolean cancelable;

  /**
   * Terminable.
   */
  @JsonbProperty(JSON_TERMINATABLE)
  private Boolean terminatable;

  /**
   * Représentation en chaine de caractères de la date de création.
   */
  @JsonbProperty(JSON_CREATION_DATE_AS_STRING)
  private String creationDateAsString;

  /**
   * Représentation en chaine de caractères de la date de démmarage.
   */
  @JsonbProperty(JSON_START_DATE_AS_STRING)
  private String startDateAsString;

  /**
   * Représentation en chaine de caractères de la date d'arrêt.
   */
  @JsonbProperty(JSON_STOP_DATE_AS_STRING)
  private String stopDateAsString;

  /**
   * Représentation en chaine de caractères de la date d'annulation.
   */
  @JsonbProperty(JSON_CANCELLATION_DATE_AS_STRING)
  private String cancellationDateAsString;

  /**
   * Représentation en chaine de caractères de la date de terminaison.
   */
  @JsonbProperty(JSON_TERMINATION_DATE_AS_STRING)
  private String terminationDateAsString;

  /**
   * Est en retard.
   */
  @JsonbProperty(JSON_IS_LATE)
  private Boolean isLate;

  /**
   * Cette méthode permet d'initialiser à partir d'une réponse.
   *
   * @param response résponse
   */
  public void initialize(ProcessResponseDto response) {
    status = response.getStatus();
    statusAsString = response.getStatus().getName();
    startable = response.getStartable();
    stoppable = response.getStoppable();
    cancelable = response.getCancelable();
    terminatable = response.getTerminatable();
  }

  /**
   * champ json {@link #descriptive}.
   */
  public static final String JSON_DESCRIPTIVE = "descriptif";

  /**
   * champ json {@link #fromDate}.
   */
  public static final String JSON_FROM_DATE = "dateDebut";

  /**
   * champ json {@link #fromDateAsString}.
   */
  public static final String JSON_FROM_DATE_AS_STRING = "dateDebutChaine";

  /**
   * champ json {@link #toDate}.
   */
  public static final String JSON_TO_DATE = "dateFin";

  /**
   * champ json {@link #toDateAsString}.
   */
  public static final String JSON_TO_DATE_AS_STRING = "dateFinChaine";

  /**
   * champ json {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * champ json {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "codeStatut";

  /**
   * champ json {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * champ json {@link #reason}.
   */
  public static final String JSON_REASON = "raison";

  /**
   * champ json {@link #date}.
   */
  public static final String JSON_DATE = "date";

  /**
   * champ json {@link #dateAsString}.
   */
  public static final String JSON_DATE_AS_STRING = "dateChaine";

  /**
   * champ json {@link #totalWorkVolume}.
   */
  public static final String JSON_TOTAL_WORK_VOLUME = "volumeTravailTotal";

  /**
   * champ json {@link #totalWorkVolumeAsString}.
   */
  public static final String JSON_TOTAL_WORK_VOLUME_AS_STRING = JSON_TOTAL_WORK_VOLUME + "Chaine";

  /**
   * champ json {@link #completedWorkVolume}.
   */
  public static final String JSON_COMPLETED_WORK_VOLUME = "volumeTravailRealise";

  /**
   * champ json {@link #completedWorkVolumeAsString}.
   */
  public static final String JSON_COMPLETED_WORK_VOLUME_AS_STRING =
      JSON_COMPLETED_WORK_VOLUME + "Chaine";

  /**
   * champ json {@link #isWorkCompleted}.
   */
  public static final String JSON_IS_WORK_COMPLETED = "travailEstRealise";

  /**
   * champ json {@link #isWorkCompletedAsString}.
   */
  public static final String JSON_IS_WORK_COMPLETED_AS_STRING = JSON_IS_WORK_COMPLETED + "Chaine";

  /**
   * champ json {@link #workCompletionRate}.
   */
  public static final String JSON_WORK_COMPLETION_RATE = "pourcentageVolumeTravailRealise";

  /**
   * champ json {@link #batchSize}.
   */
  public static final String JSON_BATCH_SIZE = "tailleLot";

  /**
   * champ json {@link #batchSizeAsString}.
   */
  public static final String JSON_BATCH_SIZE_AS_STRING = JSON_BATCH_SIZE + "Chaine";

  /**
   * champ json {@link #threadCount}.
   */
  public static final String JSON_THREAD_COUNT = "nombreThread";

  /**
   * champ json {@link #threadCountAsString}.
   */
  public static final String JSON_THREAD_COUNT_AS_STRING = JSON_THREAD_COUNT + "Chaine";

  /**
   * champ json {@link #previousIdentifier}.
   */
  public static final String JSON_PREVIOUS_IDENTIFIER = "idPrecedent";

  /**
   * champ json {@link #previousAsString}.
   */
  public static final String JSON_PREVIOUS_AS_STRING = "precedentChaine";

  /**
   * champ json {@link #startable}.
   */
  public static final String JSON_STARTABLE = "demarrable";

  /**
   * champ json {@link #stoppable}.
   */
  public static final String JSON_STOPPABLE = "stoppable";

  /**
   * champ json {@link #cancelable}.
   */
  public static final String JSON_CANCELABLE = "annulable";

  /**
   * champ json {@link #terminatable}.
   */
  public static final String JSON_TERMINATABLE = "terminable";

  /**
   * champ json {@link #creationDateAsString}.
   */
  public static final String JSON_CREATION_DATE_AS_STRING = "dateCreationChaine";

  /**
   * champ json {@link #startDateAsString}.
   */
  public static final String JSON_START_DATE_AS_STRING = "dateDemmarageChaine";

  /**
   * champ json {@link #stopDateAsString}.
   */
  public static final String JSON_STOP_DATE_AS_STRING = "dateArretChaine";

  /**
   * champ json {@link #cancellationDateAsString}.
   */
  public static final String JSON_CANCELLATION_DATE_AS_STRING = "dateAnnulationChaine";

  /**
   * champ json {@link #terminationDateAsString}.
   */
  public static final String JSON_TERMINATION_DATE_AS_STRING = "dateTerminaisonChaine";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = "estEnRetard";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "traitement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
