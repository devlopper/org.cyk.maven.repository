package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN2AsStringDto
    extends HasTotalAmountToArbitrateN2AsString {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N2_AS_STRING = "montantTotalAArbitrerN2Chaine";
}
