package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un élément de salaire.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SalaryElementDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_SALARY_ELEMENT_GROUP_IDENTIFIER)
  private String salaryElementGroupIdentifier;

  @JsonbProperty(JSON_SALARY_ELEMENT_GROUP_AS_STRING)
  private String salaryElementGroupAsString;

  @JsonbProperty(JSON_IS_EARNING)
  private Boolean isEarning;

  @JsonbProperty(JSON_IS_EARNING_AS_STRING)
  private String isEarningAsString;
  
  @JsonbProperty(JSON_CONDITIONAL_VALUE_GROUP_IDENTIFIER)
  private String conditionalValueGroupIdentifier;

  @JsonbProperty(JSON_CONDITIONAL_VALUE_GROUP_AS_STRING)
  private String conditionalValueGroupAsString;

  @JsonbProperty(JSON_SCRIPT_CONTEXT_GROUP_IDENTIFIER)
  private String scriptContextGroupIdentifier;

  @JsonbProperty(JSON_SCRIPT_CONTEXT_GROUP_AS_STRING)
  private String scriptContextGroupAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idElementSalaire";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "elementSalaireChaine";

  /**
   * Identifiant json de {@link #salaryElementGroupIdentifier}.
   */
  public static final String JSON_SALARY_ELEMENT_GROUP_IDENTIFIER =
      SalaryElementGroupDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant json de {@link #salaryElementGroupAsString}.
   */
  public static final String JSON_SALARY_ELEMENT_GROUP_AS_STRING =
      SalaryElementGroupDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #isEarning}.
   */
  public static final String JSON_IS_EARNING = "estGain";

  /**
   * Identifiant json {@link #isEarningAsString}.
   */
  public static final String JSON_IS_EARNING_AS_STRING = JSON_IS_EARNING + "Chaine";

  /**
   * Identifiant json de {@link #conditionalValueGroupIdentifier}.
   */
  public static final String JSON_CONDITIONAL_VALUE_GROUP_IDENTIFIER =
      "idElementConditonnee";
  
  /**
   * Identifiant json de {@link #conditionalValueGroupAsString}.
   */
  public static final String JSON_CONDITIONAL_VALUE_GROUP_AS_STRING =
      "elementConditonneeChaine";

  /**
   * Identifiant json de {@link #scriptContextGroupIdentifier}.
   */
  public static final String JSON_SCRIPT_CONTEXT_GROUP_IDENTIFIER =
      "idGroupContexteScript";
  
  /**
   * Identifiant json de {@link #scriptContextGroupAsString}.
   */
  public static final String JSON_SCRIPT_CONTEXT_GROUP_AS_STRING =
      "groupeContexteScriptChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "element salaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "elements salaire";
}
