package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.UserCapacityDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Cette classe regroupe les membres d'un Groupe par Qualité, pour la fiche du Groupe : les
 * Qualités mises en avant (Responsable, Superviseur) d'abord, toujours présentes, puis les autres
 * Qualités par libellé, seulement si un membre les porte.
 *
 * @author Christian
 *
 */
public final class UsersGroupMembersByCapacity {

  /**
   * Valeur d'une Qualité mise en avant que personne ne porte.
   */
  static final String NONE = "Aucun";

  /**
   * Codes des Qualités mises en avant, dans l'ordre d'affichage.
   */
  static final List<String> FEATURED_CODES =
      List.of(UserCapacityDto.RESPONSIBLE_CODE, UserCapacityDto.SUPERVISOR_CODE);

  private UsersGroupMembersByCapacity() {
  }

  /**
   * Cette méthode calcule les lignes (libellé de la Qualité, noms des membres) de la fiche.
   *
   * @param capacities Qualités du catalogue
   * @param members    membres du Groupe, avec leur Qualité éventuelle
   * @return lignes dans l'ordre d'affichage
   */
  public static Map<String, String> lines(List<UserCapacityDto> capacities,
                                          List<UserGroupDto> members) {
    Map<String, List<String>> namesByCapacity = new HashMap<>();
    for (UserGroupDto member : members) {
      if (member.getCapacityIdentifier() != null && member.getUserAsString() != null) {
        namesByCapacity.computeIfAbsent(member.getCapacityIdentifier(), key -> new ArrayList<>())
            .add(member.getUserAsString());
      }
    }
    List<UserCapacityDto> sorted = new ArrayList<>(capacities);
    sorted.sort(Comparator.comparingInt(UsersGroupMembersByCapacity::rank)
        .thenComparing(UserCapacityDto::getName));
    Map<String, String> lines = new LinkedHashMap<>();
    for (UserCapacityDto capacity : sorted) {
      List<String> names = namesByCapacity.getOrDefault(capacity.getIdentifier(), List.of());
      if (!names.isEmpty()) {
        lines.put(capacity.getName(), String.join(", ", names.stream().sorted().toList()));
      } else if (rank(capacity) < FEATURED_CODES.size()) {
        lines.put(capacity.getName(), NONE);
      }
    }
    return lines;
  }

  private static int rank(UserCapacityDto capacity) {
    int index = FEATURED_CODES.indexOf(capacity.getCode());
    return index < 0 ? FEATURED_CODES.size() : index;
  }
}
