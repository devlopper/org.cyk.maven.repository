package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets actuellement pris
 * en charge (statut PRIS_EN_CHARGE, en cours de traitement).
 *
 * @author Christian
 */
public interface HasClaimedTicketCountDto extends HasClaimedTicketCount {

  /**
   * Identifiant json du nombre de tickets actuellement pris en charge.
   */
  String JSON_CLAIMED_TICKET_COUNT = "nombreTicketsPrisEnCharge";
}
