package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe de transfert portant l'interrupteur d'activation (R48,
 * RG_REP_SOU_15).
 *
 * @author akm
 *
 */
public interface HasIsActivatedDto extends HasIsActivated {

  /**
   * Identifiant json de {@link #getIsActivated()}.
   */
  String JSON_IS_ACTIVATED = "estActive";
}
