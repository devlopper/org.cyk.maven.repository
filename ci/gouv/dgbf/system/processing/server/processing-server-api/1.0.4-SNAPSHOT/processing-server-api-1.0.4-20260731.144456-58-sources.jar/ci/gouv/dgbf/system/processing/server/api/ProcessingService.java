package ci.gouv.dgbf.system.processing.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasHeartbeatEmitterIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasHeartbeatExpirationTimeoutInSecondsDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les fonctionnalités de {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Path(value = ProcessingService.PATH)
@Tag(name = "Traitement", description = "Gestion des traitements")
public interface ProcessingService {

  /**
   * Chemin de base des services.
   */
  String PATH = "traitements";

  /**
   * Cette classe représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ProcessingSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le descriptif.
     *
     * @return descriptif
     */
    String getDescriptive();

    /**
     * Cette méthode permet d'assigner le descriptif.
     *
     * @param descriptive descriptif
     */
    void setDescriptive(String descriptive);

    /**
     * Cette méthode permet d'obtenir la date de début.
     *
     * @return date de début
     */
    LocalDateTime getFromDate();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param fromDate date de début
     */
    void setFromDate(LocalDateTime fromDate);

    /**
     * Cette méthode permet d'obtenir la date de fin.
     *
     * @return date de fin
     */
    LocalDateTime getToDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param toDate date de fin
     */
    void setToDate(LocalDateTime toDate);

    /**
     * Cette méthode permet d'obtenir la raison.
     *
     * @return raison
     */
    String getReason();

    /**
     * Cette méthode permet d'assigner la raison.
     *
     * @param reason raison
     */
    void setReason(String reason);

    /**
     * Cette méthode permet d'obtenir la date.
     *
     * @return date
     */
    LocalDateTime getDate();

    /**
     * Cette méthode permet d'assigner la date.
     *
     * @param date date
     */
    void setDate(LocalDateTime date);

    /**
     * Cette méthode permet d'obtenir le volume total de travail.
     *
     * @return volume total de travail
     */
    Integer getTotalWorkVolume();

    /**
     * Cette méthode permet d'assigner le volume total de travail.
     *
     * @param totalWorkVolume volume total de travail
     */
    void setTotalWorkVolume(Integer totalWorkVolume);

    /**
     * Cette méthode permet d'obtenir le volume de travail réalisé.
     *
     * @return volume de travail réalisé
     */
    Integer getCompletedWorkVolume();

    /**
     * Cette méthode permet d'assigner le volume de travail réalisé.
     *
     * @param completedWorkVolume volume de travail réalisé
     */
    void setCompletedWorkVolume(Integer completedWorkVolume);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ProcessingDto} précédent.
     *
     * @return identifiant de {@link ProcessingDto} précédent
     */
    String getPreviousIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ProcessingDto} précédent.
     *
     * @param previousIdentifier identifiant de {@link ProcessingDto} précédent
     */
    void setPreviousIdentifier(String previousIdentifier);

    /**
     * Cette méthode permet d'obtenir la taille du lot.
     *
     * @return taille du lot
     */
    Integer getBatchSize();

    /**
     * Cette méthode permet d'assigner la taille du lot.
     *
     * @param batchSize taille du lot
     */
    void setBatchSize(Integer batchSize);

    /**
     * Cette méthode permet d'obtenir le nombre de thread.
     *
     * @return nombre de thread
     */
    Integer getThreadCount();

    /**
     * Cette méthode permet d'assigner le nombre de thread.
     *
     * @param threadCount nombre de thread
     */
    void setThreadCount(Integer threadCount);

    /**
     * Cette méthode permet d'obtenir le délai d'expiration du heartbeat en secondes.
     *
     * @return délai d'expiration du heartbeat en secondes
     */
    Integer getHeartbeatExpirationTimeoutInSeconds();

    /**
     * Cette méthode permet d'assigner le délai d'expiration du heartbeat en secondes.
     *
     * @param heartbeatExpirationTimeoutInSeconds délai d'expiration du heartbeat en secondes
     */
    void setHeartbeatExpirationTimeoutInSeconds(Integer heartbeatExpirationTimeoutInSeconds);

    /**
     * {@link ProcessingDto#JSON_DESCRIPTIVE}.
     */
    String JSON_DESCRIPTIVE = ProcessingDto.JSON_DESCRIPTIVE;

    /**
     * {@link ProcessingDto#JSON_FROM_DATE}.
     */
    String JSON_FROM_DATE = ProcessingDto.JSON_FROM_DATE;

    /**
     * {@link ProcessingDto#JSON_TO_DATE}.
     */
    String JSON_TO_DATE = ProcessingDto.JSON_TO_DATE;

    /**
     * {@link ProcessingDto#JSON_REASON}.
     */
    String JSON_REASON = ProcessingDto.JSON_REASON;

    /**
     * {@link ProcessingDto#JSON_DATE}.
     */
    String JSON_DATE = ProcessingDto.JSON_DATE;

    /**
     * {@link ProcessingDto#JSON_TOTAL_WORK_VOLUME}.
     */
    String JSON_TOTAL_WORK_VOLUME = ProcessingDto.JSON_TOTAL_WORK_VOLUME;

    /**
     * {@link ProcessingDto#JSON_COMPLETED_WORK_VOLUME}.
     */
    String JSON_COMPLETED_WORK_VOLUME = ProcessingDto.JSON_COMPLETED_WORK_VOLUME;

    /**
     * {@link ProcessingDto#JSON_BATCH_SIZE}.
     */
    String JSON_BATCH_SIZE = ProcessingDto.JSON_BATCH_SIZE;

    /**
     * {@link ProcessingDto#JSON_THREAD_COUNT}.
     */
    String JSON_THREAD_COUNT = ProcessingDto.JSON_THREAD_COUNT;

    /**
     * {@link ProcessingDto#JSON_PREVIOUS_IDENTIFIER}.
     */
    String JSON_PREVIOUS_IDENTIFIER = ProcessingDto.JSON_PREVIOUS_IDENTIFIER;

    /**
     * Identifiant json du délai d'expiration du heartbeat en secondes.
     */
    String JSON_HEARTBEAT_EXPIRATION_TIMEOUT_IN_SECONDS =
        HasHeartbeatExpirationTimeoutInSecondsDto.JSON_HEARTBEAT_EXPIRATION_TIMEOUT_IN_SECONDS;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_TRAITEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response create(ProcessingCreateRequestDto request);

  /**
   * Cette classe représente la requête de création de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessingCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ProcessingSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTIVE)
    private String descriptive;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    @JsonbProperty(JSON_REASON)
    private String reason;

    @JsonbProperty(JSON_DATE)
    private LocalDateTime date;

    @JsonbProperty(JSON_TOTAL_WORK_VOLUME)
    private Integer totalWorkVolume;

    @JsonbProperty(JSON_COMPLETED_WORK_VOLUME)
    private Integer completedWorkVolume;

    @JsonbProperty(JSON_BATCH_SIZE)
    private Integer batchSize;

    @JsonbProperty(JSON_THREAD_COUNT)
    private Integer threadCount;

    @JsonbProperty(JSON_PREVIOUS_IDENTIFIER)
    private String previousIdentifier;

    @JsonbProperty(JSON_HEARTBEAT_EXPIRATION_TIMEOUT_IN_SECONDS)
    private Integer heartbeatExpirationTimeoutInSeconds;
  }

  /**
   * Cette classe représente la réponse de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto {

    /**
     * {@link ProcessingDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private ProcessingStatus status;

    /**
     * {@link ProcessingDto#getStartable()}.
     */
    @JsonbProperty(JSON_STARTABLE)
    private Boolean startable;

    /**
     * {@link ProcessingDto#getStoppable()}.
     */
    @JsonbProperty(JSON_STOPPABLE)
    private Boolean stoppable;

    /**
     * {@link ProcessingDto#getCancelable()}.
     */
    @JsonbProperty(JSON_CANCELABLE)
    private Boolean cancelable;

    /**
     * {@link ProcessingDto#getTerminatable()}.
     */
    @JsonbProperty(JSON_TERMINATABLE)
    private Boolean terminatable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status statut
     */
    public void initialize(ProcessingStatus status) {
      this.status = status;
      startable = ProcessingStatus.STARTED.getPrevious().contains(status);
      stoppable = ProcessingStatus.STOPPED.getPrevious().contains(status);
      cancelable = ProcessingStatus.CANCELLED.getPrevious().contains(status);
      terminatable = ProcessingStatus.TERMINATED.getPrevious().contains(status);
    }

    /**
     * {@link ProcessingDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = ProcessingDto.JSON_STATUS;

    /**
     * {@link ProcessingDto#JSON_STARTABLE}.
     */
    public static final String JSON_STARTABLE = ProcessingDto.JSON_STARTABLE;

    /**
     * {@link ProcessingDto#JSON_STOPPABLE}.
     */
    public static final String JSON_STOPPABLE = ProcessingDto.JSON_STOPPABLE;

    /**
     * {@link ProcessingDto#JSON_CANCELABLE}.
     */
    public static final String JSON_CANCELABLE = ProcessingDto.JSON_CANCELABLE;

    /**
     * {@link ProcessingDto#JSON_TERMINATABLE}.
     */
    public static final String JSON_TERMINATABLE = ProcessingDto.JSON_TERMINATABLE;
  }

  /**
   * Cette classe représente la requête de flux de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessingProcessRequestDto extends ByIdentifierRequestDto {

    /**
     * {@link ProcessingDto#getReason()}.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * {@link ProcessingDto#getDate()}.
     */
    @JsonbProperty(JSON_DATE)
    private LocalDateTime date;

    /**
     * {@link ProcessingDto#JSON_REASON}.
     */
    public static final String JSON_REASON = ProcessingDto.JSON_REASON;

    /**
     * {@link ProcessingDto#JSON_DATE}.
     */
    public static final String JSON_DATE = ProcessingDto.JSON_DATE;
  }

  /**
   * Identifiant du service de démarrage.
   */
  String START_IDENTIFIER = "DEMARRAGE_TRAITEMENT";

  /**
   * Chemin du service de démarrage.
   */
  String START_PATH = "demarrage";

  /**
   * Cette méthode permet de démmarer un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(START_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response start(ProcessingProcessRequestDto request);

  /**
   * Identifiant du service d'arrêt.
   */
  String STOP_IDENTIFIER = "ARRET_TRAITEMENT";

  /**
   * Chemin du service d'arrêt.
   */
  String STOP_PATH = "arret";

  /**
   * Cette méthode permet d'arrêter un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(STOP_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response stop(ProcessingProcessRequestDto request);

  /**
   * Identifiant du service d'annulation.
   */
  String CANCEL_IDENTIFIER = "ANNULATION_TRAITEMENT";

  /**
   * Chemin du service d'annulation.
   */
  String CANCEL_PATH = "annulation";

  /**
   * Cette méthode permet d'annuler un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CANCEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response cancel(ProcessingProcessRequestDto request);

  /**
   * Identifiant du service de terminaison.
   */
  String TERMINATE_IDENTIFIER = "TERMINAISON_TRAITEMENT";

  /**
   * Chemin du service de terminaison.
   */
  String TERMINATE_PATH = "terminaison";

  /**
   * Cette méthode permet de terminer un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TERMINATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response terminate(ProcessingProcessRequestDto request);

  /**
   * Identifiant du service de réinitialisation.
   */
  String RESET_IDENTIFIER = "REINITIALISATION_TRAITEMENT";

  /**
   * Chemin du service de réinitialisation.
   */
  String RESET_PATH = "reinitialisation";

  /**
   * Cette méthode permet de réinitialiser un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(RESET_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response reset(ProcessingProcessRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TRAITEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir des traitements.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des traitements")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ProcessingGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcessingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcessingDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_TRAITEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un traitement")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TRAITEMENT";

  /**
   * Chemin du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant un traitement.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un traitement")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TRAITEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ProcessingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un traitement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcessingUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessingUpdateRequestDto extends ByIdentifierRequestDto
      implements ProcessingSaveRequestDto {

    @JsonbProperty(JSON_DESCRIPTIVE)
    private String descriptive;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;

    @JsonbProperty(JSON_REASON)
    private String reason;

    @JsonbProperty(JSON_DATE)
    private LocalDateTime date;

    @JsonbProperty(JSON_TOTAL_WORK_VOLUME)
    private Integer totalWorkVolume;

    @JsonbProperty(JSON_COMPLETED_WORK_VOLUME)
    private Integer completedWorkVolume;

    @JsonbProperty(JSON_BATCH_SIZE)
    private Integer batchSize;

    @JsonbProperty(JSON_THREAD_COUNT)
    private Integer threadCount;

    @JsonbProperty(JSON_PREVIOUS_IDENTIFIER)
    private String previousIdentifier;

    @JsonbProperty(JSON_HEARTBEAT_EXPIRATION_TIMEOUT_IN_SECONDS)
    private Integer heartbeatExpirationTimeoutInSeconds;

    /**
     * Forcer la mise à jour.
     */
    @JsonbProperty("force")
    private Boolean force;
  }

  /**
   * Identifiant du service de mise à jour du volume de travail réalisé.
   */
  String UPDATE_COMPLETED_WORK_VOLUME_IDENTIFIER = "MISE_A_JOUR_VOLUME_TRAVAIL_REALISE_TRAITEMENT";

  /**
   * Chemin du service de mise à jour du volume de travail réalisé.
   */
  String UPDATE_COMPLETED_WORK_VOLUME_PATH = "volume-travail-realise";

  /**
   * Cette méthode permet de mettre à jour le volume de travail réalisé.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_COMPLETED_WORK_VOLUME_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response updateCompletedWorkVolume(ProcessingUpdateCompletedWorkVolumeRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour du volume de travail réalisé.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessingUpdateCompletedWorkVolumeRequestDto extends ByIdentifierRequestDto
      implements HasValueDto<Integer>, HasHeartbeatEmitterIdentifierDto {

    @JsonbProperty(JSON_VALUE)
    private Integer value;

    /**
     * Proportion du volume total de travail.
     */
    @JsonbProperty(JSON_PROPORTION)
    private BigDecimal proportion;

    /**
     * Est un increment si vrai ou un décrément si faux. N'est rien si null.
     */
    @JsonbProperty(JSON_IS_INCREMENT)
    private Boolean isIncrement;

    @JsonbProperty(JSON_HEARTBEAT_EMITTER_IDENTIFIER)
    private String heartbeatEmitterIdentifier;

    /**
     * Cette méthode permet de calculer le volume de travail réalisé.
     *
     * @param totalWorkVolume volume de travail total.
     * @param currentCompletedWorkVolume volume de travail réalisé courant.
     * @return volume de travail réalisé
     */
    public Integer computeCompletedWorkVolume(Integer totalWorkVolume,
        Integer currentCompletedWorkVolume) {
      if (isIncrement == null) {
        return value;
      }
      return currentCompletedWorkVolume + (isIncrement ? 1 : -1) * value;
    }

    /**
     * {@link #proportion}.
     */
    public static final String JSON_PROPORTION = "proportion";

    /**
     * {@link #isIncrement}.
     */
    public static final String JSON_IS_INCREMENT = "estIncrement";
  }

  /**
   * Identifiant du service d'enregistrement de heartbeat.
   */
  String REGISTER_HEARTBEAT_IDENTIFIER = "ENREGISTREMENT_HEARTBEAT_TRAITEMENT";

  /**
   * Chemin du service d'enregistrement de heartbeat.
   */
  String REGISTER_HEARTBEAT_PATH = "heartbeat";

  /**
   * Cette méthode permet d'enregistrer un heartbeat.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REGISTER_HEARTBEAT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REGISTER_HEARTBEAT_IDENTIFIER,
      description = "Ce service permet d'enregistrer un heartbeat")
  Response registerHeartbeat(ProcessingRegisterHeartbeatRequestDto request);

  /**
   * Cette classe représente la requête d'enregistrement de heartbeat.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessingRegisterHeartbeatRequestDto extends ByIdentifierRequestDto
      implements HasHeartbeatEmitterIdentifierDto {

    @JsonbProperty(JSON_HEARTBEAT_EMITTER_IDENTIFIER)
    private String heartbeatEmitterIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TRAITEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ProcessingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un traitement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_TACHE";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER,
      description = "Ce service permet d'obtenir un graphique")
  Response getChart(GetChartRequestDto request);
}
