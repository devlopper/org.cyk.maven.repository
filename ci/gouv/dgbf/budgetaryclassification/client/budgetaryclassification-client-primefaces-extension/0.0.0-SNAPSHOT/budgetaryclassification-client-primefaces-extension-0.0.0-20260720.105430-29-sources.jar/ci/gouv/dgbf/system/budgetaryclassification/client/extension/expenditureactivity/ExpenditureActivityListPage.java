package ci.gouv.dgbf.system.budgetaryclassification.client.extension.expenditureactivity;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link ExpenditureActivityDto}.
 *
 * @author AKM
 *
 */
@Named
@ViewScoped
public class ExpenditureActivityListPage extends AbstractPage {

  @Inject
  @Getter
  ExpenditureActivityController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ExpenditureActivityDto.NAME;
    controller.initialize();
  }

  public static final String OUTCOME = "expenditureActivityListPage";
}
