package ci.gouv.dgbf.extension.primefaces.component;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représnte le message d'un composant.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Message extends AbstractWidget {
  
  String forId;
  
}
