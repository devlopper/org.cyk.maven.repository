package ci.gouv.dgbf.system.file.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class FileIconManager {

  String filesGroupStatusCreated;
  
  String filesGroupConfirm;
  String filesGroupStatusConfirmed;
  
  /**
   * Cette méthode permet d'instancier.
   */
  public FileIconManager() {
    filesGroupStatusCreated = "pi pi-pencil";
    
    filesGroupConfirm = "pi pi-thumbs-up";
    filesGroupStatusConfirmed = filesGroupConfirm;
  }
}
