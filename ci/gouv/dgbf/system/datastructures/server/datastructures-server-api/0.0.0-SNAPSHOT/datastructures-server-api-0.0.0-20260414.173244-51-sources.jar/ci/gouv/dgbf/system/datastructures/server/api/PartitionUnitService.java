package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasPartitionTypeCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasPartitionValueDataDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link HierarchyDto}.
 *
 * @author Arnaud
 */
@Path(value = PartitionUnitService.PATH)
@Tag(name = "Gestion des unités de partition")
public interface PartitionUnitService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "unites-partitions";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface PartitionUnitSaveRequestDto {
    /**
     * Cette méthode me permet d'obtenir l'identifiant de {@link PartitionDto}.
     *
     * @return identifiant de {@link PartitionDto}
     */
    String getPartitionIdentifier();

    /**
     * Cette méthode me permet d'assigner l'identifiant de {@link PartitionUnitDto}.
     *
     * @param identifier identifiant de {@link PartitionUnitDto}
     */
    void setPartitionIdentifier(String identifier);

    /**
     * Identifiant json de {@link PartitionUnitDto}.
     */
    String JSON_PARTITION_IDENTIFIER = PartitionUnitDto.JSON_PARTITION_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UNITE_PARTITION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PartitionUnitCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class PartitionUnitCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements PartitionUnitSaveRequestDto {

    @JsonbProperty(JSON_PARTITION_IDENTIFIER)
    private String partitionIdentifier;
  }

  /**
   * Cette interface représente la requête d'enregistrement par libellé.
   *
   * @author Arnaud
   */
  interface PartitionUnitSaveByNameRequestDto {
    /**
     * Cette méthode permet d'obtenir le libellé.
     *
     * @return le libellé
     */
    String getName();

    /**
     * Cette méthode permet d'assigner le libellé.
     *
     * @param name le libellé
     */
    void setName(String name);

    /**
     * Cette méthode permet d'obtenir la donnée de la valeur de la partition.
     *
     * @return la donnée de la valeur de la partition
     */
    String getPartitionValueData();

    /**
     * Cette méthode permet d'assigner la donnée de la valeur de la partition.
     *
     * @param partitionValueData la donnée de la valeur de la partition
     */
    void setPartitionValueData(String partitionValueData);

    /**
     * {@link HasNameDto#JSON_NAME}.
     */
    String JSON_NAME = HasNameDto.JSON_NAME;

    /**
     * {@link HasPartitionValueDataDto#JSON_PARTITION_VALUE_DATA}.
     */
    String JSON_PARTITION_VALUE_DATA = HasPartitionValueDataDto.JSON_PARTITION_VALUE_DATA;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_BY_NAME_IDENTIFIER = "CREATION_PAR_LIBELLE_UNITE_PARTITION";

  /**
   * Chemin du service de création.
   */
  String CREATE_BY_NAME_PATH = "creation-par-libelle";

  /**
   * Cette méthode permet de créer {@link PartitionUnitDto} par libellé.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_NAME_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_NAME_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByName(PartitionUnitCreateByNameRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class PartitionUnitCreateByNameRequestDto extends AbstractNamableCreateRequestJsonDto
      implements PartitionUnitSaveByNameRequestDto {

    @JsonbProperty(JSON_PARTITION_TYPE_CODE)
    private String partitionTypeCode;

    @JsonbProperty(JSON_PARTITION_VALUE_DATA)
    private String partitionValueData;

    @JsonbProperty(JSON_SHOULD_CREATE_PARTITION_IF_DOES_NOT_EXIST)
    private Boolean shouldCreatePartitionIfDoesNotExist;

    @JsonbProperty(JSON_SHOULD_DELETE_PARTITION_WHEN_ALL_UNITS_DELETED)
    private Boolean shouldDeletePartitionWhenAllUnitsDeleted;

    /**
     * {@link HasPartitionTypeCodeDto#JSON_PARTITION_TYPE_CODE}.
     */
    public static final String JSON_PARTITION_TYPE_CODE =
        HasPartitionTypeCodeDto.JSON_PARTITION_TYPE_CODE;

    /**
     * Identifiant json {@link #shouldCreatePartitionIfDoesNotExist}.
     */
    public static final String JSON_SHOULD_CREATE_PARTITION_IF_DOES_NOT_EXIST =
        "doitCreerPartitionSiInexistante";

    /**
     * Identifiant json {@link #shouldDeletePartitionWhenAllUnitsDeleted}.
     */
    public static final String JSON_SHOULD_DELETE_PARTITION_WHEN_ALL_UNITS_DELETED =
        "doitSupprimerPartitionSiTousEnfantsSupprimes";
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_UNITE_PARTITION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PartitionUnitGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  public static class PartitionUnitGetManyResponseDto
      extends AbstractGetByPageResponseDto<PartitionUnitDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PartitionUnitDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_UNITE_PARTITION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PartitionUnitDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_UNITE_PARTITION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PartitionUnitDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_UNITE_PARTITION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PartitionUnitUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class PartitionUnitUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements PartitionUnitSaveRequestDto {

    @JsonbProperty(JSON_PARTITION_IDENTIFIER)
    private String partitionIdentifier;
  }

  /**
   * Identifiant du service de mise à jour par libellé.
   */
  String UPDATE_BY_NAME_IDENTIFIER = "MISE_A_JOUR_PAR_LIBELLE_UNITE_PARTITION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_BY_NAME_PATH = "mise-a-jour-par-libelle";

  /**
   * Cette méthode permet de mettre à jour {@link PartitionUnitDto} par libellé.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_BY_NAME_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_BY_NAME_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateByName(PartitionUnitUpdateByNameRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class PartitionUnitUpdateByNameRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements PartitionUnitSaveByNameRequestDto {

    @JsonbProperty(JSON_PARTITION_VALUE_DATA)
    private String partitionValueData;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UNITE_PARTITION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PartitionUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
