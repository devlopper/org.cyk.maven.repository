package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'application.
 *
 * @author BoobaCool
 */
public interface HasApplicationAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'application.
   *
   * @return représentation en chaine de caractères de l'application
   */
  String getApplicationAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'application.
   *
   * @param applicationAsString représentation en chaine de caractères de l'application
   */
  void setApplicationAsString(String applicationAsString);

  /**
   * Identifiant java de représentation en chaine de caractères de l'application.
   */
  String FIELD_APPLICATION_AS_STRING = "applicationAsString";
}
