package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un constructeur de {@link LabelValueGroupsInformationCard} de
 * {@link DocumentTypeGroupDto}.
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class DocumentTypeGroupLabelValueGroupsInformationCardBuilder {

  DocumentationIconManager iconManager;

  String type;

  String group;

  /**
   * Cette méthode permet de construire.
   *
   * @param iconManager {@link DocumentationIconManager}
   */
  public DocumentTypeGroupLabelValueGroupsInformationCardBuilder(
      DocumentationIconManager iconManager) {
    this.iconManager = iconManager;
  }

  /**
   * Cette méthode permet de construire.
   *
   * @return {@link LabelValueGroupsInformationCard}
   */
  public LabelValueGroupsInformationCard build() {
    LabelValueGroupsInformationCard labelValueGroupsInformationCard =
        new LabelValueGroupsInformationCard();
    labelValueGroupsInformationCard.getHeaderText().setValue("Propriétés");
    LabelValueGroupsInformationCard.Group informationCardGroup =
        labelValueGroupsInformationCard.group();
    informationCardGroup.addIfValueNotBlank("Type de document", type)
        .addIfValueNotBlank("Groupe de types de document", group);

    return labelValueGroupsInformationCard;
  }
}
