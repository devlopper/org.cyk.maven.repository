package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur de configuration d'impression de rapport.
 *
 * @author Christian
 */
@Dependent
public class ReportPrintConfigurationController extends AbstractController {

  /**
   * Identifiant du rapport.
   */
  @Getter
  @Setter
  String reportIdentifier;

  /**
   * {@link ConfigurationType}.
   */
  @Getter
  @Setter
  ConfigurationType configurationType;

  /**
   * Paramètres du rapport.
   */
  @Getter
  @Setter
  Map<String, List<String>> parameters;

  /**
   * Nom du paramètre référence.
   */
  @Getter
  @Setter
  String referenceParameterName;

  /**
   * Valeur du paramètre référence.
   */
  @Getter
  @Setter
  String referenceParameterValue;

  /**
   * {@link PrintButtonController}.
   */
  @Inject
  @Getter
  PrintButtonController buttonController;

  /**
   * {@link PrintParametersDialogController}.
   */
  @Inject
  @Getter
  PrintParametersDialogController parametersDialogController;

  /**
   * Cette méthode représente un constructeur.
   *
   */
  protected ReportPrintConfigurationController() {
    referenceParameterName = HasIdentifierDto.JSON_IDENTIFIER;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    Core.doThrowIfBlank(IllegalArgumentException.class, "identifiant de rapport requis",
        reportIdentifier);
    Core.doThrowIfNull(IllegalArgumentException.class, "type de configuration d'impression requis",
        configurationType);

    parametersDialogController.setReportIdentifier(reportIdentifier);
    
    buttonController.setParametersDialogController(parametersDialogController);
    buttonController.initialize();
    
    switch (configurationType) {
      case DERIVED_REFERENCE_PARAMETER -> initializeDerivedReference();
      case GIVEN_REFERENCE_PARAMETER -> initializeGivenReference();
      case GIVEN_PARAMETERS -> initializeGivenParameters();
      default -> throw new IllegalStateException(
          "Type de configuration d'impression non supporté : " + configurationType);
    }
  }

  /**
   * Cette méthode permet d'initialiser dans le cas d'une référence dérivée.
   */
  protected void initializeDerivedReference() {
    buttonController.getButton().setTypeAsSubmit();
    buttonController.getButton().setActionFunction(actionFunction());
  }

  /**
   * Cette méthode permet d'initialiser dans le cas d'une référence fournie.
   */
  protected void initializeGivenReference() {
    buttonController.getButton().setTypeAsButton();
    parametersDialogController
        .setViewerOpenerConsumer(viewerOpener(referenceParameterName, referenceParameterValue));
    buttonController.computeOnClick();
  }

  /**
   * Cette méthode permet d'initialiser dans le cas de paramètres fournis.
   */
  protected void initializeGivenParameters() {
    buttonController.getButton().setTypeAsButton();
    parametersDialogController.setViewerOpenerConsumer(viewerOpener(parameters));
    buttonController.computeOnClick();
  }

  Function<Object, String> actionFunction() {
    return element -> {
      parametersDialogController.setViewerOpenerConsumer(
          viewerOpener(referenceParameterName, Core.getIdentifier(element)));
      parametersDialogController.open();
      return null;
    };
  }

  Consumer<ViewerOpener> viewerOpener(String parameterName, String paramterValue) {
    return opener -> opener.scriptBuilder().uriBuilder().reportParametersAsJsonBuilder().map()
        .add(parameterName, paramterValue);
  }
  
  Consumer<ViewerOpener> viewerOpener(Map<String, List<String>> parameters) {
    return opener -> opener.scriptBuilder().uriBuilder().reportParametersAsJsonBuilder().map()
        .add(parameters);
  }

  /**
   * Cette énumération représente les types de configuration d'impression.
   */
  public enum ConfigurationType {
    /**
     * Paramètres donnés.
     */
    GIVEN_PARAMETERS,

    /**
     * Paramètre référence donné.
     */
    GIVEN_REFERENCE_PARAMETER,

    /**
     * Paramètre référence dérivé.
     */
    DERIVED_REFERENCE_PARAMETER,

    /**
     * Inconnu.
     */
    UNKNOWN
  }
}
