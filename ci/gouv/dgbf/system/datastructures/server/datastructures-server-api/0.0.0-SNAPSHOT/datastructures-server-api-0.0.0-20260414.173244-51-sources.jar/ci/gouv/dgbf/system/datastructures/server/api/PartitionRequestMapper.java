package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService.PartitionCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService.PartitionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PartitionDto}.
 *
 * @author Arnaud
 */
@Mapper
@Javadoc("""
        Cette interface représente le mapping de requête et {@link PartitionDto}.

        @author Arnaud
        """)
public interface PartitionRequestMapper
        extends RequestMapper<PartitionDto, PartitionCreateRequestDto, PartitionUpdateRequestDto> {

}
