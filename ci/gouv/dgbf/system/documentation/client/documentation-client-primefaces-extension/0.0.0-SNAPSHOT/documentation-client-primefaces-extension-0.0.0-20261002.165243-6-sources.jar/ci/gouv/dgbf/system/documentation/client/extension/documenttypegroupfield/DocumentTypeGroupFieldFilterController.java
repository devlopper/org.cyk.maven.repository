package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroupfield;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link DocumentTypeGroupFieldDto}.
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentTypeGroupFieldFilterController
    extends AbstractFilterController<DocumentTypeGroupFieldFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public DocumentTypeGroupFieldFilterController() {
    super(DocumentTypeGroupFieldFilter.class);
  }
}
