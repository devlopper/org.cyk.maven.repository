package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementTypeDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * {@link #AdministrativeUnitEmployeeStatus}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS)
  private AdministrativeUnitEmployeeStatus administrativeUnitEmployeeStatus;

  /**
   * Représentation en chaine de caractères de {@link #EmployeeStatus}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS_AS_STRING)
  private String administrativeUnitEmployeeStatusAsString;

  /**
   * Identifiant json de identifiant de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeMouvement";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link MovementTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeMouvementChaine";

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeStatus}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS =
      "statutEmployeUniteAdministrative";

  /**
   * Identifiant json de {@link #administrativeUnitEmployeeStatusAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_STATUS_AS_STRING =
      "statutEmployeUniteAdministrativeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de mouvement";
}
