package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.LocalityGroupService.LocalityGroupCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.LocalityGroupService.LocalityGroupGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.LocalityGroupService.LocalityGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link LocalityGroupService}.
 *
 * @author arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class LocalityGroupClient extends AbstractClient<LocalityGroupService>
        implements GetByIdentifier<LocalityGroupDto>, GetMany<LocalityGroupGetManyResponseDto>,
        DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public LocalityGroupClient service(LocalityGroupService service) {
    return (LocalityGroupClient) super.service(service);
  }

  /**
   * {@link LocalityGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(LocalityGroupCreateRequestDto request) {
    return new CreateExecutor(LocalityGroupService.CREATE_IDENTIFIER)
                .execute(() -> service().create(request));
  }

  /**
   * {@link LocalityGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public LocalityGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<LocalityGroupGetManyResponseDto>(
        LocalityGroupGetManyResponseDto.class,
            LocalityGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link LocalityGroupService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LocalityGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
        PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link LocalityGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public LocalityGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<LocalityGroupDto>(LocalityGroupDto.class,
            LocalityGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link LocalityGroupService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public LocalityGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
        String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link LocalityGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public LocalityGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<LocalityGroupDto>(LocalityGroupDto.class,
            LocalityGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link LocalityGroupService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public LocalityGroupDto getByIdentifier(String identifier, 
        ProjectionDto projection, String auditWho,
            String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link LocalityGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(LocalityGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(LocalityGroupService.UPDATE_IDENTIFIER)
                .execute(() -> service().update(request));
  }

  /**
   * {@link LocalityGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(LocalityGroupService.DELETE_IDENTIFIER)
                .execute(() -> service().delete(request));
  }

  /**
   * {@link LocalityGroupService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
            String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}