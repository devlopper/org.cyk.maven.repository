package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le pourcentage de progression de la saisie
 * pour l'année N.
 *
 * @author Christian
 */
public interface HasInputProgressPercentageN {

  /**
   * Obtient le pourcentage de progression de la saisie pour l'année N.
   *
   * @return le pourcentage de progression de la saisie pour l'année N,
   *         {@code null} si aucun pourcentage n'est défini
   */
  Integer getInputProgressPercentageN();

  /**
   * Définit le pourcentage de progression de la saisie pour l'année N.
   *
   * @param inputProgressPercentageN le pourcentage de progression de la saisie pour l'année N
   */
  void setInputProgressPercentageN(Integer inputProgressPercentageN);

  /**
   * Identifiant java du pourcentage de progression de la saisie pour l'année N.
   */
  String FIELD_INPUT_PROGRESS_PERCENTAGE_N = "inputProgressPercentageN";
}