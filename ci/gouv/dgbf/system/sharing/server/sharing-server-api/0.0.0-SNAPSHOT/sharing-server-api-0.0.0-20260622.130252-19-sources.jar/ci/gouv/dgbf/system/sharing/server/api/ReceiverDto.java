package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un destinataire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReceiverDto extends AbstractResourceOrReceiverDto {
  
  /**
   * {@link ReceiverType}.
   */
  @JsonbProperty(JSON_TYPE)
  private ReceiverType type;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "destinataire";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
