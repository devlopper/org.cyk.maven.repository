package ci.gouv.dgbf.system.servicecatalog.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les classifications stratégiques (DDD) d'un {@link ModuleDto}, valeurs
 * du référentiel {@code TR_CLASSIFICATION_STRATEGIQUE}.
 *
 * @author Christian
 *
 */
@Getter
public enum StrategicClassification {

  /**
   * {@link StrategicClassificationCode#CORE_DOMAIN}.
   */
  CORE_DOMAIN(StrategicClassificationCode.CORE_DOMAIN, "Domaine cœur"),

  /**
   * {@link StrategicClassificationCode#SUPPORTING_SUBDOMAIN}.
   */
  SUPPORTING_SUBDOMAIN(StrategicClassificationCode.SUPPORTING_SUBDOMAIN, "Sous-domaine support"),

  /**
   * {@link StrategicClassificationCode#GENERIC_SUBDOMAIN}.
   */
  GENERIC_SUBDOMAIN(StrategicClassificationCode.GENERIC_SUBDOMAIN, "Sous-domaine générique");

  private String code;
  private String name;

  private StrategicClassification(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link StrategicClassification} par code.
   *
   * @param code code
   * @return {@link StrategicClassification}
   */
  public static StrategicClassification getByCode(String code) {
    return Stream.of(StrategicClassification.values())
        .filter(classification -> classification.getCode().equals(code)
            || classification.name().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
