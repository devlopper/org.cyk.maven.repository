package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des anomalies inter-modules.
 */
@Path(value = AnomalyService.PATH)
@Tag(name = "Gestion des anomalies")
public interface AnomalyService extends SpecificService {

  String PATH = "anomalies";

  String CREATE_IDENTIFIER = "CREATION_ANOMALIE";
  String CREATE_PATH = "";

  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ANOMALIE";
  String GET_MANY_PATH = "obtention/plusieurs";

  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ANOMALIE";
  String GET_ONE_PATH = "obtention/un";

  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ANOMALIE";
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  String TREAT_IDENTIFIER = "TRAITEMENT_ANOMALIE";
  String TREAT_PATH = "traitement";

  /**
   * Crée une nouvelle anomalie.
   *
   * @param request requête de création
   * @return réponse HTTP
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(AnomalyCreateRequestDto request);

  /**
   * Obtient plusieurs anomalies avec pagination.
   *
   * @param request requête de recherche
   * @return réponse HTTP
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = AnomalyGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Obtient une seule anomalie par critère.
   *
   * @param request requête
   * @return réponse HTTP
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = AnomalyDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Obtient une anomalie par son identifiant technique.
   *
   * @param request requête
   * @return réponse HTTP
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = AnomalyDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Traite une anomalie (action de workflow irréversible).
   *
   * @param request requête de traitement
   * @return réponse HTTP
   */
  @Path(TREAT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TREAT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response treat(AnomalyTreatRequestDto request);

  /**
   * Requête de création d'une anomalie.
   */
  @Getter
  @Setter
  class AnomalyCreateRequestDto extends AbstractAuditedRequestJsonDto {

    @JsonbProperty("type")
    private AnomalyType type;

    @JsonbProperty("module")
    private String module;

    @JsonbProperty("contexte")
    private String context;
  }

  /**
   * Requête de traitement d'une anomalie par l'administrateur.
   */
  @Getter
  @Setter
  class AnomalyTreatRequestDto extends ByIdentifierRequestDto {

    @JsonbProperty("commentaireTraitement")
    private String treatmentComment;
  }

  /**
   * Réponse paginée pour l'obtention de plusieurs anomalies.
   */
  @Getter
  @Setter
  class AnomalyGetManyResponseDto extends AbstractGetByPageResponseDto<AnomalyDto> {

    @JsonbProperty(JSON_DATAS)
    private List<AnomalyDto> datas;

    @Override
    public List<AnomalyDto> getDatas() {
      return datas;
    }
  }
}

