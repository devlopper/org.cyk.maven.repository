package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketAssignUserRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketClaimRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketClaimResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketCreateChildRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketDissatisfyRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketDissatisfyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketEscalateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketEscalateResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketGetManyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketRedirectRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketRedirectResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketResolveRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketResolveResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketSatisfyRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketSatisfyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TicketService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TicketClient extends AbstractClient<TicketService>
    implements GetByIdentifier<TicketDto>, GetMany<TicketGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public TicketClient service(TicketService service) {
    return (TicketClient) super.service(service);
  }

  /**
   * {@link TicketService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(TicketCreateRequestDto request) {
    return new CreateExecutor(TicketService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TicketService#create}.
   *
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    TicketCreateRequestDto request = new TicketCreateRequestDto();
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link TicketService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TicketGetManyResponseDto>(TicketGetManyResponseDto.class,
        TicketService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link TicketService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TicketGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TicketService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TicketDto>(TicketDto.class, TicketService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link TicketService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TicketDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TicketService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public TicketDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TicketDto>(TicketDto.class,
        TicketService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TicketService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TicketDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TicketService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(TicketService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link TicketService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(TicketUpdateRequestDto request) {
    return new IdentifiableExecutor(TicketService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TicketService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    TicketUpdateRequestDto request = new TicketUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link TicketService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TicketService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link TicketService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link TicketService#claim}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketClaimResponseDto claim(TicketClaimRequestDto request) {
    return new GetOneExecutor<>(TicketClaimResponseDto.class,
        TicketService.CLAIM_IDENTIFIER).execute(() -> service().claim(request));
  }

  /**
   * {@link TicketService#resolve}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketResolveResponseDto resolve(TicketResolveRequestDto request) {
    return new GetOneExecutor<>(TicketResolveResponseDto.class, TicketService.RESOLVE_IDENTIFIER)
        .execute(() -> service().resolve(request));
  }

  /**
   * {@link TicketService#satisfy}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketSatisfyResponseDto satisfy(TicketSatisfyRequestDto request) {
    return new GetOneExecutor<>(TicketSatisfyResponseDto.class, TicketService.SATISFY_IDENTIFIER)
        .execute(() -> service().satisfy(request));
  }

  /**
   * {@link TicketService#dissatisfy}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketDissatisfyResponseDto dissatisfy(TicketDissatisfyRequestDto request) {
    return new GetOneExecutor<>(TicketDissatisfyResponseDto.class,
        TicketService.DISSATISFY_IDENTIFIER).execute(() -> service().dissatisfy(request));
  }

  /**
   * {@link TicketService#redirect}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketRedirectResponseDto redirect(TicketRedirectRequestDto request) {
    return new GetOneExecutor<>(TicketRedirectResponseDto.class,
        TicketService.REDIRECT_IDENTIFIER).execute(() -> service().redirect(request));
  }

  /**
   * {@link TicketService#escalate}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketEscalateResponseDto escalate(TicketEscalateRequestDto request) {
    return new GetOneExecutor<>(TicketEscalateResponseDto.class,
        TicketService.ESCALATE_IDENTIFIER).execute(() -> service().escalate(request));
  }


  /**
   * {@link TicketService#assignUser}.
   *
   * @param request requête
   * @return réponse
   */
  public TicketAssignUserRequestDto assignUser(TicketAssignUserRequestDto request) {
    return new GetOneExecutor<>(TicketAssignUserRequestDto.class,
        TicketService.ASSIGN_USER_IDENTIFIER).execute(() -> service().assignUser(request));
  }

  /**
   * {@link TicketService#createChild}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createChild(TicketCreateChildRequestDto request) {
    return new CreateExecutor(TicketService.CREATE_CHILD_IDENTIFIER)
        .execute(() -> service().createChild(request));
  }
}
