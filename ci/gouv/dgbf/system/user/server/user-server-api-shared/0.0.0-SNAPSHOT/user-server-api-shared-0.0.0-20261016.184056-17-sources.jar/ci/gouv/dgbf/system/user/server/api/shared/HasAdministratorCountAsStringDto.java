package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'administrateurs sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasAdministratorCountAsStringDto extends HasAdministratorCountAsString {

  /**
   * Identifiant json du nombre d'administrateurs sous forme de chaîne.
   */
  String JSON_ADMINISTRATOR_COUNT_AS_STRING = "nombreAdministrateursChaine";
}
