package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.RemunerableService.RemunerableCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.RemunerableService.RemunerableUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RemunerableDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et
    {@link RemunerableDto}.

    @author Christian
               """)
public interface RemunerableRequestMapper extends
    RequestMapper<RemunerableDto, RemunerableCreateRequestDto, RemunerableUpdateRequestDto> {

}
