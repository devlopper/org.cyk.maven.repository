package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ApplicationDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-30T08:59:57+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ApplicationRequestMapperImpl implements ApplicationRequestMapper {

    @Override
    public ApplicationService.ApplicationCreateRequestDto mapCreate(ApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ApplicationService.ApplicationCreateRequestDto applicationCreateRequestDto = new ApplicationService.ApplicationCreateRequestDto();

        applicationCreateRequestDto.setCode( arg0.getCode() );
        applicationCreateRequestDto.setName( arg0.getName() );
        applicationCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );

        return applicationCreateRequestDto;
    }

    @Override
    public ApplicationService.ApplicationUpdateRequestDto mapUpdate(ApplicationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ApplicationService.ApplicationUpdateRequestDto applicationUpdateRequestDto = new ApplicationService.ApplicationUpdateRequestDto();

        applicationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        applicationUpdateRequestDto.setCode( arg0.getCode() );
        applicationUpdateRequestDto.setName( arg0.getName() );
        applicationUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );

        return applicationUpdateRequestDto;
    }
}
