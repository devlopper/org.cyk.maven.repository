package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimedValueDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-15T15:46:51+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimedValueRequestMapperImpl implements ClaimedValueRequestMapper {

    @Override
    public ClaimedValueService.ClaimedValueCreateRequestDto mapCreate(ClaimedValueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimedValueService.ClaimedValueCreateRequestDto claimedValueCreateRequestDto = new ClaimedValueService.ClaimedValueCreateRequestDto();

        claimedValueCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimedValueCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimedValueCreateRequestDto.setClaimIdentifier( arg0.getClaimIdentifier() );
        claimedValueCreateRequestDto.setClaimTypeClaimableIdentifier( arg0.getClaimTypeClaimableIdentifier() );
        claimedValueCreateRequestDto.setNature( arg0.getNature() );
        claimedValueCreateRequestDto.setValue( arg0.getValue() );
        claimedValueCreateRequestDto.setValueType( arg0.getValueType() );
        claimedValueCreateRequestDto.setClaimableValueIdentifier( arg0.getClaimableValueIdentifier() );
        claimedValueCreateRequestDto.setCurrentMovementIdentifier( arg0.getCurrentMovementIdentifier() );
        claimedValueCreateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );
        claimedValueCreateRequestDto.setRetainedValue( arg0.getRetainedValue() );
        claimedValueCreateRequestDto.setRetainedValueType( arg0.getRetainedValueType() );
        claimedValueCreateRequestDto.setRetainedClaimableValueIdentifier( arg0.getRetainedClaimableValueIdentifier() );
        claimedValueCreateRequestDto.setRetainedCurrentMovementIdentifier( arg0.getRetainedCurrentMovementIdentifier() );
        claimedValueCreateRequestDto.setRetainedEffectiveDate( arg0.getRetainedEffectiveDate() );

        return claimedValueCreateRequestDto;
    }

    @Override
    public ClaimedValueService.ClaimedValueUpdateRequestDto mapUpdate(ClaimedValueDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimedValueService.ClaimedValueUpdateRequestDto claimedValueUpdateRequestDto = new ClaimedValueService.ClaimedValueUpdateRequestDto();

        claimedValueUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimedValueUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimedValueUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimedValueUpdateRequestDto.setClaimIdentifier( arg0.getClaimIdentifier() );
        claimedValueUpdateRequestDto.setClaimTypeClaimableIdentifier( arg0.getClaimTypeClaimableIdentifier() );
        claimedValueUpdateRequestDto.setNature( arg0.getNature() );
        claimedValueUpdateRequestDto.setValue( arg0.getValue() );
        claimedValueUpdateRequestDto.setValueType( arg0.getValueType() );
        claimedValueUpdateRequestDto.setClaimableValueIdentifier( arg0.getClaimableValueIdentifier() );
        claimedValueUpdateRequestDto.setCurrentMovementIdentifier( arg0.getCurrentMovementIdentifier() );
        claimedValueUpdateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );
        claimedValueUpdateRequestDto.setRetainedValue( arg0.getRetainedValue() );
        claimedValueUpdateRequestDto.setRetainedValueType( arg0.getRetainedValueType() );
        claimedValueUpdateRequestDto.setRetainedClaimableValueIdentifier( arg0.getRetainedClaimableValueIdentifier() );
        claimedValueUpdateRequestDto.setRetainedCurrentMovementIdentifier( arg0.getRetainedCurrentMovementIdentifier() );
        claimedValueUpdateRequestDto.setRetainedEffectiveDate( arg0.getRetainedEffectiveDate() );

        return claimedValueUpdateRequestDto;
    }
}
