package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentitiesGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-24T12:48:30+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentitiesGroupRequestMapperImpl implements IdentitiesGroupRequestMapper {

    @Override
    public IdentitiesGroupService.IdentitiesGroupCreateRequestDto mapCreate(IdentitiesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentitiesGroupService.IdentitiesGroupCreateRequestDto identitiesGroupCreateRequestDto = new IdentitiesGroupService.IdentitiesGroupCreateRequestDto();

        identitiesGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identitiesGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identitiesGroupCreateRequestDto.setCascadeOnDelete( arg0.getCascadeOnDelete() );
        identitiesGroupCreateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identitiesGroupCreateRequestDto.setIdentityRole( arg0.getIdentityRole() );

        return identitiesGroupCreateRequestDto;
    }

    @Override
    public IdentitiesGroupService.IdentitiesGroupUpdateRequestDto mapUpdate(IdentitiesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentitiesGroupService.IdentitiesGroupUpdateRequestDto identitiesGroupUpdateRequestDto = new IdentitiesGroupService.IdentitiesGroupUpdateRequestDto();

        identitiesGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identitiesGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identitiesGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identitiesGroupUpdateRequestDto.setCascadeOnDelete( arg0.getCascadeOnDelete() );
        identitiesGroupUpdateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identitiesGroupUpdateRequestDto.setIdentityRole( arg0.getIdentityRole() );

        return identitiesGroupUpdateRequestDto;
    }
}
