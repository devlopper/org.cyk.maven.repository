package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link IdentityGroupRoleDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = IdentityGroupRoleService.PATH)
@Tag(name = "Gestion des rôles d'identités de groupe")
public interface IdentityGroupRoleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "roles-identites-groupes";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un rôle d'identité de groupe.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un rôle d'identité de groupe",
      description = "Ce service permet de créer un rôle d'identité de groupe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(IdentityGroupRoleCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface IdentityGroupRoleSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link IdentityGroupDto}.
     *
     * @return identifiant de {@link IdentityGroupDto}
     */
    String getIdentityGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link IdentityGroupDto}.
     *
     * @param identityGroupIdentifier identifiant de {@link IdentityGroupDto}
     */
    void setIdentityGroupIdentifier(String identityGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RoleDto}.
     *
     * @return identifiant de {@link RoleDto}
     */
    String getRoleIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de @link RoleDto}.
     *
     * @param roleIdentifier identifiant de @link RoleDto}
     */
    void setRoleIdentifier(String roleIdentifier);

    /**
     * {@link IdentityGroupRoleDto#JSON_IDENTITY_GROUP_IDENTIFIER}.
     */
    String JSON_IDENTITY_GROUP_IDENTIFIER = IdentityGroupRoleDto.JSON_IDENTITY_GROUP_IDENTIFIER;

    /**
     * {@link IdentityGroupRoleDto#JSON_ROLE_IDENTIFIER}.
     */
    String JSON_ROLE_IDENTIFIER = IdentityGroupRoleDto.JSON_ROLE_IDENTIFIER;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityGroupRoleCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements IdentityGroupRoleSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_GROUP_IDENTIFIER)
    private String identityGroupIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des rôles d'identités de groupe")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class IdentityGroupRoleGetManyResponseDto
      extends AbstractGetByPageResponseDto<IdentityGroupRoleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<IdentityGroupRoleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un rôle d'identité de groupe")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link IdentityGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un rôle d'identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentityGroupRoleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link IdentityGroupRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un rôle d'identité de groupe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(IdentityGroupRoleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class IdentityGroupRoleUpdateRequestDto extends ByIdentifierRequestDto
      implements IdentityGroupRoleSaveRequestDto {
    @JsonbProperty(JSON_IDENTITY_GROUP_IDENTIFIER)
    private String identityGroupIdentifier;

    @JsonbProperty(JSON_ROLE_IDENTIFIER)
    private String roleIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_IDENTITE_GROUPE_ROLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un rôle d'identité de groupe")
  Response delete(DeleteOneRequestDto request);
}
