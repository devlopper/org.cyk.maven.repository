package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressService.EmailAddressGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client de {@link EmailAddressService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class EmailAddressClient extends AbstractClient<EmailAddressService>
    implements GetMany<EmailAddressGetManyResponseDto>, GetByIdentifier<EmailAddressDto> {

  @Override
  public EmailAddressClient service(EmailAddressService service) {
    return (EmailAddressClient) super.service(service);
  }

  /**
   * {@link EmailAddressService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public EmailAddressGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<EmailAddressGetManyResponseDto>(EmailAddressGetManyResponseDto.class,
        EmailAddressService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link EmailAddressService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmailAddressGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link EmailAddressService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public EmailAddressDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<EmailAddressDto>(EmailAddressDto.class,
        EmailAddressService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link EmailAddressService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmailAddressDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link EmailAddressService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public EmailAddressDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<EmailAddressDto>(EmailAddressDto.class,
        EmailAddressService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link EmailAddressService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public EmailAddressDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
