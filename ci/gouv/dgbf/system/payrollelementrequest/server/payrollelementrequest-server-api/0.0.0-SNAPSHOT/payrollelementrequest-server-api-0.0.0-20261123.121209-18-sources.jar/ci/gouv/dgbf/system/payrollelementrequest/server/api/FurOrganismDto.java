package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un organisme du FUR : le lien entre le code organisme du FUR et
 * l'organisme de tutelle dans Solde AN 2000, avec le service par défaut et les codes CALO
 * associés. Il alimente l'organisme de tutelle et le service des lignes du FUR unifié (RG-06 et
 * RG-07 du dossier de spécifications du FUR).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurOrganismDto extends AbstractIdentifiableAuditableDto {

  /**
   * Code organisme du FUR, tel qu'il figure dans la colonne {@code CODE_ORGANISME}.
   */
  @JsonbProperty(JSON_ORGANISM_CODE)
  private String organismCode;

  /**
   * Code de l'organisme de tutelle, dans Solde AN 2000.
   */
  @JsonbProperty(JSON_GUARDIAN_ORGANISM_CODE)
  private String guardianOrganismCode;

  /**
   * Code du service par défaut de l'organisme, dans Solde AN 2000 (quatre caractères).
   */
  @JsonbProperty(JSON_SERVICE_CODE)
  private String serviceCode;

  /**
   * Code de la section CALO.
   */
  @JsonbProperty(JSON_CALO_SECTION_CODE)
  private String caloSectionCode;

  /**
   * Code du service par défaut CALO.
   */
  @JsonbProperty(JSON_CALO_SERVICE_CODE)
  private String caloServiceCode;

  /**
   * Identifiant json {@link #organismCode}.
   */
  public static final String JSON_ORGANISM_CODE = "codeOrganisme";

  /**
   * Identifiant json {@link #guardianOrganismCode}.
   */
  public static final String JSON_GUARDIAN_ORGANISM_CODE = "codeOrganismeTutelle";

  /**
   * Identifiant json {@link #serviceCode}.
   */
  public static final String JSON_SERVICE_CODE = "codeService";

  /**
   * Identifiant json {@link #caloSectionCode}.
   */
  public static final String JSON_CALO_SECTION_CODE = "codeSectionCalo";

  /**
   * Identifiant json {@link #caloServiceCode}.
   */
  public static final String JSON_CALO_SERVICE_CODE = "codeServiceCalo";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "organisme du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "organismes du FUR";
}
