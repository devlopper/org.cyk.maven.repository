package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les groupes de types de document.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentTypesGroupFilter extends AbstractIdentifiableFilter {

}
