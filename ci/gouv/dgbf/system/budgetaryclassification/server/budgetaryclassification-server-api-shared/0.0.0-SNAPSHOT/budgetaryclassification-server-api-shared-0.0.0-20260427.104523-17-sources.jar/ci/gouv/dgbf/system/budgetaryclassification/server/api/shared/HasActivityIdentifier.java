package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de l'activité.
 *
 * @author arnaud
 */
public interface HasActivityIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'activité.
   *
   * @return identifiant de l'activité
   */
  String getActivityIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'activité.
   *
   * @param identifier identifiant de l'activité
   */

  void setActivityIdentifier(String identifier);
  /**
   * Identifiant java de l'identifiant de l'activité.
   */

  String FIELD_ACTIVITY_IDENTIFIER = "activityIdentifier";
}