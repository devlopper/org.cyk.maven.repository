package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BudgetDto}.
 *
 * @author Donsylla
 */
@Path(value = BudgetService.PATH)
@Tag(name = "Gestion des budgets")
public interface BudgetService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "budgets";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Donsylla
   */
  interface BudgetSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de l'exercice.
     *
     * @return identifiant de l'exercice
     */
    String getExerciseIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'exercice.
     *
     * @param exerciseIdentifier identifiant de l'exercice
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la collectivité.
     *
     * @return identifiant de la collectivité
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la collectivité.
     *
     * @param localAuthorityIdentifier identifiant de la collectivité
     */
    void setLocalAuthorityIdentifier(String localAuthorityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du programme triennal d'origine.
     *
     * @return identifiant du programme triennal d'origine
     */
    String getTriennialProgramIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du programme triennal d'origine.
     *
     * @param triennialProgramIdentifier identifiant du programme triennal d'origine
     */
    void setTriennialProgramIdentifier(String triennialProgramIdentifier);

    /**
     * {@link BudgetDto#JSON_EXERCISE_IDENTIFIER}.
     */
    String JSON_EXERCISE_IDENTIFIER = BudgetDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * {@link BudgetDto#JSON_LOCAL_AUTHORITY_IDENTIFIER}.
     */
    String JSON_LOCAL_AUTHORITY_IDENTIFIER = BudgetDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;

    /**
     * {@link BudgetDto#JSON_TRIENNIAL_PROGRAM_IDENTIFIER}.
     */
    String JSON_TRIENNIAL_PROGRAM_IDENTIFIER = BudgetDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_BUDGET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un budget",
      description = "Ce service permet de créer un budget")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BudgetCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements BudgetSaveRequestDto {
    @JsonbProperty(BudgetDto.JSON_TYPE)
    private BudgetType type;

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_BUDGETS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des budgets")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = BudgetGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  public static class BudgetGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BudgetDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_BUDGET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_BUDGET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_BUDGET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BudgetUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Donsylla
   */
  @Getter
  @Setter
  class BudgetUpdateRequestDto extends ByIdentifierRequestDto
      implements BudgetSaveRequestDto {
    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_BUDGET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link BudgetDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un budget")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
