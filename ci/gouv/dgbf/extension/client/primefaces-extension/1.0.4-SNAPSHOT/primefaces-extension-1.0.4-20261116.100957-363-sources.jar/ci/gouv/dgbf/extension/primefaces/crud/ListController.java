package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.Form;
import ci.gouv.dgbf.extension.primefaces.IdentifiableActionController;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Confirm;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.DataTable.RecordComponentController;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import ci.gouv.dgbf.extension.primefaces.component.MenuButton;
import ci.gouv.dgbf.extension.primefaces.component.MenuItem;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasSearchText;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente un contrôleur de liste.
 *
 * @author Christian
 *
 */
@Dependent
public class ListController extends AbstractController {

  @Getter
  @Setter
  Object client;

  @Getter
  @Setter
  Class<?> entityClass;

  @Getter
  @Setter
  String entityName;

  @Getter
  @Setter
  String entityPluralName;

  @Getter
  @Setter
  String rootFolderName;

  @Getter
  @Setter
  String entityFolderName;

  Class<?> getManyResponseDtoClass;

  @Getter
  @Setter
  Form form;

  /**
   * Disposition des formulaires. À renseigner avant {@link #initialize()}.
   */
  @Getter
  @Setter
  FormLayout formLayout = FormLayout.LEGACY;

  /* Creation */

  @Getter
  @Setter
  CreateUserInterface createUserInterface;

  @Inject
  @Getter
  CreateController createController;

  @Getter
  @Setter
  Button showCreateDialogButton;

  @Getter
  @Setter
  Button createButton;

  @Getter
  @Setter
  Dialog createDialog;

  /* Read */

  @Inject
  @Getter
  ReadController readController;

  @Getter
  @Setter
  DataTable dataTable;

  @Getter
  @Setter
  Button gotoReadPageButton;

  @Getter
  @Setter
  DataTable.RecordComponentController gotoReadPageButtonController;

  /* Update */

  @Inject
  @Getter
  UpdateController updateController;

  @Getter
  @Setter
  Dialog updateDialog;

  @Getter
  @Setter
  Button showUpdateDialogButton;

  @Getter
  @Setter
  DataTable.RecordComponentController showUpdateDialogButtonController;

  /* Delete */

  @Inject
  @Getter
  DeleteController deleteController;

  @Getter
  @Setter
  Button deleteButton;

  @Getter
  @Setter
  DataTable.RecordComponentController deleteButtonController;

  /* Filter */

  @Getter
  @Setter
  AbstractFilterController<?> filterController;

  /* Managers */

  @Inject
  ScriptManager scriptManager;

  @Inject
  ComponentManager componentManager;

  /* Notification */

  @Inject
  MessageManager messageManager;

  @Getter
  @Setter
  String notificationChannel;


  Dialog currentShowingDialog;

  @Getter
  @Setter
  String moreContentFilePath;

  @Getter
  @Setter
  String dataTableContentFileName;

  @Getter
  @Setter
  MenuButton recordMenuButton;

  /* Actions de ligne (constitution-ui §3.10) */

  /** Nombre maximal d'actions principales visibles par ligne. */
  public static final int MAXIMUM_PRIMARY_ROW_ACTIONS_COUNT = 3;

  /** En dessous de ce nombre d'actions déclarées, aucun menu « plus » n'est affiché. */
  public static final int MAXIMUM_ROW_ACTIONS_COUNT_WITHOUT_MENU = 2;

  /**
   * Disposition des actions de ligne. À renseigner avant {@link #initialize()}.
   */
  @Getter
  @Setter
  RowActionsLayout rowActionsLayout = RowActionsLayout.LEGACY;

  @Getter
  List<IdentifiableProcessingController> rowActions;

  /**
   * Cette méthode est le constructeur par défaut.
   */
  public ListController() {
    name = "Liste";

    rowActions = new ArrayList<>();

    form = new Form();
    form.setIdentifier("form");

    dataTable = new DataTable();
    dataTable.setIdentifier("dataTable");
    dataTable.setForm(form);
    dataTable.setStyleClass(dataTable.getStyleClass() + " crud-list");
    dataTable.getActionsOutputPanel().setForm(form);
    dataTable.getFilterDialog().setStyleClass("crud-list-dialog crud-list-dialog-filter");

    dataTable.getActionColumn().setRendered(true);

    gotoReadPageButton = new Button();
    gotoReadPageButton.setTitle("Consulter");
    gotoReadPageButton.setIcon("pi pi-eye");
    gotoReadPageButton.setRendered(false);
    gotoReadPageButtonController = new RecordComponentController();

    showCreateDialogButton = new Button();
    showCreateDialogButton.setValue("Ajouter");
    showCreateDialogButton.setIcon("pi pi-plus");
    createDialog = new Dialog();
    createDialog.setIdentifier("createDialog");
    createDialog.setWidgetVar("createDialogWidgetVar");
    createDialog.setStyleClass("crud-list-dialog crud-list-dialog-create");
    createButton = new Button();
    createButton.setValue("Ajouter");
    createButton.setIcon("pi pi-plus");
    createButton.addStylesClasses("crud-list-button-create", "dgbf-button-own");

    showUpdateDialogButton = new Button();
    showUpdateDialogButton.setTitle("Mettre à jour");
    showUpdateDialogButton.setIcon("pi pi-pencil");
    showUpdateDialogButtonController = new RecordComponentController();
    updateDialog = new Dialog();
    updateDialog.setIdentifier("updateDialog");
    updateDialog.setWidgetVar("updateDialogWidgetVar");
    updateDialog.setStyleClass("crud-list-dialog crud-list-dialog-update");

    deleteButton = new Button();
    deleteButton.setTitle("Supprimer");
    deleteButton.setIcon("pi pi-trash");
    deleteButtonController = new RecordComponentController();

    rootFolderName = "/private";

    moreContentFilePath = "/extension/empty.xhtml";
  }

  /**
   * Cette méthode permet de calculer les identifiants complets à aprtir de l'identifiant d'un
   * conteneur.
   *
   * @param identifier identifiant du conteneur.
   */
  public void computeCompleteIdentifiersFromContainer(String identifier) {
    dataTable.setCompleteIdentifier(
        identifier + ":" + dataTable.getForm().getIdentifier() + ":" + dataTable.getIdentifier());
    createDialog.setCompleteIdentifier(identifier + ":" + createDialog.getIdentifier());
    updateDialog.setCompleteIdentifier(identifier + ":" + updateDialog.getIdentifier());
  }

  /**
   * Cette méthode permet d'iitialiser.
   *
   */
  public void initialize() {
    /*
     * Les notifications seront désactivées car nous sommes dans le même conteneur.
     */

    dataTable.setScriptManager(scriptManager);
    dataTable.setComponentManager(componentManager);

    entityName =
        Optional.ofNullable(entityName).orElse(Core.getHumanReadableClassName(entityClass));
    entityPluralName = Optional.ofNullable(entityPluralName)
        .orElse(Core.getHumanReadableClassPluralName(entityClass));
    entityFolderName = buildEntityFolderName();

    /* Lecture */

    readController.setName(readController.getName() + " " + entityName);
    readController.setClient(client);
    Core.runIfNull(readController.getFilter(), () -> readController.setFilter(filterController));
    readController.initializeModel(entityClass, getManyResponseDtoClass);
    dataTable.setContentFilePath(buildPathFromFolder("%s/%s/" + computeDataTableContentFileName()));
    dataTable.setValue(readController.getModel());
    dataTable.addStyleClass(entityFolderName + "-datatable");

    buildDataTableTitle();

    /* Création */

    createController.setName(createController.getName() + " " + entityName);
    createController.getNotificationPublishController().setEnabled(false);
    createController.addResponseConsumer(response -> {
      createController.setEntity(null);
      scriptManager.hide(createDialog);
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
    createController.setEntityClass(entityClass);

    prepareCreate();

    /* Mise à jour */

    updateController.setName(updateController.getName() + " " + entityName);
    configureAction(updateDialog, "saveForm", updateController);

    /* Suppression */

    deleteController.setName(deleteController.getName() + " " + entityName);
    deleteController.setClient(client);
    deleteController.getNotificationPublishController().setEnabled(false);
    deleteController.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });

    /* Filtre */

    dataTable.getFilterDialog().setContentFilePath(buildPathFromFolder(computeFilterFormPath()));
    buildDataTableFilterDialogHeader();
    dataTable.setGlobalFilterConsumer(this::filterGlobally);

    dataTable.getActionColumn().computeWithForButtonsWithIconOnly(countVisibleActionsButtons());

    if (FormLayout.STACKED.equals(formLayout)) {
      configureDialogs();
    }
  }

  String computeDataTableContentFileName() {
    return Optional.ofNullable(dataTableContentFileName).orElse("columns.xhtml");
  }

  void prepareCreate() {
    if (CreateUserInterface.NONE.equals(createUserInterface)) {
      Core.runIfStringBlank(createButton.confirm().getMessage(),
          () -> createButton.confirm().setMessageAreYouSureTo(createController.getName()));
      createButton.setActionFunction(argument -> {
        prepareCreateController();
        createController.execute();
        return null;
      });
      showCreateDialogButton.setRendered(false);
    } else {
      createDialog.setContentFilePath(buildPathFromFolder("%s/%s/component/saveForm.xhtml"));
      createDialog.setHeader(createController.getName());
      createButton.setRendered(false);
    }
  }

  String computeFilterFormPath() {
    return dataTable.getFilterButton().isRendered() ? "%s/%s/component/filterForm.xhtml"
        : "/extension/empty.xhtml";
  }

  int countVisibleActionsButtons() {
    int count = 0;
    if (gotoReadPageButton.isRendered()) {
      count++;
    }
    if (showUpdateDialogButton.isRendered()) {
      count++;
    }
    if (deleteButton.isRendered()) {
      count++;
    }
    return count;
  }

  /**
   * Cette méthode permet d'ajouter une action de ligne. En mode {@link RowActionsLayout#PRIORITY},
   * son emplacement (icône dans la ligne ou menu « plus ») découle automatiquement de sa priorité
   * ({@link IdentifiableProcessingController#getPriority()}), sans appel supplémentaire du
   * développeur (constitution-ui §3.10).
   *
   * @param rowAction action de ligne
   * @return this
   */
  public ListController addRowAction(IdentifiableProcessingController rowAction) {
    rowActions.add(rowAction);
    return this;
  }

  boolean isPrimaryRowAction(IdentifiableProcessingController rowAction) {
    return ActionPriority.PRIMARY.equals(rowAction.getPriority());
  }

  /**
   * Cette méthode permet de savoir si {@link #rowActions} doivent alimenter un menu « plus », ou
   * rester toutes en icône dans la ligne si au plus {@link #MAXIMUM_ROW_ACTIONS_COUNT_WITHOUT_MENU}
   * actions sont déclarées en tout (constitution-ui §3.10).
   *
   * @return vrai si un menu « plus » est nécessaire
   */
  boolean isRowActionsMenuNeeded() {
    return countVisibleActionsButtons()
        + rowActions.size() > MAXIMUM_ROW_ACTIONS_COUNT_WITHOUT_MENU;
  }

  /**
   * Cette méthode permet d'obtenir les actions de ligne à afficher en icône dans la ligne, en mode
   * {@link RowActionsLayout#PRIORITY} : les actions principales ; ou toutes les actions de ligne
   * si {@link #isRowActionsMenuNeeded()} est faux (aucun menu « plus » dans ce cas).
   *
   * @return actions de ligne à afficher en icône dans la ligne
   */
  public List<IdentifiableProcessingController> getInlineRowActions() {
    if (!RowActionsLayout.PRIORITY.equals(rowActionsLayout)) {
      return List.of();
    }
    if (!isRowActionsMenuNeeded()) {
      return rowActions;
    }
    return rowActions.stream().filter(this::isPrimaryRowAction).toList();
  }

  /**
   * Cette méthode permet de mettre en place {@link RowActionsLayout#PRIORITY} (constitution-ui
   * §3.10) : à appeler une fois {@link #rowActionsLayout} à {@link RowActionsLayout#PRIORITY} et
   * toutes les actions de ligne enregistrées ({@link
   * #addRowAction(IdentifiableProcessingController)}), après {@link #initialize()}. Vérifie le
   * plafond de {@link #MAXIMUM_PRIMARY_ROW_ACTIONS_COUNT} actions principales, alimente
   * {@link #recordMenuButton} avec les actions de ligne secondaires si {@link
   * #isRowActionsMenuNeeded()}, puis recalcule la largeur de la colonne d'action.
   */
  public void applyRowActionsLayout() {
    Core.doThrowIfTrue(IllegalStateException.class,
        "rowActionsLayout doit être PRIORITY avant d'appeler applyRowActionsLayout()",
        !RowActionsLayout.PRIORITY.equals(rowActionsLayout));

    long declaredPrimaryRowActionsCount =
        rowActions.stream().filter(this::isPrimaryRowAction).count();
    int totalPrimaryCount = countVisibleActionsButtons() + (int) declaredPrimaryRowActionsCount;
    Core.doThrowIfTrue(IllegalStateException.class,
        String.format(
            "Au plus %d actions principales sont autorisées par ligne (constitution-ui §3.10), "
                + "%d sont déclarées pour %s",
            MAXIMUM_PRIMARY_ROW_ACTIONS_COUNT, totalPrimaryCount, entityName),
        totalPrimaryCount > MAXIMUM_PRIMARY_ROW_ACTIONS_COUNT);

    if (isRowActionsMenuNeeded()) {
      rowActions.stream().filter(rowAction -> !isPrimaryRowAction(rowAction))
          .forEach(rowAction -> rowAction.addToRecordMenuButton(recordMenuButton()));
    }

    dataTable.getActionColumn()
        .computeWithForButtonsWithIconOnly(countVisibleActionsButtonsWithPriority());
  }

  boolean hasRecordMenuButtonItems() {
    return recordMenuButton != null && recordMenuButton.getButtons() != null
        && !recordMenuButton.getButtons().isEmpty();
  }

  int countVisibleActionsButtonsWithPriority() {
    int count = countVisibleActionsButtons() + getInlineRowActions().size();
    if (hasRecordMenuButtonItems()) {
      count++;
    }
    return count;
  }

  void buildDataTableTitle() {
    if (Core.isStringBlank(dataTable.getTitle())) {
      dataTable.setTitle("Tableau de " + entityPluralName);
    }
  }

  void buildDataTableFilterDialogHeader() {
    if (Core.isStringBlank(dataTable.getFilterDialog().getHeader())) {
      String header = filterController == null ? null : filterController.getName();
      dataTable.getFilterDialog()
          .setHeader(Core.getOrDefaultIfBlank(header, "Filtre " + entityName));
    }
  }

  String buildEntityFolderName() {
    return Optional.ofNullable(entityClass).map(clazz -> {
      String name = clazz.getSimpleName().toLowerCase();
      return buildEntityFolderName(name);
    }).orElse(null);
  }

  String buildEntityFolderName(String name) {
    if (name.endsWith("dto")) {
      name = name.substring(0, name.length() - 3);
    }
    return name;
  }

  String buildPathFromFolder(String format) {
    return Optional.ofNullable(Core.getOrNullifyIfStringBlank(format))
        .map(value -> String.format(format, rootFolderName, entityFolderName)).orElse(null);
  }

  /**
   * Cette méthode permet de préparer la création.
   */
  public void showCreateDialog() {
    validateEntityClass();
    prepareCreateController();
    // Avant le vidage : les champs prévenant leur contrôleur, qui écrit dans l'entité du dialogue
    // affiché, ce doit être celle de la création (la modification peut n'avoir jamais été ouverte).
    currentShowingDialog = createDialog;
    PrimeFaces.current().resetInputs(createDialog.getIdentifier());
    // Les champs sont partagés avec la mise à jour : sans cela, la création s'ouvre avec les
    // valeurs de la dernière modification consultée.
    DialogInputCleaner.clear(createDialog.getIdentifier());
    // Le vidage a pu écraser des valeurs prérenseignées (champ masqué dont le contrôleur reçoit
    // null) : les consommateurs de l'entité les réécrivent.
    createController.consumeEntity();
    componentManager.update(createDialog);
    scriptManager.show(createDialog);
  }

  void prepareCreateController() {
    createController.instantiateEntity();
  }

  /**
   * Cette méthode permet de préparer la mise à jour.
   *
   * @param identifier identifiant
   */
  public void showUpdateDialog(String identifier) {
    showUpdateDialog(identifier, updateDialog, updateController);
  }

  /**
   * Cette méthode permet de préparer la mise à jour.
   *
   * @param identifier identifiant
   */
  public void showUpdateDialog(String identifier, Dialog dialog, UpdateController controller) {
    validateEntityClass();
    controller.setEntity(new ActionExecutor<Object>(this,
        String.format("Obtention %s par identifiant %s", entityClass.getSimpleName(), identifier),
        () -> getByIdentifier(identifier, controller.projection)).execute());
    if (controller.getEntity() == null) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE, "{0} identifié par {1} introuvable",
          new Object[] {entityClass.getSimpleName(), identifier});
    } else {
      controller.consumeEntity();
      PrimeFaces.current().resetInputs(dialog.getIdentifier());
      componentManager.update(dialog);
      scriptManager.show(dialog);
      currentShowingDialog = dialog;
    }
  }

  void validateEntityClass() {
    if (entityClass == null) {
      throw new IllegalStateException("La classe de l'entité ne doit pas être nulle");
    }
  }

  Object getByIdentifier(String identifier, ProjectionDto projection) {
    if (client instanceof GetByIdentifier<?> c) {
      return c.getByIdentifier(identifier, projection, userIdentifier, null);
    }
    throw new IllegalStateException("L'obtention par identifiant n'a pas été implémentée");
  }

  public boolean isReadControllerHasProjectionName(String name) {
    return readController.hasProjectionName(name);
  }

  /**
   * Cette méthode permet de configurer un bouton d'action sur un enregistrement.
   *
   * @param dialog dialogue
   * @param formFileName nom du fichier
   * @param controller contrôleur de l'action
   */
  public void configureAction(Dialog dialog, String formFileName, UpdateController controller) {
    Core.runIfStringBlank(controller.getName(),
        () -> controller.setName(controller.getName() + " " + entityName));
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      scriptManager.hide(dialog);
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
    Core.runIfNull(controller.getProjection(),
        () -> controller.setProjection(readController.getProjectionDto()));
    dialog.setContentFilePath(buildPathFromFolder("%s/%s/component/" + formFileName + ".xhtml"));
    Core.runIfStringBlank(dialog.getHeader(), () -> dialog.setHeader(controller.getName()));
  }

  /**
   * Cette méthode permet de configurer un bouton d'action.
   *
   * @param controller contrôleur de l'action
   */
  public void configureAction(IdentifiableActionController controller) {
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
  }

  /**
   * Cette méthode permet de configurer un bouton d'action.
   *
   * @param controller contrôleur de l'action
   */
  public void configureAction(UpdateController controller) {
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      componentManager.update(dataTable);
      messageManager.addGrowlMessageFromResponse(response);
      componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
    });
  }

  /**
   * Configure les deux dialogues pour le formulaire empilé (stacked form).
   * Applique la classe CSS, désactive la fermeture par Échap, câble les
   * callbacks DgbfForms et enregistre le paramètre dgbfFormSaved sur succès.
   * Idempotente : sans effet si les dialogues sont déjà configurés.
   */
  void configureDialogs() {
    configureDialogForStacked(createDialog);
    configureDialogForStacked(updateDialog);
    createController.addResponseConsumer(
        response -> PrimeFaces.current().ajax().addCallbackParam("dgbfFormSaved", true));
    updateController.addResponseConsumer(
        response -> PrimeFaces.current().ajax().addCallbackParam("dgbfFormSaved", true));
  }

  private void configureDialogForStacked(Dialog dialog) {
    Dialog.configureForStackedForm(dialog);
  }

  /**
   * Cette méthode permet de filter.
   */
  public void filter() {
    if (filterController != null) {
      filterController.filter();
    }
    scriptManager.hide(dataTable.getFilterDialog());
    componentManager.update(dataTable);
  }

  /**
   * Cette méthode permet de filtrer globalement à partir du texte de recherche de la barre
   * d'outils : elle renseigne {@link FilterHasSearchText#setSearchText(String)} puis délègue à
   * {@link #filter()}.
   *
   * @param searchText texte de recherche
   */
  public void filterGlobally(String searchText) {
    if (filterController != null
        && filterController.getFilter() instanceof FilterHasSearchText filter) {
      filter.setSearchText(searchText);
    }
    filter();
  }

  /**
   * Cette méthode permet d'obtenir l'entité en création ou en modification.
   *
   * @return entité en création ou en modification.
   */
  public Object getCreateControllerOrUpdateControllerEntity() {
    if (currentShowingDialog == createDialog) {
      return createController.getEntity();
    }
    if (currentShowingDialog == updateDialog) {
      return updateController.getEntity();
    }
    return null;
  }

  /**
   * Cette méthode permet d'obtenir l'entité en création ou en modification.
   *
   * @param <T> type
   * @param clazz classe
   * @return entité en création ou en modification.
   */
  @SuppressWarnings("unchecked")
  public <T> T getCreateControllerOrUpdateControllerEntityAs(Class<T> clazz) {
    return (T) getCreateControllerOrUpdateControllerEntity();
  }

  public boolean isCurrentShowingDialogCreate() {
    return isCurrentShowingDialog(createDialog);
  }

  public boolean isCurrentShowingDialogUpdate() {
    return isCurrentShowingDialog(updateDialog);
  }

  boolean isCurrentShowingDialog(Dialog dialog) {
    return currentShowingDialog == dialog;
  }

  public boolean getGotoReadPageButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, gotoReadPageButton,
        gotoReadPageButtonController);
  }

  public boolean getShowUpdateDialogButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, showUpdateDialogButton,
        showUpdateDialogButtonController);
  }

  public boolean getDeleteButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, deleteButton, deleteButtonController);
  }

  /**
   * Cette méthode permet d'obtenir {@link MenuButton} d'enregistrement.
   *
   * @return {@link MenuButton} d'enregistrement
   */
  public MenuButton recordMenuButton() {
    if (recordMenuButton == null) {
      recordMenuButton = new MenuButton();
      recordMenuButton.setIcon("pi pi-ellipsis-v");
      recordMenuButton.setAccessibleLabel("Autres actions");
    }
    return recordMenuButton;
  }

  /**
   * Cette méthode permet de construire {@ink #recordMenuButton}.
   */
  public void buildRecordMenuButton() {
    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().outcome(gotoReadPageButton.getOutcome())
                .value(gotoReadPageButton.getTitle()).icon(gotoReadPageButton.getIcon()))
        .build();

    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().actionFunction(showUpdateDialogFunction())
                .value(showUpdateDialogButton.getTitle()).icon(showUpdateDialogButton.getIcon()))
        .build();

    recordMenuButton().buttonBuilder()
        .menuItemBuilder(
            (MenuItem.Builder) MenuItem.newBuilder().actionFunction(deleteByIdentifierFunction())
                .value(deleteButton.getTitle()).icon(deleteButton.getIcon())
                .confirmBuilder(Confirm.builder().action(deleteButton.getTitle())))
        .build();
  }

  Function<Object, String> showUpdateDialogFunction() {
    return identifier -> {
      showUpdateDialog((String) identifier);
      return null;
    };
  }

  Function<Object, String> deleteByIdentifierFunction() {
    return identifier -> {
      deleteController.deleteByIdentifier((String) identifier);
      return null;
    };
  }

  /**
   * Cette méthode permet la lecture seule.
   */
  public void useAsReadOnly() {
    showCreateDialogButton.setRendered(false);
    showUpdateDialogButton.setRendered(false);
    deleteButton.setRendered(false);
    dataTable.getFilterButton().setRendered(false);
  }

  /**
   * Cette énumération représente les interfaces utilisateurs de création.
   *
   * @author Christian
   *
   */
  public enum CreateUserInterface {
    DIALOG, PAGE, NONE
  }

  /**
   * Disposition des formulaires de création et de mise à jour. {@code LEGACY} est transitoire :
   * il disparaîtra quand tous les CRUD seront migrés vers {@code STACKED}.
   */
  public enum FormLayout {
    LEGACY, STACKED
  }

  /**
   * Cette énumération représente la disposition des actions de ligne (constitution-ui §3.10).
   * {@code LEGACY} est transitoire : il disparaîtra quand toutes les listes seront migrées vers
   * {@code PRIORITY}.
   */
  public enum RowActionsLayout {
    LEGACY, PRIORITY
  }

  /**
   * Cette énumération représente la priorité d'une action de ligne (constitution-ui §3.10).
   * {@code PRIMARY} : icône visible dans la ligne, jamais dans le menu « plus ». {@code
   * SECONDARY} : menu « plus », placement automatique en mode {@link RowActionsLayout#PRIORITY}.
   */
  public enum ActionPriority {
    PRIMARY, SECONDARY
  }
}
