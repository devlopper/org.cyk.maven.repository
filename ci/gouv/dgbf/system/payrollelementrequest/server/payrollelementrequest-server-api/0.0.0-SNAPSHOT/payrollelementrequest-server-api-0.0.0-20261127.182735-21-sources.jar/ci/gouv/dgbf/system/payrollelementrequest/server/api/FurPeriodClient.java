package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurPeriodService.FurPeriodGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link FurPeriodService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class FurPeriodClient extends AbstractClient<FurPeriodService>
    implements GetByIdentifier<FurPeriodDto>, GetMany<FurPeriodGetManyResponseDto> {

  @Override
  public FurPeriodClient service(FurPeriodService service) {
    return (FurPeriodClient) super.service(service);
  }

  /**
   * {@link FurPeriodService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FurPeriodGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FurPeriodGetManyResponseDto>(FurPeriodGetManyResponseDto.class,
        FurPeriodService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FurPeriodService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FurPeriodGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FurPeriodService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public FurPeriodDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FurPeriodDto>(FurPeriodDto.class,
        FurPeriodService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FurPeriodService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FurPeriodDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
