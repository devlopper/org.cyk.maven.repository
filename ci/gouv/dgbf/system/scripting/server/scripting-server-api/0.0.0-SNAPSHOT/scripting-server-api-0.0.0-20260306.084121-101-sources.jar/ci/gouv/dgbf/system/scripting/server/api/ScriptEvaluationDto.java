package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une évaluation de script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptEvaluationDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link ScriptDto}.
   */
  @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
  private String scriptIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ScriptDto}.
   */
  @JsonbProperty(JSON_SCRIPT_AS_STRING)
  private String scriptAsString;
  
  /**
   * Arguments.
   */
  @JsonbProperty(JSON_ARGUMENTS)
  private Map<String, String> arguments;

  /**
   * Représentation en chaine de caractères des arguments.
   */
  @JsonbProperty(JSON_ARGUMENTS_AS_STRING)
  private String argumentsAsString;
  
  /**
   * Format de la représentation en chaine de caractères des arguments.
   */
  @JsonbProperty(JSON_ARGUMENTS_AS_STRING_FORMAT)
  private StringFormat argumentsAsStringFormat;
  
  /**
   * Résultat.
   */
  @JsonbProperty(JSON_RESULT)
  private Map<String, String> result;

  /**
   * Représentation en chaine de caractères du résultat.
   */
  @JsonbProperty(JSON_RESULT_AS_STRING)
  private String resultAsString;
  
  /**
   * Format de la représentation en chaine de caractères du résultat.
   */
  @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
  private StringFormat resultAsStringFormat;

  /**
   * Résultat en entier.
   */
  @JsonbProperty(JSON_RESULT_AS_INTEGER)
  private Integer resultAsInteger;
  
  /**
   * Résultat en booléen.
   */
  @JsonbProperty(JSON_RESULT_AS_BOOLEAN)
  private Boolean resultAsBoolean;
  
  /**
   * Message.
   */
  @JsonbProperty(JSON_MESSAGE)
  private String message;
  
  /**
   * Identifiant json de identifiant de {@link ScriptEvaluationDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEvaluationScript";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ScriptEvaluationDto}.
   */
  public static final String JSON_THIS_AS_STRING = "evaluationScriptChaine";

  /**
   * Identifiant json {@link #scriptIdentifier}.
   */
  public static final String JSON_SCRIPT_IDENTIFIER = ScriptDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #scriptAsString}.
   */
  public static final String JSON_SCRIPT_AS_STRING = ScriptDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json {@link #arguments}.
   */
  public static final String JSON_ARGUMENTS = "arguments";

  /**
   * Identifiant json {@link #argumentsAsString}.
   */
  public static final String JSON_ARGUMENTS_AS_STRING = JSON_ARGUMENTS + "Chaine";
  
  /**
   * Identifiant json {@link #argumentsAsStringFormat}.
   */
  public static final String JSON_ARGUMENTS_AS_STRING_FORMAT = "formatArgumentsChaine";
  
  /**
   * Identifiant json {@link #result}.
   */
  public static final String JSON_RESULT = "resultat";

  /**
   * Identifiant json {@link #resultAsString}.
   */
  public static final String JSON_RESULT_AS_STRING = "resultatChaine";
  
  /**
   * Identifiant json {@link #resultAsStringFormat}.
   */
  public static final String JSON_RESULT_AS_STRING_FORMAT = "formatResultatChaine";

  /**
   * Identifiant json {@link #resultAsInteger}.
   */
  public static final String JSON_RESULT_AS_INTEGER = "resultatEntier";
  
  /**
   * Identifiant json {@link #resultAsBoolean}.
   */
  public static final String JSON_RESULT_AS_BOOLEAN = "resultatBooleen";
  
  /**
   * Identifiant json {@link #message}.
   */
  public static final String JSON_MESSAGE = "message";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "évaluation de script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "évaluations de script";
}
