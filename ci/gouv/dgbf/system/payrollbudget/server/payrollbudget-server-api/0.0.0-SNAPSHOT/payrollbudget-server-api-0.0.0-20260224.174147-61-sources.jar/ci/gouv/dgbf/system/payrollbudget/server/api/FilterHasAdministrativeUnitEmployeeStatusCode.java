package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasAdministrativeUnitEmployeeStatusCode
    extends HasAdministrativeUnitEmployeeStatusCode {

  /**
   * Cette méthode permet de mettre à jour le code de {@link AdministrativeUnitEmployeeStatus}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateAdministrativeUnitEmployeeStatusCode(FilterDto filter) {
    setAdministrativeUnitEmployeeStatusCode(AdministrativeUnitEmployeeStatusCodeFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour le code de {@link AdministrativeUnitEmployeeStatus} de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterAdministrativeUnitEmployeeStatusCode(FilterDto filter) {
    AdministrativeUnitEmployeeStatusCodeFilter.set(filter,
        getAdministrativeUnitEmployeeStatusCode());
  }

}
