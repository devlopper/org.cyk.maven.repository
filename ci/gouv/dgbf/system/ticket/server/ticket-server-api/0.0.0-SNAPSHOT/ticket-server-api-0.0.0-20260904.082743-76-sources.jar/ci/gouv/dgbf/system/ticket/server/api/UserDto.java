package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketClaimActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketDissatisfactionActionsCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasTicketResolutionActionsCountAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un utilisateur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class UserDto extends AbstractIdentifiableNamableDto
    implements HasTicketClaimActionsCountAsStringDto, HasTicketResolutionActionsCountAsStringDto,
    HasTicketDissatisfactionActionsCountAsStringDto, HasClaimedTicketCountAsStringDto {

  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT_AS_STRING)
  private String claimedTicketCountAsString;

  @JsonbProperty(JSON_TICKET_CLAIM_ACTIONS_COUNT_AS_STRING)
  private String ticketClaimActionsCountAsString;

  @JsonbProperty(JSON_TICKET_RESOLUTION_ACTIONS_COUNT_AS_STRING)
  private String ticketResolutionActionsCountAsString;

  @JsonbProperty(JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT_AS_STRING)
  private String ticketDissatisfactionActionsCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUtilisateur";

  /**
   * Identifiant json du nom.
   */
  public static final String JSON_THIS_NAME = "nomUtilisateur";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "utilisateur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
