package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de mail.
 *
 * @author Christian
 */
public interface HasMailAsStringDto extends HasMailAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du mail.
   */
  String JSON_MAIL_AS_STRING = "mailChaine";
}
