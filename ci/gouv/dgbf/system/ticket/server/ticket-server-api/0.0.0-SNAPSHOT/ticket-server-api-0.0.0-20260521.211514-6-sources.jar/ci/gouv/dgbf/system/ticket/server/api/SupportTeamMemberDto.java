package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente membre equipe support.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamMemberDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
  private String supportTeamIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_AS_STRING)
  private String supportTeamAsString;

  /**
   * Identifiant utilisateur .
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Indicateur de responsabilité.
   */
  @JsonbProperty(JSON_IS_RESPONSIBLE)
  private Boolean isResponsible;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idMembreServiceSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "membreServiceSupportChaine";


  /**
   * Identifiant champ java {@link #supportTeamIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_IDENTIFIER =
      SupportTeamDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_AS_STRING = SupportTeamDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = "idUtilisateur";

  /**
   * Identifiant champ java {@link #isResponsible}.
   */
  public static final String JSON_IS_RESPONSIBLE = "esResponsable";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "membre service support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "membres services support";

}

