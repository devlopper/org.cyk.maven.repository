package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.menu.DefaultMenuItem;

/**
 * Cette classe représente un élément de menu.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MenuItem extends AbstractCommand {

  String outcome;
  String command;
  String confirmationScript;
  Map<String, List<String>> parameters;
  boolean escape;

  public MenuItem() {
    escape = true;
  }
  
  /**
   * Cette méthode permet de construire.
   *
   * @return {@link DefaultMenuItem.Builder}
   */
  public DefaultMenuItem.Builder builder() {
    return DefaultMenuItem.builder().value(value).icon(icon).title(title).outcome(outcome)
        .command(command).styleClass(styleClass).style(style).update(update).params(parameters)
        .confirmationScript(confirmationScript).escape(escape);
  }

  /**
   * Cette méthode permet d'ajouter les paramètres.
   *
   * @param map map
   */
  public void addParameters(Map<String, List<String>> map) {
    if (Optional.ofNullable(map).orElse(Collections.emptyMap()).isEmpty()) {
      return;
    }
    parameters().putAll(map);
  }

  Map<String, List<String>> parameters() {
    Core.runIfNull(parameters, () -> parameters = new LinkedHashMap<>());
    return parameters;
  }

  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder extends AbstractBuilder<MenuItem> {
    String outcome;
    String command;
    String confirmationScript;
    Map<String, List<String>> parameters;
    boolean escape;
    
    @Override
    public MenuItem build() {
      MenuItem menuItem = super.build();
      menuItem.outcome = outcome;
      menuItem.command = command;
      menuItem.confirmationScript = confirmationScript;
      menuItem.parameters = parameters;
      menuItem.escape = escape;
      return menuItem;
    }
    
    @Override
    protected MenuItem instantiate() {
      return new MenuItem();
    }

    /**
     * Cette méthode permet d'ajouter les paramètres.
     *
     * @param map map
     */
    public void addParameters(Map<String, List<String>> map) {
      if (Optional.ofNullable(map).orElse(Collections.emptyMap()).isEmpty()) {
        return;
      }
      parameters().putAll(map);
    }

    Map<String, List<String>> parameters() {
      Core.runIfNull(parameters, () -> parameters = new LinkedHashMap<>());
      return parameters;
    }
  }
}
