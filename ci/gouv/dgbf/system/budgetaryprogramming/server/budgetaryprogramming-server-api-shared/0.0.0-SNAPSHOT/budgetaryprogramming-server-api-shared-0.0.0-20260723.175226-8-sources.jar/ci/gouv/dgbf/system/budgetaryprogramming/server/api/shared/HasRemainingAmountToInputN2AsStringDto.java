package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN2AsStringDto
    extends HasRemainingAmountToInputN2AsString {

  /**
   * Identifiant json du montant restant à saisir pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N2_AS_STRING =
      "montantResteASaisirN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName