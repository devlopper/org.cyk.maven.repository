package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.AbstractIdentifiableActionsController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente un contrôleur des actions de {@link DocumentGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class DocumentGroupActionsController
    extends AbstractIdentifiableActionsController<DocumentGroupDto, DocumentGroupClient> {

  @Inject
  @Getter
  DocumentGroupClient client;

  @Override
  public void initializeWhenNotNull(DocumentGroupDto identifiable) {
    // TODO: Auto-generated method stub
  }
}
