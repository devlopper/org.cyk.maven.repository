package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollConstantIdentifierDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayslipIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayslipConstantDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = PayslipConstantService.PATH)
@Tag(name = "Gestion des constantes de bulletin de paie")
public interface PayslipConstantService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "constantes-bulletins-paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface PayslipConstantSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipDto}.
     *
     * @return l'identifiant de {@link PayslipDto}
     */
    String getPayslipIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipDto}.
     *
     * @param payslipIdentifier l'identifiant de {@link PayslipDto}
     */
    void setPayslipIdentifier(String payslipIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollConstantDto}.
     *
     * @return l'identifiant de {@link PayrollConstantDto}
     */
    String getPayrollConstantIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollConstantDto}.
     *
     * @param payrollConstantIdentifier l'identifiant de {@link PayrollConstantDto}
     */
    void setPayrollConstantIdentifier(String payrollConstantIdentifier);

    /**
     * Cette méthode permet d'obtenir la valeur.
     *
     * @return la valeur
     */
    Integer getValue();

    /**
     * Cette méthode permet d'assigner la valeur.
     *
     * @param value la valeur
     */
    void setValue(Integer value);

    /**
     * {@link HasPayslipIdentifierDto#JSON_PAYSLIP_IDENTIFIER}.
     */
    String JSON_PAYSLIP_IDENTIFIER = HasPayslipIdentifierDto.JSON_PAYSLIP_IDENTIFIER;

    /**
     * {@link HasPayrollConstantIdentifierDto#JSON_PAYROLL_CONSTANT_IDENTIFIER}.
     */
    String JSON_PAYROLL_CONSTANT_IDENTIFIER =
        HasPayrollConstantIdentifierDto.JSON_PAYROLL_CONSTANT_IDENTIFIER;

    /**
     * {@link HasValueDto#JSON_VALUE}.
     */
    String JSON_VALUE = HasValueDto.JSON_VALUE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayslipConstantCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipConstantCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayslipConstantSaveRequestDto {

    @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
    private String payslipIdentifier;

    @JsonbProperty(JSON_PAYROLL_CONSTANT_IDENTIFIER)
    private String payrollConstantIdentifier;

    @JsonbProperty(JSON_VALUE)
    private Integer value;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayslipConstantGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class PayslipConstantGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayslipConstantDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayslipConstantDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipConstantDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipConstantDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayslipConstantUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipConstantUpdateRequestDto extends ByIdentifierRequestDto
      implements PayslipConstantSaveRequestDto {

    @JsonbProperty(JSON_PAYSLIP_IDENTIFIER)
    private String payslipIdentifier;

    @JsonbProperty(JSON_PAYROLL_CONSTANT_IDENTIFIER)
    private String payrollConstantIdentifier;

    @JsonbProperty(JSON_VALUE)
    private Integer value;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de mise à jour de la valeur.
   */
  String UPDATE_VALUE_IDENTIFIER = "MISE_A_JOUR_VALEUR_CONSTANTE_BULLETIN_PAIE";

  /**
   * Chemin du service de mise à jour de la valeur.
   */
  String UPDATE_VALUE_PATH = "valeur";

  /**
   * Cette méthode permet de calculer les montants {@link PayslipConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_VALUE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_VALUE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateValue(PayslipConstantUpdateValueRequestDto request);

  /**
   * Cette classe représente la requête de calcul de montants.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayslipConstantUpdateValueRequestDto extends ByIdentifierRequestDto
      implements HasValueDto<Integer> {

    @JsonbProperty(JSON_VALUE)
    private Integer value;
  }
}
