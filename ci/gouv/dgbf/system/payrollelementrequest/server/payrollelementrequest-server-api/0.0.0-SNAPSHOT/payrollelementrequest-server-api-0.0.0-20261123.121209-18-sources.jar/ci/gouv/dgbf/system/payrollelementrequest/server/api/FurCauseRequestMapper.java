package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurCauseService.FurCauseCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurCauseService.FurCauseUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FurCauseDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FurCauseDto}.

    @author akm
               """)
public interface FurCauseRequestMapper extends
    RequestMapper<FurCauseDto, FurCauseCreateRequestDto,
        FurCauseUpdateRequestDto> {

}
