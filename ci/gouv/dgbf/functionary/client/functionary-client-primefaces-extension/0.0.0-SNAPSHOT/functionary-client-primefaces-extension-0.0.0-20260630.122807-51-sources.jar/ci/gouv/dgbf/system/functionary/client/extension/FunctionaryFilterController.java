package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputDateController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FunctionaryFilterController extends AbstractFilterController<FunctionaryFilter> {

  @Inject
  @Getter
  InputTextController registrationNumberInputTextController;

  @Inject
  @Getter
  InputTextController firstNameInputTextController;

  @Inject
  @Getter
  InputTextController lastNamesInputTextController;

  @Inject
  @Getter
  InputDateController birthDateInputDateController;

  @Inject
  @Getter
  InputDateController firstServiceStartDateInputDateController;

  /**
   * Cette méthode permet de construire.
   */
  public FunctionaryFilterController() {
    super(FunctionaryFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setRegistrationNumber(getRequestParameter(FunctionaryFilter.JSON_REGISTRATION_NUMBER));
    filter.setSearchText(getRequestParameter(SearchTextFilter.JSON_KEY));

    registrationNumberInputTextController.setOutputLableValue("Matricule");
    registrationNumberInputTextController.getInputText()
        .addValueConsumer(registrationNumber -> filter.setRegistrationNumber(registrationNumber));

    firstNameInputTextController.setOutputLableValue("Nom");
    firstNameInputTextController.getInputText()
        .addValueConsumer(firstName -> filter.setFirstName(firstName));

    lastNamesInputTextController.setOutputLableValue("Prénom(s)");
    lastNamesInputTextController.getInputText()
        .addValueConsumer(lastNames -> filter.setLastNames(lastNames));

    birthDateInputDateController.setOutputLableValue("Date de naissance");
    birthDateInputDateController.getInputLocalDate()
        .addValueConsumer(birthDate -> filter.setBirthDate(birthDate));

    firstServiceStartDateInputDateController
        .setOutputLableValue("Date de première prise de service");
    firstServiceStartDateInputDateController.getInputLocalDate().addValueConsumer(
        firstServiceStartDate -> filter.setFirstServiceStartDate(firstServiceStartDate));
  }
}
