package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de mouvement de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum PayslipMovementStatus {

  /**
   * {@link PayslipMovementStatusCode#ACTIVATED}.
   */
  ACTIVATED(PayslipMovementStatusCode.ACTIVATED, "Activé", "Activer", "Activation"),

  /**
   * {@link PayslipMovementStatusCode#DEFERRED}.
   */
  DEFERRED(PayslipMovementStatusCode.DEFERRED, "Différé", "Différer", "Différé"),

  /**
   * {@link PayslipMovementStatusCode#DEFERRED_PROPOSED}.
   */
  DEFERRED_PROPOSED(PayslipMovementStatusCode.DEFERRED_PROPOSED, "Différé proposé",
      "Proposer différé", "Proposition de différé"),

  /**
   * {@link PayslipMovementStatusCode#REJECTED}.
   */
  REJECTED(PayslipMovementStatusCode.REJECTED, "Rejeté", "Rejeter", "Rejet"),

  /**
   * {@link PayslipMovementStatusCode#REJECTION_PROPOSED}.
   */
  REJECTION_PROPOSED(PayslipMovementStatusCode.REJECTION_PROPOSED,
      "Rejet proposé", "Proposer rejet", "Propositon de rejet"),
    
  /**
   * {@link PayslipMovementStatusCode#CLOSED}.
   */
  CLOSED(PayslipMovementStatusCode.CLOSED, "Cloturé", "Cloturer", "Cloturé")

  ;

  private PayslipMovementStatus(String code, String name, String action, String actionName) {
    this.code = code;
    this.name = name;
    this.action = action;
    this.actionName = actionName;
  }

  private String code;
  private String name;
  private String action;
  private String actionName;
  private Set<PayslipMovementStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le statut par code.
   *
   * @param code code
   * @return statut
   */
  public static PayslipMovementStatus getByCode(String code) {
    return Stream.of(PayslipMovementStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    ACTIVATED.previous =
        Core.getSet(List.of(DEFERRED_PROPOSED, DEFERRED, REJECTION_PROPOSED, REJECTED));
    DEFERRED_PROPOSED.previous = Core.getSet(List.of(ACTIVATED));
    DEFERRED.previous = Core.getSet(List.of(ACTIVATED, DEFERRED_PROPOSED));
    REJECTION_PROPOSED.previous = Core.getSet(List.of(ACTIVATED));
    REJECTED.previous = Core.getSet(List.of(ACTIVATED, REJECTION_PROPOSED));
  }
}
