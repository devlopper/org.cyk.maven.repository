package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TicketDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-11T11:06:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TicketRequestMapperImpl implements TicketRequestMapper {

    @Override
    public TicketService.TicketCreateRequestDto mapCreate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketCreateRequestDto ticketCreateRequestDto = new TicketService.TicketCreateRequestDto();

        ticketCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        ticketCreateRequestDto.setSupportTeamMemberIdentifier( arg0.getSupportTeamMemberIdentifier() );
        ticketCreateRequestDto.setReference( arg0.getReference() );
        ticketCreateRequestDto.setObject( arg0.getObject() );
        ticketCreateRequestDto.setDescription( arg0.getDescription() );
        ticketCreateRequestDto.setStatusComment( arg0.getStatusComment() );
        ticketCreateRequestDto.setDiagnosis( arg0.getDiagnosis() );
        ticketCreateRequestDto.setActionsPerformed( arg0.getActionsPerformed() );
        ticketCreateRequestDto.setSolution( arg0.getSolution() );
        ticketCreateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketCreateRequestDto;
    }

    @Override
    public TicketService.TicketUpdateRequestDto mapUpdate(TicketDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TicketService.TicketUpdateRequestDto ticketUpdateRequestDto = new TicketService.TicketUpdateRequestDto();

        ticketUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        ticketUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        ticketUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ticketUpdateRequestDto.setSupportTeamMemberIdentifier( arg0.getSupportTeamMemberIdentifier() );
        ticketUpdateRequestDto.setReference( arg0.getReference() );
        ticketUpdateRequestDto.setObject( arg0.getObject() );
        ticketUpdateRequestDto.setDescription( arg0.getDescription() );
        ticketUpdateRequestDto.setStatusComment( arg0.getStatusComment() );
        ticketUpdateRequestDto.setDiagnosis( arg0.getDiagnosis() );
        ticketUpdateRequestDto.setActionsPerformed( arg0.getActionsPerformed() );
        ticketUpdateRequestDto.setSolution( arg0.getSolution() );
        ticketUpdateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return ticketUpdateRequestDto;
    }
}
