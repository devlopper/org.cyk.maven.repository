package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountNDto extends HasInputtedAmountN {

  /**
   * Identifiant json du montant saisi à l'horizon N.
   */
  String JSON_INPUTTED_AMOUNT_N = "montantSaisiN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName