package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MovementDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-23T15:06:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MovementRequestMapperImpl implements MovementRequestMapper {

    @Override
    public MovementService.MovementCreateRequestDto mapCreate(MovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementService.MovementCreateRequestDto movementCreateRequestDto = new MovementService.MovementCreateRequestDto();

        movementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementCreateRequestDto.setAdministrativeUnitEmployeeIdentifier( arg0.getAdministrativeUnitEmployeeIdentifier() );
        movementCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        movementCreateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );

        return movementCreateRequestDto;
    }

    @Override
    public MovementService.MovementUpdateRequestDto mapUpdate(MovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementService.MovementUpdateRequestDto movementUpdateRequestDto = new MovementService.MovementUpdateRequestDto();

        movementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        movementUpdateRequestDto.setAdministrativeUnitEmployeeIdentifier( arg0.getAdministrativeUnitEmployeeIdentifier() );
        movementUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        movementUpdateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );

        return movementUpdateRequestDto;
    }
}
