package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PolicyVersionDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T18:39:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PolicyVersionRequestMapperImpl implements PolicyVersionRequestMapper {

    @Override
    public PolicyVersionService.PolicyVersionCreateRequestDto mapCreate(PolicyVersionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyVersionService.PolicyVersionCreateRequestDto policyVersionCreateRequestDto = new PolicyVersionService.PolicyVersionCreateRequestDto();

        policyVersionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyVersionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        policyVersionCreateRequestDto.setPolicyIdentifier( arg0.getPolicyIdentifier() );
        policyVersionCreateRequestDto.setVersion( arg0.getVersion() );
        policyVersionCreateRequestDto.setPublicationDate( arg0.getPublicationDate() );
        policyVersionCreateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        policyVersionCreateRequestDto.setIsActive( arg0.getIsActive() );

        return policyVersionCreateRequestDto;
    }

    @Override
    public PolicyVersionService.PolicyVersionCreateRequestDto mapUpdate(PolicyVersionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PolicyVersionService.PolicyVersionCreateRequestDto policyVersionCreateRequestDto = new PolicyVersionService.PolicyVersionCreateRequestDto();

        policyVersionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        policyVersionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        policyVersionCreateRequestDto.setPolicyIdentifier( arg0.getPolicyIdentifier() );
        policyVersionCreateRequestDto.setVersion( arg0.getVersion() );
        policyVersionCreateRequestDto.setPublicationDate( arg0.getPublicationDate() );
        policyVersionCreateRequestDto.setFileIdentifier( arg0.getFileIdentifier() );
        policyVersionCreateRequestDto.setIsActive( arg0.getIsActive() );

        return policyVersionCreateRequestDto;
    }
}
