package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN2AsStringDto extends HasTotalAmountToValidateN2AsString {

  /**
   * Identifiant json du montant total à valider pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_VALIDATE_N2_AS_STRING =
      "montantTotalAValiderN2Chaine";
}
