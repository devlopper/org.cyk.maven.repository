package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;

/**
 * Cette classe représente la base de page de liste d'unités administratives partagées de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public abstract class AbstractConnectedUserSharedAdministrativeUnitListPage
    extends AbstractConnectedUserSharedResourceListPage {

  @Override
  String resourceName() {
    return "unités administratives partagées";
  }

  @Override
  ResourceType resourceType() {
    return ResourceType.ADMINISTRATIVE_UNIT;
  }

  @Override
  Location resourceLocation() {
    return Location.BUDGETARY_CLASSIFICATION;
  }
}
