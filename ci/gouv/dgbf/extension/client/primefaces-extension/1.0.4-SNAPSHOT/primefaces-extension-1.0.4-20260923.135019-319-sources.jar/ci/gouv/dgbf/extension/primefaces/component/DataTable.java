package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.Core.ConcatenateArguments;
import ci.gouv.dgbf.extension.core.NonBlankStringList;
import ci.gouv.dgbf.extension.core.segregation.AuditInfosGetter;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.model.menu.MenuModel;

/**
 * Cette classe représente une table de données.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DataTable extends AbstractWidget {

  Object value;
  boolean paginator;
  String rows;
  String tableStyle;
  String tableStyleClass;
  String rowStyleClass;
  String rowsPerPageTemplate;
  String paginatorPosition;
  String paginatorTemplate;
  String currentPageReportTemplate;
  String emptyMessage;
  boolean paginatorAlwaysVisible;
  boolean stripedRows;
  boolean reflow;
  boolean headerRendered;
  boolean editable;
  String editMode;

  Column orderNumberColumn;
  Column auditColumn;
  Column actionColumn;

  Button filterButton;
  Button exportButton;
  Button columnsButton;
  String title;

  ToolbarStyle toolbarStyle;
  boolean globalFilterRendered;
  String globalFilterText;
  Consumer<String> globalFilterConsumer;

  Runnable filterRunnable;

  Dialog filterDialog;

  ComponentManager componentManager;
  ScriptManager scriptManager;

  OutputPanel containerOutputPanel;
  
  OutputPanel actionsOutputPanel;

  MenuModel recordMenuModel;

  /* Selection */

  boolean selectable;

  List<Object> selection;

  Function<Object, String> getRowKeyFunction;

  @Getter
  @Setter
  Function<Object, String> rowStyleClassFunction;

  /**
   * Cette méthode permet d'instancier un objet.
   *
   */
  public DataTable() {
    containerOutputPanel = new OutputPanel();
    containerOutputPanel.addStylesClasses("row");
    containerOutputPanel.setForm(form);
    
    actionsOutputPanel = new OutputPanel();
    actionsOutputPanel.addStylesClasses("row", "mb-4");
    actionsOutputPanel.setForm(form);

    headerRendered = true;
    stripedRows = true;
    reflow = true;
    toolbarStyle = ToolbarStyle.DEFAULT;
    globalFilterRendered = false;
    templateFilePath = Constant.SLASH + "extension/component/datatable/default.xhtml";
    paginator = true;
    rows = "10";
    rowsPerPageTemplate = "5,10,50,100,150,250,500,1000,{ShowAll|'Tout'}";
    paginatorPosition = "bottom";
    paginatorTemplate = "{CurrentPageReport} {FirstPageLink} {PreviousPageLink} {PageLinks} "
        + "{NextPageLink} {LastPageLink} {RowsPerPageDropdown}";
    currentPageReportTemplate = "{startRecord}-{endRecord} sur {totalRecords}";
    tableStyleClass = "table table-striped";
    styleClass = "custom-pagination responsive";
    paginatorAlwaysVisible = false;

    editable = false;
    editMode = "cell";

    orderNumberColumn = new Column();
    orderNumberColumn.setHeaderText("N°");
    orderNumberColumn.setWidth("20px");

    auditColumn = new Column();
    auditColumn.setHeaderText("Audit");
    auditColumn.setVisible(false);
    auditColumn.setRendered(false);
    auditColumn.setExportable(false);

    actionColumn = new Column();
    actionColumn.setHeaderText("Action");
    actionColumn.computeWithForButtonsWithIconOnly(2);
    actionColumn.setRendered(false);
    actionColumn.setExportable(false);

    filterButton = new Button();
    filterButton.setValue("Filtres");
    filterButton.setIcon("pi pi-filter");
    filterButton.setRendered(false);

    exportButton = new Button();
    exportButton.setValue("Exporter");
    exportButton.setIcon("pi pi-file-export");

    columnsButton = new Button();
    columnsButton.setValue("Colonnes");
    columnsButton.setIcon("pi pi-align-justify");

    filterDialog = new Dialog();
    filterDialog.setIdentifier("filterDialog");
    filterDialog.setWidgetVar("filterDialogWidgetVar");
  }

  /**
   * Cette méthode permet d'obtenir la clé de la ligne.
   *
   * @param data donnée
   * @return clé de la ligne
   */
  public Object getRowKey(Object data) {
    if (selectable) {
      Core.doThrowIfNull(IllegalArgumentException.class,
          "fonction d'obtention de clé de ligne requise", getRowKeyFunction);
      return getRowKeyFunction.apply(data);
    }
    return null;
  }

  /**
   * Cette méthode permet d'obtenir la selection comme étant du type donné.
   *
   * @param <T> type
   * @param clazz classe
   * @return selection comme étant du type donné
   */
  @SuppressWarnings("unchecked")
  public <T> List<T> getSelectionAs(Class<T> clazz) {
    return (List<T>) selection;
  }

  /**
   * Cette méthode permet d'ajouter des classes de styles.
   *
   * @param stylesClasses classes de styles
   * @return this
   */
  public AbstractWidget addTableStylesClasses(List<String> stylesClasses) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(tableStyleClass).add(stylesClasses);
    tableStyleClass =
        Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(" "));
    return this;
  }

  public AbstractWidget addTableStylesClasses(String... stylesClasses) {
    return addTableStylesClasses(
        Arrays.stream(Optional.ofNullable(stylesClasses).orElse(new String[] {})).toList());
  }

  public AbstractWidget addTableStyleClass(String styleClass) {
    return addTableStylesClasses(styleClass);
  }

  /**
   * Cette méthode permet d'ajouter des styles.
   *
   * @param styles styles
   * @return this
   */
  public AbstractWidget addTableStyles(List<String> styles) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(tableStyle).add(styles);
    tableStyle = Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(";"));
    return this;
  }

  public AbstractWidget addTableStyles(String... styles) {
    return addTableStyles(
        Arrays.stream(Optional.ofNullable(styles).orElse(new String[] {})).toList());
  }

  public AbstractWidget addTableStyle(String style) {
    return addTableStyles(style);
  }

  public void showFilterDialog() {
    componentManager.update(filterDialog);
    scriptManager.show(filterDialog);
  }

  /**
   * Cette méthode permet de filtrer globalement à partir de {@link #globalFilterText}. Le
   * traitement effectif est délégué à {@link #globalFilterConsumer}, fourni par le module
   * appelant.
   */
  public void filterGlobally() {
    Core.acceptConsumer(globalFilterConsumer, globalFilterText);
  }

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'audit d'un
   * enregistrement.
   *
   * @param r enregistrement
   * @return représentation en chaine de caractère de l'audit
   */
  public String getAuditAsStringByRecord(Object r) {
    if (r instanceof AuditInfosGetter audit) {
      return audit.getAuditAsString();
    } else {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "L'obtention de la représentation en chaine de caractères "
              + "de l'audit pas encore implémentée pour {0}",
          r);
    }
    return null;
  }

  /**
   * Cette énumération représente les dispositions possibles de la barre d'outils.
   *
   * @author Christian
   *
   */
  public enum ToolbarStyle {
    CLASSIC, MODERN

    ;

    public static ToolbarStyle DEFAULT = CLASSIC;
  }

  /**
   * Cette méthode permet d'obtenir la classe de style de la ligne pour un enregistrement donné.
   * Si {@link #rowStyleClassFunction} n'est pas défini, se rabat sur {@link #rowStyleClass}
   * (comportement inchangé pour les écrans qui ne définissent pas de style conditionnel).
   *
   * @param r enregistrement
   * @return classe de style de la ligne
   */
  public String getRowStyleClassByRecord(Object r) {
    return rowStyleClassFunction != null ? rowStyleClassFunction.apply(r) : rowStyleClass;
  }

  /**
   * Cette classe représente un contrôleur de composnant d'enregistrement du tableau.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class RecordComponentController {
    Function<Object, Boolean> renderedFunction;

    /**
     * Cette méthode permet d'assigner la fonction d'affichage.
     *
     * @param renderedFunction fonction d'affichage
     * @return {@link RecordComponentController}
     */
    public RecordComponentController setRenderedFunctionIfNull(
        Function<Object, Boolean> renderedFunction) {
      if (this.renderedFunction == null) {
        this.renderedFunction = renderedFunction;;
      }
      return this;
    }

    /**
     * Cette méthode permet d'obtenir la visibilité.
     *
     * @param object enregistrement
     * @param value valeur
     * @return visibilité
     */
    public boolean rendered(Object object, boolean value) {
      return Optional.ofNullable(renderedFunction).map(f -> f.apply(object)).orElse(value);
    }

    /**
     * Cette méthode permet d'obtenir la visibilité.
     *
     * @param object enregistrement
     * @param widget composnant
     * @param componentController contrôleur
     * @return visibilité
     */
    public static boolean rendered(Object object, AbstractWidget widget,
        RecordComponentController componentController) {
      boolean widgetIsRendered = Optional.ofNullable(widget).map(w -> w.isRendered()).orElse(false);
      return Optional.ofNullable(componentController)
          .map(c -> componentController.rendered(object, widgetIsRendered))
          .orElse(widgetIsRendered);
    }
  }
}
