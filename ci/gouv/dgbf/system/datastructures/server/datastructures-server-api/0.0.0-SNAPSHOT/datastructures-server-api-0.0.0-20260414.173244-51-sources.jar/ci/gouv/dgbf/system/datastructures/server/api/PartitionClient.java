package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PartitionService}.
 *
 * @author Arnaud
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PartitionClient extends AbstractClient<PartitionService>
    implements GetByIdentifier<PartitionDto>,
    GetMany<PartitionService.PartitionGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PartitionClient service(PartitionService service) {
    return (PartitionClient) super.service(service);
  }

  /**
   * {@link PartitionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PartitionService.PartitionCreateRequestDto request) {
    return new CreateExecutor(PartitionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PartitionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionService.PartitionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PartitionService.PartitionGetManyResponseDto>(
        PartitionService.PartitionGetManyResponseDto.class,
        PartitionService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PartitionService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionService.PartitionGetManyResponseDto getMany(ProjectionDto projection,
                                                                      FilterDto filter,
                                                                      PageDto page, String auditWho,
                                                                      String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link HierarchyService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PartitionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PartitionDto>(PartitionDto.class,
        PartitionService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PartitionService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PartitionDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                                 String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PartitionService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PartitionDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PartitionDto>(PartitionDto.class,
        PartitionService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PartitionService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PartitionDto getByIdentifier(String identifier, ProjectionDto projection,
                                          String auditWho,
                                          String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PartitionService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(
      PartitionService.PartitionUpdateRequestDto request) {
    return new IdentifiableExecutor(PartitionService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PartitionService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PartitionService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PartitionService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
