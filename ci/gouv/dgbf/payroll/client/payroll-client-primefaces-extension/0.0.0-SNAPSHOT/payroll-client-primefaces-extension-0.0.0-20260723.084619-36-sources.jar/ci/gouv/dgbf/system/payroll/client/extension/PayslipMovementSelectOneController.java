package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementClient;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayslipMovementDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayslipMovementSelectOneController 
    extends AbstractSelectOneIdentifiableController<PayslipMovementDto, 
    PayslipMovementGetManyResponseDto, PayslipMovementClient> {

  @Getter
  @Inject
  PayslipMovementClient client;

  protected PayslipMovementSelectOneController() {
    super(PayslipMovementDto.class, SelectItemLabelStrategy.NAME);
  }
}
