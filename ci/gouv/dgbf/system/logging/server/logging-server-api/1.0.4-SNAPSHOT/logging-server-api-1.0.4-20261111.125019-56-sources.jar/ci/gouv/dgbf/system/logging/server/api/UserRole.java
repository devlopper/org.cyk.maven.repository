package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs pour le module Logging.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  /**
   * Administrateur du module Logging.
   */
  ADMINISTRATOR("ADMINISTRATEUR_LOGGING");

  private final String code;

  UserRole(String code) {
    this.code = code;
  }
}

