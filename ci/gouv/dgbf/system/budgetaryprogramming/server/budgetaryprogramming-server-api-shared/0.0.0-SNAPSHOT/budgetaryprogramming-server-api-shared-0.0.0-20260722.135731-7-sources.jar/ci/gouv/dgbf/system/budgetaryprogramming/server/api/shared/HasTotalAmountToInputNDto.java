package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputNDto extends HasTotalAmountToInputN {

  /**
   * Identifiant json du montant total à saisir pour l'année N.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N = "montantTotalASaisirN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
