package ci.gouv.dgbf.extension.primefaces.test;

import static org.mockito.ArgumentMatchers.any;

import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.NotificationPublishController;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.crud.CreateController;
import ci.gouv.dgbf.extension.primefaces.crud.DeleteController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ReadController;
import ci.gouv.dgbf.extension.primefaces.crud.UpdateController;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link ListController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class ListControllerMocker {

  Object entity;

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link ListController}
   */
  public ListController mock() {
    ListController controller = Mockito.mock(ListController.class);
    Mockito.when(controller.getReadController()).thenReturn(new ReadController());
    Mockito.when(controller.getShowCreateDialogButton()).thenReturn(new Button());
    Mockito.when(controller.getCreateButton()).thenReturn(new Button());
    Mockito.when(controller.getShowUpdateDialogButton()).thenReturn(new Button());
    Mockito.when(controller.getDeleteButton()).thenReturn(new Button());
    Mockito.when(controller.getGotoReadPageButton()).thenReturn(new Button());
    Mockito.when(controller.getDataTable()).thenReturn(new DataTable());
    Mockito.when(controller.getCreateControllerOrUpdateControllerEntity()).thenReturn(entity);
    Mockito.when(controller.getCreateControllerOrUpdateControllerEntityAs(any()))
        .thenReturn(entity);

    Mockito.when(controller.getCreateController()).thenReturn(new CreateController() {
      {
        componentManager = Mockito.mock(ComponentManager.class);
      }
    });
    controller.getCreateController()
        .setNotificationPublishController(Mockito.mock(NotificationPublishController.class));

    Mockito.when(controller.getUpdateController()).thenReturn(new UpdateController() {
      {
        componentManager = Mockito.mock(ComponentManager.class);
      }
    });
    controller.getUpdateController()
        .setNotificationPublishController(Mockito.mock(NotificationPublishController.class));

    Mockito.when(controller.getDeleteController()).thenReturn(new DeleteController() {
      {
        componentManager = Mockito.mock(ComponentManager.class);
      }
    });
    controller.getDeleteController()
        .setNotificationPublishController(Mockito.mock(NotificationPublishController.class));
    return controller;
  }

}
