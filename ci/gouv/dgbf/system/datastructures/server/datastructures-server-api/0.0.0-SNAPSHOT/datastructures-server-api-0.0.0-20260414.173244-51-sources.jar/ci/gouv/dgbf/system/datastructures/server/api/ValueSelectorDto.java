package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasDataEntityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterAttributeValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasRequestAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un sélecteur de valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueSelectorDto extends AbstractIdentifiableAuditableDto implements HasNameDto,
    HasCodeDto, HasSourceIdentifierDto, HasSourceAsStringDto, HasFilterAttributeNameDto,
    HasRequestAsStringDto, HasFilterAttributeValueDto, HasDataEntityIdentifierDto {

  @JsonbProperty(JSON_CODE)
  private String code;

  @JsonbProperty(JSON_NAME)
  private String name;

  @JsonbProperty(JSON_SOURCE_IDENTIFIER)
  private String sourceIdentifier;

  @JsonbProperty(JSON_SOURCE_AS_STRING)
  private String sourceAsString;

  @JsonbProperty(JSON_FILTER_ATTRIBUTE_NAME)
  private String filterAttributeName;

  @JsonbProperty(JSON_REQUEST_AS_STRING)
  private String requestAsString;

  @JsonbProperty(JSON_FILTER_ATTRIBUTE_VALUE)
  private String filterAttributeValue;

  @JsonbProperty(JSON_DATA_ENTITY_IDENTIFIER)
  private String dataEntityIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSelecteurValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "selecteurValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "sélecteur de valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sélecteurs de valeur";
}
