package ci.gouv.dgbf.system.servicecatalog.client.extension.representation;

import ci.gouv.dgbf.extension.primefaces.component.output.AbstractTagRepresentation;
import ci.gouv.dgbf.system.servicecatalog.server.api.StrategicClassification;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.EnumMap;
import java.util.Map;

/**
 * Cette classe représente la pastille unique de la classification stratégique d'un module,
 * utilisée par le fragment {@code /servicecatalog/component/output/strategicClassification.xhtml}
 * en liste comme en fiche.
 *
 * @author Christian
 */
@ApplicationScoped
@Named("strategicClassificationRepresentation")
public class StrategicClassificationRepresentation
    extends AbstractTagRepresentation<StrategicClassification> {

  static final Map<StrategicClassification, String> ICONS =
      new EnumMap<>(StrategicClassification.class);

  static {
    ICONS.put(StrategicClassification.CORE_DOMAIN, "pi pi-star");
    ICONS.put(StrategicClassification.SUPPORTING_SUBDOMAIN, "pi pi-sitemap");
    ICONS.put(StrategicClassification.GENERIC_SUBDOMAIN, "pi pi-th-large");
  }

  @Override
  protected String getLabel(StrategicClassification value) {
    return value.getName();
  }

  @Override
  protected String getIcon(StrategicClassification value) {
    return ICONS.get(value);
  }
}
