package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une projection de poste de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollComponentProjectionDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link AdministrativeUnitEmployeeDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
  private String administrativeUnitEmployeeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitEmployeeDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING)
  private String administrativeUnitEmployeeAsString;
  
  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  private String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  private String budgetAsString;

  /**
   * Identifiant unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de unité administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Identifiant employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_IDENTIFIER)
  private String employeeIdentifier;

  /**
   * Représentation en chaine de caractères de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_AS_STRING)
  private String employeeAsString;

  /**
   * Identifiant {@link PayrollComponentDto}.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  /**
   * Représentation en chaine de caractères de {@link PayrollComponentDto}.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  private String payrollComponentAsString;

  /**
   * Identifiant {@link PayrollPeriodGroupDto}.
   */
  @JsonbProperty(JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER)
  private String payrollPeriodGroupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link PayrollPeriodGroupDto}.
   */
  @JsonbProperty(JSON_PAYROLL_PERIOD_GROUP_AS_STRING)
  private String payrollPeriodGroupAsString;

  /**
   * Montant de référence.
   */
  @JsonbProperty(JSON_REFERENCE_AMOUNT)
  private Integer referenceAmount;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  private String referenceAmountAsString;

  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  private Integer amount;

  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  private String amountAsString;

  /**
   * Identifiant json champ {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Identifiant json {@link #administrativeUnitEmployeeIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER =
      AdministrativeUnitEmployeeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitEmployeeAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_AS_STRING =
      AdministrativeUnitEmployeeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #employeeIdentifier}.
   */
  public static final String JSON_EMPLOYEE_IDENTIFIER = "idEmploye";

  /**
   * Identifiant json champ {@link #employeeAsString}.
   */
  public static final String JSON_EMPLOYEE_AS_STRING = "employeChaine";

  /**
   * Identifiant json champ {@link #payrollComponentIdentifier}.
   */
  public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER = "idPostePaie";

  /**
   * Identifiant json champ {@link #payrollComponentAsString}.
   */
  public static final String JSON_PAYROLL_COMPONENT_AS_STRING = "postePaieChaine";

  /**
   * Identifiant json champ {@link #payrollPeriodGroupIdentifier}.
   */
  public static final String JSON_PAYROLL_PERIOD_GROUP_IDENTIFIER = "idGroupePeriodePaie";

  /**
   * Identifiant json champ {@link #payrollPeriodGroupAsString}.
   */
  public static final String JSON_PAYROLL_PERIOD_GROUP_AS_STRING = "groupePeriodePaieChaine";

  /**
   * Identifiant json champ {@link #referenceAmount}.
   */
  public static final String JSON_REFERENCE_AMOUNT = "montantReference";

  /**
   * Identifiant json champ {@link #referenceAmountAsString}.
   */
  public static final String JSON_REFERENCE_AMOUNT_AS_STRING = "montantReferenceChaine";

  /**
   * Identifiant json champ {@link #amount}.
   */
  public static final String JSON_AMOUNT = "montant";

  /**
   * Identifiant json champ {@link #amountAsString}.
   */
  public static final String JSON_AMOUNT_AS_STRING = "montantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "projection de poste de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "projections de poste de paie";
}
