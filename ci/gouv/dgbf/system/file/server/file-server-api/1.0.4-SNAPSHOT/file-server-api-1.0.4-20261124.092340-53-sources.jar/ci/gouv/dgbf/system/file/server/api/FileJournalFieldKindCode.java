package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileJournalFieldKind} : valeurs stockées dans
 * {@code TA_JOURNAL_FICHIER.CHAMP_CONCERNE} ({@code CK_TJF_CHAMP}, script 013) et citées par la
 * liste {@code champsEffaces} de la modification des informations.
 *
 * @author Christian
 */
public class FileJournalFieldKindCode {

  private FileJournalFieldKindCode() {}

  /** Nom du Fichier. */
  public static final String NAME = "NOM";

  /** Description du Fichier. */
  public static final String DESCRIPTION = "DESCRIPTION";

  /** Date de production du Fichier. */
  public static final String PRODUCTION_DATE = "DATE_PRODUCTION";

  /** Détenteur de l'Exemplaire physique. */
  public static final String HOLDER = "DETENTEUR";
}
