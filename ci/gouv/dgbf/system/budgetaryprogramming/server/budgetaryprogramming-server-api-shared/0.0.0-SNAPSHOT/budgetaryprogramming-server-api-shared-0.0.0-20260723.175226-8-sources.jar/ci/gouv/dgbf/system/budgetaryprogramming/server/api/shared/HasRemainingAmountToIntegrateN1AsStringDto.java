package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateN1AsStringDto
    extends HasRemainingAmountToIntegrateN1AsString {

  /**
   * Identifiant json du montant restant à intégrer pour l'année N+1,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INTEGRATE_N1_AS_STRING =
      "montantResteAIntegrerN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName