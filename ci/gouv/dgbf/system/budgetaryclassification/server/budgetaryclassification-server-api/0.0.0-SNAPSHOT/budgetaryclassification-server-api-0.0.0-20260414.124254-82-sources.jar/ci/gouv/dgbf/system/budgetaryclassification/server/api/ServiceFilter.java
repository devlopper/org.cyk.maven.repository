package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ServiceDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ServiceFilter extends AbstractIdentifiableFilter {

  /*
   * Identifiant {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String administrativeUnitIdentifier;

  /**
   * Code de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CODE)
  String administrativeUnitCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ServiceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ServiceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    administrativeUnitIdentifier = getAdministrativeUnitIdentifier(filter);
    administrativeUnitCode = getAdministrativeUnitCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setAdministrativeUnitIdentifier(filter, administrativeUnitIdentifier);
    setAdministrativeUnitCode(filter, administrativeUnitCode);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link AdministrativeUnitDto}
   */
  public static void setAdministrativeUnitIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link AdministrativeUnitDto}
   */
  public static String getAdministrativeUnitIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @param code code {@link AdministrativeUnitDto}
   */
  public static void setAdministrativeUnitCode(FilterDto filter, String code) {
    set(filter, JSON_ADMINISTRATIVE_UNIT_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link AdministrativeUnitDto}.
   *
   * @param filter filtre
   * @return code de {@link AdministrativeUnitDto}
   */
  public static String getAdministrativeUnitCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ADMINISTRATIVE_UNIT_CODE));
  }

  /**
   * Identifiant json champ {@link ServiceFilter#administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      ServiceDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

  /**
   * Identifiant json champ {@link ServiceFilter#administrativeUnitCode}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_CODE =
      ServiceDto.JSON_ADMINISTRATIVE_UNIT_CODE;
}
