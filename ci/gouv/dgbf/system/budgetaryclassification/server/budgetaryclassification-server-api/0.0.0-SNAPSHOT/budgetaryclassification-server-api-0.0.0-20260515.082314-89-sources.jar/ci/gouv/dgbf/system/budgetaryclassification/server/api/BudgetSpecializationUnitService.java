package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link BudgetSpecializationUnitDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = BudgetSpecializationUnitService.PATH)
@Tag(name = "Gestion des unités de spécialisation budget")
public interface BudgetSpecializationUnitService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "unites-specialisation-budget";
  
  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface BudgetSpecializationUnitSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link BudgetarySectionDto}.
     *
     * @return identifiant de {@link BudgetarySectionDto}
     */
    String getBudgetarySectionIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link BudgetarySectionDto}.
     *
     * @param budgetarySectionIdentifier identifiant de {@link BudgetarySectionDto}
     */
    void setBudgetarySectionIdentifier(String budgetarySectionIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link BudgetCategoryDto}.
     *
     * @return identifiant de {@link BudgetCategoryDto}
     */
    String getBudgetCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link BudgetCategoryDto}.
     *
     * @param budgetCategoryIdentifier identifiant de {@link BudgetCategoryDto}
     */
    void setBudgetCategoryIdentifier(String budgetCategoryIdentifier);


    /**
     * Identifiant json identifiant de {@link BudgetarySectionDto}.
     */
    String JSON_BUDGETARY_SECTION_IDENTIFIER = BudgetarySectionDto.JSON_THIS_IDENTIFIER;


    /**
     * Identifiant json identifiant de {@link BudgetCategoryDto}.
     */
    String JSON_BUDGET_CATEGORY_IDENTIFIER = BudgetCategoryDto.JSON_THIS_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(BudgetSpecializationUnitCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class BudgetSpecializationUnitCreateRequestDto extends
        AbstractCodableNamableCreateRequestJsonDto implements
        BudgetSpecializationUnitSaveRequestDto {

    @JsonbProperty(JSON_BUDGETARY_SECTION_IDENTIFIER)
    private String budgetarySectionIdentifier;

    @JsonbProperty(JSON_BUDGET_CATEGORY_IDENTIFIER)
    private String budgetCategoryIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = BudgetSpecializationUnitGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class BudgetSpecializationUnitGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetSpecializationUnitDto> {

    @JsonbProperty(JSON_DATAS)
    private List<BudgetSpecializationUnitDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UNE_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetSpecializationUnitDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = BudgetSpecializationUnitDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(BudgetSpecializationUnitUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class BudgetSpecializationUnitUpdateRequestDto extends
        AbstractCodableNamableUpdateRequestJsonDto implements
        BudgetSpecializationUnitSaveRequestDto {
    @JsonbProperty(JSON_BUDGETARY_SECTION_IDENTIFIER)
    private String budgetarySectionIdentifier;

    @JsonbProperty(JSON_BUDGET_CATEGORY_IDENTIFIER)
    private String budgetCategoryIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UNITE_SPECIALISATION_BUDGET";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link  BudgetSpecializationUnitDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
