package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.CommitmentService.CommitmentCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.CommitmentService.CommitmentGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.CommitmentService.CommitmentUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link CommitmentService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class CommitmentClient extends AbstractClient<CommitmentService>
    implements GetByIdentifier<CommitmentDto>, GetMany<CommitmentGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public CommitmentClient service(CommitmentService service) {
    return (CommitmentClient) super.service(service);
  }

  /**
   * {@link CommitmentService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(CommitmentCreateRequestDto request) {
    return new CreateExecutor(CommitmentService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link CommitmentService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public CommitmentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<CommitmentGetManyResponseDto>(CommitmentGetManyResponseDto.class,
        CommitmentService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link CommitmentService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public CommitmentGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                              PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link CommitmentService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public CommitmentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<CommitmentDto>(CommitmentDto.class,
        CommitmentService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link CommitmentService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CommitmentDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                              String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link CommitmentService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public CommitmentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<CommitmentDto>(CommitmentDto.class,
        CommitmentService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link CommitmentService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public CommitmentDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
                                       String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link CommitmentService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(CommitmentUpdateRequestDto request) {
    return new IdentifiableExecutor(CommitmentService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link CommitmentService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(CommitmentService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link CommitmentService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
