package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe avec une notion de filtre par est collectivité.
 *
 * @author Christian
 */
public interface FilterHasIsLocalAuthority extends HasIsLocalAuthority {

  /**
   * Cette méthode permet de mettre à jour est EPN.
   *
   * @param filter {@link FilterDto}
   */
  default void updateIsLocalAuthority(FilterDto filter) {
    setIsLocalAuthority(IsLocalAuthorityFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour est EPN de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterIsLocalAuthority(FilterDto filter) {
    IsLocalAuthorityFilter.set(filter, getIsLocalAuthority());
  }

}
