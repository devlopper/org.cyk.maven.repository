package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link FurLocalityDto}. N'étend
 * pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link FurLocalityDto} n'a ni code ni nom propres : la localité est identifiée par son code de
 * localité d'affectation.
 *
 * @author akm
 *
 */
@Path(FurLocalityService.PATH)
@Tag(name = "Gestion des localités du FUR")
public interface FurLocalityService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "localites-fur";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface FurLocalitySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le code de la localité.
     *
     * @return le code de la localité
     */
    String getLocalityCode();

    /**
     * Cette méthode permet d'assigner le code de la localité.
     *
     * @param localityCode le code de la localité
     */
    void setLocalityCode(String localityCode);

    /**
     * Cette méthode permet d'obtenir le code de la localité CALO.
     *
     * @return le code de la localité CALO
     */
    String getCaloLocalityCode();

    /**
     * Cette méthode permet d'assigner le code de la localité CALO.
     *
     * @param caloLocalityCode le code de la localité CALO
     */
    void setCaloLocalityCode(String caloLocalityCode);

    /**
     * Cette méthode permet d'obtenir le code du mode de règlement.
     *
     * @return le code du mode de règlement
     */
    String getPaymentModeCode();

    /**
     * Cette méthode permet d'assigner le code du mode de règlement.
     *
     * @param paymentModeCode le code du mode de règlement
     */
    void setPaymentModeCode(String paymentModeCode);

    /**
     * {@link FurLocalityDto#JSON_LOCALITY_CODE}.
     */
    String JSON_LOCALITY_CODE = FurLocalityDto.JSON_LOCALITY_CODE;

    /**
     * {@link FurLocalityDto#JSON_CALO_LOCALITY_CODE}.
     */
    String JSON_CALO_LOCALITY_CODE = FurLocalityDto.JSON_CALO_LOCALITY_CODE;

    /**
     * {@link FurLocalityDto#JSON_PAYMENT_MODE_CODE}.
     */
    String JSON_PAYMENT_MODE_CODE = FurLocalityDto.JSON_PAYMENT_MODE_CODE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_LOCALITE_FUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FurLocalityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FurLocalityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurLocalityCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements FurLocalitySaveRequestDto {

    @JsonbProperty(JSON_LOCALITY_CODE)
    private String localityCode;

    @JsonbProperty(JSON_CALO_LOCALITY_CODE)
    private String caloLocalityCode;

    @JsonbProperty(JSON_PAYMENT_MODE_CODE)
    private String paymentModeCode;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_LOCALITE_FUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class FurLocalityGetManyResponseDto
      extends AbstractGetByPageResponseDto<FurLocalityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FurLocalityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_LOCALITE_FUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_LOCALITE_FUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link FurLocalityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FurLocalityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_LOCALITE_FUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FurLocalityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FurLocalityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class FurLocalityUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements FurLocalitySaveRequestDto {

    @JsonbProperty(JSON_LOCALITY_CODE)
    private String localityCode;

    @JsonbProperty(JSON_CALO_LOCALITY_CODE)
    private String caloLocalityCode;

    @JsonbProperty(JSON_PAYMENT_MODE_CODE)
    private String paymentModeCode;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_LOCALITE_FUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FurLocalityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
