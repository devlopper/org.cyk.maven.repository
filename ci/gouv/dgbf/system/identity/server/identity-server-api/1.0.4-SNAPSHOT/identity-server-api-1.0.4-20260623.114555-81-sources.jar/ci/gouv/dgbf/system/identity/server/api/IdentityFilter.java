package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityFilter extends AbstractIdentityFilter {

  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(value = JSON_GROUP_IDENTIFIER)
  String groupIdentifier;

  /**
   * Identifiant à exclure {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(value = JSON_EXCLUDED_GROUP_IDENTIFIER)
  String excludedGroupIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
    excludedGroupIdentifier = getExcludedGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setExcludedGroupIdentifier(filter, excludedGroupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #groupIdentifier}.
   *
   * @param filter filtre
   * @param groupIdentifier {@link #groupIdentifier}
   */
  public static void setGroupIdentifier(FilterDto filter, String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #groupIdentifier}.
   *
   * @param filter filtre
   * @return {@link #groupIdentifier}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner {@link #excludedGroupIdentifier}.
   *
   * @param filter filtre
   * @param excludedGroupIdentifier {@link #excludedGroupIdentifier}
   */
  public static void setExcludedGroupIdentifier(FilterDto filter, String excludedGroupIdentifier) {
    set(filter, JSON_EXCLUDED_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(excludedGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #excludedGroupIdentifier}.
   *
   * @param filter filtre
   * @return {@link #excludedGroupIdentifier}
   */
  public static String getExcludedGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXCLUDED_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = IdentityDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant JSON {@link #excludedGroupIdentifier}.
   */
  public static final String JSON_EXCLUDED_GROUP_IDENTIFIER =
      IdentityDto.JSON_GROUP_IDENTIFIER + "Exclu";
}

