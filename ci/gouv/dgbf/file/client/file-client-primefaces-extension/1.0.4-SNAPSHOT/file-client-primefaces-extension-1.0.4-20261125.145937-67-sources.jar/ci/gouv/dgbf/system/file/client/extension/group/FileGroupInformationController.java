package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.ClientRuntimeException;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateInformationRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileJournalFieldKindCode;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.application.FacesMessage;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le contrôleur de l'action « Renommer dans le groupe » : modification du
 * Nom dans le Groupe et de la Description dans le Groupe d'un Fichier de Groupe, sans toucher au
 * Fichier partagé (RG_FILE_CAT_10, DEC_FILE_04 D04). Seuls les champs changés sont envoyés, un
 * champ vidé est envoyé comme effacé (le rattachement reprend alors celui du Fichier). Un refus du
 * serveur, par exemple un rattachement gelé par l'archivage, s'affiche dans la boîte, qui reste
 * ouverte ; une réussite la ferme et rafraîchit la liste.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupInformationController extends AbstractController {

  /**
   * Widget de la boîte « Renommer dans le groupe ».
   */
  public static final String WIDGET = "fileGroupInformationDialog";

  @Inject
  FileGroupClient client;

  @Inject
  MessageManager messageManager;

  @Inject
  ComponentManager componentManager;

  @Setter
  ListController listController;

  @Getter
  String fileGroupIdentifier;

  /**
   * Nom du Fichier, rappelé dans la boîte.
   */
  @Getter
  String documentName;

  @Getter
  @Setter
  String name;

  @Getter
  @Setter
  String description;

  String initialName;

  String initialDescription;

  /**
   * Cette méthode permet d'ouvrir la boîte, préremplie des valeurs propres au rattachement.
   *
   * @param fileGroup rattachement ; sa projection porte le nom et la description propres
   */
  public void open(FileGroupDto fileGroup) {
    if (fileGroup == null || Core.isStringBlank(fileGroup.getIdentifier())) {
      throw new IllegalArgumentException("L'identifiant du fichier de groupe est obligatoire");
    }
    fileGroupIdentifier = fileGroup.getIdentifier();
    documentName = fileGroup.getFileAsString();
    initialName = trimToNull(fileGroup.getName());
    initialDescription = trimToNull(fileGroup.getDescription());
    name = initialName;
    description = initialDescription;
    show();
  }

  /**
   * Cette méthode permet de modifier les informations propres au rattachement.
   */
  public void update() {
    FileGroupUpdateInformationRequestDto request = new FileGroupUpdateInformationRequestDto();
    request.setIdentifier(fileGroupIdentifier);
    request.setAuditWho(userIdentifier);
    Set<String> cleared = new HashSet<>();
    apply(trimToNull(name), initialName, FileJournalFieldKindCode.NAME, request::setName, cleared);
    apply(trimToNull(description), initialDescription, FileJournalFieldKindCode.DESCRIPTION,
        request::setDescription, cleared);
    if (request.getName() == null && request.getDescription() == null && cleared.isEmpty()) {
      error("Aucune information n'a changé.");
      return;
    }
    if (!cleared.isEmpty()) {
      request.setClearedFields(cleared);
    }
    try {
      client.updateInformation(request);
    } catch (ClientRuntimeException exception) {
      error(exception.getMessage());
      return;
    }
    hide();
    refreshList();
    growl(new FacesMessage(FacesMessage.SEVERITY_INFO,
        "Les informations du fichier dans le groupe sont modifiées.", null));
  }

  private static void apply(String value, String initial, String code,
      Consumer<String> setter, Set<String> cleared) {
    if (Objects.equals(value, initial)) {
      return;
    }
    if (value == null) {
      cleared.add(code);
    } else {
      setter.accept(value);
    }
  }

  static String trimToNull(String value) {
    return Core.isStringBlank(value) ? null : value.trim();
  }

  void refreshList() {
    if (listController != null) {
      componentManager.update(listController.getDataTable());
    }
  }

  void error(String message) {
    growl(new FacesMessage(FacesMessage.SEVERITY_ERROR, message, null));
  }

  void growl(FacesMessage message) {
    messageManager.addGrowlMessage(message);
    componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
  }

  void show() {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      // Par le widgetVar : l'identifiant client du dialogue dépend du formulaire englobant.
      primeFaces.ajax().update("@widgetVar(" + WIDGET + ")");
      primeFaces.executeScript("PF('" + WIDGET + "').show();");
    }
  }

  void hide() {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      primeFaces.executeScript("PF('" + WIDGET + "').hide();");
    }
  }

  /**
   * Obtient l'instance courante de PrimeFaces.
   *
   * @return instance {@link PrimeFaces}
   */
  PrimeFaces getPrimeFaces() {
    return PrimeFaces.current();
  }
}
