package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasChildAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasChildIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasHierarchyAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasHierarchyIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasParentAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasParentIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une relation hiérarchique.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class HierarchicalRelationDto extends AbstractIdentifiableAuditableDto implements
    HasHierarchyIdentifierDto, HasHierarchyAsStringDto, HasParentIdentifierDto,
    HasParentAsStringDto, HasChildIdentifierDto, HasChildAsStringDto {

  @JsonbProperty(JSON_HIERARCHY_IDENTIFIER)
  private String hierarchyIdentifier;

  @JsonbProperty(JSON_HIERARCHY_AS_STRING)
  private String hierarchyAsString;

  @JsonbProperty(JSON_PARENT_IDENTIFIER)
  private String parentIdentifier;

  @JsonbProperty(JSON_PARENT_AS_STRING)
  private String parentAsString;

  @JsonbProperty(JSON_CHILD_IDENTIFIER)
  private String childIdentifier;

  @JsonbProperty(JSON_CHILD_AS_STRING)
  private String childAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRelationHierarchique";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "relationHierarchiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "relation hiérarchique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "relations hiérarchiques";
}
