package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Objects;
import java.util.Optional;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente la base de contrôleur de {@link TabMenu}.
 *
 * @author Christian
 *
 */
public abstract class AbstractTabMenuController extends AbstractController {

  @Getter
  protected TabMenu menu;

  protected Collection<Page> pages;

  protected Object listPageTabMenuType;
  
  /**
   * Cette méthode permet d'instantier.
   */
  protected AbstractTabMenuController() {
    menu = new TabMenu();
    listPageTabMenuType = "list";
  }

  /**
   * Cette méthode permet d'ajouter une page.
   *
   * @param tabMenuType type d'onglet de menu
   * @param tabMenuOutcome navigation d'onglet de menu
   * @return this
   */
  public AbstractTabMenuController addPage(Object tabMenuType, String tabMenuOutcome) {
    Core.throwIllegalArgumentExceptionIfNull(tabMenuType, "Tab menu type is required");
    pages().add(new Page().tabMenuType(tabMenuType).tabMenuOutcome(tabMenuOutcome));
    return this;
  }

  public AbstractTabMenuController addPage(Object tabMenuType) {
    return addPage(tabMenuType, null);
  }

  public AbstractTabMenuController addListPage() {
    return addPage(listPageTabMenuType);
  }
  
  Collection<Page> pages() {
    if (pages == null) {
      pages = new ArrayList<>();
    }
    return pages;
  }

  public AbstractTabMenuController setPageOutcome(Object tabMenuType, String tabMenuOutcome) {
    getPageByType(tabMenuType).tabMenuOutcome = tabMenuOutcome;
    return this;
  }

  public AbstractTabMenuController setListPageOutcome(String tabMenuOutcome) {
    return setPageOutcome(listPageTabMenuType, tabMenuOutcome);
  }
  
  Page getPageByType(Object tabMenuType) {
    return Optional.ofNullable(pages).orElse(Collections.emptyList()).stream()
        .filter(page -> Objects.equals(page.tabMenuType, tabMenuType)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException(
            "type tab menu <<%s>> inconnu".formatted(tabMenuType)));
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    addPages();
    Optional.ofNullable(pages).orElse(Collections.emptyList())
        .forEach(page -> menu.getOutcomesMap().put(page.tabMenuType, page.tabMenuOutcome));
    addMenuTabs();
    menu.initialize();
  }

  protected void addPages() {

  }
  
  protected void addMenuTabs() {

  }

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  @EqualsAndHashCode(of = {"tabMenuType"})
  class Page {
    Object tabMenuType;

    String tabMenuOutcome;
  }
}
