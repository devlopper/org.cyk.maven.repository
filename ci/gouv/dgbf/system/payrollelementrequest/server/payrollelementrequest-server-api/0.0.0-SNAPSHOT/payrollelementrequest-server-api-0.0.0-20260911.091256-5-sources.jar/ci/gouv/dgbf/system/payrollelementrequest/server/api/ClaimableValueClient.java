package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableValueService.ClaimableValueGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableValueService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableValueClient extends AbstractClient<ClaimableValueService>
    implements GetByIdentifier<ClaimableValueDto>, GetMany<ClaimableValueGetManyResponseDto> {

  @Override
  public ClaimableValueClient service(ClaimableValueService service) {
    return (ClaimableValueClient) super.service(service);
  }

  /**
   * {@link ClaimableValueService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableValueGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableValueGetManyResponseDto>(
        ClaimableValueGetManyResponseDto.class, ClaimableValueService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableValueService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableValueGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableValueService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableValueDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableValueDto>(ClaimableValueDto.class,
        ClaimableValueService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableValueService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableValueDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
