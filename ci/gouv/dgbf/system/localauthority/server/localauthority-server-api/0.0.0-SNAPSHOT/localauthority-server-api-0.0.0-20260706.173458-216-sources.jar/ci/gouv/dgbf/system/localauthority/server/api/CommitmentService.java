package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link CommitmentDto}.
 *
 * @author Desysoft
 */
@Path(value = CommitmentService.PATH)
@Tag(name = "Gestion des activités")
public interface CommitmentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "engagements";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ENGAGEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un engagement",
      description = "Ce service permet de créer un engagement")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(CommitmentCreateRequestDto request);

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Desysoft
   */
  interface CommitmentSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link LocalAuthorityDto}.
     *
     * @return identifiant de {@link LocalAuthorityDto}
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
     *
     * @param identifier identifiant de {@link LocalAuthorityDto}
     */
    void setLocalAuthorityIdentifier(String identifier);

    /**
     * Reprensentaion json de l'identifiant d'un fournisseur'.
     *
     */
    String JSON_SUPPLIER_IDENTIFIER = "idFournisseur";

    /**
     * Reprensentaion chaine de la phase.
     *
     */
    String JSON_SUPPLIER_AS_STRING = "fournisseurChaine";

    /**
     * Représentation en chaine de caractères de {@link SupplierDto}.
     *
     * @param supplierIdentifier identifiant de fournisseur
     */
    void setSupplierIdentifier(String supplierIdentifier);

    /**
     * Identifiant {@link SupplierDto}.
     *
     * @return supplier identifier
     */
    String getSupplierIdentifier();


    /**
     * Cette methode permet d'obtenir le sujet de l'engagement.
     *
     * @return subject
     */
    String getSubject();

    /**
     * Cette méthode permet d'assigner le sujet.
     *
     * @param subject sujet
     */
    void setSubject(String subject);

    /**
     * Cette methode permet d'obtenir la référence de l'engagement.
     *
     * @return commitmentReference La référence de l'engagememnt
     */
    String getCommitmentReference();

    /**
     * Cette méthode permet d'assigner la référence de l'engagement.
     *
     * @param commitmentReference référence facture
     */
    void setCommitmentReference(String commitmentReference);

    /**
     * Cette methode permet d'obtenir le numéro de la facture décompte.
     *
     * @return numéro de la facture décompte
     */
    String getInvoiceReferenceNumber();

    /**
     * Cette méthode permet d'assigner le numéro de la facture décompte.
     *
     * @param invoiceReferenceNumber numéro facture décompte
     */
    void setInvoiceReferenceNumber(String invoiceReferenceNumber);

    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    long getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(long amount);

    /**
     * Identifiant json du champ de l'identitant de {@link LocalAuthorityDto}.
     */
    String JSON_LOCAL_AUTHORITY_IDENTIFIER =
        CommitmentDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;


    /**
     * Identifiant json du champ sujet de {@link CommitmentDto}.
     */
    String JSON_SUBJECT = CommitmentDto.JSON_SUBJECT;


    /**
     * Identifiant json du champ référence d'engagement de {@link CommitmentDto}.
     */
    String JSON_COMMITMENT_REFERENCE = CommitmentDto.JSON_COMMITMENT_REFERENCE;


    /**
     * Identifiant json du champ numéro facture décompte de {@link CommitmentDto}.
     */
    String JSON_INVOICE_REFERENCE_NUMBER = CommitmentDto.JSON_INVOICE_REFERENCE_NUMBER;


    /**
     * Identifiant json du champ de montant.
     */
    String JSON_AMOUNT = CommitmentDto.JSON_AMOUNT;

  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class CommitmentCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements CommitmentSaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
    private String supplierIdentifier;

    @JsonbProperty(JSON_SUBJECT)
    private String subject;

    @JsonbProperty(JSON_COMMITMENT_REFERENCE)
    private String commitmentReference;

    @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
    private String invoiceReferenceNumber;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ENGAGEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des activités")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = CommitmentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class CommitmentGetManyResponseDto
      extends AbstractGetByPageResponseDto<CommitmentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<CommitmentDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ENGAGEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un engagement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = CommitmentDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ENGAGEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un engagement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = CommitmentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ENGAGEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un engagement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(CommitmentUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class CommitmentUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements CommitmentSaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_SUPPLIER_IDENTIFIER)
    private String supplierIdentifier;

    @JsonbProperty(JSON_SUBJECT)
    private String subject;

    @JsonbProperty(JSON_COMMITMENT_REFERENCE)
    private String commitmentReference;

    @JsonbProperty(JSON_INVOICE_REFERENCE_NUMBER)
    private String invoiceReferenceNumber;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ENGAGEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link CommitmentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un engagement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
