package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.payroll.server.api.PayslipStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente le gestionnaire de {@link PayslipStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class PayslipStatusManager extends AbstractStatusManager<PayslipStatus> {
  
  /**
   * Cette méthode permet d'instanctier.
   */
  public PayslipStatusManager() {
    super(PayslipStatus.class, e -> e.getName());
  }
}
