package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.Ajax;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import jakarta.faces.event.AjaxBehaviorEvent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.component.autocomplete.AutoComplete;

/**
 * Cette classe représente la base d'une sélection de valeur par suggestion.
 *
 * @param <C> Type de choix
 * @param <V> Type de la vaeur du choix
 * @param <I> Type de la sélection
 * @param <T> Type de la valeur de la sélection
 */
@Getter
@Setter
public abstract class AbstractAutoComplete<C, V, I, T> extends AbstractInput<T> {

  Boolean multiple;
  Boolean forceSelection;
  Boolean dropdown;
  Integer queryDelay;
  Integer minQueryLength;
  Integer initialResultsCount;
  Integer maxResults;
  String moreText;
  String effect;
  Boolean cache;
  Long cacheTimeout;
  String scrollHeight;

  String query;

  Ajax moreTextSelectAjax;
  Ajax itemSelectAjax;


  /* Gestions des choix */

  @Deprecated(forRemoval = true)
  Function<I, String> labelGetFunction;
  @Deprecated(forRemoval = true)
  Function<I, T> valueGetFunction;
  @Deprecated(forRemoval = true)
  T nullValue;
  @Deprecated(forRemoval = true)
  String nullLabel;

  Function<String, List<C>> onCompleteFunction;
  Function<C, String> itemLabelGetFunction;
  Function<C, V> itemValueGetFunction;
  V nullItemValue;
  List<C> nullChoices;
  String nullItemLabel;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractAutoComplete(ScriptManager scriptManager) {
    multiple = false;
    forceSelection = true;
    dropdown = true;
    queryDelay = 1000;
    minQueryLength = 3;
    initialResultsCount = 10;
    maxResults = initialResultsCount;
    moreText = "...";
    effect = "fade";
    cache = true;
    cacheTimeout = null;
    scrollHeight = null;

    instantiateMoreTextSelectAjax(scriptManager);

    itemSelectAjax();

    nullLabel = Constant.EMPTY_STRING;
    nullItemLabel = Constant.EMPTY_STRING;
    nullChoices = List.of();

    labelGetFunction = t -> Core.getAsString(t, nullLabel);
    itemLabelGetFunction = t -> Core.getAsString(t, nullItemLabel);
  }

  protected void instantiateMoreTextSelectAjax(ScriptManager scriptManager) {
    moreTextSelectAjax = new Ajax();
    moreTextSelectAjax.setDisabled(false);
    moreTextSelectAjax.setEvent("moreTextSelect");
    moreTextSelectAjax.setConsumer(event -> searchMoreText(scriptManager, event));
  }

  void searchMoreText(ScriptManager scriptManager, AjaxBehaviorEvent event) {
    maxResults = maxResults + initialResultsCount;
    AutoComplete component = (AutoComplete) event.getSource();
    component.setMaxResults(maxResults);
    scriptManager.execute(String.format("PF('%s').search('%s')", widgetVar, query));
  }

  /**
   * Cette méthode permet d'obtenir une valeur non nulle.
   *
   * @return valeur non nulle
   */
  public Ajax itemSelectAjax() {
    return Optional.ofNullable(itemSelectAjax).orElseGet(() -> {
      itemSelectAjax = new Ajax();
      itemSelectAjax.setDisabled(true);
      return itemSelectAjax;
    });
  }

  @Deprecated(forRemoval = true)
  public String getLabel(I instance) {
    return Core.applyFunction(labelGetFunction, instance, nullLabel);
  }

  @Deprecated(forRemoval = true)
  public T getValue(I instance) {
    return Core.applyFunction(valueGetFunction, instance, nullValue);
  }

  public List<C> onComplete(String query) {
    this.query = query;
    return Core.applyFunction(onCompleteFunction, query, nullChoices);
  }

  public String getItemLabel(C choice) {
    return Core.applyFunction(itemLabelGetFunction, choice, nullLabel);
  }

  public V getItemValue(C choice) {
    return Core.applyFunction(itemValueGetFunction, choice, nullItemValue);
  }

  /**
   * Cette méthode permet d'écrire une valeur.
   *
   * @param identifier identifiant
   * @param value valeur
   */
  public void writeValue(String identifier, T value) {
    SelectItem item = buildSelectItem(identifier, value);
    writeValueAsObject(item);
  }

  SelectItem buildSelectItem(String identifier, T value) {
    return new SelectItem(identifier, String.valueOf(value)) {
      @Override
      public String toString() {
        return (String) getValue();
      }
    };
  }
}
