package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'intervalle.
 *
 * @author Christian
 */
public interface HasIntervalIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'intervalle.
   *
   * @return identifiant de l'intervalle
   */
  String getIntervalIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de l'intervalle.
   *
   * @param identifier identifiant de l'intervalle
   */
  void setIntervalIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de l'intervalle.
   */
  String FIELD_INTERVAL_IDENTIFIER = "intervalIdentifier";
}