package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.MovementTrackingService.MovementTrackingCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.MovementTrackingService.MovementTrackingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MovementTrackingDto}.
 *
 * @author A.K.M
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link MovementTrackingDto}.

    @author A.K.M
               """)
public interface MovementTrackingRequestMapper extends RequestMapper<MovementTrackingDto, 
                     MovementTrackingCreateRequestDto, MovementTrackingUpdateRequestDto> {
}
