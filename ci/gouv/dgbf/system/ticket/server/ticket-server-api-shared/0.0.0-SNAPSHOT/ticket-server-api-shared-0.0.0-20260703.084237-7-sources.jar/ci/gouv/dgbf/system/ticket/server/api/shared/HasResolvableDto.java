package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être résolu.
 *
 * @author Christian
 */
public interface HasResolvableDto extends HasResolvable {

  /**
   * Identifiant json de peut être résolu.
   */
  String JSON_RESOLVABLE = "peutEtreResolu";
}