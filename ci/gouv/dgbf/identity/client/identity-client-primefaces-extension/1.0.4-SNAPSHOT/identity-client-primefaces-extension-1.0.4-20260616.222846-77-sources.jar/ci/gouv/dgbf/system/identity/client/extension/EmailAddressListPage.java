package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link EmailAddressDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class EmailAddressListPage extends AbstractPage {

  @Inject
  @Getter
  EmailAddressController controller;

  @Inject
  @Getter
  EmailAddressCollectionTabMenuController tabMenuController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + EmailAddressDto.NAME;
    controller.initialize();
    
    tabMenuController.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "emailAddressListPage";
}
