package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'insatisfactions
 * constatées sur des tickets (indicateur qualité) sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasTicketDissatisfactionActionsCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre cumulé d'insatisfactions constatées sur des
   * tickets sous forme de chaîne.
   *
   * @return le nombre cumulé d'insatisfactions constatées sur des tickets sous forme de chaîne
   */
  String getTicketDissatisfactionActionsCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre cumulé d'insatisfactions constatées sur des
   * tickets sous forme de chaîne.
   *
   * @param ticketDissatisfactionActionsCountAsString le nombre cumulé d'insatisfactions
   *                                                   constatées sur des tickets sous forme de
   *                                                   chaîne
   */
  void setTicketDissatisfactionActionsCountAsString(
      String ticketDissatisfactionActionsCountAsString);

  /**
   * Identifiant java du nombre cumulé d'insatisfactions constatées sur des tickets sous forme
   * de chaîne.
   */
  String FIELD_TICKET_DISSATISFACTION_ACTIONS_COUNT_AS_STRING =
      "ticketDissatisfactionActionsCountAsString";
}
