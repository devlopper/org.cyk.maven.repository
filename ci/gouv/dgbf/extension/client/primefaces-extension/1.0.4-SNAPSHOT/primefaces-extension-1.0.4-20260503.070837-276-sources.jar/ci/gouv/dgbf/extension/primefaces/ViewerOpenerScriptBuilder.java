package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;
import java.net.URI;
import java.util.Optional;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un constructeur de script d'ouverture de visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class ViewerOpenerScriptBuilder {
  private static final Logger LOGGER = Logger.getLogger(ViewerOpenerScriptBuilder.class.getName());

  @Getter
  @Setter
  Supplier<URI> uriSupplier;

  String windowName;

  String parameters;

  /**
   * Cette méthode permet de construire le script d'ouverture d'un visualisateur.
   *
   * @return script d'ouverture de visualisateur
   */
  public String build() {
    validate();
    URI uri = uriSupplier.get();
    validate(uri);
    String localWindowName = Optional.ofNullable(Core.getOrNullifyIfStringBlank(windowName))
        .orElse(getWindowNameWhenBlank());
    String localParameters = Optional.ofNullable(Core.getOrNullifyIfStringBlank(parameters))
        .orElse(getParametersWhenBlank());
    String script = String.format(SCRIPT_FORMAT, uri, localWindowName, localParameters);
    LOGGER.log(Level.FINER, "Script d''ouverture du visualisateur construit. {0}",
        script);
    return script;
  }

  void validate() {
    if (uriSupplier == null) {
      throw new IllegalArgumentException("Le fournisseur d'uri est obligatoire");
    }
  }
  
  void validate(URI uri) {
    if (uri == null) {
      throw new IllegalStateException("L'uri est obligatoire");
    }
  }

  protected String getWindowNameWhenBlank() {
    return "fichier";
  }

  protected String getParametersWhenBlank() {
    return "scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,titlebar=no";
  }

  private static final String SCRIPT_FORMAT =
      "var w = window.open('%1$s','%2$s','%3$s');w.document.title = '%2$s';";
}
