package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusClient;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link CivilServiceStatusDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class CivilServiceStatusController extends AbstractController {

  @Inject
  CivilServiceStatusClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  CivilServiceStatusRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = CivilServiceStatusDto.NAME;

    listController.setEntityClass(CivilServiceStatusDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(CivilServiceStatusService.PATH);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome("civilServiceStatusReadIndexesPage");

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            CivilServiceStatusDto.JSON_CATEGORY_COUNT_AS_STRING,
            CivilServiceStatusDto.JSON_GRADE_CLASS_COUNT_AS_STRING,
            CivilServiceStatusDto.JSON_ECHELON_COUNT_AS_STRING,
            CivilServiceStatusDto.JSON_PAYSCALE_COUNT_AS_STRING));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      CivilServiceStatusCreateRequestDto request = 
          requestMapper.mapCreate((CivilServiceStatusDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText()
          .writeValue(((CivilServiceStatusDto) entity).getCode());
      nameInputTextController.getInputText()
          .writeValue(((CivilServiceStatusDto) entity).getName());
    };
  }

  Consumer<String> codeConsumer() {
    return code -> listController
    .getCreateControllerOrUpdateControllerEntityAs(CivilServiceStatusDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController
    .getCreateControllerOrUpdateControllerEntityAs(CivilServiceStatusDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      CivilServiceStatusUpdateRequestDto request = 
          requestMapper.mapUpdate((CivilServiceStatusDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
