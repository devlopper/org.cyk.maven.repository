package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.faces.context.FacesContext;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente l'accesseur à la valeur de paramètre de vue.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class ViewParameterValueGetter {

  String requestParameterName;
  String defaultValue;
  Boolean authorized;

  /**
   * Cette méthode permet d'obtenir la valeur.
   *
   * @return valeur
   */
  public String get() {
    String value = null;
    if (Boolean.TRUE.equals(Core.getOrDefaultIfNull(authorized, true))) {
      Core.doThrowIfBlank(IllegalArgumentException.class, "clé de valeur requise",
          requestParameterName);
      value = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap()
          .getOrDefault(requestParameterName, defaultValue);
    }
    return value;
  }

  /**
   * Cette méthode permet d'assigner identifiant à {@link #requestParameterName}.
   *
   * @return this
   */
  public ViewParameterValueGetter requestParameterNameIsIdentifier() {
    requestParameterName = "identifiant";
    return this;
  }
}
