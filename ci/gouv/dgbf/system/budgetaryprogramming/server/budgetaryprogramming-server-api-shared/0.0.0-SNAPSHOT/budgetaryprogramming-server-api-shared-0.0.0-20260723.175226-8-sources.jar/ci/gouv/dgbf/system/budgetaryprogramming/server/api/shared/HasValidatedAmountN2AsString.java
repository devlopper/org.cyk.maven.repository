package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant validé pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountN2AsString {

  /**
   * Obtient le montant validé pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant validé pour l'année N+2 sous forme de chaîne de caractères
   */
  String getValidatedAmountN2AsString();

  /**
   * Définit le montant validé pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param validatedAmountN2AsString le montant validé pour l'année N+2 sous forme de chaîne de
   *        caractères
   */
  void setValidatedAmountN2AsString(String validatedAmountN2AsString);

  /**
   * Identifiant java du montant validé pour l'année N+2, sous forme de chaîne de caractères.
   */
  String FIELD_VALIDATED_AMOUNT_N2_AS_STRING =
      "validatedAmountN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName