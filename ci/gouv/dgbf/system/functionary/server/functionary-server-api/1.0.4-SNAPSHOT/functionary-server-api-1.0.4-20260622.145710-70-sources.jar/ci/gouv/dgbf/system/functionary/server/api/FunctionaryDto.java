package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fonctionnaire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de l'employé.
   */
  @JsonbProperty(value = JSON_EMPLOYEE_IDENTIFIER)
  private String employeeIdentifier;

  /**
   * Identifiant de l'identité.
   */
  @JsonbProperty(value = JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;
  
  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Numéro matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  private String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  private String lastNames;

  /**
   * Nom et prénoms.
   */
  @JsonbProperty(value = JSON_FIRST_NAME_AND_LAST_NAMES)
  private String firstNameAndLastNames;
  
  /**
   * Identifiant du genre.
   */
  @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
  private String genderIdentifier;

  /**
   * Est du genre masculin.
   */
  @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
  private Boolean isGenderMasculine;

  /**
   * Date de naissance.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE)
  private LocalDate birthDate;

  /**
   * Représentation en chaine de caractères de {@link #birthDate}.
   */
  @JsonbProperty(value = JSON_BIRTH_DATE_AS_STRING)
  private String birthDateAsString;
  
  /**
   * Date de première prise de service.
   */
  @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE)
  private LocalDate firstServiceStartDate;

  /**
   * Représentation en chaine de caractères de {@link #firstServiceStartDate}.
   */
  @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE_AS_STRING)
  private String firstServiceStartDateAsString;

  /**
   * Représentation en chaine de caractères de {@link #functionaryAsString}.
   */
  @JsonbProperty(value = JSON_FUNCTIONARY_AS_STRING)
  private String functionaryAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaire";

  /**
   * Identifiant json {@link #employeeIdentifier}.
   */
  public static final String JSON_EMPLOYEE_IDENTIFIER = "idEmploye";

  /**
   * Identifiant json {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";
  
  /**
   * Identifiant json {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = "adresseEmail";

  /**
   * Identifiant json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";

  /**
   * Identifiant json {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "nom";

  /**
   * Identifiant json {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = "prenoms";

  /**
   * Identifiant champ json {@link #firstNameAndLastNames}.
   */
  public static final String JSON_FIRST_NAME_AND_LAST_NAMES = "nomEtPrenoms";
  
  /**
   * Identifiant json {@link #genderIdentifier}.
   */
  public static final String JSON_GENDER_IDENTIFIER = "idGenre";

  /**
   * Identifiant json {@link #isGenderMasculine}.
   */
  public static final String JSON_IS_GENDER_MASCULINE = "estGenreMasculin";

  /**
   * Identifiant json {@link #birthDate}.
   */
  public static final String JSON_BIRTH_DATE = "dateNaissance";

  /**
   * Identifiant json {@link #birthDateAsString}.
   */
  public static final String JSON_BIRTH_DATE_AS_STRING = "dateNaissanceChaine";
  
  /**
   * Identifiant json {@link #firstServiceStartDate}.
   */
  public static final String JSON_FIRST_SERVICE_START_DATE = "datePremierePriseService";

  /**
   * Identifiant champ json {@link #firstServiceStartDateAsString}.
   */
  public static final String JSON_FIRST_SERVICE_START_DATE_AS_STRING =
      "datePremierePriseServiceChaine";

  /**
   * Identifiant champ json {@link #functionaryAsString}.
   */
  public static final String JSON_FUNCTIONARY_AS_STRING =
      "fonctionnaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
