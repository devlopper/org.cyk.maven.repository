package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayslipComponentService.PayslipComponentCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipComponentService.PayslipComponentUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayslipComponentDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayslipComponentDto}.

    @author Christian
               """)
public interface PayslipComponentRequestMapper
    extends RequestMapper<PayslipComponentDto, PayslipComponentCreateRequestDto,
        PayslipComponentUpdateRequestDto> {

}
