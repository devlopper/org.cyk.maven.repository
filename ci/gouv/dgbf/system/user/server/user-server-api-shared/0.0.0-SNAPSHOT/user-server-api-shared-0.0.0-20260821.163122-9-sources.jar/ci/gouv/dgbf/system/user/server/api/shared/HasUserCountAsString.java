package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'utilisateurs sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasUserCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'utilisateurs sous forme de chaîne.
   *
   * @return le nombre d'utilisateurs sous forme de chaîne
   */
  String getUserCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre d'utilisateurs sous forme de chaîne.
   *
   * @param userCountAsString le nombre d'utilisateurs sous forme de chaîne
   */
  void setUserCountAsString(String userCountAsString);

  /**
   * Identifiant java du nombre d'utilisateurs sous forme de chaîne.
   */
  String FIELD_USER_COUNT_AS_STRING = "userCountAsString";
}
