package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalJournalEntriesGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationAcceptRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationAcceptResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationCancelRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationCancelResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationInformationCorrectionRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationRefuseRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupArchivalSolicitationService.FileGroupArchivalSolicitationRefuseResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service {@link FileGroupArchivalSolicitationService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileGroupArchivalSolicitationClient
    extends AbstractClient<FileGroupArchivalSolicitationService>
    implements GetMany<FileGroupArchivalSolicitationGetManyResponseDto>,
        GetByIdentifier<FileGroupArchivalSolicitationDto> {

  @Override
  public FileGroupArchivalSolicitationClient service(
      FileGroupArchivalSolicitationService service) {
    return (FileGroupArchivalSolicitationClient) super.service(service);
  }

  /**
   * {@link FileGroupArchivalSolicitationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FileGroupArchivalSolicitationCreateRequestDto request) {
    return new CreateExecutor(FileGroupArchivalSolicitationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchivalSolicitationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FileGroupArchivalSolicitationGetManyResponseDto>(
        FileGroupArchivalSolicitationGetManyResponseDto.class,
        FileGroupArchivalSolicitationService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FileGroupArchivalSolicitationGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchivalSolicitationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FileGroupArchivalSolicitationDto>(
        FileGroupArchivalSolicitationDto.class,
        FileGroupArchivalSolicitationService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupArchivalSolicitationDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getByIdentifier}.
   *
   * @param request requête
   * @return {@link FileGroupArchivalSolicitationDto}
   */
  public FileGroupArchivalSolicitationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FileGroupArchivalSolicitationDto>(
        FileGroupArchivalSolicitationDto.class,
        FileGroupArchivalSolicitationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return {@link FileGroupArchivalSolicitationDto}
   */
  @Override
  public FileGroupArchivalSolicitationDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FileGroupArchivalSolicitationService#cancel}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchivalSolicitationCancelResponseDto cancel(
      FileGroupArchivalSolicitationCancelRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchivalSolicitationCancelResponseDto.class,
        FileGroupArchivalSolicitationService.CANCEL_IDENTIFIER)
            .execute(() -> service().cancel(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#accept}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchivalSolicitationAcceptResponseDto accept(
      FileGroupArchivalSolicitationAcceptRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchivalSolicitationAcceptResponseDto.class,
        FileGroupArchivalSolicitationService.ACCEPT_IDENTIFIER)
            .execute(() -> service().accept(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#refuse}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupArchivalSolicitationRefuseResponseDto refuse(
      FileGroupArchivalSolicitationRefuseRequestDto request) {
    return new GetOneExecutor<>(FileGroupArchivalSolicitationRefuseResponseDto.class,
        FileGroupArchivalSolicitationService.REFUSE_IDENTIFIER)
            .execute(() -> service().refuse(request));
  }

  /** {@link FileGroupArchivalSolicitationService#getArchivalJournalEntries}. */
  public FileGroupArchivalJournalEntriesGetManyResponseDto getArchivalJournalEntries(
      GetManyRequestDto request) {
    return new GetOneExecutor<FileGroupArchivalJournalEntriesGetManyResponseDto>(
        FileGroupArchivalJournalEntriesGetManyResponseDto.class,
        FileGroupArchivalSolicitationService.GET_JOURNAL_ENTRIES_IDENTIFIER)
            .execute(() -> service().getArchivalJournalEntries(request));
  }

  /**
   * {@link FileGroupArchivalSolicitationService#getArchivalJournalEntries}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupArchivalJournalEntriesGetManyResponseDto getArchivalJournalEntries(
      ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getArchivalJournalEntries(request);
  }

  /** {@link FileGroupArchivalSolicitationService#correctInformation}. */
  public IdentifiableResponseDto correctInformation(
      FileGroupArchivalSolicitationInformationCorrectionRequestDto request) {
    return new GetOneExecutor<>(IdentifiableResponseDto.class,
        FileGroupArchivalSolicitationService.CORRECT_INFORMATION_IDENTIFIER)
            .execute(() -> service().correctInformation(request));
  }

  /** Obtient le nombre de concepts. */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(FileGroupArchivalSolicitationService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }
}
