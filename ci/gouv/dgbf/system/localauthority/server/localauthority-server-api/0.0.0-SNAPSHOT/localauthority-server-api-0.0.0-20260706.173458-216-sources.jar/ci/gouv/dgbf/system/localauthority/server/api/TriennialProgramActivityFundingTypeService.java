package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TriennialProgramActivityFundingTypeDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = TriennialProgramActivityFundingTypeService.PATH)
@Tag(name = "Gestion des types de financement d'un programme triennal")
public interface TriennialProgramActivityFundingTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites-programmes-triennals-moyens-de-financement";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un type de financement d'un "
      + "programme triennal",
      description = "Ce service permet de créer un type de financement d'un programme triennal")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TriennialProgramActivityFundingTypeCreateRequestDto request);

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface SaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant {@link FundingTypeDto}.
     *
     * @return identifiant {@link FundingTypeDto}
     */
    String getFundingTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link FundingTypeDto}.
     *
     * @param modeIdentifier identifiant {@link FundingTypeDto}
     */
    void setFundingTypeIdentifier(String modeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
     *
     * @return identifiant {@link TriennialProgramActivityDto}
     */
    String getTriennialProgramActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
     *
     * @param triennialProgramActivityIdentifier identifiant {@link TriennialProgramActivityDto}
     */
    void setTriennialProgramActivityIdentifier(String triennialProgramActivityIdentifier);

    /**
     * Cette méthode permet d'obtenir le le montant 1.
     *
     * @return montant 1
     */
    long getAmount1();

    /**
     * Cette méthode permet d'assigner le le montant 1.
     *
     * @param amount1 montant 1
     */
    void setAmount1(long amount1);

    /**
     * Cette méthode permet d'obtenir le le montant 1.
     *
     * @return montant 2
     */
    long getAmount2();

    /**
     * Cette méthode permet d'assigner le le montant 1.
     *
     * @param amount2 montant 2
     */
    void setAmount2(long amount2);

    /**
     * Cette méthode permet d'obtenir le le montant 2.
     *
     * @return montant 3
     */
    long getAmount3();

    /**
     * Cette méthode permet d'assigner le le montant 2.
     *
     * @param amount3 montant 3
     */
    void setAmount3(long amount3);

    /**
     * Identifiant champ json de {@link FundingTypeDto}.
     */
    String JSON_FUNDING_TYPE_IDENTIFIER =
        TriennialProgramActivityFundingTypeDto.JSON_FUNDING_TYPE_IDENTIFIER;

    /**
     * Identifiant champ json de {@link TriennialProgramActivityDto}.
     */
    String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
        TriennialProgramActivityFundingTypeDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;

    /**
     * Identifiant champ json du montant 1.
     */
    String JSON_AMOUNT_1 = FundingDto.JSON_AMOUNT_1;

    /**
     * Identifiant champ json du montant 2.
     */
    String JSON_AMOUNT_2 = FundingDto.JSON_AMOUNT_2;

    /**
     * Identifiant champ json du montant 3.
     */
    String JSON_AMOUNT_3 = FundingDto.JSON_AMOUNT_3;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramActivityFundingTypeCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SaveRequestDto {
    @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENTS";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des types de financement d'un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = GetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class GetManyResponseDto
      extends AbstractGetByPageResponseDto<TriennialProgramActivityFundingTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TriennialProgramActivityFundingTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un type de financement d'un programme triennal")
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema =
          @Schema(implementation = TriennialProgramActivityFundingTypeDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un type de financement d'un "
          + "programme triennal")
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema =
          @Schema(implementation = TriennialProgramActivityFundingTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un type de financement d'un programme "
          + "triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TriennialProgramActivityFundingTypeUpdateRequestDto request);


  /**
   * Cette classe représente la requête de mise à jour du commentaire d'un type de financement
   * d'un programme triennal.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramActivityFundingTypeUpdateRequestDto extends ByIdentifierRequestDto
      implements SaveRequestDto {
    @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }

  /**
   * Identifiant du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_IDENTIFIER =
      "MISE_A_JOUR_MONTANT_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_PATH = TriennialProgramActivityFundingTypeUpdateAmountRequestDto.JSON_AMOUNT;

  /**
   * Cette méthode permet de mettre à jour montant de
   * {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_AMOUNT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_AMOUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateAmount(TriennialProgramActivityFundingTypeUpdateAmountRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de montant.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramActivityFundingTypeUpdateAmountRequestDto
      extends ByIdentifierRequestDto {
    /**
     * Montant.
     */
    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    /**
     * Index.
     */
    @JsonbProperty(JSON_INDEX)
    private int index;

    /**
     * Identifiant json {@link #amount}.
     */
    public static final String JSON_AMOUNT = "montant";

    /**
     * Identifiant json {@link #index}.
     */
    public static final String JSON_INDEX = "index";

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE_PROGRAMME_TRIENNAL_TYPE_FINANCEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TriennialProgramActivityFundingTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un type de financement d'un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

