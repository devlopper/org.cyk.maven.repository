package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FundGroupDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FundGroupRequestMapperImpl implements FundGroupRequestMapper {

    @Override
    public FundGroupService.FundGroupCreateRequestDto mapCreate(FundGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundGroupService.FundGroupCreateRequestDto fundGroupCreateRequestDto = new FundGroupService.FundGroupCreateRequestDto();

        fundGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundGroupCreateRequestDto.setCode( arg0.getCode() );
        fundGroupCreateRequestDto.setName( arg0.getName() );
        fundGroupCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return fundGroupCreateRequestDto;
    }

    @Override
    public FundGroupService.FundGroupUpdateRequestDto mapUpdate(FundGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundGroupService.FundGroupUpdateRequestDto fundGroupUpdateRequestDto = new FundGroupService.FundGroupUpdateRequestDto();

        fundGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fundGroupUpdateRequestDto.setCode( arg0.getCode() );
        fundGroupUpdateRequestDto.setName( arg0.getName() );
        fundGroupUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return fundGroupUpdateRequestDto;
    }
}
