package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.EvaluateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextService.ScriptContextCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextService.ScriptContextGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptContextService.ScriptContextUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ScriptContextService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ScriptContextClient extends AbstractClient<ScriptContextService>
    implements GetByIdentifier<ScriptContextDto>, GetMany<ScriptContextGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ScriptContextClient service(ScriptContextService service) {
    return (ScriptContextClient) super.service(service);
  }

  /**
   * {@link ScriptContextService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ScriptContextCreateRequestDto request) {
    return new CreateExecutor(ScriptContextService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ScriptContextService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptContextGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ScriptContextGetManyResponseDto>(
        ScriptContextGetManyResponseDto.class, ScriptContextService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ScriptContextService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptContextGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ScriptContextService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptContextDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ScriptContextDto>(ScriptContextDto.class,
        ScriptContextService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ScriptContextService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ScriptContextDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ScriptContextService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ScriptContextDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ScriptContextDto>(ScriptContextDto.class,
        ScriptContextService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ScriptContextService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptContextDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ScriptContextService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ScriptContextUpdateRequestDto request) {
    return new IdentifiableExecutor(ScriptContextService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ScriptContextService#evaluate}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto evaluate(EvaluateRequestDto request) {
    return new IdentifiableExecutor(ScriptContextService.EVALUATE_IDENTIFIER)
        .execute(() -> service().evaluate(request));
  }

  /**
   * {@link ScriptContextService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ScriptContextService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ScriptContextService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
