package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * du l'unité de spécialisation du budget.
 *
 * @author arnaud
 */
public interface HasBudgetSpecializationUnitAsStringDto
       extends HasBudgetSpecializationUnitAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'unité de spécialisation
   * du budget.
   */
  String JSON_BUDGET_SPECIALIZATION_UNIT_AS_STRING = "uniteSpecialisationBudgetChaine";
}
