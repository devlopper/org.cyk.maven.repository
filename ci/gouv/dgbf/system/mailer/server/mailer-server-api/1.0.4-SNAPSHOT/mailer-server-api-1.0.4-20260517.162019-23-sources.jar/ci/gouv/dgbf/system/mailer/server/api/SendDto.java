package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la requête d'envoi de mail.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SendDto extends AbstractIdentifiableAuditableDto {

  @JsonbProperty(JSON_MAIL_IDENTIFIER)
  private String mailIdentifier;
  
  public static final String JSON_MAIL_IDENTIFIER = "idMail";
}
