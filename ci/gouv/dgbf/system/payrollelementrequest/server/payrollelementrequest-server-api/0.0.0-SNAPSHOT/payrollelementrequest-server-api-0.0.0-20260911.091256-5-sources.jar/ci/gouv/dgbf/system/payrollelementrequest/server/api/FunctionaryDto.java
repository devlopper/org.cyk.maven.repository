package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryRegistrationNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Fonctionnaire ou Agent de l'État (FAE), mappée sur
 * {@code VA_FONCTIONNAIRE} : identité (simulée via {@code TA_FONCTIONNAIRE_SIMULE}, en attendant
 * l'intégration au module {@code functionary}) fusionnée avec les compteurs de réclamations
 * calculés sur {@code TA_RECLAMATION}. Un FAE pouvant tenir plusieurs bulletins de paie, chacun
 * rattaché à une structure différente, {@link #structures} expose un tableau (schéma JSON libre,
 * seule {@code identifiantStructure} est une clé garantie) plutôt qu'une affectation unique.
 * Aucune donnée stockée -- recalculée à chaque lecture.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryDto extends AbstractIdentifiableDto
    implements HasFunctionaryRegistrationNumberDto {

  /**
   * Matricule.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(JSON_LAST_NAME)
  private String lastName;

  /**
   * Prénom.
   */
  @JsonbProperty(JSON_FIRST_NAME)
  private String firstName;

  /**
   * Structures (bulletins de paie) du FAE -- une par structure, schéma libre (aucune clé
   * garantie hormis {@code identifiantStructure}) ; désérialisée côté serveur depuis
   * {@code VA_FONCTIONNAIRE} (voir {@code FunctionaryDynamicQuery}), jamais transmise sous forme
   * de chaîne JSON encodée. Jamais {@code null} (liste vide par défaut).
   */
  @JsonbProperty(JSON_STRUCTURES)
  private List<Map<String, String>> structures = new ArrayList<>();

  /**
   * Nombre total de réclamations ayant fait l'objet d'au moins une Soumission -- exclut les
   * brouillons à l'état {@code CREEE} jamais soumis.
   */
  @JsonbProperty(JSON_TOTAL_CLAIM_COUNT)
  private Integer totalClaimCount;

  /**
   * Nombre de réclamations en cours ({@code SOUMISE} + {@code PRISE_EN_CHARGE}).
   */
  @JsonbProperty(JSON_IN_PROGRESS_CLAIM_COUNT)
  private Integer inProgressClaimCount;

  /**
   * Nombre de réclamations acceptées.
   */
  @JsonbProperty(JSON_ACCEPTED_CLAIM_COUNT)
  private Integer acceptedClaimCount;

  /**
   * Nombre de réclamations rejetées.
   */
  @JsonbProperty(JSON_REJECTED_CLAIM_COUNT)
  private Integer rejectedClaimCount;

  /**
   * Nombre de réclamations différées.
   */
  @JsonbProperty(JSON_DEFERRED_CLAIM_COUNT)
  private Integer deferredClaimCount;

  /**
   * Pont vers {@link HasFunctionaryRegistrationNumberDto} : nom d'accesseur imposé par cette
   * interface de segregation, distinct du nom de {@link #registrationNumber} conservé (repris tel
   * quel par plusieurs écrans client via {@code #{functionary.registrationNumber}} -- le renommer
   * romprait ces vues sans bénéfice).
   *
   * @return {@link #registrationNumber}
   */
  @Override
  public String getFunctionaryRegistrationNumber() {
    return registrationNumber;
  }

  /**
   * {@link #getFunctionaryRegistrationNumber()}.
   *
   * @param functionaryRegistrationNumber {@link #registrationNumber}
   */
  @Override
  public void setFunctionaryRegistrationNumber(String functionaryRegistrationNumber) {
    this.registrationNumber = functionaryRegistrationNumber;
  }

  /**
   * Identifiant json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER =
      HasFunctionaryRegistrationNumberDto.JSON_FUNCTIONARY_REGISTRATION_NUMBER;

  /**
   * Identifiant json {@link #lastName}.
   */
  public static final String JSON_LAST_NAME = "nom";

  /**
   * Identifiant json {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "prenom";

  /**
   * Identifiant json {@link #structures}.
   */
  public static final String JSON_STRUCTURES = "structures";

  /**
   * Clé (au sein d'une structure de {@link #structures}) portant l'identifiant de la structure --
   * seule clé garantie, référence stable pour une réclamation choisissant sa structure.
   */
  public static final String JSON_STRUCTURE_IDENTIFIER = "identifiantStructure";

  /**
   * Identifiant json {@link #totalClaimCount}.
   */
  public static final String JSON_TOTAL_CLAIM_COUNT = "nombreReclamationsTotal";

  /**
   * Identifiant json {@link #inProgressClaimCount}.
   */
  public static final String JSON_IN_PROGRESS_CLAIM_COUNT = "nombreReclamationsEnCours";

  /**
   * Identifiant json {@link #acceptedClaimCount}.
   */
  public static final String JSON_ACCEPTED_CLAIM_COUNT = "nombreReclamationsAcceptees";

  /**
   * Identifiant json {@link #rejectedClaimCount}.
   */
  public static final String JSON_REJECTED_CLAIM_COUNT = "nombreReclamationsRejetees";

  /**
   * Identifiant json {@link #deferredClaimCount}.
   */
  public static final String JSON_DEFERRED_CLAIM_COUNT = "nombreReclamationsDifferees";

  /**
   * Identifiant json de identifiant de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaire";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "fonctionnaires";
}
