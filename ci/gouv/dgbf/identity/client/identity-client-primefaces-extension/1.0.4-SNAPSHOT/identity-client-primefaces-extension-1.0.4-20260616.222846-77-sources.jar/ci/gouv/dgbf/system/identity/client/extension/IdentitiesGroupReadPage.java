package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupClient;
import ci.gouv.dgbf.system.identity.server.api.IdentitiesGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de consultation de {@link IdentitiesGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentitiesGroupReadPage extends AbstractPage {

  @Inject
  IdentitiesGroupClient client;

  IdentitiesGroupDto group;

  @Inject
  @Getter
  IdentityGroupController identityGroupController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture " + IdentitiesGroupDto.NAME;

    group = client.getByIdentifier(getRequestParameterIdentifier(),
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER), userIdentifier,
        null);

    identityGroupController.getFilterController().getFilter()
        .setGroupIdentifier(group.getIdentifier());
    identityGroupController.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "identitiesGroupReadPage";
}
