package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de programmation.
 *
 * @author Christian
 */
public interface HasProgrammingIdentifierDto extends HasProgrammingIdentifier {

  /**
   * Identifiant json de l'identifiant de la programmation.
   */
  String JSON_PROGRAMMING_IDENTIFIER = "idProgrammation";
}