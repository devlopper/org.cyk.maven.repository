package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des dossiers de masse salariale.
 *
 * <p>Les quatre critères de l'écran de réception : la section budgétaire, l'EPN, l'exercice et le
 * statut. Ce sont exactement les axes selon lesquels un chargé de contrôle cherche un dossier.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class BudgetAdministrativeUnitDossierFilter extends AbstractIdentifiableFilter {

  /**
   * Budget de rattachement.
   */
  String budgetIdentifier;

  /**
   * Exercice budgétaire.
   */
  String exerciseIdentifier;

  /**
   * EPN auquel le dossier appartient.
   */
  String administrativeUnitIdentifier;

  /**
   * Code {@link BudgetAdministrativeUnitStatus}.
   */
  String statusCode;

  public BudgetAdministrativeUnitDossierFilter() {
    super();
  }

  public BudgetAdministrativeUnitDossierFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setBudgetIdentifier(read(filter, BudgetAdministrativeUnitDossierDto.JSON_BUDGET_IDENTIFIER));
    setExerciseIdentifier(
        read(filter, BudgetAdministrativeUnitDossierDto.JSON_EXERCISE_IDENTIFIER));
    setAdministrativeUnitIdentifier(
        read(filter, BudgetAdministrativeUnitDossierDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
    setStatusCode(read(filter, BudgetAdministrativeUnitDossierDto.JSON_STATUS_CODE));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, BudgetAdministrativeUnitDossierDto.JSON_BUDGET_IDENTIFIER, getBudgetIdentifier());
    write(filter, BudgetAdministrativeUnitDossierDto.JSON_EXERCISE_IDENTIFIER,
        getExerciseIdentifier());
    write(filter, BudgetAdministrativeUnitDossierDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER,
        getAdministrativeUnitIdentifier());
    write(filter, BudgetAdministrativeUnitDossierDto.JSON_STATUS_CODE, getStatusCode());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats, sous la forme
   * {@code dto -> BudgetAdministrativeUnitDossierFilter.read(dto, clé)}.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
