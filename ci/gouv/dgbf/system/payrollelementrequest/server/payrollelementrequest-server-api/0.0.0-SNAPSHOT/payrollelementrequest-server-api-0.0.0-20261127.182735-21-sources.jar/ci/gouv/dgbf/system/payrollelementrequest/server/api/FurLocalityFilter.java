package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FurLocalityDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FurLocalityFilter extends AbstractIdentifiableFilter {

  /**
   * Code de la localité d'affectation.
   */
  String localityCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FurLocalityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FurLocalityFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localityCode = getLocalityCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalityCode(filter, localityCode);
  }

  /**
   * Cette méthode permet d'assigner le code de la localité.
   *
   * @param filter filtre
   * @param localityCode code de la localité
   */
  public static void setLocalityCode(FilterDto filter, String localityCode) {
    set(filter, JSON_LOCALITY_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(localityCode));
  }

  /**
   * Cette méthode permet d'obtenir le code de la localité.
   *
   * @param filter filtre
   * @return code de la localité
   */
  public static String getLocalityCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCALITY_CODE));
  }

  /**
   * Identifiant json champ {@link #localityCode}.
   */
  public static final String JSON_LOCALITY_CODE = FurLocalityDto.JSON_LOCALITY_CODE;
}
