package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DeclarationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-25T14:45:38+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DeclarationRequestMapperImpl implements DeclarationRequestMapper {

    @Override
    public DeclarationService.DeclarationCreateRequestDto mapCreate(DeclarationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeclarationService.DeclarationCreateRequestDto declarationCreateRequestDto = new DeclarationService.DeclarationCreateRequestDto();

        declarationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        declarationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        declarationCreateRequestDto.setTicketIdentifier( arg0.getTicketIdentifier() );
        declarationCreateRequestDto.setReporterIdentityIdentifier( arg0.getReporterIdentityIdentifier() );

        return declarationCreateRequestDto;
    }

    @Override
    public DeclarationService.DeclarationUpdateRequestDto mapUpdate(DeclarationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DeclarationService.DeclarationUpdateRequestDto declarationUpdateRequestDto = new DeclarationService.DeclarationUpdateRequestDto();

        declarationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        declarationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        declarationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        declarationUpdateRequestDto.setTicketIdentifier( arg0.getTicketIdentifier() );
        declarationUpdateRequestDto.setReporterIdentityIdentifier( arg0.getReporterIdentityIdentifier() );

        return declarationUpdateRequestDto;
    }
}
