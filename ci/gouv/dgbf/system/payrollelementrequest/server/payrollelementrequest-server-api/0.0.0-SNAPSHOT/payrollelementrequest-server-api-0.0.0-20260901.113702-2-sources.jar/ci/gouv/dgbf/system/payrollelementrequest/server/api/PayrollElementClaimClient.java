package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimSubmitRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimSubmitResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimService.PayrollElementClaimUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollElementClaimService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollElementClaimClient extends AbstractClient<PayrollElementClaimService>
    implements GetByIdentifier<PayrollElementClaimDto>,
    GetMany<PayrollElementClaimGetManyResponseDto> {

  @Override
  public PayrollElementClaimClient service(PayrollElementClaimService service) {
    return (PayrollElementClaimClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollElementClaimCreateRequestDto request) {
    return new CreateExecutor(PayrollElementClaimService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollElementClaimService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimGetManyResponseDto>(
        PayrollElementClaimGetManyResponseDto.class, PayrollElementClaimService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollElementClaimGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementClaimService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimDto>(PayrollElementClaimDto.class,
        PayrollElementClaimService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollElementClaimService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimDto>(PayrollElementClaimDto.class,
        PayrollElementClaimService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollElementClaimService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollElementClaimDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollElementClaimService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollElementClaimUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollElementClaimService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollElementClaimService#submit}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimSubmitResponseDto submit(PayrollElementClaimSubmitRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimSubmitResponseDto>(
        PayrollElementClaimSubmitResponseDto.class, PayrollElementClaimService.SUBMIT_IDENTIFIER)
            .execute(() -> service().submit(request));
  }
}
