package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de {@link IdentityDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentitiesGroupDto extends AbstractIdentifiableAuditableDto {

  /**
   * Représentation en chaine de caractères du nombre de {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITIES_COUNT_AS_STRING)
  private String identitiesCountAsString;

  /**
   * Suppression en cascade.
   */
  @JsonbProperty(JSON_CASCADE_ON_DELETE)
  private Boolean cascadeOnDelete;
  
  /**
   * Identifiant {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;
  
  /**
   * Représentation en chaine de caractères {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;
  
  /**
   * {@link Role} de {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_ROLE)
  private Role identityRole;
  
  /**
   * Représentation en chaine de caractères {@link Role} de {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_ROLE_AS_STRING)
  private String identityRoleAsString;
  
  /**
   * Identifiant JSON de {@link #identitiesCountAsString}.
   */
  public static final String JSON_IDENTITIES_COUNT_AS_STRING = "nombreIdentitesChaine";

  /**
   * Identifiant JSON de {@link #cascadeOnDelete}.
   */
  public static final String JSON_CASCADE_ON_DELETE = "suppressionEnCascade";
  
  /**
   * Identifiant JSON de {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";
  
  /**
   * Identifiant JSON de {@link #identityAsString}.
   */
  public static final String JSON_IDENTITY_AS_STRING = "identiteChaine";
  
  /**
   * Identifiant JSON de {@link #identityRole}.
   */
  public static final String JSON_IDENTITY_ROLE = "roleIdentite";
  
  /**
   * Identifiant JSON de {@link #identityRoleAsString}.
   */
  public static final String JSON_IDENTITY_ROLE_AS_STRING = "roleIdentiteChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe d'identités";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes d'identités";
}
