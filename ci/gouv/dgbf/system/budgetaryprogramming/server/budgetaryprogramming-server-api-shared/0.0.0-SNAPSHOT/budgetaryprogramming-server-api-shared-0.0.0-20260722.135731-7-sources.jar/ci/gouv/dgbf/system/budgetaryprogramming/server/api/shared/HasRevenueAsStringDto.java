package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de revenu.
 *
 * @author Christian
 */
public interface HasRevenueAsStringDto extends HasRevenueAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du revenu.
   */
  String JSON_REVENUE_AS_STRING = "revenuChaine";
}
