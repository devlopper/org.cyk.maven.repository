package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.ArrayHelper;
import ci.gouv.dgbf.extension.core.FileHelper;
import ci.gouv.dgbf.extension.core.Jsonifier;
import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.core.throwable.ThrowableHelper;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportClient;
import ci.gouv.dgbf.system.report.server.api.ReportService;
import ci.gouv.dgbf.system.report.server.api.ReportService.GetBytesByIdentifierRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ParameterDto;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.omnifaces.servlet.FileServlet;

/**
 * Cette classe représente le serveur d'octets de rapport.
 *
 * @author Christian
 *
 */
@WebServlet(ReportServlet.URL_PATTERN)
public class ReportServlet extends FileServlet {
  private static final Logger LOGGER = Logger.getLogger(ReportServlet.class.getName());

  /**
   * Motif de l'URL.
   */
  public static final String URL_PATTERN = ViewerUriBuilder.PATH + "/*";

  @Inject
  transient ReportClient client;

  @Inject
  transient StringHelper stringHelper;

  @Inject
  transient ArrayHelper arrayHelper;

  @Inject
  transient FileHelper fileHelper;

  @Inject
  transient Jsonifier jsonifier;

  @Inject
  transient ThrowableHelper throwableHelper;

  @Override
  protected File getFile(HttpServletRequest request) {
    File file;
    String fileType = getFileType(request);
    byte[] bytes = getBytes(request, fileType);
    if (bytes == null) {
      file = null;
    } else {
      String fileName = getFileName(request);
      file = fileHelper.writeToTemprorayFile(bytes,
          fileName + System.currentTimeMillis() + "." + fileType);
    }
    LOGGER.log(Level.FINER, "Fichier obtenu. {0}", file);
    return file;
  }

  byte[] getBytes(HttpServletRequest request, String fileType) {
    byte[] bytes;
    try {
      bytes = client.getBytesByIdentifier(
          request.getParameter(ByIdentifierRequestDto.JSON_IDENTIFIER), fileType,
          getParameters(request), request.getParameter(AbstractRequestDto.JSON_AUDIT_WHO),
          request.getParameter(AbstractAuditedRequestJsonDto.JSON_AUDIT_SESSION));
      LOGGER.log(Level.FINER, "Octets obtenus. #{0}", arrayHelper.getSize(bytes));
    } catch (Exception exception) {
      request.setAttribute("exception", exception);
      bytes = null;
      LOGGER.log(Level.SEVERE, "Erreur lors de l''obtention des octets. {0}",
          exception.getMessage());
    }

    return bytes;
  }

  String getFileType(HttpServletRequest request) {
    String type = request.getParameter(GetBytesByIdentifierRequestDto.JSON_FILE_TYPE);
    if (stringHelper.isBlank(type)) {
      type = ReportService.DEFAULT_FILE_TYPE;
    }
    return type;
  }

  String getFileName(HttpServletRequest request) {
    String name = request.getParameter(GetBytesByIdentifierRequestDto.JSON_FILE_NAME);
    if (stringHelper.isBlank(name)) {
      name = FILE_NAME;
    }
    return name;
  }

  @SuppressWarnings("unchecked")
  List<ParameterDto> getParameters(HttpServletRequest httpServletRequest) {
    List<ParameterDto> parameters = null;
    String json = httpServletRequest.getParameter(GetBytesByIdentifierRequestDto.JSON_PARAMETERS);
    if (stringHelper.isNotBlank(json)) {
      json = URLDecoder.decode(json, StandardCharsets.UTF_8);
      Map<String, List<String>> map = jsonifier.unjsonify(Map.class, json);
      parameters = buildParameters(map);
    }
    return parameters;
  }

  List<ParameterDto> buildParameters(Map<String, List<String>> map) {
    if (map == null) {
      return Collections.emptyList();
    } else {
      return map.entrySet().stream().map(entry -> {
        ParameterDto parameter = new ParameterDto();
        parameter.setName(entry.getKey());
        parameter.setValues(entry.getValue());
        return parameter;
      }).toList();
    }
  }

  @Override
  protected long getExpireTime(HttpServletRequest request, File file) {
    /*
     * Time should be computed based on request parameters. for now 0 but will be handled later
     */
    return 0;
  }

  @Override
  protected void handleFileNotFound(HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    Exception exception = (Exception) request.getAttribute("exception");
    if (exception == null) {
      super.handleFileNotFound(request, response); 
    } else {
      response.sendError(500, throwableHelper.getMessage(exception)); 
    }    
  }

  static final String FILE_NAME = "rapport";
}
