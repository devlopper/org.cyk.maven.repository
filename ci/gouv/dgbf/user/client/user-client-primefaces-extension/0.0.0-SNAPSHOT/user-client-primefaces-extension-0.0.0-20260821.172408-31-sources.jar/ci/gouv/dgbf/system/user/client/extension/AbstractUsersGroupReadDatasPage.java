package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupClient;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la classe dont herite les autres classes.
 *
 * @author Christian
 *
 */
public abstract class AbstractUsersGroupReadDatasPage extends AbstractPage {

  @Inject
  protected UsersGroupClient client;

  @Getter
  protected UsersGroupDto usersGroup;

  @Getter
  protected LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  protected IconManager iconManager;

  @Inject
  @Getter
  protected UsersGroupTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + UsersGroupDto.NAME;
    String identifier = getRequestParameterIdentifier();

    usersGroup = client.getByIdentifier(identifier, instantiateProjection(), userIdentifier, null);

    buildLabelValueGroupsInformationCard();

    tabMenuController.usersGroup = usersGroup;
    tabMenuController.initialize();
  }

  /**
   * Cette méthode permet de construire {@link #labelValueGroupsInformationCard}.
   */
  protected void buildLabelValueGroupsInformationCard() {
    UsersGroupLabelValueGroupsInformationCardBuilder builder =
        new UsersGroupLabelValueGroupsInformationCardBuilder(iconManager);
    builder.code(usersGroup.getCode()).name(usersGroup.getName())
        .module(usersGroup.getModuleAsString());
    labelValueGroupsInformationCard = builder.build();
  }

  /**
   * Cette méthode permet d'instancier {@link ProjectionDto}.
   *
   * @return {@link ProjectionDto}
   */
  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        UsersGroupDto.JSON_MODULE_AS_STRING);
  }
}
