package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant saisi à l'horizon N2.
 *
 * @author Christian
 */
public interface HasInputtedAmountN2 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant saisi à l'horizon N2.
   *
   * @return le montant saisi à l'horizon N2
   */
  Long getInputtedAmountN2();

  /**
   * Cette méthode permet d'assigner le montant saisi à l'horizon N2.
   *
   * @param amount le montant saisi à l'horizon N2
   */
  void setInputtedAmountN2(Long amount);

  /**
   * Identifiant java du montant saisi à l'horizon N2.
   */
  String FIELD_INPUTTED_AMOUNT_N2 = "inputtedAmountN2";
}
