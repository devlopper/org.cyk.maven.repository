package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ExpectedEffectService.ExpectedEffectCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ExpectedEffectService.ExpectedEffectUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ExpectedEffectDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ExpectedEffectDto}.

    @author akm
               """)
public interface ExpectedEffectRequestMapper extends
    RequestMapper<ExpectedEffectDto, ExpectedEffectCreateRequestDto,
        ExpectedEffectUpdateRequestDto> {

}
