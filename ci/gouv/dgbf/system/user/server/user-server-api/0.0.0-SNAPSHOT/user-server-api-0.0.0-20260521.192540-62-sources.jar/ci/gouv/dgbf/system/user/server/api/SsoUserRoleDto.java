package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;


/**
 * Cette classe représente la relation utilisateur et role SSO (Single Sign-On).
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SsoUserRoleDto extends AbstractIdentifiableDto {

  /**
   * Le nom du role.
   */
  @JsonbProperty(value = JSON_ROLE_NAME)
  private String roleName;

  /**
   * Identifiant json champ {@link #roleName}.
   */
  public static final String JSON_ROLE_NAME = "roleName";


  /**
   * Le ID du client.
   */
  @JsonbProperty(value = JSON_USERNAME)
  private String username;

  /**
   * Identifiant json champ {@link #username}.
   */
  public static final String JSON_USERNAME = "username";


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUserRoleReference";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "userRoleReferenceChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "privilège référencé";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "privilèges référencés";
}