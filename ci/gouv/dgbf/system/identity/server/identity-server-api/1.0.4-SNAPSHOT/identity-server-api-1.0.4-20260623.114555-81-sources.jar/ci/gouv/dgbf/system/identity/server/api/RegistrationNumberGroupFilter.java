package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RegistrationNumberGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class RegistrationNumberGroupFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Est fonction publique.
   */
  Boolean isPublicFunction;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isPublicFunction = getIsPublicFunction(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsPublicFunction(filter, isPublicFunction);
  }

  /**
   * Cette méthode permet d'assigner est fonction publique.
   *
   * @param filter filtre
   * @param isPublicFunction est fonction publique
   */
  public static void setIsPublicFunction(FilterDto filter, Boolean isPublicFunction) {
    set(filter, JSON_IS_PUBLIC_FUNCTION, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isPublicFunction));
  }

  /**
   * Cette méthode permet d'obtenir est fonction publique.
   *
   * @param filter filtre
   * @return est fonction publique
   */
  public static Boolean getIsPublicFunction(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_PUBLIC_FUNCTION));
  }

  /**
   * Identifiant JSON {@link #isPublicFunction}.
   * 
   */
  public static final String JSON_IS_PUBLIC_FUNCTION = "estFonctionPublique";
}
