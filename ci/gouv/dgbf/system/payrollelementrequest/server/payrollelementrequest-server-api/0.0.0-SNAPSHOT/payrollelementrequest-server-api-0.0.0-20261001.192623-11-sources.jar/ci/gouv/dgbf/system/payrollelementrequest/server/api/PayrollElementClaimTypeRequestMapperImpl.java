package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-01T19:26:44+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementClaimTypeRequestMapperImpl implements PayrollElementClaimTypeRequestMapper {

    @Override
    public PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto mapCreate(PayrollElementClaimTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto payrollElementClaimTypeCreateRequestDto = new PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto();

        payrollElementClaimTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeCreateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeCreateRequestDto.setName( arg0.getName() );
        payrollElementClaimTypeCreateRequestDto.setClaimTypeGroupIdentifier( arg0.getClaimTypeGroupIdentifier() );
        payrollElementClaimTypeCreateRequestDto.setRoleTraitement( arg0.getRoleTraitement() );
        payrollElementClaimTypeCreateRequestDto.setTreasuryTransmittable( arg0.getTreasuryTransmittable() );
        payrollElementClaimTypeCreateRequestDto.setFunctionaryDepositAuthorized( arg0.getFunctionaryDepositAuthorized() );
        payrollElementClaimTypeCreateRequestDto.setExpectedDocumentTypesGroupIdentifier( arg0.getExpectedDocumentTypesGroupIdentifier() );
        payrollElementClaimTypeCreateRequestDto.setDescription( arg0.getDescription() );
        payrollElementClaimTypeCreateRequestDto.setRegulatoryReference( arg0.getRegulatoryReference() );
        payrollElementClaimTypeCreateRequestDto.setRegulatoryReferenceDocumentIdentifier( arg0.getRegulatoryReferenceDocumentIdentifier() );

        return payrollElementClaimTypeCreateRequestDto;
    }

    @Override
    public PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto mapUpdate(PayrollElementClaimTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto payrollElementClaimTypeUpdateRequestDto = new PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto();

        payrollElementClaimTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementClaimTypeUpdateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeUpdateRequestDto.setName( arg0.getName() );
        payrollElementClaimTypeUpdateRequestDto.setClaimTypeGroupIdentifier( arg0.getClaimTypeGroupIdentifier() );
        payrollElementClaimTypeUpdateRequestDto.setRoleTraitement( arg0.getRoleTraitement() );
        payrollElementClaimTypeUpdateRequestDto.setTreasuryTransmittable( arg0.getTreasuryTransmittable() );
        payrollElementClaimTypeUpdateRequestDto.setFunctionaryDepositAuthorized( arg0.getFunctionaryDepositAuthorized() );
        payrollElementClaimTypeUpdateRequestDto.setExpectedDocumentTypesGroupIdentifier( arg0.getExpectedDocumentTypesGroupIdentifier() );
        payrollElementClaimTypeUpdateRequestDto.setDescription( arg0.getDescription() );
        payrollElementClaimTypeUpdateRequestDto.setRegulatoryReference( arg0.getRegulatoryReference() );
        payrollElementClaimTypeUpdateRequestDto.setRegulatoryReferenceDocumentIdentifier( arg0.getRegulatoryReferenceDocumentIdentifier() );

        return payrollElementClaimTypeUpdateRequestDto;
    }
}
