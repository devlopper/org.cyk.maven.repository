package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimTypeObjectDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-27T10:25:25+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimTypeObjectRequestMapperImpl implements ClaimTypeObjectRequestMapper {

    @Override
    public ClaimTypeObjectService.ClaimTypeObjectCreateRequestDto mapCreate(ClaimTypeObjectDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimTypeObjectService.ClaimTypeObjectCreateRequestDto claimTypeObjectCreateRequestDto = new ClaimTypeObjectService.ClaimTypeObjectCreateRequestDto();

        claimTypeObjectCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimTypeObjectCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimTypeObjectCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        claimTypeObjectCreateRequestDto.setObjectNature( arg0.getObjectNature() );
        claimTypeObjectCreateRequestDto.setObjectIdentifier( arg0.getObjectIdentifier() );
        claimTypeObjectCreateRequestDto.setValueInputMode( arg0.getValueInputMode() );

        return claimTypeObjectCreateRequestDto;
    }

    @Override
    public ClaimTypeObjectService.ClaimTypeObjectUpdateRequestDto mapUpdate(ClaimTypeObjectDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimTypeObjectService.ClaimTypeObjectUpdateRequestDto claimTypeObjectUpdateRequestDto = new ClaimTypeObjectService.ClaimTypeObjectUpdateRequestDto();

        claimTypeObjectUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimTypeObjectUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimTypeObjectUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimTypeObjectUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        claimTypeObjectUpdateRequestDto.setObjectNature( arg0.getObjectNature() );
        claimTypeObjectUpdateRequestDto.setObjectIdentifier( arg0.getObjectIdentifier() );
        claimTypeObjectUpdateRequestDto.setValueInputMode( arg0.getValueInputMode() );

        return claimTypeObjectUpdateRequestDto;
    }
}
