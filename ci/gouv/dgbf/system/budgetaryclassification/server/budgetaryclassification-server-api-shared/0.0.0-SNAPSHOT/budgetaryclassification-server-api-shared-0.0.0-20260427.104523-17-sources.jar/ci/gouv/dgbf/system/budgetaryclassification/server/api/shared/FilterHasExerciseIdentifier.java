package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant d'exercice.
 *
 * @author Christian
 */
public interface FilterHasExerciseIdentifier extends HasExerciseIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant exercice.
   *
   * @param filter {@link FilterDto}
   */
  default void updateExerciseIdentifier(FilterDto filter) {
    setExerciseIdentifier(ExerciseIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant exercice de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterExerciseIdentifier(FilterDto filter) {
    ExerciseIdentifierFilter.set(filter, getExerciseIdentifier());
  }

}
