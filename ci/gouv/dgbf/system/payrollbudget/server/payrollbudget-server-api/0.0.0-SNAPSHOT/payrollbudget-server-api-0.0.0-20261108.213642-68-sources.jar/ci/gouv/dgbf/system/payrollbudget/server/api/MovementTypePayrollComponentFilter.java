package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche du paramétrage.
 *
 * <p>Le type de mouvement est le critère courant : « quels postes ce mouvement touche-t-il ? »
 * est la question que l'écran pose à chaque ouverture. Le poste sert la question inverse, moins
 * fréquente mais nécessaire avant de retirer un poste du référentiel.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementTypePayrollComponentFilter extends AbstractIdentifiableFilter {

  /**
   * Type de mouvement dont on veut les postes de paie.
   */
  String movementTypeIdentifier;

  /**
   * Poste de paie dont on veut les types de mouvement.
   */
  String payrollComponentIdentifier;

  public MovementTypePayrollComponentFilter() {
    super();
  }

  public MovementTypePayrollComponentFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setMovementTypeIdentifier(
        read(filter, MovementTypePayrollComponentDto.JSON_MOVEMENT_TYPE_IDENTIFIER));
    setPayrollComponentIdentifier(
        read(filter, MovementTypePayrollComponentDto.JSON_PAYROLL_COMPONENT_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, MovementTypePayrollComponentDto.JSON_MOVEMENT_TYPE_IDENTIFIER,
        getMovementTypeIdentifier());
    write(filter, MovementTypePayrollComponentDto.JSON_PAYROLL_COMPONENT_IDENTIFIER,
        getPayrollComponentIdentifier());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
