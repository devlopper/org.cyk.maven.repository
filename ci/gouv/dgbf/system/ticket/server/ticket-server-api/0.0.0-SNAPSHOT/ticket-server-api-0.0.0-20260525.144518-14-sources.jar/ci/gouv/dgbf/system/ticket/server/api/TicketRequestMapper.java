package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketTakeInChargeRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TicketDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TicketDto}.

    @author Arnaud
               """)
public interface TicketRequestMapper
    extends RequestMapper<TicketDto, TicketCreateRequestDto,
     TicketUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link TicketTakeInChargeRequestDto}.
   *
   * @param ticket {@link TicketDto}
   * @return {@link TicketTakeInChargeRequestDto}
   */
  TicketTakeInChargeRequestDto mapTakeInChargeRequest(TicketDto ticket);
  
}
