package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionUpdateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionVerifyRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueConditionService.ValueConditionVerifyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ValueConditionService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ValueConditionClient extends AbstractClient<ValueConditionService>
    implements GetByIdentifier<ValueConditionDto>, GetMany<ValueConditionGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ValueConditionClient service(ValueConditionService service) {
    return (ValueConditionClient) super.service(service);
  }

  /**
   * {@link ValueConditionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ValueConditionCreateRequestDto request) {
    return new CreateExecutor(ValueConditionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ValueConditionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueConditionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ValueConditionGetManyResponseDto>(
        ValueConditionGetManyResponseDto.class, ValueConditionService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ValueConditionService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueConditionGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ValueConditionService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueConditionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ValueConditionDto>(ValueConditionDto.class,
        ValueConditionService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ValueConditionService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ValueConditionDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ValueConditionService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ValueConditionDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueConditionDto>(ValueConditionDto.class,
        ValueConditionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ValueConditionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueConditionDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ValueConditionService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ValueConditionUpdateRequestDto request) {
    return new IdentifiableExecutor(ValueConditionService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ValueConditionService#verify}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueConditionVerifyResponseDto verify(ValueConditionVerifyRequestDto request) {
    return new GetOneExecutor<ValueConditionVerifyResponseDto>(
        ValueConditionVerifyResponseDto.class, ValueConditionService.VERIFY_IDENTIFIER)
            .execute(() -> service().verify(request));
  }

  /**
   * {@link ValueConditionService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ValueConditionService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ValueConditionService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
