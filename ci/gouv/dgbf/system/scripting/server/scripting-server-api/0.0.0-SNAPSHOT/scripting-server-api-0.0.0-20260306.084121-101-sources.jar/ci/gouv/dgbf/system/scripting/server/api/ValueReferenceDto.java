package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFilterColumnNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasProjectionColumnNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasTableNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une référence de valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueReferenceDto extends AbstractIdentifiableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasTableNameDto,
    HasProjectionColumnNameDto, HasFilterColumnNameDto, HasValueTypeDto, HasValueTypeAsStringDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;
  
  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;
  
  @JsonbProperty(JSON_TABLE_NAME)
  private String tableName;

  @JsonbProperty(JSON_PROJECTION_COLUMN_NAME)
  private String projectionColumnName;

  @JsonbProperty(JSON_FILTER_COLUMN_NAME)
  private String filterColumnName;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReferenceValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "referenceValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "référence de valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "références de valeur";
}
