package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ResourceVisibilityLevelListPage extends AbstractPage {

  @Inject
  @Getter
  ResourceVisibilityLevelController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ResourceVisibilityLevelDto.PLURAL_NAME;
    controller.initialize();
  }

  /**
   * Cette constante est le cas de navigation.
   */
  public static final String OUTCOME = "resourceVisibilityLevelListPage";
}
