package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcessingEntityDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ProcessingEntityDto}.

    @author akm
               """)
public interface ProcessingEntityRequestMapper extends
    RequestMapper<ProcessingEntityDto, ProcessingEntityCreateRequestDto,
        ProcessingEntityUpdateRequestDto> {

}
