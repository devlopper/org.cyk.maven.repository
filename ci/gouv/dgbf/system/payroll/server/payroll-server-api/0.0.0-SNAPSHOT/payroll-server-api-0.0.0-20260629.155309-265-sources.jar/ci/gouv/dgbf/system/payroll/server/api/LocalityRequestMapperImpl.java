package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link LocalityDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class LocalityRequestMapperImpl implements LocalityRequestMapper {

    @Override
    public LocalityService.LocalityCreateRequestDto mapCreate(LocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LocalityService.LocalityCreateRequestDto localityCreateRequestDto = new LocalityService.LocalityCreateRequestDto();

        localityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        localityCreateRequestDto.setCode( arg0.getCode() );
        localityCreateRequestDto.setName( arg0.getName() );

        return localityCreateRequestDto;
    }

    @Override
    public LocalityService.LocalityUpdateRequestDto mapUpdate(LocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LocalityService.LocalityUpdateRequestDto localityUpdateRequestDto = new LocalityService.LocalityUpdateRequestDto();

        localityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        localityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        localityUpdateRequestDto.setCode( arg0.getCode() );
        localityUpdateRequestDto.setName( arg0.getName() );

        return localityUpdateRequestDto;
    }
}
