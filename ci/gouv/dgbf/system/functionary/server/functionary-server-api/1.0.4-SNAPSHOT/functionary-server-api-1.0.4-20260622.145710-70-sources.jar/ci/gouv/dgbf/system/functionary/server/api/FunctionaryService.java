package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ExistenceVerificationRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette inteface représente les services de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Path(FunctionaryService.PATH)
@Tag(name = "Gestion des fonctionnaires")
public interface FunctionaryService extends SpecificService {

  /**
   * Chemin du service de gestion des fonctionnaires.
   */
  String PATH = "fonctionnaires";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FONCTIONNAIRE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Christian
   *
   */
  interface FunctionarySaveRequestDto {
    /**
     * Cette méthode permet d'obtenir le numéro matricule.
     *
     * @return numéro matricule
     */
    String getRegistrationNumber();

    /**
     * Cette méthode permet d'assigner le numéro matricule.
     *
     * @param registrationNumber numéro matricule
     */
    void setRegistrationNumber(String registrationNumber);

    /**
     * Cette méthode permet d'obtenir le nom.
     *
     * @return nom
     */
    String getFirstName();

    /**
     * Cette méthode permet d'assigner le nom.
     *
     * @param firstName nom
     */
    void setFirstName(String firstName);

    /**
     * Cette méthode permet d'obtenir les prénoms.
     *
     * @return prénoms
     */
    String getLastNames();

    /**
     * Cette méthode permet d'assigner les prénoms.
     *
     * @param lastNames prénoms
     */
    void setLastNames(String lastNames);

    /**
     * Cette méthode permet d'obtenir l'adresse email.
     *
     * @return adresse email
     */
    String getEmailAddress();

    /**
     * Cette méthode permet d'assigner l'adresse email.
     *
     * @param emailAddress adresse email
     */
    void setEmailAddress(String emailAddress);

    /**
     * Cette méthode permet d'obtenir l'identifiant du genre.
     *
     * @return identifiant du genre
     */
    String getGenderIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du genre.
     *
     * @param genderIdentifier identifiant du genre
     */
    void setGenderIdentifier(String genderIdentifier);

    /**
     * Cette méthode permet d'obtenir la masculinité.
     *
     * @return masculinité
     */
    Boolean getIsGenderMasculine();

    /**
     * Cette méthode permet d'assigner la masculinité.
     *
     * @param isGenderMasculine masculinité
     */
    void setIsGenderMasculine(Boolean isGenderMasculine);

    /**
     * Cette méthode permet d'obtenir la date de naissance.
     *
     * @return date de naissance
     */
    LocalDate getBirthDate();

    /**
     * Cette méthode permet d'assigner la date de naissance.
     *
     * @param birthDate date de naissance
     */
    void setBirthDate(LocalDate birthDate);

    /**
     * Cette méthode permet d'obtenir la date de prise de service.
     *
     * @return date de prise de service
     */
    LocalDate getFirstServiceStartDate();

    /**
     * Cette méthode permet d'assigner la date de prise de service.
     *
     * @param firstServiceStartDate date de prise de service
     */
    void setFirstServiceStartDate(LocalDate firstServiceStartDate);

    /**
     * {@link FunctionaryDto#JSON_FIRST_NAME}.
     */
    String JSON_FIRST_NAME = FunctionaryDto.JSON_FIRST_NAME;

    /**
     * {@link FunctionaryDto#JSON_LAST_NAMES}.
     */
    String JSON_LAST_NAMES = FunctionaryDto.JSON_LAST_NAMES;

    /**
     * {@link FunctionaryDto#JSON_EMAIL_ADDRESS}.
     */
    String JSON_EMAIL_ADDRESS = FunctionaryDto.JSON_EMAIL_ADDRESS;

    /**
     * {@link FunctionaryDto#JSON_GENDER_IDENTIFIER}.
     */
    String JSON_GENDER_IDENTIFIER = FunctionaryDto.JSON_GENDER_IDENTIFIER;

    /**
     * {@link FunctionaryDto#JSON_IS_GENDER_MASCULINE}.
     */
    String JSON_IS_GENDER_MASCULINE = FunctionaryDto.JSON_IS_GENDER_MASCULINE;

    /**
     * {@link FunctionaryDto#JSON_BIRTH_DATE}.
     */
    String JSON_BIRTH_DATE = FunctionaryDto.JSON_BIRTH_DATE;

    /**
     * {@link FunctionaryDto#JSON_FIRST_SERVICE_START_DATE}.
     */
    String JSON_FIRST_SERVICE_START_DATE = FunctionaryDto.JSON_FIRST_SERVICE_START_DATE;

    /**
     * {@link FunctionaryDto#JSON_REGISTRATION_NUMBER}.
     */
    String JSON_REGISTRATION_NUMBER = FunctionaryDto.JSON_REGISTRATION_NUMBER;
  }

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_FONCTIONNAIRE";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le nombre de {@link FunctionaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Cette méthode permet de créer un fonctionnaire.
   *
   * @param request la requête de création de fonctionnaire
   * @return la réponse de création de fonctionnaire
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FunctionaryCreateRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FunctionaryCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements FunctionarySaveRequestDto {

    @JsonbProperty(value = JSON_FIRST_NAME)
    private String firstName;

    @JsonbProperty(value = JSON_LAST_NAMES)
    private String lastNames;

    @JsonbProperty(value = JSON_EMAIL_ADDRESS)
    private String emailAddress;

    @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
    private String genderIdentifier;

    @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
    private Boolean isGenderMasculine;

    @JsonbProperty(value = JSON_BIRTH_DATE)
    private LocalDate birthDate;

    @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE)
    private LocalDate firstServiceStartDate;

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FONCTIONNAIRE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir des fonctionnaires.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FunctionaryGetManyResponseDto
      extends AbstractGetByPageResponseDto<FunctionaryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FunctionaryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FONCTIONNAIRE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un fonctionnaire.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service de vérification d'existence.
   */
  String VERIFY_EXISTENCE_IDENTIFIER = "VERIFICATION_EXISTENCE_FONCTIONNAIRE";

  /**
   * Chemin du service de vérification d'existence.
   */
  String VERIFY_EXISTENCE_PATH = "verification-existence";

  /**
   * Cette méthode permet de vérifier l'existence.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VERIFY_EXISTENCE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = VERIFY_EXISTENCE_IDENTIFIER)
  Response verifyExistence(ExistenceVerificationRequestDto request);

  /**
   * Identifiant du service de vérification d'existence stricte.
   */
  String VERIFY_EXISTENCE_STRICT_IDENTIFIER = "VERIFICATION_EXISTENCE_STRICTE_FONCTIONNAIRE";

  /**
   * Chemin du service de vérification d'existence stricte.
   */
  String VERIFY_EXISTENCE_STRICT_PATH = "verification-existence-stricte";

  /**
   * Cette méthode permet de vérifier strictement l'existence.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VERIFY_EXISTENCE_STRICT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = VERIFY_EXISTENCE_STRICT_IDENTIFIER)
  Response verifyExistenceStrict(FunctionaryStrictExistenceVerificationRequestDto request);

  /**
   * Cette classe représente la requête vérification d'existence stricte.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class FunctionaryStrictExistenceVerificationRequestDto
      extends AbstractAuditedRequestJsonDto {
    /**
     * Matricule.
     */
    @NotNull
    @JsonbProperty(JSON_REGISTRATION_NUMBER)
    String registrationNumber;

    /**
     * Date de naissance.
     */
    @NotNull
    @JsonbProperty(JSON_BIRTH_DATE)
    LocalDate birthDate;

    /**
     * Nom et prénoms.
     */
    @NotNull
    @JsonbProperty(JSON_FIRST_NAME_AND_LAST_NAMES)
    String firstNameAndLastNames;

    /**
     * Date de première prise de service.
     */
    @NotNull
    @JsonbProperty(JSON_FIRST_SERVICE_START_DATE)
    LocalDate firstServiceStartDate;

    /**
     * Identifiant json {@link #registrationNumber}.
     */
    public static final String JSON_REGISTRATION_NUMBER = FunctionaryDto.JSON_REGISTRATION_NUMBER;

    /**
     * Identifiant json {@link #birthDate}.
     */
    public static final String JSON_BIRTH_DATE = FunctionaryDto.JSON_BIRTH_DATE;

    /**
     * Identifiant json {@link #firstNameAndLastNames}.
     */
    public static final String JSON_FIRST_NAME_AND_LAST_NAMES =
        FunctionaryDto.JSON_FIRST_NAME_AND_LAST_NAMES;

    /**
     * Identifiant json {@link #firstServiceStartDate}.
     */
    public static final String JSON_FIRST_SERVICE_START_DATE =
        FunctionaryDto.JSON_FIRST_SERVICE_START_DATE;
  }

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FONCTIONNAIRE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FunctionaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FunctionaryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FONCTIONNAIRE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FunctionaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FunctionaryUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FunctionaryUpdateRequestDto extends ByIdentifierRequestDto
      implements FunctionarySaveRequestDto {

    @JsonbProperty(value = JSON_FIRST_NAME)
    private String firstName;

    @JsonbProperty(value = JSON_LAST_NAMES)
    private String lastNames;

    @JsonbProperty(value = JSON_EMAIL_ADDRESS)
    private String emailAddress;

    @JsonbProperty(value = JSON_GENDER_IDENTIFIER)
    private String genderIdentifier;

    @JsonbProperty(value = JSON_IS_GENDER_MASCULINE)
    private Boolean isGenderMasculine;

    @JsonbProperty(value = JSON_BIRTH_DATE)
    private LocalDate birthDate;

    @JsonbProperty(value = JSON_FIRST_SERVICE_START_DATE)
    private LocalDate firstServiceStartDate;

    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FONCTIONNAIRE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FunctionaryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'importation de fonctionnaire par matricule.
   */
  String IMPORT_BY_REGISTRATION_NUMBER_IDENTIFIER = "IMPORTATION_FONCTIONNAIRE_PAR_MATRICULE";

  /**
   * Chemin du service d'imporation de fonctionnaire par matricule.
   */
  String IMPORT_BY_REGISTRATION_NUMBER_PATH = "importation/par-matricule";

  /**
   * Cette méthode permet d'importer un fonctionnaire par matricule.
   *
   * @param request requête
   * @return réponse
   */
  @Path(IMPORT_BY_REGISTRATION_NUMBER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = IMPORT_BY_REGISTRATION_NUMBER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response importByRegistrationNumber(FunctionaryImportByRegistrationNumberRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête d'obtention de
   * fonctionnaire par matricule.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FunctionaryImportByRegistrationNumberRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * {@link FunctionaryDto#getRegistrationNumber()}.
     */
    @NotNull
    @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
    private String registrationNumber;

    /**
     * {@link FunctionaryDto#JSON_REGISTRATION_NUMBER}.
     */
    public static final String JSON_REGISTRATION_NUMBER = FunctionaryDto.JSON_REGISTRATION_NUMBER;
  }

  /**
   * Identifiant du service d'importation de tout.
   */
  String IMPORT_ALL_IDENTIFIER = "IMPORTATION_TOUT_FONCTIONNAIRE";

  /**
   * Chemin du service d'imporation de tout.
   */
  String IMPORT_ALL_PATH = "importation-tout";

  /**
   * Cette méthode permet d'importer tout.
   *
   * @param request requête
   * @return réponse
   */
  @Path(IMPORT_ALL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = IMPORT_ALL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = CreateManyResponseDto.class))})
  Response importAll(FunctionaryImportAllRequestDto request);

  /**
   * Cette classe représente la requête d'importation de tout.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FunctionaryImportAllRequestDto extends AbstractAuditedRequestJsonDto {
  }
}
