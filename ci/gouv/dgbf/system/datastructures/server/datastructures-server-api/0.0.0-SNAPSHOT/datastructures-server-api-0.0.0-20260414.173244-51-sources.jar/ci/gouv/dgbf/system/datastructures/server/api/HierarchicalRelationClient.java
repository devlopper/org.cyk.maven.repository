package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchicalRelationService.HierarchicalRelationCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchicalRelationService.HierarchicalRelationGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.HierarchicalRelationService.HierarchicalRelationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link HierarchicalRelationService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class HierarchicalRelationClient extends AbstractClient<HierarchicalRelationService>
    implements GetByIdentifier<HierarchicalRelationDto>,
    GetMany<HierarchicalRelationGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public HierarchicalRelationClient service(HierarchicalRelationService service) {
    return (HierarchicalRelationClient) super.service(service);
  }

  /**
   * {@link HierarchicalRelationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(HierarchicalRelationCreateRequestDto request) {
    return new CreateExecutor(HierarchicalRelationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link HierarchicalRelationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public HierarchicalRelationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<HierarchicalRelationGetManyResponseDto>(
        HierarchicalRelationGetManyResponseDto.class,
        HierarchicalRelationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link HierarchicalRelationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public HierarchicalRelationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link HierarchicalRelationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public HierarchicalRelationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<HierarchicalRelationDto>(HierarchicalRelationDto.class,
        HierarchicalRelationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link HierarchicalRelationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public HierarchicalRelationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link HierarchicalRelationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public HierarchicalRelationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<HierarchicalRelationDto>(HierarchicalRelationDto.class,
        HierarchicalRelationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link HierarchicalRelationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public HierarchicalRelationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link HierarchicalRelationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(HierarchicalRelationUpdateRequestDto request) {
    return new IdentifiableExecutor(HierarchicalRelationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link HierarchicalRelationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(HierarchicalRelationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link HierarchicalRelationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
