package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de filtre de {@link ResourceDto} et {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractResourceOrReceiverFilter extends AbstractIdentifiableFilter {

  private String reference;
  private Location location;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  protected AbstractResourceOrReceiverFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  protected AbstractResourceOrReceiverFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    reference = getReference(filter);
    location = getLocation(filter);
  }
  
  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setReference(filter, reference);
    setLocation(filter, location);
  }

  /**
   * Cette méthode permet d'assigner la référence.
   *
   * @param filter filtre
   * @param reference référence
   */
  public static void setReference(FilterDto filter, String reference) {
    set(filter, JSON_REFERENCE, f -> f.getValueAsString(), f -> f.setValueAsString(reference));
  }

  /**
   * Cette méthode permet d'obtenir la référence.
   *
   * @param filter filtre
   * @return référence
   */
  public static String getReference(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REFERENCE));
  }

  /**
   * Cette méthode permet d'assigner la {@link Location}.
   *
   * @param filter filtre
   * @param type {@link Location}
   */
  public static void setLocation(FilterDto filter, Location type) {
    set(filter, JSON_LOCATION, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link Location}.
   *
   * @param filter filtre
   * @return {@link Location}
   */
  public static Location getLocation(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_LOCATION, Location.class));
  }

  /**
   * Identifiant json champ {@link #reference}.
   */
  public static final String JSON_REFERENCE = AbstractResourceOrReceiverDto.JSON_REFERENCE;

  /**
   * Identifiant json champ type.
   */
  public static final String JSON_TYPE = AbstractResourceOrReceiverDto.JSON_TYPE;

  /**
   * Identifiant json champ {@link #location}.
   */
  public static final String JSON_LOCATION = AbstractResourceOrReceiverDto.JSON_LOCATION;
}
