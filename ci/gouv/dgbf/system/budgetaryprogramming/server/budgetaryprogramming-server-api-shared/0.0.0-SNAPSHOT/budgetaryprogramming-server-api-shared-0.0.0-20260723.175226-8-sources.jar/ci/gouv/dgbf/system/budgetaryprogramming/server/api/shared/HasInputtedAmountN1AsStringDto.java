package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant saisi pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountN1AsStringDto extends HasInputtedAmountN1AsString {

  /**
   * Identifiant json du montant saisi pour l'année N+1.
   */
  String JSON_INPUTTED_AMOUNT_N1_AS_STRING = "montantSaisiN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName