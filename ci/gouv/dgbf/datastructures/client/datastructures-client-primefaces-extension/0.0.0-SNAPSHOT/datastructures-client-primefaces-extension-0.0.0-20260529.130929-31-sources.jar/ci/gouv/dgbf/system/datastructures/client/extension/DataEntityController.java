package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasCreationScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasDeletionScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasExistenceVerificationScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceGroupsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.HasListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityClient;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityService.DataEntityUpdateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityType;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DataEntityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DataEntityController extends AbstractController implements HasListController {

  @Inject
  DataEntityClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  DataEntityRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  DataEntityTypeSelectOneController typeSelectOneController;

  @Inject
  @Getter
  InputTextController addressInputTextController;

  @Inject
  @Getter
  InputTextController creationScriptInputTextController;

  @Inject
  @Getter
  InputTextController deletionScriptInputTextController;

  @Inject
  @Getter
  InputTextController existenceVerificationScriptInputTextController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DataEntityDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(DataEntityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DataEntityService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
            HasCodeDto.JSON_CODE, HasNameDto.JSON_NAME, HasTypeAsStringDto.JSON_TYPE_AS_STRING,
            HasAddressDto.JSON_ADDRESS, HasValuesCountAsStringDto.JSON_VALUES_COUNT_AS_STRING,
            HasValueSourceGroupsCountAsStringDto.JSON_VALUE_SOURCE_GROUPS_COUNT_AS_STRING));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      DataEntityCreateRequestDto request = requestMapper.mapCreate((DataEntityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER,
            HasCodeDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
            DataEntityDto.JSON_TYPE, HasAddressDto.JSON_ADDRESS,
            HasCreationScriptDto.JSON_CREATION_SCRIPT, HasDeletionScriptDto.JSON_DELETION_SCRIPT,
            HasExistenceVerificationScriptDto.JSON_EXISTENCE_VERIFICATION_SCRIPT));
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    typeSelectOneController.getSelectOneMenu().addValueConsumer(typeConsumer());

    addressInputTextController.setOutputLableValue("Adresse");
    addressInputTextController.getInputText().addValueConsumer(addressConsumer());

    creationScriptInputTextController.setOutputLableValue("Script de création");
    creationScriptInputTextController.getInputTextarea().addValueConsumer(creationScriptConsumer());

    deletionScriptInputTextController.setOutputLableValue("Script de suppression");
    deletionScriptInputTextController.getInputTextarea().addValueConsumer(deletionScriptConsumer());

    existenceVerificationScriptInputTextController
        .setOutputLableValue("Script de vérification d'existence");
    existenceVerificationScriptInputTextController.getInputTextarea()
        .addValueConsumer(existenceVerificationScriptConsumer());
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setName(name);
  }

  Consumer<String> typeConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setType(Core.getEnumerationValueByName(DataEntityType.class, name));
  }

  Consumer<String> addressConsumer() {
    return script -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setCreationScript(script);
  }

  Consumer<String> creationScriptConsumer() {
    return script -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setCreationScript(script);
  }

  Consumer<String> deletionScriptConsumer() {
    return script -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setDeletionScript(script);
  }

  Consumer<String> existenceVerificationScriptConsumer() {
    return script -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DataEntityDto.class)
        .setExistenceVerificationScript(script);
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      codeInputTextController.getInputText().writeValue(((DataEntityDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((DataEntityDto) entity).getName());
      typeSelectOneController.getSelectOneMenu()
          .writeValue(((DataEntityDto) entity).getType().name());
      addressInputTextController.getInputText()
          .writeValue(((DataEntityDto) entity).getAddress());
      creationScriptInputTextController.getInputTextarea()
          .writeValue(((DataEntityDto) entity).getCreationScript());
      deletionScriptInputTextController.getInputTextarea()
          .writeValue(((DataEntityDto) entity).getDeletionScript());
      existenceVerificationScriptInputTextController.getInputTextarea()
          .writeValue(((DataEntityDto) entity).getExistenceVerificationScript());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      DataEntityUpdateRequestDto request = requestMapper.mapUpdate((DataEntityDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            typeSelectOneController.getSelectOneMenu(), addressInputTextController.getInputText(),
            creationScriptInputTextController.getInputTextarea(),
            deletionScriptInputTextController.getInputTextarea(),
            existenceVerificationScriptInputTextController.getInputTextarea())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
