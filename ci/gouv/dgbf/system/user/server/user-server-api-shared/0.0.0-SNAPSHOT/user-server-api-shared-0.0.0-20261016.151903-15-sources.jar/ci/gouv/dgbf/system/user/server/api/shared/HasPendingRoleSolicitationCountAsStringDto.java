package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de demandes de rôle en attente
 * sous forme de chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasPendingRoleSolicitationCountAsStringDto
    extends HasPendingRoleSolicitationCountAsString {

  /**
   * Identifiant json du nombre de demandes de rôle en attente sous forme de chaîne.
   */
  String JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING = "nombreDemandesRoleEnAttenteChaine";
}
