package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a filtre par identifiant d'intervalle.
 *
 * @author Christian
 */
public interface FilterHasIntervalIdentifier extends HasIntervalIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'intervalle.
   *
   * @param filter {@link FilterDto}
   */
  default void updateIntervalIdentifier(FilterDto filter) {
    setIntervalIdentifier(IntervalIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de l'intervalle de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterIntervalIdentifier(FilterDto filter) {
    IntervalIdentifierFilter.set(filter, getIntervalIdentifier());
  }

}
