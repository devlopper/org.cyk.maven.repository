package ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubAdministrativeUnitClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubAdministrativeUnitDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubAdministrativeUnitService.SubAdministrativeUnitGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SubAdministrativeUnitDto}.
 *
 * @author stephane
 *
 */
@Dependent
public class SubAdministrativeUnitSelectOneController
    extends AbstractSelectOneIdentifiableController<SubAdministrativeUnitDto,
        SubAdministrativeUnitGetManyResponseDto, SubAdministrativeUnitClient> {

  @Inject
  @Getter
  SubAdministrativeUnitClient client;

  protected SubAdministrativeUnitSelectOneController() {
    super(SubAdministrativeUnitDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
