package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.sharing.server.api.ResourceService.ResourceGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ResourceService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ResourceClient extends AbstractClient<ResourceService> implements
    GetByIdentifier<ResourceDto>, GetMany<ResourceGetManyResponseDto>, OneRetrievable<ResourceDto> {

  @Override
  public ResourceClient service(ResourceService service) {
    return (ResourceClient) super.service(service);
  }

  /**
   * {@link ResourceService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ResourceGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ResourceGetManyResponseDto>(ResourceGetManyResponseDto.class,
        ResourceService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ResourceService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ResourceGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ResourceService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ResourceDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ResourceDto>(ResourceDto.class, ResourceService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ResourceService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ResourceDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Cette méthode permet d'obtenir une ressource avec son niveau de visibilité effectif pour un
   * utilisateur (RG_SHA_14).
   *
   * @param type {@link ResourceType}
   * @param location {@link Location}
   * @param reference référence dans le système source
   * @param userName nom d'utilisateur pour lequel calculer le niveau
   * @param userDomainCode code du domaine de l'utilisateur (realm Keycloak)
   * @param auditWho audit acteur
   * @return ressource dont {@link ResourceDto#getEffectiveVisibilityLevel()} est renseigné
   */
  public ResourceDto getWithEffectiveVisibilityLevel(ResourceType type, Location location,
      String reference, String userName, String userDomainCode, String auditWho) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractResourceOrReceiverDto.JSON_REFERENCE, AbstractResourceOrReceiverDto.JSON_TYPE,
        AbstractResourceOrReceiverDto.JSON_LOCATION, ResourceDto.JSON_EFFECTIVE_VISIBILITY_LEVEL);
    ResourceFilter filter = new ResourceFilter();
    filter.setType(type);
    filter.setLocation(location);
    filter.setReference(reference);
    filter.setVisibilityLevelUserName(userName);
    filter.setVisibilityLevelUserDomainCode(userDomainCode);
    request.setFilter(filter.toDto());
    request.setAuditWho(auditWho);
    return getOne(request);
  }

  /**
   * Cette méthode permet d'obtenir les ressources à visibilité réduite
   * ({@link VisibilityLevel#SUMMARY} ou {@link VisibilityLevel#NONE}) pour un utilisateur. Toute
   * ressource absente de la réponse est {@link VisibilityLevel#FULL}.
   *
   * @param userName nom d'utilisateur pour lequel calculer le niveau
   * @param userDomainCode code du domaine de l'utilisateur (realm Keycloak)
   * @param type {@link ResourceType} (facultatif)
   * @param auditWho audit acteur
   * @return ressources à visibilité réduite
   */
  public ResourceGetManyResponseDto getReducedVisibilityByUserName(String userName,
      String userDomainCode, ResourceType type, String auditWho) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractResourceOrReceiverDto.JSON_REFERENCE, AbstractResourceOrReceiverDto.JSON_TYPE,
        AbstractResourceOrReceiverDto.JSON_LOCATION, ResourceDto.JSON_EFFECTIVE_VISIBILITY_LEVEL);
    ResourceFilter filter = new ResourceFilter();
    filter.setType(type);
    filter.setVisibilityLevelUserName(userName);
    filter.setVisibilityLevelUserDomainCode(userDomainCode);
    filter.setVisibilityLevelCodes(
        new LinkedHashSet<>(Set.of(VisibilityLevelCode.SUMMARY, VisibilityLevelCode.NONE)));
    request.setFilter(filter.toDto());
    request.setAuditWho(auditWho);
    return getMany(request);
  }

  /**
   * {@link ResourceService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ResourceDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ResourceDto>(ResourceDto.class,
        ResourceService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ResourceService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ResourceDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
