package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitService.BudgetAdministrativeUnitCalculateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitService.BudgetAdministrativeUnitGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link BudgetAdministrativeUnitService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class BudgetAdministrativeUnitClient extends AbstractClient<BudgetAdministrativeUnitService>
    implements OneRetrievable<BudgetAdministrativeUnitDto>,
    GetByIdentifier<BudgetAdministrativeUnitDto>,
    GetMany<BudgetAdministrativeUnitGetManyResponseDto> {

  @Override
  public BudgetAdministrativeUnitClient service(BudgetAdministrativeUnitService service) {
    return (BudgetAdministrativeUnitClient) super.service(service);
  }

  /**
   * {@link BudgetAdministrativeUnitService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetAdministrativeUnitGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitGetManyResponseDto>(
        BudgetAdministrativeUnitGetManyResponseDto.class,
        BudgetAdministrativeUnitService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link BudgetAdministrativeUnitService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetAdministrativeUnitGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BudgetAdministrativeUnitService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetAdministrativeUnitDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitDto>(BudgetAdministrativeUnitDto.class,
        BudgetAdministrativeUnitService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link BudgetAdministrativeUnitService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetAdministrativeUnitDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BudgetAdministrativeUnitService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public BudgetAdministrativeUnitDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetAdministrativeUnitDto>(BudgetAdministrativeUnitDto.class,
        BudgetAdministrativeUnitService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BudgetAdministrativeUnitService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetAdministrativeUnitDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  } 

  /**
   * {@link BudgetAdministrativeUnitService#calculate}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto calculate(
      BudgetAdministrativeUnitCalculateRequestDto request) {
    return new IdentifiableExecutor(
        BudgetAdministrativeUnitService.CALCULATE_IDENTIFIER)
            .execute(() -> service().calculate(request));
  }
}
