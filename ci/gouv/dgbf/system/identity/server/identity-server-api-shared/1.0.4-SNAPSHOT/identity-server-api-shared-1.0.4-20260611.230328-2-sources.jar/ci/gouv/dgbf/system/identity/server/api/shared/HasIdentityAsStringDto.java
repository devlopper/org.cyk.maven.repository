package ci.gouv.dgbf.system.identity.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'identité.
 *
 * @author Christian
 */
public interface HasIdentityAsStringDto extends HasIdentityAsString {

  /**
   * Identifiant json de représentation en chaine de caractères de l'identité.
   */
  String JSON_IDENTITY_AS_STRING = "identiteChaine";
}
