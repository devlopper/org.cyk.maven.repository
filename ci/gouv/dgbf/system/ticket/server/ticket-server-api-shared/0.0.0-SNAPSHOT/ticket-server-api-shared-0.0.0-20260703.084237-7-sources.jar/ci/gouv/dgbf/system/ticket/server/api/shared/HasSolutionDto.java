package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion de solution.
 *
 * @author Christian
 */
public interface HasSolutionDto extends HasSolution {
  
  /**
   * Identifiant json de la solution.
   */
  String JSON_SOLUTION = "solution";
}
