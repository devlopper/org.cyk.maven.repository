package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link MovementDto}.
 *
 * @author stephane
 *
 */
@Getter
public enum MovementStatus {
  /**
   * Projeté.
   */
  PROJECTED(MovementStatusCode.PROJECTED, "Projeté", "Projection"),

  /**
   * Activé.
   */
  ACTIVATED(MovementStatusCode.ACTIVATED, "Activé", "Activation"),

  /**
   * Proposé.
   */
  SUGGESTED(MovementStatusCode.SUGGESTED, "Proposé", "Proposition"),

  /**
   * Refusé.
   */
  REFUSED(MovementStatusCode.REFUSED, "Refusé", "Refus"),

  /**
   * Clôturé.
   */
  CLOSED(MovementStatusCode.CLOSED, "Clôturé", "Clôture")

  ;

  private MovementStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<MovementStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link MovementStatus} par code.
   *
   * @param code code
   * @return {@link MovementStatus}
   */
  public static MovementStatus getByCode(String code) {
    return Stream.of(MovementStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }

  static {
    PROJECTED.previous = Collections.emptySet();
    ACTIVATED.previous = Core.getSet(List.of(SUGGESTED));
    SUGGESTED.previous = Collections.emptySet();
    REFUSED.previous = Core.getSet(List.of(SUGGESTED));
    CLOSED.previous = Core.getSet(List.of(ACTIVATED));
  }
}
