package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.component.CommandUpdatePropertyValueBuilder;
import ci.gouv.dgbf.extension.primefaces.segregation.HasUpdate;
import jakarta.faces.event.AjaxBehaviorEvent;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un requête ajax.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Ajax implements HasUpdate {

  String event;
  Consumer<AjaxBehaviorEvent> consumer;
  String update;
  boolean disabled;

  public Ajax() {
    update = NONE;
    disabled = false;
  }

  public void listen(AjaxBehaviorEvent event) {
    consumer.accept(event);
  }

  /**
   * Cette méthode permet configurer.
   *
   * @param consumer {@link #consumer}
   * @param updatePropertyValueBuilder {@link CommandUpdatePropertyValueBuilder}
   */
  public void configure(Consumer<AjaxBehaviorEvent> consumer,
      CommandUpdatePropertyValueBuilder updatePropertyValueBuilder) {
    this.consumer = consumer;
    Core.runIfNotNull(updatePropertyValueBuilder, () -> {
      CommandUpdatePropertyValueBuilder builder = new CommandUpdatePropertyValueBuilder();
      String string = updatePropertyValueBuilder.build();
      if (!Core.isStringBlank(string)) {
        if (!NONE.equals(update)) {
          builder.strings().add(update);
        }
        builder.strings().add(string);
        update = builder.build();
      }
    });
    disabled = this.consumer == null;
  }

  /**
   * Cette méthode permet d'instantier {@link Builder}.
   *
   * @return {@link Builder}
   */
  public static Builder newBuilder() {
    return new Builder();
  }
  
  /**
   * Cette classe représente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {

    String event;
    Consumer<AjaxBehaviorEvent> consumer;
    CommandUpdatePropertyValueBuilder updatePropertyValueBuilder;
    boolean disabled;

    /**
     * Cette méthode permet de construire une instance.
     */
    public Builder() {
      updatePropertyValueBuilder = new CommandUpdatePropertyValueBuilder();
      updatePropertyValueBuilder.strings().add(NONE);
      disabled = false;
    }

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Ajax}
     */
    public Ajax build() {
      Ajax ajax = new Ajax();
      ajax.event = event;
      ajax.consumer = consumer;
      ajax.update =
          Optional.ofNullable(updatePropertyValueBuilder).map(i -> i.build()).orElse(null);
      ajax.disabled = disabled;
      return ajax;
    }
  }
  
  private static final String NONE = "@none";
}
