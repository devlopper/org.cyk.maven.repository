package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasFundingSourceAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasLessorAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une imputation de {@link ProgrammingDto}.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingImputationDto extends AbstractImputationAmountsContainerDto
    implements HasFundingSourceAsStringDto, HasLessorAsStringDto {

  // Funding source

  @JsonbProperty(JSON_FUNDING_SOURCE_AS_STRING)
  private String fundingSourceAsString;

  // Lessor

  @JsonbProperty(JSON_LESSOR_AS_STRING)
  private String lessorAsString;

  /**
   * Indique si l'imputation est une dépense.
   */
  @JsonbProperty(JSON_EXPENDITURE)
  private Boolean expenditure;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idImputationProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "imputationProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "imputation de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "imputations de programmation";

  /**
   * Identifiant json pour {@link #expenditure}.
   */
  public static final String JSON_EXPENDITURE = "estDepense";
}
