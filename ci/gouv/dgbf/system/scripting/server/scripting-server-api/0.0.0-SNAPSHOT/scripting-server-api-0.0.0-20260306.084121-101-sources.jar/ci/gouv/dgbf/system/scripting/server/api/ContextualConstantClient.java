package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantService.ContextualConstantCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantService.ContextualConstantGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantService.ContextualConstantUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ContextualConstantService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ContextualConstantClient extends AbstractClient<ContextualConstantService>
    implements GetByIdentifier<ContextualConstantDto>,
    GetMany<ContextualConstantGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ContextualConstantClient service(ContextualConstantService service) {
    return (ContextualConstantClient) super.service(service);
  }

  /**
   * {@link ContextualConstantService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ContextualConstantCreateRequestDto request) {
    return new CreateExecutor(ContextualConstantService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ContextualConstantService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ContextualConstantGetManyResponseDto>(
        ContextualConstantGetManyResponseDto.class, ContextualConstantService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ContextualConstantService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ContextualConstantService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ContextualConstantDto>(ContextualConstantDto.class,
        ContextualConstantService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ContextualConstantService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ContextualConstantDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ContextualConstantService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ContextualConstantDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ContextualConstantDto>(ContextualConstantDto.class,
        ContextualConstantService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ContextualConstantService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ContextualConstantService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ContextualConstantUpdateRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ContextualConstantService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ContextualConstantService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
