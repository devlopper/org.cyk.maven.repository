package ci.gouv.dgbf.system.sharing.server.api;

/**
 * Cette classe représente les codes de types de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
public class ReceiverTypeCode {

  private ReceiverTypeCode() {

  }

  /**
   * Utilisateur.
   */
  public static final String USER = "UTILISATEUR";
  /**
   * Groupe d'utilisateur.
   */
  public static final String USER_GROUP = "GROUPE_UTILISATEUR";
}
