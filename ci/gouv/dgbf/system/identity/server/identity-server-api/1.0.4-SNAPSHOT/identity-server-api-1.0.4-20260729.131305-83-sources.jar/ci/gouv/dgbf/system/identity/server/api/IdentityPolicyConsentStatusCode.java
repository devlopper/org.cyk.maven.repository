package ci.gouv.dgbf.system.identity.server.api;

/**
 * Cette classe représente les codes de {@link IdentityPolicyConsentStatus}.
 *
 * @author Desysoft
 *
 */
public class IdentityPolicyConsentStatusCode {

  private IdentityPolicyConsentStatusCode() {

  }

  /**
   * En attente.
   */
  public static final String PENDING = "EN_ATTENTE";

  /**
   * Accepté.
   */
  public static final String ACCEPTED = "ACCEPTE";

  /**
   * Refusé.
   */
  public static final String REFUSED = "REFUSE";

  /**
   * Révoqué.
   */
  public static final String REVOKED = "REVOQUE";
}
