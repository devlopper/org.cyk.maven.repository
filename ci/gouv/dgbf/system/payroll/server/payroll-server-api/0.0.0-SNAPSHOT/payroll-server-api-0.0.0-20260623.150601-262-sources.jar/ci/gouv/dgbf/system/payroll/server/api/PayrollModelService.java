package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollModelDto}.
 *
 * @author akm
 *
 */
@Path(value = PayrollModelService.PATH)
@Tag(name = "Gestion des modèles de paie")
public interface PayrollModelService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "modeles-paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface PayrollModelSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollJobGroupDto}.
     *
     * @return identifiant {@link PayrollJobGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollJobGroupDto}.
     *
     * @param identifier identifiant {@link PayrollJobGroupDto}
     */
    void setGroupIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollTypeDto}.
     *
     * @return identifiant {@link PayrollTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollTypeDto}.
     *
     * @param identifier identifiant {@link PayrollTypeDto}
     */
    void setTypeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayslipTemplateDto}.
     *
     * @return identifiant {@link PayslipTemplateDto}
     */
    String getPayslipTemplateIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayslipTemplateDto}.
     *
     * @param identifier identifiant {@link PayslipTemplateDto}
     */
    void setPayslipTemplateIdentifier(String identifier);

    /**
     * {@link PayrollModelDto#JSON_GROUP_IDENTIFIER}.
     */
    public static final String JSON_GROUP_IDENTIFIER =
        PayrollModelDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link PayrollModelDto#JSON_TYPE_IDENTIFIER}.
     */
    public static final String JSON_TYPE_IDENTIFIER =
        PayrollModelDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link PayrollModelDto#JSON_PAYSLIP_TEMPLATE_IDENTIFIER}.
     */
    public static final String JSON_PAYSLIP_TEMPLATE_IDENTIFIER =
        PayrollModelDto.JSON_PAYSLIP_TEMPLATE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MODELE_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollModelCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollModelCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayrollModelSaveRequestDto {
    /**
     * Identifiant de {@link PayrollJobGroupDto}.
     */
    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    String groupIdentifier;
    /**
     * Identifiant de {@link PayrollTypeDto}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    String typeIdentifier;
    /**
     * Identifiant de {@link PayslipTemplateDto}.
     */
    @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
    String payslipTemplateIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MODELE_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayrollModelGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollModelGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollModelDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollModelDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MODELE_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollModelDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MODELE_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollModelDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MODELE_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollModelUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollModelUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayrollModelSaveRequestDto {
    /**
     * Identifiant de {@link PayrollJobGroupDto}.
     */
    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    String groupIdentifier;
    /**
     * Identifiant de {@link PayrollTypeDto}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    String typeIdentifier;
    /**
     * Identifiant de {@link PayslipTemplateDto}.
     */
    @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
    String payslipTemplateIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MODELE_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
