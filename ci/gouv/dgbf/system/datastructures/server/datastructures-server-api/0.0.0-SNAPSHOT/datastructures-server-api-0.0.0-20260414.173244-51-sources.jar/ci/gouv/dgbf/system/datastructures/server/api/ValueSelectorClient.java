package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateManyRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorEvaluateResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorService.ValueSelectorUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;

/**
 * Cette classe représente un client de {@link ValueSelectorService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
public class ValueSelectorClient extends AbstractClient<ValueSelectorService>
    implements GetByIdentifier<ValueSelectorDto>, GetMany<ValueSelectorGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ValueSelectorClient service(ValueSelectorService service) {
    return (ValueSelectorClient) super.service(service);
  }

  /**
   * {@link ValueSelectorService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ValueSelectorCreateRequestDto request) {
    return new CreateExecutor(ValueSelectorService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ValueSelectorService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ValueSelectorGetManyResponseDto>(
        ValueSelectorGetManyResponseDto.class, ValueSelectorService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ValueSelectorService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSelectorGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ValueSelectorService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ValueSelectorDto>(ValueSelectorDto.class,
        ValueSelectorService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ValueSelectorService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ValueSelectorDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ValueSelectorService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ValueSelectorDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSelectorDto>(ValueSelectorDto.class,
        ValueSelectorService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ValueSelectorService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSelectorDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ValueSelectorService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ValueSelectorUpdateRequestDto request) {
    return new IdentifiableExecutor(ValueSelectorService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ValueSelectorService#evaluate}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorEvaluateResponseDto evaluate(ValueSelectorEvaluateRequestDto request) {
    return new GetOneExecutor<ValueSelectorEvaluateResponseDto>(
        ValueSelectorEvaluateResponseDto.class, ValueSelectorService.EVALUATE_IDENTIFIER)
            .execute(() -> service().evaluate(request));
  }

  /**
   * {@link ValueSelectorService#evaluateInternal}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorEvaluateResponseDto evaluateInternal(
      ValueSelectorEvaluateRequestDto request) {
    return new GetOneExecutor<ValueSelectorEvaluateResponseDto>(
        ValueSelectorEvaluateResponseDto.class, ValueSelectorService.EVALUATE_INTERNAL_IDENTIFIER)
            .execute(() -> service().evaluateInternal(request));
  }

  /**
   * {@link ValueSelectorService#evaluateMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorEvaluateManyResponseDto evaluateMany(
      ValueSelectorEvaluateManyRequestDto request) {
    return new GetOneExecutor<ValueSelectorEvaluateManyResponseDto>(
        ValueSelectorEvaluateManyResponseDto.class, ValueSelectorService.EVALUATE_MANY_IDENTIFIER)
            .execute(() -> service().evaluateMany(request));
  }

  /**
   * {@link ValueSelectorService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ValueSelectorService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ValueSelectorService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
