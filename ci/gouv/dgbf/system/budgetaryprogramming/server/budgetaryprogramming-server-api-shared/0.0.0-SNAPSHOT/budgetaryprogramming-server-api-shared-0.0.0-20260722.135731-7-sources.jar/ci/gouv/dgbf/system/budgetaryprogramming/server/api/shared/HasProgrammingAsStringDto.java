package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de programmation.
 *
 * @author Christian
 */
public interface HasProgrammingAsStringDto extends HasProgrammingAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la programmation.
   */
  String JSON_PROGRAMMING_AS_STRING = "programmationChaine";
}
