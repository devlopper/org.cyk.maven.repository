package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN1AsStringDto
    extends HasRemainingAmountToInputN1AsString {

  /**
   * Identifiant json du montant restant à saisir pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INPUT_N1_AS_STRING =
      "montantResteASaisirN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName