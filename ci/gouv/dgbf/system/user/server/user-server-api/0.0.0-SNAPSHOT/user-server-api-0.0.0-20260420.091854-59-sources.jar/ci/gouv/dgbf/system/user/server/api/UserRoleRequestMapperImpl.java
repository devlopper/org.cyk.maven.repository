package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UserRoleDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-20T09:19:16+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UserRoleRequestMapperImpl implements UserRoleRequestMapper {

    @Override
    public UserRoleService.UserRoleCreateRequestDto mapCreate(UserRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserRoleService.UserRoleCreateRequestDto userRoleCreateRequestDto = new UserRoleService.UserRoleCreateRequestDto();

        userRoleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        userRoleCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        userRoleCreateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        userRoleCreateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return userRoleCreateRequestDto;
    }

    @Override
    public UserRoleService.UserRoleUpdateRequestDto mapUpdate(UserRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserRoleService.UserRoleUpdateRequestDto userRoleUpdateRequestDto = new UserRoleService.UserRoleUpdateRequestDto();

        userRoleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        userRoleUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        userRoleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        userRoleUpdateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        userRoleUpdateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return userRoleUpdateRequestDto;
    }
}
