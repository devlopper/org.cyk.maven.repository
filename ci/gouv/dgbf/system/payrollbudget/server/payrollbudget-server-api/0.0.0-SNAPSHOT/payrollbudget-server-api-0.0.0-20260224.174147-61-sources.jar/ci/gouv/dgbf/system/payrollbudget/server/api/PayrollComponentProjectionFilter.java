package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitEmployeeIdentifier;
import ci.gouv.dgbf.system.employee.server.api.shared.FilterHasEmployeePayrollComponentIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollComponentIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollPeriodGroupIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollComponentProjectionDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class PayrollComponentProjectionFilter extends AbstractIdentifiableFilter
    implements FilterHasPayrollComponentIdentifier, FilterHasPayrollPeriodGroupIdentifier,
    FilterHasAdministrativeUnitEmployeeIdentifier, FilterHasEmployeePayrollComponentIdentifier {

  /**
   * Identifiant {@link EmployeePayrollComponentDto}.
   */
  String employeePayrollComponentIdentifier;
  
  /**
   * Identifiant #{@link AdministrativeUnitEmployeeDto}.
   */
  String administrativeUnitEmployeeIdentifier;

  /**
   * Identifiant poste de paie.
   */
  String payrollComponentIdentifier;

  /**
   * Identifiant groupe de période de paie.
   */
  String payrollPeriodGroupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollComponentProjectionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollComponentProjectionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateEmployeePayrollComponentIdentifier(filter);
    updateAdministrativeUnitEmployeeIdentifier(filter);
    updatePayrollComponentIdentifier(filter);
    updatePayrollPeriodGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterEmployeePayrollComponentIdentifier(filter);
    updateFilterAdministrativeUnitEmployeeIdentifier(filter);
    updateFilterPayrollComponentIdentifier(filter);
    updateFilterPayrollPeriodGroupIdentifier(filter);
  }
}
