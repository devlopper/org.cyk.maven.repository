package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasFileCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupUpdateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FilesGroupController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FilesGroupRequestMapper requestMapper;

  @Inject
  @Getter
  SelectBooleanController isConfirmedSelectBooleanController;

  @Inject
  @Getter
  FilesGroupUploadController uploadController;

  /**
   * Contrôleur du bouton de Confirmation (RG_FILE_GRP_02, 03), affiché dans la colonne Action de
   * la liste, selon le mécanisme déjà établi pour ce type de bouton côté {@code FileController}
   * (TCH_FILE_541).
   */
  @Inject
  @Getter
  IdentifiableProcessingController confirmProcessingController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FilesGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FilesGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FilesGroupService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING,
        HasFileCountAsStringDto.JSON_FILE_COUNT_AS_STRING, HasDescriptionDto.JSON_DESCRIPTION);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().addEntityConsumer(entity -> {
      uploadController.reset();
      ((FilesGroupDto) entity).setIsConfirmed(Boolean.TRUE);
      isConfirmedSelectBooleanController.getSelectOneRadioBoolean().writeValue(Boolean.TRUE);
    });
    listController.getCreateController().setFunction(createFunction());

    listController.getUpdateController().addEntityConsumer(entity -> uploadController
        .loadExisting(((FilesGroupDto) entity).getIdentifier(), userIdentifier));
    listController.getUpdateController().setFunction(updateFunction());

    listController.getGotoReadPageButton().setOutcome(FilesGroupReadPage.OUTCOME);
    listController.getGotoReadPageButton().setRendered(true);

    initializeConfirmProcessing();
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(3);

    isConfirmedSelectBooleanController.setOutputLableValue("Est confirmé ?");
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices();
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean()
        .addValueConsumer(isConfirmedConsumer());
  }

  Function<Object, Object> createFunction() {
    return entity -> {
      FilesGroupCreateRequestDto request = requestMapper.mapCreate((FilesGroupDto) entity);
      request.setAuditWho(userIdentifier);
      request.setAuditSession(UUID.randomUUID().toString());
      CreateResponseDto response = client.create(request);
      uploadController.createFiles(response.getIdentifier(), request.getAuditSession());
      return response;
    };
  }
  
  Function<Object, Object> updateFunction() {
    return entity -> {
      FilesGroupUpdateRequestDto request = requestMapper.mapUpdate((FilesGroupDto) entity);
      // Le formulaire transmet toujours une valeur explicite : champ vidé (reçu null) = effacer.
      if (request.getDescription() == null) {
        request.setDescription("");
      }
      request.setAuditWho(userIdentifier);
      IdentifiableResponseDto response = client.update(request);
      uploadController.update(response.getIdentifier(), userIdentifier);
      return response;
    };
  }

  Consumer<Boolean> isConfirmedConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(FilesGroupDto.class).setIsConfirmed(value);
  }

  /**
   * Cette méthode permet de savoir si un Groupe de Fichiers peut être confirmé dans l'état où il
   * se trouve (RG_FILE_GRP_02, 03) : encore "Créé" (provisoire), jamais une fois "Confirmé".
   *
   * @param filesGroup groupe de fichiers
   * @return {@code true} si le groupe de fichiers peut être confirmé
   */
  public boolean confirmable(FilesGroupDto filesGroup) {
    return FilesGroupStatus.CREATED.equals(filesGroup.getStatus());
  }

  /**
   * Cette méthode permet d'initialiser {@link #confirmProcessingController}, affiché dans la
   * colonne Action de la liste (RG_FILE_GRP_02, 03).
   */
  void initializeConfirmProcessing() {
    confirmProcessingController.setListController(listController);
    confirmProcessingController.prepareConfirmation(FilesGroupDto.class, "Confirmer",
        "pi pi-thumbs-up", confirmFunction());
    confirmProcessingController
        .setSubmitButtonControllerRenderedFunction(entity -> confirmable((FilesGroupDto) entity));
    confirmProcessingController.initialize();
  }

  /**
   * Cette méthode permet de confirmer un Groupe de Fichiers par son identifiant (RG_FILE_GRP_02,
   * 03).
   *
   * @return fonction de confirmation
   */
  UnaryOperator<Object> confirmFunction() {
    return identifier -> {
      FilesGroupConfirmRequestDto request = new FilesGroupConfirmRequestDto();
      request.setIdentifier((String) identifier);
      request.setAuditWho(userIdentifier);
      return client.confirm(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(isConfirmedSelectBooleanController.getSelectOneRadioBoolean()).stream()
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
