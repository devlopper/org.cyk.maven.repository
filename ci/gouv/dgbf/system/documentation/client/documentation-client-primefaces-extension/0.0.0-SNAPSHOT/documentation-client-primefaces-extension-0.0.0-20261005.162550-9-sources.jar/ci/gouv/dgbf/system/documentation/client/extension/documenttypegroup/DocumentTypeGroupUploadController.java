package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentFieldValueDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentGetManyResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentUpdateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldFilter;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de dépôt des pièces attendues d'un groupe de types de
 * document.
 *
 * <p>À la sélection d'un groupe de types de document, elle construit un dépôt attendu par type
 * de document rattaché à ce groupe. Chaque fichier déposé devient un
 * {@link ci.gouv.dgbf.system.documentation.server.api.DocumentDto} rattaché au groupe créé, via
 * {@link #createDocuments(String)} appelé après la création du groupe. Une indisponibilité du
 * module {@code documentation} ou {@code file} est journalisée sans bloquer l'ouverture du
 * formulaire.
 *
 * <p>Le fragment associé est {@code /private/documenttypegroup/component/upload.xhtml}, livré par
 * ce même module ; il est piloté par le {@code ui:param name="controller"} pointant vers une
 * instance de cette classe.
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentTypeGroupUploadController extends AbstractController {

  /**
   * Classe CSS portée par le {@code p:dataTable} du fragment.
   */
  public static final String PANEL_STYLE_CLASS = "expected-documents-panel";

  /**
   * Sélecteur PrimeFaces du panneau des dépôts, à utiliser comme cible de rafraîchissement ajax
   * ({@code update}) depuis le contrôleur de la page hôte.
   */
  public static final String PANEL_SELECTOR = "@(." + PANEL_STYLE_CLASS + ")";

  @Inject
  DocumentTypeGroupClient documentTypeGroupClient;

  @Inject
  DocumentGroupClient documentGroupClient;

  @Inject
  DocumentTypeGroupFieldClient fieldClient;

  @Inject
  DocumentClient documentClient;

  @Inject
  FileClient fileClient;

  @Getter
  List<Upload> uploads;

  /**
   * Identifiant du groupe de types ayant servi à construire {@link #uploads}, pour ne
   * reconstruire les dépôts que lorsque la sélection change réellement.
   */
  String currentTypesGroupIdentifier;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentTypeGroupUploadController() {
    uploads = new ArrayList<>();
  }

  /**
   * Cette méthode permet de reconstruire la liste des dépôts attendus à partir du groupe de
   * types de document sélectionné. Une indisponibilité du module {@code documentation} est
   * journalisée et retombe sur une liste vide.
   *
   * <p>La reconstruction n'a lieu que si le groupe de types a changé : le consommateur de valeur
   * du sélecteur est aussi invoqué à la soumission du formulaire (phase de mise à jour du
   * modèle), et reconstruire à ce moment-là perdrait les fichiers déjà déposés avant que
   * {@link #createDocuments(String)} ne s'exécute.
   *
   * @param typesGroupIdentifier identifiant du groupe de types de document
   */
  public void refresh(String typesGroupIdentifier) {
    if (Objects.equals(currentTypesGroupIdentifier, typesGroupIdentifier)) {
      return;
    }
    currentTypesGroupIdentifier = typesGroupIdentifier;
    uploads.clear();
    if (typesGroupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentTypeGroupDto.JSON_TYPE_IDENTIFIER, DocumentTypeGroupDto.JSON_TYPE_AS_STRING,
        DocumentTypeGroupDto.JSON_REQUIRED);
    FilterDto filter = new FilterDto().addCriteria(DocumentTypeGroupDto.JSON_GROUP_IDENTIFIER,
        typesGroupIdentifier);
    DocumentTypeGroupGetManyResponseDto response;
    try {
      response = documentTypeGroupClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des pièces attendues pour le groupe de types " + typesGroupIdentifier
              + " en échec.",
          exception);
      return;
    }
    if (response != null && response.getDatas() != null) {
      response.getDatas().forEach(rattachement -> {
        Upload upload = new Upload(rattachement.getTypeIdentifier(), rattachement.getTypeAsString(),
            Boolean.TRUE.equals(rattachement.getRequired()));
        upload.setTypeGroupIdentifier(rattachement.getIdentifier());
        loadFieldInputs(upload);
        uploads.add(upload);
      });
    }
  }

  /**
   * Cette méthode permet de charger les champs configurables du rattachement d'un dépôt attendu.
   * Une indisponibilité du module {@code documentation} est journalisée et le dépôt reste sans
   * champ, pour ne pas bloquer l'ouverture du formulaire.
   *
   * @param upload dépôt attendu
   */
  private void loadFieldInputs(Upload upload) {
    if (upload.getTypeGroupIdentifier() == null) {
      return;
    }
    FilterDto filter = new FilterDto();
    DocumentTypeGroupFieldFilter.setTypeGroupIdentifier(filter, upload.getTypeGroupIdentifier());
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        HasNameDto.JSON_NAME, DocumentTypeGroupFieldDto.JSON_VALUE_TYPE,
        DocumentTypeGroupFieldDto.JSON_REQUIRED);
    try {
      List<DocumentTypeGroupFieldDto> fields =
          fieldClient.getMany(projection, filter, null, userIdentifier, null).getDatas();
      if (fields != null) {
        fields.forEach(field -> upload.getFieldInputs().add(DocumentFieldInput.of(field)));
      }
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des champs du rattachement " + upload.getTypeGroupIdentifier() + " en échec.",
          exception);
    }
  }

  /**
   * Cette méthode permet de vérifier, à partir de l'état courant des dépôts (sans appel serveur),
   * si un type de pièce obligatoire n'a encore aucun fichier déposé — pour un retour immédiat côté
   * UI. Le caractère obligatoire d'une pièce provient du {@link DocumentTypeGroupDto} lu par
   * {@link #refresh(String)} ; un module qui doit recalculer les pièces manquantes côté serveur
   * peut lire les rattachements obligatoires via le critère
   * {@code DocumentTypeGroupFilter.JSON_REQUIRED}.
   *
   * @return true si au moins une pièce obligatoire n'a pas de fichier déposé
   */
  public boolean hasMissingRequiredDocuments() {
    return uploads.stream().anyMatch(upload -> upload.isRequired()
        && upload.getFileIdentifier() == null);
  }

  /**
   * Cette méthode permet de savoir si au moins un dépôt attendu porte des champs configurables,
   * pour n'afficher la colonne des informations que dans ce cas.
   *
   * @return true si au moins un dépôt porte des champs
   */
  public boolean hasFieldInputs() {
    return uploads.stream().anyMatch(upload -> !upload.getFieldInputs().isEmpty());
  }

  /**
   * Cette méthode permet de compléter la liste des dépôts attendus (déjà reconstruite via
   * {@link #refresh(String)}) avec les documents déjà déposés dans un groupe de document
   * existant — utilisé à l'ouverture d'un formulaire de modification d'une entité existante. Une
   * indisponibilité du module {@code documentation} ne doit pas empêcher cette ouverture : on se
   * contente de journaliser et de retomber sur la liste des dépôts attendus sans documents déjà
   * déposés, comme {@link #refresh(String)}/{@link #resolveFile(String)}.
   *
   * @param groupIdentifier identifiant du groupe de document
   */
  public void loadExistingDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentDto.JSON_TYPE_IDENTIFIER, DocumentDto.JSON_FILE_IDENTIFIER);
    FilterDto filter =
        new FilterDto().addCriteria(DocumentDto.JSON_GROUP_IDENTIFIER, groupIdentifier);
    DocumentGetManyResponseDto response;
    try {
      response = documentClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des documents du groupe " + groupIdentifier + " en échec.", exception);
      return;
    }
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(document -> uploads.stream()
        .filter(upload -> upload.getTypeIdentifier().equals(document.getTypeIdentifier()))
        .findFirst().ifPresent(upload -> {
          // Conservés pour permettre à syncDocuments(String) de distinguer un dépôt déjà
          // persisté (à mettre à jour ou supprimer) d'un dépôt nouvellement déposé (à créer), et
          // de détecter un remplacement de fichier.
          upload.setDocumentIdentifier(document.getIdentifier());
          upload.setOriginalFileIdentifier(document.getFileIdentifier());
          upload.setFileIdentifier(document.getFileIdentifier());
          if (document.getFileIdentifier() != null) {
            FileDto file = resolveFile(document.getFileIdentifier());
            upload.setFileName(file == null ? document.getFileIdentifier() : file.getName());
          }
          loadFieldValues(upload, document.getIdentifier());
        }));
  }

  /**
   * Cette méthode permet de pré-remplir les saisies d'un dépôt avec les valeurs de champs de son
   * document. La liste des documents ne projette pas les valeurs de champs : elles sont lues par
   * identifiant, qui doit lui-même être projeté pour que le serveur retrouve les valeurs. Une
   * indisponibilité du module {@code documentation} est journalisée, sans bloquer l'ouverture du
   * formulaire.
   *
   * @param upload dépôt attendu
   * @param documentIdentifier identifiant du document existant
   */
  private void loadFieldValues(Upload upload, String documentIdentifier) {
    if (upload.getFieldInputs().isEmpty()) {
      return;
    }
    try {
      DocumentDto document = documentClient.getByIdentifier(documentIdentifier,
          new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
              DocumentDto.JSON_FIELD_VALUES),
          userIdentifier, null);
      prefillFieldInputs(upload, document == null ? null : document.getFieldValues());
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des valeurs de champs du document " + documentIdentifier + " en échec.",
          exception);
    }
  }

  /**
   * Cette méthode permet d'obtenir le fichier déjà déposé pour un document existant, à partir de
   * son identifiant — une indisponibilité du module {@code file} ne doit pas empêcher l'ouverture
   * du formulaire de modification (le dépôt reste consultable/modifiable même si son nom de
   * fichier ne peut pas être affiché) : on se contente de journaliser et de retomber sur
   * l'identifiant brut du fichier (cf. {@link #loadExistingDocuments(String)}).
   *
   * @param fileIdentifier identifiant du fichier
   * @return le fichier, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private FileDto resolveFile(String fileIdentifier) {
    try {
      return fileClient.getByIdentifier(fileIdentifier,
          new ProjectionDto().addNames(FileDto.JSON_NAME), userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention du fichier " + fileIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de déposer un fichier pour un dépôt attendu. Le dépôt concerné est
   * retrouvé via l'attribut {@code typeIdentifier} posé sur le composant ({@code p:fileUpload}
   * n'expose pas de variable EL implicite permettant de le passer autrement).
   *
   * @param event évènement de dépôt de fichier
   */
  public void upload(FileUploadEvent event) {
    String typeIdentifier =
        (String) event.getComponent().getAttributes().get(ATTRIBUTE_TYPE_IDENTIFIER);
    Upload upload = uploads.stream()
        .filter(candidate -> candidate.getTypeIdentifier().equals(typeIdentifier)).findFirst()
        .orElse(null);
    if (upload == null) {
      Logger.getLogger(getClass().getName()).log(Level.WARNING,
          "Dépôt de fichier reçu pour un type de pièce non résolu : {0}", typeIdentifier);
      return;
    }
    try {
      String fileIdentifier = fileClient.getIdentifierByBytesOrByCreate(
          event.getFile().getFileName(), event.getFile().getContent(), userIdentifier, null);
      upload.setFileIdentifier(fileIdentifier);
      upload.setFileName(event.getFile().getFileName());
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Dépôt du fichier " + event.getFile().getFileName() + " pour la pièce "
              + typeIdentifier + " en échec.",
          exception);
      throw exception;
    }
  }

  /**
   * Nom de l'attribut du composant {@code p:fileUpload} portant l'identifiant du type de document
   * concerné.
   */
  public static final String ATTRIBUTE_TYPE_IDENTIFIER = "typeIdentifier";

  /**
   * Cette méthode permet de retirer le fichier déposé pour un dépôt attendu.
   *
   * @param upload dépôt attendu
   */
  public void remove(Upload upload) {
    upload.setFileIdentifier(null);
    upload.setFileName(null);
  }

  /**
   * Cette méthode permet de créer le groupe de document porteur des pièces attendues. L'entité
   * consommatrice n'existe pas encore à cet instant lorsqu'elle a besoin de connaître
   * l'identifiant du groupe dès sa propre création (ex. pour le stocker sur elle-même) :
   * l'identifiant d'enregistrement transmis au module {@code documentation} est donc un
   * identifiant de corrélation généré ici, sans lien de clé étrangère avec l'entité
   * consommatrice.
   *
   * @param typesGroupIdentifier identifiant du groupe de types de document attendu
   * @param processIdentifier identifiant du processus métier consommateur
   * @param sourceIdentifier identifiant du module source consommateur
   * @param operationIdentifier identifiant de l'opération métier consommatrice
   * @return identifiant du groupe de document créé
   */
  public String createDocumentGroup(String typesGroupIdentifier, String processIdentifier,
      String sourceIdentifier, String operationIdentifier) {
    DocumentGroupCreateRequestDto request = new DocumentGroupCreateRequestDto();
    request.setTypeGroupIdentifier(typesGroupIdentifier);
    request.setProcessIdentifier(processIdentifier);
    request.setSourceIdentifier(sourceIdentifier);
    request.setRecordIdentifier(UUID.randomUUID().toString());
    request.setOperationIdentifier(operationIdentifier);
    request.setAuditWho(userIdentifier);
    CreateResponseDto response = documentGroupClient.create(request);
    return response.getIdentifier();
  }

  /**
   * Cette méthode permet de créer, dans le groupe de document, un document pour chaque dépôt
   * attendu dont un fichier a été déposé.
   *
   * @param groupIdentifier identifiant du groupe de document créé
   */
  public void createDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    uploads.stream().filter(this::isToPersist)
        .forEach(upload -> documentClient.create(buildCreateRequest(upload, groupIdentifier)));
    reset();
  }

  /**
   * Cette méthode permet de synchroniser, en modification d'une entité existante, les documents
   * du groupe avec l'état courant des dépôts attendus : création des pièces nouvellement
   * déposées, mise à jour de celles dont le fichier a été remplacé, et suppression de celles
   * retirées par l'utilisateur.
   *
   * @param groupIdentifier identifiant du groupe de document
   */
  public void syncDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    uploads.forEach(upload -> {
      if (upload.getDocumentIdentifier() == null) {
        if (isToPersist(upload)) {
          documentClient.create(buildCreateRequest(upload, groupIdentifier));
        }
      } else if (!isToPersist(upload)) {
        documentClient.deleteByIdentifier(upload.getDocumentIdentifier(), userIdentifier, null);
      } else if (!upload.getFieldInputs().isEmpty()
          || !Objects.equals(upload.getFileIdentifier(), upload.getOriginalFileIdentifier())) {
        DocumentUpdateRequestDto request = new DocumentUpdateRequestDto();
        request.setIdentifier(upload.getDocumentIdentifier());
        request.setTypeIdentifier(upload.getTypeIdentifier());
        request.setGroupIdentifier(groupIdentifier);
        request.setFileIdentifier(upload.getFileIdentifier());
        request.setFieldValues(buildFieldValues(upload));
        request.setAuditWho(userIdentifier);
        documentClient.update(request);
      }
    });
  }

  /**
   * Cette méthode permet de savoir si un dépôt doit donner lieu à un document : un fichier est
   * déposé, une valeur de champ est saisie, ou la pièce est obligatoire et porte des champs (le
   * serveur refuse alors la création tant qu'un champ obligatoire manque, y compris sans fichier).
   *
   * @param upload dépôt attendu
   * @return true si un document doit exister pour ce dépôt
   */
  boolean isToPersist(Upload upload) {
    return upload.getFileIdentifier() != null || !buildFieldValues(upload).isEmpty()
        || upload.isRequired() && !upload.getFieldInputs().isEmpty();
  }

  DocumentCreateRequestDto buildCreateRequest(Upload upload, String groupIdentifier) {
    DocumentCreateRequestDto request = new DocumentCreateRequestDto();
    request.setTypeIdentifier(upload.getTypeIdentifier());
    request.setGroupIdentifier(groupIdentifier);
    request.setFileIdentifier(upload.getFileIdentifier());
    request.setFieldValues(buildFieldValues(upload));
    request.setAuditWho(userIdentifier);
    return request;
  }

  /**
   * Cette méthode permet de convertir les saisies d'un dépôt en {@link DocumentFieldValueDto},
   * posés sur la requête de création ou de mise à jour du document.
   *
   * @param upload dépôt attendu
   * @return valeurs des champs saisis
   */
  List<DocumentFieldValueDto> buildFieldValues(Upload upload) {
    List<DocumentFieldValueDto> values = new ArrayList<>();
    for (DocumentFieldInput input : upload.getFieldInputs()) {
      String text = input.getValueAsText();
      if (text == null || text.isBlank()) {
        continue;
      }
      DocumentFieldValueDto value = new DocumentFieldValueDto();
      value.setFieldIdentifier(input.getField().getIdentifier());
      value.setValue(text);
      values.add(value);
    }
    return values;
  }

  /**
   * Cette méthode permet de pré-remplir les saisies d'un dépôt avec les valeurs d'un document
   * existant.
   *
   * @param upload dépôt attendu
   * @param values valeurs déjà saisies, ou null
   */
  void prefillFieldInputs(Upload upload, List<DocumentFieldValueDto> values) {
    if (values == null) {
      return;
    }
    for (DocumentFieldValueDto value : values) {
      upload.getFieldInputs().stream()
          .filter(input -> input.getField().getIdentifier().equals(value.getFieldIdentifier()))
          .findFirst().ifPresent(input -> input.writeValueAsText(value.getValue()));
    }
  }

  /**
   * Cette méthode permet de vider les dépôts, afin que la prochaine création reparte d'un
   * formulaire vierge.
   */
  public void reset() {
    uploads.clear();
    currentTypesGroupIdentifier = null;
  }

  /**
   * Cette classe représente un dépôt attendu (un type de pièce), avec le fichier éventuellement
   * déposé.
   *
   * @author si.kimou
   *
   */
  @Getter
  @Setter
  public static class Upload {

    String typeIdentifier;
    String typeAsString;
    boolean required;

    /**
     * Identifiant du rattachement (type de document dans le groupe), pour charger les champs
     * configurables du dépôt.
     */
    String typeGroupIdentifier;

    /**
     * Saisies des champs configurables du rattachement ; vide si le rattachement n'en porte pas.
     */
    final List<DocumentFieldInput> fieldInputs = new ArrayList<>();
    String fileIdentifier;
    String fileName;

    /**
     * Identifiant du document déjà persisté pour ce dépôt (renseigné par
     * {@link #loadExistingDocuments(String)}), ou {@code null} si aucun document n'existe encore
     * en base pour ce dépôt.
     */
    String documentIdentifier;

    /**
     * Identifiant du fichier tel que chargé depuis le document existant (renseigné par
     * {@link #loadExistingDocuments(String)}), utilisé par {@link #syncDocuments(String)} pour
     * détecter un remplacement de fichier.
     */
    String originalFileIdentifier;

    /**
     * Cette méthode permet de construire.
     *
     * @param typeIdentifier identifiant du type de document attendu
     * @param typeAsString libellé du type de document attendu
     * @param required obligatoire ou non (RG_DOC_PCE : blocage côté hôte si vrai et sans fichier)
     */
    public Upload(String typeIdentifier, String typeAsString, boolean required) {
      this.typeIdentifier = typeIdentifier;
      this.typeAsString = typeAsString;
      this.required = required;
    }
  }
}
