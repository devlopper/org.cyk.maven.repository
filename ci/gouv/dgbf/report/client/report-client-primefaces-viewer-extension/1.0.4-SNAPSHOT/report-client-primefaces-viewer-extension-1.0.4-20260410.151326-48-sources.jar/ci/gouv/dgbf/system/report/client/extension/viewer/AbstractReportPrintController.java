package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base de contrôleur d'impression de rapport.
 *
 * @author Christian
 */
@Dependent
public abstract class AbstractReportPrintController extends AbstractController {

  @Inject
  @Getter
  ReportPrintConfigurationController configurationController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    configurationController.setReportIdentifier(getReportIdentifier());
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du rapport.
   *
   * @return identifiant du rapport
   */
  protected abstract String getReportIdentifier();

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    configurationController.initialize();
  }

}
