package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant intégré pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountN1AsStringDto extends HasIntegratedAmountN1AsString {

  /**
   * Identifiant json du montant intégré pour l'année N+1.
   */
  String JSON_INTEGRATED_AMOUNT_N1_AS_STRING = "montantIntegreN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName