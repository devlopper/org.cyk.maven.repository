package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableAuditableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasSuspendedDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.Email;
import java.time.LocalDateTime;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une réclamation d'élément de paie. Son code est son numéro unique,
 * attribué par le serveur à la création (RG_REP_SOU_18).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimDto extends AbstractIdentifiableCodableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto,
    HasStatusDto<PayrollElementClaimStatus>, HasStatusAsStringDto, HasEmailAddressDto,
    HasSuspendedDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Statut courant du cycle de vie de la réclamation (RG_REP_STA_01).
   */
  @JsonbProperty(JSON_STATUS)
  private PayrollElementClaimStatus status;

  /**
   * Représentation en chaine de caractères de {@link #status}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Indicateur de suspension, orthogonal au statut (R47, RG_REP_STA_04).
   */
  @JsonbProperty(JSON_SUSPENDED)
  private Boolean suspended;

  /**
   * Nature de la réclamation -- Ordinaire ou Contentieux (référentiel
   * {@code TR_NATURE_RECLAMATION}), simple discriminant classificatoire sans effet sur son
   * traitement.
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Source du dépôt -- FAE, Tiers habilité ou FUR (référentiel {@code TR_SOURCE_RECLAMATION}),
   * entièrement déduite à la création, jamais fournie par le client. Filtrable (prise en charge,
   * traitements).
   */
  @JsonbProperty(JSON_SOURCE)
  private String source;

  /**
   * Identifiant du Fonctionnaire ou Agent de l'État concerné par la réclamation, module
   * {@code functionary} -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_CONCERNED_FUNCTIONARY_IDENTIFIER)
  private String concernedFunctionaryIdentifier;

  /**
   * Instantané (pas une référence vivante) de la structure du FAE concerné choisie à la
   * soumission ({@code FunctionaryDto#getStructures()}) -- {@code null} si le FAE n'a qu'une
   * structure ou si la réclamation ne passe pas par l'annuaire (ex. "Ma fonction").
   */
  @JsonbProperty(JSON_CONCERNED_STRUCTURE)
  private Map<String, Object> concernedStructure;

  /**
   * Identifiant de l'émetteur de la réclamation, module {@code identity} -- sans FK (couplage
   * faible).
   */
  @JsonbProperty(JSON_ISSUER_IDENTIFIER)
  private String issuerIdentifier;

  /**
   * Identifiant du Groupe de Documents constituant le dossier de pièces de la réclamation, module
   * {@code documentation} -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_DOCUMENTS_GROUP_IDENTIFIER)
  private String documentsGroupIdentifier;

  /**
   * Identifiant du Lot d'Import dont la réclamation est issue, {@code null} si elle a été saisie
   * (RG_REP_SOU_12).
   */
  @JsonbProperty(JSON_IMPORT_BATCH_IDENTIFIER)
  private String importBatchIdentifier;

  /**
   * Numéro de la ligne du Lot Import FUR à l'origine de la réclamation, {@code null} si elle
   * n'est pas issue du FUR ; avec {@link #importBatchIdentifier}, identifie de façon unique la
   * ligne FUR source.
   */
  @JsonbProperty(JSON_FUR_LINE_NUMBER)
  private Integer furLineNumber;

  /**
   * Identifiant de l'agent de traitement actuellement en charge de la réclamation -- vide avant
   * sa Prise en charge.
   */
  @JsonbProperty(JSON_PROCESSING_AGENT_IDENTIFIER)
  private String processingAgentIdentifier;

  /**
   * Date de création de la réclamation.
   */
  @JsonbProperty(JSON_CREATION_DATE)
  private LocalDateTime creationDate;

  /**
   * Commentaire libre de l'Émetteur, facultatif.
   */
  @JsonbProperty(JSON_COMMENT)
  private String comment;

  /**
   * Adresse email de contact, facultative -- instantané figé à la Soumission (pré-rempli depuis
   * {@code VMA_FONCTIONNAIRE} si connue pour le FAE concerné), jamais mis à jour ensuite.
   */
  @Email
  @JsonbProperty(JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Nombre de {@code ClaimedValueReview} encore à l'état Générée (projection calculée, jamais
   * une colonne réelle) -- portefeuille de l'Agent, onglet "Mes revues à transmettre"
   * (RU_REP_007/RU_REP_015).
   */
  @JsonbProperty(JSON_PENDING_REVIEWS_COUNT)
  private Long pendingReviewsCount;

  /**
   * Identifiant du bordereau de transmission qui porte la réclamation (projection calculée, jamais
   * une colonne réelle, RG_REP_RVR_17).
   */
  @JsonbProperty(JSON_SLIP_IDENTIFIER)
  private String slipIdentifier;

  /**
   * Numéro du bordereau de transmission qui porte la réclamation (projection calculée, jamais une
   * colonne réelle, RG_REP_RVR_17) -- écran récapitulatif des réclamations transmises.
   */
  @JsonbProperty(JSON_SLIP_NUMBER)
  private String slipNumber;

  /**
   * Nombre total de réclamations portées par le bordereau de transmission de la ligne, quelle que
   * soit la page affichée (projection calculée, RG_REP_RVR_17).
   */
  @JsonbProperty(JSON_SLIP_CLAIM_COUNT)
  private Long slipClaimCount;

  /**
   * Identifiant de l'utilisateur qui a émis le bordereau de transmission qui porte la réclamation
   * (projection calculée, RG_REP_RVR_17).
   */
  @JsonbProperty(JSON_SLIP_ISSUER)
  private String slipIssuer;

  /**
   * Date et heure d'émission du bordereau de transmission qui porte la réclamation (projection
   * calculée, RG_REP_RVR_17).
   */
  @JsonbProperty(JSON_SLIP_ISSUE_DATE)
  private LocalDateTime slipIssueDate;

  /**
   * Nombre de {@code ClaimedValueReview} au statut porté par le filtre courant (projection
   * calculée, jamais une colonne réelle) -- écran de traitement des revues (RU_REP_010), colonne
   * "Nombre de revues".
   */
  @JsonbProperty(JSON_REVIEW_STATUS_COUNT)
  private Long reviewStatusCount;

  /**
   * Date du dernier événement d'historique de la réclamation (changement de statut, suspension
   * ou reprise) -- projection calculée, jamais une colonne réelle. Visibilité rapide de la
   * fraîcheur du traitement (liste et détail) sans ouvrir l'onglet Historique.
   */
  @JsonbProperty(JSON_LAST_PROCESSING_DATE)
  private LocalDateTime lastProcessingDate;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #source}.
   */
  public static final String JSON_SOURCE = "source";

  /**
   * Identifiant json {@link #concernedFunctionaryIdentifier}.
   */
  public static final String JSON_CONCERNED_FUNCTIONARY_IDENTIFIER = "idFaeConcerne";

  /**
   * Identifiant json {@link #concernedStructure}.
   */
  public static final String JSON_CONCERNED_STRUCTURE = "structureConcernee";

  /**
   * Identifiant json {@link #issuerIdentifier}.
   */
  public static final String JSON_ISSUER_IDENTIFIER = "idEmetteur";

  /**
   * Identifiant json {@link #documentsGroupIdentifier}.
   */
  public static final String JSON_DOCUMENTS_GROUP_IDENTIFIER = "idDossierPieces";

  /**
   * Identifiant json {@link #importBatchIdentifier}.
   */
  public static final String JSON_IMPORT_BATCH_IDENTIFIER = "idLotImport";

  /**
   * Identifiant json {@link #furLineNumber}.
   */
  public static final String JSON_FUR_LINE_NUMBER = "numeroLigneFur";

  /**
   * Identifiant json {@link #processingAgentIdentifier}.
   */
  public static final String JSON_PROCESSING_AGENT_IDENTIFIER = "idAgentTraitement";

  /**
   * Identifiant json {@link #creationDate}.
   */
  public static final String JSON_CREATION_DATE = "dateCreation";

  /**
   * Identifiant json {@link #comment}.
   */
  public static final String JSON_COMMENT = "commentaire";

  /**
   * Identifiant json {@link #pendingReviewsCount}.
   */
  public static final String JSON_PENDING_REVIEWS_COUNT = "nombreRevuesEnAttente";

  /**
   * Identifiant json {@link #slipIdentifier}.
   */
  public static final String JSON_SLIP_IDENTIFIER = "identifiantBordereau";

  /**
   * Identifiant json {@link #slipNumber}.
   */
  public static final String JSON_SLIP_NUMBER = "numeroBordereau";

  /**
   * Identifiant json {@link #slipClaimCount}.
   */
  public static final String JSON_SLIP_CLAIM_COUNT = "nombreReclamationsBordereau";

  /**
   * Identifiant json {@link #slipIssuer}.
   */
  public static final String JSON_SLIP_ISSUER = "emetteurBordereau";

  /**
   * Identifiant json {@link #slipIssueDate}.
   */
  public static final String JSON_SLIP_ISSUE_DATE = "dateBordereau";

  /**
   * Identifiant json {@link #reviewStatusCount}.
   */
  public static final String JSON_REVIEW_STATUS_COUNT = "nombreRevuesAuStatut";

  /**
   * Identifiant json {@link #lastProcessingDate}.
   */
  public static final String JSON_LAST_PROCESSING_DATE = "dateDernierTraitement";

  /**
   * Identifiant json de identifiant de {@link PayrollElementClaimDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayrollElementClaimDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "réclamations";

  /**
   * Nature Ordinaire.
   */
  public static final String NATURE_ORDINARY = "ORDINAIRE";

  /**
   * Nature Contentieux.
   */
  public static final String NATURE_LITIGATION = "CONTENTIEUX";

  /**
   * Source FAE -- dépôt pour soi-même.
   */
  public static final String SOURCE_FAE = "FAE";

  /**
   * Source Tiers habilité -- dépôt pour un FAE concerné désigné (RU_REP_003 : DRH, Agent de
   * traitement au guichet, etc.), non distingués entre eux à ce jour.
   */
  public static final String SOURCE_AUTHORIZED_THIRD_PARTY = "TIERS_HABILITE";

  /**
   * Source FUR -- généré automatiquement par un import FUR.
   */
  public static final String SOURCE_FUR = "FUR";
}
