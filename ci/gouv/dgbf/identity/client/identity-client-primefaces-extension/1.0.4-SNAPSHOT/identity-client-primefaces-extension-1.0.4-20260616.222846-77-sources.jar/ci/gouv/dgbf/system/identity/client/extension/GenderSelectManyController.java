package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.GenderClient;
import ci.gouv.dgbf.system.identity.server.api.GenderDto;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de plusieurs {@link GenderDto}.
 *
 * @author arnaud
 *
 */
@Dependent
public class GenderSelectManyController extends
    AbstractSelectManyIdentifiableController<GenderDto, GenderGetManyResponseDto, GenderClient> {

  @Inject
  @Getter
  GenderClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected GenderSelectManyController() {
    super(GenderDto.class, SelectItemLabelStrategy.NAME);
  }
}
