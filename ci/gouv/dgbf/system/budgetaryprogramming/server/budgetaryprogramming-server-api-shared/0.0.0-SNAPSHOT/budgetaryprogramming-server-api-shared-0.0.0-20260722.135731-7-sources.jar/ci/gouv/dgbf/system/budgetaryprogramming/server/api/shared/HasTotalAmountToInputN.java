package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N.
 *
 * @author Christian
 */
public interface HasTotalAmountToInputN {

  /**
   * Obtient le montant total à saisir pour l'année N.
   *
   * @return le montant total à saisir pour l'année N, {@code null} si aucun plafond n'est défini
   */
  Long getTotalAmountToInputN();

  /**
   * Définit le montant total à saisir pour l'année N.
   *
   * @param totalAmountToInputN le montant total à saisir pour l'année N
   */
  void setTotalAmountToInputN(Long totalAmountToInputN);
  
  /**
   * Identifiant json du montant total à saisir pour l'année N.
   */
  String FIELD_TOTAL_AMOUNT_TO_INPUT_N = "totalAmountToInputN";
}
