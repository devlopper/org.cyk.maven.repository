package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe d'emplois de paie.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollModelDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link PayrollJobGroup}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #groupIdentifier}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Identifiant {@link PayrollType}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant du modèle de bulletin de paie. 
   */
  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_IDENTIFIER)
  private String payslipTemplateIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #payslipTemplateIdentifier}.
   */
  @JsonbProperty(JSON_PAYSLIP_TEMPLATE_AS_STRING)
  private String payslipTemplateAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPayrollModel";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "payrollModelChaine";

  /**
   * Identifiant json de {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupEmploiPaie";

  /**
   * Identifiant json de {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupEmploiPaieChaine";

  /**
   * Identifiant json de {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = "idTypePaie";

  /**
   * Identifiant json de {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = "typePaieChaine";

  /**
   * Identifiant json de {@link #payslipTemplateIdentifier}.
   */
  public static final String JSON_PAYSLIP_TEMPLATE_IDENTIFIER = "idModeleBulletin";

  /**
   * Identifiant json de {@link #payslipTemplateAsString}.
   */
  public static final String JSON_PAYSLIP_TEMPLATE_AS_STRING = "modeleBulletinChaine";



  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "modèle de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modèles de paie";
}
