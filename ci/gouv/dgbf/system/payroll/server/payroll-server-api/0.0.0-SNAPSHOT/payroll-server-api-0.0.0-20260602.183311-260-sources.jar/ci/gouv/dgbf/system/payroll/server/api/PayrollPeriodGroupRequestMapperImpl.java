package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollPeriodGroupDto}.
*
* @author arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T18:33:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollPeriodGroupRequestMapperImpl implements PayrollPeriodGroupRequestMapper {

    @Override
    public PayrollPeriodGroupService.PayrollPeriodGroupCreateRequestDto mapCreate(PayrollPeriodGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollPeriodGroupService.PayrollPeriodGroupCreateRequestDto payrollPeriodGroupCreateRequestDto = new PayrollPeriodGroupService.PayrollPeriodGroupCreateRequestDto();

        payrollPeriodGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollPeriodGroupCreateRequestDto.setCode( arg0.getCode() );
        payrollPeriodGroupCreateRequestDto.setName( arg0.getName() );
        payrollPeriodGroupCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payrollPeriodGroupCreateRequestDto;
    }

    @Override
    public PayrollPeriodGroupService.PeriodGroupUpdateRequestDto mapUpdate(PayrollPeriodGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollPeriodGroupService.PeriodGroupUpdateRequestDto periodGroupUpdateRequestDto = new PayrollPeriodGroupService.PeriodGroupUpdateRequestDto();

        periodGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        periodGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        periodGroupUpdateRequestDto.setCode( arg0.getCode() );
        periodGroupUpdateRequestDto.setName( arg0.getName() );
        periodGroupUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return periodGroupUpdateRequestDto;
    }
}
