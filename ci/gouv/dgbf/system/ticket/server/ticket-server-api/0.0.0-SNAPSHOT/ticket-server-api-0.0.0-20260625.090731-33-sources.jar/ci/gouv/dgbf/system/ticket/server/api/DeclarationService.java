package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestMultipartDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.annotations.providers.multipart.PartType;

/**
 * Cette interface représente les services de {@link DeclarationDto}.
 *
 * @author Arnaud KOFFI
 *
 */
@Path(value = DeclarationService.PATH)
@Tag(name = "Gestion des déclarations")
public interface DeclarationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "declarations";


  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface DeclarationSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link TicketDto}.
     *
     * @return identifiant de {@link TicketDto}
     */
    String getTicketIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link TicketDto}.
     *
     * @param ticketIdentifier identifiant de {@link TicketDto}
     */
    void setTicketIdentifier(String ticketIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité du declarant.
     *
     * @return identifiant de l'utilisateur
     */
    String getReporterIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité du declarant.
     *
     * @param reporterIdentityIdentifier identifiant de l'identité du declarant
     */
    void setReporterIdentityIdentifier(String reporterIdentityIdentifier);


    /**
     * Identifiant json identifiant de {@link TicketDto}.
     */
    String JSON_TICKET_IDENTIFIER = TicketDto.JSON_THIS_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link DeclarationDto}.
     */
    String JSON_REPORTER_IDENTITY_IDENTIFIER = DeclarationDto.JSON_REPORTER_IDENTITY_IDENTIFIER;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_DECLARATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DeclarationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeclarationCreateRequestDto extends AbstractAuditedRequestJsonDto
        implements DeclarationSaveRequestDto {
    @JsonbProperty(DeclarationSaveRequestDto.JSON_TICKET_IDENTIFIER)
    private String ticketIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DECLARATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = DeclarationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class DeclarationGetManyResponseDto
      extends AbstractGetByPageResponseDto<DeclarationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DeclarationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DECLARATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeclarationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DECLARATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DeclarationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DECLARATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DeclarationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class DeclarationUpdateRequestDto extends ByIdentifierRequestDto implements
        DeclarationSaveRequestDto {
    @JsonbProperty(DeclarationSaveRequestDto.JSON_TICKET_IDENTIFIER)
    private String ticketIdentifier;

    @JsonbProperty(DeclarationSaveRequestDto.JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DECLARATION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DeclarationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);


  /**
   * Identifiant du service de création d'incident.
   */
  String CREATE_INCIDENT_IDENTIFIER = "CREATION_INCIDENT_DECLARATION";

  /**
   * Chemin du service de création d'un incident.
   */
  String CREATE_INCIDENT_PATH = "creation-incident";

  /**
   * Cette méthode permet de créer un incident.
   *
   * @param request requête
   * @return réponse
 */
  @Path(CREATE_INCIDENT_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_INCIDENT_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response createIncident(DeclarationCreateIncidentRequestDto request);

  /**
   * Cette classe représente la requête de création d'incident.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class DeclarationCreateIncidentRequestDto extends AbstractAuditedRequestMultipartDto  {

    /**
     * Identifiant de l'identité du déclarant.
     */
    @JsonbProperty(JSON_REPORTER_IDENTITY_IDENTIFIER)
    @Parameter(name = JSON_REPORTER_IDENTITY_IDENTIFIER,
        description = "l'identifiant de l'identité du déclarant")
    @PartType(MediaType.TEXT_PLAIN)
    @FormParam(value = JSON_REPORTER_IDENTITY_IDENTIFIER)
    private String reporterIdentityIdentifier;

    /**
     * Objet.
     */
    @JsonbProperty(JSON_OBJECT)
    @Parameter(name = JSON_OBJECT, description = "l'objet")
    @PartType(MediaType.TEXT_PLAIN)
    @FormParam(value = JSON_OBJECT)
    private String object;

    /**
     * Description.
     */
    @JsonbProperty(JSON_DESCRIPTION)
    @Parameter(name = JSON_DESCRIPTION, description = "la description")
    @PartType(MediaType.TEXT_PLAIN)
    @FormParam(value = JSON_DESCRIPTION)
    private String description;

    /**
     * Domaine fonctionnel.
     */
    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    @Parameter(name = JSON_DOMAIN_IDENTIFIER, description = "le domaine fonctionnel")
    @PartType(MediaType.TEXT_PLAIN)
    @FormParam(value = JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;



    /**
     * Nom du fichier joint.
     */
    @JsonbProperty(JSON_FILE_NAME)
    @FormParam(value = JSON_FILE_NAME)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_FILE_NAME, description = "le nom du fichier", example = "fichier01.txt")
    private String filename;

    /**
     * Type de contenu du fichier joint.
     */
    @FormParam(value = JSON_FILE_CONTENT_TYPE)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_FILE_CONTENT_TYPE,
        description = "le type de contenu du fichier. Il doit respecter le format MIME",
        example = "text/plain")
    @JsonbProperty(JSON_FILE_CONTENT_TYPE)
    private String fileContentType;

    /**
     * Octets.
     */
    @FormParam(value = JSON_FILE_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    @Parameter(name = JSON_FILE_BYTES, description = "les données binaires du fichier")
    @JsonbProperty(JSON_FILE_BYTES)
    private byte[] fileBytes;

    /**
     * Identifiant json {@link #description}.
     */
    public static final String JSON_DESCRIPTION = DeclarationDto.JSON_DESCRIPTION;

    /**
     * Identifiant json {@link #object}.
     */
    public static final String JSON_OBJECT = DeclarationDto.JSON_OBJECT;


    /**
     * Identifiant json {@link #reporterIdentityIdentifier}.
     */
    public static final String JSON_REPORTER_IDENTITY_IDENTIFIER =
        DeclarationDto.JSON_REPORTER_IDENTITY_IDENTIFIER;

    /**
     * Identifiant json {@link #domainIdentifier}.
     */
    public static final String JSON_DOMAIN_IDENTIFIER = DeclarationDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * Identifiant json {@link #filename}.
     */
    public static final String JSON_FILE_NAME = "nomFichier";

    /**
     * Identifiant json {@link #fileContentType}.
     */
    public static final String JSON_FILE_CONTENT_TYPE = "typeContenu";

    /**
     * Identifiant json {@link #fileBytes}.
     */
    public static final String JSON_FILE_BYTES = "bytes";
  }
}
