package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.MenuModel;

/**
 * Cette classe représente un menu en bouton.
 *
 * @author Christian
 *
 */
public class MenuButton extends AbstractWidget {

  @Getter
  @Setter
  String value;

  @Getter
  @Setter
  String icon;

  @Getter
  @Setter
  String menuItemStyleClassFormat;

  @Getter
  @Setter
  String menuItemStyleClassPrefix;

  @Getter
  @Setter
  Map<String, List<String>> menuItemParameters;

  @Getter
  @Setter
  List<Button> buttons;

  @Getter
  @Setter
  MenuModel model;

  /**
   * Cette méthode permet d'instantier.
   */
  public MenuButton() {
    menuItemStyleClassPrefix = "data";
    menuItemStyleClassFormat = "%s-tab-menu-item-%s";
  }

  /**
   * Cette méthode permet d'obtenir un bouton par index.
   *
   * @param index index
   * @return bouton
   */
  public Button getButtonByIndex(Integer index) {
    return Core.getListElementAt(buttons, index);
  }

  protected Collection<Button> buttons() {
    Core.runIfNull(buttons, () -> buttons = new ArrayList<>());
    return buttons;
  }

  public Map<String, List<String>> menuItemParameters() {
    Core.runIfNull(menuItemParameters, () -> menuItemParameters = new LinkedHashMap<>());
    return menuItemParameters;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    Optional.ofNullable(buttons).orElse(Collections.emptyList()).forEach(button -> {
      button.initialize();
      model().getElements().add(button.model);
    });
  }

  MenuModel model() {
    Core.runIfNull(model, () -> model = new DefaultMenuModel());
    return model;
  }

  public static Builder builder() {
    return new Builder();
  }

  /**
   * Cette classe représente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {
    String value;
    String icon;
    List<Button.Builder> buttonsBuilders;

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link MenuButton}
     */
    public MenuButton build() {
      MenuButton menuButton = new MenuButton();
      menuButton.value = value;
      menuButton.icon = icon;
      Core.runIfCollectionNotEmpty(buttonsBuilders,
          () -> menuButton.buttons = buttonsBuilders.stream().map(Button.Builder::build).toList());
      return menuButton;
    }

    List<Button.Builder> nonNullButtonsBuilders() {
      if (buttonsBuilders == null) {
        buttonsBuilders = new ArrayList<>();
      }
      return buttonsBuilders;
    }

    /**
     * Cette méthode permet d'ajouter une liste de {@link Button.Builder}.
     *
     * @param builders liste de {@link Button.Builder}
     * @return {@link Builder}
     */
    public Builder addButtonsBuilders(List<Button.Builder> builders) {
      if (Core.isCollectionNotEmpty(builders)) {
        nonNullButtonsBuilders().addAll(builders);
      }
      return this;
    }

    /**
     * Cette méthode permet d'ajouter un tableau de {@link Button.Builder}.
     *
     * @param builders tableau de {@link Button.Builder}
     * @return {@link Builder}
     */
    public Builder addButtonsBuilders(Button.Builder... builders) {
      if (!Core.isArrayEmpty(builders)) {
        addButtonsBuilders(List.of(builders));
      }
      return this;
    }
  }

  public Button.Builder buttonBuilder() {
    return new Button.Builder().menuButton(this);
  }

  /**
   * Cette classe représente un bouton.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class Button {
    MenuItem menuItem;

    DefaultMenuItem model;

    DataTable.RecordComponentController componentController;

    void initialize() {
      model = menuItem.builder().build();
    }

    /**
     * Cette méthode permet d'obtenir la visibilité de l'item de menu pour un enregistrement.
     *
     * @param record enregistrement
     * @return visibilité
     */
    public boolean isRenderedByRecord(Object record) {
      return DataTable.RecordComponentController.rendered(record, menuItem, componentController);
    }

    public static Builder builder() {
      return new Builder();
    }

    /**
     * Cette classe représente un constructeur.
     *
     * @author Christian
     *
     */
    @Getter
    @Setter
    @Accessors(chain = true, fluent = true)
    public static class Builder {
      MenuItem.Builder menuItemBuilder;
      MenuButton menuButton;
      Function<Object, Boolean> renderedFunction;

      /**
       * Cette méthode permet de construire.
       *
       * @return {@link Button}
       */
      public Button build() {
        Button button = new Button();
        Core.throwIllegalArgumentExceptionIfNull(menuItemBuilder,
            "Le constructeur d'élément de menu est requis");
        button.menuItem = menuItemBuilder.build();
        Core.runIfNotNull(renderedFunction, () -> {
          button.componentController = new DataTable.RecordComponentController();
          button.componentController.setRenderedFunction(renderedFunction);
        });
        Core.runIfNotNull(menuButton, () -> menuButton.buttons().add(button));
        return button;
      }

    }
  }
}
