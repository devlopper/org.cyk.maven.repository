package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une opération, action fonctionnelle qu'un Processus expose.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class OperationDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasProcessIdentifierDto, HasProcessAsStringDto {

  /**
   * Description de l'opération.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Référence optionnelle vers le Cas d'Utilisation du module propriétaire (ex: CU_DOC_004) —
   * best-effort, non garantie à jour, jamais utilisée par une règle de gestion.
   */
  @JsonbProperty(JSON_USE_CASE_REFERENCE)
  private String useCaseReference;

  /**
   * Identifiant du Processus auquel cette opération est obligatoirement rattachée.
   */
  @JsonbProperty(JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  /**
   * Libellé du Processus auquel cette opération est rattachée.
   */
  @JsonbProperty(JSON_PROCESS_AS_STRING)
  private String processAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idOperation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "operationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "opération";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "opérations";

  /**
   * Identifiant json pour {@link #useCaseReference}.
   */
  public static final String JSON_USE_CASE_REFERENCE = "referenceCasUtilisation";
}
