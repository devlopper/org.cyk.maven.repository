package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant arbitré pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountN2AsString {

  /**
   * Obtient le montant arbitré pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant arbitré pour l'année N+2 sous forme de chaîne de caractères
   */
  String getArbitratedAmountN2AsString();

  /**
   * Définit le montant arbitré pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param arbitratedAmountN2AsString le montant arbitré pour l'année N+2 sous forme de chaîne de
   *        caractères
   */
  void setArbitratedAmountN2AsString(String arbitratedAmountN2AsString);

  /**
   * Identifiant java du montant arbitré pour l'année N+2, sous forme de chaîne de caractères.
   */
  String FIELD_ARBITRATED_AMOUNT_N2_AS_STRING =
      "arbitratedAmountN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName