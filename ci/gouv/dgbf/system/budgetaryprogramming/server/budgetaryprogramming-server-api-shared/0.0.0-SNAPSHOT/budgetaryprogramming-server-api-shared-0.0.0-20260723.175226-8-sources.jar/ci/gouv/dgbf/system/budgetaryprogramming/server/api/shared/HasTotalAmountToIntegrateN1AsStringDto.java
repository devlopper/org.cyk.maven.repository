package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateN1AsStringDto
    extends HasTotalAmountToIntegrateN1AsString {

  /**
   * Identifiant json du montant total à intégrer pour l'année N+1,
   * sous forme de chaîne de caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_INTEGRATE_N1_AS_STRING =
      "montantTotalAIntegrerN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName