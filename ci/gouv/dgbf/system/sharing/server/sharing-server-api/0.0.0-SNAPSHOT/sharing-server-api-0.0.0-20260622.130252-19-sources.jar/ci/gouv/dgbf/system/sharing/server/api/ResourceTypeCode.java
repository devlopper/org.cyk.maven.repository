package ci.gouv.dgbf.system.sharing.server.api;

/**
 * Cette classe représente les codes de types de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
public class ResourceTypeCode {

  private ResourceTypeCode() {

  }

  /**
   * Exercice.
   */
  public static final String EXERCISE = "EXERCICE";
  
  /**
   * Section.
   */
  public static final String SECTION = "SECTION";
  
  /**
   * Unité administrative.
   */
  public static final String ADMINISTRATIVE_UNIT = "UNITE_ADMINISTRATIVE";
  
  /**
   * Unité de spécialisation du budget.
   */
  public static final String BUDGET_SPECIALIZATION_UNIT = "UNITE_SPECIALISATION_BUDGET";
  
  /**
   * Action.
   */
  public static final String ACTION = "ACTION";
  
  /**
   * Activité.
   */
  public static final String ACTIVITY = "ACTIVITE";
  
  /**
   * Dossier.
   */
  public static final String FOLDER = "DOSSIER";
  
  /**
   * Tâche.
   */
  public static final String TASK = "TACHE";

  /**
   * Fichier.
   */
  public static final String FILE = "FILE";

  /**
   * Fichier de groupe.
   */
  public static final String FILE_GROUP = "FICHIER_GROUPE";
}
