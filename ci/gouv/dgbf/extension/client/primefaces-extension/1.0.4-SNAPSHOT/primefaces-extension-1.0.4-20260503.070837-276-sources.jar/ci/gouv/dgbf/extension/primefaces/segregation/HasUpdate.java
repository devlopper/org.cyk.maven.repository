package ci.gouv.dgbf.extension.primefaces.segregation;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.Core.ConcatenateArguments;
import ci.gouv.dgbf.extension.core.NonBlankStringList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Cette interface représente une entité avec une notion de mise à jour de composnant.
 *
 * @author Christian
 *
 */
public interface HasUpdate {

  /**
   * Cette méthode permet d'obtenir la chaine de caractères des références à mettre à jour.
   *
   * @return chaine de caractères des références à mettre à jour
   */
  String getUpdate();

  /**
   * Cette méthode permet d'assigner la chaine de caractères des références à mettre à jour.
   *
   * @param update chaine de caractères des références à mettre à jour
   */
  void setUpdate(String update);

  /**
   * Cette méthode permet d'ajouter un ensemble de chaines de caractères de références à mettre à
   * jour.
   *
   * @param updates ensemble de chaines de caractères des références à mettre à jour
   */
  default void addUpdates(Set<String> updates) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(getUpdate())
        .add(Optional.ofNullable(updates).orElse(Collections.emptySet()).stream().toList());
    setUpdate(Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(" ")));
  }

  /**
   * Cette méthode permet d'ajouter un tableau de chaines de caractères de références à mettre à
   * jour.
   *
   * @param updates tableau de chaines de caractères des références à mettre à jour
   */
  default void addUpdates(String... updates) {
    addUpdates(Arrays.stream(Optional.ofNullable(updates).orElse(new String[] {}))
        .collect(Collectors.toSet()));
  }

  /**
   * Cette méthode permet d'ajouter une chaine de caractères de références à mettre à jour.
   *
   * @param update chaine de caractères des références à mettre à jour
   */
  default void addUpdate(String update) {
    addUpdates(update);
  }
}
