package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * Cette énumération représente les graphiques de {@link BudgetAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@AllArgsConstructor
@Getter
public enum BudgetAdministrativeUnitChart {

  /**
   * Compte employé par catégorie.
   */
  EMPLOYEE_BY_CATEGORY_COUNT(BudgetAdministrativeUnitChartCode.EMPLOYEE_BY_CATEGORY_COUNT,
      "Nombre employé par catégorie")

  ;

  /**
   * Code.
   */
  String code;

  String name;

  /**
   * Cette méthode permet d'obtenir {@link BudgetAdministrativeUnitChart} par code.
   *
   * @param code code
   * @return {@link BudgetAdministrativeUnitChart}
   */
  public static BudgetAdministrativeUnitChart getByCode(String code) {
    return Stream.of(BudgetAdministrativeUnitChart.values())
        .filter(status -> status.getCode().equals(code)).findFirst().orElse(null);
  }
}
