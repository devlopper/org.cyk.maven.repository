package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasAcceptableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasDeferableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasRejectableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasSendableToLitigationDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasSubmittableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasTakeChargeableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link PayrollElementClaimDto}. N'étend pas
 * {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link PayrollElementClaimDto} n'a ni code ni nom propres.
 *
 * @author akm
 *
 */
@Path(PayrollElementClaimService.PATH)
@Tag(name = "Gestion des réclamations")
public interface PayrollElementClaimService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "reclamations";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface PayrollElementClaimSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollElementClaimTypeDto}.
     *
     * @return l'identifiant de {@link PayrollElementClaimTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollElementClaimTypeDto}.
     *
     * @param typeIdentifier l'identifiant de {@link PayrollElementClaimTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir la nature de la réclamation.
     *
     * @return la nature de la réclamation
     */
    String getNature();

    /**
     * Cette méthode permet d'assigner la nature de la réclamation.
     *
     * @param nature la nature de la réclamation
     */
    void setNature(String nature);

    /**
     * Cette méthode permet d'obtenir le commentaire libre de l'Émetteur.
     *
     * @return le commentaire libre de l'Émetteur
     */
    String getComment();

    /**
     * Cette méthode permet d'assigner le commentaire libre de l'Émetteur.
     *
     * @param comment le commentaire libre de l'Émetteur
     */
    void setComment(String comment);

    /**
     * {@link PayrollElementClaimDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = PayrollElementClaimDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link PayrollElementClaimDto#JSON_NATURE}.
     */
    String JSON_NATURE = PayrollElementClaimDto.JSON_NATURE;

    /**
     * {@link PayrollElementClaimDto#JSON_COMMENT}.
     */
    String JSON_COMMENT = PayrollElementClaimDto.JSON_COMMENT;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_RECLAMATION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollElementClaimDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollElementClaimCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayrollElementClaimSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_COMMENT)
    private String comment;

    /**
     * Adresse email de contact, facultative -- figée à cette Soumission (RG_REP_SOU_02, jamais
     * modifiable ensuite, contrairement à {@link #comment}), non partagée avec
     * {@link PayrollElementClaimSaveRequestDto} pour cette raison.
     */
    @Email
    @JsonbProperty(JSON_EMAIL_ADDRESS)
    private String emailAddress;

    /**
     * Identifiant du Groupe de Documents constituant le dossier de pièces de la réclamation,
     * déjà créé côté module {@code documentation} (RG_REP_PCE_02).
     */
    @NotNull
    @JsonbProperty(JSON_DOCUMENTS_GROUP_IDENTIFIER)
    private String documentsGroupIdentifier;

    /**
     * Identifiant du FAE pour le compte duquel la réclamation est déposée (RU_REP_003) --
     * facultatif : {@code null} pour une réclamation déposée par le FAE pour lui-même (cas
     * majoritaire), auquel cas le serveur retient {@link #getAuditWho()} (RG_REP_SOU_02).
     * Distinct de l'Émetteur ({@link #getAuditWho()}, toujours l'auteur réel du dépôt), qui reste
     * inchangé même quand ce champ est renseigné.
     */
    @JsonbProperty(JSON_CONCERNED_FUNCTIONARY_IDENTIFIER)
    private String concernedFunctionaryIdentifier;

    /**
     * Instantané de la structure du FAE concerné choisie à la soumission (RU_REP_003) --
     * facultatif : {@code null} si le FAE n'a qu'une structure, ou si {@link
     * #concernedFunctionaryIdentifier} est vide.
     */
    @JsonbProperty(JSON_CONCERNED_STRUCTURE)
    private Map<String, String> concernedStructure;

    /**
     * Identifiant json {@link #documentsGroupIdentifier}.
     */
    public static final String JSON_DOCUMENTS_GROUP_IDENTIFIER =
        PayrollElementClaimDto.JSON_DOCUMENTS_GROUP_IDENTIFIER;

    /**
     * Identifiant json {@link #concernedFunctionaryIdentifier}.
     */
    public static final String JSON_CONCERNED_FUNCTIONARY_IDENTIFIER =
        PayrollElementClaimDto.JSON_CONCERNED_FUNCTIONARY_IDENTIFIER;

    /**
     * Identifiant json {@link #concernedStructure}.
     */
    public static final String JSON_CONCERNED_STRUCTURE =
        PayrollElementClaimDto.JSON_CONCERNED_STRUCTURE;

    /**
     * Identifiant json {@link #emailAddress}.
     */
    public static final String JSON_EMAIL_ADDRESS = PayrollElementClaimDto.JSON_EMAIL_ADDRESS;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RECLAMATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class PayrollElementClaimGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollElementClaimDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollElementClaimDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_RECLAMATION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_RECLAMATION";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre (RU_REP_015, décompte par onglet du portefeuille).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RECLAMATION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PayrollElementClaimDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollElementClaimDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_RECLAMATION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollElementClaimDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollElementClaimUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayrollElementClaimSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_NATURE)
    private String nature;

    @JsonbProperty(JSON_COMMENT)
    private String comment;
  }

  /**
   * Cette classe représente la base des réponses de traitement (motif R44/R45).
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<PayrollElementClaimStatus>, HasStatusAsStringDto,
      HasSubmittableDto, HasTakeChargeableDto, HasAcceptableDto, HasRejectableDto,
      HasDeferableDto, HasSendableToLitigationDto {

    @JsonbProperty(JSON_STATUS)
    private PayrollElementClaimStatus status;

    @JsonbProperty(JSON_STATUS_AS_STRING)
    private String statusAsString;

    @JsonbProperty(JSON_SUBMITTABLE)
    private Boolean submittable;

    @JsonbProperty(JSON_TAKE_CHARGEABLE)
    private Boolean takeChargeable;

    @JsonbProperty(JSON_ACCEPTABLE)
    private Boolean acceptable;

    @JsonbProperty(JSON_REJECTABLE)
    private Boolean rejectable;

    @JsonbProperty(JSON_DEFERABLE)
    private Boolean deferable;

    @JsonbProperty(JSON_SENDABLE_TO_LITIGATION)
    private Boolean sendableToLitigation;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut et de la nature.
     *
     * @param status statut
     * @param nature nature ({@link PayrollElementClaimDto#NATURE_ORDINARY}/
     *        {@link PayrollElementClaimDto#NATURE_LITIGATION})
     */
    public void initialize(PayrollElementClaimStatus status, String nature) {
      this.status = status;
      this.statusAsString = status == null ? null : status.getName();
      this.submittable = PayrollElementClaimStatus.SUBMITTED.getPrevious().contains(status);
      this.takeChargeable = PayrollElementClaimStatus.IN_CHARGE.getPrevious().contains(status);
      this.acceptable = PayrollElementClaimStatus.ACCEPTED.getPrevious().contains(status);
      this.rejectable = PayrollElementClaimStatus.REJECTED.getPrevious().contains(status);
      this.deferable = PayrollElementClaimStatus.DEFERRED.getPrevious().contains(status);
      // Contentieux (RG_REP_SOU_07/RG_REP_PEC_07) : discriminant classificatoire sans effet sur
      // le statut -- disponible tant que la réclamation est Prise en charge et pas déjà au
      // contentieux.
      this.sendableToLitigation = PayrollElementClaimStatus.IN_CHARGE.equals(status)
          && !PayrollElementClaimDto.NATURE_LITIGATION.equals(nature);
    }

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut seul -- {@link
     * #sendableToLitigation} toujours faux (jamais {@link PayrollElementClaimStatus#IN_CHARGE} à
     * l'issue de la Soumission, seul appelant restant de cette variante).
     *
     * @param status statut
     */
    public void initialize(PayrollElementClaimStatus status) {
      initialize(status, PayrollElementClaimDto.NATURE_LITIGATION);
    }
  }

  /**
   * Identifiant du service de Soumission (RG_REP_STA_01).
   */
  String SUBMIT_IDENTIFIER = "SOUMISSION_RECLAMATION";

  /**
   * Chemin du service de Soumission.
   */
  String SUBMIT_PATH = "soumission";

  /**
   * Cette méthode permet de soumettre {@link PayrollElementClaimDto} (RG_REP_STA_01).
   *
   * @param request requête
   * @return réponse
   */
  @Path(SUBMIT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SUBMIT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimSubmitResponseDto.class))})
  Response submit(PayrollElementClaimSubmitRequestDto request);

  /**
   * Cette classe représente la requête de Soumission.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimSubmitRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Soumission.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimSubmitResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Prise en charge (RG_REP_PEC_01).
   */
  String TAKE_CHARGE_IDENTIFIER = "PRISE_EN_CHARGE_RECLAMATION";

  /**
   * Chemin du service de Prise en charge.
   */
  String TAKE_CHARGE_PATH = "prise-en-charge";

  /**
   * Cette méthode permet de prendre en charge {@link PayrollElementClaimDto} (RG_REP_PEC_01) --
   * réservée à l'Agent de Traitement (RU_REP_005).
   *
   * @param request requête
   * @return réponse
   */
  @Path(TAKE_CHARGE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TAKE_CHARGE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimTakeChargeResponseDto.class))})
  Response takeCharge(PayrollElementClaimTakeChargeRequestDto request);

  /**
   * Cette classe représente la requête de Prise en charge.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimTakeChargeRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de Prise en charge.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimTakeChargeResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service d'Acceptation (RG_REP_PEC_08).
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_RECLAMATION";

  /**
   * Chemin du service d'Acceptation.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet d'accepter {@link PayrollElementClaimDto} (RG_REP_PEC_08) -- terminal
   * positif, immédiat quel que soit le circuit de Revue de Valeur Réclamée qui en découle
   * (RG_REP_STA_01/02/03).
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = ACCEPT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimAcceptResponseDto.class))})
  Response accept(PayrollElementClaimAcceptRequestDto request);

  /**
   * Cette classe représente la requête d'Acceptation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimAcceptRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse d'Acceptation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimAcceptResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Rejet (RG_REP_PEC_05).
   */
  String REJECT_IDENTIFIER = "REJET_RECLAMATION";

  /**
   * Chemin du service de Rejet.
   */
  String REJECT_PATH = "rejet";

  /**
   * Cette méthode permet de rejeter {@link PayrollElementClaimDto} (RG_REP_PEC_05) -- terminal,
   * motif obligatoire (FA1 bloque si absent).
   *
   * @param request requête
   * @return réponse
   */
  @Path(REJECT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REJECT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimRejectResponseDto.class))})
  Response reject(PayrollElementClaimRejectRequestDto request);

  /**
   * Cette classe représente la requête de Rejet.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimRejectRequestDto extends ByIdentifierRequestDto {

    @NotNull
    @JsonbProperty(JSON_MOTIF)
    private String motif;
  }

  /**
   * Cette classe représente la réponse de Rejet.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimRejectResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de Différé (RG_REP_PEC_06).
   */
  String DEFER_IDENTIFIER = "DIFFERE_RECLAMATION";

  /**
   * Chemin du service de Différé.
   */
  String DEFER_PATH = "differe";

  /**
   * Cette méthode permet de différer {@link PayrollElementClaimDto} (RG_REP_PEC_06) -- motif
   * facultatif, l'Émetteur complète/corrige puis resoumet (retour à Soumise).
   *
   * @param request requête
   * @return réponse
   */
  @Path(DEFER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DEFER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimDeferResponseDto.class))})
  Response defer(PayrollElementClaimDeferRequestDto request);

  /**
   * Cette classe représente la requête de Différé.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimDeferRequestDto extends ByIdentifierRequestDto {

    @JsonbProperty(JSON_MOTIF)
    private String motif;
  }

  /**
   * Cette classe représente la réponse de Différé.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimDeferResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant json du motif de Rejet/Différé.
   */
  String JSON_MOTIF = "motif";

  /**
   * Identifiant du service d'Envoi au contentieux (RG_REP_SOU_07/RG_REP_PEC_07).
   */
  String SEND_TO_LITIGATION_IDENTIFIER = "ENVOI_CONTENTIEUX_RECLAMATION";

  /**
   * Chemin du service d'Envoi au contentieux.
   */
  String SEND_TO_LITIGATION_PATH = "envoi-contentieux";

  /**
   * Cette méthode permet d'envoyer {@link PayrollElementClaimDto} au contentieux
   * (RG_REP_SOU_07/RG_REP_PEC_07) -- simple discriminant classificatoire ({@link
   * PayrollElementClaimDto#NATURE_LITIGATION}), le statut reste inchangé (Prise en charge) et la
   * réclamation continue ensuite le même circuit Accepter/Rejeter/Différer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SEND_TO_LITIGATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SEND_TO_LITIGATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = PayrollElementClaimSendToLitigationResponseDto.class))})
  Response sendToLitigation(PayrollElementClaimSendToLitigationRequestDto request);

  /**
   * Cette classe représente la requête d'Envoi au contentieux.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimSendToLitigationRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse d'Envoi au contentieux.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class PayrollElementClaimSendToLitigationResponseDto extends ProcessResponseDto {

  }
}
