package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.SsoUserRoleService.SsoUserRoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.SsoUserRoleService.SsoUserRoleGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.SsoUserRoleService.SsoUserRoleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SsoUserRoleService}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SsoUserRoleClient extends AbstractClient<SsoUserRoleService>
    implements GetByIdentifier<SsoUserRoleDto>,
    GetMany<SsoUserRoleGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SsoUserRoleClient service(SsoUserRoleService service) {
    return (SsoUserRoleClient) super.service(service);
  }

  /**
   * {@link SsoRoleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SsoUserRoleCreateRequestDto request) {
    return new CreateExecutor(SsoUserRoleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SsoRoleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SsoUserRoleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SsoUserRoleGetManyResponseDto>(SsoUserRoleGetManyResponseDto.class,
        SsoRoleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SsoRoleService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SsoUserRoleGetManyResponseDto getMany(ProjectionDto projection,
                                               FilterDto filter, PageDto page,
                                               String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SsoRoleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SsoUserRoleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SsoUserRoleDto>(SsoUserRoleDto.class,
        SsoUserRoleService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link SsoUserRoleService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SsoUserRoleDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                               String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SsoUserRoleService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SsoUserRoleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SsoUserRoleDto>(SsoUserRoleDto.class,
        SsoUserRoleService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SsoUserRoleService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SsoUserRoleDto getByIdentifier(String identifier, ProjectionDto projection,
                                        String auditWho,
                                        String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SsoUserRoleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SsoUserRoleUpdateRequestDto request) {
    return new IdentifiableExecutor(SsoUserRoleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SsoUserRoleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SsoUserRoleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SsoUserRoleService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link SsoUserRoleService#doImport}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto doImport(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(SsoUserRoleService.IMPORT_IDENTIFIER)
        .execute(() -> service().doImport(request));
  }
}
