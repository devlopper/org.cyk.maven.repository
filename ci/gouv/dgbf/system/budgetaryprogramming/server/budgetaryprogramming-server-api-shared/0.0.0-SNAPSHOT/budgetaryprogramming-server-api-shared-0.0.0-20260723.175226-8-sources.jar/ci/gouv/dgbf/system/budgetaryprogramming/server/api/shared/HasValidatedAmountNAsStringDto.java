package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de montant validé à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountNAsStringDto extends HasValidatedAmountNAsString {

  /**
   * Identifiant json du montant validé à l'horizon N, sous forme de chaîne de caractères.
   */
  String JSON_VALIDATED_AMOUNT_N_AS_STRING = "montantValideNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
