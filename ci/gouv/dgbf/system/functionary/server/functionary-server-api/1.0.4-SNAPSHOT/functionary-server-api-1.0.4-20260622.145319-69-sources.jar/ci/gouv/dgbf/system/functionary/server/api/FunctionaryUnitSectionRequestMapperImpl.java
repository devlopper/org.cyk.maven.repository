package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionaryUnitSectionDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FunctionaryUnitSectionRequestMapperImpl implements FunctionaryUnitSectionRequestMapper {

    @Override
    public FunctionaryUnitSectionService.FunctionaryUnitSectionCreateRequestDto mapCreate(FunctionaryUnitSectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionaryUnitSectionService.FunctionaryUnitSectionCreateRequestDto functionaryUnitSectionCreateRequestDto = new FunctionaryUnitSectionService.FunctionaryUnitSectionCreateRequestDto();

        functionaryUnitSectionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionaryUnitSectionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        functionaryUnitSectionCreateRequestDto.setUnitSectionIdentifier( arg0.getUnitSectionIdentifier() );

        return functionaryUnitSectionCreateRequestDto;
    }

    @Override
    public FunctionaryUnitSectionService.FunctionaryUnitSectionUpdateRequestDto mapUpdate(FunctionaryUnitSectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionaryUnitSectionService.FunctionaryUnitSectionUpdateRequestDto functionaryUnitSectionUpdateRequestDto = new FunctionaryUnitSectionService.FunctionaryUnitSectionUpdateRequestDto();

        functionaryUnitSectionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionaryUnitSectionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        functionaryUnitSectionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionaryUnitSectionUpdateRequestDto.setUnitSectionIdentifier( arg0.getUnitSectionIdentifier() );

        return functionaryUnitSectionUpdateRequestDto;
    }
}
