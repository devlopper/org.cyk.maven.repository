package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasAcceptableDto;
import ci.gouv.dgbf.extension.core.segregation.HasCancelableDto;
import ci.gouv.dgbf.extension.core.segregation.HasRefusableDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusCommentDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleIdentifierDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une demande de rôle faite par un utilisateur sur une application.
 *
 * @author BoobaCool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RoleSolicitationDto extends AbstractIdentifiableAuditableDto
    implements HasUserIdentifierDto, HasUserAsStringDto, HasRoleIdentifierDto,
    HasRoleAsStringDto, HasStatusDto<RoleSolicitationStatus>, HasStatusAsStringDto,
    HasStatusCommentDto, HasAcceptableDto, HasRefusableDto, HasCancelableDto {

  /**
   * Identifiant de l'utilisateur demandeur.
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Représentation en chaine de caractères de l'utilisateur demandeur.
   */
  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  /**
   * Identifiant du rôle demandé.
   */
  @JsonbProperty(JSON_ROLE_IDENTIFIER)
  private String roleIdentifier;

  /**
   * Représentation en chaine de caractères du rôle demandé.
   */
  @JsonbProperty(JSON_ROLE_AS_STRING)
  private String roleAsString;

  /**
   * Statut de la demande.
   */
  @JsonbProperty(JSON_STATUS)
  private RoleSolicitationStatus status;

  /**
   * Représentation en chaine de caractères du statut.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Commentaire du dernier changement de statut (ex : motif du refus).
   */
  @JsonbProperty(JSON_STATUS_COMMENT)
  private String statusComment;

  /**
   * Vrai si la demande peut être acceptée.
   */
  @JsonbProperty(JSON_ACCEPTABLE)
  private Boolean acceptable;

  /**
   * Vrai si la demande peut être refusée.
   */
  @JsonbProperty(JSON_REFUSABLE)
  private Boolean refusable;

  /**
   * Vrai si la demande peut être annulée.
   */
  @JsonbProperty(JSON_CANCELABLE)
  private Boolean cancelable;

  /**
   * Motif de la demande.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Identifiant json pour {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDemandeRole";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "demandeRoleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "demande de rôle";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "demandes de rôle";
}
