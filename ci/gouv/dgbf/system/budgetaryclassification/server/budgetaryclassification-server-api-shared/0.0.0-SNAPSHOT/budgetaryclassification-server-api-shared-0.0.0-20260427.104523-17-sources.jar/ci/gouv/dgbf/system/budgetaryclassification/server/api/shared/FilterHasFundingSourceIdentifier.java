package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de source de financement.
 *
 * @author Christian
 */
public interface FilterHasFundingSourceIdentifier extends HasFundingSourceIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant exercice.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFundingSourceIdentifier(FilterDto filter) {
    setFundingSourceIdentifier(FundingSourceIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant exercice de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterFundingSourceIdentifier(FilterDto filter) {
    FundingSourceIdentifierFilter.set(filter, getFundingSourceIdentifier());
  }

}
