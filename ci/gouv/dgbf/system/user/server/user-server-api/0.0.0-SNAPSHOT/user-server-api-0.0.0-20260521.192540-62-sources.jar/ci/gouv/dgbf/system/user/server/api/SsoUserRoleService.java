package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SsoUserRoleDto}.
 *
 * @author BoobaCool
 */
@Path(value = SsoUserRoleService.PATH)
@Tag(name = "Gestion des privilèges utilisateurs référencés")
public interface SsoUserRoleService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "users-roles-references";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author BoobaCool
   */
  interface SsoUserRoleSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le nom du role.
     *
     * @return le nom du role
     */
    String getRoleName();

    /**
     * Cette méthode permet de modifier le nom du role.
     *
     * @param roleName le nom du role
     */
    void setRoleName(String roleName);

    /**
     * {@link SsoUserRoleDto#JSON_ROLE_NAME}.
     */
    String JSON_ROLE_NAME = SsoUserRoleDto.JSON_ROLE_NAME;

    /**
     * Cette méthode permet d'obtenir le nom de l'utilisateur.
     *
     * @return le nom d'utilisateur
     */
    String getUsername();


    /**
     * Cette méthode permet de modifier le nom de l'utilisateur.
     *
     * @param username le nom de l'utilisateur
     */
    void setUsername(String username);

    /**
     * {@link SsoUserRoleDto#JSON_USERNAME}.
     */
    String JSON_USERNAME = SsoUserRoleDto.JSON_USERNAME;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_USER_ROLE_REFERENCE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SsoUserRoleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class SsoUserRoleCreateRequestDto extends AbstractCodableCreateRequestJsonDto
      implements SsoUserRoleSaveRequestDto {


    @JsonbProperty(JSON_ROLE_NAME)
    private String roleName;

    @JsonbProperty(JSON_USERNAME)
    private String username;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_USER_ROLE_REFERENCE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = SsoUserRoleGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class SsoUserRoleGetManyResponseDto
      extends AbstractGetByPageResponseDto<SsoUserRoleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SsoUserRoleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_USER_ROLE_REFERENCE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SsoUserRoleDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_USER_ROLE_REFERENCE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SsoUserRoleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_USER_ROLE_REFERENCE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SsoUserRoleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class SsoUserRoleUpdateRequestDto extends ByIdentifierRequestDto
      implements SsoUserRoleSaveRequestDto {
    @JsonbProperty(JSON_ROLE_NAME)
    private String roleName;

    @JsonbProperty(JSON_USERNAME)
    private String username;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_USER_ROLE_REFERENCE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);


  /**
   * Identifiant du service d'importation.
   */
  String IMPORT_IDENTIFIER = "IMPORTATION_ROLE_UTILISATEUR_REFERENCE";

  /**
   * Chemin du service d'importation.
   */
  String IMPORT_PATH = "importation";

  /**
   * Cette méthode permet d'importer {@link SsoUserRoleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(IMPORT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = IMPORT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response doImport(ByIdentifierRequestDto request);
}
