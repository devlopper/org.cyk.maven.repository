package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureNatureClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureNatureDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureNatureService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ExpenditureNatureDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ExpenditureNatureSelectOneController extends AbstractSelectOneIdentifiableController<
    ExpenditureNatureDto, GetManyResponseDto, ExpenditureNatureClient> {

  @Inject
  @Getter
  ExpenditureNatureClient client;

  protected ExpenditureNatureSelectOneController() {
    super(ExpenditureNatureDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
