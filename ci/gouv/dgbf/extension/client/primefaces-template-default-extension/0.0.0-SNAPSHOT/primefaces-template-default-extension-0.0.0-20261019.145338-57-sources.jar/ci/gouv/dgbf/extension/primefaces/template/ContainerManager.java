package ci.gouv.dgbf.extension.primefaces.template;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette class représente le gestionnaire du conteneur.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Getter
@Setter
@Named
public class ContainerManager {

  private String sidebar;
  private String layout;
  private String topbar;
  private String sidebarSize;
  private String sidebarImage;
  private String preloader;
  private String theme;
  private String themeColors;
  private String sidebarVisibility;
  private String layoutStyle;
  private String bsTheme;
  private String layoutWidth;
  private String layoutPosition;
  private String bodyImage;
  private String sidebarUserShow;
  private String styleContentColorManager;

  /**
   * Active la charte graphique DGBF sur les écrans privés (constitution-ui.md §3.4). Faux par
   * défaut : chaque module l'active par {@value #CHARTE_ENABLED_PROPERTY} dans sa configuration.
   */
  @ConfigProperty(name = CHARTE_ENABLED_PROPERTY, defaultValue = "false")
  boolean charteEnabled;


  /**
   * Cette méthode permet de construire.
   */
  public ContainerManager() {
    layout = "semibox";
    topbar = "light";
    sidebar = "dark";
    sidebarSize = "lg";
    sidebarImage = "none";
    preloader = "disable";
    theme = "saas";
    themeColors = "default";
    sidebarVisibility = "show";
    layoutStyle = "default";
    bsTheme = "";
    layoutWidth = "fluid";
    layoutPosition = "fixed";
    bodyImage = "none";
    sidebarUserShow = "";
    styleContentColorManager = "";
  }

  static final String CHARTE_ENABLED_PROPERTY = "dgbf.charte.enabled";
}
