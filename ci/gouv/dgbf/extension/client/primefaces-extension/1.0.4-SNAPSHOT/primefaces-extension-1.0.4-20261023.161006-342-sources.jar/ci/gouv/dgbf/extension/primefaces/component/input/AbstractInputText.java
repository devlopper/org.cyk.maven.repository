package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une saisie de texte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInputText extends AbstractInput<String> {

  protected String placeholder;
  /** Lecture seule : la valeur reste affichée et soumise, mais n'est plus modifiable. */
  protected boolean readOnly;
  /** Nombre maximal de caractères saisissables (par défaut : pas de limite). */
  protected Integer maxLength = Integer.MAX_VALUE;

  public AbstractInputText computePlaceholderFromOutputLabelValue() {
    placeholder = "Saisir " + outputLabel().getValue();
    return this;
  }
}
