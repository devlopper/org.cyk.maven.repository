package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ActivityDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = ActivityService.PATH)
@Tag(name = "Gestion des activités")
public interface ActivityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une activité",
      description = "Ce service permet de créer une activité")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ActivityCreateRequestDto request);

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_ACTIVITE";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le nombre de {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des activités")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);


  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityDto.class))})
  Response getOne(GetOneRequestDto request);


  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);


  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ActivityUpdateRequestDto request);


  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   */
  interface ActivitySaveRequestDto {


    /**
     * Cette méthode permet d'obtenir l'identitant de {@link LocalAuthorityDto}.
     *
     * @return identifiant de {@link LocalAuthorityDto}
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
     *
     * @param identifier identifiant de {@link LocalAuthorityDto}
     */
    void setLocalAuthorityIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link ActivityNatureDto}.
     *
     * @return identitant de {@link ActivityNatureDto}
     */
    String getNatureIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ActivityNatureDto}.
     *
     * @param identifier identifiant de {@link ActivityNatureDto}
     */
    void setNatureIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link ActivityCategoryDto}.
     *
     * @return identifiant de {@link ActivityCategoryDto}
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ActivityCategoryDto}.
     *
     * @param identifier identifiant de {@link ActivityCategoryDto}
     */
    void setCategoryIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link FunctionalAccountDto}.
     *
     * @return identifiant de {@link FunctionalAccountDto}
     */
    String getFunctionalAccountIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FunctionalAccountDto}.
     *
     * @param identifier identifiant de {@link FunctionalAccountDto}
     */
    void setFunctionalAccountIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link BeneficiaryDto}.
     *
     * @return identifiant de {@link BeneficiaryDto}
     */
    String getBeneficiaryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link BeneficiaryDto}.
     *
     * @param identifier identifiant de {@link BeneficiaryDto}
     */
    void setBeneficiaryIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identitant de {@link ExpertiseDomainDto}.
     *
     * @return identifiant de {@link ExpertiseDomainDto}
     */
    String getExpertiseDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ExpertiseDomainDto}.
     *
     * @param identifier identifiant de {@link ExpertiseDomainDto}
     */
    void setExpertiseDomainIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    long getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(long amount);

    /**
     * Cette méthode permet d'obtenir la catégorie.
     *
     * @return catégorie
     */
    ActivityCategory getCategoryEnum();

    /**
     * Cette méthode permet d'assigner la catégorie.
     *
     * @param categoryEnum catégorie
     */
    void setCategoryEnum(ActivityCategory categoryEnum);

    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return la description de {@link ActivityDto}
     */
    String getDescription();

    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description description
     */
    void setDescription(String description);

    /**
     * Cette méthode permet d'obtenir la justification.
     *
     * @return la justification de {@link ActivityDto}
     */
    String getJustification();

    /**
     * Cette méthode permet d'assigner la justification.
     *
     * @param justification justification
     */
    void setJustification(String justification);

    /**
     * Cette méthode permet d'obtenir l'identifiant l'activité à laquelle on fait référence.
     *
     * @return la référence operation de {@link ActivityDto}
     */
    String getReferencedActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'activité à laquelle on fait référence.
     *
     * @param referencedActivityIdentifier identifiant de l'activity
     */
    void setReferencedActivityIdentifier(String referencedActivityIdentifier);

    /**
     * Cette méthode permet d'obtenir la référence au PND.
     *
     * @return la référence au PND de {@link ActivityDto}
     */
    String getPndReference();

    /**
     * Cette méthode permet d'assigner la référence au PND.
     *
     * @param pndReference référence du PND
     */
    void setPndReference(String pndReference);

    /**
     * Cette méthode permet d'obtenir la référence eventuelle.
     *
     * @return la référence éventuelle de {@link ActivityDto}
     */
    String getEventualReference();

    /**
     * Cette méthode permet d'assigner la référence éventuelle.
     *
     * @param eventualReference autres références éventuelles
     */
    void setEventualReference(String eventualReference);


    /**
     * Cette méthode permet d'obtenir l'identifiant de progrramme triennal permettant de créer une
     * activité de programme triennal.
     *
     * @return l'identifiant de {@link TriennialProgramDto}
     */
    String getTriennialProgramIdentifier();


    /**
     * Cette méthode permet d'assigner l'identifiant de progrramme triennal.
     *
     * @param triennialProgramIdentifier identifiant de programme triennal
     */
    void setTriennialProgramIdentifier(String triennialProgramIdentifier);

    /**
     * Cette méthode permet d'obtenir la retentue de garantie.
     *
     * @return guaranteeRetention retentue de garantie
     */
    long getGuaranteeRetention();

    /**
     * Cette méthode permet d'assigner la retentue de garantie.
     *
     * @param guaranteeRetention retentue de garantie
     */
    void setGuaranteeRetention(long guaranteeRetention);

    /**
     * Cette méthode permet d'obtenir le budget de prise en charge avant report.
     *
     * @return yearBudgetBeforeCarryover Budget de prise en charge avant report
     */
    Integer getYearBudgetBeforeCarryover();

    /**
     * Cette méthode permet d'assigner le budget de prise en charge avant report.
     *
     * @param yearBudgetBeforeCarryover budget de prise en charge avant report
     */
    void setYearBudgetBeforeCarryover(Integer yearBudgetBeforeCarryover);

    /**
     * Cette méthode permet d'obtenir l'année prévisionnelle de mandatement.
     *
     * @return plannedPaymentYear année prévisionnelle de mandatement
     */
    Integer getPlannedPaymentYear();

    /**
     * Cette méthode permet d'assigner l'année prévisionnelle de mandatement'.
     *
     * @param plannedPaymentYear année prévisionnelle de mandatement
     */
    void setPlannedPaymentYear(Integer plannedPaymentYear);


    /**
     * Cette méthode permet d'obtenir la durée.
     *
     * @return la durée de {@link ActivityDto}
     */
    String getDuration();

    /**
     * Cette méthode permet d'assigner la durée.
     *
     * @param duration durée
     */
    void setDuration(String duration);


    /**
     * Cette méthode permet d'assigner l'impact attendu.
     *
     * @param expectedImpact impact attendu
     */
    void setExpectedImpact(String expectedImpact);

    /**
     * Cette méthode permet d'obtenir l'impact attendu.
     *
     * @return l'impact attendu de {@link ActivityDto}
     */
    String getExpectedImpact();


    /**
     * Cette méthode permet d'assigner l'observation.
     *
     * @param observation bservation
     */
    void setObservation(String observation);

    /**
     * Cette méthode permet d'obtenir l'impact attendu.
     *
     * @return l'observation de {@link ActivityDto}
     */
    String getObservation();


    /**
     * Identifiant json du champ de l'identitant de {@link ActivityNatureDto}.
     */
    public static final String JSON_NATURE_IDENTIFIER = ActivityDto.JSON_NATURE_IDENTIFIER;
    /**
     * Identifiant json du champ de l'identitant de {@link ActivityCategoryDto}.
     */
    public static final String JSON_CATEGORY_IDENTIFIER = ActivityDto.JSON_CATEGORY_IDENTIFIER;
    /**
     * Identifiant json du champ de l'identitant de {@link FunctionalAccountDto}.
     */
    public static final String JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER =
        ActivityDto.JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER;

    /**
     * Identifiant json du champ de l'identitant de {@link BeneficiaryDto}.
     */
    public static final String JSON_BENEFICIARY_IDENTIFIER =
        ActivityDto.JSON_BENEFICIARY_IDENTIFIER;

    /**
     * Identifiant json du champ de l'identitant de {@link ExpertiseDomainDto}.
     */
    public static final String JSON_EXPERTISE_DOMAIN_IDENTIFIER =
        ActivityDto.JSON_EXPERTISE_DOMAIN_IDENTIFIER;
    /**
     * Identifiant json du champ de l'identitant de {@link LocalAuthorityDto}.
     */
    public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
        ActivityDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;
    /**
     * Identifiant json du champ de montant.
     */
    public static final String JSON_AMOUNT = ActivityDto.JSON_AMOUNT;
    /**
     * {@link ActivityCategory}.
     */
    public static final String JSON_CATEGORY = ActivityDto.JSON_CATEGORY;
    /**
     * Identifiant json desctiption.
     */
    String JSON_DESCRIPTION = ActivityDto.JSON_DESCRIPTION;
    /**
     * Identifiant json desctiption.
     */
    String JSON_JUSTIFICATION = ActivityDto.JSON_JUSTIFICATION;
    /**
     * Identifiant json de la référence de l'opération.
     */
    String REFERENCED_ACTIVITY_IDENTIFIER = ActivityDto.JSON_REFERENCED_ACTIVITY_IDENTIFIER;
    /**
     * Identifiant json de la référence au PND.
     */
    String PND_REFERENCE = ActivityDto.JSON_PND_REFERENCE;
    /**
     * Identifiant json de la référence eventuelle.
     */
    String EVENTUAL_REFERENCE = ActivityDto.JSON_EVENTUAL_REFERENCE;


    /**
     * Identifiant json du programme triennal.
     */
    String TRIENNIAL_PROGRAM_IDENTIFIER = "idProgrammeTriennal";


    /**
     * Identifiant json de la retenue de garantie.
     */
    String JSON_GUARANTEE_RETENTION = ActivityDto.JSON_GUARANTEE_RETENTION;

    /**
     * Identifiant json budget de prise en charge avant report.
     */
    String JSON_YEAR_BUDGET_BEFORE_CARRYOVER = "anneeBudgetPriseEnChargeAvantReport";

    /**
     * Identifiant json année prévisionnelle de mandatement.
     */
    String JSON_PLANNED_PAYMENT_YEAR = "anneePrevisionnelPaiement";


    /**
     * Identifiant json de la durée.
     */
    String JSON_DURATION = "duree";

    /**
     * Identifiant json de l'impact attendu.
     */
    String JSON_EXPECTED_IMPACT = "impactAttendu";


    /**
     * Identifiant json des observations sur l'action ou l'opération.
     */
    String JSON_OBSERVATION = "observations";


  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ActivityCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ActivitySaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(JSON_BENEFICIARY_IDENTIFIER)
    private String beneficiaryIdentifier;

    @JsonbProperty(JSON_EXPERTISE_DOMAIN_IDENTIFIER)
    private String expertiseDomainIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    @JsonbProperty(JSON_CATEGORY)
    private ActivityCategory categoryEnum;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_JUSTIFICATION)
    private String justification;

    @JsonbProperty(REFERENCED_ACTIVITY_IDENTIFIER)
    private String referencedActivityIdentifier;

    @JsonbProperty(PND_REFERENCE)
    private String pndReference;

    @JsonbProperty(EVENTUAL_REFERENCE)
    private String eventualReference;

    @JsonbProperty(TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_GUARANTEE_RETENTION)
    private long guaranteeRetention;

    @JsonbProperty(JSON_YEAR_BUDGET_BEFORE_CARRYOVER)
    private Integer yearBudgetBeforeCarryover;

    @JsonbProperty(JSON_PLANNED_PAYMENT_YEAR)
    private Integer plannedPaymentYear;

    @JsonbProperty(JSON_DURATION)
    private String duration;

    @JsonbProperty(JSON_EXPECTED_IMPACT)
    private String expectedImpact;

    @JsonbProperty(JSON_OBSERVATION)
    private String observation;
  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ActivityGetManyResponseDto extends AbstractGetByPageResponseDto<ActivityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ActivityDto> datas;
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ActivityUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ActivitySaveRequestDto {

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_FUNCTIONAL_ACCOUNT_IDENTIFIER)
    private String functionalAccountIdentifier;

    @JsonbProperty(JSON_BENEFICIARY_IDENTIFIER)
    private String beneficiaryIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    @JsonbProperty(JSON_CATEGORY)
    private ActivityCategory categoryEnum;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_JUSTIFICATION)
    private String justification;

    @JsonbProperty(REFERENCED_ACTIVITY_IDENTIFIER)
    private String referencedActivityIdentifier;

    @JsonbProperty(PND_REFERENCE)
    private String pndReference;

    @JsonbProperty(EVENTUAL_REFERENCE)
    private String eventualReference;

    @JsonbProperty(TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;


    @JsonbProperty(JSON_EXPERTISE_DOMAIN_IDENTIFIER)
    private String expertiseDomainIdentifier;

    @JsonbProperty(JSON_GUARANTEE_RETENTION)
    private long guaranteeRetention;

    @JsonbProperty(JSON_YEAR_BUDGET_BEFORE_CARRYOVER)
    private Integer yearBudgetBeforeCarryover;

    @JsonbProperty(JSON_PLANNED_PAYMENT_YEAR)
    private Integer plannedPaymentYear;

    @JsonbProperty(JSON_DURATION)
    private String duration;

    @JsonbProperty(JSON_EXPECTED_IMPACT)
    private String expectedImpact;

    @JsonbProperty(JSON_OBSERVATION)
    private String observation;
  }
}
