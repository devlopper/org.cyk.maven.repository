package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserRole;
import ci.gouv.dgbf.system.user.server.api.UserRoleDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link UserRoleDto} d'un {@link UserDto}.
 *
 * @author BoobaCool
 */
@Named
@ViewScoped
public class UserReadRolesPage extends AbstractUserReadDatasPage {

  @Override
  protected String getListPageOutcome() {
    return "userListPage";
  }

  @Inject
  @Getter
  protected UserRoleController userRoleController;

  @Inject
  UserRights userRights;

  @Override
  public void initializeWhenIdentifiableNotNull(UserDto instance) {
    super.initializeWhenIdentifiableNotNull(instance);
    userRoleController.getFilterController().getFilter()
        .setUserIdentifier(user.getIdentifier());
    userRoleController.initialize();
  }

  /**
   * Cette méthode indique si « Ajouter plusieurs » est proposé : l'Utilisateur connecté a le Droit
   * d'assigner des Rôles pour au moins une Application (TCH_UTI_773, RG_UTI_ROL_16).
   *
   * @return vrai s'il a le Droit
   */
  public boolean isCreateManyRendered() {
    return userRights.isGrantedForAny(UserRole.ASSIGN_USER_ROLE);
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "userReadRolesPage";
}
