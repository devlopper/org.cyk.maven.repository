package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasPositionFieldCode extends HasPositionFieldCode {

  /**
   * Cette méthode permet de mettre à jour le code de {@link PositionField}.
   *
   * @param filter {@link FilterDto}
   */
  default void updatePositionFieldCode(FilterDto filter) {
    setPositionFieldCode(PositionFieldCodeFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour le code de {@link PositionField} de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterPositionFieldCode(FilterDto filter) {
    PositionFieldCodeFilter.set(filter, getPositionFieldCode());
  }

}
