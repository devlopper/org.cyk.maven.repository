package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un dossier.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FolderDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements ActivityContainerableDto {

  /**
   * Description.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Identifiant de {@link FolderTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Identifiant de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Représentation en chaine de caractères du statut.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant de l'identité du responsable.
   */
  @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
  private String responsibleIdentityIdentifier;

  /**
   * Priorité.
   */
  @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
  private String priorityIdentifier;

  /**
   * Représentarion en chaine de caractères de l'identité du responsable.
   */
  @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_AS_STRING)
  private String responsibleIdentityAsString;

  /* Activity */

  @JsonbProperty(JSON_ACTIVITY_COUNT)
  private Integer activityCount;

  @JsonbProperty(JSON_ACTIVITY_COUNT_AS_STRING)
  private String activityCountAsString;

  @JsonbProperty(JSON_CREATED_ACTIVITY_COUNT_AS_STRING)
  private String createdActivityCountAsString;

  @JsonbProperty(JSON_SUSPENDED_ACTIVITY_COUNT_AS_STRING)
  private String suspendedActivityCountAsString;

  @JsonbProperty(JSON_STARTED_ACTIVITY_COUNT)
  private Integer startedActivityCount;

  @JsonbProperty(JSON_STARTED_ACTIVITY_COUNT_AS_STRING)
  private String startedActivityCountAsString;

  @JsonbProperty(JSON_STOPPED_ACTIVITY_COUNT_AS_STRING)
  private String stoppedActivityCountAsString;

  @JsonbProperty(JSON_REALIZED_ACTIVITY_COUNT)
  private Integer realizedActivityCount;

  @JsonbProperty(JSON_REALIZED_ACTIVITY_COUNT_AS_STRING)
  private String realizedActivityCountAsString;

  @JsonbProperty(JSON_LATE_ACTIVITY_COUNT)
  private Integer lateActivityCount;

  @JsonbProperty(JSON_LATE_ACTIVITY_COUNT_AS_STRING)
  private String lateActivityCountAsString;

  @JsonbProperty(JSON_NOT_LATE_ACTIVITY_COUNT_AS_STRING)
  private String notLateActivityCountAsString;

  @JsonbProperty(JSON_PENDING_START_ACTIVITY_COUNT)
  private Integer pendingStartActivityCount;

  @JsonbProperty(JSON_PENDING_START_ACTIVITY_COUNT_AS_STRING)
  private String pendingStartActivityCountAsString;

  @JsonbProperty(JSON_DONE_ACTIVITY_COUNT)
  private Integer doneActivityCount;

  @JsonbProperty(JSON_DONE_ACTIVITY_COUNT_AS_STRING)
  private String doneActivityCountAsString;

  @JsonbProperty(JSON_NOT_DONE_ACTIVITY_COUNT_AS_STRING)
  private String notDoneActivityCountAsString;

  /**
   * Identifiant groupe de fichiers.
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Identifiant groupe d'identités.
   */
  @JsonbProperty(JSON_IDENTITIES_GROUP_IDENTIFIER)
  private String identitiesGroupIdentifier;

  /**
   * Est en retard.
   */
  @JsonbProperty(JSON_IS_LATE)
  private Boolean isLate;

  /**
   * Représentation en chaine de caractère de la date de fin.
   */
  @JsonbProperty(JSON_TO_DATE_AS_STRING)
  private String toDateAsString;


  /**
   * Identifiant json de identifiant de {@link FolderDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDossier";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FolderDto}.
   */
  public static final String JSON_THIS_AS_STRING = "dossierChaine";

  /**
   * Identifiant json {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = "idType";

  /**
   * Identifiant json {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      AdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant json {@link #responsibleIdentityIdentifier}.
   */
  public static final String JSON_RESPONSIBLE_IDENTITY_IDENTIFIER = "idIdentiteResponsable";

  /**
   * Identifiant json {@link #priorityIdentifier}.
   */
  public static final String JSON_PRIORITY_IDENTIFIER = "idPriorite";

  /**
   * Identifiant json {@link #responsibleIdentityAsString}.
   */
  public static final String JSON_RESPONSIBLE_IDENTITY_AS_STRING = "identiteResponsableChaine";

  /**
   * Identifiant json champ {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "idGroupeFichiers";

  /**
   * Identifiant json champ {@link #identitiesGroupIdentifier}.
   */
  public static final String JSON_IDENTITIES_GROUP_IDENTIFIER = "idGroupeIdentites";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = "estEnRetard";

  /**
   * Identifiant json champ {@link #toDateAsString}.
   */
  public static final String JSON_TO_DATE_AS_STRING = "dateFinChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dossier";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
