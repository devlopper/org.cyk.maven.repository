package ci.gouv.dgbf.extension.primefaces;

import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpSession;

/**
 * Cette classe représente les fonctiosn statiques de traitement de face.
 *
 * @author Christian
 *
 */
public class SessionCore {

  private SessionCore() {}
  
  public static void setAttributeRedirectUrl(String url, HttpSession session) {
    session.setAttribute(RequestManager.PARAMETER_REDIRECT_URL_NAME, url);
  }

  public static void setAttributeRedirectUrl(String url) {
    setAttributeRedirectUrl(url,
        (HttpSession) FacesContext.getCurrentInstance().getExternalContext().getSession(false));
  }
  
}
