package ci.gouv.dgbf.system.localauthority.server.api;

import lombok.Getter;

/**
 * Cette classe représente les sections de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 */
@Getter
public enum BudgetSection {

  /**
   * Fonctionnement.
   */
  FUNCTIONING("Fonctionnement"),

  /**
   * Investissement.
   */
  INVESTMENT("Investissement");

  private BudgetSection(String name) {
    this.name = name;
  }

  private String name;
}
