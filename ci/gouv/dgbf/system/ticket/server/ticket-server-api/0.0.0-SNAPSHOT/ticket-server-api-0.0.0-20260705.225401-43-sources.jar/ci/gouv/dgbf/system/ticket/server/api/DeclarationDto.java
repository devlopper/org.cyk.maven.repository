package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasReporterIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une déclaration.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DeclarationDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasDomainIdentifierDto, HasReporterIdentityIdentifierDto,
    HasFilesGroupIdentifierDto, HasTicketIdentifierDto, HasTicketAsStringDto {

  @JsonbProperty(JSON_TICKET_IDENTIFIER)
  private String ticketIdentifier;

  @JsonbProperty(JSON_TICKET_AS_STRING)
  private String ticketAsString;

  @JsonbProperty(JSON_REPORTER_IDENTITY_IDENTIFIER)
  private String reporterIdentityIdentifier;

  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDeclaration";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "declarationChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "déclaration";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
