package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de suspension (R47,
 * RG_REP_STA_04, RG_REP_RVR_13), orthogonal au statut ou à l'étape courante.
 *
 * @author akm
 *
 */
public interface HasSuspendedDto {

  /**
   * Identifiant json de {@link #getSuspended()}.
   */
  String JSON_SUSPENDED = "suspendue";

  /**
   * Cette méthode permet d'obtenir l'indicateur de suspension.
   *
   * @return indicateur de suspension
   */
  Boolean getSuspended();

  /**
   * Cette méthode permet d'assigner l'indicateur de suspension.
   *
   * @param suspended indicateur de suspension
   */
  void setSuspended(Boolean suspended);
}
