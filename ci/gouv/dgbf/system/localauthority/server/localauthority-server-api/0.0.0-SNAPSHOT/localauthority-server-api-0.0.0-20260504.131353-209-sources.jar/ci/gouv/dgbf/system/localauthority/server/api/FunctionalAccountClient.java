package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.FunctionalAccountService.FunctionalAccountGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FunctionalAccountService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FunctionalAccountClient extends AbstractClient<FunctionalAccountService>
    implements GetByIdentifier<FunctionalAccountDto>, GetMany<FunctionalAccountGetManyResponseDto> {

  @Override
  public FunctionalAccountClient service(FunctionalAccountService service) {
    return (FunctionalAccountClient) super.service(service);
  }

  /**
   * {@link FunctionalAccountService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionalAccountGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FunctionalAccountGetManyResponseDto>(
        FunctionalAccountGetManyResponseDto.class, FunctionalAccountService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link FunctionalAccountService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionalAccountGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FunctionalAccountService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionalAccountDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FunctionalAccountDto>(FunctionalAccountDto.class,
        FunctionalAccountService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FunctionalAccountService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionalAccountDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FunctionalAccountService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FunctionalAccountDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FunctionalAccountDto>(FunctionalAccountDto.class,
        FunctionalAccountService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FunctionalAccountService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionalAccountDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
