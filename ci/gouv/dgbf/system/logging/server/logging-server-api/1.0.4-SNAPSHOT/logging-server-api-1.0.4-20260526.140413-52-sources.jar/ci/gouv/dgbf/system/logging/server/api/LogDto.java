package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.io.Serializable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un objet de transfert de données d'un log.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class LogDto extends AbstractIdentifiableAuditableDto implements Serializable,
    HasProcessIdentifierDto, HasProcessAsStringDto, HasLevelDto, HasMessageDto {

  /**
   * Identifiant du processus (Ex: mic-imputation, mic-budgetisation-api).
   */
  @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
  private String processIdentifier;

  /**
   * Représentation en chaine de caractères du processus.
   */
  @JsonbProperty(value = JSON_PROCESS_AS_STRING)
  private String processAsString;

  /**
   * Niveau.
   */
  @JsonbProperty(value = JSON_LEVEL)
  private LogLevel level;

  /**
   * Message.
   */
  @JsonbProperty(value = JSON_MESSAGE)
  private String message;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idLog";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "logChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "log";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
