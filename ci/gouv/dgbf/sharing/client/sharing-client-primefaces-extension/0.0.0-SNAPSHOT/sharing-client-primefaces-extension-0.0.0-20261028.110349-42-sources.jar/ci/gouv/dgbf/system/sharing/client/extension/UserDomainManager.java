package ci.gouv.dgbf.system.sharing.client.extension;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.Optional;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette classe représente le gestionnaire du code du domaine de l'utilisateur connecté (realm
 * Keycloak). Le nom d'un utilisateur n'est unique que dans son domaine : sharing le recherche par
 * le couple (code du domaine, nom) (TCH_SHA_070).
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
public class UserDomainManager {

  /**
   * Code du domaine imposé par configuration. À défaut, déduit de l'URL du serveur OIDC.
   */
  @Inject
  @ConfigProperty(name = "dgbf.system.sharing.user.domain.code")
  Optional<String> code;

  /**
   * URL du serveur OIDC, de la forme {@code https://hote/auth/realms/SIIB}.
   */
  @Inject
  @ConfigProperty(name = "quarkus.oidc.auth-server-url")
  Optional<String> oidcAuthServerUrl;

  /**
   * Cette méthode permet d'obtenir le code du domaine de l'utilisateur connecté.
   *
   * @return code du domaine, nul s'il est inconnu (le serveur applique alors son domaine par
   *         défaut, pendant la transition)
   */
  public String getCode() {
    return Optional.ofNullable(code).flatMap(value -> value).filter(value -> !value.isBlank())
        .orElseGet(() -> Optional.ofNullable(oidcAuthServerUrl).flatMap(value -> value)
            .map(UserDomainManager::getRealm).orElse(null));
  }

  /**
   * Cette méthode permet d'obtenir le realm d'une URL de serveur OIDC.
   *
   * @param url URL du serveur OIDC
   * @return realm, nul si l'URL n'en contient pas
   */
  static String getRealm(String url) {
    String marker = "/realms/";
    int index = url.lastIndexOf(marker);
    if (index < 0) {
      return null;
    }
    String realm = url.substring(index + marker.length());
    int slash = realm.indexOf('/');
    realm = slash < 0 ? realm : realm.substring(0, slash);
    return realm.isBlank() ? null : realm;
  }
}
