package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupTypeService.FunctionGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupTypeService.FunctionGroupTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionGroupDto}.
 *
 * @author Boobacool
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionGroupDto}.

    @author Boobacool
     """)
public interface FunctionGroupTypeRequestMapper
    extends RequestMapper<FunctionGroupTypeDto, FunctionGroupTypeCreateRequestDto,
                          FunctionGroupTypeUpdateRequestDto> {

}
