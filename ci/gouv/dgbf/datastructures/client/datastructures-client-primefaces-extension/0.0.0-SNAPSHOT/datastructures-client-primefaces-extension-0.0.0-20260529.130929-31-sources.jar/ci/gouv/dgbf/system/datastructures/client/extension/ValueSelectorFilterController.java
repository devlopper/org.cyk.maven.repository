package ci.gouv.dgbf.system.datastructures.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ValueSelectorDto}.
 *
 * @author Christian
 */
@Dependent
public class ValueSelectorFilterController extends AbstractFilterController<ValueSelectorFilter> {

  @Inject
  @Getter
  ValueSourceSelectOneController sourceSelectOneController;

  /**
   * Cette méthode permet d'instantier.
   */
  public ValueSelectorFilterController() {
    super(ValueSelectorFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    sourceSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setSourceIdentifier(identifier));

  }



}
