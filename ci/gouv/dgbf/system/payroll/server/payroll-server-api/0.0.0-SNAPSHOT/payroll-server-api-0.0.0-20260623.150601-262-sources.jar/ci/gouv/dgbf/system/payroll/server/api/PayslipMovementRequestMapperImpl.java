package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipMovementDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T15:06:37+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipMovementRequestMapperImpl implements PayslipMovementRequestMapper {

    @Override
    public PayslipMovementService.PayslipMovementCreateRequestDto mapCreate(PayslipMovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipMovementService.PayslipMovementCreateRequestDto payslipMovementCreateRequestDto = new PayslipMovementService.PayslipMovementCreateRequestDto();

        payslipMovementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipMovementCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipMovementCreateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipMovementCreateRequestDto.setActualMovementIdentifier( arg0.getActualMovementIdentifier() );
        payslipMovementCreateRequestDto.setPreviousMovementIdentifier( arg0.getPreviousMovementIdentifier() );
        payslipMovementCreateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );

        return payslipMovementCreateRequestDto;
    }

    @Override
    public PayslipMovementService.PayslipMovementUpdateRequestDto mapUpdate(PayslipMovementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipMovementService.PayslipMovementUpdateRequestDto payslipMovementUpdateRequestDto = new PayslipMovementService.PayslipMovementUpdateRequestDto();

        payslipMovementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipMovementUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipMovementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipMovementUpdateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipMovementUpdateRequestDto.setActualMovementIdentifier( arg0.getActualMovementIdentifier() );
        payslipMovementUpdateRequestDto.setPreviousMovementIdentifier( arg0.getPreviousMovementIdentifier() );
        payslipMovementUpdateRequestDto.setEffectiveDate( arg0.getEffectiveDate() );

        return payslipMovementUpdateRequestDto;
    }
}
