package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDomainIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasReporterIdentityIdentifier;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUserIdentifier;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TicketFilter extends AbstractIdentifiableFilter implements FilterHasStatusCode,
    FilterHasStatusCodes, FilterHasDomainIdentifier, FilterHasReporterIdentityIdentifier,
    FilterHasUserIdentifier {

  private String statusCode;
  private Set<String> statusCodes;
  private String domainIdentifier;

  /**
   * Identifiants des domaines fonctionnels.
   */
  private Set<String> domainIdentifiers;

  private String reporterIdentityIdentifier;

  private String userIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TicketFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TicketFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
    updateDomainIdentifier(filter);
    domainIdentifiers = getDomainIdentifiers(filter);
    updateReporterIdentityIdentifier(filter);
    updateUserIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
    updateFilterDomainIdentifier(filter);
    setDomainIdentifiers(filter, domainIdentifiers);
    updateFilterReporterIdentityIdentifier(filter);
    updateFilterUserIdentifier(filter);
  }

  /**
   * Cette méthode permet d'assigner les identifiants des domaines fonctionnels.
   *
   * @param filter filtre
   * @param domainIdentifiers identifiants des domaines fonctionnels
   */
  public static void setDomainIdentifiers(FilterDto filter, Set<String> domainIdentifiers) {
    set(filter, JSON_DOMAIN_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(domainIdentifiers));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants des domaines fonctionnels.
   *
   * @param filter filtre
   * @return identifiants des domaines fonctionnels
   */
  public static Set<String> getDomainIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_DOMAIN_IDENTIFIERS));
  }

  /**
   * Identifiant JSON {@link #domainIdentifiers}.
   */
  public static final String JSON_DOMAIN_IDENTIFIERS = "idDomaines";
}
