package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un partage.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SharingDto extends AbstractIdentifiableAuditableDto {

  /* La ressource */

  /**
   * Identifiant {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
  private String resourceIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_AS_STRING)
  private String resourceAsString;

  /**
   * Référence {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_REFERENCE)
  private String resourceReference;
  
  /**
   * Nom {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_NAME)
  private String resourceName;
  
  /**
   * {@link ResourceType}.
   */
  @JsonbProperty(JSON_RESOURCE_TYPE)
  private ResourceType resourceType;

  /**
   * Représentation en chaine de caractères de {@link #resourceType}.
   */
  @JsonbProperty(JSON_RESOURCE_TYPE_AS_STRING)
  private String resourceTypeAsString;

  /**
   * {@link Location} de {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_LOCATION)
  private Location resourceLocation;

  /**
   * Représentation en chaine de caractères de {@link #resourceLocation}.
   */
  @JsonbProperty(JSON_RESOURCE_LOCATION_AS_STRING)
  private String resourceLocationAsString;
  
  /* Le destinataire */

  /**
   * Identifiant {@link ReceiverDto}.
   */
  @JsonbProperty(JSON_RECEIVER_IDENTIFIER)
  private String receiverIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ReceiverDto}.
   */
  @JsonbProperty(JSON_RECEIVER_AS_STRING)
  private String receiverAsString;

  /**
   * {@link ReceiverType}.
   */
  @JsonbProperty(JSON_RECEIVER_TYPE)
  private ReceiverType receiverType;

  /**
   * Représentation en chaine de caractères de {@link #receiverType}.
   */
  @JsonbProperty(JSON_RECEIVER_TYPE_AS_STRING)
  private String receiverTypeAsString;

  /**
   * {@link Location} de {@link ReceiverDto}.
   */
  @JsonbProperty(JSON_RECEIVER_LOCATION)
  private Location receiverLocation;

  /**
   * Représentation en chaine de caractères de {@link #receiverLocation}.
   */
  @JsonbProperty(JSON_RECEIVER_LOCATION_AS_STRING)
  private String receiverLocationAsString;
  
  /* Options */
  
  /**
   * Refusé.
   */
  @JsonbProperty(JSON_REFUSED)
  private Boolean refused;
  
  /**
   * Représentation en chaine de caractères de {@link #refused}.
   */
  @JsonbProperty(JSON_REFUSED_AS_STRING)
  private String refusedAsString;
  
  /**
   * Date de début.
   */
  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;
  
  /**
   * Représentation en chaine de caractère de {@link #fromDate}.
   */
  @JsonbProperty(JSON_FROM_DATE_AS_STRING)
  private String fromDateAsString;
  
  /**
   * Date de fin.
   */
  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;
  
  /**
   * Représentation en chaine de caractère de {@link #toDate}.
   */
  @JsonbProperty(JSON_TO_DATE_AS_STRING)
  private String toDateAsString;
  
  /**
   * Identifiant champ json {@link #resourceIdentifier}.
   */
  public static final String JSON_RESOURCE_IDENTIFIER = "idRessource";
  /**
   * Identifiant champ json {@link #resourceAsString}.
   */
  public static final String JSON_RESOURCE_AS_STRING = "ressourceChaine";
  /**
   * Identifiant champ json {@link #resourceReference}.
   */
  public static final String JSON_RESOURCE_REFERENCE = "referenceRessource";
  /**
   * Identifiant champ json {@link #resourceName}.
   */
  public static final String JSON_RESOURCE_NAME = "referenceName";
  /**
   * Identifiant champ json {@link #resourceType}.
   */
  public static final String JSON_RESOURCE_TYPE = "typeRessource";
  /**
   * Identifiant champ json {@link #resourceTypeAsString}.
   */
  public static final String JSON_RESOURCE_TYPE_AS_STRING = "typeRessourceChaine";
  /**
   * Identifiant champ json {@link #resourceLocation}.
   */
  public static final String JSON_RESOURCE_LOCATION = "localisationRessource";
  /**
   * Identifiant champ json {@link #resourceLocationAsString}.
   */
  public static final String JSON_RESOURCE_LOCATION_AS_STRING = "localisationRessourceChaine";

  /**
   * Identifiant champ json {@link #receiverIdentifier}.
   */
  public static final String JSON_RECEIVER_IDENTIFIER = "idDestinataire";
  /**
   * Identifiant champ json {@link #receiverAsString}.
   */
  public static final String JSON_RECEIVER_AS_STRING = "destinataireChaine";
  /**
   * Identifiant champ json {@link #receiverType}.
   */
  public static final String JSON_RECEIVER_TYPE = "typeDestinataire";
  /**
   * Identifiant champ json {@link #receiverTypeAsString}.
   */
  public static final String JSON_RECEIVER_TYPE_AS_STRING = "typeDestinataireChaine";
  /**
   * Identifiant champ json {@link #receiverLocation}.
   */
  public static final String JSON_RECEIVER_LOCATION = "localisationDestinataire";
  /**
   * Identifiant champ json {@link #receiverLocationAsString}.
   */
  public static final String JSON_RECEIVER_LOCATION_AS_STRING = "localisationDestinataireChaine";

  /**
   * Identifiant champ json {@link #refused}.
   */
  public static final String JSON_REFUSED = "refuse";
  /**
   * Identifiant champ json {@link #refusedAsString}.
   */
  public static final String JSON_REFUSED_AS_STRING = "refuseChaine";
  
  /**
   * Identifiant json champ {@link #fromDate}.
   */
  public static final String JSON_FROM_DATE = "dateDebut";
  
  /**
   * Identifiant json champ {@link #fromDateAsString}.
   */
  public static final String JSON_FROM_DATE_AS_STRING = "dateDebutChaine";
  
  /**
   * Identifiant json champ {@link #toDate}.
   */
  public static final String JSON_TO_DATE = "dateFin";
  
  /**
   * Identifiant json champ {@link #toDateAsString}.
   */
  public static final String JSON_TO_DATE_AS_STRING = "dateFinChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "partage";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
