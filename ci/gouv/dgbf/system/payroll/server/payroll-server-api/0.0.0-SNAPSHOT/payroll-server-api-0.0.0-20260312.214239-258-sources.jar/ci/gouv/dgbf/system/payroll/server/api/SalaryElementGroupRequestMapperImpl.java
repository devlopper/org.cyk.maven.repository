package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SalaryElementGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-12T21:43:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SalaryElementGroupRequestMapperImpl implements SalaryElementGroupRequestMapper {

    @Override
    public SalaryElementGroupService.SalaryElementGroupCreateRequestDto mapCreate(SalaryElementGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementGroupService.SalaryElementGroupCreateRequestDto salaryElementGroupCreateRequestDto = new SalaryElementGroupService.SalaryElementGroupCreateRequestDto();

        salaryElementGroupCreateRequestDto.setCode( arg0.getCode() );
        salaryElementGroupCreateRequestDto.setName( arg0.getName() );

        return salaryElementGroupCreateRequestDto;
    }

    @Override
    public SalaryElementGroupService.SalaryElementGroupUpdateRequestDto mapUpdate(SalaryElementGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementGroupService.SalaryElementGroupUpdateRequestDto salaryElementGroupUpdateRequestDto = new SalaryElementGroupService.SalaryElementGroupUpdateRequestDto();

        salaryElementGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        salaryElementGroupUpdateRequestDto.setCode( arg0.getCode() );
        salaryElementGroupUpdateRequestDto.setName( arg0.getName() );

        return salaryElementGroupUpdateRequestDto;
    }
}
