package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@code ClaimedValueReview} (Revue de
 * Valeur Réclamée) -- n'étend pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais
 * {@link SpecificService}, entité sans code ni nom propres, jamais exposée en lecture/écriture
 * générique (RU_REP_007, création interne seule). Seule la transmission groupée pour Visa
 * (RU_REP_012 étape 1, RG_REP_RVR_01) est exposée ici, seule action déclenchable par un Agent de
 * Traitement sur cette entité.
 *
 * @author akm
 *
 */
@Path(ClaimedValueReviewService.PATH)
@Tag(name = "Gestion des revues de valeur réclamée")
public interface ClaimedValueReviewService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "revues-valeur-reclamee";

  /**
   * Identifiant du service de Transmission pour Visa (RG_REP_RVR_01).
   */
  String TRANSMIT_TO_VISA_IDENTIFIER = "TRANSMISSION_VISA_REVUE_VALEUR_RECLAMEE";

  /**
   * Chemin du service de Transmission pour Visa.
   */
  String TRANSMIT_TO_VISA_PATH = "transmission-visa";

  /**
   * Cette méthode permet de transmettre pour Visa, en une seule fois, toutes les Revues de
   * Valeur Réclamée encore à l'état Générée issues des réclamations sélectionnées par l'Agent de
   * Traitement demandeur (RG_REP_PEC_02) -- action manuelle et groupée par réclamation, jamais
   * ligne par ligne au niveau d'une Revue individuelle (l'Agent choisit quelles réclamations
   * transmettre, jamais quelle Revue parmi celles d'une même réclamation, RG_REP_RVR_02). Chaque
   * réclamation sélectionnée est revalidée côté serveur comme appartenant bien à l'acteur
   * demandeur -- la sélection envoyée par le client n'est jamais une preuve d'autorisation.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_TO_VISA_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = TRANSMIT_TO_VISA_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(
          schema = @Schema(implementation = ClaimedValueReviewTransmitToVisaResponseDto.class))})
  Response transmitToVisa(ClaimedValueReviewTransmitToVisaRequestDto request);

  /**
   * Cette classe représente la requête de Transmission pour Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToVisaRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiants des réclamations sélectionnées par l'Agent (portefeuille, "Transmettre la
     * sélection") -- jamais vide (FA1).
     */
    @NotEmpty
    @JsonbProperty(JSON_CLAIM_IDENTIFIERS)
    private Set<String> claimIdentifiers;
  }

  /**
   * Cette classe représente la réponse de Transmission pour Visa.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimedValueReviewTransmitToVisaResponseDto extends AbstractResponseDto {

    @JsonbProperty(JSON_TRANSMITTED_COUNT)
    private Integer transmittedCount;
  }

  /**
   * Identifiant json champ {@code transmittedCount}.
   */
  String JSON_TRANSMITTED_COUNT = "nombreTransmises";

  /**
   * Identifiant json champ {@code claimIdentifiers}.
   */
  String JSON_CLAIM_IDENTIFIERS = ClaimedValueReviewFilter.JSON_CLAIM_IDENTIFIERS;
}
