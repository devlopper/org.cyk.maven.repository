package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentTypesGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T13:38:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentTypesGroupRequestMapperImpl implements DocumentTypesGroupRequestMapper {

    @Override
    public DocumentTypesGroupService.DocumentTypesGroupCreateRequestDto mapCreate(DocumentTypesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypesGroupService.DocumentTypesGroupCreateRequestDto documentTypesGroupCreateRequestDto = new DocumentTypesGroupService.DocumentTypesGroupCreateRequestDto();

        documentTypesGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypesGroupCreateRequestDto.setCode( arg0.getCode() );
        documentTypesGroupCreateRequestDto.setName( arg0.getName() );

        return documentTypesGroupCreateRequestDto;
    }

    @Override
    public DocumentTypesGroupService.DocumentTypesGroupUpdateRequestDto mapUpdate(DocumentTypesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypesGroupService.DocumentTypesGroupUpdateRequestDto documentTypesGroupUpdateRequestDto = new DocumentTypesGroupService.DocumentTypesGroupUpdateRequestDto();

        documentTypesGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypesGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentTypesGroupUpdateRequestDto.setCode( arg0.getCode() );
        documentTypesGroupUpdateRequestDto.setName( arg0.getName() );

        return documentTypesGroupUpdateRequestDto;
    }
}
