package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.SubLocalityZoneService.SubLocalityZoneCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SubLocalityZoneService.SubLocalityZoneUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SubLocalityZoneDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SubLocalityZoneDto}.

    @author akm
               """)
public interface SubLocalityZoneRequestMapper extends RequestMapper<SubLocalityZoneDto,
    SubLocalityZoneCreateRequestDto, SubLocalityZoneUpdateRequestDto> {

}
