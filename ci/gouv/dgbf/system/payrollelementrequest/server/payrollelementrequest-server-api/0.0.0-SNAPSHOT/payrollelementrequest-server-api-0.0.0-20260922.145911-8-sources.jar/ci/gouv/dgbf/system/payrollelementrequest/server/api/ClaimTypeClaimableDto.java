package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Réclamable de Type de Réclamation : le rattachement d'un Réclamable
 * (Élément de Paie ou Constante de Paie) à un Type de Réclamation, avec son Mode de Saisie,
 * nullable -- {@code FAE}/{@code AGENT} (saisissable) ou {@code null} (purement informatif)
 * (RG_REP_CIB_01/04/08).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimTypeClaimableDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Nature de l'objet ciblé : {@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE} (RG_REP_CIB_01).
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant du Réclamable (Élément de Paie ou Constante de Paie) rattaché -- vraie FK
   * composite (avec {@link #nature}) vers le référentiel {@code Claimable}
   * ({@code TA_RECLAMABLE}, RG_REP_CIB_07).
   */
  @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
  private String claimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimableIdentifier} -- résolue
   * côté serveur (lecture directe de {@code Claimable}, même module), sur le même principe que
   * {@link #typeAsString}.
   */
  @JsonbProperty(JSON_CLAIMABLE_AS_STRING)
  private String claimableAsString;

  /**
   * Mode de Saisie, nullable : {@code FAE} ou {@code AGENT} (saisissable, RG_REP_CIB_04), ou
   * {@code null} (purement informatif, ex-Effet Possible, RG_REP_CIB_08).
   */
  @JsonbProperty(JSON_VALUE_INPUT_MODE)
  private String valueInputMode;

  /**
   * Nature du Mouvement à appliquer à l'Impact d'une Valeur Réclamée sur ce Réclamable :
   * {@code CREATION} (crée), {@code MODIFICATION} (clôture le Mouvement actif concerné puis crée)
   * ou {@code SUPPRESSION} (clôture le Mouvement actif concerné). {@code null} pour un Réclamable
   * purement informatif.
   */
  @JsonbProperty(JSON_MOVEMENT_NATURE)
  private String movementNature;

  /**
   * Ordre d'affichage dans la liste unique montrée à l'agent de traitement, saisissable ou
   * informatif confondus (RG_REP_CIB_01/08).
   */
  @JsonbProperty(JSON_RANK)
  private Integer rank;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json {@link #claimableAsString}.
   */
  public static final String JSON_CLAIMABLE_AS_STRING = "reclamableChaine";

  /**
   * Identifiant json {@link #valueInputMode}.
   */
  public static final String JSON_VALUE_INPUT_MODE = "modeSaisie";

  /**
   * Identifiant json {@link #movementNature}.
   */
  public static final String JSON_MOVEMENT_NATURE = "natureMouvement";

  /**
   * Identifiant json {@link #rank}.
   */
  public static final String JSON_RANK = "ordre";

  /**
   * Identifiant json de identifiant de {@link ClaimTypeClaimableDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamableTypeReclamation";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimTypeClaimableDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamableTypeReclamationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "réclamable des types de réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "réclamables des types de réclamation";
}
