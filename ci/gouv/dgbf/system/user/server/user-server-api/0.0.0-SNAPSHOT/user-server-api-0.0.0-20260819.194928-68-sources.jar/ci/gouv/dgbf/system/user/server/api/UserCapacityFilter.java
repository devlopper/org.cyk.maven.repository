package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les qualités d'utilisateur.
 *
 * @author BoobaCool
 *
 */
@Getter
@Setter
public class UserCapacityFilter extends AbstractIdentifiableFilter {

}
