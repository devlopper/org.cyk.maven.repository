package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController.Viewer;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingClient;
import ci.gouv.dgbf.system.processing.server.api.ProcessingDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingRequestMapper;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessResponseDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingService.ProcessingProcessRequestDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de processeur.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingProcessorController extends AbstractController {

  @Inject
  ProcessingClient client;

  @Inject
  ProcessingRequestMapper requestMapper;

  @Getter
  ProcessingDto processing;

  @Inject
  @Getter
  IdentifiableProcessingController startController;

  @Inject
  @Getter
  IdentifiableProcessingController stopController;

  @Inject
  @Getter
  IdentifiableProcessingController cancelController;

  @Inject
  @Getter
  IdentifiableProcessingController terminateController;

  @Getter
  @Setter
  Function<Object, Object> getIdentifierFunction;

  @Getter
  @Setter
  Boolean statusNameRendered;

  @Getter
  @Setter
  Set<String> updatables;

  @Getter
  IdentifiableProcessingController currentController;

  @Inject
  ComponentManager componentManager;

  @Inject
  ScriptManager scriptManager;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "contrôleur de processeur";
    statusNameRendered = true;
    updatables = new HashSet<>();
    updatables.add("processorPanel");
  }

  /**
   * Cette méthode permet d'initialiser les contrôleurs.
   */
  public void initializeControllers() {
    initializeController(startController, ProcessingStatus.STARTED, client::start);
    initializeController(stopController, ProcessingStatus.STOPPED, client::stop);
    initializeController(cancelController, ProcessingStatus.CANCELLED, client::cancel);
    initializeController(terminateController, ProcessingStatus.TERMINATED, client::terminate);
    
    getIdentifierFunction = entity -> ((ProcessingDto) entity).getIdentifier();
    startController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStartable());
    stopController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStoppable());
    cancelController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getCancelable());
    terminateController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getTerminatable());
  }

  void initializeController(IdentifiableProcessingController controller, ProcessingStatus status,
      Function<ProcessingProcessRequestDto, ProcessResponseDto> function) {
    controller.getGetByIdentifierController().setClient(client);
    controller.getController().getNotificationPublishController().setEnabled(false);

    initializeButton(controller.showDialogButton(), status);
    controller.showDialogButton().addUpdates(updatables);
    controller.addShowDialogConsumer(identifier -> currentController = controller);
    controller.setName(status.getActionName());
    controller.getController().setFunction(identifier -> process(function));
    controller.setViewer(Viewer.DIALOG);
    controller.setFormFileName("processForm");

    controller.dialog().setHeader(status.getAction());
    controller.dialog().setIdentifier(status.name() + "ProcessingDialog");
    controller.dialog().setWidgetVar(status.name() + "ProcessingDialogWidgetVar");
  }

  /**
   * Cette methode permet d'initialiser les boutons d'actions.
   */
  public void initializeConfirmButtons() {
    initializeConfirmButton(startController, ProcessingStatus.STARTED);
    initializeConfirmButton(stopController, ProcessingStatus.STOPPED);
    initializeConfirmButton(cancelController, ProcessingStatus.CANCELLED);
    initializeConfirmButton(terminateController, ProcessingStatus.TERMINATED);
  }

  void initializeConfirmButton(IdentifiableProcessingController controller,
      ProcessingStatus status) {
    controller.prepareConfirmation(status.getAction(), null);
    initializeButton(controller.submitButton(), status);
    controller.submitButton().setValue(null);
    // controller.dialog().setHeader(controller.submitButton().getValue());
  }

  void initializeButton(Button button, ProcessingStatus status) {
    button.setValue(status.getAction());
    button.setTitle(status.getAction());
    button.setIcon(buildActionIcon(status));
    button.addStylesClasses("ui-button-raised", buildActionStylesClasses(status));
  }

  String buildActionIcon(ProcessingStatus status) {
    if (ProcessingStatus.STARTED.equals(status)) {
      return "pi pi-play";
    }
    if (ProcessingStatus.STOPPED.equals(status)) {
      return "pi pi-stop";
    }
    if (ProcessingStatus.CANCELLED.equals(status)) {
      return "pi pi-times";
    }
    if (ProcessingStatus.TERMINATED.equals(status)) {
      return "pi pi-check";
    }
    return null;
  }

  String buildActionStylesClasses(ProcessingStatus status) {
    if (ProcessingStatus.STARTED.equals(status)) {
      return String.format("ui-button-primary processing-processor-button-%s",
          status.getActionCode());
    }
    if (ProcessingStatus.STOPPED.equals(status)) {
      return String.format("ui-button-warning processing-processor-button-%s",
          status.getActionCode());
    }
    if (ProcessingStatus.CANCELLED.equals(status)) {
      return String.format("ui-button-danger processing-processor-button-%s",
          status.getActionCode());
    }
    if (ProcessingStatus.TERMINATED.equals(status)) {
      return String.format("ui-button-success processing-processor-button-%s",
          status.getActionCode());
    }
    return null;
  }

  /**
   * Cette méthode permet d'initialiser pour un contrôleur de liste.
   *
   * @param listController contrôleur de liste
   */
  public void initialize(ListController listController) {
    /* Démarrage */

    startController.getGetByIdentifierController().setClient(client);
    startController.setName("Démarrage traitement");
    startController.setListController(listController);
    startController.setFormFileName("processForm");
    startController.initialize();
    startController.getController()
        .setFunction(identifier -> client.start((String) identifier, userIdentifier, null));
    startController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStartable());

    /* Arrêt */

    stopController.getGetByIdentifierController().setClient(client);
    stopController.setName("Arrêt traitement");
    stopController.setListController(listController);
    stopController.setFormFileName("processForm");
    stopController.initialize();
    stopController.getController()
        .setFunction(identifier -> client.stop((String) identifier, userIdentifier, null));
    stopController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStoppable());

    /* Annulation */

    cancelController.getGetByIdentifierController().setClient(client);
    cancelController.setName("Annulation traitement");
    cancelController.setListController(listController);
    cancelController.setFormFileName("processForm");
    cancelController.initialize();
    cancelController.getController()
        .setFunction(identifier -> client.cancel((String) identifier, userIdentifier, null));
    cancelController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getCancelable());

    /* Terminaison */

    terminateController.getGetByIdentifierController().setClient(client);
    terminateController.setName("Terminaison traitement");
    terminateController.setListController(listController);
    terminateController.setFormFileName("processForm");
    terminateController.initialize();
    terminateController.getController()
        .setFunction(identifier -> client.terminate((String) identifier, userIdentifier, null));
    terminateController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getTerminatable());
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param processing {@link ProcessingDto}
   */
  public void initialize(ProcessingDto processing) {
    this.processing = processing;

    initializeControllers();

    /*
     * String update = updatables.stream().collect(Collectors.joining(" "));
     * initializeAction(startController, update, "Démarrage traitement", client::start);
     * initializeAction(stopController, update, "Arrêt traitement", client::stop);
     * initializeAction(cancelController, update, "Annulation traitement", client::cancel);
     * initializeAction(terminateController, update, "Terminaison traitement", client::terminate);
     */

    startController.submitButton().addStyleClass("ui-button-raised ui-button-primary");
    stopController.submitButton().addStyleClass("ui-button-raised ui-button-warning");
    cancelController.submitButton().addStyleClass("ui-button-raised ui-button-danger");
    terminateController.submitButton().addStyleClass("ui-button-raised ui-button-success");

    getIdentifierFunction = entity -> ((ProcessingDto) entity).getIdentifier();
    startController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStartable());
    stopController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getStoppable());
    cancelController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getCancelable());
    terminateController.getController()
        .setIsEnabledFunction(entity -> ((ProcessingDto) entity).getTerminatable());
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param identifier identifiant du traitement
   */
  public void initialize(String identifier) {
    processing = new ActionExecutor<>(this, ProcessingService.GET_BY_IDENTIFIER_IDENTIFIER, () -> {
      ProcessingDto dto = client.getByIdentifier(identifier,
          new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
              ProcessingDto.JSON_STATUS, ProcessingDto.JSON_STARTABLE, ProcessingDto.JSON_STOPPABLE,
              ProcessingDto.JSON_CANCELABLE, ProcessingDto.JSON_TERMINATABLE),
          userIdentifier, null);
      initialize(dto);
      return processing;
    }).setExceptionShowableInDialog(false).execute();
  }

  ProcessResponseDto process(Function<ProcessingProcessRequestDto, ProcessResponseDto> function) {
    ProcessingProcessRequestDto request = requestMapper.mapProcess(processing);
    request.setAuditWho(userIdentifier);
    ProcessResponseDto response = function.apply(request);
    processing.initialize(response);
    return response;
  }

  /**
   * Cette méthode permet d'exécuter.
   */
  public void execute() {
    currentController.execute(processing);
    processing.setDate(null);
    processing.setReason(null);
    componentManager.update(currentController.getDialog());
    componentManager.updateByExpressions(":processorForm:processorPanel");
    scriptManager.hide(currentController.getDialog());
  }
}
