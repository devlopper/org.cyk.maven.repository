package ci.gouv.dgbf.system.budgetaryclassification.server.api;

/**
 * Cette classe représente les codes de {@link ExpenditureActivityStatus}.
 *
 * @author Arnaud
 *
 */
public class ExpenditureActivityStatusCode {

  private ExpenditureActivityStatusCode() {

  }

  /**
   * Activé.
   */
  public static final String ACTIVATED = "ACTIVE";

  /**
   * Suspendu.
   */
  public static final String SUSPENDED = "SUSPENDU";

  /**
   * Clôturé.
   */
  public static final String CLOSED = "CLÔTURE";
}
