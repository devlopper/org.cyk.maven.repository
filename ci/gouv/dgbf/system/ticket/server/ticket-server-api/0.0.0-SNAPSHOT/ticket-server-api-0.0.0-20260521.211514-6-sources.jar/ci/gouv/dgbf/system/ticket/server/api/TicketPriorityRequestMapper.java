package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.TicketPriorityService.TicketPriorityCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketPriorityService.TicketPriorityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TicketPriorityDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TicketPriorityDto}.

    @author Arnaud
               """)
public interface TicketPriorityRequestMapper
    extends RequestMapper<TicketPriorityDto, TicketPriorityCreateRequestDto,
     TicketPriorityUpdateRequestDto> {

}
