package ci.gouv.dgbf.system.servicecatalog.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ModulesGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-19T11:17:02+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ModulesGroupRequestMapperImpl implements ModulesGroupRequestMapper {

    @Override
    public ModulesGroupService.ModulesGroupCreateRequestDto mapCreate(ModulesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ModulesGroupService.ModulesGroupCreateRequestDto modulesGroupCreateRequestDto = new ModulesGroupService.ModulesGroupCreateRequestDto();

        modulesGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        modulesGroupCreateRequestDto.setCode( arg0.getCode() );
        modulesGroupCreateRequestDto.setName( arg0.getName() );
        modulesGroupCreateRequestDto.setOrder( arg0.getOrder() );

        return modulesGroupCreateRequestDto;
    }

    @Override
    public ModulesGroupService.ModulesGroupUpdateRequestDto mapUpdate(ModulesGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ModulesGroupService.ModulesGroupUpdateRequestDto modulesGroupUpdateRequestDto = new ModulesGroupService.ModulesGroupUpdateRequestDto();

        modulesGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        modulesGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        modulesGroupUpdateRequestDto.setCode( arg0.getCode() );
        modulesGroupUpdateRequestDto.setName( arg0.getName() );
        modulesGroupUpdateRequestDto.setOrder( arg0.getOrder() );

        return modulesGroupUpdateRequestDto;
    }
}
