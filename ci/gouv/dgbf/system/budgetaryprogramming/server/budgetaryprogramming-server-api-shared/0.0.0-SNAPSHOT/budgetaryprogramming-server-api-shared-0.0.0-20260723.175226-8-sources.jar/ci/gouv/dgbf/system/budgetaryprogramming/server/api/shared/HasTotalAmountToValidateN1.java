package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN1 {

  /**
   * Obtient le montant total à valider pour l'année N+1.
   *
   * @return le montant total à valider pour l'année N+1
   */
  Long getTotalAmountToValidateN1();

  /**
   * Définit le montant total à valider pour l'année N+1.
   *
   * @param totalAmountToValidateN1 le montant total à valider pour l'année N+1
   */
  void setTotalAmountToValidateN1(Long totalAmountToValidateN1);

  /**
   * Identifiant java du montant total à valider pour l'année N+1.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N1 = "totalAmountToValidateN1";
}