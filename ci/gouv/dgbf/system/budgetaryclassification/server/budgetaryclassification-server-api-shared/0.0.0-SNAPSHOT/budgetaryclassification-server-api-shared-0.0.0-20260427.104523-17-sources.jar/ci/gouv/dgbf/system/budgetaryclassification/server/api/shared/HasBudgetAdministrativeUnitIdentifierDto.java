package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'unité administrative de budget.
 *
 * @author Christian
 */
public interface HasBudgetAdministrativeUnitIdentifierDto
    extends HasBudgetAdministrativeUnitIdentifier {

  /**
   * Identifiant json de l'identifiant de l'unité administrative de budget.
   */
  String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrativeBudget";
}
