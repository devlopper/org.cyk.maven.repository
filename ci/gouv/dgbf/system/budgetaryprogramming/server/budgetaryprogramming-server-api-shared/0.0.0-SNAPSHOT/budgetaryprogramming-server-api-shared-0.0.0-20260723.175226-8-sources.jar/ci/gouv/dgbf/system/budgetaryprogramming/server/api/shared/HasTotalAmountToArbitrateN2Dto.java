package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN2Dto extends HasTotalAmountToArbitrateN2 {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N+2.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N2 = "montantTotalAArbitrerN2";
}
