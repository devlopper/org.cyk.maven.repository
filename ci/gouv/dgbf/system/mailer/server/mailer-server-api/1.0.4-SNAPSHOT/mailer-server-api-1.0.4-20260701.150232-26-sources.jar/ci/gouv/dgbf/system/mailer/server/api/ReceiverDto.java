package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasAddressDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.mailer.server.api.shared.HasMailIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un destinataire.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ReceiverDto extends AbstractIdentifiableAuditableDto
    implements HasMailIdentifierDto, HasAddressDto {

  @JsonbProperty(value = JSON_MAIL_IDENTIFIER)
  public String mailIdentifier;

  @JsonbProperty(value = JSON_ADDRESS)
  public String address;

}