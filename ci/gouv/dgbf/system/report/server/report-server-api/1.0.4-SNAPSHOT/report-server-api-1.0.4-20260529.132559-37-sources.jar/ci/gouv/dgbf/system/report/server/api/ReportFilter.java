package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ReportDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class ReportFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link ReportsGroupDto}.
   */
  String groupIdentifier;

  /**
   * code de  {@link ReportsGroupDto}.
   */
  String groupCode;


  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ReportFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ReportFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
    groupCode = getGroupCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
    setGroupCode(filter, groupCode);
  }


  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ReportsGroupDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link ReportsGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ReportsGroupDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ReportsGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link ReportsGroupDto}.
   *
   * @param filter filtre
   * @param code   code de {@link ReportsGroupDto}
   */
  public static void setGroupCode(FilterDto filter, String code) {
    set(filter, JSON_GROUP_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link ReportsGroupDto}.
   *
   * @param filter filtre
   * @return code de {@link ReportsGroupDto}
   */
  public static String getGroupCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_CODE));
  }


  /**
   * Identifiant json champ {@link ReportFilter#groupCode}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
      ReportGroupDto.JSON_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link ReportFilter#groupCode}.
   */
  public static final String JSON_GROUP_CODE =
      "codeGroupe";

}

