package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasIsLocalAuthority;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasIsNationalPublicInstitution;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ResourceFilter extends AbstractResourceOrReceiverFilter
    implements FilterHasTypeCode, FilterHasUserName, FilterHasIsNationalPublicInstitution,
    FilterHasIsLocalAuthority {

  /**
   * {@link ResourceType}.
   */
  ResourceType type;

  /**
   * Code {@link ResourceType}.
   */
  String typeCode;

  /**
   * Nom d'utilisateur.
   */
  String userName;

  /**
   * Est EPN.
   */
  Boolean isNationalPublicInstitution;

  /**
   * Est Collectivité.
   */
  Boolean isLocalAuthority;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ResourceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ResourceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    type = getType(filter);
    updateTypeCode(filter);
    updateUserName(filter);
    updateIsNationalPublicInstitution(filter);
    updateIsLocalAuthority(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setType(filter, type);
    updateFilterTypeCode(filter);
    updateFilterUserName(filter);
    updateFilterIsNationalPublicInstitution(filter);
    updateFilterIsLocalAuthority(filter);
  }

  /**
   * Cette méthode permet d'assigner la {@link ResourceType}.
   *
   * @param filter filtre
   * @param type {@link ResourceType}
   */
  public static void setType(FilterDto filter, ResourceType type) {
    set(filter, JSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(type));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ResourceType}.
   *
   * @param filter filtre
   * @return {@link ResourceType}
   */
  public static ResourceType getType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_TYPE, ResourceType.class));
  }
}
