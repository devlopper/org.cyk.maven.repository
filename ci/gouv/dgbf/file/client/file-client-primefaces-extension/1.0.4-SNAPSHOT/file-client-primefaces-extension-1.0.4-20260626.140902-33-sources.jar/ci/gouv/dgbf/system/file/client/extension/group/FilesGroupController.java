package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FilesGroupController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FilesGroupRequestMapper requestMapper;

  @Inject
  @Getter
  SelectBooleanController isConfirmedSelectBooleanController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FilesGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FilesGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FilesGroupService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      FilesGroupCreateRequestDto request = requestMapper.mapCreate((FilesGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getShowUpdateDialogButton().setRendered(false);

    listController.getGotoReadPageButton().setOutcome(FilesGroupReadPage.OUTCOME);
    listController.getGotoReadPageButton().setRendered(true);

    isConfirmedSelectBooleanController.setOutputLableValue("Est confirmé ?");
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices();
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean()
        .addValueConsumer(isConfirmedConsumer());
  }

  Consumer<Boolean> isConfirmedConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(FilesGroupDto.class).setIsConfirmed(value);
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(isConfirmedSelectBooleanController.getSelectOneRadioBoolean()).stream()
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
