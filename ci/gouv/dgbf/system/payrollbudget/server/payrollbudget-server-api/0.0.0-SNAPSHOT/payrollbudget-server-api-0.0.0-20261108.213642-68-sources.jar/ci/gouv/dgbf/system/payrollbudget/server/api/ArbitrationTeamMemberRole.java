package ci.gouv.dgbf.system.payrollbudget.server.api;

import java.util.Arrays;
import java.util.List;
import lombok.Getter;

/**
 * Les titres sous lesquels un agent peut figurer dans une équipe d'arbitrage.
 *
 * <p><strong>Ce n'est pas une liste de droits.</strong> Le titre rend la composition lisible —
 * qui tient les mouvements, qui tient les transferts — mais ce que l'agent peut réellement
 * instruire se lit dans son jeton, et nulle part ailleurs.</p>
 *
 * <p>Les cinq valeurs sont celles que la contrainte {@code CK_EQUIPE_MBR_ROLE} autorise en
 * base, reprises telles quelles. <strong>Quatre d'entre elles ne coïncident pas avec le code
 * du profil Keycloak de même nom</strong>, seul {@code CHEF_EQUIPE} s'écrit pareil :</p>
 *
 * <ul>
 *   <li>{@code CHARGE_CONTROLE} en base, {@code CHARGE_DE_CONTROLE} au profil ;</li>
 *   <li>{@code CHARGE_MOUVEMENT} en base, {@code CHARGE_MOUVEMENTS} au profil ;</li>
 *   <li>{@code CHARGE_MESURE_PONCTUELLE} en base, {@code CHARGE_MESURES_PONCTUELLES} au
 *       profil ;</li>
 *   <li>{@code CHARGE_TRANSFERT_SOLDE} en base, {@code CHARGE_TRANSFERTS_SOLDE} au profil.</li>
 * </ul>
 *
 * <p>Le singulier d'un côté, le pluriel de l'autre : l'écart est antérieur à ce
 * développement, et l'aligner demanderait une migration de contrainte, qui relève du
 * métier. En attendant, ne jamais prendre l'un pour l'autre — un code de profil posé comme
 * rôle d'équipe part jusqu'à la base et en revient en {@code ORA-02290}.</p>
 *
 * <p>Sans cette énumération, un titre hors liste partait jusqu'à la base et en revenait en
 * {@code ORA-02290} — un numéro d'erreur Oracle, là où l'agent attend une phrase.</p>
 *
 * @author Christian
 *
 */
@Getter
public enum ArbitrationTeamMemberRole {

  /**
   * Chargé de contrôle : réceptionne et joint les pièces.
   */
  CONTROL_OFFICER("CHARGE_CONTROLE", "Chargé de contrôle"),

  /**
   * Chargé des mouvements projetés.
   */
  MOVEMENT_OFFICER("CHARGE_MOUVEMENT", "Chargé des mouvements"),

  /**
   * Chargé des mesures ponctuelles.
   */
  PUNCTUAL_MEASURE_OFFICER("CHARGE_MESURE_PONCTUELLE", "Chargé des mesures ponctuelles"),

  /**
   * Chargé des transferts de solde.
   */
  BALANCE_TRANSFER_OFFICER("CHARGE_TRANSFERT_SOLDE", "Chargé des transferts de solde"),

  /**
   * Chef d'équipe.
   */
  TEAM_LEADER("CHEF_EQUIPE", "Chef d'équipe");

  private final String code;

  private final String name;

  ArbitrationTeamMemberRole(String code, String name) {
    this.code = code;
    this.name = name;
  }

  /**
   * Retrouve un titre par son code.
   *
   * @param code code recherché
   * @return le titre correspondant
   * @throws IllegalArgumentException si le code n'est d'aucun titre
   */
  public static ArbitrationTeamMemberRole getByCode(String code) {
    return Arrays.stream(values()).filter(role -> role.code.equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException(
            "Le role « %s » n'est pas un titre d'equipe connu.".formatted(code)));
  }

  /**
   * Indique si un code désigne un titre connu.
   *
   * @param code code examiné
   * @return vrai si la base l'accepterait
   */
  public static boolean isKnown(String code) {
    return Arrays.stream(values()).anyMatch(role -> role.code.equals(code));
  }

  /**
   * Les cinq titres, dans l'ordre du circuit.
   *
   * @return les titres
   */
  public static List<ArbitrationTeamMemberRole> getAll() {
    return Arrays.asList(values());
  }

  @Override
  public String toString() {
    return name;
  }
}
