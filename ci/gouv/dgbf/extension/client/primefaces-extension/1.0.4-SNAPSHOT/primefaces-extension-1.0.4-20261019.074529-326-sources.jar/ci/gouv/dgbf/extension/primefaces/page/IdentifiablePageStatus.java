package ci.gouv.dgbf.extension.primefaces.page;

/** États de résolution d'une page centrée sur une ressource. */
public enum IdentifiablePageStatus {
  INITIAL,
  LOADING,
  MISSING_IDENTIFIER,
  NO_RESOURCE_AVAILABLE,
  NOT_FOUND,
  AVAILABLE,
  ACCESS_DENIED,
  ERROR
}
