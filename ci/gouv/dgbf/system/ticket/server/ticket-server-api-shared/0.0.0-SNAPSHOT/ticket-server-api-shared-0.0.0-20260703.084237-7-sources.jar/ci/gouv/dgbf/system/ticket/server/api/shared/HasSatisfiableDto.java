package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être satisfait.
 *
 * @author Christian
 */
public interface HasSatisfiableDto extends HasSatisfiable {

  /**
   * Identifiant json de peut être satisfait.
   */
  String JSON_SATISFIABLE = "peutEtreSatisfait";
}