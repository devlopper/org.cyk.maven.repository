package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionTypeDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class FunctionTypeFilter extends AbstractIdentifiableFilter {
  
}
