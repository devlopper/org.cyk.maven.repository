package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les champs concernés par une entrée du journal du Fichier
 * (RG_FILE_FIC_23). Les Propriétés ({@code PROPRIETE}) arrivent avec TCH_FILE_651.
 *
 * @author Christian
 */
@Getter
public enum FileJournalFieldKind {

  /** {@link FileJournalFieldKindCode#NAME}. */
  NAME(FileJournalFieldKindCode.NAME, "Nom"),

  /** {@link FileJournalFieldKindCode#DESCRIPTION}. */
  DESCRIPTION(FileJournalFieldKindCode.DESCRIPTION, "Description"),

  /** {@link FileJournalFieldKindCode#PRODUCTION_DATE}. */
  PRODUCTION_DATE(FileJournalFieldKindCode.PRODUCTION_DATE, "Date de production"),

  /** {@link FileJournalFieldKindCode#HOLDER}. */
  HOLDER(FileJournalFieldKindCode.HOLDER, "Détenteur");

  private final String code;
  private final String name;

  private FileJournalFieldKind(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le champ par code.
   *
   * @param code code stocké
   * @return champ
   */
  public static FileJournalFieldKind getByCode(String code) {
    return Stream.of(values()).filter(kind -> kind.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
