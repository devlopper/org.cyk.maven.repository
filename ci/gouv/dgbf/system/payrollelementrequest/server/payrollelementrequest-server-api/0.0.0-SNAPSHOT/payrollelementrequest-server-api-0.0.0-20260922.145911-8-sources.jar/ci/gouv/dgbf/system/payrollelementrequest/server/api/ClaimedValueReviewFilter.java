package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimedValueReviewDto} -- utilisé en interne par
 * {@code ClaimedValueReviewTransmitToVisaBusiness} (transmission groupée pour Visa,
 * RG_REP_RVR_01) et par l'obtention générique de plusieurs (RU_REP_015, portefeuille de l'Agent
 * par statut et par rôle).
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimedValueReviewFilter extends AbstractIdentifiableFilter {

  /**
   * Statut courant du circuit ({@code GENEREE}, {@code TRANSMISE_VISA}, ...).
   */
  String status;

  /**
   * Identifiant de l'Agent de Traitement ayant traité la réclamation à l'origine de la revue
   * (via {@code ClaimedValue.claim.processingAgentIdentifier}).
   */
  String processingAgentIdentifier;

  /**
   * Identifiants des réclamations sélectionnées par l'Agent (portefeuille, "Transmettre la
   * sélection") -- l'Agent choisit quelles réclamations transmettre pour Visa, jamais quelle
   * Revue individuelle parmi celles d'une même réclamation (RG_REP_RVR_02).
   */
  Set<String> claimIdentifiers;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimedValueReviewFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimedValueReviewFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    status = getStatus(filter);
    processingAgentIdentifier = getProcessingAgentIdentifier(filter);
    claimIdentifiers = getClaimIdentifiers(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setStatus(filter, status);
    setProcessingAgentIdentifier(filter, processingAgentIdentifier);
    setClaimIdentifiers(filter, claimIdentifiers);
  }

  /**
   * Cette méthode permet d'assigner le statut courant.
   *
   * @param filter filtre
   * @param status statut courant
   */
  public static void setStatus(FilterDto filter, String status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsString(status));
  }

  /**
   * Cette méthode permet d'obtenir le statut courant.
   *
   * @param filter filtre
   * @return statut courant
   */
  public static String getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'Agent de Traitement.
   *
   * @param filter filtre
   * @param processingAgentIdentifier identifiant de l'Agent de Traitement
   */
  public static void setProcessingAgentIdentifier(FilterDto filter,
      String processingAgentIdentifier) {
    set(filter, JSON_PROCESSING_AGENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(processingAgentIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'Agent de Traitement.
   *
   * @param filter filtre
   * @return identifiant de l'Agent de Traitement
   */
  public static String getProcessingAgentIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESSING_AGENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants de réclamations sélectionnées.
   *
   * @param filter filtre
   * @param claimIdentifiers identifiants de réclamations sélectionnées
   */
  public static void setClaimIdentifiers(FilterDto filter, Set<String> claimIdentifiers) {
    set(filter, JSON_CLAIM_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet(
            (LinkedHashSet<String>) Core.getLinkedHashSet(claimIdentifiers)));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants de réclamations sélectionnées -- {@code null}
   * si absent ou vide (jamais un ensemble vide) : {@link #setClaimIdentifiers} normalise toujours
   * {@code null} en ensemble vide côté sérialisation (via {@code Core.getLinkedHashSet}), et un
   * prédicat {@code IN} construit sur un ensemble vide exclurait sinon systématiquement tout
   * résultat (ex. {@code ClaimedValueReviewDynamicQuery}, RU_REP_015) au lieu de ne pas filtrer
   * du tout.
   *
   * @param filter filtre
   * @return identifiants de réclamations sélectionnées, ou {@code null} si aucun
   */
  public static Set<String> getClaimIdentifiers(FilterDto filter) {
    Set<String> claimIdentifiers =
        get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_CLAIM_IDENTIFIERS));
    return claimIdentifiers == null || claimIdentifiers.isEmpty() ? null : claimIdentifiers;
  }

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #processingAgentIdentifier}.
   */
  public static final String JSON_PROCESSING_AGENT_IDENTIFIER = "agentTraitement";

  /**
   * Identifiant json champ {@link #claimIdentifiers}.
   */
  public static final String JSON_CLAIM_IDENTIFIERS = "idsReclamations";
}
