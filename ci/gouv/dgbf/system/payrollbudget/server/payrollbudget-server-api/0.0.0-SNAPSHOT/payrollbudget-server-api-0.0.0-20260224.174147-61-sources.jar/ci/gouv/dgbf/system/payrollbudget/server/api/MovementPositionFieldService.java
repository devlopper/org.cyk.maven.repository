package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link MovementPositionFieldDto}.
 *
 * @author Christian
 *
 */
@Path(value = MovementPositionFieldService.PATH)
@Tag(name = "Gestion des mouvements")
public interface MovementPositionFieldService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "champs-positions-mouvements";

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface MovementPositionFieldSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link MovementDto}.
     *
     * @return identifiant {@link MovementDto}
     */
    String getMovementIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link MovementDto}.
     *
     * @param identifier identifiant {@link MovementDto}
     */
    void setMovementIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir {@link PositionField}.
     *
     * @return {@link PositionField}
     */
    PositionField getPositionField();

    /**
     * Cette méthode permet d'assigner {@link PositionField}.
     *
     * @param positionField {@link PositionField}
     */
    void setPositionField(PositionField positionField);

    /**
     * Cette méthode permet d'obtenir la référence.
     *
     * @return référence
     */
    String getReference();

    /**
     * Cette méthode permet d'assigner la référence.
     *
     * @param reference référence
     */
    void setReference(String reference);

    /**
     * {@link MovementPositionFieldDto#JSON_MOVEMENT_IDENTIFIER}.
     */
    String JSON_MOVEMENT_IDENTIFIER = MovementPositionFieldDto.JSON_MOVEMENT_IDENTIFIER;

    /**
     * {@link MovementPositionFieldDto#JSON_POSITION_FIELD}.
     */
    String JSON_POSITION_FIELD = MovementPositionFieldDto.JSON_POSITION_FIELD;

    /**
     * {@link MovementPositionFieldDto#JSON_REFERENCE}.
     */
    String JSON_REFERENCE = MovementPositionFieldDto.JSON_REFERENCE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MovementPositionFieldCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class MovementPositionFieldCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements MovementPositionFieldSaveRequestDto {

    @JsonbProperty(JSON_MOVEMENT_IDENTIFIER)
    String movementIdentifier;

    @JsonbProperty(JSON_POSITION_FIELD)
    PositionField positionField;

    @JsonbProperty(JSON_REFERENCE)
    String reference;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = MovementPositionFieldGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class MovementPositionFieldGetManyResponseDto
      extends AbstractGetByPageResponseDto<MovementPositionFieldDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MovementPositionFieldDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(MovementPositionFieldUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class MovementPositionFieldUpdateRequestDto extends ByIdentifierRequestDto
      implements MovementPositionFieldSaveRequestDto {

    @JsonbProperty(JSON_MOVEMENT_IDENTIFIER)
    String movementIdentifier;

    @JsonbProperty(JSON_POSITION_FIELD)
    PositionField positionField;

    @JsonbProperty(JSON_REFERENCE)
    String reference;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CHAMP_POSITION_MOUVEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
