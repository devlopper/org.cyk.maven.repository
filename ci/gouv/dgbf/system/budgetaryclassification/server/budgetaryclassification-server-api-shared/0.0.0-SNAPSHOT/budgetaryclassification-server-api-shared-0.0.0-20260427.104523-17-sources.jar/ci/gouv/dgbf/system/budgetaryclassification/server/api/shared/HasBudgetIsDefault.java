package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de budget est par défaut.
 *
 * @author Christian
 */
public interface HasBudgetIsDefault extends HasField {

  /**
   * Cette méthode permet d'obtenir budget est par défaut.
   *
   * @return budget est par défaut
   */
  Boolean getBudgetIsDefault();
  
  /**
   * Cette méthode permet d'assigner budget est par défaut.
   *
   * @param isBudgetDefault budget est par défaut
   */
  void setBudgetIsDefault(Boolean isBudgetDefault);
  
  /**
   * Identifiant java de budget est par défaut.
   */
  String FIELD_BUDGET_IS_DEFAULT = "budgetIsDefault";
}