package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptEvaluationDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ScriptEvaluationFilter extends AbstractScriptDataFilter {

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptEvaluationFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ScriptEvaluationFilter(FilterDto dto) {
    super(dto);
  }

}
