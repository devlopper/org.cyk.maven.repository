package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityService.ResourceConfidentialityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/** Mapping des requêtes REST de confidentialité. */
@Mapper
@Javadoc("""
    Mapping des requêtes REST de confidentialité.
    """)
public interface ResourceConfidentialityRequestMapper extends
    RequestMapper<ResourceConfidentialityDto, ResourceConfidentialityCreateRequestDto,
        ResourceConfidentialityUpdateRequestDto> {
}
