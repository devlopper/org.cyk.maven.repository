package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryRegistrationNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbTypeDeserializer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Fonctionnaire ou Agent de l'État (FAE), mappée sur
 * {@code VA_FONCTIONNAIRE} : identité (jointure cross-schema réelle sur
 * {@code REMUNERATION}/{@code IDENTITE}/{@code EMPLOYE}/{@code FONCTIONNAIRE}/
 * {@code CLASSIFICATION_BUDGETAIRE}) fusionnée avec les compteurs de réclamations calculés sur
 * {@code TA_RECLAMATION}. Un FAE pouvant tenir plusieurs bulletins de paie, chacun rattaché à une
 * structure différente, {@link #structures} expose un tableau (schéma JSON libre, seule
 * {@link #JSON_STRUCTURE_SERVICE} est une clé garantie) plutôt qu'une affectation unique.
 * Aucune donnée stockée -- recalculée à chaque lecture.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryDto extends AbstractIdentifiableDto
    implements HasFunctionaryRegistrationNumberDto, HasEmailAddressDto {

  /**
   * Matricule.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(JSON_LAST_NAME)
  private String lastName;

  /**
   * Prénom.
   */
  @JsonbProperty(JSON_FIRST_NAME)
  private String firstName;

  /**
   * Adresse email -- {@code null} si aucune adresse connue pour ce FAE (jamais obligatoire).
   */
  @JsonbProperty(JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Structures (regroupements Section/Service) du FAE -- une par Structure, schéma libre ; chaque
   * attribut (section, service, emploi, fonction, localite, grade, classe, echelon) est soit un
   * objet {@code {code,libelle}}, soit un tableau de tels objets quand plusieurs valeurs actives
   * coexistent pour cette Structure (ex. deux Fonctions), {@code indice} restant une valeur
   * simple. Aucun identifiant de bulletin de paie n'est exposé ici -- la résolution du bulletin
   * exact se fait par {@link #registrationNumber} et le {@code code} de {@code service}.
   * Désérialisée côté serveur depuis {@code VA_FONCTIONNAIRE} (voir
   * {@code FunctionaryDynamicQuery}), jamais transmise sous forme de chaîne JSON encodée. Jamais
   * {@code null} (liste vide par défaut). {@link StructuresJsonbDeserializer} préserve l'ordre des
   * clés de chaque structure à toute désérialisation JSON-B de ce champ, y compris côté client
   * (réponse REST) -- la désérialisation JSON-B générique d'un {@code Map} ne le garantit pas.
   */
  @JsonbProperty(JSON_STRUCTURES)
  @JsonbTypeDeserializer(StructuresJsonbDeserializer.class)
  private List<Map<String, Object>> structures = new ArrayList<>();

  /**
   * Nombre total de réclamations ayant fait l'objet d'au moins une Soumission -- exclut les
   * brouillons à l'état {@code CREEE} jamais soumis.
   */
  @JsonbProperty(JSON_TOTAL_CLAIM_COUNT)
  private Integer totalClaimCount;

  /**
   * Nombre de réclamations en cours ({@code SOUMISE} + {@code PRISE_EN_CHARGE}).
   */
  @JsonbProperty(JSON_IN_PROGRESS_CLAIM_COUNT)
  private Integer inProgressClaimCount;

  /**
   * Nombre de réclamations acceptées.
   */
  @JsonbProperty(JSON_ACCEPTED_CLAIM_COUNT)
  private Integer acceptedClaimCount;

  /**
   * Nombre de réclamations rejetées.
   */
  @JsonbProperty(JSON_REJECTED_CLAIM_COUNT)
  private Integer rejectedClaimCount;

  /**
   * Nombre de réclamations différées.
   */
  @JsonbProperty(JSON_DEFERRED_CLAIM_COUNT)
  private Integer deferredClaimCount;

  /**
   * Pont vers {@link HasFunctionaryRegistrationNumberDto} : nom d'accesseur imposé par cette
   * interface de segregation, distinct du nom de {@link #registrationNumber} conservé (repris tel
   * quel par plusieurs écrans client via {@code #{functionary.registrationNumber}} -- le renommer
   * romprait ces vues sans bénéfice).
   *
   * @return {@link #registrationNumber}
   */
  @Override
  public String getFunctionaryRegistrationNumber() {
    return registrationNumber;
  }

  /**
   * {@link #getFunctionaryRegistrationNumber()}.
   *
   * @param functionaryRegistrationNumber {@link #registrationNumber}
   */
  @Override
  public void setFunctionaryRegistrationNumber(String functionaryRegistrationNumber) {
    this.registrationNumber = functionaryRegistrationNumber;
  }

  /**
   * Identifiant json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER =
      HasFunctionaryRegistrationNumberDto.JSON_FUNCTIONARY_REGISTRATION_NUMBER;

  /**
   * Identifiant json {@link #lastName}.
   */
  public static final String JSON_LAST_NAME = "nom";

  /**
   * Identifiant json {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "prenom";

  /**
   * Identifiant json {@link #structures}.
   */
  public static final String JSON_STRUCTURES = "structures";

  /**
   * Clé (au sein d'une structure de {@link #structures}) portant le Service ({@code
   * {code,libelle}}) -- {@code service.code} est la référence stable pour une réclamation
   * choisissant sa structure, combinée à {@link #registrationNumber} pour résoudre le bulletin de
   * paie exact.
   */
  public static final String JSON_STRUCTURE_SERVICE = "service";

  /**
   * Clé (au sein d'une structure de {@link #structures}) portant la Section Budgétaire ({@code
   * {code,libelle}}) -- repli d'affichage si {@link #JSON_STRUCTURE_SERVICE} est absent.
   */
  public static final String JSON_STRUCTURE_SECTION = "section";

  /**
   * Clé (au sein d'une structure de {@link #structures}) portant l'Emploi ({@code
   * [{code,libelle}, ...]}) -- repli d'affichage si {@link #JSON_STRUCTURE_SERVICE} et
   * {@link #JSON_STRUCTURE_SECTION} sont absents.
   */
  public static final String JSON_STRUCTURE_EMPLOI = "emploi";

  // Aucune constante pour les autres attributs de structure (fonction, localite, grade, classe,
  // echelon, indice, ou tout attribut futur) : le schema de STRUCTURES_JSON reste volontairement
  // libre et extensible sans redeploiement (cf. FunctionaryController#structureEntries) -- une
  // constante par cle nommement connue reintroduirait une dependance figee a un schema cense
  // rester dynamique, a l'oppose du but recherche.

  /**
   * Clé (au sein d'un objet {@code {code,libelle}} de {@link #structures}) portant le code.
   */
  public static final String JSON_STRUCTURE_ATTRIBUTE_CODE = "code";

  /**
   * Clé (au sein d'un objet {@code {code,libelle}} de {@link #structures}) portant le libellé.
   */
  public static final String JSON_STRUCTURE_ATTRIBUTE_LABEL = "libelle";

  /**
   * Clé (au sein d'un objet {@code {code,libelle,element}} de {@link #structures}) portant le code
   * {@code payroll} de l'Élément de paie dont la valeur est issue -- permet de retrouver, sans
   * connaître le nom de la clé de l'attribut, celui qui porte les valeurs d'un Élément donné
   * (RG_REP_IMP_01).
   */
  public static final String JSON_STRUCTURE_ATTRIBUTE_ELEMENT = "element";

  /**
   * Clé (au sein d'un objet de {@link #structures}) portant le code de l'Emploi dont la valeur est
   * issue -- le Grade (porté par l'Emploi) s'en sert pour être rattaché à l'Emploi qui le porte.
   */
  public static final String JSON_STRUCTURE_ATTRIBUTE_EMPLOI = "emploi";

  /**
   * Identifiant json {@link #totalClaimCount}.
   */
  public static final String JSON_TOTAL_CLAIM_COUNT = "nombreReclamationsTotal";

  /**
   * Identifiant json {@link #inProgressClaimCount}.
   */
  public static final String JSON_IN_PROGRESS_CLAIM_COUNT = "nombreReclamationsEnCours";

  /**
   * Identifiant json {@link #acceptedClaimCount}.
   */
  public static final String JSON_ACCEPTED_CLAIM_COUNT = "nombreReclamationsAcceptees";

  /**
   * Identifiant json {@link #rejectedClaimCount}.
   */
  public static final String JSON_REJECTED_CLAIM_COUNT = "nombreReclamationsRejetees";

  /**
   * Identifiant json {@link #deferredClaimCount}.
   */
  public static final String JSON_DEFERRED_CLAIM_COUNT = "nombreReclamationsDifferees";

  /**
   * Identifiant json de identifiant de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaire";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FunctionaryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "fonctionnaires";
}
