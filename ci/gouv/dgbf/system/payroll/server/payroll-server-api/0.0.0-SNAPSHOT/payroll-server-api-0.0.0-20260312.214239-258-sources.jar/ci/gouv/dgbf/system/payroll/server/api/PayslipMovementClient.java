package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementProcessRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementProcessResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipMovementService.PayslipMovementUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayslipMovementService}.
 *
 * @author stephane
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayslipMovementClient extends AbstractClient<PayslipMovementService>
    implements GetByIdentifier<PayslipMovementDto>, GetMany<PayslipMovementGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayslipMovementClient service(PayslipMovementService service) {
    return (PayslipMovementClient) super.service(service);
  }

  /**
   * {@link PayslipMovementService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayslipMovementCreateRequestDto request) {
    return new CreateExecutor(PayslipMovementService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayslipMovementService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayslipMovementGetManyResponseDto>(
        PayslipMovementGetManyResponseDto.class, PayslipMovementService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayslipMovementService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipMovementGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayslipMovementService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayslipMovementDto>(PayslipMovementDto.class,
        PayslipMovementService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayslipMovementService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipMovementDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayslipMovementService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayslipMovementDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayslipMovementDto>(PayslipMovementDto.class,
        PayslipMovementService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayslipMovementService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipMovementDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayslipMovementService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayslipMovementUpdateRequestDto request) {
    return new IdentifiableExecutor(PayslipMovementService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayslipMovementService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayslipMovementService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayslipMovementService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link PayslipMovementService#activate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementProcessResponseDto activate(PayslipMovementProcessRequestDto request) {
    return new PayslipMovementProcessExecutor(PayslipMovementService.ACTIVATE_IDENTIFIER)
        .execute(() -> service().activate(request));
  }

  /**
   * {@link PayslipMovementService#defer}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementProcessResponseDto defer(PayslipMovementProcessRequestDto request) {
    return new PayslipMovementProcessExecutor(PayslipMovementService.DEFER_IDENTIFIER)
        .execute(() -> service().defer(request));
  }

  /**
   * {@link PayslipMovementService#reject}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementProcessResponseDto reject(PayslipMovementProcessRequestDto request) {
    return new PayslipMovementProcessExecutor(PayslipMovementService.REJECT_IDENTIFIER)
        .execute(() -> service().reject(request));
  }

  /**
   * {@link PayslipMovementService#proposeDeferral}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementProcessResponseDto proposeDeferral(
      PayslipMovementProcessRequestDto request) {
    return new PayslipMovementProcessExecutor(PayslipMovementService.PROPOSE_DEFERRAL_IDENTIFIER)
        .execute(() -> service().proposeDeferral(request));
  }

  /**
   * {@link PayslipMovementService#proposeRejection}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipMovementProcessResponseDto proposeRejection(
      PayslipMovementProcessRequestDto request) {
    return new PayslipMovementProcessExecutor(PayslipMovementService.PROPOSE_REJECTION_IDENTIFIER)
        .execute(() -> service().proposeRejection(request));
  }

  /**
   * {@link PayslipMovementService#updateActualMovement}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateActualMovement(
      PayslipMovementUpdateRequestDto request) {
    return new IdentifiableExecutor(
        PayslipMovementService.UPDATE_ACTUAL_MOVEMENT_IDENTIFIER)
        .execute(() -> service().updateActualMovement(request));
  }

  /**
   * Cette classe représente un exécuteur de traitement .
   *
   * @author Christian
   *
   */
  public class PayslipMovementProcessExecutor extends Executor<PayslipMovementProcessResponseDto> {

    /**
     * Cette méthode permet d'instancier.
     *
     * @param identifier identifiant
     */
    public PayslipMovementProcessExecutor(String identifier) {
      super(PayslipMovementProcessResponseDto.class, identifier);
    }

  }
}
