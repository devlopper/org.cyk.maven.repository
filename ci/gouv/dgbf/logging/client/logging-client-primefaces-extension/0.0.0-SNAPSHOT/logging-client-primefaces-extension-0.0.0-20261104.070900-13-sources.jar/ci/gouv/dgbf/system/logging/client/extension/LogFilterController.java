package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.LogLevelSelectOneController;
import ci.gouv.dgbf.system.logging.server.api.LogDto;
import ci.gouv.dgbf.system.logging.server.api.LogFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link LogDto}.
 *
 * @author Christian
 */
@Dependent
public class LogFilterController extends AbstractFilterController<LogFilter> {

  @Inject
  @Getter
  InputTextController processIdentifierInputTextController;
  
  @Inject
  @Getter
  InputTextController userNameInputTextController;

  @Inject
  @Getter
  InputTextController messageInputTextController;

  @Inject
  @Getter
  InputTextController auditSessionInputTextController;

  @Inject
  @Getter
  LogLevelSelectOneController levelSelectOneController;

  /**
   * Cette méthode permet d'instantier.
   */
  public LogFilterController() {
    super(LogFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    processIdentifierInputTextController.setOutputLableValue("Identifiant du processus");
    processIdentifierInputTextController.getInputText()
        .addValueConsumer(identifier -> filter.setProcessIdentifier(identifier));
    
    levelSelectOneController.getSelectOneRadio().getOutputLabel().setValue("Niveau");
    levelSelectOneController.getSelectOneRadio().addValueConsumer(levelNameConsumer());

    userNameInputTextController.setOutputLableValue("Nom de l'utilisateur");
    userNameInputTextController.getInputText()
        .addValueConsumer(userName -> filter.setUserName(userName));

    messageInputTextController.setOutputLableValue("Message");
    messageInputTextController.getInputText()
        .addValueConsumer(message -> filter.setMessage(message));

    auditSessionInputTextController.setOutputLableValue("Session d'audit");
    auditSessionInputTextController.getInputText()
        .addValueConsumer(session -> filter.setAuditSession(session));
  }

  Consumer<String> levelNameConsumer() {
    return name -> filter
        .setLevelCode(Optional.ofNullable(Core.getEnumerationValueByName(LogLevel.class, name))
            .map(LogLevel::getCode).orElse(null));
  }
}
