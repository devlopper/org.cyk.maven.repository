package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueService.ConditionalValueCheckApplicabilityRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueService.ConditionalValueCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueService.ConditionalValueUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ConditionalValueDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ConditionalValueDto}.

    @author Christian
               """)
public interface ConditionalValueRequestMapper extends RequestMapper<ConditionalValueDto,
    ConditionalValueCreateRequestDto, ConditionalValueUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper.
   *
   * @param conditionalValue {@link ConditionalValueDto}
   * @return {@link ConditionalValueCheckApplicabilityRequestDto}
   */
  ConditionalValueCheckApplicabilityRequestDto mapCheckApplicability(
      ConditionalValueDto conditionalValue);

}
