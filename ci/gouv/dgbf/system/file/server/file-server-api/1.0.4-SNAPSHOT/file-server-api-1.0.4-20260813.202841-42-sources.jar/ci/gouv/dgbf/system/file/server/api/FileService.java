package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasConfirmedDto;
import ci.gouv.dgbf.extension.core.segregation.HasContentTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasPrimitiveBytesArrayDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestMultipartDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import java.util.function.Function;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import org.jboss.resteasy.annotations.providers.multipart.PartType;

/**
 * Cette interface représente un service de gestion de fichier.<br/>
 * Elle définit les méthodes pour créer des fichiers, obtenir les octets d'un fichier.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = FileService.PATH)
@Tag(name = "Gestion des fichiers")
public interface FileService {

  /**
   * Chemin du service de gestion de fichier.
   */
  String PATH = "fichiers";

  /**
   * Cette classe représente l'objet de transfert de donnée de base des requêtes au format multipart
   * liée au propriétaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  abstract class AbstractOwnerRequestMultipartDto extends AbstractAuditedRequestMultipartDto {

    /**
     * Identifiant {@link OwnerDto}.
     */
    @NotNull
    @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
    @FormParam(value = JSON_OWNER_IDENTIFIER)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_OWNER_IDENTIFIER,
        description = "l'identifiant du propriétaire du fichier", example = "application01")
    private String ownerIdentifier;

    /**
     * Identifiant JSON {@link #ownerIdentifier}.
     */
    public static final String JSON_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER;
  }

  /**
   * Cette classe représente l'objet de transfert de donnée de base des requêtes au format json liée
   * au propriétaire.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  abstract class AbstractOwnerRequestJsonDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant {@link OwnerDto}.
     */
    @NotNull
    @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
    @Parameter(name = JSON_OWNER_IDENTIFIER,
        description = "l'identifiant du propriétaire du fichier", example = "application01")
    private String ownerIdentifier;

    /**
     * Identifiant JSON {@link #ownerIdentifier}.
     */
    public static final String JSON_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FICHIER";

  /**
   * Chemin du service de création de fichier.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un fichier.
   *
   * @param request la requête de crétation de fichier
   * @return la réponse de création de fichier
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un fichier",
      description = "Ce service permet de créer un fichier")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FileCreateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée de la requête de création d'un fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileCreateRequestDto extends AbstractOwnerRequestMultipartDto
      implements HasNameDto, HasContentTypeDto, HasPrimitiveBytesArrayDto, HasConfirmedDto {

    /**
     * Nom.
     */
    @NotNull
    @JsonbProperty(JSON_NAME)
    @FormParam(value = JSON_NAME)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_NAME, description = "le nom du fichier", example = "fichier01.txt")
    private String name;

    /**
     * Type de contenu.
     */
    @JsonbProperty(JSON_CONTENT_TYPE)
    @FormParam(value = JSON_CONTENT_TYPE)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONTENT_TYPE,
        description = "le type de contenu du fichier. Il doit respecter le format MIME",
        example = "text/plain")
    private String contentType;

    /**
     * Octets.
     */
    @NotEmpty
    @JsonbProperty(value = JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    @Parameter(name = JSON_BYTES, description = "les données binaires du fichier")
    private byte[] bytes;

    @JsonbProperty(value = JSON_CONFIRMED)
    @FormParam(value = JSON_CONFIRMED)
    @PartType(MediaType.TEXT_PLAIN)
    @Parameter(name = JSON_CONFIRMED,
        description = "si non fourni, le fichier est créé directement confirmé")
    private Boolean confirmed;
    
    /**
     * Identifiant JSON {@link #name}.
     */
    public static final String JSON_NAME = HasNameDto.JSON_NAME;

    /**
     * Identifiant JSON {@link #contentType}.
     */
    public static final String JSON_CONTENT_TYPE = HasContentTypeDto.JSON_CONTENT_TYPE;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = HasPrimitiveBytesArrayDto.JSON_BYTES;
  }

  /**
   * Identifiant du service d'obtention des octets d'un fichier.
   */
  String GET_BYTES_IDENTIFIER = "OBTENTION_OCTETS_FICHIER";

  /**
   * Chemin du service d'obtention des octets d'un fichier.
   */
  String GET_BYTES_PATH = "octets";

  /**
   * Cette méthode permet d'obtenir les octets d'un fichier.
   *
   * @param request la requête
   * @return les octets
   */
  @Path(GET_BYTES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_OCTET_STREAM)
  @Operation(operationId = GET_BYTES_IDENTIFIER, summary = "Obtention des octets d'un fichier",
      description = "Ce service permet d'obtenir les octets d'un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = byte.class))})
  Response getBytes(GetBytesRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée de la requête d'obtention des octets
   * d'un fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class GetBytesRequestDto extends AbstractOwnerRequestJsonDto {

    /**
     * Identifiant {@link FileDto}.
     */
    @NotNull
    @JsonbProperty(JSON_IDENTIFIER)
    @Parameter(name = JSON_IDENTIFIER)
    private String identifier;

    /**
     * Identifiant JSON {@link #identifier}.
     */
    public static final String JSON_IDENTIFIER = AbstractIdentifiableDto.JSON_IDENTIFIER;

    /**
     * Cette méthode permet d'instantier une requête d'obtention de un.
     *
     * @param request requête
     * @return requête d'obtention de un
     */
    public static GetOneRequestDto instantiate(GetBytesRequestDto request) {
      if (request == null) {
        return null;
      }
      GetOneRequestDto getOneRequestDto = new GetOneRequestDto();
      getOneRequestDto.setAuditSession(request.getAuditSession());
      getOneRequestDto.setAuditWho(request.getAuditWho());
      getOneRequestDto.filter().addCriteria(AbstractIdentifiableFilter.JSON_IDENTIFIER,
          request.getIdentifier());
      getOneRequestDto.filter().addCriteria(FileFilter.JSON_OWNER_IDENTIFIER,
          request.getOwnerIdentifier());
      getOneRequestDto.projection().addNames(FileDto.JSON_BYTES);
      return getOneRequestDto;
    }
  }

  /**
   * Identifiant du service d'obtention des octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_OCTETS_PAR_IDENTIFIANT_FICHIER";

  /**
   * Chemin du service d'obtention des octets par identifiant.
   */
  String GET_BYTES_BY_IDENTIFIER_PATH = "octets-par-identifiant";

  /**
   * Cette méthode permet d'obtenir les octets par identifiant.
   *
   * @param request la requête
   * @return les octets
   */
  @Path(GET_BYTES_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_OCTET_STREAM)
  @Operation(operationId = GET_BYTES_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = byte.class))})
  Response getBytesByIdentifier(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de l'identifiant d'un fichier par les octets.
   */
  String GET_IDENTIFIER_BY_BYTES_IDENTIFIER = "OBTENTION_IDENTIFIANT_PAR_OCTETS";

  /**
   * Chemin du service d'obtention de l'identifiant d'un fichier par les octets.
   */
  String GET_IDENTIFIER_BY_BYTES_PATH = "identifiant-par-octets";

  /**
   * Cette méthode permet d'obtenir l'identifiant d'un fichier en fonction de ses octets.
   *
   * @param request la requête
   * @return l'identifiant
   */
  @POST
  @Path(GET_IDENTIFIER_BY_BYTES_PATH)
  @Consumes(MediaType.MULTIPART_FORM_DATA)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_IDENTIFIER_BY_BYTES_IDENTIFIER,
      summary = "Obtention de l'identifiant d'un fichier à partir de ses octets",
      description = "Ce service permet d'obtenir l'identifiant d'un fichier à partir de ses octets")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = String.class))})
  Response getIdentifierByBytes(GetIdentifierByBytesRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée de la requête d'obtention de
   * l'identifiant par du contenu de fichier.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class GetIdentifierByBytesRequestDto extends AbstractOwnerRequestMultipartDto {

    /**
     * Octets.
     */
    @NotNull
    @JsonbProperty(JSON_BYTES)
    @FormParam(value = JSON_BYTES)
    @PartType(MediaType.APPLICATION_OCTET_STREAM)
    private byte[] bytes;

    /**
     * Identifiant JSON {@link #bytes}.
     */
    public static final String JSON_BYTES = FileDto.JSON_BYTES;

    /**
     * Cette méthode permet d'instantier une requête d'obtention de un.
     *
     * @param request requête
     * @param hashComputationFunction fonction de calcul du hash
     * @return requête d'obtention de un
     */
    public static GetOneRequestDto instantiate(GetIdentifierByBytesRequestDto request,
        Function<byte[], String> hashComputationFunction) {
      if (request == null) {
        return null;
      }
      GetOneRequestDto getOneRequestDto = new GetOneRequestDto();
      getOneRequestDto.setAuditSession(request.getAuditSession());
      getOneRequestDto.setAuditWho(request.getAuditWho());
      getOneRequestDto.setFilter(new FilterDto());
      String hash = hashComputationFunction.apply(request.getBytes());
      getOneRequestDto.getFilter().addCriteria(FileFilter.JSON_HASH, hash);
      getOneRequestDto.getFilter().addCriteria(FileFilter.JSON_OWNER_IDENTIFIER,
          request.getOwnerIdentifier());
      getOneRequestDto.setProjection(new ProjectionDto());
      getOneRequestDto.getProjection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
      return getOneRequestDto;
    }
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FICHIER";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des fichiers")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<FileDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FileDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FICHIER";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un fichier")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention de un par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FICHIER";

  /**
   * Chemin du service d'obtention de un par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir un par identifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un fichier")
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FICHIER";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileUpdateRequestDto.class))})
  Response update(FileUpdateRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileUpdateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Identifiant du service de confirmation.
   */
  String CONFIRM_IDENTIFIER = "CONFIRMATION_FICHIER";

  /**
   * Chemin du service de confirmation.
   */
  String CONFIRM_PATH = "confirmation";

  /**
   * Cette méthode permet de confirmer {@link FileDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONFIRM_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONFIRM_IDENTIFIER,
      description = "Ce service permet de confirmer un fichier")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FileConfirmResponseDto.class))})
  Response confirm(FileConfirmRequestDto request);

  /**
   * Cette classe représente la requête de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileConfirmRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<FileStatus>, HasConfirmableDto {

    @JsonbProperty(JSON_STATUS)
    private FileStatus status;

    @JsonbProperty(JSON_CONFIRMABLE)
    private Boolean confirmable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link FileStatus}
     */
    public void initialize(FileStatus status) {
      this.status = status;
    }
  }

  /**
   * Cette classe représente la réponse de confirmation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class FileConfirmResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FICHIER";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un fichier")
  Response delete(DeleteOneRequestDto request);
}
