package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ReservedRole;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste des rôles d'une {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Named
@ViewScoped
public class ApplicationReadRolesPage extends AbstractApplicationReadDatasPage {

  @Inject
  @Getter
  RoleController roleController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    roleController.getFilterController().getFilter()
        .setApplicationIdentifier(application.getIdentifier());
    // Rôles métier seulement : les Rôles réservés sont dans l'onglet Administrateurs (RU_UTI_027)
    roleController.getFilterController().getFilter().setExcludedCodes(ReservedRole.CODES);
    roleController.initialize();
  }

  public static final String OUTCOME = "applicationReadRolesPage";
}
