package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.system.file.server.api.OwnerDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du bouton d'ouverture du visualisateur.
 *
 * @author Christian
 *
 */
@Dependent
public class OpenFileViewerButtonController extends AbstractController {

  @Getter
  @Setter
  String title;

  @Getter
  @Setter
  String type;

  @Getter
  @Setter
  String icon;

  @Getter
  @Setter
  String onClick;

  @Getter
  @Setter
  String styleClass;

  @Getter
  @Inject
  OpenFileViewerParametersDialogController parametersDialogController;

  @Inject
  FileViewerUriBuilder viewerUriBuilder;

  /**
   * Cette méthode permet de construire une instance.
   */
  public OpenFileViewerButtonController() {
    title = "Voir";
    icon = "pi pi-eye";
    type = "submit";
  }

  /**
   * Ouvrir.
   *
   * @param identifier identifiant
   * @param ownerIdentifier identifiant {@link OwnerDto}
   */
  public void open(String identifier, String ownerIdentifier) {
    parametersDialogController.viewerOpenerConsumer =
        opener -> opener.getScriptBuilder().setUriSupplier(
            () -> viewerUriBuilder.build(identifier, ownerIdentifier, userIdentifier, null));
    parametersDialogController.open();
  }
}
