package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PhaseDto}.
 *
 * @author stephane
 *
 */
@Path(value = PhaseService.PATH)
@Tag(name = "Gestion des phases")
public interface PhaseService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "phases";


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PHASE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Stephane
   *
   */
  interface PhaseSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramActivityDto}.
     *
     * @return identifiant de {@link TriennialProgramActivityDto}
     */
    String getTriennialProgramActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramActivityDto}.
     *
     * @param triennialProgramActivityIdentifier identifiant de {@link TriennialProgramActivityDto}
     */
    void setTriennialProgramActivityIdentifier(String triennialProgramActivityIdentifier);

    /**
     * Cette méthode permet d'assigner le numero de la phase.
     *
     * @param orderNumber numéro de la phase
     */
    void setOrderNumber(Integer orderNumber);

    /**
     * Cette méthode permet d'obténir le numero de la phase.
     *
     * @return numéro de la phase
     */
    Integer getOrderNumber();

    /**
     * Cette méthode permet d'assigner le commentaire.
     *
     * @param comment commentaire
     */
    void setComment(String comment);

    /**
     * Cette méthode permet d'obténir le commentaire.
     *
     * @return commentaire
     */
    String getComment();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param startDate date de début
     */
    void setStartDate(LocalDate startDate);

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @return date de début
     */
    LocalDate getStartDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param endDate date de fin
     */
    void setEndDate(LocalDate endDate);

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @return date de fin
     */
    LocalDate getEndDate();

    /**
     * Identifiant JSON {@link TriennialProgramActivityDto}.
     */
    public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
        PhaseDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;

    /**
     * Identitiant json {@link PhaseDto#triennialProgramActivityAsString}.
     */
    public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING =
        PhaseDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING;

    /**
     * Identitiant json {@link PhaseDto#orderNumber}.
     */
    public static final String JSON_ORDER_NUMBER = PhaseDto.JSON_ORDER_NUMBER;
    /**
     * Identitiant json {@link PhaseDto#startDate}.
     */
    public static final String JSON_START_DATE = PhaseDto.JSON_START_DATE;
    /**
     * Identitiant json {@link PhaseDto#endDate}.
     */
    public static final String JSON_END_DATE = PhaseDto.JSON_END_DATE;
    /**
     * Identitiant json {@link PhaseDto#comment}.
     */
    public static final String JSON_COMMENT = PhaseDto.JSON_COMMENT;
  }


  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PhaseCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Stephane
   *
   */
  @Getter
  @Setter
  class PhaseCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PhaseSaveRequestDto {

    /**
     * Identifiant de {@link TriennialProgramActivityDto}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    /**
     * Représentation en chaine de caractères de {@link TriennialProgramActivityDto}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING)
    private String triennialProgramActivityAsString;

    /**
     * Numéro de la phase {@link PhaseDto}.
     */
    @JsonbProperty(JSON_ORDER_NUMBER)
    private Integer orderNumber;

    /**
     * Commentaire {@link PhaseDto}.
     */
    @JsonbProperty(JSON_COMMENT)
    private String comment;

    /**
     * Date de début {@link PhaseDto}.
     */
    @JsonbProperty(JSON_START_DATE)
    private LocalDate startDate;

    /**
     * Date de fin {@link PhaseDto}.
     */
    @JsonbProperty(JSON_END_DATE)
    private LocalDate endDate;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PHASE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhaseGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Stephane
   *
   */
  @Getter
  @Setter
  public static class PhaseGetManyResponseDto extends AbstractGetByPageResponseDto<PhaseDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PhaseDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PHASE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PhaseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhaseDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PHASE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PhaseDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PHASE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PhaseUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Stephane
   *
   */
  @Getter
  @Setter
  class PhaseUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PhaseSaveRequestDto {

    /**
     * Identifiant de {@link TriennialProgramActivityDto}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    /**
     * Représentation en chaine de caractères de {@link TriennialProgramActivityDto}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING)
    private String triennialProgramActivityAsString;

    /**
     * Numéro de la phase {@link PhaseDto}.
     */
    @JsonbProperty(JSON_ORDER_NUMBER)
    private Integer orderNumber;

    /**
     * Commentaire {@link PhaseDto}.
     */
    @JsonbProperty(JSON_COMMENT)
    private String comment;

    /**
     * Date de début {@link PhaseDto}.
     */
    @JsonbProperty(JSON_START_DATE)
    private LocalDate startDate;

    /**
     * Date de fin {@link PhaseDto}.
     */
    @JsonbProperty(JSON_END_DATE)
    private LocalDate endDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PHASE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PhaseDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
