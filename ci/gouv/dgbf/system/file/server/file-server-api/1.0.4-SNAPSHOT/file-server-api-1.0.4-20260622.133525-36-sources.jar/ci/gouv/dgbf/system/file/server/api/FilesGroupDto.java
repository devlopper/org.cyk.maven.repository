package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un groupe de fichiers.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@Accessors(chain = true)
public class FilesGroupDto extends AbstractIdentifiableAuditableDto {
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de fichiers";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de fichiers";
}
