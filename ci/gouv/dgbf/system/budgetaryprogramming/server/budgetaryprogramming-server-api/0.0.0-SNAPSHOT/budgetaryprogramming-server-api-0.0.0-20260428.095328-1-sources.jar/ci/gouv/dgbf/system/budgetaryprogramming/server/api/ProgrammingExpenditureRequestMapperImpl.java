package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingExpenditureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-28T09:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingExpenditureRequestMapperImpl implements ProgrammingExpenditureRequestMapper {

    @Override
    public ProgrammingExpenditureService.ProgrammingExpenditureCreateRequestDto mapCreate(ProgrammingExpenditureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingExpenditureService.ProgrammingExpenditureCreateRequestDto programmingExpenditureCreateRequestDto = new ProgrammingExpenditureService.ProgrammingExpenditureCreateRequestDto();

        programmingExpenditureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingExpenditureCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingExpenditureCreateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingExpenditureCreateRequestDto.setExpenditureIdentifier( arg0.getExpenditureIdentifier() );

        return programmingExpenditureCreateRequestDto;
    }

    @Override
    public ProgrammingExpenditureService.ProgrammingExpenditureUpdateRequestDto mapUpdate(ProgrammingExpenditureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingExpenditureService.ProgrammingExpenditureUpdateRequestDto programmingExpenditureUpdateRequestDto = new ProgrammingExpenditureService.ProgrammingExpenditureUpdateRequestDto();

        programmingExpenditureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        programmingExpenditureUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        programmingExpenditureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingExpenditureUpdateRequestDto.setProgrammingIdentifier( arg0.getProgrammingIdentifier() );
        programmingExpenditureUpdateRequestDto.setExpenditureIdentifier( arg0.getExpenditureIdentifier() );

        return programmingExpenditureUpdateRequestDto;
    }
}
