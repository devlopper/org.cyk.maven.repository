package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultConstantIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ConstantCategoryDto}.
 *
 * @author Christian
 *
 */
@Path(value = ConstantCategoryService.PATH)
@Tag(name = "Gestion des catégories de constante")
public interface ConstantCategoryService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "categories-constantes";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ConstantCategorySaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant du domaine.
     *
     * @return l'identifiant du domaine
     */
    String getDomainIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du domaine.
     *
     * @param domainIdentifier l'identifiant du domaine
     */
    void setDomainIdentifier(String domainIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la constante par défaut.
     *
     * @return l'identifiant de la constante par défaut
     */
    String getDefaultConstantIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la constante par défaut.
     *
     * @param defaultConstantIdentifier l'identifiant de la constante par défaut
     */
    void setDefaultConstantIdentifier(String defaultConstantIdentifier);

    /**
     * {@link HasDomainIdentifierDto#JSON_DOMAIN_IDENTIFIER}.
     */
    String JSON_DOMAIN_IDENTIFIER = HasDomainIdentifierDto.JSON_DOMAIN_IDENTIFIER;

    /**
     * {@link HasDefaultConstantIdentifierDto#JSON_DEFAULT_CONSTANT_IDENTIFIER}.
     */
    String JSON_DEFAULT_CONSTANT_IDENTIFIER =
        HasDefaultConstantIdentifierDto.JSON_DEFAULT_CONSTANT_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ConstantCategoryCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantCategoryCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ConstantCategorySaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
    
    @JsonbProperty(JSON_DEFAULT_CONSTANT_IDENTIFIER)
    private String defaultConstantIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ConstantCategoryGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ConstantCategoryGetManyResponseDto
      extends AbstractGetByPageResponseDto<ConstantCategoryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ConstantCategoryDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantCategoryDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantCategoryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ConstantCategoryUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantCategoryUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ConstantCategorySaveRequestDto {

    @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
    private String domainIdentifier;
    
    @JsonbProperty(JSON_DEFAULT_CONSTANT_IDENTIFIER)
    private String defaultConstantIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'évaluation.
   */
  String EVALUATE_IDENTIFIER = "EVALUATION_CATEGORIE_CONSTANTE";

  /**
   * Chemin du service d'évaluation.
   */
  String EVALUATE_PATH = "evaluation";

  /**
   * Cette méthode permet d'évaluer {@link ConstantCategoryDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ConstantCategoryEvaluateResponseDto.class))})
  Response evaluate(ConstantCategoryEvaluateRequestDto request);

  /**
   * Cette classe représente la requête d'évaluation par identifiants.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantCategoryEvaluateRequestDto extends ByIdentifierRequestDto
      implements HasGroupIdentifierDto, HasFromDateDto<LocalDateTime>, HasToDateDto<LocalDateTime> {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;
  }

  /**
   * Cette classe représente la réponse d'évaluation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ConstantCategoryEvaluateResponseDto extends IdentifiableResponseDto
      implements HasStringValueDto, HasValueTypeDto {

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
  }
}
