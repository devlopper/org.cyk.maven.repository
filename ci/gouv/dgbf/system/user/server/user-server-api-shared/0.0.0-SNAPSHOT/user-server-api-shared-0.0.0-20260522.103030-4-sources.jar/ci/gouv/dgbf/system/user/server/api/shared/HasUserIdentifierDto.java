package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'utilisateur.
 *
 * @author Christian
 */
public interface HasUserIdentifierDto extends HasUserIdentifier {

  /**
   * Identifiant json de l'identifiant de l'utilisateur.
   */
  String JSON_USER_IDENTIFIER = "idUtilisateur";
}
