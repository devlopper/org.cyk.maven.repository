package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionGroupDto}.
*
* @author Boobacool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FunctionGroupTypeRequestMapperImpl implements FunctionGroupTypeRequestMapper {

    @Override
    public FunctionGroupTypeService.FunctionGroupTypeCreateRequestDto mapCreate(FunctionGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionGroupTypeService.FunctionGroupTypeCreateRequestDto functionGroupTypeCreateRequestDto = new FunctionGroupTypeService.FunctionGroupTypeCreateRequestDto();

        functionGroupTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionGroupTypeCreateRequestDto.setCode( arg0.getCode() );
        functionGroupTypeCreateRequestDto.setName( arg0.getName() );

        return functionGroupTypeCreateRequestDto;
    }

    @Override
    public FunctionGroupTypeService.FunctionGroupTypeUpdateRequestDto mapUpdate(FunctionGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionGroupTypeService.FunctionGroupTypeUpdateRequestDto functionGroupTypeUpdateRequestDto = new FunctionGroupTypeService.FunctionGroupTypeUpdateRequestDto();

        functionGroupTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionGroupTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionGroupTypeUpdateRequestDto.setCode( arg0.getCode() );
        functionGroupTypeUpdateRequestDto.setName( arg0.getName() );

        return functionGroupTypeUpdateRequestDto;
    }
}
