package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamService.ArbitrationTeamCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.ArbitrationTeamService.ArbitrationTeamUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Passage de l'{@link ArbitrationTeamDto} de l'écran aux requêtes du service.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Passage de l'{@link ArbitrationTeamDto} de l'écran aux requêtes du service.

    @author Christian
               """)
public interface ArbitrationTeamRequestMapper
    extends RequestMapper<ArbitrationTeamDto, ArbitrationTeamCreateRequestDto,
        ArbitrationTeamUpdateRequestDto> {

}
