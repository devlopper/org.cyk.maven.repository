package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre de tickets actuellement pris
 * en charge (statut PRIS_EN_CHARGE, en cours de traitement) sous forme de chaîne.
 *
 * @author Christian
 */
public interface HasActiveClaimedTicketCountAsStringDto
    extends HasActiveClaimedTicketCountAsString {

  /**
   * Identifiant json du nombre de tickets actuellement pris en charge sous forme de chaîne.
   */
  String JSON_ACTIVE_CLAIMED_TICKET_COUNT_AS_STRING = "nombreTicketsPrisEnChargeActifsChaine";
}
