package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasUserName;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasCapacityCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les qualités d'utilisateur.
 *
 * @author BoobaCool
 *
 */
@Getter
@Setter
public class UserCapacityFilter extends AbstractIdentifiableFilter implements FilterHasUserName,
    FilterHasCapacityCode {

  /**
   * Nom utilisateur.
   */
  private String userName;

  /**
   * Code capacité.
   */
  private String capacityCode;

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public UserCapacityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public UserCapacityFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateUserName(filter);
    updateCapacityCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterUserName(filter);
    updateFilterCapacityCode(filter);
  }

}
