package ci.gouv.dgbf.system.identity.client.extension.identity;

import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.core.throwable.ExceptionCore;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.NavigationManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputsGroupController;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityService;
import ci.gouv.dgbf.system.identity.server.api.shared.IdentityIdentifierFilter;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import lombok.Getter;

/**
 * Cette classe représente la page de saisie de l'adresse email en du de
 * {@link IdentityService#DECLARE_IDENTIFIER}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityDeclareVerifyEmailAddressExistencePage extends AbstractPage {

  @Inject
  IdentityClient client;

  IdentityDto identity;

  @Inject
  @Getter
  InputTextController emailAddressInputTextController;

  String emailAddress;

  @Inject
  @Getter
  InputsGroupController inputsGroupController;

  @Getter
  Button submitCommandButton;

  @Inject
  NavigationManager navigationManager;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    emailAddressInputTextController.setOutputLableValue("Adresse email");
    emailAddressInputTextController.getInputText().addValueConsumer(emailAddressConsumer());
    emailAddressInputTextController.getInputText().setRequired(true);

    inputsGroupController.add(emailAddressInputTextController.getInputText());

    submitCommandButton = new Button();
    submitCommandButton.setValue("Suivant");
    submitCommandButton.setIcon("pi pi-sign-in");
    submitCommandButton.addUpdates(inputsGroupController.getComaSeparatedMessagesIdentifiers());
    submitCommandButton.setActionFunction(this::verifyExistence);
  }

  @Override
  protected void setContentTitleWhenBlank() {
    contentTitle = "Déclaration d'une identité - Vérification de l'existence de l'adresse email";
  }

  Consumer<String> emailAddressConsumer() {
    return value -> emailAddress = value;
  }

  String verifyExistence(Object argument) {
    new ActionExecutor<>(this, "Déclaration", this::verifyExistence).execute();
    return null;
  }

  Object verifyExistence() {
    GetOneRequestDto request = new GetOneRequestDto();
    IdentityFilter filter = new IdentityFilter();
    filter.setEmailAddress(emailAddress);
    request.useFilter(filter);
    request.projection().addNames(HasIdentifierDto.JSON_IDENTIFIER);
    request.setAuditWho(userIdentifier);
    identity = client.getOne(request);

    if (identity == null) {
      navigationManager.navigate(IdentityDeclarePage.OUTCOME,
          Map.of(EmailAddressFilter.JSON_KEY, List.of(emailAddress)));
    } else {
      ExceptionCore.doThrowIllegalArgumentIfBlankByName("outcome cible",
          requestParameterTargetOutcomeValue);
      navigationManager.navigate(requestParameterTargetOutcomeValue,
          Map.of(IdentityIdentifierFilter.JSON_KEY, List.of(identity.getIdentifier())));
    }
    return null;
  }

  @Override
  protected String getIdentifierForUnauthenticatedAccess() {
    return IdentityService.DECLARE_IDENTIFIER;
  }

  public static final String OUTCOME = "identityDeclareVerifyEmailAddressExistencePage";
}
