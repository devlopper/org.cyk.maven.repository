package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.primefaces.component.input.InputFloat;
import ci.gouv.dgbf.extension.primefaces.component.input.InputInteger;
import ci.gouv.dgbf.extension.primefaces.component.input.InputLocalDate;
import ci.gouv.dgbf.extension.primefaces.component.input.InputText;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectOneRadioBoolean;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldDto;
import java.time.LocalDate;
import lombok.Getter;

/**
 * Cette classe représente une saisie dynamique correspondant à un
 * {@link DocumentTypeGroupFieldDto}, instanciée au dépôt d'un
 * {@link ci.gouv.dgbf.system.documentation.server.api.DocumentDto} une fois le type et le groupe
 * de document choisis. Un seul des composants ci-dessous est non nul, selon
 * {@link DocumentTypeGroupFieldDto#getValueType()}.
 *
 * @author si.kimou
 *
 */
@Getter
public class DocumentFieldInput {

  private final DocumentTypeGroupFieldDto field;

  private InputText inputText;
  private InputInteger inputInteger;
  private InputFloat inputFloat;
  private InputLocalDate inputLocalDate;
  private SelectOneRadioBoolean selectOneRadioBoolean;

  private DocumentFieldInput(DocumentTypeGroupFieldDto field) {
    this.field = field;
  }

  /**
   * Cette méthode permet d'instancier la saisie correspondant au {@link ValueType} du champ.
   *
   * @param field champ configurable
   * @return saisie instanciée
   */
  public static DocumentFieldInput of(DocumentTypeGroupFieldDto field) {
    DocumentFieldInput fieldInput = new DocumentFieldInput(field);
    boolean required = Boolean.TRUE.equals(field.getRequired());
    ValueType valueType = field.getValueType();
    if (valueType == null) {
      return fieldInput;
    }
    switch (valueType) {
      case INTEGER:
        fieldInput.inputInteger = new InputInteger();
        fieldInput.inputInteger.setRequired(required);
        fieldInput.inputInteger.outputLabel().setValue(field.getName());
        break;
      case FLOAT:
        fieldInput.inputFloat = new InputFloat();
        fieldInput.inputFloat.setRequired(required);
        fieldInput.inputFloat.outputLabel().setValue(field.getName());
        break;
      case INSTANT:
        fieldInput.inputLocalDate = new InputLocalDate();
        fieldInput.inputLocalDate.setRequired(required);
        fieldInput.inputLocalDate.outputLabel().setValue(field.getName());
        break;
      case BOOLEAN:
        fieldInput.selectOneRadioBoolean = new SelectOneRadioBoolean();
        fieldInput.selectOneRadioBoolean.setRequired(required);
        fieldInput.selectOneRadioBoolean.outputLabel().setValue(field.getName());
        fieldInput.selectOneRadioBoolean.addTrueOrFalseChoices(!required);
        break;
      case STRING:
      case MAP:
      default:
        fieldInput.inputText = new InputText();
        fieldInput.inputText.setRequired(required);
        fieldInput.inputText.outputLabel().setValue(field.getName());
        break;
    }
    return fieldInput;
  }

  /**
   * Cette méthode permet d'obtenir la valeur saisie, sous forme de texte -- format attendu par
   * {@link ci.gouv.dgbf.system.documentation.server.api.DocumentFieldValueDto#getValue()}.
   *
   * @return valeur sous forme de texte, ou null si rien n'a été saisi
   */
  public String getValueAsText() {
    if (inputText != null) {
      return inputText.getValue();
    }
    if (inputInteger != null) {
      return inputInteger.getValue() == null ? null : inputInteger.getValue().toString();
    }
    if (inputFloat != null) {
      return inputFloat.getValue() == null ? null : inputFloat.getValue().toString();
    }
    if (inputLocalDate != null) {
      return inputLocalDate.getValue() == null ? null : inputLocalDate.getValue().toString();
    }
    if (selectOneRadioBoolean != null) {
      return selectOneRadioBoolean.getValue() == null ? null
          : selectOneRadioBoolean.getValue().toString();
    }
    return null;
  }

  /**
   * Cette méthode permet de pré-remplir la saisie à partir d'une valeur textuelle, pour la
   * modification d'un {@link ci.gouv.dgbf.system.documentation.server.api.DocumentDto}.
   *
   * @param text valeur textuelle, format ISO pour {@link #inputLocalDate}
   */
  public void writeValueAsText(String text) {
    if (text == null || text.isBlank()) {
      return;
    }
    if (inputText != null) {
      inputText.writeValue(text);
    } else if (inputInteger != null) {
      inputInteger.writeValue(Integer.valueOf(text));
    } else if (inputFloat != null) {
      inputFloat.writeValue(Float.valueOf(text));
    } else if (inputLocalDate != null) {
      inputLocalDate.writeValue(LocalDate.parse(text));
    } else if (selectOneRadioBoolean != null) {
      selectOneRadioBoolean.writeValue(Boolean.valueOf(text));
    }
  }
}
