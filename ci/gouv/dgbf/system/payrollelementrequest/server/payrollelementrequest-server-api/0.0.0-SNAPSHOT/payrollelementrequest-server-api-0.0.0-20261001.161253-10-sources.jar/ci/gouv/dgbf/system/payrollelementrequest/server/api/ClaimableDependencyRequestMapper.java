package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDependencyService.ClaimableDependencyCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableDependencyService.ClaimableDependencyUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ClaimableDependencyDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ClaimableDependencyDto}.

    @author akm
               """)
public interface ClaimableDependencyRequestMapper extends
    RequestMapper<ClaimableDependencyDto, ClaimableDependencyCreateRequestDto,
        ClaimableDependencyUpdateRequestDto> {

}
