package ci.gouv.dgbf.extension.primefaces.test;

import static org.mockito.Mockito.when;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.test.MockedStaticGetter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.primefaces.PrimeFaces;
import org.primefaces.PrimeFaces.Ajax;
import org.primefaces.PrimeFaces.Dialog;

/**
 * Cette classe représente un mocker de PrimeFaces.
 *
 * @author Christian
 *
 */
@Setter
@Accessors(chain = true, fluent = true)
public class PrimeFacesMocker {
  Object container;
  Dialog dialog;
  Ajax ajax;

  /**
   * Cette méthode permet d'instancier.
   *
   * @param container conteneur
   */
  public PrimeFacesMocker(Object container) {
    this.container = container;
  }

  /**
   * Cette méthode permet de mocker une instance primefaces.
   *
   * @return instance primefaces
   */
  public PrimeFaces mock() {
    /*
     * Mock primefaces.
     */
    PrimeFaces primeFaces = Mockito.mock(PrimeFaces.class);
    ajax = Core.getOrInstantiateIfNull(ajax, () -> Mockito.mock(Ajax.class));
    dialog = Core.getOrInstantiateIfNull(dialog, () -> Mockito.mock(Dialog.class));

    Mockito.when(primeFaces.dialog()).thenReturn(dialog);
    Mockito.when(primeFaces.ajax()).thenReturn(ajax);

    when(primeFaces.dialog()).thenReturn(dialog);
    /*
     * Mock PrimeFaces static method call
     */
    get(container, Boolean.FALSE).when(PrimeFaces::current).thenReturn(primeFaces);
    return primeFaces;
  }

  /**
   * Cette méthode permet d'obtenir l'instance enregistrée.
   *
   * @param container conteneur
   * @param silent silencieux
   * @return instance enregistrée
   */
  public static MockedStatic<PrimeFaces> get(Object container, Boolean silent) {
    return new MockedStaticGetter<PrimeFaces>(container, PrimeFaces.class).silent(silent).get();
  }
}
