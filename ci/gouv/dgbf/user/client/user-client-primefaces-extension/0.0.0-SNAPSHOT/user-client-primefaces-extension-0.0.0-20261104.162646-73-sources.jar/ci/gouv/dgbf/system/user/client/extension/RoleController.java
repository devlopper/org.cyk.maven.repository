package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Column;
import ci.gouv.dgbf.extension.primefaces.component.ColumnDetail;
import ci.gouv.dgbf.extension.primefaces.component.CommandUpdatePropertyValueBuilder;
import ci.gouv.dgbf.extension.primefaces.component.MenuItem;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController.Viewer;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.ReservedRole;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.RoleNature;
import ci.gouv.dgbf.system.user.server.api.RoleRequestMapper;
import ci.gouv.dgbf.system.user.server.api.RoleService;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleAssignRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleRevokeRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateNatureRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateRequestableRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserRole;
import ci.gouv.dgbf.system.user.server.api.UserService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RoleController extends AbstractController {
  /** Longueur de la colonne CODE (évolution SQL 007). */
  static final int CODE_MAX_LENGTH = 64;


  @Inject
  RoleClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  RoleFilterController filterController;

  /** Identité (Libellé en titre, Code en sous-ligne, Application en détail masquable). */
  @Getter
  Column identityColumn;

  @Inject
  RoleRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  InputTextController descriptionInputTextController;

  @Inject
  @Getter
  ApplicationSelectOneController applicationSelectOneController;

  @Inject
  @Getter
  IdentifiableProcessingController assignUsersProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController revokeProcessingController;

  @Inject
  @Getter
  UserSelectManyController assignUsersSelectManyController;

  @Inject
  @Getter
  UserSelectManyController revokeUsersSelectManyController;

  /** Nature du Rôle en création (RG_UTI_ROL_18) ; défaut applicatif. */
  @Inject
  @Getter
  RoleNatureSelectOneController natureSelectOneController;

  /** Composants du Rôle en création, affiché seulement si Nature métier (RG_UTI_ROL_19). */
  @Inject
  @Getter
  RoleSelectManyController componentsSelectManyController;

  /** Nature choisie dans le dialogue dédié « Changer la Nature » (RG_UTI_ROL_21, RU_UTI_030). */
  @Inject
  @Getter
  RoleNatureSelectOneController changeNatureSelectOneController;

  /** Composants choisis dans le dialogue dédié « Changer la Nature ». */
  @Inject
  @Getter
  RoleSelectManyController changeNatureComponentsSelectManyController;

  @Inject
  @Getter
  IdentifiableProcessingController changeNatureProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController requestableYesProcessingController;

  @Inject
  @Getter
  IdentifiableProcessingController requestableNoProcessingController;

  /** Application et identifiant du Rôle en cours d'édition dans le dialogue de changement de
   * Nature (RG_UTI_ROL_19 : composants proposés limités à cette Application, sans lui-même). */
  String changeNatureRoleIdentifier;
  String changeNatureApplicationIdentifier;

  String processedRoleIdentifier;

  /** Identifiant du Rôle en cours de modification générique (null en création), exclu de ses
   * propres composants (RG_UTI_ROL_19). */
  String updateRoleIdentifier;

  @Inject
  UserClient userClient;

  @Inject
  UserRights userRights;

  @Getter
  @Setter
  UserFilter userFilter;

  @Getter
  @Setter
  private List<String> selectedUserIdentifiers = new ArrayList<>();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = RoleDto.NAME;
  }

  void initializeColumns(boolean applicationProjected) {
    identityColumn = new Column();
    identityColumn.initializeAsIdentity();

    ColumnDetail application = new ColumnDetail();
    application.setFieldName("applicationAsString");
    application.setTitle("Application");
    application.setRendered(applicationProjected);
    identityColumn.addDetail(application);
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(RoleDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(RoleService.PATH);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(RoleReadUsersPage.OUTCOME);

    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        RoleDto.JSON_DESCRIPTION, RoleDto.JSON_NATURE, RoleDto.JSON_REQUESTABLE);
    // Application connue via filtre (fiche Application) → détail inutile en liste
    boolean applicationProjected = filterController.getFilter().getApplicationIdentifier() == null;
    if (applicationProjected) {
      projection.addNames(RoleDto.JSON_APPLICATION_AS_STRING);
    }
    initializeColumns(applicationProjected);

    projection.addNames(RoleDto.JSON_APPLICATION_CODE, RoleDto.JSON_DOMAIN_CODE);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.getShowCreateDialogButton()
        .setRendered(userRights.isGrantedForAny(UserRole.MANAGE_APPLICATION_ROLE)
            || userRights.isGrantedForAny(UserRole.MANAGE_BUSINESS_ROLE));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      RoleCreateRequestDto request = requestMapper.mapCreate((RoleDto) entity);
      request.setNature(readSelectedNature(natureSelectOneController));
      request.setComponentIdentifiers(componentsSelectManyController.getAutoComplete().getValue());
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME, RoleDto.JSON_DESCRIPTION,
            RoleDto.JSON_APPLICATION_IDENTIFIER, RoleDto.JSON_NATURE,
            RoleDto.JSON_COMPONENT_IDENTIFIERS, RoleDto.JSON_COMPONENT_NAMES));

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());
    // Rôle réservé ni modifié ni supprimé depuis la liste : il se désigne (RG_UTI_ROL_17)
    // et réservé aux détenteurs du Droit de configurer les Rôles de l'Application de la ligne
    listController.getShowUpdateDialogButtonController().setRenderedFunction(
        row -> isAssignable(row) && isManageable(row));
    listController.getDeleteButtonController().setRenderedFunction(
        row -> isAssignable(row) && isManageable(row));

    codeInputTextController.initializeCode(codeConsumer(), CODE_MAX_LENGTH);
    nameInputTextController.initializeName(nameConsumer());

    descriptionInputTextController.setOutputLableValue("Description");
    descriptionInputTextController.getInputTextarea().addValueConsumer(descriptionConsumer());

    applicationSelectOneController.getSelectOneMenu().setRequired(true);
    applicationSelectOneController.getSelectOneMenu()
        .addValueConsumer(applicationIdentifierConsumer());
    // Les composants proposés dépendent de l'Application : vidés si elle change (RG_UTI_ROL_19)
    applicationSelectOneController.getSelectOneMenu().valueChangeAjax().configure(
        event -> componentsSelectManyController.getAutoComplete().writeValue(new ArrayList<>()),
        CommandUpdatePropertyValueBuilder.newInstance()
            .strings(Set.of(FORM_SAVE_INPUTS_PANEL_ID, CREATE_SAVE_BUTTON_ID)));

    initializeAssignUsersSelectManyController();
    initializeRevokeUsersSelectManyController();
    initializeAssignUsersProcessingController();
    initializeRevokeProcessingController();
    initializeNatureSelectOneController();
    initializeComponentsSelectManyController();
    initializeChangeNatureProcessingController();
    initializeRequestableProcessingControllers();

    /* Menu bouton d'actions (comme sur la liste des utilisateurs) */
    assignUsersProcessingController.addToRecordMenuButton(listController.recordMenuButton());
    revokeProcessingController.addToRecordMenuButton(listController.recordMenuButton());
    changeNatureProcessingController.addToRecordMenuButton(listController.recordMenuButton());
    requestableYesProcessingController.addToRecordMenuButton(listController.recordMenuButton());
    requestableNoProcessingController.addToRecordMenuButton(listController.recordMenuButton());
  }

  /**
   * Cette méthode permet d'ajouter "Consulter" (bouton de lecture) au menu "..." de chaque ligne,
   * à la place de l'icône séparée. Appel explicite car ce bouton pointe vers
   * {@link RoleReadUsersPage}, une page absente des consommateurs qui n'en ont pas besoin (ex.
   * ticket-client) : contrairement à l'assignation/révocation, l'ajouter systématiquement ici
   * romprait ces consommateurs.
   */
  public void addGotoReadPageButtonToRecordMenuButton() {
    listController.recordMenuButton().buttonBuilder()
        .menuItemBuilder((MenuItem.Builder) MenuItem.newBuilder()
            .outcome(listController.getGotoReadPageButton().getOutcome())
            .value(listController.getGotoReadPageButton().getTitle())
            .icon(listController.getGotoReadPageButton().getIcon()))
        .build();
    listController.getGotoReadPageButton().setRendered(false);
  }


  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {
      applicationSelectOneController.getSelectOneMenu().setDisabled(false);
      natureSelectOneController.getSelectOneMenu().setDisabled(false);
      natureSelectOneController.getSelectOneMenu().writeValue(RoleNature.APPLICATION_ROLE.name());
      componentsSelectManyController.getAutoComplete().writeValue(new ArrayList<>());
      // Pas de Rôle encore créé à exclure de ses propres composants (contrairement à la
      // modification générique, où cela évite l'auto-référence, RG_UTI_ROL_19)
      updateRoleIdentifier = null;
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      RoleDto role = (RoleDto) entity;

      codeInputTextController.getInputText().writeValue(role.getCode());
      nameInputTextController.getInputText().writeValue(role.getName());
      descriptionInputTextController.getInputTextarea().writeValue(role.getDescription());

      // L'Application d'un Rôle ne change plus après la création : la requête de mise à jour
      // ne la porte pas
      applicationSelectOneController.getSelectOneMenu().setDisabled(true);
      applicationSelectOneController.getSelectOneMenu()
          .writeValue(role.getApplicationIdentifier());

      // Nature fixe en modification générique — seul le dialogue dédié de changement de
      // Nature la modifie (RG_UTI_ROL_21). Affichée désactivée, comme l'Application ci-dessus,
      // pour que le sélecteur de composants partagé avec la création (readSelectedNature)
      // reste correct sans dupliquer la logique d'affichage/d'invariante : l'Administrateur
      // Technique y gère le contenu d'un Rôle déjà métier (RU_UTI_028).
      natureSelectOneController.getSelectOneMenu().setDisabled(true);
      natureSelectOneController.getSelectOneMenu()
          .writeValue((role.getNature() == null ? RoleNature.APPLICATION_ROLE : role.getNature())
              .name());
      updateRoleIdentifier = role.getIdentifier();
      componentsSelectManyController.getAutoComplete()
          .writeValue(role.getComponentIdentifiers() == null ? new ArrayList<>()
              : new ArrayList<>(role.getComponentIdentifiers()));
    };
  }

  /**
   * Méthode de complétion pour l'autocomplete d'assignation : seuls les utilisateurs n'ayant pas
   * encore le rôle en cours sont proposés.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants sans le rôle en cours
   */
  public List<UserDto> completeUnassignedUser(String query) {
    return completeUser(query, processedRoleIdentifier, null);
  }

  /**
   * Méthode de complétion pour l'autocomplete de révocation : seuls les utilisateurs ayant le
   * rôle en cours sont proposés.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants ayant le rôle en cours
   */
  public List<UserDto> completeAssignedUser(String query) {
    return completeUser(query, null, processedRoleIdentifier);
  }

  /**
   * Méthode de complétion pour l'autocomplete des utilisateurs.
   * Identique à ApplicationController.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants
   */
  public List<UserDto> completeUser(String query) {
    return completeUser(query, null, null);
  }

  List<UserDto> completeUser(String query, String unassignedRoleIdentifier,
                             String assignedRoleIdentifier) {
    if (query == null || query.trim().length() < 2) {
      return List.of();
    }

    UserFilter filter = new UserFilter();
    filter.setNameContains(query);
    filter.setUnassignedRoleIdentifier(unassignedRoleIdentifier);
    filter.setAssignedRoleIdentifier(assignedRoleIdentifier);

    PageDto pageDto = new PageDto();
    pageDto.setIndex(0);
    pageDto.setSize(20);

    // Comme « Ajouter plusieurs » (UserController.complete) : pas de JSON_AS_STRING, qui
    // joint l'identité et exclut les utilisateurs sans identité.
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME
    );

    UserService.UserGetManyResponseDto response =
        userClient.getMany(projection,
            filter.toDto(),
            pageDto,
            userIdentifier,
            null);

    return response != null && response.getDatas() != null
        ? response.getDatas()
        : List.of();
  }

  Consumer<String> applicationIdentifierConsumer() {
    return identifier -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setApplicationIdentifier(identifier);
  }

  Consumer<String> descriptionConsumer() {
    return description -> listController
        .getCreateControllerOrUpdateControllerEntityAs(RoleDto.class).setDescription(description);
  }


  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(RoleDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      RoleUpdateRequestDto request = requestMapper.mapUpdate((RoleDto) entity);
      // Composition d'un Rôle métier (RU_UTI_028) ; sans effet sur un Rôle applicatif, dont le
      // sélecteur reste vide (champ partagé avec la création, RG_UTI_ROL_19)
      request.setComponentIdentifiers(componentsSelectManyController.getAutoComplete().getValue());
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(codeInputTextController.getInputText(), nameInputTextController.getInputText(),
            descriptionInputTextController.getInputTextarea(),
            applicationSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }

  /**
   * Initialise l'autocomplete multiple de l'assignation.
   */
  void initializeAssignUsersSelectManyController() {
    assignUsersSelectManyController.setOutputLableValue("Utilisateurs à assigner");
    assignUsersSelectManyController.getAutoComplete().setMultiple(true);
    assignUsersSelectManyController.getAutoComplete().setRequired(true);
    assignUsersSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeUnassignedUser(query)));
  }

  /**
   * Initialise l'autocomplete multiple de la révocation, identique à celui de l'assignation.
   */
  void initializeRevokeUsersSelectManyController() {
    revokeUsersSelectManyController.setOutputLableValue("Utilisateurs à révoquer");
    revokeUsersSelectManyController.getAutoComplete().setMultiple(true);
    revokeUsersSelectManyController.getAutoComplete().setRequired(true);
    revokeUsersSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeAssignedUser(query)));
  }

  void initializeAssignUsersProcessingController() {
    assignUsersProcessingController.setViewer(Viewer.DIALOG);
    // Liste fournie avant la préparation : bouton de ligne en icône seule, avec infobulle
    assignUsersProcessingController.setListController(listController);
    assignUsersProcessingController.prepareDialog(RoleDto.class, "Assignation d'utilisateurs",
        "pi pi-user-plus", assignUsersFunction(), "assignUsersForm", client);
    assignUsersProcessingController.addShowDialogConsumer(loadAvailableRolesForAssignment());
    assignUsersProcessingController.initialize();
    // Pas d'attribution générique d'un Rôle réservé, qui se désigne (RG_UTI_ROL_17)
    assignUsersProcessingController.setShowDialogButtonControllerRenderedFunction(
        row -> isAssignable(row)
            && userRights.isGrantedOnRow(UserRole.ASSIGN_USER_ROLE, row));
  }

  /**
   * Cette méthode indique si la ligne peut recevoir une attribution générique : pas un Rôle
   * réservé (RG_UTI_ROL_17).
   *
   * @param row ligne ({@link RoleDto})
   * @return vrai si elle n'est pas un Rôle réservé
   */
  static boolean isAssignable(Object row) {
    return !isReserved(row);
  }

  /**
   * Cette méthode indique si la ligne peut être modifiée ou supprimée : l'un des deux Droits qui
   * remplacent l'ancien Droit global {@code CONFIGURE_ROLE} (RG_UTI_ROL_18, TCH_UTI_779) —
   * l'Administrateur Applicatif gère les Rôles applicatifs, l'Administrateur Technique les
   * Rôles métier. Un seul écran générique les manipule encore tous les deux pour l'instant
   * (TCH_UTI_780/781 les séparera).
   *
   * @param row ligne ({@link RoleDto})
   * @return vrai si l'un des deux Droits est accordé pour l'Application de la ligne
   */
  boolean isManageable(Object row) {
    if (!(row instanceof RoleDto role) || role.getNature() == null) {
      return false;
    }
    UserRole right = role.getNature() == RoleNature.APPLICATION_ROLE
        ? UserRole.MANAGE_APPLICATION_ROLE : UserRole.MANAGE_BUSINESS_ROLE;
    return userRights.isGrantedOnRow(right, row);
  }

  /**
   * Cette méthode indique si la ligne est un Rôle réservé (RG_UTI_ROL_17).
   *
   * @param row ligne ({@link RoleDto})
   * @return vrai si son code est celui d'un Rôle réservé
   */
  static boolean isReserved(Object row) {
    return row != null && ReservedRole.CODES.contains(((RoleDto) row).getCode());
  }

  void initializeRevokeProcessingController() {
    revokeProcessingController.setViewer(Viewer.DIALOG);
    // Liste fournie avant la préparation : bouton de ligne en icône seule, avec infobulle
    revokeProcessingController.setListController(listController);
    revokeProcessingController.prepareDialog(RoleDto.class, "Revocation d'utilisateurs",
        "pi pi-user-minus", revokeFunction(), "revokeForm", client);
    revokeProcessingController.addShowDialogConsumer(loadAssignedRoles());
    revokeProcessingController.setShowDialogButtonControllerRenderedFunction(
        row -> userRights.isGrantedOnRow(UserRole.REVOKE_USER_ROLE, row));
    revokeProcessingController.initialize();
  }

  /**
   * Identifiant du panneau des champs de saisie (gabarit {@code /extension/crud/form/save/
   * default.xhtml}, commun à tous les formulaires qui le décorent) — ciblé en ajax pour
   * rafraîchir l'affichage des composants et l'indicateur valide/invalide (RU_UTI_030 CA4).
   */
  static final String FORM_SAVE_INPUTS_PANEL_ID = "formSaveInputsOutputPanel";

  /** Identifiant du bouton Enregistrer du formulaire de création (voir {@code saveForm.xhtml}). */
  static final String CREATE_SAVE_BUTTON_ID = "roleCreateSaveButton";

  /** Identifiant du bouton Enregistrer du dialogue de changement de Nature (voir
   * {@code changeNatureForm.xhtml}). */
  static final String CHANGE_NATURE_SAVE_BUTTON_ID = "roleChangeNatureSaveButton";

  /**
   * Initialise le sélecteur de Nature du formulaire de création (RG_UTI_ROL_18).
   */
  void initializeNatureSelectOneController() {
    natureSelectOneController.getSelectOneMenu().setRequired(true);
    natureSelectOneController.getSelectOneMenu().writeValue(RoleNature.APPLICATION_ROLE.name());
    natureSelectOneController.getSelectOneMenu().valueChangeAjax().configure(event -> { },
        CommandUpdatePropertyValueBuilder.newInstance()
            .strings(Set.of(FORM_SAVE_INPUTS_PANEL_ID, CREATE_SAVE_BUTTON_ID)));
  }

  /**
   * Initialise le sélecteur de composants du formulaire de création, affiché seulement si la
   * Nature choisie est métier (RG_UTI_ROL_19). Les choix se limitent aux Rôles de l'Application
   * choisie, sans les Rôles réservés (filtre côté client, le serveur revalide dans tous les cas).
   */
  void initializeComponentsSelectManyController() {
    componentsSelectManyController.setOutputLableValue("Composants");
    componentsSelectManyController.getAutoComplete().setMultiple(true);
    componentsSelectManyController.getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeComponents(query,
            applicationSelectOneController.getSelectOneMenu().getValue(), updateRoleIdentifier)));
    componentsSelectManyController.getAutoComplete().itemSelectAjax().setDisabled(false);
    componentsSelectManyController.getAutoComplete().itemSelectAjax().configure(event -> { },
        CommandUpdatePropertyValueBuilder.newInstance()
            .strings(Set.of(FORM_SAVE_INPUTS_PANEL_ID, CREATE_SAVE_BUTTON_ID)));
  }

  /**
   * Cette méthode permet de compléter la liste des Rôles proposés comme composants : de la même
   * Application, sans le Rôle en cours d'édition (s'il existe déjà) ni les Rôles réservés
   * (RG_UTI_ROL_17, RG_UTI_ROL_19).
   *
   * @param query                 la chaîne de recherche
   * @param applicationIdentifier identifiant de l'Application du Rôle édité
   * @param excludedRoleIdentifier identifiant du Rôle édité, à exclure de ses propres composants
   * @return les Rôles correspondants
   */
  List<RoleDto> completeComponents(String query, String applicationIdentifier,
                                    String excludedRoleIdentifier) {
    if (applicationIdentifier == null) {
      return List.of();
    }
    RoleFilter filter = new RoleFilter();
    filter.setNameContains(query);
    filter.setApplicationIdentifier(applicationIdentifier);
    // Un Rôle réservé ne peut jamais être composant (RG_UTI_ROL_19)
    filter.setExcludedCodes(ReservedRole.CODES);
    GetManyRequestDto request = new GetManyRequestDto();
    request.useFilter(filter);
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME);
    request.setAuditWho(userIdentifier);
    RoleService.RoleGetManyResponseDto response = client.getMany(request);
    List<RoleDto> candidates = RoleService.RoleGetManyResponseDto.getDatas(RoleDto.class, response);
    return excludedRoleIdentifier == null ? candidates
        : candidates.stream()
            .filter(candidate -> !excludedRoleIdentifier.equals(candidate.getIdentifier()))
            .toList();
  }

  /**
   * Cette méthode permet d'obtenir la Nature actuellement sélectionnée dans un sélecteur, ou le
   * défaut applicatif si rien n'est encore choisi (RG_UTI_ROL_18).
   *
   * @param controller sélecteur de Nature
   * @return Nature sélectionnée
   */
  static RoleNature readSelectedNature(RoleNatureSelectOneController controller) {
    String name = controller.getSelectOneMenu().getValue();
    return name == null ? RoleNature.APPLICATION_ROLE : RoleNature.valueOf(name);
  }

  /**
   * Cette méthode vérifie l'invariante RG_UTI_ROL_18/19 à partir d'un état en cours d'édition :
   * applicatif sans composant, ou métier avec au moins un composant.
   *
   * @param nature     Nature choisie
   * @param components composants choisis
   * @return vrai si invalide (bouton Enregistrer à désactiver)
   */
  static boolean isCompositionInvalid(RoleNature nature, List<String> components) {
    boolean hasComponents = components != null && !components.isEmpty();
    return RoleNature.BUSINESS_ROLE.equals(nature) ? !hasComponents : hasComponents;
  }

  /**
   * Cette méthode indique si le sélecteur de composants du formulaire de création ou de
   * modification générique (champ partagé, RU_UTI_028) doit être affiché : Nature métier,
   * choisie à la création ou fixée par le Rôle chargé en modification (RG_UTI_ROL_19/21).
   *
   * @return vrai si la Nature est métier
   */
  public boolean isCreateComponentsRendered() {
    return RoleNature.BUSINESS_ROLE.equals(readSelectedNature(natureSelectOneController));
  }

  /**
   * Cette méthode indique, en direct, si l'état en cours d'édition du formulaire de création ou
   * de modification générique est invalide (RU_UTI_030 CA4, appliqué aussi à la création ; en
   * modification, c'est l'Administrateur Technique qui ne doit jamais pouvoir vider la
   * composition d'un Rôle métier jusqu'à zéro, RU_UTI_028) : le bouton Enregistrer y est lié.
   *
   * @return vrai si invalide
   */
  public boolean isCreateCompositionInvalid() {
    return isCompositionInvalid(readSelectedNature(natureSelectOneController),
        componentsSelectManyController.getAutoComplete().getValue());
  }

  /**
   * Initialise le dialogue dédié de changement de Nature (RG_UTI_ROL_21, RU_UTI_030), réservé à
   * l'Administrateur Applicatif — jamais à l'Administrateur Technique.
   */
  void initializeChangeNatureProcessingController() {
    changeNatureProcessingController.setViewer(Viewer.DIALOG);
    changeNatureProcessingController.setListController(listController);
    changeNatureProcessingController.getController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            RoleDto.JSON_APPLICATION_IDENTIFIER, RoleDto.JSON_NATURE,
            RoleDto.JSON_COMPONENT_IDENTIFIERS, RoleDto.JSON_COMPONENT_NAMES));
    changeNatureProcessingController.prepareDialog(RoleDto.class, "Changer la Nature",
        "pi pi-sitemap", changeNatureFunction(), "changeNatureForm", client);
    changeNatureProcessingController.getController()
        .addEntityConsumer(changeNatureEntityConsumer());
    changeNatureProcessingController.setShowDialogButtonControllerRenderedFunction(
        row -> isAssignable(row)
            && userRights.isGrantedOnRow(UserRole.MANAGE_APPLICATION_ROLE, row));
    changeNatureProcessingController.initialize();

    changeNatureSelectOneController.getSelectOneMenu().setRequired(true);
    changeNatureSelectOneController.getSelectOneMenu().valueChangeAjax().configure(
        event -> changeNatureComponentsSelectManyController.getAutoComplete()
            .writeValue(new ArrayList<>()),
        CommandUpdatePropertyValueBuilder.newInstance()
            .strings(Set.of(FORM_SAVE_INPUTS_PANEL_ID, CHANGE_NATURE_SAVE_BUTTON_ID)));

    changeNatureComponentsSelectManyController.setOutputLableValue("Composants");
    changeNatureComponentsSelectManyController.getAutoComplete().setMultiple(true);
    changeNatureComponentsSelectManyController.getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeComponents(query,
            changeNatureApplicationIdentifier, changeNatureRoleIdentifier)));
    changeNatureComponentsSelectManyController.getAutoComplete().itemSelectAjax()
        .setDisabled(false);
    changeNatureComponentsSelectManyController.getAutoComplete().itemSelectAjax()
        .configure(event -> { },
            CommandUpdatePropertyValueBuilder.newInstance()
                .strings(Set.of(FORM_SAVE_INPUTS_PANEL_ID, CHANGE_NATURE_SAVE_BUTTON_ID)));
  }

  /**
   * Prépare le dialogue de changement de Nature : mémorise l'Application et l'identifiant du
   * Rôle édité (filtre des composants proposés), pré-remplit la Nature et les composants actuels.
   *
   * @return consommateur de l'entité chargée
   */
  Consumer<Object> changeNatureEntityConsumer() {
    return entity -> {
      RoleDto role = (RoleDto) entity;
      changeNatureRoleIdentifier = role.getIdentifier();
      changeNatureApplicationIdentifier = role.getApplicationIdentifier();
      changeNatureSelectOneController.getSelectOneMenu()
          .writeValue(role.getNature() == null ? RoleNature.APPLICATION_ROLE.name()
              : role.getNature().name());
      changeNatureComponentsSelectManyController.getAutoComplete()
          .writeValue(role.getComponentIdentifiers() == null ? new ArrayList<>()
              : new ArrayList<>(role.getComponentIdentifiers()));
    };
  }

  /**
   * Cette méthode indique si le sélecteur de composants du dialogue de changement de Nature doit
   * être affiché (Nature métier choisie, RG_UTI_ROL_19).
   *
   * @return vrai si la Nature choisie dans le dialogue est métier
   */
  public boolean isChangeNatureComponentsRendered() {
    return RoleNature.BUSINESS_ROLE.equals(readSelectedNature(changeNatureSelectOneController));
  }

  /**
   * Cette méthode indique, en direct, si l'état en cours d'édition du dialogue de changement de
   * Nature est invalide (RU_UTI_030 CA4) : le bouton Enregistrer du dialogue y est lié.
   *
   * @return vrai si invalide
   */
  public boolean isChangeNatureCompositionInvalid() {
    return isCompositionInvalid(readSelectedNature(changeNatureSelectOneController),
        changeNatureComponentsSelectManyController.getAutoComplete().getValue());
  }

  UnaryOperator<Object> changeNatureFunction() {
    return entity -> {
      RoleUpdateNatureRequestDto request = new RoleUpdateNatureRequestDto();
      request.setIdentifier(((RoleDto) entity).getIdentifier());
      request.setNature(readSelectedNature(changeNatureSelectOneController));
      request.setComponentIdentifiers(
          changeNatureComponentsSelectManyController.getAutoComplete().getValue());
      request.setAuditWho(this.userIdentifier);
      return client.updateNature(request);
    };
  }

  /**
   * Initialise les deux actions dédiées de définition du caractère Demandable (RG_UTI_ROL_20,
   * RU_UTI_029) — deux boutons explicites (rendre demandable / non demandable) plutôt qu'une
   * bascule unique, pour ne pas avoir à relire l'état actuel de la ligne au moment de l'exécution
   * (RG_UTI_ROL_20 : toujours Non et non modifiable pour un Rôle réservé).
   */
  void initializeRequestableProcessingControllers() {
    requestableYesProcessingController.setListController(listController);
    requestableYesProcessingController.prepareConfirmation(RoleDto.class, "Rendre demandable",
        "pi pi-check-circle", requestableFunction(Boolean.TRUE));
    requestableYesProcessingController.initialize();
    // Viewer.NONE (prepareConfirmation) : addToRecordMenuButton lit la fonction d'affichage
    // du bouton d'ENVOI pour une ligne du menu, pas celle du bouton d'ouverture de dialogue
    // (jamais consultée dans ce mode) — voir IdentifiableProcessingController.
    // addToRecordMenuButton/getSubmitButtonRenderedByRecord.
    requestableYesProcessingController.setSubmitButtonControllerRenderedFunction(
        row -> isAssignable(row) && userRights.isGrantedOnRow(UserRole.DEFINE_ROLE_REQUEST_POLICY,
            row) && !Boolean.TRUE.equals(((RoleDto) row).getRequestable()));

    requestableNoProcessingController.setListController(listController);
    requestableNoProcessingController.prepareConfirmation(RoleDto.class, "Rendre non demandable",
        "pi pi-times-circle", requestableFunction(Boolean.FALSE));
    requestableNoProcessingController.initialize();
    requestableNoProcessingController.setSubmitButtonControllerRenderedFunction(
        row -> isAssignable(row) && userRights.isGrantedOnRow(UserRole.DEFINE_ROLE_REQUEST_POLICY,
            row) && Boolean.TRUE.equals(((RoleDto) row).getRequestable()));
  }

  UnaryOperator<Object> requestableFunction(Boolean requestable) {
    return identifier -> {
      RoleUpdateRequestableRequestDto request = new RoleUpdateRequestableRequestDto();
      request.setIdentifier((String) identifier);
      request.setRequestable(requestable);
      request.setAuditWho(this.userIdentifier);
      return client.updateRequestable(request);
    };
  }

  UnaryOperator<Object> assignUsersFunction() {
    return entity -> {
      RoleAssignRequestDto request = new RoleAssignRequestDto();
      request.setIdentifier(((RoleDto) entity).getIdentifier());
      request.setUserIdentifiers(
          new HashSet<>(assignUsersSelectManyController.getAutoComplete().getValue()));
      request.setAuditWho(this.userIdentifier);
      return client.assign(request);
    };
  }

  UnaryOperator<Object> revokeFunction() {
    return entity -> {
      // Créer et envoyer la requête
      RoleRevokeRequestDto request = new RoleRevokeRequestDto();
      request.setIdentifier(((RoleDto) entity).getIdentifier());
      request.setUserIdentifiers(
          new HashSet<>(revokeUsersSelectManyController.getAutoComplete().getValue()));
      request.setAuditWho(this.userIdentifier);
      return client.revoke(request);
    };
  }

  /**
   * Prépare l'assignation : mémorise le rôle en cours pour filtrer l'autocomplete.
   */
  public Consumer<String> loadAvailableRolesForAssignment() {
    return identifier -> {
      processedRoleIdentifier = identifier;
      assignUsersSelectManyController.getAutoComplete().writeValue(new ArrayList<>());
    };
  }

  /**
   * Prépare la révocation : mémorise le rôle en cours pour filtrer l'autocomplete.
   */
  public Consumer<String> loadAssignedRoles() {
    return identifier -> {
      processedRoleIdentifier = identifier;
      revokeUsersSelectManyController.getAutoComplete().writeValue(new ArrayList<>());
    };
  }

  /**
   * Méthode pour obtenir le label d'affichage d'un utilisateur.
   *
   * @param user l'utilisateur
   * @return le label formaté
   */
  public String getUserLabel(UserDto user) {
    return user.getName() + " (" + user.getIdentityAsString() + ")";
  }

  /**
   * Cette méthode permet de préparer la sélection multiple.
   *
   * @param controller     controller
   * @param client         client
   * @param userIdentifier user
   */

  public static void prepareSelectManyController(RoleSelectManyController controller,
                                                 RoleClient client,
                                                 String userIdentifier) {
    controller.getAutoComplete().setMultiple(true);
    controller
        .getAutoComplete()
        .setOnCompleteFunction(query ->
            new ArrayList<>(complete(client, query, userIdentifier)));
  }

  /**
   * Cette méthode permet de compléter la liste des rôles.
   *
   * @param client         client
   * @param query          query
   * @param userIdentifier user
   * @return list of users
   */
  static List<RoleDto> complete(RoleClient client, String query, String userIdentifier) {
    GetManyRequestDto request = new GetManyRequestDto();
    RoleFilter filter = new RoleFilter();
    filter.setNameContains(query);
    // Les Rôles réservés se désignent, ils ne s'attribuent pas (RG_UTI_ROL_17)
    filter.setExcludedCodes(ReservedRole.CODES);
    request.useFilter(filter);
    request.projection().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME
    );
    request.setAuditWho(userIdentifier);
    RoleService.RoleGetManyResponseDto response = client.getMany(request);
    return RoleService.RoleGetManyResponseDto.getDatas(RoleDto.class, response);
  }

}

