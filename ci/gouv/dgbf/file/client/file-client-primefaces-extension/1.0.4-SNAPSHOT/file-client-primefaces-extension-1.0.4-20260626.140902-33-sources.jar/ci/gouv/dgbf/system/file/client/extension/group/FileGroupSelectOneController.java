package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FileGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupSelectOneController
    extends AbstractSelectOneIdentifiableController<FileGroupDto,
        FileGroupGetManyResponseDto, FileGroupClient> {

  @Inject
  @Getter
  FileGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FileGroupSelectOneController() {
    super(FileGroupDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
