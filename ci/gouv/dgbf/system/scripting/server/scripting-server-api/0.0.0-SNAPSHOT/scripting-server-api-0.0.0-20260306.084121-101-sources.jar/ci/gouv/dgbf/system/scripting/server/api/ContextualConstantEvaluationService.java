package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasConstantCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ContextualConstantEvaluationDto}.
 *
 * @author Arnaud
 *
 */
@Path(value = ContextualConstantEvaluationService.PATH)
@Tag(name = "Gestion des evaluations de constantes contextuelles")
public interface ContextualConstantEvaluationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "evaluations-constantes-contextuelles";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Arnaud
   */
  interface ContextualConstantEvaluationSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir la valeur.
     *
     * @return la valeur
     */
    String getValue();

    /**
     * Cette méthode permet d'assigner la valeur.
     *
     * @param value la valeur
     */
    void setValue(String value);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ContextualConstantEvaluationGroupDto}.
     *
     * @return identifiant de {@link ContextualConstantEvaluationGroupDto}
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ContextualConstantDto}.
     *
     * @param contextualConstantIdentifier identifiant de {@link ContextualConstantDto}
     */
    void setContextualConstantIdentifier(String contextualConstantIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ContextualConstantDto}.
     *
     * @return identifiant de {@link ContextualConstantDto}
     */
    String getContextualConstantIdentifier();


    /**
     * {@link ContextualConstantEvaluationDto#JSON_VALUE}.
     */
    String JSON_VALUE = ContextualConstantEvaluationDto.JSON_VALUE;


    /**
     * {@link ContextualConstantEvaluationDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = ContextualConstantEvaluationDto.JSON_GROUP_IDENTIFIER;


    /**
     * {@link ContextualConstantEvaluationDto#JSON_CONTEXTUAL_CONSTANT_IDENTIFIER}.
     */
    String JSON_CONTEXTUAL_CONSTANT_IDENTIFIER =
        ContextualConstantEvaluationDto.JSON_CONTEXTUAL_CONSTANT_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ContextualConstantEvaluationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ContextualConstantEvaluationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ContextualConstantEvaluationSaveRequestDto {

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CONTEXTUAL_CONSTANT_IDENTIFIER)
    private String contextualConstantIdentifier;
  }

  /**
   * Identifiant du service de création contextuelle.
   */
  String CREATE_CONTEXTUALLY_IDENTIFIER = "CREATION_CONTEXTUELLE_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de création contextuelle.
   */
  String CREATE_CONTEXTUALLY_PATH = "creation-contextuelle";

  /**
   * Cette méthode permet de créer contextuellement {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_CONTEXTUALLY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_CONTEXTUALLY_IDENTIFIER)
  @APIResponse(responseCode = "201", content = {@Content(schema = @Schema(
      implementation = ContextualConstantEvaluationCreateContextuallyResponseDto.class))})
  Response createContextually(ContextualConstantEvaluationCreateContextuallyRequestDto request);

  /**
   * Cette classe représente la requête de création contextuelle.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ContextualConstantEvaluationCreateContextuallyRequestDto
      extends AbstractAuditedRequestJsonDto
      implements HasGroupIdentifierDto, HasConstantCategoryIdentifierDto,
      HasConstantGroupIdentifierDto, HasStringValueDto, HasValueTypeDto {

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CONSTANT_CATEGORY_IDENTIFIER)
    private String constantCategoryIdentifier;

    @JsonbProperty(JSON_CONSTANT_GROUP_IDENTIFIER)
    private String constantGroupIdentifier;

    @JsonbProperty(JSON_CONSTANT_GROUP_NAME)
    private String constantGroupName;
    
    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(JSON_VALUE_TYPE)
    private ValueType valueType;
    
    /**
     * Identifiant json de {@link #constantGroupName}.
     */
    public static final String JSON_CONSTANT_GROUP_NAME = "nomGroupeConstante";
  }

  /**
   * Cette classe représente la réponse de création contextuelle.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ContextualConstantEvaluationCreateContextuallyResponseDto extends CreateResponseDto
      implements HasConstantGroupIdentifierDto {

    @JsonbProperty(JSON_CONSTANT_GROUP_IDENTIFIER)
    private String constantGroupIdentifier;
  }
  
  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = ContextualConstantEvaluationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class ContextualConstantEvaluationGetManyResponseDto
      extends AbstractGetByPageResponseDto<ContextualConstantEvaluationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ContextualConstantEvaluationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ContextualConstantEvaluationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ContextualConstantEvaluationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ContextualConstantEvaluationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ContextualConstantEvaluationUpdateRequestDto
      extends AbstractCodableNamableUpdateRequestJsonDto
      implements ContextualConstantEvaluationSaveRequestDto {

    @JsonbProperty
    private String value;

    @JsonbProperty
    private String groupIdentifier;

    @JsonbProperty
    private String contextualConstantIdentifier;
  }

  /**
   * Identifiant du service de mise à jour de la valeur.
   */
  String UPDATE_VALUE_IDENTIFIER = "MISE_A_JOUR_VALEUR_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de mise à jour de la valeur.
   */
  String UPDATE_VALUE_PATH = "valeur";

  /**
   * Cette méthode permet de mettre à jour de la valeur de {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_VALUE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_VALUE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateValue(ContextualConstantEvaluationUpdateValueRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de la valeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ContextualConstantEvaluationUpdateValueRequestDto extends ByIdentifierRequestDto
      implements HasStringValueDto {

    @JsonbProperty(JSON_VALUE)
    private String value;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EVALUATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ContextualConstantEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
