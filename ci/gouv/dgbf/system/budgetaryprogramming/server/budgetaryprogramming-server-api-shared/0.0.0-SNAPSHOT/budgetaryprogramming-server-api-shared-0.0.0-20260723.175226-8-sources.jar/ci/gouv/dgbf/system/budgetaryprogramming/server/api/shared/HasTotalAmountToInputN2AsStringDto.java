package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputN2AsStringDto extends HasTotalAmountToInputN2AsString {

  /**
   * Identifiant json du montant total à saisir pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N2_AS_STRING = "montantTotalASaisirN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName