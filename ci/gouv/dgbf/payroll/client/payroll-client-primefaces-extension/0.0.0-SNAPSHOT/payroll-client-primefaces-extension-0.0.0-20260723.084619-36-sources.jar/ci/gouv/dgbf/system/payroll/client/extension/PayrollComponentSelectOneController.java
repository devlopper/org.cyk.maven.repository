package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollComponentService.PayrollComponentGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollComponentDto}.
 *
 * @author stephane
 *
 */
@Dependent
public class PayrollComponentSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollComponentDto, PayrollComponentGetManyResponseDto, PayrollComponentClient> {

  @Getter
  @Inject
  PayrollComponentClient client;

  protected PayrollComponentSelectOneController() {
    super(PayrollComponentDto.class, SelectItemLabelStrategy.NAME);
  }
}
