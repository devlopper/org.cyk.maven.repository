package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollTypeService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollTypeClient extends AbstractClient<PayrollTypeService>
    implements GetByIdentifier<PayrollTypeDto>, GetMany<PayrollTypeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollTypeClient service(PayrollTypeService service) {
    return (PayrollTypeClient) super.service(service);
  }

  /**
   * {@link PayrollTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollTypeCreateRequestDto request) {
    return new CreateExecutor(PayrollTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollTypeGetManyResponseDto>(
        PayrollTypeGetManyResponseDto.class, PayrollTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollTypeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollTypeGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollTypeDto>(PayrollTypeDto.class,
        PayrollTypeService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollTypeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollTypeDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollTypeDto>(PayrollTypeDto.class,
        PayrollTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollTypeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollTypeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollTypeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
