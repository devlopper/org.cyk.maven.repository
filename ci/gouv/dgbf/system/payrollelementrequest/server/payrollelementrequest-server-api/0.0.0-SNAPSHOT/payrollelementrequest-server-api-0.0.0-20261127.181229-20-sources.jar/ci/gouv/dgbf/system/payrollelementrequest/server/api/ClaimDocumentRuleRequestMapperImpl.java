package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ClaimDocumentRuleDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T18:12:39+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ClaimDocumentRuleRequestMapperImpl implements ClaimDocumentRuleRequestMapper {

    @Override
    public ClaimDocumentRuleService.ClaimDocumentRuleCreateRequestDto mapCreate(ClaimDocumentRuleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimDocumentRuleService.ClaimDocumentRuleCreateRequestDto claimDocumentRuleCreateRequestDto = new ClaimDocumentRuleService.ClaimDocumentRuleCreateRequestDto();

        claimDocumentRuleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimDocumentRuleCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimDocumentRuleCreateRequestDto.setPieceCode( arg0.getPieceCode() );
        claimDocumentRuleCreateRequestDto.setDocumentPrefix( arg0.getDocumentPrefix() );
        claimDocumentRuleCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return claimDocumentRuleCreateRequestDto;
    }

    @Override
    public ClaimDocumentRuleService.ClaimDocumentRuleUpdateRequestDto mapUpdate(ClaimDocumentRuleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ClaimDocumentRuleService.ClaimDocumentRuleUpdateRequestDto claimDocumentRuleUpdateRequestDto = new ClaimDocumentRuleService.ClaimDocumentRuleUpdateRequestDto();

        claimDocumentRuleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        claimDocumentRuleUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        claimDocumentRuleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        claimDocumentRuleUpdateRequestDto.setPieceCode( arg0.getPieceCode() );
        claimDocumentRuleUpdateRequestDto.setDocumentPrefix( arg0.getDocumentPrefix() );
        claimDocumentRuleUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );

        return claimDocumentRuleUpdateRequestDto;
    }
}
