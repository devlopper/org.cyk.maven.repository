package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasHierarchyIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link HierarchicalRelationDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class HierarchicalRelationFilter extends AbstractIdentifiableFilter
    implements FilterHasHierarchyIdentifier {

  private String hierarchyIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public HierarchicalRelationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public HierarchicalRelationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateHierarchyIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterHierarchyIdentifier(filter);
  }

}
