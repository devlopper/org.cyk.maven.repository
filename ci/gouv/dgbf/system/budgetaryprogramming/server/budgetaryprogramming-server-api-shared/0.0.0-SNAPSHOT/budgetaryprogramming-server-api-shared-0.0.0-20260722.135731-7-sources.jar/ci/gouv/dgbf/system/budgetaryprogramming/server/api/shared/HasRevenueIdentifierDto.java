package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de revenu.
 *
 * @author Christian
 */
public interface HasRevenueIdentifierDto extends HasRevenueIdentifier {

  /**
   * Identifiant json de l'identifiant du revenu.
   */
  String JSON_REVENUE_IDENTIFIER = "idRevenue";
}