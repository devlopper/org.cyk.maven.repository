package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ScriptParameterService.ScriptParameterCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptParameterService.ScriptParameterUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ScriptParameterDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ScriptParameterDto}.

    @author Christian
               """)
public interface ScriptParameterRequestMapper extends RequestMapper<ScriptParameterDto,
    ScriptParameterCreateRequestDto, ScriptParameterUpdateRequestDto> {

}
