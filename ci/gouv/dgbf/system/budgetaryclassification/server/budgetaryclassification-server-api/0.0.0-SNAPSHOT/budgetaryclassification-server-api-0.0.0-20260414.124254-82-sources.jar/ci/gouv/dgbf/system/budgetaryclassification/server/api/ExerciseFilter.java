package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasYear;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExerciseDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ExerciseFilter extends AbstractIdentifiableFilter implements FilterHasYear {
  
  /**
   * Budget préparable.
   */
  Boolean budgetPreparable;

  /**
   * Année.
   */
  Integer year;
  
  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ExerciseFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ExerciseFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    budgetPreparable = getBudgetPreparable(filter);
    updateYear(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setBudgetPreparable(filter, budgetPreparable);
    updateFilterYear(filter);
  }

  /**
   * Cette méthode permet d'assigner préparabilité du budget.
   *
   * @param filter filtre
   * @param budgetPreparable préparabilité du budget
   */
  public static void setBudgetPreparable(FilterDto filter, Boolean budgetPreparable) {
    set(filter, JSON_BUDGET_PREPARABLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(budgetPreparable));
  }

  /**
   * Cette méthode permet d'obtenir la préparabilité du budget.
   *
   * @param filter filtre
   * @return préparabilité du budget
   */
  public static Boolean getBudgetPreparable(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_BUDGET_PREPARABLE));
  }

  /**
   * Identifiant json champ {@link #budgetPreparable}.
   */
  public static final String JSON_BUDGET_PREPARABLE =
      ExerciseDto.JSON_BUDGET_PREPARABLE;
}
