package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementInstanceDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementInstanceFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de l'élément de paie.
   */
  String payrollElementIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementInstanceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementInstanceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    payrollElementIdentifier = getPayrollElementIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setPayrollElementIdentifier(filter, payrollElementIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'élément de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPayrollElementIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYROLL_ELEMENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'élément de paie.
   *
   * @param filter filtre
   * @return identifiant de l'élément de paie
   */
  public static String getPayrollElementIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PAYROLL_ELEMENT_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link PayrollElementInstanceFilter#payrollElementIdentifier}.
   */
  public static final String JSON_PAYROLL_ELEMENT_IDENTIFIER =
          PayrollElementInstanceDto.JSON_PAYROLL_ELEMENT_IDENTIFIER;

}
