package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasPendingRoleSolicitationCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasRoleCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserCountDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une application.
 *
 * @author Boobacool
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ApplicationDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasRoleCountDto, HasRoleCountAsStringDto, HasUserCountDto,
    HasUserCountAsStringDto, HasPendingRoleSolicitationCountDto,
    HasPendingRoleSolicitationCountAsStringDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  /**
   * Code du Domaine : avec le Code de l'Application, il permet au frontal d'évaluer les Droits
   * de la ligne (RG_UTI_ROL_16).
   */
  @JsonbProperty(JSON_DOMAIN_CODE)
  private String domainCode;

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  /**
   * Nombre de Rôles métier, sans les Rôles réservés (RU_UTI_027).
   */
  @JsonbProperty(JSON_ROLE_COUNT)
  private Integer roleCount;

  /**
   * Représentation en chaîne de caractères de {@link #roleCount}.
   */
  @JsonbProperty(JSON_ROLE_COUNT_AS_STRING)
  private String roleCountAsString;

  /**
   * Nombre d'Utilisateurs détenant au moins un Rôle de l'Application (RU_UTI_027).
   */
  @JsonbProperty(JSON_USER_COUNT)
  private Integer userCount;

  /**
   * Représentation en chaîne de caractères de {@link #userCount}.
   */
  @JsonbProperty(JSON_USER_COUNT_AS_STRING)
  private String userCountAsString;

  /**
   * Nombre de demandes de rôle en attente (statut Créée) sur les Rôles de l'Application
   * (RU_UTI_027).
   */
  @JsonbProperty(JSON_PENDING_ROLE_SOLICITATION_COUNT)
  private Integer pendingRoleSolicitationCount;

  /**
   * Représentation en chaîne de caractères de {@link #pendingRoleSolicitationCount}.
   */
  @JsonbProperty(JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING)
  private String pendingRoleSolicitationCountAsString;

  /**
   * Identifiant json {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = DomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #domainAsString}.
   */
  public static final String JSON_DOMAIN_AS_STRING = DomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #domainCode}.
   */
  public static final String JSON_DOMAIN_CODE = "codeDomaine";

  /**
   * Identifiant json {@link #userIdentifier}.
   */

  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idApplication";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "applicationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "application";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
