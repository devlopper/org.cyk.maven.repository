package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RepresentationDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T15:33:03+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RepresentationRequestMapperImpl implements RepresentationRequestMapper {

    @Override
    public RepresentationService.RepresentationCreateRequestDto mapCreate(RepresentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationService.RepresentationCreateRequestDto representationCreateRequestDto = new RepresentationService.RepresentationCreateRequestDto();

        representationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationCreateRequestDto.setCode( arg0.getCode() );
        representationCreateRequestDto.setName( arg0.getName() );

        return representationCreateRequestDto;
    }

    @Override
    public RepresentationService.RepresentationUpdateRequestDto mapUpdate(RepresentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationService.RepresentationUpdateRequestDto representationUpdateRequestDto = new RepresentationService.RepresentationUpdateRequestDto();

        representationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        representationUpdateRequestDto.setCode( arg0.getCode() );
        representationUpdateRequestDto.setName( arg0.getName() );

        return representationUpdateRequestDto;
    }
}
