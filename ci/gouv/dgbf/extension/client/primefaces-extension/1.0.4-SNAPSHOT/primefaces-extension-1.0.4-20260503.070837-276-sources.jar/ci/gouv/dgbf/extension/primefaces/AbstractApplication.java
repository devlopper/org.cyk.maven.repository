package ci.gouv.dgbf.extension.primefaces;

import jakarta.inject.Inject;

/**
 * Cette classe repérsente la base de point d'entrée de processus.
 *
 * @author Christian
 *
 */
public abstract class AbstractApplication {

  @Inject
  protected ApplicationManager manager;
  
}
