package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.FunctionalDomainService.FunctionalDomainCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.FunctionalDomainService.FunctionalDomainUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionalDomainDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionalDomainDto}.

    @author Christian
    """)
public interface FunctionalDomainRequestMapper extends
    RequestMapper<FunctionalDomainDto, FunctionalDomainCreateRequestDto, 
        FunctionalDomainUpdateRequestDto> {
}
