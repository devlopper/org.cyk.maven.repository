package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Réclamable : un input du calcul de paie (Élément de Paie ou
 * Constante de Paie) synchronisé depuis le module {@code payroll} (RG_REP_CIB_07).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Nature du Réclamable ({@code ELEMENT_PAIE} ou {@code CONSTANTE_PAIE}).
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant, module payroll, de l'Élément de Paie ou de la Constante de Paie synchronisé(e).
   */
  @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
  private String payrollIdentifier;

  /**
   * Date de la dernière synchronisation.
   */
  @JsonbProperty(JSON_SYNCHRONIZATION_DATE)
  private String synchronizationDate;

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #payrollIdentifier}.
   */
  public static final String JSON_PAYROLL_IDENTIFIER = "idPayroll";

  /**
   * Identifiant json {@link #synchronizationDate}.
   */
  public static final String JSON_SYNCHRONIZATION_DATE = "dateSynchronisation";

  /**
   * Identifiant json de identifiant de {@link ClaimableDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimableDto}.
   */
  public static final String JSON_THIS_AS_STRING = "reclamableChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "réclamables";
}
