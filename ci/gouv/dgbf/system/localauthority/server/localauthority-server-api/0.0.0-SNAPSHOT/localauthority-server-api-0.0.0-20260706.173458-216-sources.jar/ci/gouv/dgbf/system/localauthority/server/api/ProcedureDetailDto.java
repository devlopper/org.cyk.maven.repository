package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import java.util.Date;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une procedure.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcedureDetailDto extends AbstractIdentifiableNamableAuditableDto {

  /**
   * Identifiant de {@link ProcedureDto}.
   */
  @JsonbProperty(JSON_PROCEDURE_IDENTIFIER)
  private String procedureIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ProcedureDto}.
   */
  @JsonbProperty(JSON_PROCEDURE_AS_STRING)
  private String procedureAsString;

  /**
   * Ordre.
   */
  @JsonbProperty(JSON_ORDER)
  private Integer order;

  /**
   * Représentation en chaine de caractères d'order.
   */
  @JsonbProperty(JSON_ORDER_AS_STRING)
  private String orderAsString;

  /**
   * Date.
   */
  @JsonbProperty(JSON_DATE)
  private LocalDate date;

  /**
   * Représentation en chaine de caractères de detailDate.
   */
  @JsonbProperty(JSON_DATE_AS_STRING)
  private String dateAsString;

  /**
   * Identitiant json {@link ProcedureDetailDto#procedureIdentifier}.
   */
  public static final String JSON_PROCEDURE_IDENTIFIER = "idProcedure";

  /**
   * Identitiant json {@link ProcedureDetailDto#procedureAsString}.
   */
  public static final String JSON_PROCEDURE_AS_STRING = "procedureChaine";

  /**
   * Identifiant json {@link ProcedureDetailDto#order}.
   */
  public static final String JSON_ORDER = "order";


  /**
   * Identifiant json {@link ProcedureDetailDto#orderAsString}.
   */
  public static final String JSON_ORDER_AS_STRING = "orderChaine";

  /**
   * Identifiant json {@link ProcedureDetailDto#date}.
   */
  public static final String JSON_DATE = "date";


  /**
   * Identifiant json {@link ProcedureDetailDto#dateAsString}.
   */
  public static final String JSON_DATE_AS_STRING  = "dateChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "detail de procedure";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "details de procedure";
}
