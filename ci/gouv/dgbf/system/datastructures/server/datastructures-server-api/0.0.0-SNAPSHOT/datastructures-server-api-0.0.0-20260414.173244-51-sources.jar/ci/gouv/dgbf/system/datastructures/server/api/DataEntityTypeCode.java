package ci.gouv.dgbf.system.datastructures.server.api;

/**
 * Cette classe représente le code de {@link DataEntityType}.
 *
 * @author Christian
 *
 */
public class DataEntityTypeCode {

  private DataEntityTypeCode() {

  }

  /**
   * Table.
   */
  public static final String TABLE = "TABLE";

  /**
   * Vue.
   */
  public static final String VIEW = "VUE";

  /**
   * Fichier.
   */
  public static final String FILE = "FICHIER";

  /**
   * API.
   */
  public static final String API = "API";
}
