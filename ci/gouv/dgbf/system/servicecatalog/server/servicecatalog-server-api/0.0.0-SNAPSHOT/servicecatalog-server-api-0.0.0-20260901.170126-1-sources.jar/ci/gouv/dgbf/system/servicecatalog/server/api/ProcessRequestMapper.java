package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessService.ProcessCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessService.ProcessUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcessDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProcessDto}.

    @author Christian
               """)
public interface ProcessRequestMapper
    extends RequestMapper<ProcessDto, ProcessCreateRequestDto,
        ProcessUpdateRequestDto> {

}
