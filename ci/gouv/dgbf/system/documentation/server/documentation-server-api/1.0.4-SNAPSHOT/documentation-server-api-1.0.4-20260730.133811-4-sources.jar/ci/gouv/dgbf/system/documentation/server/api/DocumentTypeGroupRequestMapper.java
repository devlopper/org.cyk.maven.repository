package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentTypeGroupDto}.

    @author Christian
               """)
public interface DocumentTypeGroupRequestMapper
    extends RequestMapper<DocumentTypeGroupDto, DocumentTypeGroupCreateRequestDto,
        DocumentTypeGroupUpdateRequestDto> {

}
