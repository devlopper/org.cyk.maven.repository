package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonClient;
import ci.gouv.dgbf.system.functionary.server.api.EchelonDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonRequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService.EchelonCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.EchelonService.EchelonUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link EchelonDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class EchelonController extends AbstractController {

  @Inject
  EchelonClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  EchelonFilterController filterController;

  @Inject
  EchelonRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  CivilServiceStatusSelectOneController civilServiceStatusSelectOneController;



  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = EchelonDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(EchelonDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(EchelonService.PATH);

    listController.getDataTable().getFilterButton().setRendered(true);

    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME);

    projection.addNamesIfStringBlank(filterController.getFilter()
        .getCivilServiceStatusIdentifier(),
        EchelonDto.JSON_CIVIL_SERVICE_STATUS_AS_STRING);

    listController.getReadController().setProjection(projection);

    civilServiceStatusSelectOneController.setRenderable(StringCore.isBlank(filterController
        .getFilter().getCivilServiceStatusIdentifier()));

    listController.initialize();

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());

    listController.getCreateController().setFunction(entity -> {
      EchelonCreateRequestDto request = requestMapper.mapCreate((EchelonDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME,
            EchelonDto.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    codeInputTextController.initializeCode(codeConsumer());
    nameInputTextController.initializeName(nameConsumer());

    civilServiceStatusSelectOneController.getSelectOneMenu().setRequired(true);
    civilServiceStatusSelectOneController.getSelectOneMenu()
        .addValueConsumer(civilServiceStatusIdentifierConsumer());

  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> {

      ((EchelonDto) entity).setCivilServiceStatusIdentifier(filterController.getFilter()
          .getCivilServiceStatusIdentifier());
    };
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {

      codeInputTextController.getInputText().writeValue(((EchelonDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((EchelonDto) entity).getName());
      civilServiceStatusSelectOneController.getSelectOneMenu()
          .writeValue(((EchelonDto) entity).getCivilServiceStatusIdentifier());
    };
  }

  Consumer<String> civilServiceStatusIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(EchelonDto.class)
        .setCivilServiceStatusIdentifier(identifier);
  }

  Consumer<String> codeConsumer() {
    return code -> listController.getCreateControllerOrUpdateControllerEntityAs(
        EchelonDto.class)
        .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name -> listController.getCreateControllerOrUpdateControllerEntityAs(
        EchelonDto.class)
        .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      EchelonUpdateRequestDto request = requestMapper.mapUpdate((EchelonDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des
   * messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
