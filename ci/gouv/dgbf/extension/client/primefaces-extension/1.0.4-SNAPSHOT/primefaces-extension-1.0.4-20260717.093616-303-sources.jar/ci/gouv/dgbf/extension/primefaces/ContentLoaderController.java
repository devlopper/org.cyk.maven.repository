package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.primefaces.component.OutputPanel;
import jakarta.enterprise.context.Dependent;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de chargeur de contenu.
 */
@Dependent
public class ContentLoaderController {

  @Getter
  @Setter
  ContentLoader loader;

  @Getter
  @Setter
  OutputPanel outputPanel;

  @Getter
  @Setter
  Text loadingText;

  @Getter
  @Setter
  Text loadedText;

  /**
   * Cette méthode permet de construire.
   */
  public ContentLoaderController() {
    outputPanel = new OutputPanel();

    loadingText = new Text();
    loadingText.setValue("Veuillez patienter, chargement en cours...");

    loadedText = new Text();
    loadedText.setValue("chargement éffectué.");
  }

  /**
   * Cette méthode permet d'obtenir {@link ContentLoader} non null.
   *
   * @return {@link ContentLoader} non null
   */
  public ContentLoader loader() {
    if (loader == null) {
      loader = new ContentLoader();
    }
    return loader;
  }
}
