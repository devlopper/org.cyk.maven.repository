package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamMemberService.SupportTeamMemberCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.SupportTeamMemberService.SupportTeamMemberUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SupportTeamMemberDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SupportTeamMemberDto}.

    @author Arnaud
               """)
public interface SupportTeamMemberRequestMapper
    extends RequestMapper<SupportTeamMemberDto, SupportTeamMemberCreateRequestDto,
     SupportTeamMemberUpdateRequestDto> {

}
