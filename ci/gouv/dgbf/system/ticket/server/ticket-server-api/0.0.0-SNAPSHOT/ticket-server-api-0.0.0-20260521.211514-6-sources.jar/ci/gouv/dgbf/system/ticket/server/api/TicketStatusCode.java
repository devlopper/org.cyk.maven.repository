package ci.gouv.dgbf.system.ticket.server.api;

/**
 * Cette classe représente les codes de {@link TicketStatus}.
 *
 * @author Arnaud
 *
 */
public class TicketStatusCode {

  private TicketStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Pris_en_charge.
   */
  public static final String IN_PROGRESS = "PRIS_EN_CHARGE";

  /**
   * Résolu.
   */
  public static final String RESOLVED = "RESOLU";

  /**
   * Satisfait.
   */
  public static final String SATISFIED = "SATISFAIT";

  /**
   * Non satisfait.
   */
  public static final String UNSATISFIED = "NON_SATISFAIT";
}
