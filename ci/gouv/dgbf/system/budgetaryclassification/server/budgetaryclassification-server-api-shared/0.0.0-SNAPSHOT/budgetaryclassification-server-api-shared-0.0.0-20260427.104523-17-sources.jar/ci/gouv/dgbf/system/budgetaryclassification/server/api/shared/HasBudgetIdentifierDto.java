package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de budget.
 *
 * @author Christian
 */
public interface HasBudgetIdentifierDto extends HasBudgetIdentifier {
  
  /**
   * Identifiant json de l'identifiant de budget.
   */
  String JSON_BUDGET_IDENTIFIER = "idBudget";
}