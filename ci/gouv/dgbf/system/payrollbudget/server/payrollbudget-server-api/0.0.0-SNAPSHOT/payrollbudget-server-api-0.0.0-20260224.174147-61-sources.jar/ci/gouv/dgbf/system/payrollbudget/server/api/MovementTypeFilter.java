package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link MovementTypeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementTypeFilter extends AbstractIdentifiableFilter
    implements FilterHasAdministrativeUnitEmployeeStatusCode {

  /**
   * Code de {@link AdministrativeUnitEmployeeStatus}.
   */
  String administrativeUnitEmployeeStatusCode;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public MovementTypeFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public MovementTypeFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateAdministrativeUnitEmployeeStatusCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterAdministrativeUnitEmployeeStatusCode(filter);
  }

}
