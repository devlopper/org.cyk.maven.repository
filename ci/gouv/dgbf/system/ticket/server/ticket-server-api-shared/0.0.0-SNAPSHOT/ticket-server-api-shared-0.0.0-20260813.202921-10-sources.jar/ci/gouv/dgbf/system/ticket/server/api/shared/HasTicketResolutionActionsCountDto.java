package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'actions de résolution
 * de ticket.
 *
 * @author Christian
 */
public interface HasTicketResolutionActionsCountDto extends HasTicketResolutionActionsCount {

  /**
   * Identifiant json du nombre cumulé d'actions de résolution de ticket.
   */
  String JSON_TICKET_RESOLUTION_ACTIONS_COUNT = "nombreActionsResolutionTicket";
}
