package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ExpenditureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-08T19:42:15+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ExpenditureRequestMapperImpl implements ExpenditureRequestMapper {

    @Override
    public ExpenditureService.ExpenditureCreateRequestDto mapCreate(ExpenditureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureService.ExpenditureCreateRequestDto expenditureCreateRequestDto = new ExpenditureService.ExpenditureCreateRequestDto();

        expenditureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        expenditureCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        expenditureCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        expenditureCreateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        expenditureCreateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        expenditureCreateRequestDto.setFundingSourceIdentifier( arg0.getFundingSourceIdentifier() );
        expenditureCreateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );

        return expenditureCreateRequestDto;
    }

    @Override
    public ExpenditureService.ExpenditureUpdateRequestDto mapUpdate(ExpenditureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ExpenditureService.ExpenditureUpdateRequestDto expenditureUpdateRequestDto = new ExpenditureService.ExpenditureUpdateRequestDto();

        expenditureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        expenditureUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        expenditureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        expenditureUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        expenditureUpdateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        expenditureUpdateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        expenditureUpdateRequestDto.setFundingSourceIdentifier( arg0.getFundingSourceIdentifier() );
        expenditureUpdateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );

        return expenditureUpdateRequestDto;
    }
}
