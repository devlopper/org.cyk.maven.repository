package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat de consultation des impacts d'un mouvement de carrière.
 *
 * <p><strong>Consultation seulement.</strong> Un impact n'est pas saisi : il est le produit du
 * calcul qui rapproche la situation de l'agent avant la mesure et sa situation après. Lui ouvrir
 * une écriture reviendrait à laisser corriger à la main un montant que la règle a établi — et
 * l'arbitrage perdrait ce qui fait sa valeur, à savoir que chaque chiffre se rattache à une
 * règle et non à une décision de saisie.</p>
 *
 * @author Christian
 *
 */
@Path(value = MovementImpactService.PATH)
@Tag(name = "Gestion des impacts de mouvement")
public interface MovementImpactService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "impacts-mouvements";

  /**
   * Identifiant du service d'obtention de plusieurs {@link MovementImpactDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_IMPACT_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link MovementImpactDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des impacts.
   *
   * @param request critères, projection et pagination
   * @return les impacts correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation des impacts des mouvements")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = MovementImpactGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche d'impacts.
   */
  @Getter
  @Setter
  public static class MovementImpactGetManyResponseDto
      extends AbstractGetByPageResponseDto<MovementImpactDto> {
    @JsonbProperty(JSON_DATAS)
    private List<MovementImpactDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de {@link MovementImpactDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_IMPACT_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link MovementImpactDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'un impact par son identifiant.
   *
   * @param request identifiant et projection
   * @return l'impact correspondant
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = MovementImpactDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);
}
