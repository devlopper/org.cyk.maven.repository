package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import java.util.Collections;
import java.util.Set;
import lombok.Getter;

/**
 * Énumération représentant le statut de traitement d'une anomalie.
 */
@Getter
public enum AnomalyStatus implements CodableByStringWithGetterOnly {

  /**
   * Statut initial à la création (non traitée).
   */
  CREATED(AnomalyStatusCode.CREATED, "Créée"),

  /**
   * Statut final irréversible posé par l'administrateur.
   */
  TREATED(AnomalyStatusCode.TREATED, "Traitée");

  private final String code;
  private final String name;
  private Set<AnomalyStatus> previous;

  static {
    CREATED.previous = Collections.emptySet();
    TREATED.previous = Collections.singleton(CREATED);
  }

  AnomalyStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  /**
   * Retourne l'ensemble des statuts autorisés à transitionner vers ce statut. Toujours
   * renseigné (bloc static ci-dessus, pour chaque constante) : pas de garde contre {@code null}.
   *
   * @return ensemble des statuts prédécesseurs
   */
  public Set<AnomalyStatus> getPrevious() {
    return previous;
  }

  /**
   * Recherche un statut par son code.
   *
   * @param code code à rechercher
   * @return statut correspondant
   */
  public static AnomalyStatus getByCode(String code) {
    if (code == null) {
      return null;
    }
    for (AnomalyStatus value : values()) {
      if (value.code.equals(code)) {
        return value;
      }
    }
    throw new IllegalArgumentException("Code de statut d'anomalie inconnu : " + code);
  }
}

