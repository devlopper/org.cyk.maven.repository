package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de service.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ServiceGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link ServiceGroupDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeService";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ServiceGroupDto}.
   */
  public static final String JSON_THIS_AS_STRING = "groupeServiceChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de service";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de service";
}
