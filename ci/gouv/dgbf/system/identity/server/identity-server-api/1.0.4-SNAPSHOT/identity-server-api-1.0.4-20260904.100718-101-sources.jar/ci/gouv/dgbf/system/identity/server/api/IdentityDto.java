package ci.gouv.dgbf.system.identity.server.api;

import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une identité.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityDto extends AbstractIdentityDto {

  /**
   * Identifiant {@link IdentitiesGroupDto}.
   */
  @JsonbProperty(value = JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;
  
  /**
   * Identifiant json champ {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";
  
  /**
   * Identifiant json d'un attribut de type {@link IdentityDto}.
   */
  public static final String JSON_THIS = "identite";
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "identité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
