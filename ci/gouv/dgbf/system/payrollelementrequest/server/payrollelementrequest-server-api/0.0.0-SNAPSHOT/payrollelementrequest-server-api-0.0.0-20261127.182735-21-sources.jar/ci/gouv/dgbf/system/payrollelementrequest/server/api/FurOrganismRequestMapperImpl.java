package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FurOrganismDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T18:26:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.20.1 (Eclipse Adoptium)"
)
@ApplicationScoped
public class FurOrganismRequestMapperImpl implements FurOrganismRequestMapper {

    @Override
    public FurOrganismService.FurOrganismCreateRequestDto mapCreate(FurOrganismDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurOrganismService.FurOrganismCreateRequestDto furOrganismCreateRequestDto = new FurOrganismService.FurOrganismCreateRequestDto();

        furOrganismCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        furOrganismCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        furOrganismCreateRequestDto.setOrganismCode( arg0.getOrganismCode() );
        furOrganismCreateRequestDto.setGuardianOrganismCode( arg0.getGuardianOrganismCode() );
        furOrganismCreateRequestDto.setServiceCode( arg0.getServiceCode() );
        furOrganismCreateRequestDto.setCaloSectionCode( arg0.getCaloSectionCode() );
        furOrganismCreateRequestDto.setCaloServiceCode( arg0.getCaloServiceCode() );

        return furOrganismCreateRequestDto;
    }

    @Override
    public FurOrganismService.FurOrganismUpdateRequestDto mapUpdate(FurOrganismDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurOrganismService.FurOrganismUpdateRequestDto furOrganismUpdateRequestDto = new FurOrganismService.FurOrganismUpdateRequestDto();

        furOrganismUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        furOrganismUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        furOrganismUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        furOrganismUpdateRequestDto.setOrganismCode( arg0.getOrganismCode() );
        furOrganismUpdateRequestDto.setGuardianOrganismCode( arg0.getGuardianOrganismCode() );
        furOrganismUpdateRequestDto.setServiceCode( arg0.getServiceCode() );
        furOrganismUpdateRequestDto.setCaloSectionCode( arg0.getCaloSectionCode() );
        furOrganismUpdateRequestDto.setCaloServiceCode( arg0.getCaloServiceCode() );

        return furOrganismUpdateRequestDto;
    }
}
