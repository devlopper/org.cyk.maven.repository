package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.ClassHelper;
import jakarta.inject.Inject;

/**
 * Cette classe représente la base de contrôleur de mise à jour.
 *
 * @author Christian
 *
 */
public abstract class AbstractUpdateController<T, R>
    extends AbstractCreateOrUpdateController<T, R> {

  @Inject
  ClassHelper classHelper;

  protected AbstractUpdateController() {
    name = "Mise à jour";
  }

  @Override
  public boolean isCreate() {
    return false;
  }
}
