package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FolderPriorityDto}.
 *
 * @author Dahoud
 */
@Getter
@Setter
public class FolderPriorityFilter extends AbstractIdentifiableFilter {}
