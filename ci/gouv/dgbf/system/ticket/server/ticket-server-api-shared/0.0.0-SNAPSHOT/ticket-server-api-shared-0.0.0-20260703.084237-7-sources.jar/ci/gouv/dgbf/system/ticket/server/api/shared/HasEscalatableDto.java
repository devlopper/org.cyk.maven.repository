package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être escaladé.
 *
 * @author Christian
 */
public interface HasEscalatableDto extends HasEscalatable {

  /**
   * Identifiant json de peut être escaladé.
   */
  String JSON_ESCALATABLE = "peutEtreEscalade";
}