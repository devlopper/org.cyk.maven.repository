package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityActionType;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventChartCode;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventClient;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventDto;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventFilter;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventService.TraceabilityEventGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Contrôleur du tableau de bord d'activité utilisateur (Mon activité / Activité d'un utilisateur).
 *
 * @author Christian
 *
 */
@Dependent
public class ConnectedUserActivityController extends AbstractController {

  @Inject
  TraceabilityEventClient client;

  @Inject
  @Getter
  ChartController volumeByDayChartController;

  @Inject
  @Getter
  ChartController functionalityChartController;

  @Getter
  @Setter
  String targetUser;

  @Getter
  @Setter
  boolean consultingOtherUser;

  @Getter
  int periodDays = 7;

  @Getter
  boolean customPeriod;

  @Getter
  @Setter
  LocalDateTime dateDebut;

  @Getter
  @Setter
  LocalDateTime dateFin;

  @Getter
  String periodError;

  @Getter
  String lastActivity = "Aucune activité sur la période";

  @Getter
  long totalActions;

  @Getter
  long totalLectures;

  @Getter
  long totalExecutions;

  @Getter
  long totalEnvois;

  @Getter
  long totalCreations;

  @Getter
  long totalModifications;

  @Getter
  long totalSuppressions;

  @Getter
  long totalErreurs;

  @Getter
  List<ActivityItemDto> topRecords = new ArrayList<>();

  @Getter
  List<ActivityItemDto> sessions = new ArrayList<>();

  @Getter
  long recentErrorsCount;

  @Getter
  List<TraceabilityEventDto> events = new ArrayList<>();

  @Getter
  @Setter
  TraceabilityEventDto selectedEvent;

  @Getter
  @Setter
  String selectedActionType;

  @Getter
  @Setter
  String selectedProcess;

  @Getter
  @Setter
  String searchQuery;

  @Getter
  List<String> availableProcesses = new ArrayList<>();

  @Getter
  @Setter
  String searchUserText;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Mon activité";
    for (ChartController controller : List.of(volumeByDayChartController,
        functionalityChartController)) {
      controller.setTitleDisplayed(false);
      controller.setLegendDisplayed(false);
      controller.setIntegerValues(true);
    }
    functionalityChartController.setUniformColor(true);
  }

  /**
   * Initialise les agrégats, métriques et événements de l'activité utilisateur.
   */
  public void initialize() {
    if (!customPeriod) {
      dateFin = LocalDateTime.now();
      dateDebut = dateFin.minusDays(periodDays);
    }

    TraceabilityEventFilter filter = new TraceabilityEventFilter();
    filter.setChartCode(TraceabilityEventChartCode.USER_ACTIVITY);
    filter.setDateFrom(dateDebut);
    filter.setDateTo(dateFin);
    FilterDto filterDto = filter.toDto();
    filterDto.addCriteria("auditActor", targetUser);

    GetChartResponseDto chartResponse = client.getChart(filterDto, userIdentifier, null);
    ChartDto fullChart = chartResponse != null ? chartResponse.getChart() : null;

    processKpis(fullChart);
    processLastActivity(fullChart);
    processCharts(fullChart);
    processTopRecords(fullChart);
    processSessions(fullChart);
    processRecentErrors(fullChart);

    loadEvents();
  }

  void processKpis(ChartDto chart) {
    totalActions = 0;
    totalLectures = 0;
    totalExecutions = 0;
    totalEnvois = 0;
    totalCreations = 0;
    totalModifications = 0;
    totalSuppressions = 0;
    totalErreurs = 0;

    ChartDataSetDto kpis = findDataSet(chart, TraceabilityEventChartCode.KPIS);
    if (kpis == null || kpis.getDatas() == null) {
      return;
    }
    for (ChartDataDto data : kpis.getDatas()) {
      Long valObj = data.getValue();
      long val = 0L;
      if (valObj != null) {
        val = valObj.longValue();
      }
      if ("TOTAL".equals(data.getKey())) {
        totalActions = val;
      } else if ("LECTURE".equals(data.getKey())) {
        totalLectures = val;
      } else if ("EXECUTION".equals(data.getKey())) {
        totalExecutions = val;
      } else if ("ENVOI".equals(data.getKey())) {
        totalEnvois = val;
      } else if ("CREATION".equals(data.getKey())) {
        totalCreations = val;
      } else if ("MODIFICATION".equals(data.getKey())) {
        totalModifications = val;
      } else if ("SUPPRESSION".equals(data.getKey())) {
        totalSuppressions = val;
      } else if ("ERREUR".equals(data.getKey())) {
        totalErreurs = val;
      }
    }
  }

  void processLastActivity(ChartDto chart) {
    lastActivity = "Aucune activité sur la période";
    ChartDataSetDto ds = findDataSet(chart, TraceabilityEventChartCode.LAST_ACTIVITY);
    if (ds == null || ds.getDatas() == null || ds.getDatas().isEmpty()) {
      return;
    }
    String iso = ds.getDatas().iterator().next().getKey();
    if (iso == null || iso.isBlank()) {
      return;
    }
    try {
      LocalDateTime lastWhen = LocalDateTime.parse(iso);
      lastActivity = formatLastActivity(lastWhen);
    } catch (Exception e) {
      lastActivity = iso;
    }
  }

  void processCharts(ChartDto chart) {
    ChartDataSetDto volumeDataSet = findDataSet(chart, TraceabilityEventChartCode.VOLUME_BY_DAY);
    volumeByDayChartController.setSupplier(
        () -> buildResponse("Activité par jour", volumeDataSet));
    volumeByDayChartController.buildBarChart();

    ChartDataSetDto functionalityDataSet =
        findDataSet(chart, TraceabilityEventChartCode.FUNCTIONALITY);
    functionalityChartController.setSupplier(
        () -> buildResponse("Où j'ai travaillé", functionalityDataSet));
    functionalityChartController.buildBarChart();

    ChartDataSetDto processDataSet = findDataSet(chart, TraceabilityEventChartCode.PROCESS);

    availableProcesses = new ArrayList<>();
    if (processDataSet == null || processDataSet.getDatas() == null) {
      return;
    }
    for (ChartDataDto d : processDataSet.getDatas()) {
      String key = d.getKey();
      if (key != null && !key.isBlank()) {
        availableProcesses.add(key);
      }
    }
  }

  void processTopRecords(ChartDto chart) {
    topRecords = new ArrayList<>();
    ChartDataSetDto ds = findDataSet(chart, TraceabilityEventChartCode.TOP_RECORDS);
    if (ds == null || ds.getDatas() == null) {
      return;
    }
    for (ChartDataDto d : ds.getDatas()) {
      Long val = d.getValue();
      long count = 0L;
      if (val != null) {
        count = val.longValue();
      }
      topRecords.add(new ActivityItemDto(d.getKey(), count));
    }
  }

  void processSessions(ChartDto chart) {
    sessions = new ArrayList<>();
    ChartDataSetDto ds = findDataSet(chart, TraceabilityEventChartCode.SESSIONS);
    if (ds == null || ds.getDatas() == null) {
      return;
    }
    for (ChartDataDto d : ds.getDatas()) {
      Long val = d.getValue();
      long count = 0L;
      if (val != null) {
        count = val.longValue();
      }
      sessions.add(new ActivityItemDto(d.getKey(), count));
    }
  }

  void processRecentErrors(ChartDto chart) {
    recentErrorsCount = 0L;
    ChartDataSetDto ds = findDataSet(chart, TraceabilityEventChartCode.RECENT_ERRORS);
    if (ds == null || ds.getDatas() == null || ds.getDatas().isEmpty()) {
      return;
    }
    Long val = ds.getDatas().iterator().next().getValue();
    if (val != null) {
      recentErrorsCount = val.longValue();
    }
  }

  /**
   * Charge la liste des événements de la chronologie selon les filtres courants.
   */
  public void loadEvents() {
    TraceabilityEventFilter listFilter = new TraceabilityEventFilter();
    listFilter.setDateFrom(dateDebut);
    listFilter.setDateTo(dateFin);
    if (selectedActionType != null && !selectedActionType.isBlank()) {
      listFilter.setActionType(TraceabilityActionType.getByCode(selectedActionType));
    }
    if (selectedProcess != null && !selectedProcess.isBlank()) {
      listFilter.setProcessIdentifier(selectedProcess);
    }
    if (searchQuery != null && !searchQuery.isBlank()) {
      listFilter.setMessageSummary(searchQuery.trim());
    }

    final ProjectionDto projection = new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        "type", "category", "sourceIdentifier", "processIdentifier", "level", "source", "record",
        "operation", "actionType", "containsMaskedData", "messageSummary",
        AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING);

    PageDto page = new PageDto();
    page.setIndex(1);
    page.setSize(50);

    FilterDto listFilterDto = listFilter.toDto();
    listFilterDto.addCriteria("auditActor", targetUser);

    TraceabilityEventGetManyResponseDto response = client.getMany(
        projection, listFilterDto, page, userIdentifier, null);
    if (response != null && response.getDatas() != null) {
      events = response.getDatas();
    } else {
      events = Collections.emptyList();
    }
  }

  /**
   * Applique un intervalle rapide en nombre de jours.
   *
   * @param days nombre de jours
   */
  public void applyPeriod(int days) {
    this.periodDays = days;
    this.customPeriod = false;
    this.periodError = null;
    initialize();
  }

  /**
   * Applique une période personnalisée avec contrôle de validité (max 90 jours).
   *
   * @param start date de début
   * @param end date de fin
   */
  public void applyCustomPeriod(LocalDateTime start, LocalDateTime end) {
    if (start == null || end == null) {
      periodError = "Veuillez renseigner les dates de début et de fin.";
      return;
    }
    if (start.isAfter(end)) {
      periodError = "La date de début doit être antérieure à la date de fin.";
      return;
    }
    if (ChronoUnit.DAYS.between(start, end) > 90) {
      periodError = "La période ne peut pas dépasser 90 jours.";
      return;
    }
    this.dateDebut = start;
    this.dateFin = end;
    this.customPeriod = true;
    this.periodError = null;
    initialize();
  }

  /**
   * Applique les filtres de type d'action, processus et recherche textuelle.
   */
  public void applyFilters() {
    loadEvents();
  }

  /**
   * Réinitialise les filtres d'action, processus et recherche.
   */
  public void resetFilters() {
    selectedActionType = null;
    selectedProcess = null;
    searchQuery = null;
    loadEvents();
  }

  /**
   * Recherche prédictive des utilisateurs pour l'autocomplétion administrateur.
   *
   * @param query préfixe ou terme saisi
   * @return liste des identifiants correspondants
   */
  public List<String> completeUser(String query) {
    if (query == null || query.trim().length() < 3) {
      return Collections.emptyList();
    }
    FilterDto filter = new FilterDto();
    TraceabilityEventFilter.setChartCode(filter, TraceabilityEventChartCode.USER_SEARCH);
    filter.addCriteria("search", query.trim());
    GetChartResponseDto response = client.getChart(filter, userIdentifier, null);
    if (response == null || response.getChart() == null) {
      return Collections.emptyList();
    }
    ChartDataSetDto ds = findDataSet(response.getChart(),
        TraceabilityEventChartCode.USER_SEARCH);
    if (ds == null || ds.getDatas() == null) {
      return Collections.emptyList();
    }
    return ds.getDatas().stream()
        .map(ChartDataDto::getKey)
        .filter(k -> k != null && !"ANONYME".equals(k))
        .collect(Collectors.toList());
  }

  /**
   * Change l'utilisateur cible consulté.
   *
   * @param user identifiant de l'utilisateur
   */
  public void selectTargetUser(String user) {
    if (user == null || user.isBlank()) {
      return;
    }
    this.targetUser = user.trim();
    if (userIdentifier != null) {
      this.consultingOtherUser = !targetUser.equalsIgnoreCase(userIdentifier);
    } else {
      this.consultingOtherUser = false;
    }
    initialize();
  }

  String formatLastActivity(LocalDateTime when) {
    if (when == null) {
      return "Aucune activité sur la période";
    }
    LocalDate date = when.toLocalDate();
    LocalDate today = LocalDate.now();
    DateTimeFormatter timeFmt = DateTimeFormatter.ofPattern("HH:mm:ss");
    if (date.equals(today)) {
      return "aujourd'hui à " + when.format(timeFmt);
    }
    if (date.equals(today.minusDays(1))) {
      return "hier à " + when.format(timeFmt);
    }
    DateTimeFormatter dateFmt = DateTimeFormatter.ofPattern("dd/MM/yyyy 'à' HH:mm:ss");
    return "le " + when.format(dateFmt);
  }

  ChartDataSetDto findDataSet(ChartDto chart, String name) {
    if (chart == null || chart.getDataSets() == null) {
      return null;
    }
    return chart.getDataSets().stream()
        .filter(ds -> name.equals(ds.getName()))
        .findFirst()
        .orElse(null);
  }

  GetChartResponseDto buildResponse(String title, ChartDataSetDto dataSet) {
    ChartDto chart = new ChartDto();
    chart.setName(title);
    if (dataSet != null && dataSet.getDatas() != null && !dataSet.getDatas().isEmpty()) {
      chart.addDataSet(dataSet);
      LinkedHashSet<String> keys = dataSet.getDatas().stream()
          .map(ChartDataDto::getKey)
          .collect(Collectors.toCollection(LinkedHashSet::new));
      chart.setKeys(keys);
    }
    GetChartResponseDto response = new GetChartResponseDto();
    response.setChart(chart);
    return response;
  }

  /**
   * Élément synthétique d'activité pour les panneaux latéraux (top enregistrements, sessions).
   */
  @Getter
  @Setter
  public static class ActivityItemDto implements Serializable {

    private String label;
    private long count;

    public ActivityItemDto() {}

    public ActivityItemDto(String label, long count) {
      this.label = label;
      this.count = count;
    }
  }
}
