package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les modules.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ModuleFilter extends AbstractIdentifiableFilter {

  private Boolean visible;
  private StrategicClassification strategicClassification;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ModuleFilter() {}

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ModuleFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    visible = getVisible(filter);
    strategicClassification = getStrategicClassification(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setVisible(filter, visible);
    setStrategicClassification(filter, strategicClassification);
  }

  /**
   * Cette méthode permet d'assigner la visibilité.
   *
   * @param filter filtre
   * @param visible visibilité
   */
  public static void setVisible(FilterDto filter, Boolean visible) {
    set(filter, HasVisibleDto.JSON_VISIBLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(visible));
  }

  /**
   * Cette méthode permet d'obtenir la visibilité.
   *
   * @param filter filtre
   * @return visibilité
   */
  public static Boolean getVisible(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(HasVisibleDto.JSON_VISIBLE));
  }

  /**
   * Cette méthode permet d'assigner la classification stratégique.
   *
   * @param filter filtre
   * @param strategicClassification classification stratégique
   */
  public static void setStrategicClassification(FilterDto filter,
      StrategicClassification strategicClassification) {
    set(filter, ModuleDto.JSON_STRATEGIC_CLASSIFICATION, f -> f.getValueAsString(),
        f -> f.setValueAsString(
            strategicClassification == null ? null : strategicClassification.getCode()));
  }

  /**
   * Cette méthode permet d'obtenir la classification stratégique.
   *
   * @param filter filtre
   * @return classification stratégique
   */
  public static StrategicClassification getStrategicClassification(FilterDto filter) {
    String code = get(filter,
        d -> d.getFieldValueAsStringByName(ModuleDto.JSON_STRATEGIC_CLASSIFICATION));
    return code == null || code.isBlank() ? null : StrategicClassification.getByCode(code);
  }
}
