package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.EconomicNatureClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.EconomicNatureDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.EconomicNatureService.EconomicNatureGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link EconomicNatureDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class EconomicNatureSelectOneController extends AbstractSelectOneIdentifiableController<
    EconomicNatureDto, EconomicNatureGetManyResponseDto, EconomicNatureClient> {

  @Inject
  @Getter
  EconomicNatureClient client;

  protected EconomicNatureSelectOneController() {
    super(EconomicNatureDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
