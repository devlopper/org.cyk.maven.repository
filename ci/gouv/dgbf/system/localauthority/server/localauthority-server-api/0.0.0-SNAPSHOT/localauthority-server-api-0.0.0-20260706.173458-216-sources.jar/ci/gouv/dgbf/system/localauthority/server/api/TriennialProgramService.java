package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TriennialProgramDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = TriennialProgramService.PATH)
@Tag(name = "Gestion des programmes triennaux")
public interface TriennialProgramService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "programmes-triennaux";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   */
  interface TriennialProgramSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de l'exercice.
     *
     * @return identifiant de l'exercice
     */
    String getExerciseIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'exercice.
     *
     * @param exerciseIdentifier identifiant de l'exercice
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la collectivité.
     *
     * @return identifiant de la collectivité
     */
    String getLocalAuthorityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la collectivité.
     *
     * @param localAuthorityIdentifier identifiant de la collectivité
     */
    void setLocalAuthorityIdentifier(String localAuthorityIdentifier);

    /**
     * {@link TriennialProgramDto#JSON_EXERCISE_IDENTIFIER}.
     */
    String JSON_EXERCISE_IDENTIFIER = TriennialProgramDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * {@link TriennialProgramDto#JSON_LOCAL_AUTHORITY_IDENTIFIER}.
     */
    String JSON_LOCAL_AUTHORITY_IDENTIFIER = TriennialProgramDto.JSON_LOCAL_AUTHORITY_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un programme triennal",
      description = "Ce service permet de créer un programme triennal")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TriennialProgramCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements TriennialProgramSaveRequestDto {
    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

    @JsonbProperty(JSON_APPROVAL_NUMBER)
    private String approvalNumber;

    /**
     * {@link TriennialProgramDto#JSON_APPROVAL_NUMBER}.
     */
    public static final String JSON_APPROVAL_NUMBER = TriennialProgramDto.JSON_APPROVAL_NUMBER;
  }


  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramApprovalRequestDto extends ByIdentifierRequestDto {
    /**
     * Numéro d'approbation.
     */
    @JsonbProperty(JSON_APPROVAL_NUMBER)
    private String approvalNumber;


    /**
     * Date d'approbation Metier {@link TriennialProgramDto}.
     */
    @JsonbProperty(JSON_BUSINESS_APPROVAL_DATE)
    private LocalDate businessApprovalDate;

    /**
     * {@link TriennialProgramDto#JSON_APPROVAL_NUMBER}.
     */
    public static final String JSON_APPROVAL_NUMBER = TriennialProgramDto.JSON_APPROVAL_NUMBER;

    /**
     * {@link TriennialProgramDto#JSON_BUSINESS_APPROVAL_DATE}.
     */
    public static final String JSON_BUSINESS_APPROVAL_DATE =
        TriennialProgramDto.JSON_BUSINESS_APPROVAL_DATE;

  }

  /**
   * Cette classe représente la requête de retour.
   *
   * @author AKM
   */
  @Getter
  @Setter
  class TriennialProgramReturnRequestDto extends ByIdentifierRequestDto {

    /**
     * Raison.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * {@link #reason}.
     */
    public static final String JSON_REASON = "raison";
  }

  /**
   * Cette classe représente la réponse de mise à jour du statut.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramStatusUpdateResponseDto extends IdentifiableResponseDto {

    /**
     * {@link TriennialProgramDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private TriennialProgramStatus status;

    /**
     * {@link TriennialProgramDto#getStatusAsString()}.
     */
    @JsonbProperty(JSON_STATUS_AS_STRING)
    private String statusAsString;

    /**
     * {@link TriennialProgramDto#getStatusReason()}.
     */
    @JsonbProperty(JSON_REASON)
    private String reason;

    /**
     * {@link TriennialProgramDto#getTransmitable()}.
     */
    private Boolean transmitable;

    /**
     * {@link TriennialProgramDto#getAcceptable()}.
     */
    private Boolean acceptable;

    /**
     * {@link TriennialProgramDto#getReturnable()}.
     */
    private Boolean returnable;

    /**
     * {@link TriennialProgramDto#getApprovable()}.
     */
    private Boolean approvable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status         {@link TriennialProgramStatus}
     * @param statusAsString représentation en chaine de caractères de
     *                       {@link TriennialProgramStatus}
     * @param reason         raison
     */
    public void initialize(TriennialProgramStatus status, String statusAsString, String reason) {
      this.status = status;
      this.statusAsString = statusAsString;
      this.reason = reason;
      transmitable = TriennialProgramStatus.TRANSMITTED.getPrevious().contains(status);
      acceptable = TriennialProgramStatus.ACCEPTED.getPrevious().contains(status);
      returnable = TriennialProgramStatus.RETURNED.getPrevious().contains(status);
      approvable = TriennialProgramStatus.APPROVED.getPrevious().contains(status);
    }

    /**
     * {@link TriennialProgramDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = TriennialProgramDto.JSON_STATUS;

    /**
     * {@link TriennialProgramDto#JSON_STATUS_AS_STRING}.
     */
    public static final String JSON_STATUS_AS_STRING = TriennialProgramDto.JSON_STATUS_AS_STRING;

    /**
     * {@link TriennialProgramDto#JSON_STATUS_REASON}.
     */
    public static final String JSON_REASON = TriennialProgramDto.JSON_STATUS_REASON;

    /**
     * {@link TriennialProgramDto#JSON_TRANSMITABLE}.
     */
    public static final String JSON_TRANSMITABLE = TriennialProgramDto.JSON_TRANSMITABLE;

    /**
     * {@link TriennialProgramDto#JSON_ACCEPTABLE}.
     */
    public static final String JSON_ACCEPTABLE = TriennialProgramDto.JSON_ACCEPTABLE;

    /**
     * {@link TriennialProgramDto#JSON_RETURNABLE}.
     */
    public static final String JSON_RETURNABLE = TriennialProgramDto.JSON_RETURNABLE;

    /**
     * {@link TriennialProgramDto#JSON_APPROVABLE}.
     */
    public static final String JSON_APPROVABLE = TriennialProgramDto.JSON_APPROVABLE;
  }

  /**
   * Identifiant du service de transmission.
   */
  String TRANSMIT_IDENTIFIER = "TRANSMISSION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de transmission.
   */
  String TRANSMIT_PATH = "transmission";

  /**
   * Cette méthode permet de transmettre {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response transmit(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'acceptation.
   */
  String ACCEPT_IDENTIFIER = "ACCEPTATION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'acceptation.
   */
  String ACCEPT_PATH = "acceptation";

  /**
   * Cette méthode permet d'accepter {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(ACCEPT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response accept(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'approbation.
   */
  String APPROVE_IDENTIFIER = "APPROBATION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'approbation.
   */
  String APPROVE_PATH = "approbation";

  /**
   * Cette méthode permet d'accepter {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(APPROVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response approve(TriennialProgramApprovalRequestDto request);

  /**
   * Identifiant du service de retour.
   */
  String RETURN_IDENTIFIER = "RETOUR_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de retour.
   */
  String RETURN_PATH = "retour";

  /**
   * Cette méthode permet de retourner {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(RETURN_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response returnBack(TriennialProgramReturnRequestDto request);

  /**
   * Identifiant du service d'initialisation.
   */
  String INITIALIZATION_IDENTIFIER = "INITIALISATION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'initialisation.
   */
  String INITIALIZATION_PATH = "initialisation";

  /**
   * Cette méthode permet d'initialiser le programme triennal {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(INITIALIZATION_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = INITIALIZATION_IDENTIFIER,
      summary = "Initialisation d'un programme " + "triennal",
      description = "Ce service permet d'initialiser un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response initialize(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROGRAMMES_TRIENNAUX";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des programmes triennaux")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = TriennialProgramGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class TriennialProgramGetManyResponseDto
      extends AbstractGetByPageResponseDto<TriennialProgramDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TriennialProgramDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TriennialProgramDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TriennialProgramDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TriennialProgramUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramUpdateRequestDto extends ByIdentifierRequestDto
      implements TriennialProgramSaveRequestDto {
    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
    private String localAuthorityIdentifier;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TriennialProgramDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un programme triennal")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_DOSSIER";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER,
      description = "Ce service permet d'obtenir un graphique")
  Response getChart(GetChartRequestDto request);
}
