package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEffectiveDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementInstanceIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Path(value = MovementService.PATH)
@Tag(name = "Gestion des mouvements")
public interface MovementService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "mouvements";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author A.K.M
   *
   */
  interface MovementSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RemunerableDto}.
     *
     * @return l'identifiant de {@link RemunerableDto}
     */
    String getRemunerableIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link RemunerableDto}.
     *
     * @param remunerableIdentifier l'identifiant de {@link RemunerableDto}
     */
    void setRemunerableIdentifier(String remunerableIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'instance de l'élément de paie.
     *
     * @return l'identifiant de l'instance de l'élément de paie
     */
    String getPayrollElementInstanceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'instance de l'élément de paie.
     *
     * @param payrollElementInstanceIdentifier l'identifiant de l'instance de l'élément de paie
     */
    void setPayrollElementInstanceIdentifier(String payrollElementInstanceIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du type.
     *
     * @return l'identifiant du type
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du type.
     *
     * @param typeIdentifier l'identifiant du type
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir la date d'effet.
     *
     * @return la date d'effet
     */
    LocalDate getEffectiveDate();

    /**
     * Cette méthode permet d'assigner la date d'effet.
     *
     * @param effectiveDate la date d'effet
     */
    void setEffectiveDate(LocalDate effectiveDate);

    /**
     * Cette méthode permet d'obtenir la date d'application.
     *
     * @return la date d'application
     */
    LocalDate getApplicationDate();

    /**
     * Cette méthode permet d'assigner la date d'application.
     *
     * @param applicationDate la date d'application
     */
    void setApplicationDate(LocalDate applicationDate);

    /**
     * {@link HasRemunerableIdentifierDto#JSON_REMUNERABLE_IDENTIFIER}.
     */
    String JSON_REMUNERABLE_IDENTIFIER = HasRemunerableIdentifierDto.JSON_REMUNERABLE_IDENTIFIER;

    /**
     * {@link HasPayrollElementInstanceIdentifierDto#JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER}.
     */
    String JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER =
        HasPayrollElementInstanceIdentifierDto.JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER;

    /**
     * {@link HasTypeIdentifierDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = HasTypeIdentifierDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link HasEffectiveDateDto#JSON_EFFECTIVE_DATE}.
     */
    String JSON_EFFECTIVE_DATE = HasEffectiveDateDto.JSON_EFFECTIVE_DATE;

    /**
     * {@link JSON_APPLICATION_DATE}.
     */
    String JSON_APPLICATION_DATE = "dateApplication";
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MOUVEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MovementCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class MovementCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements MovementSaveRequestDto {

    @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
    private String remunerableIdentifier;

    @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER)
    private String payrollElementInstanceIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_EFFECTIVE_DATE)
    private LocalDate effectiveDate;

    @JsonbProperty(JSON_APPLICATION_DATE)
    private LocalDate applicationDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  public static class MovementGetManyResponseDto extends AbstractGetByPageResponseDto<MovementDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MovementDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MOUVEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MovementDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MOUVEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(MovementUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class MovementUpdateRequestDto extends ByIdentifierRequestDto implements MovementSaveRequestDto {

    @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
    private String remunerableIdentifier;

    @JsonbProperty(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER)
    private String payrollElementInstanceIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_EFFECTIVE_DATE)
    private LocalDate effectiveDate;

    @JsonbProperty(JSON_APPLICATION_DATE)
    private LocalDate applicationDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MOUVEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link MovementDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
