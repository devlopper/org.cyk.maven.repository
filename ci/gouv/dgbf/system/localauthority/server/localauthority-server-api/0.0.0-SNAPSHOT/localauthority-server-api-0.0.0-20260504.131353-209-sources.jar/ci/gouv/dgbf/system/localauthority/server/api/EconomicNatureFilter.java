package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link EconomicNatureDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class EconomicNatureFilter extends AbstractIdentifiableFilter {

  /**
   * {@link ActivityCategory}.
   */
  ActivityCategory activityCategory;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public EconomicNatureFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public EconomicNatureFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    activityCategory = getActivityCategory(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setActivityCategory(filter, activityCategory);
  }

  /**
   * Cette méthode permet d'assigner {@link ActivityCategory}.
   *
   * @param filter           filtre
   * @param activityCategory {@link ActivityCategory}
   */
  public static void setActivityCategory(FilterDto filter, ActivityCategory activityCategory) {
    set(filter, JSON_ACTIVITY_CATEGORY, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(activityCategory));
  }

  /**
   * Cette méthode permet d'obtenir {@link ActivityCategory}.
   *
   * @param filter filtre
   * @return {@link ActivityCategory}
   */
  public static ActivityCategory getActivityCategory(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsEnum(JSON_ACTIVITY_CATEGORY, ActivityCategory.class));
  }

  /**
   * Identifiant json champ {@link EconomicNatureFilter#activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = EconomicNatureDto.JSON_ACTIVITY_CATEGORY;

}
