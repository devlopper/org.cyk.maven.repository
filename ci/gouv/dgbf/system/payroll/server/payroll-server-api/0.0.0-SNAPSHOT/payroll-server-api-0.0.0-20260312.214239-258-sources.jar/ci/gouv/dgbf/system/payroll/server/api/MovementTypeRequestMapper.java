package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.MovementTypeService.MovementTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.MovementTypeService.MovementTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MovementTypeDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link MovementTypeDto}.

    @author stephane
               """)
public interface MovementTypeRequestMapper
    extends RequestMapper<MovementTypeDto, 
            MovementTypeCreateRequestDto, MovementTypeUpdateRequestDto> {

}
