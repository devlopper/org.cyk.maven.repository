package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.system.documentation.client.extension.documenttypegroupfield.DocumentTypeGroupFieldController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de lecture des {@link DocumentTypeGroupFieldDto} d'un
 * {@link DocumentTypeGroupDto}.
 *
 * @author si.kimou
 *
 */
@Named
@ViewScoped
public class DocumentTypeGroupReadFieldsPage extends AbstractDocumentTypeGroupReadDatasPage {

  @Inject
  @Getter
  DocumentTypeGroupFieldController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    controller.getFilterController().getFilter().setTypeGroupIdentifier(instance.getIdentifier());
    controller.initialize();
  }

  /**
   * Identifiant de navigation.
   */
  public static final String OUTCOME = "documentTypeGroupReadFieldsPage";
}
