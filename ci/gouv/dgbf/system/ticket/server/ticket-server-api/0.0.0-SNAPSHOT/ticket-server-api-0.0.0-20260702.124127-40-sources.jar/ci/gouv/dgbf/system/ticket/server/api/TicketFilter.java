package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDomainIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TicketDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TicketFilter extends AbstractIdentifiableFilter
    implements FilterHasStatusCode, FilterHasStatusCodes, FilterHasDomainIdentifier {

  private String statusCode;
  private Set<String> statusCodes;
  private String domainIdentifier;
  private String reporterIdentityIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TicketFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TicketFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
    updateDomainIdentifier(filter);
    reporterIdentityIdentifier = getReporterIdentityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
    updateFilterDomainIdentifier(filter);
    setReporterIdentityIdentifier(filter, reporterIdentityIdentifier);
  }

  /**
   * Cette méthode permet d'assigner.
   *
   * @param filter filtre
   * @param reporterIdentityIdentifier id
   */
  public static void setReporterIdentityIdentifier(FilterDto filter,
                                                   String reporterIdentityIdentifier) {
    set(filter, JSON_REPORTER_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(reporterIdentityIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir.
   *
   * @param filter filtre
   * @return id
   */
  public static String getReporterIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REPORTER_IDENTITY_IDENTIFIER));
  }


  public static final String JSON_REPORTER_IDENTITY_IDENTIFIER = "identifiantIdentiteDeclarant";

}
