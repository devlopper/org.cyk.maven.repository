package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Codes du Statut de Ligne d'Arbitrage.
 *
 * <p>Quinze états. Contrairement au Dossier, qui n'est qu'un conteneur au cycle linéaire, la
 * Ligne porte toute la logique métier : deux origines exclusives, un circuit de visa, un
 * aiguillage, une boucle de report et deux issues terminales — le rejet au traitement et
 * la consolidation.</p>
 *
 * <p>Source : diagrammes d'états du 27/08/2026, annexe 6.2.</p>
 *
 * @author Christian
 *
 */
public class ArbitrationMovementStatusCode {

  private ArbitrationMovementStatusCode() {
  }

  /** Ligne saisie dans la gestion courante de l'exercice. Origine n°1. */
  public static final String CREATED = "CREE";

  /** Ligne produite par la reprise des soldes. Origine n°2 (RG_PRB_ARB_15). */
  public static final String INITIALIZED = "INITIALISE";

  /** Le contrôleur a visé la ligne. */
  public static final String ENDORSED = "VISE";

  /** La ligne n'a pas été visée, ou n'y était pas assujettie. */
  public static final String NOT_ENDORSED = "NON_VISE";

  /**
   * Acheminée vers l'entité de traitement. Point de convergence du cycle : on y arrive du visa
   * comme d'un report (RG_PRB_ARB_19).
   */
  public static final String TRANSMITTED = "TRANSMIS";

  /** Prise en charge par le destinataire ; déclenche l'aiguillage. */
  public static final String RECEIVED = "RECEPTIONNE";

  /**
   * Retenue pour traitement (RG_PRB_ARB_18).
   *
   * <p>L'admission n'est plus une étape du circuit : aucune transition ne mène ici depuis
   * la réception. Le code reste produit, mais par un autre chemin — c'est l'état de
   * naissance des lignes que la DCB ajoute en cours de traitement.</p>
   */
  public static final String ADMITTED = "ADMIS";

  /** Report : la ligne n'est pas rejetée, son traitement attend la levée d'un blocage. */
  public static final String DEFERRED = "DIFFERE";

  /** Le blocage est levé ; la ligne se traite sans nouvelle transmission. */
  public static final String DEFERRED_SATISFIED = "DIFFERE_SATISFAIT";

  /**
   * Envoyée au service chargé de l'exécution (RG_PRB_ARB_21).
   *
   * <p>Plus produit par aucun chemin depuis la révision du 05/10/2026. Le code reste
   * déclaré parce que la base en porte, et qu'un état retiré d'une énumération est un
   * état dont la lecture échouerait.</p>
   */
  public static final String SENT = "ENVOYE";

  /** Le traitement a été accepté ; reste à le faire valider par le chef d'équipe. */
  public static final String PROCESSING_ACCEPTED = "TRAITEMENT_ACCEPTE";

  /** Le traitement a été refusé. Terminal et définitif (RG_PRB_ARB_22, point ouvert O6). */
  public static final String PROCESSING_REJECTED = "TRAITEMENT_REJETE";

  /**
   * Validé — la ligne a franchi l'étape de validation.
   *
   * <p>N'est atteignable que dans un dossier dont le chef d'équipe a validé le traitement.</p>
   */
  public static final String VALIDATED = "VALIDE";

  /** Intégrée aux données consolidées de l'exercice. Terminal. */
  public static final String CONSOLIDATED = "CONSOLIDE";

  /**
   * Traitée mais non intégrée à la consolidation.
   *
   * <p>Non terminal, à la différence du rejet : la mise à l'écart se reprend tant que le
   * dossier n'est pas clos (point ouvert O7).</p>
   */
  public static final String NOT_CONSOLIDATED = "NON_CONSOLIDE";
}
