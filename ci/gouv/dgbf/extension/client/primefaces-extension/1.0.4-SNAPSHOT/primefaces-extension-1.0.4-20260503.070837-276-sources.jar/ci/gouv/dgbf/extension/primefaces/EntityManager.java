package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'entité.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class EntityManager {

  static final String DTO_SUFFIX = "dto";

  Map<Class<?>, Entity> map;

  /**
   * Cette méthode permet d'obtenir une entité.
   *
   * @param entityClass classe de l'entité
   * @return nom du dossier
   */
  public Entity getEntity(Class<?> entityClass) {
    Core.doThrowIfNull(IllegalArgumentException.class, "Classe de l'entité est requise",
        entityClass);
    if (map().containsKey(entityClass)) {
      return map().get(entityClass);
    }
    Entity entity = new Entity();
    entity.rootFolderName = "/private";
    entity.folderName = buildFolderName(entityClass.getSimpleName());
    map().put(entityClass, entity);
    return entity;
  }

  /**
   * Cette méthode permet d'obtenir le map non nul.
   *
   * @return map non nul
   */
  public Map<Class<?>, Entity> map() {
    if (map == null) {
      map = new HashMap<>();
    }
    return map;
  }

  String buildFolderName(String name) {
    name = name.toLowerCase();
    if (name.endsWith(DTO_SUFFIX)) {
      name = name.substring(0, name.length() - DTO_SUFFIX.length());
    }
    return name;
  }

  public String formatEntityFormPath(Class<?> entityClass, String fileName) {
    return getEntity(entityClass).formatFormPath(fileName);
  }

  /**
   * Cette classe représente une entité.
   *
   * @author Christian
   *
   */
  @Getter
  public static class Entity {
    String rootFolderName;
    String folderName;

    Entity() {}

    /**
     * Cette méthode permet de formatter un chemin.
     *
     * @param format format
     * @return chemin
     */
    public String formatPath(String format) {
      return Optional.ofNullable(Core.getOrNullifyIfStringBlank(format))
          .map(value -> String.format(format, rootFolderName, folderName)).orElse(null);
    }

    public String formatFormPath(String fileName) {
      return formatPath("%s/%s/component/" + fileName + ".xhtml");
    }
  }
}
