package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône de {@link ProcessingStatus}.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class ProcessingStatusIconManager {

  String late;
  String startWaiting;
  String running;
  String done;
  
  /**
   * Cette méthode permet d'instancier.
   */
  public ProcessingStatusIconManager() {
    late = "pi pi-tag";
    startWaiting = "pi pi-briefcase";
    running = "pi pi-money-bill";
    done = "pi pi-check";
  }
}
