package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-14T11:12:41+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentationRequestMapperImpl implements DocumentationRequestMapper {

    @Override
    public DocumentationService.DocumentationCreateRequestDto mapCreate(DocumentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentationService.DocumentationCreateRequestDto documentationCreateRequestDto = new DocumentationService.DocumentationCreateRequestDto();

        documentationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentationCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        documentationCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        documentationCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        documentationCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        documentationCreateRequestDto.setText( arg0.getText() );
        documentationCreateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return documentationCreateRequestDto;
    }

    @Override
    public DocumentationService.DocumentationUpdateRequestDto mapUpdate(DocumentationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentationService.DocumentationUpdateRequestDto documentationUpdateRequestDto = new DocumentationService.DocumentationUpdateRequestDto();

        documentationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        documentationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentationUpdateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        documentationUpdateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        documentationUpdateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        documentationUpdateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        documentationUpdateRequestDto.setText( arg0.getText() );
        documentationUpdateRequestDto.setFilesGroupIdentifier( arg0.getFilesGroupIdentifier() );

        return documentationUpdateRequestDto;
    }
}
