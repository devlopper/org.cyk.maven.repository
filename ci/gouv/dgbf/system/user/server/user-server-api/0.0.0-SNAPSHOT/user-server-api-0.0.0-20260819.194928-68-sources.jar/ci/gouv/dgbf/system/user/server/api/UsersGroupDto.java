package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasModuleAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine.
 *
 * @author kimou
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UsersGroupDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasModuleIdentifierDto, HasModuleAsStringDto {

  /**
   * Identifiant du module propriétaire.
   */
  @JsonbProperty(JSON_MODULE_IDENTIFIER)
  private String moduleIdentifier;

  /**
   * Représentation en chaine de caractères du module propriétaire.
   */
  @JsonbProperty(JSON_MODULE_AS_STRING)
  private String moduleAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupeUtilisateurs";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupeUtilisateursChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe utilisateur";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes utilisateurs";
}
