package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasChartCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetIsDefault;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetAdministrativeUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class BudgetAdministrativeUnitFilter extends AbstractIdentifiableFilter
    implements FilterHasBudgetIdentifier, FilterHasBudgetIsDefault,
    FilterHasAdministrativeUnitIdentifier, FilterHasChartCode {

  String budgetIdentifier;
  Boolean budgetIsDefault;

  String administrativeUnitIdentifier;
  String chartCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetAdministrativeUnitFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetAdministrativeUnitFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetIdentifier(filter);
    updateBudgetIsDefault(filter);
    updateAdministrativeUnitIdentifier(filter);
    updateChartCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetIdentifier(filter);
    updateFilterBudgetIsDefault(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    updateFilterChartCode(filter);
  }
}

