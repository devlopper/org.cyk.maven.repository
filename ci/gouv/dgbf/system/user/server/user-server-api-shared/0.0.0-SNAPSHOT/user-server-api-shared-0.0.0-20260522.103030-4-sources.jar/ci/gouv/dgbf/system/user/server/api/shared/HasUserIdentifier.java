package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'utilisateur.
 *
 * @author Christian
 */
public interface HasUserIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur.
   *
   * @return identifiant de l'utilisateur
   */
  String getUserIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur.
   *
   * @param userIdentifier identifiant de l'utilisateur
   */
  void setUserIdentifier(String userIdentifier);

  /**
   * Identifiant java de l'identifiant de l'utilisateur.
   */
  String FIELD_USER_IDENTIFIER = "userIdentifier";
}
