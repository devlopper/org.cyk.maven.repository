package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente un contrôleur de d'entrée de booléen.
 *
 * @author Christian
 *
 */
@Dependent
public class SelectBooleanController extends AbstractInputController {

  /* Controls */

  protected SelectOneRadioBoolean selectOneRadioBoolean;
  protected SelectOneBooleanButton selectOneBooleanButton;

  /*------------------------------ Select One Radio ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link SelectOneRadioBoolean}.
   *
   * @return {@link SelectOneRadioBoolean}
   */
  public SelectOneRadioBoolean getSelectOneRadioBoolean() {
    if (!initialized) {
      Core.runIfNull(selectOneRadioBoolean,
          () -> selectOneRadioBoolean = instantiateSelectOneRadioBoolean());
      initialized = true;
    }
    return selectOneRadioBoolean;
  }

  protected SelectOneRadioBoolean instantiateSelectOneRadioBoolean() {
    SelectOneRadioBoolean select = new SelectOneRadioBoolean();
    processSelectOneRadioBoolean(select);
    processOutputLabel(select.outputLabel());
    return select;
  }

  protected void processSelectOneRadioBoolean(SelectOneRadioBoolean selectOneRadioBoolean) {
    processInput(selectOneRadioBoolean);
  }

  /*------------------------------ Input Local Date Time ------------------------------*/

  /**
   * Cette méthode permet d'obtenir {@link SelectOneBooleanButton}.
   *
   * @return {@link SelectOneBooleanButton}
   */
  public SelectOneBooleanButton getSelectOneBooleanButton() {
    if (!initialized) {
      Core.runIfNull(selectOneBooleanButton,
          () -> selectOneBooleanButton = instantiateSelectOneBooleanButton());
      initialized = true;
    }
    return selectOneBooleanButton;
  }

  protected SelectOneBooleanButton instantiateSelectOneBooleanButton() {
    SelectOneBooleanButton select = new SelectOneBooleanButton();
    processSelectOneBooleanButton(select);
    processOutputLabel(select.outputLabel());
    return select;
  }

  protected void processSelectOneBooleanButton(SelectOneBooleanButton selectOneBooleanButton) {
    processInput(selectOneBooleanButton);
  }

}
