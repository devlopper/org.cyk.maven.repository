package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExerciseService.ProgrammingExerciseCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingExerciseService.ProgrammingExerciseUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingExerciseDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingExerciseDto}.

    @author Christian
               """)
public interface ProgrammingExerciseRequestMapper
    extends RequestMapper<ProgrammingExerciseDto, ProgrammingExerciseCreateRequestDto,
        ProgrammingExerciseUpdateRequestDto> {

}
