package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion d'identifiant d'équipe support.
 *
 * @author Arnaud
 */
public interface HasSupportTeamIdentifierDto extends HasSupportTeamIdentifier {

  /**
   * Identifiant json de l'identifiant de l'équipe support.
   */
  String JSON_SUPPORT_TEAM_IDENTIFIER = "idEquipeSupport";
}
