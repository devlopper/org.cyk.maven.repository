package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskGetManyResponseDto;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskUpdateFileManageableWhenTerminatedRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TaskService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TaskClient extends AbstractClient<TaskService>
    implements GetByIdentifier<TaskDto>, GetMany<TaskGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto>, GetChart<GetChartResponseDto> {

  @Override
  public TaskClient service(TaskService service) {
    return (TaskClient) super.service(service);
  }

  /**
   * {@link TaskService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(TaskCreateRequestDto request) {
    return new CreateExecutor(TaskService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TaskService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public TaskGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<TaskGetManyResponseDto>(TaskGetManyResponseDto.class,
        TaskService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link TaskService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TaskGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TaskService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TaskDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TaskDto>(TaskDto.class, TaskService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link TaskService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TaskDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TaskService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public TaskDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TaskDto>(TaskDto.class, TaskService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TaskService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TaskDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TaskService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(TaskUpdateRequestDto request) {
    return new IdentifiableExecutor(TaskService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TaskService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TaskService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link TaskService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link TaskService#updateFileManageableWhenTerminated}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateFileManageableWhenTerminated(
      TaskUpdateFileManageableWhenTerminatedRequestDto request) {
    return new IdentifiableExecutor(TaskService.UPDATE_FILE_MANAGEABLE_WHEN_TERMINATED_IDENTIFIER)
        .execute(() -> service().updateFileManageableWhenTerminated(request));
  }

  /**
   * {@link TaskService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        TaskService.GET_CHART_IDENTIFIER).execute(() -> service().getChart(request));
  }
  
  /**
   * {@link TaskService#getChart}.
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditWho, String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getChart(request);
  }
}
