package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une situation de mouvement.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementTrackingDto extends AbstractIdentifiableAuditableDto {

  /**
   * Date d'effet.
   */
  @JsonbProperty(JSON_EFFECT_DATE)
  private LocalDate effectDate;

  /**
   * Représentation en chaine de caractères de {@link #effectDate}.
   */
  @JsonbProperty(JSON_EFFECT_DATE_AS_STRING)
  private String effectDateAsString;

  /**
   * Date de prise en compte.
   */
  @JsonbProperty(JSON_DATE_TAKEN_IN_COUNTS)
  private LocalDate dateTakeInCounts;

  /**
   * Représentation en chaine de caractères de {@link #dateTakeInCounts}.
   */
  @JsonbProperty(JSON_DATE_TAKEN_IN_COUNTS_AS_STRING)
  private String dateTakeInCountsAsString;

  /**
   * Date de rappel.
   */
  @JsonbProperty(JSON_DATE_REMINDER)
  private LocalDate dateReminder;

  /**
   * Représentation en chaine de caractères de {@link #dateReminder}.
   */
  @JsonbProperty(JSON_DATE_REMINDER_AS_STRING)
  private String dateReminderAsString;

  /**
   * {@link MovementStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private MovementStatus status;

  /**
   * Représentation en chaine de caractères de {@link MovementStatus}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSuiviMouvement";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "suiviMouvementChaine";

  /**
   * Identifiant json champ {@link #effectDate}.
   */
  public static final String JSON_EFFECT_DATE = "dateEffet";

  /**
   * Identifiant json champ {@link #effectDateAsString}.
   */
  public static final String JSON_EFFECT_DATE_AS_STRING = "dateEffetChaine";

  /**
   * Identifiant json champ {@link #dateTakeInCounts}.
   */
  public static final String JSON_DATE_TAKEN_IN_COUNTS = "datePriseEnCompte";

  /**
   * Identifiant json champ {@link #dateTakeInCountsAsString}.
   */
  public static final String JSON_DATE_TAKEN_IN_COUNTS_AS_STRING = "datePriseEnCompteChaine";

  /**
   * Identifiant json champ {@link #dateReminder}.
   */
  public static final String JSON_DATE_REMINDER = "dateRappel";

  /**
   * Identifiant json champ {@link #dateReminderAsString}.
   */
  public static final String JSON_DATE_REMINDER_AS_STRING = "dateRappelChaine";

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "suivi mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "suivis mouvements";
}
