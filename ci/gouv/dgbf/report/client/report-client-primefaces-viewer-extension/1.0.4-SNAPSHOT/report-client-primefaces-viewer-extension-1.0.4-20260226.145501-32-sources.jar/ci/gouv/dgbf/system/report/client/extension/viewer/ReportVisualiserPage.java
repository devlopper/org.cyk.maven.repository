package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.GetBytesByIdentifierRequestDto;
import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpServletRequest;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la page du visualisateur de rapport.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class ReportVisualiserPage {

  @Getter
  @Setter
  String fileType;

  @Getter
  String url;

  @Inject
  HttpServletRequest request;

  @Inject
  StringHelper stringHelper;

  ViewerUriBuilder viewerUriBuilder;

  @Getter
  boolean optionable;

  @PostConstruct
  void postConstruct() {
    viewerUriBuilder = new ViewerUriBuilder();
    viewerUriBuilder.reportIdentifier(request.getParameter(ByIdentifierRequestDto.JSON_IDENTIFIER));

    setParameters(viewerUriBuilder);

    fileType = request.getParameter(GetBytesByIdentifierRequestDto.JSON_FILE_TYPE);
    viewerUriBuilder.fileType(fileType);
    viewerUriBuilder.auditWho(request.getParameter(AbstractRequestDto.JSON_AUDIT_WHO));
    viewerUriBuilder
        .auditSession(request.getParameter(AbstractAuditedRequestJsonDto.JSON_AUDIT_SESSION));
    optionable =
        Boolean.valueOf(request.getParameter(ViewerUriBuilder.QUERY_PARAMETER_CUSTOMISABLE));
    viewerUriBuilder.customisable(Boolean.FALSE);
  }

  void setParameters(ViewerUriBuilder viewerUriBuilder) {
    String parametersAsJson = request.getParameter(GetBytesByIdentifierRequestDto.JSON_PARAMETERS);
    if (parametersAsJson != null) {
      parametersAsJson = URLDecoder.decode(parametersAsJson, StandardCharsets.UTF_8);
      viewerUriBuilder.reportParametersAsJson(parametersAsJson);
    }
  }

  /**
   * Cette méthode permet d'appliquer les paramètres.
   *
   */
  public void applyParameters() {
    if (stringHelper.isBlank(fileType)) {
      throw new IllegalArgumentException("Veuillez sélectionner le type de fichier");
    }
    viewerUriBuilder.fileType(fileType);
    url = viewerUriBuilder.build().toString();
  }
}
