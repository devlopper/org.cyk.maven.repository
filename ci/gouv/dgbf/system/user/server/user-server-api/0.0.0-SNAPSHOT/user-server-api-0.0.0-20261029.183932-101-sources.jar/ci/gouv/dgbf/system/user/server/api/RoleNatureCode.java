package ci.gouv.dgbf.system.user.server.api;

/**
 * Cette classe représente les codes de {@link RoleNature}.
 *
 * @author Christian
 */
public class RoleNatureCode {

  private RoleNatureCode() {

  }

  /**
   * Applicatif.
   */
  public static final String APPLICATION_ROLE = "APPLICATIF";

  /**
   * Métier.
   */
  public static final String BUSINESS_ROLE = "METIER";
}
