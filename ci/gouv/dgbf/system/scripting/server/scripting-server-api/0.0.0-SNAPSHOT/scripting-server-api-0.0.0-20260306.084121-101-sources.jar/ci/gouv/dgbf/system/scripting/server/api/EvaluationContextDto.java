package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;

/**
 * Cette classe représente un contexte d'évaluation.
 *
 * @author Christian
 */
public class EvaluationContextDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idContexteEvaluation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "contexteEvaluationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "contexte d'évaluation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "contextes d'évaluation";
}
