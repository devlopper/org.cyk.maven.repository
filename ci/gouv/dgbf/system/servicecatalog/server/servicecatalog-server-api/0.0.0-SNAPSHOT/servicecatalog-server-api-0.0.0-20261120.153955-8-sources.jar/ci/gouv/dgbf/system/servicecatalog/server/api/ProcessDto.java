package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un processus, composant technique déployé d'un Module (le backend ou
 * l'un de ses frontends).
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcessDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasVisibleDto, HasModuleIdentifierDto, HasModuleAsStringDto {

  /**
   * Description du processus.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Nature du processus, valeur du référentiel {@code TR_NATURE_PROCESSUS}.
   */
  @JsonbProperty(JSON_NATURE)
  private ProcessNature nature;

  /**
   * URL de base, adresse d'entrée du processus.
   */
  @JsonbProperty(JSON_BASE_URL)
  private String baseUrl;

  /**
   * Indique si le processus est présenté à tous les utilisateurs authentifiés dans le
   * catalogue. Faux par défaut.
   */
  @JsonbProperty(JSON_VISIBLE)
  private Boolean visible;

  /**
   * Accès public du processus : utilisable sans connexion et présenté dans le Portail public
   * (RG_SVC_VIS_04), faux par défaut.
   */
  @JsonbProperty(JSON_PUBLIC_ACCESS)
  private Boolean publicAccess;

  /**
   * Identifiant du Module auquel ce processus est obligatoirement rattaché.
   */
  @JsonbProperty(JSON_MODULE_IDENTIFIER)
  private String moduleIdentifier;

  /**
   * Libellé du Module auquel ce processus est rattaché.
   */
  @JsonbProperty(JSON_MODULE_AS_STRING)
  private String moduleAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER =
      HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER;

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = HasProcessAsStringDto.JSON_PROCESS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "processus";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "processus";

  /**
   * Identifiant json pour {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json pour {@link #baseUrl}.
   */
  public static final String JSON_BASE_URL = "urlDeBase";

  /**
   * Identifiant json pour {@link #publicAccess}.
   */
  public static final String JSON_PUBLIC_ACCESS = "accesPublic";
}
