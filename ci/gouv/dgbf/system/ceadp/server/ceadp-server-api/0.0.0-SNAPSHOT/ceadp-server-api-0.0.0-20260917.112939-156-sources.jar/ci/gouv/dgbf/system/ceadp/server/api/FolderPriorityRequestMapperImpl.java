package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FolderPriorityDto}.
*
* @author Dahoud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FolderPriorityRequestMapperImpl implements FolderPriorityRequestMapper {

    @Override
    public FolderPriorityService.FolderPriorityCreateRequestDto mapCreate(FolderPriorityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderPriorityService.FolderPriorityCreateRequestDto folderPriorityCreateRequestDto = new FolderPriorityService.FolderPriorityCreateRequestDto();

        folderPriorityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderPriorityCreateRequestDto.setCode( arg0.getCode() );
        folderPriorityCreateRequestDto.setName( arg0.getName() );

        return folderPriorityCreateRequestDto;
    }

    @Override
    public FolderPriorityService.FolderPriorityUpdateRequestDto mapUpdate(FolderPriorityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FolderPriorityService.FolderPriorityUpdateRequestDto folderPriorityUpdateRequestDto = new FolderPriorityService.FolderPriorityUpdateRequestDto();

        folderPriorityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        folderPriorityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        folderPriorityUpdateRequestDto.setCode( arg0.getCode() );
        folderPriorityUpdateRequestDto.setName( arg0.getName() );

        return folderPriorityUpdateRequestDto;
    }
}
