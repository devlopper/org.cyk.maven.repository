package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupportTeamExpertiseDto}.
*
* @author Kimou
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-18T08:18:19+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupportTeamExpertiseRequestMapperImpl implements SupportTeamExpertiseRequestMapper {

    @Override
    public SupportTeamExpertiseService.SupportTeamExpertiseCreateRequestDto mapCreate(SupportTeamExpertiseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamExpertiseService.SupportTeamExpertiseCreateRequestDto supportTeamExpertiseCreateRequestDto = new SupportTeamExpertiseService.SupportTeamExpertiseCreateRequestDto();

        supportTeamExpertiseCreateRequestDto.setSupportTeamIdentifier( arg0.getSupportTeamIdentifier() );
        supportTeamExpertiseCreateRequestDto.setFunctionalDomainIdentifier( arg0.getFunctionalDomainIdentifier() );
        supportTeamExpertiseCreateRequestDto.setSupportLevelIdentifier( arg0.getSupportLevelIdentifier() );

        return supportTeamExpertiseCreateRequestDto;
    }

    @Override
    public SupportTeamExpertiseService.SupportTeamExpertiseUpdateRequestDto mapUpdate(SupportTeamExpertiseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamExpertiseService.SupportTeamExpertiseUpdateRequestDto supportTeamExpertiseUpdateRequestDto = new SupportTeamExpertiseService.SupportTeamExpertiseUpdateRequestDto();

        supportTeamExpertiseUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportTeamExpertiseUpdateRequestDto.setSupportTeamIdentifier( arg0.getSupportTeamIdentifier() );
        supportTeamExpertiseUpdateRequestDto.setFunctionalDomainIdentifier( arg0.getFunctionalDomainIdentifier() );
        supportTeamExpertiseUpdateRequestDto.setSupportLevelIdentifier( arg0.getSupportLevelIdentifier() );

        return supportTeamExpertiseUpdateRequestDto;
    }
}
