package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une unité de section.
 *
 * @author stephane
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SectionUnitDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant {@link SectionDto}.
   */
  @JsonbProperty(JSON_SECTION_IDENTIFIER)
  private String sectionIdentifier;

  /**
   * Représentation en chaine de caractères de {@link SectionDto}.
   */
  @JsonbProperty(JSON_SECTION_AS_STRING)
  private String sectionAsString;
  
  /**
   * Identifiant {@link SectionUnitDto} parent.
   */
  @JsonbProperty(JSON_PARENT_IDENTIFIER)
  private String parentIdentifier;

  /**
   * Représentation en chaine de caractères de {@link SectionUnitDto} parent.
   */
  @JsonbProperty(JSON_PARENT_AS_STRING)
  private String parentAsString;
  
  /**
   * Identifiant json de identifiant de {@link SectionUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUniteSection";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link SectionUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "uniteSectionChaine";

  /**
   * Identifiant json champ {@link #sectionIdentifier}.
   */
  public static final String JSON_SECTION_IDENTIFIER = SectionDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #sectionAsString}.
   */
  public static final String JSON_SECTION_AS_STRING = SectionDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json champ {@link #parentIdentifier}.
   */
  public static final String JSON_PARENT_IDENTIFIER = "idParent";

  /**
   * Identifiant json champ {@link #parentAsString}.
   */
  public static final String JSON_PARENT_AS_STRING = "parentChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "unité de section";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "unités de section";
}
