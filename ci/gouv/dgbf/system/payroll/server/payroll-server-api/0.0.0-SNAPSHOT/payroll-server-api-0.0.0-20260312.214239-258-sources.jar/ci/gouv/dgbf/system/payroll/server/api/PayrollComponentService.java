package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIsEvaluableInSecondaryContextDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollComponentDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = PayrollComponentService.PATH)
@Tag(name = "Gestion des postes de paie")
public interface PayrollComponentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "postes-paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface PayrollComponentSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir vrai si c'est un gain sinon faux.
     *
     * @return vrai si c'est un gain sinon faux
     */
    Boolean getIsEarning();

    /**
     * Cette méthode permet d'assigner vrai si c'est un gain sinon faux.
     *
     * @param isEarning vrai si c'est un gain sinon faux
     */
    void setIsEarning(Boolean isEarning);

    /**
     * Cette méthode permet d'obtenir vrai si c'est taxable sinon faux.
     *
     * @return vrai si c'est taxable sinon faux
     */
    Boolean getIsTaxable();

    /**
     * Cette méthode permet d'assigner vrai si c'est taxable sinon faux.
     *
     * @param isTaxable vrai si c'est taxable sinon faux
     */
    void setIsTaxable(Boolean isTaxable);

    /**
     * Cette méthode permet d'obtenir vrai si c'est pensionnable sinon faux.
     *
     * @return vrai si c'est pensionnable sinon faux
     */
    Boolean getIsPensionable();

    /**
     * Cette méthode permet d'assigner vrai si c'est pensionnable sinon faux.
     *
     * @param isPensionable vrai si c'est pensionnable sinon faux
     */
    void setIsPensionable(Boolean isPensionable);

    /**
     * Cette méthode permet d'obtenir vrai si c'est cumulable au net sinon faux.
     *
     * @return vrai si c'est cumulable au net sinon faux
     */
    Boolean getIsNetCumulable();

    /**
     * Cette méthode permet d'assigner vrai si c'est cumulable au net sinon faux.
     *
     * @param isNetCumulable vrai si c'est cumulable au net sinon faux
     */
    void setIsNetCumulable(Boolean isNetCumulable);

    /**
     * Cette méthode permet d'obtenir si évalué dans le contexte secondaire.
     *
     * @return si évalué dans le contexte secondaire
     */
    Boolean getIsEvaluableInSecondaryContext();

    /**
     * Cette méthode permet d'assigner si évalué dans le contexte secondaire.
     *
     * @param isEvaluableInSecondaryContext si évalué dans le contexte secondaire
     */
    void setIsEvaluableInSecondaryContext(Boolean isEvaluableInSecondaryContext);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la formule de calcul employé.
     *
     * @return identifiant de la formule de calcul employé
     */
    String getEmployeeCalculationFormulaIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la formule de calcul employé.
     *
     * @param employeeCalculationFormulaIdentifier identifiant de la formule de calcul employé
     */
    void setEmployeeCalculationFormulaIdentifier(String employeeCalculationFormulaIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la formule de calcul employeur.
     *
     * @return identifiant de la formule de calcul employeur
     */
    String getEmployerCalculationFormulaIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la formule de calcul employeur.
     *
     * @param employerCalculationFormulaIdentifier identifiant de la formule de calcul employeur
     */
    void setEmployerCalculationFormulaIdentifier(String employerCalculationFormulaIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la catégorie de poste de paie.
     *
     * @return identifiant de la catégorie de poste de paie
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la catégorie de poste de paie.
     *
     * @param categoryIdentifier identifiant de la catégorie de poste de paie
     */
    void setCategoryIdentifier(String categoryIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la nature de poste de paie.
     *
     * @return identifiant de la nature de poste de paie
     */
    String getNatureIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la nature de poste de paie.
     *
     * @param natureIdentifier identifiant de la nature de poste de paie
     */
    void setNatureIdentifier(String natureIdentifier);

    /**
     * {@link PayrollComponentDto#JSON_IS_EARNING}.
     */
    String JSON_IS_EARNING = PayrollComponentDto.JSON_IS_EARNING;

    /**
     * {@link PayrollComponentDto#JSON_IS_TAXABLE}.
     */
    String JSON_IS_TAXABLE = PayrollComponentDto.JSON_IS_TAXABLE;

    /**
     * {@link PayrollComponentDto#JSON_IS_PENSIONABLE}.
     */
    String JSON_IS_PENSIONABLE = PayrollComponentDto.JSON_IS_PENSIONABLE;

    /**
     * {@link PayrollComponentDto#JSON_IS_NET_CUMULABLE}.
     */
    String JSON_IS_NET_CUMULABLE = PayrollComponentDto.JSON_IS_NET_CUMULABLE;

    /**
     * {@link HasIsEvaluableInSecondaryContextDto#JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT}.
     */
    String JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT =
        HasIsEvaluableInSecondaryContextDto.JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT;

    /**
     * {@link PayrollComponentDto#JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER}.
     */
    String JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER =
        PayrollComponentDto.JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER;

    /**
     * {@link PayrollComponentDto#JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER}.
     */
    String JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER =
        PayrollComponentDto.JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER;

    /**
     * {@link PayrollComponentDto#JSON_CATEGORY_IDENTIFIER}.
     */
    String JSON_CATEGORY_IDENTIFIER = PayrollComponentDto.JSON_CATEGORY_IDENTIFIER;

    /**
     * {@link PayrollComponentDto#JSON_NATURE_IDENTIFIER}.
     */
    String JSON_NATURE_IDENTIFIER = PayrollComponentDto.JSON_NATURE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_POSTE_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollComponentCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollComponentCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PayrollComponentSaveRequestDto {

    @JsonbProperty(JSON_IS_EARNING)
    private Boolean isEarning;

    @JsonbProperty(JSON_IS_TAXABLE)
    private Boolean isTaxable;

    @JsonbProperty(JSON_IS_PENSIONABLE)
    private Boolean isPensionable;

    @JsonbProperty(JSON_IS_NET_CUMULABLE)
    private Boolean isNetCumulable;

    @JsonbProperty(JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER)
    private String employeeCalculationFormulaIdentifier;

    @JsonbProperty(JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER)
    private String employerCalculationFormulaIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;
    
    @JsonbProperty(JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT)
    private Boolean isEvaluableInSecondaryContext;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayrollComponentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class PayrollComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollComponentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollComponentDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_POSTE_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollComponentUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollComponentUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PayrollComponentSaveRequestDto {
    @JsonbProperty(JSON_IS_EARNING)
    private Boolean isEarning;

    @JsonbProperty(JSON_IS_TAXABLE)
    private Boolean isTaxable;

    @JsonbProperty(JSON_IS_PENSIONABLE)
    private Boolean isPensionable;

    @JsonbProperty(JSON_IS_NET_CUMULABLE)
    private Boolean isNetCumulable;

    @JsonbProperty(JSON_EMPLOYEE_CALCULATION_FORMULA_IDENTIFIER)
    private String employeeCalculationFormulaIdentifier;

    @JsonbProperty(JSON_EMPLOYER_CALCULATION_FORMULA_IDENTIFIER)
    private String employerCalculationFormulaIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_NATURE_IDENTIFIER)
    private String natureIdentifier;
    
    @JsonbProperty(JSON_IS_EVALUABLE_IN_SECONDARY_CONTEXT)
    private Boolean isEvaluableInSecondaryContext;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_POSTE_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
