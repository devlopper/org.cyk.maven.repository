package ci.gouv.dgbf.system.budgetaryclassification.client.extension.act;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AbstractExpenditureOrResourceItemDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link ExpenditureItemDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ExpenditureItemFilterController
    extends AbstractFilterController<ExpenditureItemFilter> {

  public ExpenditureItemFilterController() {
    super(ExpenditureItemFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setExerciseIdentifier(
        getRequestParameter(AbstractExpenditureOrResourceItemDto.JSON_EXERCISE_IDENTIFIER));

    filterStringifier = filter -> String.format("Exo %s", filter.getExerciseIdentifier());
  }
}
