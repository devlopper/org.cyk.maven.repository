package ci.gouv.dgbf.system.file.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FileGroupCategoryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-12T12:52:31+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FileGroupCategoryRequestMapperImpl implements FileGroupCategoryRequestMapper {

    @Override
    public FileGroupCategoryService.FileGroupCategoryCreateRequestDto mapCreate(FileGroupCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileGroupCategoryService.FileGroupCategoryCreateRequestDto fileGroupCategoryCreateRequestDto = new FileGroupCategoryService.FileGroupCategoryCreateRequestDto();

        fileGroupCategoryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileGroupCategoryCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        fileGroupCategoryCreateRequestDto.setFileGroupIdentifier( arg0.getFileGroupIdentifier() );
        fileGroupCategoryCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return fileGroupCategoryCreateRequestDto;
    }

    @Override
    public FileGroupCategoryService.FileGroupCategoryUpdateRequestDto mapUpdate(FileGroupCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileGroupCategoryService.FileGroupCategoryUpdateRequestDto fileGroupCategoryUpdateRequestDto = new FileGroupCategoryService.FileGroupCategoryUpdateRequestDto();

        fileGroupCategoryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileGroupCategoryUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        fileGroupCategoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fileGroupCategoryUpdateRequestDto.setFileGroupIdentifier( arg0.getFileGroupIdentifier() );
        fileGroupCategoryUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return fileGroupCategoryUpdateRequestDto;
    }
}
