package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.segregation.HasSearchTextDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de texte de recherche de filtre.
 *
 * @author Christian
 */
@Dependent
public class FilterSearchTextController extends AbstractController {

  @Getter
  InputTextController inputTextController;

  HasSearchTextDto filter;

  /**
   * Cette méthode permet de construire.
   *
   * @param inputTextController {@link InputTextController}
   */
  @Inject
  public FilterSearchTextController(InputTextController inputTextController) {
    this.inputTextController = inputTextController;
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   * @param filter filtre
   */
  public void initialize(HasSearchTextDto filter) {
    this.filter = filter;
    inputTextController.setOutputLableValue("Texte de recherche");
    inputTextController.getInputText().addValueConsumer(filter::setSearchText);
  }

}
