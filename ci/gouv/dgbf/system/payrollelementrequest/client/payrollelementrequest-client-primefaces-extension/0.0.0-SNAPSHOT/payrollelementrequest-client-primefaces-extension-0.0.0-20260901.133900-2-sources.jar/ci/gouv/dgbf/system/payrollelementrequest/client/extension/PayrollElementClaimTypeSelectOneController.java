package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimTypeService.PayrollElementClaimTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollElementClaimTypeDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementClaimTypeSelectOneController
    extends AbstractSelectOneIdentifiableController<PayrollElementClaimTypeDto,
        PayrollElementClaimTypeGetManyResponseDto, PayrollElementClaimTypeClient> {

  @Getter
  @Inject
  PayrollElementClaimTypeClient client;

  protected PayrollElementClaimTypeSelectOneController() {
    super(PayrollElementClaimTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
