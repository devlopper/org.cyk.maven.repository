package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.ZoneService.ZoneCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.ZoneService.ZoneUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ZoneDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ZoneDto}.

    @author akm
               """)
public interface ZoneRequestMapper extends RequestMapper<ZoneDto,
    ZoneCreateRequestDto, ZoneUpdateRequestDto> {

}
