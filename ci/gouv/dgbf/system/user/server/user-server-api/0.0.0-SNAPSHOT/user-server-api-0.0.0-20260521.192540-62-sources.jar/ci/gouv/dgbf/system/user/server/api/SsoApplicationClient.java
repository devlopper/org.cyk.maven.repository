package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.SsoApplicationService.SsoApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.SsoApplicationService.SsoApplicationGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.SsoApplicationService.SsoApplicationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SsoApplicationService}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SsoApplicationClient extends AbstractClient<SsoApplicationService>
    implements GetByIdentifier<SsoApplicationDto>, GetMany<SsoApplicationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SsoApplicationClient service(SsoApplicationService service) {
    return (SsoApplicationClient) super.service(service);
  }

  /**
   * {@link SsoApplicationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SsoApplicationCreateRequestDto request) {
    return new CreateExecutor(SsoApplicationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }


  /**
   * {@link SsoApplicationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SsoApplicationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SsoApplicationGetManyResponseDto>(
        SsoApplicationGetManyResponseDto.class,
        SsoApplicationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SsoApplicationService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SsoApplicationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                                  PageDto page,
                                                  String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SsoApplicationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SsoApplicationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SsoApplicationDto>(SsoApplicationDto.class,
        SsoApplicationService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link SsoApplicationService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SsoApplicationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                                  String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SsoApplicationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SsoApplicationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SsoApplicationDto>(SsoApplicationDto.class,
        SsoApplicationService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SsoApplicationService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SsoApplicationDto getByIdentifier(String identifier, ProjectionDto projection,
                                           String auditWho,
                                           String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SsoApplicationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SsoApplicationUpdateRequestDto request) {
    return new IdentifiableExecutor(SsoApplicationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SsoApplicationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SsoApplicationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SsoApplicationService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
  /**
   * {@link SsoApplicationService#doImport}.
   *
   * @param request requête
   * @return réponse
   */

  public IdentifiableResponseDto doImport(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(SsoApplicationService.IMPORT_IDENTIFIER)
        .execute(() -> service().doImport(request));
  }
}
