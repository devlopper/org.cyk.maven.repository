package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ReimbursementScheduleDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-29T18:07:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ReimbursementScheduleRequestMapperImpl implements ReimbursementScheduleRequestMapper {

    @Override
    public ReimbursementScheduleService.ReimbursementScheduleCreateRequestDto mapCreate(ReimbursementScheduleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReimbursementScheduleService.ReimbursementScheduleCreateRequestDto reimbursementScheduleCreateRequestDto = new ReimbursementScheduleService.ReimbursementScheduleCreateRequestDto();

        reimbursementScheduleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        reimbursementScheduleCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        reimbursementScheduleCreateRequestDto.setIdentifier( arg0.getIdentifier() );
        reimbursementScheduleCreateRequestDto.setExpenditureSettlementIdentifier( arg0.getExpenditureSettlementIdentifier() );
        reimbursementScheduleCreateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        if ( arg0.getReimbursedAmount() != null ) {
            reimbursementScheduleCreateRequestDto.setReimbursedAmount( arg0.getReimbursedAmount() );
        }
        if ( arg0.getAmount1() != null ) {
            reimbursementScheduleCreateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            reimbursementScheduleCreateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            reimbursementScheduleCreateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return reimbursementScheduleCreateRequestDto;
    }

    @Override
    public ReimbursementScheduleService.ReimbursementScheduleUpdateRequestDto mapUpdate(ReimbursementScheduleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReimbursementScheduleService.ReimbursementScheduleUpdateRequestDto reimbursementScheduleUpdateRequestDto = new ReimbursementScheduleService.ReimbursementScheduleUpdateRequestDto();

        reimbursementScheduleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        reimbursementScheduleUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        reimbursementScheduleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        reimbursementScheduleUpdateRequestDto.setExpenditureSettlementIdentifier( arg0.getExpenditureSettlementIdentifier() );
        reimbursementScheduleUpdateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );
        if ( arg0.getReimbursedAmount() != null ) {
            reimbursementScheduleUpdateRequestDto.setReimbursedAmount( arg0.getReimbursedAmount() );
        }
        if ( arg0.getAmount1() != null ) {
            reimbursementScheduleUpdateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            reimbursementScheduleUpdateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            reimbursementScheduleUpdateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return reimbursementScheduleUpdateRequestDto;
    }
}
