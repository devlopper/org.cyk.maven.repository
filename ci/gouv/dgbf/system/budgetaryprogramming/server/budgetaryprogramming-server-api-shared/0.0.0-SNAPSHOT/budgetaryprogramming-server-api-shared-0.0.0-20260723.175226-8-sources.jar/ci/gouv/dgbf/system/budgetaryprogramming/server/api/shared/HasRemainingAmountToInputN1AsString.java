package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à saisir pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToInputN1AsString {

  /**
   * Obtient le montant restant à saisir pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant restant à saisir pour l'année N+1 sous forme de chaîne de caractères
   */
  String getRemainingAmountToInputN1AsString();

  /**
   * Définit le montant restant à saisir pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToInputN1AsString le montant restant à saisir pour l'année N+1 sous
   *        forme de chaîne de caractères
   */
  void setRemainingAmountToInputN1AsString(String remainingAmountToInputN1AsString);

  /**
   * Identifiant java du montant restant à saisir pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_INPUT_N1_AS_STRING =
      "remainingAmountToInputN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName