package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionService.PolicyVersionCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionService.PolicyVersionGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PolicyVersionDto}.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
public class PolicyVersionClient extends AbstractClient<PolicyVersionService>
    implements GetByIdentifier<PolicyVersionDto>, GetMany<PolicyVersionGetManyResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link PolicyVersionService}
   * @return client {@link PolicyVersionClient}
   */
  @Override
  public PolicyVersionClient service(PolicyVersionService service) {
    return (PolicyVersionClient) super.service(service);
  }

  /**
   * {@link PolicyVersionService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PolicyVersionCreateRequestDto request) {
    return new CreateExecutor(PolicyVersionService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PolicyVersionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PolicyVersionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PolicyVersionGetManyResponseDto>(
        PolicyVersionGetManyResponseDto.class,
        PolicyVersionService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PolicyVersionService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PolicyVersionGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PolicyVersionService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PolicyVersionDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<PolicyVersionDto>(PolicyVersionDto.class,
        PolicyVersionService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link PolicyVersionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PolicyVersionDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<PolicyVersionDto>(PolicyVersionDto.class,
        PolicyVersionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }
}
