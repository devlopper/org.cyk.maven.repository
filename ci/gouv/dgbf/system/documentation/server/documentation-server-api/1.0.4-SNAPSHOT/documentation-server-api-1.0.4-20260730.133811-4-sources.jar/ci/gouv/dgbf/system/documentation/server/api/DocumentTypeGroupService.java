package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 */
@Path(value = DocumentTypeGroupService.PATH)
@Tag(name = "Gestion des Groupes de Type de Document")
public interface DocumentTypeGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-type-document";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface DocumentTypeGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant du type de document.
     *
     * @return identifiant du type de document
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du type de document.
     *
     * @param typeIdentifier identifiant du type de document
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant du groupe de type de document.
     *
     * @return identifiant du groupe de type de document
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du groupe de type de document.
     *
     * @param groupIdentifier identifiant du groupe de type de document
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * {@link DocumentTypeGroupDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = DocumentTypeGroupDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link DocumentTypeGroupDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = DocumentTypeGroupDto.JSON_GROUP_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link DocumentTypeGroupDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de création unitaire de {@link DocumentTypeGroupDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DocumentTypeGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link DocumentTypeGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentTypeGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DocumentTypeGroupSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link DocumentTypeGroupDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link DocumentTypeGroupDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link DocumentTypeGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class DocumentTypeGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<DocumentTypeGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DocumentTypeGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link DocumentTypeGroupDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention unitaire de {@link DocumentTypeGroupDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link DocumentTypeGroupDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link DocumentTypeGroupDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link DocumentTypeGroupDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de mise à jour unitaire de {@link DocumentTypeGroupDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  Response update(DocumentTypeGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link DocumentTypeGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentTypeGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DocumentTypeGroupSaveRequestDto {

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link DocumentTypeGroupDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_TYPE_DOCUMENT";

  /**
   * Chemin du service de suppression unitaire de {@link DocumentTypeGroupDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link DocumentTypeGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  Response delete(DeleteOneRequestDto request);
}
