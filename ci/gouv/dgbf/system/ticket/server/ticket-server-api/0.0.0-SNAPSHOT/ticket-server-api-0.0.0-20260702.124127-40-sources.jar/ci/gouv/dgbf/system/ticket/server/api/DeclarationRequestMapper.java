package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationCreateIncidentRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DeclarationDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DeclarationDto}.

    @author Arnaud
               """)
public interface DeclarationRequestMapper
    extends RequestMapper<DeclarationDto, DeclarationCreateRequestDto,
     DeclarationUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link DeclarationCreateRequestDto}.
   *
   * @param declaration {@link DeclarationCreateRequestDto}
   * @return {@link DeclarationCreateRequestDto}
   */
  DeclarationCreateIncidentRequestDto mapCreateIncident(DeclarationDto declaration);
  
}
