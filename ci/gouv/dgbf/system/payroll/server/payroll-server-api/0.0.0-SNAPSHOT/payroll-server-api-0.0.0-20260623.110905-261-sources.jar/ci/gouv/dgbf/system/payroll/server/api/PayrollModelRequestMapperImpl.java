package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollModelDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T11:09:39+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollModelRequestMapperImpl implements PayrollModelRequestMapper {

    @Override
    public PayrollModelService.PayrollModelCreateRequestDto mapCreate(PayrollModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollModelService.PayrollModelCreateRequestDto payrollModelCreateRequestDto = new PayrollModelService.PayrollModelCreateRequestDto();

        payrollModelCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollModelCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollModelCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        payrollModelCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollModelCreateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );

        return payrollModelCreateRequestDto;
    }

    @Override
    public PayrollModelService.PayrollModelUpdateRequestDto mapUpdate(PayrollModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollModelService.PayrollModelUpdateRequestDto payrollModelUpdateRequestDto = new PayrollModelService.PayrollModelUpdateRequestDto();

        payrollModelUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollModelUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollModelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollModelUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        payrollModelUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollModelUpdateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );

        return payrollModelUpdateRequestDto;
    }
}
