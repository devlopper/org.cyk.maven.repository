package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base de page de liste de {@link ResourceDto} de {@link SharingDto} de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public abstract class AbstractConnectedUserSharedResourceListPage extends AbstractPage {

  @Inject
  @Getter
  ResourceController controller;

  @Inject
  SharingSessionController sessionController;
  
  @Inject
  ResourceClient resourceClient;
  
  /**
   * Cette méthode permet de construire.
   */
  protected AbstractConnectedUserSharedResourceListPage() {
    contentTitle = "Liste de mes %s".formatted(resourceName());
    title = contentTitle;
  }

  @Override
  protected void prepareContent() {
    super.prepareContent();

    prepareFilterController();

    controller.initialize();

    controller.getListController().getDataTable().getFilterButton().setRendered(false);
    controller.getListController().getDataTable().setHeaderRendered(false);
    controller.getListController().getDataTable().getActionsOutputPanel().setRendered(false);
    
    sessionController.storeFirstAdministrativeUnitResource();
    redirectIfUrlNotBlank();
  }

  /**
   * Cette méthode permet de préparer {@link ResourceFilterController}.
   */
  protected void prepareFilterController() {
    controller.getFilterController().getFilter().setUserName(userIdentifier);
    controller.getFilterController().getFilter().setType(resourceType());
    controller.getFilterController().getFilter().setLocation(resourceLocation());
  }

  abstract String resourceName();

  abstract ResourceType resourceType();

  abstract Location resourceLocation();
}
