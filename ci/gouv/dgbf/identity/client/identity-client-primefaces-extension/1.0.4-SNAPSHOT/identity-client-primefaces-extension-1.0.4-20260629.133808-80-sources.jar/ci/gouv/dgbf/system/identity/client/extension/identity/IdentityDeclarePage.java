package ci.gouv.dgbf.system.identity.client.extension.identity;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.NavigationManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputsGroupController;
import ci.gouv.dgbf.extension.server.service.api.filter.EmailAddressFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityService;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityDeclareRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityDeclareResponseDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import java.net.URI;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import lombok.Getter;

/**
 * Cette classe représente la page de {@link IdentityService#DECLARE_IDENTIFIER}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class IdentityDeclarePage extends AbstractPage {

  @Inject
  IdentityClient client;

  IdentityDto identity;

  @Inject
  IdentityRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController firstNameInputTextController;

  @Inject
  @Getter
  InputTextController lastNamesInputTextController;

  @Inject
  @Getter
  InputTextController emailAddressInputTextController;

  @Inject
  @Getter
  InputsGroupController inputsGroupController;

  @Getter
  Button submitCommandButton;

  @Inject
  NavigationManager navigationManager;

  URI baseUri;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Déclaration d'une identité";
    identity = new IdentityDto();

    firstNameInputTextController.setOutputLableValue("Nom");
    firstNameInputTextController.getInputText().addValueConsumer(firstNameConsumer());
    firstNameInputTextController.getInputText().setRequired(true);

    lastNamesInputTextController.setOutputLableValue("Prénom(s)");
    lastNamesInputTextController.getInputText().addValueConsumer(lastNamesConsumer());
    lastNamesInputTextController.getInputText().setRequired(true);

    emailAddressInputTextController.setOutputLableValue("Adresse email");
    emailAddressInputTextController.getInputText().addValueConsumer(emailAddressConsumer());
    emailAddressInputTextController.getInputText().setRequired(true);

    inputsGroupController.add(firstNameInputTextController.getInputText(),
        lastNamesInputTextController.getInputText(),
        emailAddressInputTextController.getInputText());

    submitCommandButton = new Button();
    submitCommandButton.setValue("Enregistrer");
    submitCommandButton.setIcon("pi pi-save");
    submitCommandButton.addUpdates(inputsGroupController.getComaSeparatedMessagesIdentifiers());
    submitCommandButton.setActionFunction(this::declare);

    baseUri = requestManager.buildBaseUri();
  }

  Consumer<String> firstNameConsumer() {
    return value -> identity.setFirstName(value);
  }

  Consumer<String> lastNamesConsumer() {
    return value -> identity.setLastNames(value);
  }

  Consumer<String> emailAddressConsumer() {
    return value -> identity.setEmailAddress(value);
  }

  String declare(Object argument) {
    new ActionExecutor<>(this, "Déclaration", this::declare).execute();
    return null;
  }

  IdentityDeclareResponseDto declare() {
    IdentityDeclareRequestDto request = requestMapper.mapDeclare(identity);
    request.setFrontEndBaseUri(baseUri.toString());
    request
        .setAuditWho(Core.getOrDefaultIfBlank(userIdentifier, IdentityService.DECLARE_IDENTIFIER));
    IdentityDeclareResponseDto response = client.declare(request);
    navigationManager.navigate(IdentityDeclareSuccessPage.OUTCOME,
        Map.of(EmailAddressFilter.JSON_KEY, List.of(response.getMaskedEmailAddress())));
    return response;
  }

  public static final String OUTCOME = "identityDeclarePage";
}
