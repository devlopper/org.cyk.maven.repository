package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayslipDto} (écran « Contrôle global »).
 * Concept en lecture seule dérivée : rapprochement Solde AN 2000 ↔ CALO.
 *
 * @author desysoft
 *
 */
@Path(value = PayslipService.PATH)
@Tag(name = "Gestion des bulletins de paie")
public interface PayslipService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "bulletins-paie";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de
   * plusieurs.
   *
   * @author desysoft
   *
   */
  @Getter
  @Setter
  public static class PayslipGetManyResponseDto extends AbstractGetByPageResponseDto<PayslipDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayslipDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de comptage.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_BULLETIN_PAIE";

  /**
   * Chemin du service de comptage.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le nombre de bulletins correspondant au filtre.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service d'obtention de la synthèse.
   */
  String GET_SUMMARY_IDENTIFIER = "OBTENTION_SYNTHESE_BULLETIN_PAIE";

  /**
   * Chemin du service d'obtention de la synthèse.
   */
  String GET_SUMMARY_PATH = "obtention/synthese";

  /**
   * Cette méthode permet d'obtenir les indicateurs de synthèse (RG_RAP_CTR_10) du résultat
   * correspondant au filtre, calculés sur l'intégralité du résultat, pas seulement la page
   * affichée.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_SUMMARY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_SUMMARY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayslipSummaryDto.class))})
  Response getSummary(GetCountRequestDto request);

  /**
   * Identifiant du service de rafraîchissement.
   */
  String REFRESH_IDENTIFIER = "RAFRAICHISSEMENT_BULLETIN_PAIE";

  /**
   * Chemin du service de rafraîchissement.
   */
  String REFRESH_PATH = "rejeu";

  /**
   * Cette méthode permet de rafraîchir les bulletins de paie pour un exercice et une période
   * donnés.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REFRESH_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = REFRESH_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = String.class))})
  Response refresh(PayslipRefreshRequestDto request);

  /**
   * Cette classe représente la requête de rafraîchissement.
   *
   * @author desysoft
   *
   */
  @Getter
  @Setter
  class PayslipRefreshRequestDto extends AbstractAuditedRequestJsonDto {

    @JsonbProperty(JSON_FISCAL_YEAR)
    private String fiscalYear;

    @JsonbProperty(JSON_PERIOD)
    private Integer period;

    /**
     * Identifiant json champ {@link #fiscalYear}.
     */
    public static final String JSON_FISCAL_YEAR = PayslipDto.JSON_FISCAL_YEAR;

    /**
     * Identifiant json champ {@link #period}.
     */
    public static final String JSON_PERIOD = PayslipDto.JSON_PERIOD;
  }

}
