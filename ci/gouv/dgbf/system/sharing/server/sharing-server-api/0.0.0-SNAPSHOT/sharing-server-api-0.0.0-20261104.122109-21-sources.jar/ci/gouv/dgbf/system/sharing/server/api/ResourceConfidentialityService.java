package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

/** CRUD REST de la confidentialité propre à une ressource. */
@Path(ResourceConfidentialityService.PATH)
public interface ResourceConfidentialityService extends SpecificService {

  String PATH = "ressource-confidentialite";
  String JSON_RESOURCE_IDENTIFIER = ResourceConfidentialityDto.JSON_RESOURCE_IDENTIFIER;
  String JSON_CONFIDENTIALITY_LEVEL = ResourceConfidentialityDto.JSON_CONFIDENTIALITY_LEVEL;

  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response create(ResourceConfidentialityCreateRequestDto request);

  @POST
  @Path("obtention/plusieurs")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getMany(GetManyRequestDto request);

  @POST
  @Path("obtention/un")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getOne(GetOneRequestDto request);

  @POST
  @Path("obtention/par-identifiant")
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response update(ResourceConfidentialityUpdateRequestDto request);

  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  Response delete(DeleteOneRequestDto request);

  /** Champs communs aux requêtes d'enregistrement. */
  interface SaveRequest {
    String getResourceIdentifier();

    void setResourceIdentifier(String value);

    ConfidentialityLevel getConfidentialityLevel();

    void setConfidentialityLevel(ConfidentialityLevel value);
  }

  /** Requête de création. */
  @Getter
  @Setter
  class ResourceConfidentialityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements SaveRequest {
    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;
    @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL)
    private ConfidentialityLevel confidentialityLevel;
  }

  /** Requête de mise à jour. */
  @Getter
  @Setter
  class ResourceConfidentialityUpdateRequestDto extends ByIdentifierRequestDto
      implements SaveRequest {
    @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
    private String resourceIdentifier;
    @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL)
    private ConfidentialityLevel confidentialityLevel;
  }

  /** Réponse paginée. */
  @Getter
  @Setter
  class ResourceConfidentialityGetManyResponseDto
      extends AbstractGetByPageResponseDto<ResourceConfidentialityDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ResourceConfidentialityDto> datas;
  }
}
