package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.BeneficiaryService.BeneficiaryCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.BeneficiaryService.BeneficiaryGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.BeneficiaryService.BeneficiaryUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link BeneficiaryService}.
 *
 * @author Christian
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BeneficiaryClient extends AbstractClient<BeneficiaryService>
    implements GetByIdentifier<BeneficiaryDto>, GetMany<BeneficiaryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public BeneficiaryClient service(BeneficiaryService service) {
    return (BeneficiaryClient) super.service(service);
  }

  /**
   * {@link BeneficiaryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(BeneficiaryCreateRequestDto request) {
    return new CreateExecutor(BeneficiaryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link BeneficiaryService#create}.
   *
   * @param code         code
   * @param name         nom
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    BeneficiaryCreateRequestDto request = new BeneficiaryCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link BeneficiaryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public BeneficiaryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<BeneficiaryGetManyResponseDto>(BeneficiaryGetManyResponseDto.class,
        BeneficiaryService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link BeneficiaryService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BeneficiaryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                            PageDto page,
                                            String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BeneficiaryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BeneficiaryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BeneficiaryDto>(BeneficiaryDto.class,
        BeneficiaryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link BeneficiaryService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BeneficiaryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                            String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BeneficiaryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public BeneficiaryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BeneficiaryDto>(BeneficiaryDto.class,
        BeneficiaryService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BeneficiaryService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BeneficiaryDto getByIdentifier(String identifier, ProjectionDto projection,
                                     String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link BeneficiaryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(BeneficiaryUpdateRequestDto request) {
    return new IdentifiableExecutor(BeneficiaryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link BeneficiaryService#update}.
   *
   * @param identifier   identifiant
   * @param name         nom
   * @param code         code
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
                                        String auditWho, String auditSession) {
    BeneficiaryUpdateRequestDto request = new BeneficiaryUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link BeneficiaryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(BeneficiaryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link BeneficiaryService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

