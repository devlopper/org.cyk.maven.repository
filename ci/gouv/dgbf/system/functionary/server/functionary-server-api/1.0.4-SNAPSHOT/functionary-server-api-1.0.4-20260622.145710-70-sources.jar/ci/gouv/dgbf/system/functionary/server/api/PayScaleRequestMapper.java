package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService.PayScaleCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.PayScaleService.PayScaleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayScaleDto}.
 *
 * @author Arnaud 
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayScaleDto}.

    @author AKM
               """)
public interface PayScaleRequestMapper
    extends RequestMapper<PayScaleDto, PayScaleCreateRequestDto, PayScaleUpdateRequestDto> {

}
