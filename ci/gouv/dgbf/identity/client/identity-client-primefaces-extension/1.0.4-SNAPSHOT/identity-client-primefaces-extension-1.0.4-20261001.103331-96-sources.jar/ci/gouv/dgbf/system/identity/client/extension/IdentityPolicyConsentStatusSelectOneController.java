package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentStatus;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link IdentityPolicyConsentStatus},
 * utilisé pour filtrer les consentements par statut.
 *
 * @author desysoft
 *
 */
@Dependent
public class IdentityPolicyConsentStatusSelectOneController
    extends AbstractSelectOneEnumerationController<IdentityPolicyConsentStatus> {

  protected IdentityPolicyConsentStatusSelectOneController() {
    super(IdentityPolicyConsentStatus.values());
    outputLableValue = "Statut";
  }

  @Override
  protected String computeSelectItemLabel(IdentityPolicyConsentStatus status) {
    return status.getName();
  }
}
