package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeFromDate;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasLocalDateTimeToDate;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre du tableau de bord du module Fichier (RG_FILE_UI_05) :
 * un seul sélecteur de période (bornes {@link #getFromDate()}/{@link #getToDate()}), des
 * filtres distincts module/Propriétaire/Groupe de fichiers/statut, et le code du graphique
 * demandé ({@link FileDashboardChartCode}). Le module/Propriétaire/Groupe réutilisent les
 * clés déjà définies par {@link FileFilter}, sans redéfinition.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileDashboardFilter extends AbstractFilter
    implements FilterHasLocalDateTimeFromDate, FilterHasLocalDateTimeToDate, FilterHasStatusCode {

  /**
   * {@link FileDto#getOwnerIdentifier()}.
   */
  String ownerIdentifier;

  /**
   * {@link FileDto#getModuleIdentifier()}.
   */
  String moduleIdentifier;

  /**
   * {@link FileGroupDto#getIdentifier()}.
   */
  String groupIdentifier;

  /**
   * Code de statut (interprété selon le graphique demandé).
   */
  String statusCode;

  /**
   * Borne de début de la période (sélecteur unique du tableau de bord, RG_FILE_UI_05).
   */
  LocalDateTime fromDate;

  /**
   * Borne de fin de la période.
   */
  LocalDateTime toDate;

  /**
   * Code du graphique demandé, voir {@link FileDashboardChartCode}.
   */
  String chartCode;

  /**
   * Cette méthode permet de construire une instance.
   *
   * @param filter filtre
   */
  public FileDashboardFilter(FilterDto filter) {
    super(filter);
  }

  /**
   * Cette méthode permet de construire une instance.
   */
  public FileDashboardFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    ownerIdentifier = FileFilter.getOwnerIdentifier(filter);
    moduleIdentifier = FileFilter.getModuleIdentifier(filter);
    groupIdentifier = FileFilter.getGroupIdentifier(filter);
    updateStatusCode(filter);
    updateFromDate(filter);
    updateToDate(filter);
    chartCode = getChartCode(filter);
  }

  @Override
  public FilterDto toDto() {
    FilterDto filter = new FilterDto();
    FileFilter.setOwnerIdentifier(filter, ownerIdentifier);
    FileFilter.setModuleIdentifier(filter, moduleIdentifier);
    FileFilter.setGroupIdentifier(filter, groupIdentifier);
    updateFilterStatusCode(filter);
    updateFilterFromDate(filter);
    updateFilterToDate(filter);
    setChartCode(filter, chartCode);
    return filter;
  }

  /**
   * Cette méthode permet d'obtenir le code du graphique demandé.
   *
   * @param filter filtre
   * @return code du graphique
   */
  public static String getChartCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CHART_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code du graphique demandé.
   *
   * @param filter filtre
   * @param chartCode code du graphique
   */
  public static void setChartCode(FilterDto filter, String chartCode) {
    set(filter, JSON_CHART_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(chartCode));
  }

  public static final String JSON_CHART_CODE = "codeGraphique";
}
