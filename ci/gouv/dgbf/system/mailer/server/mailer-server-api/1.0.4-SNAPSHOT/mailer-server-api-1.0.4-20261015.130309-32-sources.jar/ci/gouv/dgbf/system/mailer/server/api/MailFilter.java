package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les mails.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MailFilter extends AbstractIdentifiableFilter {

}
