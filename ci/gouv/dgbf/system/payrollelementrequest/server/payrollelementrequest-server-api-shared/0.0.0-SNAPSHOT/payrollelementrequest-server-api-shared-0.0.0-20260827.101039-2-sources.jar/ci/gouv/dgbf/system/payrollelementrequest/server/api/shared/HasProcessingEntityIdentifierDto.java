package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'entité traitante.
 *
 * @author akm
 *
 */
public interface HasProcessingEntityIdentifierDto {

  /**
   * Identifiant json de l'identifiant de l'entité traitante.
   */
  String JSON_PROCESSING_ENTITY_IDENTIFIER = "idEntiteTraitante";

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'entité traitante.
   *
   * @return identifiant de l'entité traitante
   */
  String getProcessingEntityIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'entité traitante.
   *
   * @param processingEntityIdentifier identifiant de l'entité traitante
   */
  void setProcessingEntityIdentifier(String processingEntityIdentifier);
}
