package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN {

  /**
   * Obtient le montant total à arbitrer pour l'année N.
   *
   * @return le montant total à arbitrer pour l'année N
   */
  Long getTotalAmountToArbitrateN();

  /**
   * Définit le montant total à arbitrer pour l'année N.
   *
   * @param totalAmountToArbitrateN le montant total à arbitrer pour l'année N
   */
  void setTotalAmountToArbitrateN(Long totalAmountToArbitrateN);
  
  /**
   * Identifiant json du montant total à arbitrer pour l'année N.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N = "totalAmountToArbitrateN";
}
