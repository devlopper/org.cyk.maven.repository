package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.model.charts.ChartData;
import org.primefaces.model.charts.ChartDataSet;
import org.primefaces.model.charts.axes.cartesian.CartesianScales;
import org.primefaces.model.charts.axes.cartesian.linear.CartesianLinearAxes;
import org.primefaces.model.charts.bar.BarChartDataSet;
import org.primefaces.model.charts.bar.BarChartModel;
import org.primefaces.model.charts.bar.BarChartOptions;

/**
 * Cette classe représente un histogramme.
 *
 * @author Christian
 *
 */
public class BarChart extends AbstractChart<BarChartModel> {

  public BarChart() {
    contentFilePath = Constant.SLASH + "extension/component/chart/bar/default.xhtml";
  }

  /**
   * Cette classe représentente un constructeur de modèle.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class ModelBuilder
      extends AbstractModelBuilder<BarChartModel, BarChartOptions, BarChart> {

    Boolean stacked;

    @Override
    ChartDataSet instantiateCharDataSet(ChartDataSetDto dto, int dtosCount,
        AtomicInteger dtoIndex) {
      BarChartDataSet chartDataSet = new BarChartDataSet();
      chartDataSet.setLabel(dto.getName());
      chartDataSet.setData(dto.getDatasNumbers());
      styleDataSet(chartDataSet, chartDataSet::setBackgroundColor, chartDataSet::setBorderColor,
          dtosCount, dtoIndex);
      return chartDataSet;
    }

    @Override
    BarChartModel instantateModel() {
      return new BarChartModel();
    }

    @Override
    void processModel(BarChartModel model, ChartData chartData) {
      model.setData(chartData);
    }

    @Override
    BarChartOptions instantateOptions() {
      return new BarChartOptions();
    }

    @Override
    void processOptions(BarChartModel model, ChartData chartData, BarChartOptions options) {
      model.setOptions(options);
      configureStacked(options);
    }

    void styleDataSet(BarChartDataSet barChartDataSet, Consumer<Object> backgroundColorConsumer,
        Consumer<Object> borderColorConsumer, Integer counts, AtomicInteger index) {
      consumeDataSetBackgroundAndBorderColors(backgroundColorConsumer, borderColorConsumer, counts,
          index);
      barChartDataSet.setBorderWidth(1);
    }

    void consumeDataSetBackgroundAndBorderColors(Consumer<Object> backgroundColorConsumer,
        Consumer<Object> borderColorConsumer, Integer counts, AtomicInteger index) {
      if (counts == 1) {
        backgroundColorConsumer.accept(colorPalette.getRgbaList());
        borderColorConsumer.accept(colorPalette.getRgbList());
      } else {
        backgroundColorConsumer.accept(colorPalette.getRgbaAt(index.intValue()));
        borderColorConsumer.accept(colorPalette.getRgbAt(index.intValue()));
      }
    }

    void configureStacked(BarChartOptions options) {
      if (Core.isTrue(stacked)) {
        CartesianScales cartesianScales = new CartesianScales();
        CartesianLinearAxes cartesianLinearAxes = new CartesianLinearAxes();
        cartesianLinearAxes.setStacked(true);
        cartesianLinearAxes.setOffset(true);
        cartesianScales.addXAxesData(cartesianLinearAxes);
        options.setScales(cartesianScales);
      }
    }
  }

  /**
   * Cette méthode permet de créer et d'obtenir {@link Builder}.
   *
   * @return {@link Builder}
   */
  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représentente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder
      extends AbstractBuilder<BarChartModel, BarChartOptions, ModelBuilder, BarChart> {

    @Override
    protected BarChart instantiateWidget() {
      return new BarChart();
    }
  }
}
