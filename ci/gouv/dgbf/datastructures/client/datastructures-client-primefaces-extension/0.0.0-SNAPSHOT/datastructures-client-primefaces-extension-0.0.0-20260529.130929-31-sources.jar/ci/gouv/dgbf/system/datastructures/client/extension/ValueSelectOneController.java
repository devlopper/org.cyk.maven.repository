package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueClient;
import ci.gouv.dgbf.system.datastructures.server.api.ValueDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueService.ValueGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueSelectOneController extends AbstractSelectOneIdentifiableController<
    ValueDto, ValueGetManyResponseDto, ValueClient> {

  @Getter
  @Inject
  ValueClient client;

  /**
   * Cette méthode permet de contruire.
   */
  protected ValueSelectOneController() {
    super(ValueDto.class, SelectItemLabelStrategy.NAME);
  }
}
