package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipTemplateComponentDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipTemplateComponentRequestMapperImpl implements PayslipTemplateComponentRequestMapper {

    @Override
    public PayslipTemplateComponentService.PayslipTemplateComponentCreateRequestDto mapCreate(PayslipTemplateComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTemplateComponentService.PayslipTemplateComponentCreateRequestDto payslipTemplateComponentCreateRequestDto = new PayslipTemplateComponentService.PayslipTemplateComponentCreateRequestDto();

        payslipTemplateComponentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTemplateComponentCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipTemplateComponentCreateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );
        payslipTemplateComponentCreateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payslipTemplateComponentCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipTemplateComponentCreateRequestDto;
    }

    @Override
    public PayslipTemplateComponentService.PayslipTemplateComponentUpdateRequestDto mapUpdate(PayslipTemplateComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTemplateComponentService.PayslipTemplateComponentUpdateRequestDto payslipTemplateComponentUpdateRequestDto = new PayslipTemplateComponentService.PayslipTemplateComponentUpdateRequestDto();

        payslipTemplateComponentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTemplateComponentUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipTemplateComponentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipTemplateComponentUpdateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payslipTemplateComponentUpdateRequestDto.setPayslipTemplateIdentifier( arg0.getPayslipTemplateIdentifier() );
        payslipTemplateComponentUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipTemplateComponentUpdateRequestDto;
    }
}
