package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollJobGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollJobGroupRequestMapperImpl implements PayrollJobGroupRequestMapper {

    @Override
    public PayrollJobGroupService.PayrollJobGroupCreateRequestDto mapCreate(PayrollJobGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobGroupService.PayrollJobGroupCreateRequestDto payrollJobGroupCreateRequestDto = new PayrollJobGroupService.PayrollJobGroupCreateRequestDto();

        payrollJobGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollJobGroupCreateRequestDto.setCode( arg0.getCode() );
        payrollJobGroupCreateRequestDto.setName( arg0.getName() );
        payrollJobGroupCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollJobGroupCreateRequestDto.setPayScaleIdentifier( arg0.getPayScaleIdentifier() );

        return payrollJobGroupCreateRequestDto;
    }

    @Override
    public PayrollJobGroupService.PayrollJobGroupUpdateRequestDto mapUpdate(PayrollJobGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollJobGroupService.PayrollJobGroupUpdateRequestDto payrollJobGroupUpdateRequestDto = new PayrollJobGroupService.PayrollJobGroupUpdateRequestDto();

        payrollJobGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollJobGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollJobGroupUpdateRequestDto.setCode( arg0.getCode() );
        payrollJobGroupUpdateRequestDto.setName( arg0.getName() );
        payrollJobGroupUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollJobGroupUpdateRequestDto.setPayScaleIdentifier( arg0.getPayScaleIdentifier() );

        return payrollJobGroupUpdateRequestDto;
    }
}
