package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.ContentForm;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.OwnerDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du bouton d'ouverture du visualisateur, piloté par la
 * forme du contenu (RG_FILE_FIC_18, spec-api § 9.6). Pour un fichier binaire, ouvre la
 * visionneuse d'octets ; pour un fichier descriptif, ouvre la fiche descriptive HTML.
 *
 * @author Christian
 *
 */
@Dependent
public class OpenFileViewerButtonController extends AbstractController {

  @Getter
  @Setter
  String title;

  @Getter
  @Setter
  String type;

  @Getter
  @Setter
  String icon;

  @Getter
  @Setter
  String onClick;

  @Getter
  @Setter
  String styleClass;

  @Getter
  @Inject
  OpenFileViewerParametersDialogController parametersDialogController;

  @Getter
  @Inject
  FileDescriptiveSheetDialogController descriptiveSheetDialogController;

  @Inject
  FileViewerUriBuilder viewerUriBuilder;

  @Inject
  FileClient fileClient;

  /**
   * Cette méthode permet de construire une instance.
   */
  public OpenFileViewerButtonController() {
    title = "Voir";
    icon = "pi pi-eye";
    type = "submit";
  }

  /**
   * Ouvrir le visualisateur ou la fiche descriptive selon la forme du contenu.
   *
   * @param identifier identifiant
   * @param ownerIdentifier identifiant {@link OwnerDto}
   */
  public void open(String identifier, String ownerIdentifier) {
    open(identifier, ownerIdentifier, null);
  }

  /**
   * Ouvrir le visualisateur ou la fiche descriptive selon la forme du contenu spécifiée.
   *
   * @param identifier identifiant
   * @param ownerIdentifier identifiant {@link OwnerDto}
   * @param contentForm forme du contenu (déduite si null)
   */
  public void open(String identifier, String ownerIdentifier, ContentForm contentForm) {
    ContentForm form = contentForm;
    if (form == null) {
      FileDto file = fileClient == null ? null : fileClient.getByIdentifier(identifier,
          new ProjectionDto().addNames(FileDto.JSON_CONTENT_FORM), userIdentifier, null);
      form = file != null && file.getContentForm() != null ? file.getContentForm()
          : ContentForm.BINARY;
    }
    if (ContentForm.DESCRIPTIVE.equals(form)) {
      descriptiveSheetDialogController.open(identifier);
    } else {
      parametersDialogController.viewerOpenerConsumer =
          opener -> opener.getScriptBuilder().setUriSupplier(() -> viewerUriBuilder
              .build(identifier, ownerIdentifier, ContentForm.BINARY, userIdentifier, null));
      parametersDialogController.open();
    }
  }
}
