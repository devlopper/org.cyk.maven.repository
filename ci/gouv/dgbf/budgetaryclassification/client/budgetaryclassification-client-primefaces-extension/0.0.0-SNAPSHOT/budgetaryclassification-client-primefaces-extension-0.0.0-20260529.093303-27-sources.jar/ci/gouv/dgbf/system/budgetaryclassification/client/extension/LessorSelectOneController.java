package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link LessorDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class LessorSelectOneController extends AbstractSelectOneIdentifiableController<
    LessorDto, LessorGetManyResponseDto, LessorClient> {

  @Inject
  @Getter
  LessorClient client;

  protected LessorSelectOneController() {
    super(LessorDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
