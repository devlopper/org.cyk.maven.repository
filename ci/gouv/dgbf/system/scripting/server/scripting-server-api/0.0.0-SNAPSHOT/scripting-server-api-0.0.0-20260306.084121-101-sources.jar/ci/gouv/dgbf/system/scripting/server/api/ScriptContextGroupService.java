package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasMaxValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMinValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasMultiplierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.EvaluateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.EvaluateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.math.BigDecimal;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ScriptContextGroupDto}.
 *
 * @author Arnaud
 *
 */
@Path(value = ScriptContextGroupService.PATH)
@Tag(name = "Gestion des groupes de contextes de scripts")
public interface ScriptContextGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-contextes-scripts";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author arnaud
   */
  interface ScriptContextGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le multiplicateur.
     *
     * @return le multiplicateur
     */
    BigDecimal getMultiplier();

    /**
     * Cette méthode permet d'assigner le multiplicateur.
     *
     * @param multiplier le multiplicateur
     */
    void setMultiplier(BigDecimal multiplier);
    
    /**
     * Cette méthode permet d'obtenir la valeur minimale.
     *
     * @return la valeur minimale
     */
    Integer getMinValue();

    /**
     * Cette méthode permet d'assigner la valeur minimale.
     *
     * @param minValue la valeur minimale
     */
    void setMinValue(Integer minValue);

    /**
     * Cette méthode permet d'obtenir la valeur maximale.
     *
     * @return la valeur maximale
     */
    Integer getMaxValue();

    /**
     * Cette méthode permet d'assigner la valeur maximale.
     *
     * @param maxValue la valeur maximale
     */
    void setMaxValue(Integer maxValue);

    /**
     * {@link HasMultiplierDto#JSON_MULTIPLIER}.
     */
    String JSON_MULTIPLIER = HasMultiplierDto.JSON_MULTIPLIER;
    
    /**
     * {@link HasMinValueDto#JSON_MIN_VALUE}.
     */
    String JSON_MIN_VALUE = HasMinValueDto.JSON_MIN_VALUE;

    /**
     * {@link HasMaxValueDto#JSON_MAX_VALUE}.
     */
    String JSON_MAX_VALUE = HasMaxValueDto.JSON_MAX_VALUE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ScriptContextGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ScriptContextGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ScriptContextGroupSaveRequestDto {

    @JsonbProperty(JSON_MULTIPLIER)
    private BigDecimal multiplier;
    
    @JsonbProperty(JSON_MIN_VALUE)
    private Integer minValue;

    @JsonbProperty(JSON_MAX_VALUE)
    private Integer maxValue;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ScriptContextGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  public static class ScriptContextGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ScriptContextGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ScriptContextGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptContextGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptContextGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ScriptContextGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class ScriptContextGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ScriptContextGroupSaveRequestDto {

    @JsonbProperty(JSON_MULTIPLIER)
    private BigDecimal multiplier;
    
    @JsonbProperty(JSON_MIN_VALUE)
    private Integer minValue;

    @JsonbProperty(JSON_MAX_VALUE)
    private Integer maxValue;
  }

  /**
   * Identifiant du service d'évaluation.
   */
  String EVALUATE_IDENTIFIER = "EVALUATION_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String EVALUATE_PATH = "evaluation";

  /**
   * Cette méthode permet d'évaluer {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(EVALUATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = EVALUATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = EvaluateResponseDto.class))})
  Response evaluate(EvaluateRequestDto request);

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_CONTEXTE_SCRIPT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ScriptContextGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
