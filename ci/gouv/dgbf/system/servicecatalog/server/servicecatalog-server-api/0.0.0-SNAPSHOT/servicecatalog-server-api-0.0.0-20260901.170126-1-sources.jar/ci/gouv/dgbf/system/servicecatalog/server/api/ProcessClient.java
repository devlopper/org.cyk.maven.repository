package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessService.ProcessCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessService.ProcessGetManyResponseDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessService.ProcessUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ProcessDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class ProcessClient extends AbstractClient<ProcessService>
    implements GetByIdentifier<ProcessDto>, GetMany<ProcessGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ProcessService}
   * @return client {@link ProcessClient}
   */
  @Override
  public ProcessClient service(ProcessService service) {
    return (ProcessClient) super.service(service);
  }

  /**
   * {@link ProcessService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcessCreateRequestDto request) {
    return new CreateExecutor(ProcessService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProcessService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcessGetManyResponseDto>(ProcessGetManyResponseDto.class,
        ProcessService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcessService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcessService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    return new GetOneExecutor<ProcessDto>(ProcessDto.class,
        ProcessService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link ProcessService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    return new GetOneExecutor<ProcessDto>(ProcessDto.class,
        ProcessService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link ProcessService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcessUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcessService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcessService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ProcessService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

}
