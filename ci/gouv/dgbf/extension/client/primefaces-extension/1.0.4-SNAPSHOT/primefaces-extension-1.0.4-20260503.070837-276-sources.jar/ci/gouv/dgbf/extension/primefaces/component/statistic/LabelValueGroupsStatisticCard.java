package ci.gouv.dgbf.extension.primefaces.component.statistic;

import ci.gouv.dgbf.extension.primefaces.Text;
import java.util.ArrayList;
import java.util.Collection;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente la carte statistique des groupes de libellé et valeurs.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LabelValueGroupsStatisticCard extends AbstractStatisticCard {

  Text headerText;

  Collection<Group> groups;

  Text footerText;

  Text footerLabel;

  public LabelValueGroupsStatisticCard() {
    setTemplateFilePath("/extension/component/statistic/card/labelvaluegroups.xhtml");
  }

  /**
   * Cette méthode permet d'obtenir un groupe non nul.
   *
   * @return groupe non nul
   */
  public Group group() {
    Group group = new Group();
    groups().add(group);
    return group;
  }

  Collection<Group> groups() {
    if (groups == null) {
      groups = new ArrayList<>();
    }
    return groups;
  }

  /**
   * Cette classe représente un groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public class Group {
    String style;

    String styleClass;

    Text headerText;

    Collection<LabelValue> labelValues;

    Text footerText;

    Text footerLabel;

    public LabelValueBuilder labelValueBuilder() {
      return new LabelValueBuilder();
    }

    /**
     * Cette méthode permet d'ajouter.
     *
     * @param label libellé
     * @param value valeur
     * @return groupe
     */
    public Group add(String label, String value) {
      labelValueBuilder().label(label).value(value).build();
      return this;
    }

    public Group styleClass(String styleClass) {
      this.styleClass = styleClass;
      return this;
    }

    Collection<LabelValue> labelValues() {
      if (labelValues == null) {
        labelValues = new ArrayList<>();
      }
      return labelValues;
    }

    /**
     * Cette classe représente une libellé et une valeur.
     *
     * @author Christian
     *
     */
    @Getter
    @Setter
    public class LabelValue {
      Text labelText;
      Text valueText;
    }

    /**
     * Cette classe représente un constructeur de {@link LabelValue}.
     *
     * @author Christian
     *
     */
    @Setter
    @Accessors(chain = true, fluent = true)
    public class LabelValueBuilder {
      String label;
      String labelClass;
      String value;
      String valueClass;

      /**
       * Cette méthode permet de construire.
       *
       * @return {@link LabelValue}
       */
      public Group build() {
        LabelValue labelValue = new LabelValue();
        labelValue.labelText = new Text.Builder().value(label).styleClass(labelClass).build();
        labelValue.valueText = new Text.Builder().value(value).styleClass(valueClass).build();
        labelValues().add(labelValue);
        return Group.this;
      }
    }
  }
}
