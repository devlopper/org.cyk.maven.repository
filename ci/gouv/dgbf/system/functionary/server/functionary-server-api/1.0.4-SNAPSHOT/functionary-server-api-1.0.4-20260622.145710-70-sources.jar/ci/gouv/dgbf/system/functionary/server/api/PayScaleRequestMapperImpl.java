package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayScaleDto}.
*
* @author AKM
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayScaleRequestMapperImpl implements PayScaleRequestMapper {

    @Override
    public PayScaleService.PayScaleCreateRequestDto mapCreate(PayScaleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayScaleService.PayScaleCreateRequestDto payScaleCreateRequestDto = new PayScaleService.PayScaleCreateRequestDto();

        payScaleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payScaleCreateRequestDto.setCode( arg0.getCode() );
        payScaleCreateRequestDto.setName( arg0.getName() );
        payScaleCreateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return payScaleCreateRequestDto;
    }

    @Override
    public PayScaleService.PayScaleUpdateRequestDto mapUpdate(PayScaleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayScaleService.PayScaleUpdateRequestDto payScaleUpdateRequestDto = new PayScaleService.PayScaleUpdateRequestDto();

        payScaleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payScaleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payScaleUpdateRequestDto.setCode( arg0.getCode() );
        payScaleUpdateRequestDto.setName( arg0.getName() );
        payScaleUpdateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return payScaleUpdateRequestDto;
    }
}
