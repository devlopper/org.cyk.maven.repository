package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractIconManager;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class BudgetaryClassificationIconManager extends AbstractIconManager {

  String expenditureActivity;
  
  /**
   * Cette méthode permet d'instancier.
   */
  public BudgetaryClassificationIconManager() {
    expenditureActivity = "pi pi-briefcase";
  }
}
