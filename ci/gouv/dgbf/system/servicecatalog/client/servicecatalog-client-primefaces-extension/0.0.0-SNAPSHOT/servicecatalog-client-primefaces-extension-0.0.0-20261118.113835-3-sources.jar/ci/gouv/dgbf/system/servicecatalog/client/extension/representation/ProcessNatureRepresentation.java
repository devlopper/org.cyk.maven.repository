package ci.gouv.dgbf.system.servicecatalog.client.extension.representation;

import ci.gouv.dgbf.extension.primefaces.component.output.AbstractTagRepresentation;
import ci.gouv.dgbf.system.servicecatalog.server.api.ProcessNature;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import java.util.EnumMap;
import java.util.Map;

/**
 * Cette classe représente la pastille unique de la nature d'un processus, utilisée par le fragment
 * {@code /servicecatalog/component/output/processNature.xhtml} en liste comme en fiche.
 *
 * @author Christian
 */
@ApplicationScoped
@Named("processNatureRepresentation")
public class ProcessNatureRepresentation extends AbstractTagRepresentation<ProcessNature> {

  static final Map<ProcessNature, String> ICONS = new EnumMap<>(ProcessNature.class);

  static {
    ICONS.put(ProcessNature.BACKEND, "pi pi-server");
    ICONS.put(ProcessNature.FRONTEND_WEB, "pi pi-desktop");
    ICONS.put(ProcessNature.FRONTEND_MOBILE_FLUTTER, "pi pi-mobile");
    ICONS.put(ProcessNature.FRONTEND_MOBILE_ANDROID, "pi pi-mobile");
    ICONS.put(ProcessNature.FRONTEND_MOBILE_IOS, "pi pi-mobile");
  }

  @Override
  protected String getLabel(ProcessNature value) {
    return value.getName();
  }

  @Override
  protected String getIcon(ProcessNature value) {
    return ICONS.get(value);
  }
}
