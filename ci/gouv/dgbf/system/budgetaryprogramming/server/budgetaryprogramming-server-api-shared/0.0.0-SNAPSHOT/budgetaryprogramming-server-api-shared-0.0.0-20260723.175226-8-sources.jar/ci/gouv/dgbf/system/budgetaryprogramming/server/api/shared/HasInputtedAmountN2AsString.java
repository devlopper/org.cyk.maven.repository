package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant saisi pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountN2AsString {

  /**
   * Obtient le montant saisi pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant saisi pour l'année N+2 sous forme de chaîne de caractères
   */
  String getInputtedAmountN2AsString();

  /**
   * Définit le montant saisi pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param inputtedAmountN2AsString le montant saisi pour l'année N+2 sous forme de chaîne de
   *        caractères
   */
  void setInputtedAmountN2AsString(String inputtedAmountN2AsString);

  /**
   * Identifiant java du montant saisi pour l'année N+2, sous forme de chaîne de caractères.
   */
  String FIELD_INPUTTED_AMOUNT_N2_AS_STRING = "inputtedAmountN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName