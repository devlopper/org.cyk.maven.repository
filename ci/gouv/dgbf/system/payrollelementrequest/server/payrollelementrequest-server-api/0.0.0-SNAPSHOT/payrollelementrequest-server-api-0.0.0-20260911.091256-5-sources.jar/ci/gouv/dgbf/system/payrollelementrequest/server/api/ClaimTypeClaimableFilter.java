package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimTypeClaimableDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimTypeClaimableFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Nature de l'objet ciblé.
   */
  String nature;

  /**
   * Mode de Saisie ({@code FAE}/{@code AGENT}, RG_REP_CIB_04) -- notamment utilisé pour
   * retrouver les Réclamables en Mode Agent d'un Type (RG_REP_PEC_09).
   */
  String valueInputMode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimTypeClaimableFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimTypeClaimableFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    nature = getNature(filter);
    valueInputMode = getValueInputMode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setNature(filter, nature);
    setValueInputMode(filter, valueInputMode);
  }

  /**
   * Cette méthode permet d'assigner la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @param nature nature de l'objet ciblé
   */
  public static void setNature(FilterDto filter, String nature) {
    set(filter, JSON_NATURE, f -> f.getValueAsString(),
        f -> f.setValueAsString(nature));
  }

  /**
   * Cette méthode permet d'obtenir la nature de l'objet ciblé.
   *
   * @param filter filtre
   * @return nature de l'objet ciblé
   */
  public static String getNature(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NATURE));
  }

  /**
   * Identifiant json champ {@link #nature}.
   */
  public static final String JSON_NATURE = ClaimTypeClaimableDto.JSON_NATURE;

  /**
   * Cette méthode permet d'assigner le Mode de Saisie.
   *
   * @param filter filtre
   * @param valueInputMode Mode de Saisie
   */
  public static void setValueInputMode(FilterDto filter, String valueInputMode) {
    set(filter, JSON_VALUE_INPUT_MODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(valueInputMode));
  }

  /**
   * Cette méthode permet d'obtenir le Mode de Saisie.
   *
   * @param filter filtre
   * @return Mode de Saisie
   */
  public static String getValueInputMode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_VALUE_INPUT_MODE));
  }

  /**
   * Identifiant json champ {@link #valueInputMode}.
   */
  public static final String JSON_VALUE_INPUT_MODE = ClaimTypeClaimableDto.JSON_VALUE_INPUT_MODE;
}
