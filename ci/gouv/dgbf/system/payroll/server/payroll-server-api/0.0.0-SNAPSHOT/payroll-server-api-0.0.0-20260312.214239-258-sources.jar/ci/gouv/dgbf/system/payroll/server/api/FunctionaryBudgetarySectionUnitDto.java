package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente {@link FunctionaryDto} de {@link BudgetarySectionUnitDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FunctionaryBudgetarySectionUnitDto extends AbstractIdentifiableDto {

  /**
   * Identifiant json de identifiant de {@link FunctionaryBudgetarySectionUnitDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idFonctionnaireUniteSectionBudgetaire";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link FunctionaryBudgetarySectionUnitDto}.
   */
  public static final String JSON_THIS_AS_STRING = "fonctionnaireUniteSectionBudgetaireChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fonctionnaire d'unité de section budgétaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "fonctionnaires d'unité de section budgétaire";
}
