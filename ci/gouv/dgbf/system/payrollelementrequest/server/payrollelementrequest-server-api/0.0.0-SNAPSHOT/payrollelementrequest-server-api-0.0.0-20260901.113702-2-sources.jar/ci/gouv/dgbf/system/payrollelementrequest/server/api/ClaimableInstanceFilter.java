package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableCodableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ClaimableInstanceDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class ClaimableInstanceFilter extends AbstractIdentifiableCodableFilter {

  /**
   * Identifiant du {@link ClaimableDto} {@code ELEMENT_PAIE} parent (pour filtrer les instances
   * d'un Élément de Paie donné).
   */
  String claimableIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ClaimableInstanceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ClaimableInstanceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    claimableIdentifier = getClaimableIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setClaimableIdentifier(filter, claimableIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'Élément de Paie parent.
   *
   * @param filter filtre
   * @param claimableIdentifier identifiant de l'Élément de Paie parent
   */
  public static void setClaimableIdentifier(FilterDto filter, String claimableIdentifier) {
    set(filter, JSON_CLAIMABLE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(claimableIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'Élément de Paie parent.
   *
   * @param filter filtre
   * @return identifiant de l'Élément de Paie parent
   */
  public static String getClaimableIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CLAIMABLE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER =
      ClaimableInstanceDto.JSON_CLAIMABLE_IDENTIFIER;
}
