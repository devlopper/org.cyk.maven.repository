package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDataSetDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.system.logging.server.api.LevelName;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventChartCode;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventClient;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventFilter;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventKpiCode;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du tableau de bord administrateur.
 *
 * @author Christian
 *
 */
@Dependent
public class DashboardController extends AbstractController {

  private static final Logger LOGGER = Logger.getLogger(DashboardController.class.getName());

  /**
   * Seuls les niveaux qui demandent une attention portent une couleur d'état ; les autres
   * partagent une teinte neutre (chaque couleur a un contraste d'au moins 4,5 sur fond blanc).
   */
  static final Map<String, String> LEVEL_COLORS = Map.of(
      LevelName.ERROR, "#dc2626",
      LevelName.WARNING, "#b45309",
      LevelName.INFORMATION, "#64748b",
      LevelName.CONFIGURATION, "#64748b",
      LevelName.DEBUG, "#64748b",
      LevelName.TRACE, "#64748b",
      "INCONNU", "#64748b");

  @Inject
  TraceabilityEventClient client;

  @Inject
  @Getter
  ChartController levelChartController;

  @Inject
  @Getter
  ChartController volumeByDayChartController;

  @Inject
  @Getter
  ChartController functionalityChartController;

  @Inject
  @Getter
  ChartController actionTypeChartController;

  @Inject
  @Getter
  ChartController userChartController;

  @Getter
  @Setter
  int periodDays = 30;

  /**
   * Composants dont les données n'ont pas pu être chargées : chacun s'affiche en état
   * « indisponible » et les autres restent affichés (constitution-ui.md 3.14).
   */
  final Set<String> unavailableComponents = new LinkedHashSet<>();

  /**
   * Un composant du tableau de bord = un appel au serveur (son code de graphique) et la façon de
   * lire sa réponse. Une panne ne touche que le composant concerné.
   */
  private final Map<String, Consumer<ChartDto>> processors = new LinkedHashMap<>();

  {
    processors.put(TraceabilityEventChartCode.KPIS, this::processKpis);
    processors.put(TraceabilityEventChartCode.LEVEL, chart -> processChart(levelChartController,
        chart, TraceabilityEventChartCode.LEVEL, "Répartition par niveau",
        ChartController::buildBarChart));
    processors.put(TraceabilityEventChartCode.VOLUME_BY_DAY,
        chart -> processChart(volumeByDayChartController, chart,
            TraceabilityEventChartCode.VOLUME_BY_DAY, "Volume par jour",
            ChartController::buildLineChart));
    processors.put(TraceabilityEventChartCode.FUNCTIONALITY,
        chart -> processChart(functionalityChartController, chart,
            TraceabilityEventChartCode.FUNCTIONALITY, "Activité par fonctionnalité",
            ChartController::buildBarChart));
    processors.put(TraceabilityEventChartCode.ACTION_TYPE,
        chart -> processChart(actionTypeChartController, chart,
            TraceabilityEventChartCode.ACTION_TYPE, "Répartition par type d'action",
            ChartController::buildBarChart));
    processors.put(TraceabilityEventChartCode.USER, chart -> processChart(userChartController,
        chart, TraceabilityEventChartCode.USER, "Activité par utilisateur",
        ChartController::buildBarChart));
  }

  @Getter
  long totalEvents;

  @Getter
  long errorLogs;

  @Getter
  String errorRate = "0,0 %";

  @Getter
  long correlatedEvents;

  @Getter
  String correlationRate = "0,0 %";

  @Getter
  long maskedEvents;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Tableau de bord Administrateur";
    for (ChartController controller : List.of(levelChartController, volumeByDayChartController,
        functionalityChartController, actionTypeChartController, userChartController)) {
      controller.setTitleDisplayed(false);
    }
    for (ChartController controller : List.of(levelChartController, volumeByDayChartController,
        functionalityChartController, actionTypeChartController, userChartController)) {
      controller.setLegendDisplayed(false);
      controller.setIntegerValues(true);
    }
    for (ChartController controller : List.of(functionalityChartController,
        actionTypeChartController, userChartController)) {
      controller.setUniformColor(true);
    }
    levelChartController.setKeyColors(LEVEL_COLORS);
  }

  /**
   * Cette méthode permet d'initialiser les métriques et graphiques du tableau de bord : un appel
   * par composant, pour qu'une panne ne masque que le composant concerné.
   */
  public void initialize() {
    unavailableComponents.clear();
    processors.keySet().forEach(this::load);
  }

  /**
   * Cette méthode permet de recharger un seul composant.
   *
   * @param component code du composant
   */
  public void retry(String component) {
    load(component);
  }

  /**
   * Cette méthode permet de savoir si un composant n'a pas pu être chargé.
   *
   * @param component code du composant
   * @return vrai si ses données sont indisponibles
   */
  public boolean isUnavailable(String component) {
    return unavailableComponents.contains(component);
  }

  /**
   * Cette méthode permet de savoir si plusieurs composants sont indisponibles : la page porte alors
   * un seul bandeau avec un seul « Réessayer », au lieu d'un message dans chaque composant.
   *
   * @return vrai si au moins deux composants sont indisponibles
   */
  public boolean isSeveralUnavailable() {
    return unavailableComponents.size() > 1;
  }

  void load(String component) {
    unavailableComponents.remove(component);
    processors.get(component).accept(fetch(component));
  }

  ChartDto fetch(String component) {
    TraceabilityEventFilter filter = new TraceabilityEventFilter();
    filter.setChartCode(component);
    LocalDateTime now = LocalDateTime.now();
    filter.setDateFrom(now.minusDays(periodDays));
    filter.setDateTo(now);
    try {
      GetChartResponseDto response = client.getChart(filter.toDto(), userIdentifier, null);
      return response == null ? null : response.getChart();
    } catch (RuntimeException exception) {
      unavailableComponents.add(component);
      LOGGER.log(Level.WARNING, "Tableau de bord : composant " + component + " indisponible",
          exception);
      return null;
    }
  }

  void processKpis(ChartDto chart) {
    totalEvents = 0;
    errorLogs = 0;
    errorRate = "0,0 %";
    correlatedEvents = 0;
    correlationRate = "0,0 %";
    maskedEvents = 0;

    if (chart == null || chart.getDataSets() == null) {
      return;
    }

    ChartDataSetDto kpiDataSet = findDataSet(chart, TraceabilityEventChartCode.KPIS);
    if (kpiDataSet != null && kpiDataSet.getDatas() != null) {
      for (ChartDataDto data : kpiDataSet.getDatas()) {
        if (TraceabilityEventKpiCode.TOTAL.equals(data.getKey())) {
          totalEvents = data.getValue() != null ? data.getValue() : 0;
        } else if (TraceabilityEventKpiCode.ERROR.equals(data.getKey())) {
          errorLogs = data.getValue() != null ? data.getValue() : 0;
        } else if (TraceabilityEventKpiCode.CORRELATION.equals(data.getKey())) {
          correlatedEvents = data.getValue() != null ? data.getValue() : 0;
        } else if (TraceabilityEventKpiCode.MASKING.equals(data.getKey())) {
          maskedEvents = data.getValue() != null ? data.getValue() : 0;
        }
      }
    }

    if (totalEvents > 0) {
      errorRate = String.format(Locale.FRANCE, "%.1f %%", (errorLogs * 100.0) / totalEvents);
      correlationRate = String.format(Locale.FRANCE, "%.1f %%",
          (correlatedEvents * 100.0) / totalEvents);
    }
  }

  void processChart(ChartController controller, ChartDto chart, String code, String title,
      Consumer<ChartController> builder) {
    ChartDataSetDto dataSet = findDataSet(chart, code);
    controller.setSupplier(() -> buildResponse(title, dataSet));
    builder.accept(controller);
  }

  ChartDataSetDto findDataSet(ChartDto chart, String name) {
    if (chart == null || chart.getDataSets() == null) {
      return null;
    }
    return chart.getDataSets().stream()
        .filter(ds -> name.equals(ds.getName()))
        .findFirst()
        .orElse(null);
  }

  GetChartResponseDto buildResponse(String title, ChartDataSetDto dataSet) {
    ChartDto chart = new ChartDto();
    chart.setName(title);
    if (dataSet != null && dataSet.getDatas() != null && !dataSet.getDatas().isEmpty()) {
      chart.addDataSet(dataSet);
      LinkedHashSet<String> keys = dataSet.getDatas().stream()
          .map(ChartDataDto::getKey)
          .collect(Collectors.toCollection(LinkedHashSet::new));
      chart.setKeys(keys);
    }
    GetChartResponseDto response = new GetChartResponseDto();
    response.setChart(chart);
    return response;
  }

  /**
   * Cette méthode permet d'appliquer une période en jours et de rafraîchir les données.
   *
   * @param days nombre de jours
   */
  public void applyPeriod(int days) {
    this.periodDays = days;
    initialize();
  }
}
