package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SsoUserRoleDto}.
*
* @author BoobaCool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-20T09:59:57+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SsoUserRoleRequestMapperImpl implements SsoUserRoleRequestMapper {

    @Override
    public SsoUserRoleService.SsoUserRoleCreateRequestDto mapCreate(SsoUserRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoUserRoleService.SsoUserRoleCreateRequestDto ssoUserRoleCreateRequestDto = new SsoUserRoleService.SsoUserRoleCreateRequestDto();

        ssoUserRoleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        ssoUserRoleCreateRequestDto.setRoleName( arg0.getRoleName() );
        ssoUserRoleCreateRequestDto.setUsername( arg0.getUsername() );

        return ssoUserRoleCreateRequestDto;
    }

    @Override
    public SsoUserRoleService.SsoUserRoleUpdateRequestDto mapUpdate(SsoUserRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SsoUserRoleService.SsoUserRoleUpdateRequestDto ssoUserRoleUpdateRequestDto = new SsoUserRoleService.SsoUserRoleUpdateRequestDto();

        ssoUserRoleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        ssoUserRoleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        ssoUserRoleUpdateRequestDto.setRoleName( arg0.getRoleName() );
        ssoUserRoleUpdateRequestDto.setUsername( arg0.getUsername() );

        return ssoUserRoleUpdateRequestDto;
    }
}
