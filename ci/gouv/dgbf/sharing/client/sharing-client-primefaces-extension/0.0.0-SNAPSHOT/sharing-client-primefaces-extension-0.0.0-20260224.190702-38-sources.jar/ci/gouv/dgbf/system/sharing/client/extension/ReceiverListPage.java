package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link ReceiverDto}.
 *
 * @author AKM
 *
 */
@Named
@ViewScoped
public class ReceiverListPage extends AbstractPage {

  @Inject
  @Getter
  ReceiverController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ReceiverDto.NAME;
    controller.initialize();
  }

  /**
   * Cette constante est le cas de navigation.
   */
  public static final String OUTCOME = "receiverListPage";
}
