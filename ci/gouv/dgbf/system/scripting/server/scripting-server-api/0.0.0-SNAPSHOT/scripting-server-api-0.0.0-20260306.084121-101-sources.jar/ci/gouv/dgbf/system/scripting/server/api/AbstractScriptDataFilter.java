package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de filtre par {@link ScriptDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractScriptDataFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ScriptDto}.
   */
  String scriptIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public AbstractScriptDataFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AbstractScriptDataFilter(FilterDto dto) {
    super(dto);
  }
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    scriptIdentifier = getScriptIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setScriptIdentifier(filter, scriptIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ScriptDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ScriptDto}
   */
  public static String getScriptIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SCRIPT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ScriptDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link ScriptDto}
   */
  public static void setScriptIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_SCRIPT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #scriptIdentifier}.
   */
  public static final String JSON_SCRIPT_IDENTIFIER = ScriptParameterDto.JSON_SCRIPT_IDENTIFIER;
}
