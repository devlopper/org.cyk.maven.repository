package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DeviceApplicationDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class DeviceApplicationFilter extends AbstractIdentifiableFilter {

}
