package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Interface représentant un filtre basé sur la notion de code de
 * {@link AdministrativeUnitEmployeeStatus}.
 *
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface MovementTypeIdentifierFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link MovementTypeDto}.
   *
   * @param filter {@link FilterDto}
   * @return identifiant de {@link MovementTypeDto}
   */
  public static String get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsStringByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link MovementTypeDto}.
   *
   * @param filter {@link FilterDto}
   * @param identifier identifiant de {@link MovementTypeDto}
   */
  public static void set(FilterDto filter, String identifier) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = MovementTypeDto.JSON_THIS_IDENTIFIER;


}

