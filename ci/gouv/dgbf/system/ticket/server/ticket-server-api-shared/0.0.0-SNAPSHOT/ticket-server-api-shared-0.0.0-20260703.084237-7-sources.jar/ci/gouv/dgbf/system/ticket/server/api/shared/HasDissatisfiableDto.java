package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être insatisfait.
 *
 * @author Christian
 */
public interface HasDissatisfiableDto extends HasDissatisfiable {

  /**
   * Identifiant json de peut être insatisfait.
   */
  String JSON_DISSATISFIABLE = "peutEtreInsatisfait";
}