package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être redirigé.
 *
 * @author Christian
 */
public interface HasRedirectable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être redirigé.
   *
   * @return peut être redirigé
   */
  Boolean getRedirectable();

  /**
   * Cette méthode permet d'assigner peut être redirigé.
   *
   * @param redirectable peut être redirigé
   */
  void setRedirectable(Boolean redirectable);

  /**
   * Identifiant java de peut être redirigé.
   */
  String FIELD_REDIRECTABLE = "redirectable";
}