package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PartitionTypeDto}.
 *
 * @author Boobacool
 */
@Getter
@Setter
public class PartitionTypeFilter extends AbstractIdentifiableFilter implements FilterHasCode {

  private String code;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PartitionTypeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PartitionTypeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterCode(filter);
  }

}
