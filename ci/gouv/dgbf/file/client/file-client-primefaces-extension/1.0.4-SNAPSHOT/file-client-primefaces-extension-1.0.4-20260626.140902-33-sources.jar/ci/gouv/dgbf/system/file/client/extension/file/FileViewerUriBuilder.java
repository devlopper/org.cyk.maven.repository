package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.ViewerUriBuilder;
import ci.gouv.dgbf.extension.primefaces.ViewerUriBuilder.Parameters;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.net.URI;
import lombok.Getter;

/**
 * Cette classe représente un constructeur d'URI de visualisateur de fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileViewerUriBuilder {

  @Getter
  @Inject
  ViewerUriBuilder uriBuilder;

  @PostConstruct
  void postConstruct() {
    uriBuilder.setServletPath(PATH);
    uriBuilder.initialize("file");
  }

  /**
   * Cette méthode permet de construire l'URI du visualisateur de fichier.
   *
   * @return URI
   */
  public URI build(String identifier, String ownerIdentifier, String auditWho,
      String auditSession) {
    validate(identifier);
    Parameters parameters = new Parameters();
    parameters.auditWho(auditWho);
    parameters.auditSession(auditSession);
    parameters.queryBuilder().map().add(ByIdentifierRequestDto.JSON_IDENTIFIER, identifier);
    parameters.queryBuilder().map().add(FileDto.JSON_OWNER_IDENTIFIER, ownerIdentifier);
    return uriBuilder.build(parameters);
  }

  void validate(String identifier) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L'identifiant du fichier est obligatoire");
    }
  }

  public static final String PATH = "fileviewer";
}
