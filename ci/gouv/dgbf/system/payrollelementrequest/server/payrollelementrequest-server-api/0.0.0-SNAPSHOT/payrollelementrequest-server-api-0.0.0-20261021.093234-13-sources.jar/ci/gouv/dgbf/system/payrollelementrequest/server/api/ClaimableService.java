package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasIsActivatedDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ClaimableDto} : lecture, et synchronisation à
 * la demande avec le module {@code payroll}. Pas de création/mise à jour/suppression exposées ici
 * : {@link ClaimableDto} est un référentiel synchronisé (RG_REP_CIB_07), jamais saisi via un
 * écran.
 *
 * @author akm
 *
 */
@Path(ClaimableService.PATH)
@Tag(name = "Gestion des réclamables")
public interface ClaimableService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "reclamables";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_RECLAMABLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimableGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimableDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimableDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_RECLAMABLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimableDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimableDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de synchronisation.
   */
  String SYNCHRONIZE_IDENTIFIER = "SYNCHRONISATION_RECLAMABLE";

  /**
   * Chemin du service de synchronisation.
   */
  String SYNCHRONIZE_PATH = "synchronisation";

  /**
   * Cette méthode permet de synchroniser à la demande les Réclamables depuis le module
   * {@code payroll} (RG_REP_CIB_07) : les nouveaux sont créés, les modifiés mis à jour, ceux qui
   * ont disparu désactivés.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SYNCHRONIZE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = SYNCHRONIZE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimableSynchronizeResponseDto.class))})
  Response synchronize(ClaimableSynchronizeRequestDto request);

  /**
   * Cette classe représente la requête de synchronisation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableSynchronizeRequestDto extends AbstractAuditedRequestJsonDto {

  }

  /**
   * Cette classe représente la réponse de synchronisation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableSynchronizeResponseDto extends AbstractResponseDto {

    /**
     * Nombre de Réclamables et d'instances créés, mis à jour ou désactivés.
     */
    @JsonbProperty(JSON_COUNT)
    private Integer count;

    /**
     * Identifiant json {@link #count}.
     */
    public static final String JSON_COUNT = "nombre";
  }

  /**
   * Identifiant du service d'obtention du nombre.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_RECLAMABLE";

  /**
   * Chemin du service d'obtention du nombre.
   */
  String GET_COUNT_PATH = "obtention/nombre";

  /**
   * Cette méthode permet d'obtenir le nombre de Réclamables, pour le décompte des onglets.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de désactivation.
   */
  String DEACTIVATE_IDENTIFIER = "DESACTIVATION_RECLAMABLE";

  /**
   * Chemin du service de désactivation.
   */
  String DEACTIVATE_PATH = "desactivation";

  /**
   * Cette méthode permet de désactiver un Réclamable à la main : il n'est plus proposé pour
   * paramétrer un Type de Réclamation, sans effet sur les Types et réclamations existants.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DEACTIVATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DEACTIVATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimableDeactivateResponseDto.class))})
  Response deactivate(ClaimableDeactivateRequestDto request);

  /**
   * Cette classe représente la requête de désactivation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableDeactivateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de désactivation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableDeactivateResponseDto extends IdentifiableResponseDto
      implements HasIsActivatedDto {

    @JsonbProperty(JSON_IS_ACTIVATED)
    private Boolean isActivated;
  }

  /**
   * Identifiant du service de réactivation.
   */
  String REACTIVATE_IDENTIFIER = "REACTIVATION_RECLAMABLE";

  /**
   * Chemin du service de réactivation.
   */
  String REACTIVATE_PATH = "reactivation";

  /**
   * Cette méthode permet de réactiver à la main un Réclamable désactivé, y compris celui qui a
   * disparu de payroll : la synchronisation ne le désactive plus tant qu'il n'y revient pas.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REACTIVATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REACTIVATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimableReactivateResponseDto.class))})
  Response reactivate(ClaimableReactivateRequestDto request);

  /**
   * Cette classe représente la requête de réactivation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableReactivateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de réactivation.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableReactivateResponseDto extends IdentifiableResponseDto
      implements HasIsActivatedDto {

    @JsonbProperty(JSON_IS_ACTIVATED)
    private Boolean isActivated;
  }

  /**
   * Identifiant du service de réglage de la transversalité.
   */
  String UPDATE_TRANSVERSAL_IDENTIFIER = "MODIFICATION_TRANSVERSALITE_RECLAMABLE";

  /**
   * Chemin du service de réglage de la transversalité.
   */
  String UPDATE_TRANSVERSAL_PATH = "transversalite";

  /**
   * Cette méthode permet de rendre un Réclamable transversal ou de lui retirer cette qualité
   * (RG_REP_CIB_14) : seul un Réclamable de nature Constante de Paie peut l'être.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_TRANSVERSAL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_TRANSVERSAL_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ClaimableUpdateTransversalResponseDto.class))})
  Response updateTransversal(ClaimableUpdateTransversalRequestDto request);

  /**
   * Cette classe représente la requête de réglage de la transversalité.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableUpdateTransversalRequestDto extends ByIdentifierRequestDto {

    @JsonbProperty(ClaimableDto.JSON_TRANSVERSAL)
    private Boolean transversal;
  }

  /**
   * Cette classe représente la réponse de réglage de la transversalité.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableUpdateTransversalResponseDto extends IdentifiableResponseDto {

    @JsonbProperty(ClaimableDto.JSON_TRANSVERSAL)
    private Boolean transversal;
  }
}
