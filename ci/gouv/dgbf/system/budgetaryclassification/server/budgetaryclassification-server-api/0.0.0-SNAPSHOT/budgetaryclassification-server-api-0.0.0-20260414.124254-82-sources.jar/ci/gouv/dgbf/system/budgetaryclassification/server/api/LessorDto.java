package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un bailleur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class LessorDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link LessorDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBailleur";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link LessorDto}.
   */
  public static final String JSON_THIS_AS_STRING = "bailleurChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "bailleur";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
