package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les modules.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ModuleFilter extends AbstractIdentifiableFilter {

}
