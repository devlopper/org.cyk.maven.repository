package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link EconomicNatureDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class EconomicNatureFilter extends AbstractIdentifiableFilter {

  /**
   * Oui ou non d'investissement.
   */
  Boolean investment;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    investment = getInvestment(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setInvestment(filter, investment);
  }

  /**
   * Cette méthode permet d'assigner si oui ou non {@link EconomicNatureDto} est d'investissement.
   *
   * @param filter filtre
   * @param value valeur
   */
  public static void setInvestment(FilterDto filter, Boolean value) {
    set(filter, JSON_INVESTMENT, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(value));
  }

  /**
   * Cette méthode permet d'obtenir si oui ou non {@link EconomicNatureDto} est d'investissement.
   *
   * @param filter filtre
   * @return oui ou non d'investissement
   */
  public static Boolean getInvestment(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_INVESTMENT));
  }

  /**
   * Identifiant json champ {@link EconomicNatureFilter#investment}.
   */
  public static final String JSON_INVESTMENT = EconomicNatureDto.JSON_INVESTMENT;
}
