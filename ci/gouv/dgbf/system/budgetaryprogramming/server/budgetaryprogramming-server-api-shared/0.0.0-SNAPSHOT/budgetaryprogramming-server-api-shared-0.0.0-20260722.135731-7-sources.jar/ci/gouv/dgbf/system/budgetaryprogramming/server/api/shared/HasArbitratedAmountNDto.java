package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasArbitratedAmountN}.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountNDto extends HasArbitratedAmountN {

  /**
   * Identifiant json du montant arbitré à l'horizon N.
   */
  String JSON_ARBITRATED_AMOUNT_N = "montantArbitreN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
