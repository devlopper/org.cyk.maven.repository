package ci.gouv.dgbf.system.ceadp.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ActivityTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-17T11:29:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ActivityTypeRequestMapperImpl implements ActivityTypeRequestMapper {

    @Override
    public ActivityTypeService.ActivityTypeCreateRequestDto mapCreate(ActivityTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityTypeService.ActivityTypeCreateRequestDto activityTypeCreateRequestDto = new ActivityTypeService.ActivityTypeCreateRequestDto();

        activityTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityTypeCreateRequestDto.setCode( arg0.getCode() );
        activityTypeCreateRequestDto.setName( arg0.getName() );

        return activityTypeCreateRequestDto;
    }

    @Override
    public ActivityTypeService.ActivityTypeUpdateRequestDto mapUpdate(ActivityTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ActivityTypeService.ActivityTypeUpdateRequestDto activityTypeUpdateRequestDto = new ActivityTypeService.ActivityTypeUpdateRequestDto();

        activityTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        activityTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        activityTypeUpdateRequestDto.setCode( arg0.getCode() );
        activityTypeUpdateRequestDto.setName( arg0.getName() );

        return activityTypeUpdateRequestDto;
    }
}
