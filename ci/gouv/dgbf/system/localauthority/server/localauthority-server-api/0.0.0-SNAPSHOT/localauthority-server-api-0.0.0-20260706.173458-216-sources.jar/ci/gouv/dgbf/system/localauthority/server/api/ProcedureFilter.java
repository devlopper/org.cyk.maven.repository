package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ProcedureDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ProcedureFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ProcedureFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ProcedureFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }


  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER = "idProgrammeTriennal";
}
