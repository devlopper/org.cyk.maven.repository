package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ConditionalValueGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ConditionalValueGroupRequestMapperImpl implements ConditionalValueGroupRequestMapper {

    @Override
    public ConditionalValueGroupService.ConditionalValueGroupCreateRequestDto mapCreate(ConditionalValueGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConditionalValueGroupService.ConditionalValueGroupCreateRequestDto conditionalValueGroupCreateRequestDto = new ConditionalValueGroupService.ConditionalValueGroupCreateRequestDto();

        conditionalValueGroupCreateRequestDto.setCode( arg0.getCode() );
        conditionalValueGroupCreateRequestDto.setName( arg0.getName() );
        conditionalValueGroupCreateRequestDto.setDescription( arg0.getDescription() );
        conditionalValueGroupCreateRequestDto.setValueType( arg0.getValueType() );
        conditionalValueGroupCreateRequestDto.setDefaultValue( arg0.getDefaultValue() );
        conditionalValueGroupCreateRequestDto.setValueRetrievalStrategy( arg0.getValueRetrievalStrategy() );

        return conditionalValueGroupCreateRequestDto;
    }

    @Override
    public ConditionalValueGroupService.ConditionalValueGroupUpdateRequestDto mapUpdate(ConditionalValueGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ConditionalValueGroupService.ConditionalValueGroupUpdateRequestDto conditionalValueGroupUpdateRequestDto = new ConditionalValueGroupService.ConditionalValueGroupUpdateRequestDto();

        conditionalValueGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        conditionalValueGroupUpdateRequestDto.setCode( arg0.getCode() );
        conditionalValueGroupUpdateRequestDto.setName( arg0.getName() );
        conditionalValueGroupUpdateRequestDto.setDescription( arg0.getDescription() );
        conditionalValueGroupUpdateRequestDto.setValueType( arg0.getValueType() );
        conditionalValueGroupUpdateRequestDto.setDefaultValue( arg0.getDefaultValue() );
        conditionalValueGroupUpdateRequestDto.setValueRetrievalStrategy( arg0.getValueRetrievalStrategy() );

        return conditionalValueGroupUpdateRequestDto;
    }

    @Override
    public ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueRequestDto mapGetApplicableValue(ConditionalValueGroupDto conditionalValueGroup) {
        if ( conditionalValueGroup == null ) {
            return null;
        }

        ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueRequestDto conditionalValueGroupGetApplicableValueRequestDto = new ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueRequestDto();

        conditionalValueGroupGetApplicableValueRequestDto.setIdentifier( conditionalValueGroup.getIdentifier() );
        conditionalValueGroupGetApplicableValueRequestDto.setFilterValue( conditionalValueGroup.getFilterValue() );
        Map<String, Object> map = conditionalValueGroup.getValuesMap();
        if ( map != null ) {
            conditionalValueGroupGetApplicableValueRequestDto.setValuesMap( new LinkedHashMap<String, Object>( map ) );
        }

        return conditionalValueGroupGetApplicableValueRequestDto;
    }
}
