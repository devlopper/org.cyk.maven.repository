package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN {

  /**
   * Obtient le montant total à valider pour l'année N.
   *
   * @return le montant total à valider pour l'année N
   */
  Long getTotalAmountToValidateN();

  /**
   * Définit le montant total à valider pour l'année N.
   *
   * @param totalAmountToValidateN le montant total à valider pour l'année N
   */
  void setTotalAmountToValidateN(Long totalAmountToValidateN);

  /**
   * Identifiant java du montant total à valider pour l'année N.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N = "totalAmountToValidateN";
}