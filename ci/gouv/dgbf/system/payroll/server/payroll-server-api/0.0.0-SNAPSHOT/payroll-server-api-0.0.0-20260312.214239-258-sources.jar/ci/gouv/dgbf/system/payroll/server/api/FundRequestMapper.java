package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.FundService.FundCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.FundService.FundUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FundDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FundDto}.

    @author akm
               """)
public interface FundRequestMapper
    extends RequestMapper<FundDto, 
            FundCreateRequestDto, FundUpdateRequestDto> {

}
