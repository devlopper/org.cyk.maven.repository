package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de la catégorie de budget.
 *
 * @author Arnaud
 */
public interface FilterHasBudgetCategoryIdentifier extends HasBudgetCategoryIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant catégorie budget.
   *
   * @param filter {@link FilterDto}
   */
  default void updateBudgetCategoryIdentifier(FilterDto filter) {
    setBudgetCategoryIdentifier(BudgetCategoryIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant catégorie budget de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterBudgetCategoryIdentifier(FilterDto filter) {
    BudgetCategoryIdentifierFilter.set(filter, getBudgetCategoryIdentifier());
  }

}
