package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ResourceVisibilityLevelDto}.

    @author Christian
               """)
public interface ResourceVisibilityLevelRequestMapper extends
    RequestMapper<ResourceVisibilityLevelDto, ResourceVisibilityLevelCreateRequestDto,
        ResourceVisibilityLevelUpdateRequestDto> {

}
