package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un service d'une unité administrative.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ServiceDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /*
   * Identifiant {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;
  
  /*
   * Code {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CODE)
  private String administrativeUnitCode;
  
  /*
   * Réprésentation en chaine de caractère {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;
  
  /**
   * Identifiant json champ {@link ServiceDto#administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER = "idUniteAdministrative";
  
  /**
   * Identifiant json champ {@link ServiceDto#administrativeUnitCode}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_CODE = "codeUniteAdministrative";
  
  /**
   * Identifiant json champ {@link ServiceDto#administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "service";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
