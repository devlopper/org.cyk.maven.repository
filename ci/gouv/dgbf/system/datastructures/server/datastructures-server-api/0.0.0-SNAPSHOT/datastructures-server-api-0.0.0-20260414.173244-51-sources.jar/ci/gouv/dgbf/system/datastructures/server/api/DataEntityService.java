package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasCreationScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasDeletionScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasExistenceVerificationScriptDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierGetValuesRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.ByIdentifierGetGridValuesResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.ByIdentifierGetValuesCountResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DataEntityDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = DataEntityService.PATH)
@Tag(name = "Gestion des entités de données")
public interface DataEntityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "entites-donnees";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface DataEntitySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le type.
     *
     * @return le type
     */
    DataEntityType getType();

    /**
     * Cette méthode permet d'assigner le type.
     *
     * @param type le type
     */
    void setType(DataEntityType type);

    /**
     * Cette méthode permet d'obtenir l'adresse.
     *
     * @return l'adresse
     */
    String getAddress();

    /**
     * Cette méthode permet d'assigner l'adresse.
     *
     * @param address l'adresse
     */
    void setAddress(String address);
    
    /**
     * Cette méthode permet d'obtenir le script de création.
     *
     * @return le script de création
     */
    String getCreationScript();

    /**
     * Cette méthode permet d'assigner le script de création.
     *
     * @param creationScript le script de création
     */
    void setCreationScript(String creationScript);

    /**
     * Cette méthode permet d'obtenir le script de suppression.
     *
     * @return le script de suppression
     */
    String getDeletionScript();

    /**
     * Cette méthode permet d'assigner le script de suppression.
     *
     * @param deletionScript le script de suppression
     */
    void setDeletionScript(String deletionScript);

    /**
     * Cette méthode permet d'obtenir le script de vérification d'existence.
     *
     * @return le script de vérification d'existence
     */
    String getExistenceVerificationScript();

    /**
     * Cette méthode permet d'assigner le script de vérification d'existence.
     *
     * @param existenceVerificationScript le script de vérification d'existence
     */
    void setExistenceVerificationScript(String existenceVerificationScript);

    /**
     * Identifiant json du type.
     */
    String JSON_TYPE = "type";

    /**
     * {@link HasAddressDto#JSON_ADDRESS}.
     */
    String JSON_ADDRESS = HasAddressDto.JSON_ADDRESS;
    
    /**
     * {@link HasCreationScriptDto#JSON_CREATION_SCRIPT}.
     */
    String JSON_CREATION_SCRIPT = HasCreationScriptDto.JSON_CREATION_SCRIPT;

    /**
     * {@link HasDeletionScriptDto#JSON_DELETION_SCRIPT}.
     */
    String JSON_DELETION_SCRIPT = HasDeletionScriptDto.JSON_DELETION_SCRIPT;

    /**
     * {@link HasExistenceVerificationScriptDto#JSON_EXISTENCE_VERIFICATION_SCRIPT}.
     */
    String JSON_EXISTENCE_VERIFICATION_SCRIPT =
        HasExistenceVerificationScriptDto.JSON_EXISTENCE_VERIFICATION_SCRIPT;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ENTITE_DONNEES";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DataEntityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DataEntityCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DataEntitySaveRequestDto {

    @JsonbProperty(JSON_TYPE)
    private DataEntityType type;

    @JsonbProperty(JSON_ADDRESS)
    private String address;
    
    @JsonbProperty(JSON_CREATION_SCRIPT)
    private String creationScript;

    @JsonbProperty(JSON_DELETION_SCRIPT)
    private String deletionScript;

    @JsonbProperty(JSON_EXISTENCE_VERIFICATION_SCRIPT)
    private String existenceVerificationScript;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ENTITE_DONNEES";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DataEntityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class DataEntityGetManyResponseDto
      extends AbstractGetByPageResponseDto<DataEntityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DataEntityDto> datas;
  }

  /**
   * Identifiant du service d'obtention des valeurs.
   */
  String GET_VALUES_IDENTIFIER = "OBTENTION_VALEURS_ENTITE_DONNEES";

  /**
   * Chemin du service d'obtention des valeurs.
   */
  String GET_VALUES_PATH = "obtention/valeurs";

  /**
   * Cette méthode permet d'obtenir les valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ByIdentifierGetGridValuesResponseDto.class))})
  Response getValues(ByIdentifierGetValuesRequestDto request);

  /**
   * Identifiant du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_IDENTIFIER = "OBTENTION_NOMBRE_VALEURS_ENTITE_DONNEES";

  /**
   * Chemin du service d'obtention du nombre de valeurs.
   */
  String GET_VALUES_COUNT_PATH = "obtention/nombre-valeurs";

  /**
   * Cette méthode permet d'obtenir le nombre de valeurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_VALUES_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_VALUES_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ByIdentifierGetValuesCountResponseDto.class))})
  Response getValuesCount(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ENTITE_DONNEES";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DataEntityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ENTITE_DONNEES";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = DataEntityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ENTITE_DONNEES";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(DataEntityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class DataEntityUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DataEntitySaveRequestDto {

    @JsonbProperty(JSON_TYPE)
    private DataEntityType type;

    @JsonbProperty(JSON_ADDRESS)
    private String address;
    
    @JsonbProperty(JSON_CREATION_SCRIPT)
    private String creationScript;

    @JsonbProperty(JSON_DELETION_SCRIPT)
    private String deletionScript;

    @JsonbProperty(JSON_EXISTENCE_VERIFICATION_SCRIPT)
    private String existenceVerificationScript;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ENTITE_DONNEES";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link DataEntityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
