package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une notion de montant intégré à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountNAsStringDto extends HasIntegratedAmountNAsString {

  /**
   * Identifiant json du montant intégré à l'horizon N, sous forme de chaîne de caractères.
   */
  String JSON_INTEGRATED_AMOUNT_N_AS_STRING = "montantIntegreNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
