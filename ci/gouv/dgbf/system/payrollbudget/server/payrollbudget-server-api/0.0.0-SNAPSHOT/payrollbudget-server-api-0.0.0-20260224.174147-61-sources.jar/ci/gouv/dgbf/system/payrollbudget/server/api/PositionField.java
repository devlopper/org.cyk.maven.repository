package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.EnumerationCore;
import lombok.Getter;

/**
 * Cette classe représente les champs de position.
 *
 * @author Christian
 *
 */
@Getter
public enum PositionField {

  /**
   * {@link PositionFieldCode#JOB}.
   */
  JOB(PositionFieldCode.JOB, "Emploi"),

  /**
   * {@link PositionFieldCode#PAY_INDEX}.
   */
  PAY_INDEX(PositionFieldCode.PAY_INDEX, "Indice"),

  /**
   * {@link PositionFieldCode#FUNCTION}.
   */
  FUNCTION(PositionFieldCode.FUNCTION, "Fonction")

  ;

  private PositionField(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link PositionField} par code.
   *
   * @param code code
   * @return statut
   */
  public static PositionField getByCode(String code) {
    return EnumerationCore.getByCode(PositionField.class, PositionField::getCode, code);
  }
}
