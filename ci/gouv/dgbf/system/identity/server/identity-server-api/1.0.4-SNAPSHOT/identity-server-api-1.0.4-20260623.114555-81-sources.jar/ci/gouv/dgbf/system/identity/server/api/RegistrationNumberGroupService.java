package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link RegistrationNumberGroupDto}.
 *
 * @author Christian
 *
 */
@Path(RegistrationNumberGroupService.PATH)
@Tag(name = "Gestion des groupes de matricule")
public interface RegistrationNumberGroupService extends Service {

  /**
   * Chemin du service de gestion des groupes de matricule.
   */
  String PATH = "groupes-matricule";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author arnaud
   *
   */
  interface RegistrationNumberGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le motif matricule.
     *
     * @return motif matricule
     */
    String getRegistrationNumberPattern();

    /**
     * Cette méthode permet d'assigner le motif matricule.
     *
     * @param registrationNumberPattern motif matricule
     */
    void setRegistrationNumberPattern(String registrationNumberPattern);


    /**
     * {@link RegistrationNumberGroupDto#JSON_REGISTRATION_NUMBER_PATTERN}.
     */
    public static final String JSON_REGISTRATION_NUMBER_PATTERN = 
        RegistrationNumberGroupDto.JSON_REGISTRATION_NUMBER_PATTERN;

  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UN_GROUPE_MATRICULE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link RegistrationNumberGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un groupe de matricule",
      description = "Ce service permet de créer un groupe de matricule")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RegistrationNumberGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author arnaud
   *
   */
  @Getter
  @Setter
  class RegistrationNumberGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
       implements RegistrationNumberGroupSaveRequestDto {
    /**
     * {@link RegistrationNumberGroupDto#getRegistrationNumberPattern()}.
     */
    @JsonbProperty(JSON_REGISTRATION_NUMBER_PATTERN)
    private String registrationNumberPattern;

  }


  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_MATRICULE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RegistrationNumberGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs groupes de matricules")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class RegistrationNumberGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<RegistrationNumberGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RegistrationNumberGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_MATRICULE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un groupe de matricule.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un groupe de matricule")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_MATRICULE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link RegistrationNumberGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un groupe de matricule")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RegistrationNumberGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_MATRICULE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link RegistrationNumberGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un groupe de matricule")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RegistrationNumberGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author arnaud
   *
   */

  @Getter
  @Setter
  class RegistrationNumberGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
        implements RegistrationNumberGroupSaveRequestDto {

    /**
     * {@link RegistrationNumberGroupDto#getRegistrationNumberPattern()}.
     */
    @JsonbProperty(JSON_REGISTRATION_NUMBER_PATTERN)
    private String registrationNumberPattern;

    /**
     * {@link RegistrationNumberGroupDto#JSON_REGISTRATION_NUMBER_PATTERN}.
     */
    public static final String JSON_REGISTRATION_NUMBER_PATTERN = 
           RegistrationNumberGroupDto.JSON_REGISTRATION_NUMBER_PATTERN;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_MATRICULE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link RegistrationNumberGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un groupe de matricule")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}

