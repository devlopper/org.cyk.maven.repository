package ci.gouv.dgbf.system.employee.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.system.employee.server.api.EmployeeDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link EmployeeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class EmployeeFilterController extends AbstractFilterController<EmployeeFilter> {

  @Inject
  @Getter
  InputTextController searchTextInputTextController;
  
  /**
   * Cette méthode permet de construire.
   */
  public EmployeeFilterController() {
    super(EmployeeFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setEmailAddress(getRequestParameter(EmployeeFilter.JSON_EMAIL_ADDRESS));

    filter.setSearchText(getRequestParameter(SearchTextFilter.JSON_KEY));
    
    searchTextInputTextController.setOutputLableValue("Recherche");
    searchTextInputTextController.getInputText()
        .addValueConsumer(searchText -> filter.setSearchText(searchText));
  }
}
