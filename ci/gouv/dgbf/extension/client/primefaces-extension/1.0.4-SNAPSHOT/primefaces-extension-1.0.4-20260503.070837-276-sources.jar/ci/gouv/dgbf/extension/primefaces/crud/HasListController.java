package ci.gouv.dgbf.extension.primefaces.crud;

/**
 * Cette interface représente une classe ayant une notion de {@link ListController}.
 */
public interface HasListController {

  ListController getListController();

  /**
   * Cette méthode permet de configurer le bouton d'accès à la page de consultation.
   *
   * @param outcome identifiant cas de navigation
   */
  default void enableGotoReadPageButton(String outcome) {
    getListController().getGotoReadPageButton().setRendered(true);
    getListController().getGotoReadPageButton().setOutcome(outcome);
  }
}
