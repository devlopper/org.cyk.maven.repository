package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être escaladé.
 *
 * @author Christian
 */
public interface HasEscalatable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être escaladé.
   *
   * @return peut être escaladé
   */
  Boolean getEscalatable();

  /**
   * Cette méthode permet d'assigner peut être escaladé.
   *
   * @param escalatable peut être escaladé
   */
  void setEscalatable(Boolean escalatable);

  /**
   * Identifiant java de peut être escaladé.
   */
  String FIELD_ESCALATABLE = "escalatable";
}