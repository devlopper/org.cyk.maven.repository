package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link DocumentGroupDto}.
 *
 * @author Christian
 */
@Path(value = DocumentGroupService.PATH)
@Tag(name = "Gestion des Groupes de Document")
public interface DocumentGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-document";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface DocumentGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du processus.
     *
     * @return identifiant du processus
     */
    String getProcessIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du processus.
     *
     * @param processIdentifier identifiant du processus
     */
    void setProcessIdentifier(String processIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la source.
     *
     * @return identifiant de la source
     */
    String getSourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la source.
     *
     * @param sourceIdentifier identifiant de la source
     */
    void setSourceIdentifier(String sourceIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'enregistrement.
     *
     * @return identifiant de l'enregistrement
     */
    String getRecordIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'enregistrement.
     *
     * @param recordIdentifier identifiant de l'enregistrement
     */
    void setRecordIdentifier(String recordIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'opération.
     *
     * @return identifiant de l'opération
     */
    String getOperationIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'opération.
     *
     * @param operationIdentifier identifiant de l'opération
     */
    void setOperationIdentifier(String operationIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant du type de groupe de document.
     *
     * @return identifiant du type de groupe de document
     */
    String getTypeGroupIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant du type de groupe de document.
     *
     * @param typeGroupIdentifier identifiant du type de groupe de document
     */
    void setTypeGroupIdentifier(String typeGroupIdentifier);

    /**
     * {@link DocumentGroupDto#JSON_PROCESS_IDENTIFIER}.
     */
    String JSON_PROCESS_IDENTIFIER = DocumentGroupDto.JSON_PROCESS_IDENTIFIER;

    /**
     * {@link DocumentGroupDto#JSON_SOURCE_IDENTIFIER}.
     */
    String JSON_SOURCE_IDENTIFIER = DocumentGroupDto.JSON_SOURCE_IDENTIFIER;

    /**
     * {@link DocumentGroupDto#JSON_RECORD_IDENTIFIER}.
     */
    String JSON_RECORD_IDENTIFIER = DocumentGroupDto.JSON_RECORD_IDENTIFIER;

    /**
     * {@link DocumentGroupDto#JSON_OPERATION_IDENTIFIER}.
     */
    String JSON_OPERATION_IDENTIFIER = DocumentGroupDto.JSON_OPERATION_IDENTIFIER;

    /**
     * {@link DocumentGroupDto#JSON_TYPE_GROUP_IDENTIFIER}.
     */
    String JSON_TYPE_GROUP_IDENTIFIER = DocumentGroupDto.JSON_TYPE_GROUP_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link DocumentGroupDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_DOCUMENT";

  /**
   * Chemin du service de création unitaire de {@link DocumentGroupDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(DocumentGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link DocumentGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements DocumentGroupSaveRequestDto {

    @JsonbProperty(JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(JSON_RECORD_IDENTIFIER)
    private String recordIdentifier;

    @JsonbProperty(JSON_OPERATION_IDENTIFIER)
    private String operationIdentifier;

    @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
    private String typeGroupIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link DocumentGroupDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_DOCUMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link DocumentGroupDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link DocumentGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class DocumentGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<DocumentGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<DocumentGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link DocumentGroupDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_GROUPE_DOCUMENT";

  /**
   * Chemin du service d'obtention unitaire de {@link DocumentGroupDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link DocumentGroupDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_DOCUMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link DocumentGroupDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link DocumentGroupDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_DOCUMENT";

  /**
   * Chemin du service de mise à jour unitaire de {@link DocumentGroupDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = UPDATE_IDENTIFIER)
  Response update(DocumentGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link DocumentGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class DocumentGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements DocumentGroupSaveRequestDto {

    @JsonbProperty(JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(JSON_RECORD_IDENTIFIER)
    private String recordIdentifier;

    @JsonbProperty(JSON_OPERATION_IDENTIFIER)
    private String operationIdentifier;

    @JsonbProperty(JSON_TYPE_GROUP_IDENTIFIER)
    private String typeGroupIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link DocumentGroupDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_DOCUMENT";

  /**
   * Chemin du service de suppression unitaire de {@link DocumentGroupDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link DocumentGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = DELETE_IDENTIFIER)
  Response delete(DeleteOneRequestDto request);
}
