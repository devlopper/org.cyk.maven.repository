package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SharingDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-18T10:36:36+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SharingRequestMapperImpl implements SharingRequestMapper {

    @Override
    public SharingService.SharingCreateRequestDto mapCreate(SharingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SharingService.SharingCreateRequestDto sharingCreateRequestDto = new SharingService.SharingCreateRequestDto();

        sharingCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        sharingCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        sharingCreateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        sharingCreateRequestDto.setResourceType( arg0.getResourceType() );
        sharingCreateRequestDto.setResourceLocation( arg0.getResourceLocation() );
        sharingCreateRequestDto.setReceiverIdentifier( arg0.getReceiverIdentifier() );
        sharingCreateRequestDto.setReceiverType( arg0.getReceiverType() );
        sharingCreateRequestDto.setReceiverLocation( arg0.getReceiverLocation() );
        sharingCreateRequestDto.setRefused( arg0.getRefused() );
        sharingCreateRequestDto.setFromDate( arg0.getFromDate() );
        sharingCreateRequestDto.setToDate( arg0.getToDate() );

        return sharingCreateRequestDto;
    }

    @Override
    public SharingService.SharingUpdateRequestDto mapUpdate(SharingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SharingService.SharingUpdateRequestDto sharingUpdateRequestDto = new SharingService.SharingUpdateRequestDto();

        sharingUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        sharingUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        sharingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        sharingUpdateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        sharingUpdateRequestDto.setResourceType( arg0.getResourceType() );
        sharingUpdateRequestDto.setResourceLocation( arg0.getResourceLocation() );
        sharingUpdateRequestDto.setReceiverIdentifier( arg0.getReceiverIdentifier() );
        sharingUpdateRequestDto.setReceiverType( arg0.getReceiverType() );
        sharingUpdateRequestDto.setReceiverLocation( arg0.getReceiverLocation() );
        sharingUpdateRequestDto.setRefused( arg0.getRefused() );
        sharingUpdateRequestDto.setFromDate( arg0.getFromDate() );
        sharingUpdateRequestDto.setToDate( arg0.getToDate() );

        return sharingUpdateRequestDto;
    }
}
