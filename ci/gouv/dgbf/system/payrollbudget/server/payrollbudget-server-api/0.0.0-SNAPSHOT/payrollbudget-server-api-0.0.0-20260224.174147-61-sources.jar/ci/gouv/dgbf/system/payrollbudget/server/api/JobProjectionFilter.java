package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link JobProjectionDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class JobProjectionFilter
    extends AbstractIdentifiableFilter {

  /**
   * Identifiant de l'emploi.
   */
  String jobIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public JobProjectionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public JobProjectionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    jobIdentifier = getJobIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setJobIdentifier(filter, jobIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'emploi.
   *
   * @param filter filtre
   * @return identifiant de l'emploi
   */
  public static String getJobIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_JOB_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'emploi.
   *
   * @param filter filtre
   * @param identifier identifiant de l'emploi
   */
  public static void setJobIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_JOB_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json {@link #jobIdentifier}.
   */
  public static final String JSON_JOB_IDENTIFIER =
      JobProjectionDto.JSON_JOB_IDENTIFIER;
}
