package ci.gouv.dgbf.system.token.server.api;

/**
 * Cette classe représente les codes de {@link TokenStatus}.
 *
 * @author Christian
 *
 */
public class TokenStatusCode {

  private TokenStatusCode() {

  }

  /**
   * Émis.
   */
  public static final String ISSUED = "EMIS";

  /**
   * Consommé.
   */
  public static final String CONSUMED = "CONSOMME";

  /**
   * Expiré.
   */
  public static final String EXPIRED = "EXPIRE";

  /**
   * Révoqué.
   */
  public static final String REVOKED = "REVOQUE";

  /**
   * Introuvable (aucun Jeton ne correspond à la Valeur présentée, {@code verify()} uniquement —
   * n'a pas d'équivalent parmi les statuts, ne décrit pas un Jeton existant).
   */
  public static final String NOT_FOUND = "INTROUVABLE";
}
