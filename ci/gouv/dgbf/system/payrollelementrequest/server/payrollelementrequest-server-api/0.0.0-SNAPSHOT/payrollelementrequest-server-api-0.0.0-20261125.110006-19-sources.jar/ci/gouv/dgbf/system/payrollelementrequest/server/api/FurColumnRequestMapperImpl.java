package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FurColumnDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-25T11:00:24+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FurColumnRequestMapperImpl implements FurColumnRequestMapper {

    @Override
    public FurColumnService.FurColumnCreateRequestDto mapCreate(FurColumnDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurColumnService.FurColumnCreateRequestDto furColumnCreateRequestDto = new FurColumnService.FurColumnCreateRequestDto();

        furColumnCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        furColumnCreateRequestDto.setCode( arg0.getCode() );
        furColumnCreateRequestDto.setName( arg0.getName() );
        furColumnCreateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        furColumnCreateRequestDto.setResolverKind( arg0.getResolverKind() );
        furColumnCreateRequestDto.setOutputField( arg0.getOutputField() );
        furColumnCreateRequestDto.setDateColumn( arg0.getDateColumn() );

        return furColumnCreateRequestDto;
    }

    @Override
    public FurColumnService.FurColumnUpdateRequestDto mapUpdate(FurColumnDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurColumnService.FurColumnUpdateRequestDto furColumnUpdateRequestDto = new FurColumnService.FurColumnUpdateRequestDto();

        furColumnUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        furColumnUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        furColumnUpdateRequestDto.setCode( arg0.getCode() );
        furColumnUpdateRequestDto.setName( arg0.getName() );
        furColumnUpdateRequestDto.setClaimableIdentifier( arg0.getClaimableIdentifier() );
        furColumnUpdateRequestDto.setResolverKind( arg0.getResolverKind() );
        furColumnUpdateRequestDto.setOutputField( arg0.getOutputField() );
        furColumnUpdateRequestDto.setDateColumn( arg0.getDateColumn() );

        return furColumnUpdateRequestDto;
    }
}
