package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.SsoRoleService.SsoRoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.SsoRoleService.SsoRoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SsoRoleDto}.
 *
 * @author BoobaCool
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SsoRoleDto}.
    
    @author BoobaCool
    """)
public interface SsoRoleRequestMapper extends
    RequestMapper<SsoRoleDto, SsoRoleCreateRequestDto,
        SsoRoleUpdateRequestDto> {

}
