package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * Cette classe représente un évènement journal applicatif.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@ToString
public class Notification {

  String channel;
  String message;
  
}