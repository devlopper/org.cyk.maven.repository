package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbTransient;
import java.time.LocalDateTime;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fichier de groupe.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileGroupDto extends AbstractIdentifiableAuditableDto
    implements HasStatusDto<FileGroupStatus>, HasStatusAsStringDto, HasConfirmableDto,
    HasPlannedPurgeDateDto<LocalDateTime>, HasPlannedPurgeDateAsStringDto {

  @JsonbProperty(JSON_STATUS)
  private FileGroupStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_CONFIRMABLE)
  private Boolean confirmable;

  @JsonbProperty(JSON_PLANNED_PURGE_DATE)
  private LocalDateTime plannedPurgeDate;

  @JsonbProperty(JSON_PLANNED_PURGE_DATE_AS_STRING)
  private String plannedPurgeDateAsString;

  /**
   * Identifiant {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_IDENTIFIER)
  private String fileIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_AS_STRING)
  private String fileAsString;

  /**
   * Nom de {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_NAME)
  private String fileName;

  /**
   * Octets de {@link FileDto}.
   */
  @JsonbTransient
  private byte[] fileBytes;

  /**
   * Identifiant {@link OwnerDto} de {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_OWNER_IDENTIFIER)
  private String fileOwnerIdentifier;

  /**
   * Représentation en chaine de caractères de l'audit de {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_AUDIT_AS_STRING)
  private String fileAuditAsString;

  /**
   * Identifiant {@link FilesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FilesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Mise à jour des identifiants {@link FileCategoryDto}.
   */
  @JsonbProperty(JSON_UPDATE_CATEGORIES_IDENTIFIERS)
  private Boolean updateCategoriesIdentifiers;

  /**
   * Identifiants {@link FileCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORIES_IDENTIFIERS)
  private Set<String> categoriesIdentifiers;

  /**
   * Représentation en chaine de caractères des {@link FileCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORIES_AS_STRING)
  private String categoriesAsString;

  /**
   * Identifiant de la période d'archivage applicable (sans date de fin).
   */
  @JsonbProperty(JSON_APPLICABLE_ARCHIVE_IDENTIFIER)
  private String applicableArchiveIdentifier;

  /**
   * Indicateur d'archivage effectif (présence d'une période sans date de fin).
   */
  @JsonbProperty(JSON_ARCHIVED)
  private Boolean archived;

  /**
   * Indicateur de gel pour archivage (période sans fin ou demande d'archivage en cours).
   */
  @JsonbProperty(JSON_ARCHIVAL_FROZEN)
  private Boolean archivalFrozen;

  /**
   * Identifiant de la demande d'archivage ou de retrait en cours (statut CREE).
   */
  @JsonbProperty(JSON_PENDING_ARCHIVAL_SOLICITATION_IDENTIFIER)
  private String pendingArchivalSolicitationIdentifier;

  /**
   * Date de début de la période d'archivage applicable.
   */
  @JsonbProperty(JSON_ARCHIVAL_START_DATE)
  private LocalDateTime archivalStartDate;

  /**
   * Identifiant de l'auteur du début de la période d'archivage applicable.
   */
  @JsonbProperty(JSON_ARCHIVAL_START_AUTHOR_IDENTIFIER)
  private String archivalStartAuthorIdentifier;

  /**
   * Motif du début de la période d'archivage applicable.
   */
  @JsonbProperty(JSON_ARCHIVAL_START_REASON)
  private String archivalStartReason;

  /**
   * Capacité calculée : éligible à la création d'une demande d'archivage.
   */
  @JsonbProperty(JSON_ARCHIVABLE)
  private Boolean archivable;

  /**
   * Capacité calculée : éligible à l'archivage direct.
   */
  @JsonbProperty(JSON_DIRECT_ARCHIVING_ALLOWED)
  private Boolean directArchivingAllowed;

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FileCategoryDto}.
   *
   * @param identifier identifiant de {@link FileCategoryDto}
   */
  public void setCategoriesIdentifiersFrom(String identifier) {
    if (Core.isStringBlank(identifier)) {
      categoriesIdentifiers = null;
    } else {
      categoriesIdentifiers = Core.getSetFromArray(identifier);
    }
  }

  /**
   * Cette méthode permet d'obtenir le premier identifiant {@link FileCategoryDto}.
   *
   * @return premier identifiant {@link FileCategoryDto}
   */
  public String getFirstCategoriesIdentifiers() {
    if (Core.isCollectionEmpty(categoriesIdentifiers)) {
      return null;
    }
    return categoriesIdentifiers.iterator().next();
  }

  /**
   * Identifiant JSON de {@link #fileIdentifier}.
   */
  public static final String JSON_FILE_IDENTIFIER = "idFichier";

  /**
   * Identifiant JSON de {@link #fileAsString}.
   */
  public static final String JSON_FILE_AS_STRING = "fichierChaine";

  /**
   * Identifiant JSON de {@link #fileName}.
   */
  public static final String JSON_FILE_NAME = "nomFichier";

  /**
   * Identifiant JSON de {@link #fileOwnerIdentifier}.
   */
  public static final String JSON_FILE_OWNER_IDENTIFIER = FileDto.JSON_OWNER_IDENTIFIER + "Fichier";

  /**
   * Identifiant JSON de {@link #fileAuditAsString}.
   */
  public static final String JSON_FILE_AUDIT_AS_STRING = "auditFichierChaine";

  /**
   * Identifiant JSON de {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";

  /**
   * Identifiant JSON de {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";

  /**
   * Identifiant JSON de {@link #updateCategoriesIdentifiers}.
   */
  public static final String JSON_UPDATE_CATEGORIES_IDENTIFIERS = "modificationIdsCategories";

  /**
   * Identifiant JSON de {@link #categoriesIdentifiers}.
   */
  public static final String JSON_CATEGORIES_IDENTIFIERS = "idsCategories";

  /**
   * Identifiant JSON de {@link #categoriesAsString}.
   */
  public static final String JSON_CATEGORIES_AS_STRING = "categoriesChaine";

  /**
   * Identifiant JSON de {@link #applicableArchiveIdentifier}.
   */
  public static final String JSON_APPLICABLE_ARCHIVE_IDENTIFIER = "identifiantArchiveApplicable";

  /**
   * Identifiant JSON de {@link #archived}.
   */
  public static final String JSON_ARCHIVED = "estArchive";

  /**
   * Identifiant JSON de {@link #archivalFrozen}.
   */
  public static final String JSON_ARCHIVAL_FROZEN = "estGelePourArchivage";

  /**
   * Identifiant JSON de {@link #pendingArchivalSolicitationIdentifier}.
   */
  public static final String JSON_PENDING_ARCHIVAL_SOLICITATION_IDENTIFIER =
      "identifiantDemandeArchivageEnCours";

  /**
   * Identifiant JSON de {@link #archivalStartDate}.
   */
  public static final String JSON_ARCHIVAL_START_DATE = "dateDebutArchivage";

  /**
   * Identifiant JSON de {@link #archivalStartAuthorIdentifier}.
   */
  public static final String JSON_ARCHIVAL_START_AUTHOR_IDENTIFIER =
      "identifiantAuteurDebutArchivage";

  /**
   * Identifiant JSON de {@link #archivalStartReason}.
   */
  public static final String JSON_ARCHIVAL_START_REASON = "motifDebutArchivage";

  /**
   * Identifiant JSON de {@link #archivable}.
   */
  public static final String JSON_ARCHIVABLE = "peutEtreArchive";

  /**
   * Identifiant JSON de {@link #directArchivingAllowed}.
   */
  public static final String JSON_DIRECT_ARCHIVING_ALLOWED = "peutEtreArchiveDirectement";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fichier et groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "fichiers et groupes";
}
