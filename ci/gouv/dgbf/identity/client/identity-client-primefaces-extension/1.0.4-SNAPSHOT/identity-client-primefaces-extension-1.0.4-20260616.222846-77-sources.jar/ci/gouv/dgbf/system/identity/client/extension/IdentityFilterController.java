package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative.AdministrativeUnitSelectOneController;
import ci.gouv.dgbf.system.identity.server.api.AbstractIdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentityFilterController extends AbstractFilterController<IdentityFilter> {

  @Inject
  @Getter
  AdministrativeUnitSelectOneController administrativeUnitSelectOneController;

  @Inject
  @Getter
  InputTextController searchTextInputTextController;
  
  @Inject
  @Getter
  InputTextController registrationNumberInputTextController;

  @Inject
  @Getter
  InputTextController emailAddressInputTextController;

  @Inject
  @Getter
  InputTextController firstNameInputTextController;

  @Inject
  @Getter
  InputTextController lastNamesInputTextController;

  /**
   * Cette méthode permet d'instantier.
   */
  public IdentityFilterController() {
    super(IdentityFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setEmailAddress(getRequestParameter(AbstractIdentityFilter.JSON_EMAIL_ADDRESS));
    filter.setRegistrationNumber(
        getRequestParameter(AbstractIdentityFilter.JSON_REGISTRATION_NUMBER));
    filter.setIsRegistrationNumberGroupPublicFunction(getRequestParameterAsBoolean(
        AbstractIdentityFilter.JSON_IS_REGISTRATION_NUMBER_GROUP_PUBLIC_FUNCTION));
    filter.setAdministrativeUnitIdentifier(
        getRequestParameter(AbstractIdentityFilter.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
    filter.setSearchText(getRequestParameter(SearchTextFilter.JSON_KEY));

    administrativeUnitSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> filter.setAdministrativeUnitIdentifier(identifier));
    administrativeUnitSelectOneController
        .setChoicable(Core.isStringBlank(filter.getAdministrativeUnitIdentifier()));

    searchTextInputTextController.setOutputLableValue("Recherche");
    searchTextInputTextController.getInputText()
        .addValueConsumer(searchText -> filter.setSearchText(searchText));
    
    registrationNumberInputTextController.setOutputLableValue("Matricule");
    registrationNumberInputTextController.getInputText()
        .addValueConsumer(registrationNumber -> filter.setRegistrationNumber(registrationNumber));

    emailAddressInputTextController.setOutputLableValue("Adresse électronique");
    emailAddressInputTextController.getInputText()
        .addValueConsumer(emailAddress -> filter.setEmailAddress(emailAddress));

    firstNameInputTextController.setOutputLableValue("Nom");
    firstNameInputTextController.getInputText()
        .addValueConsumer(firstName -> filter.setFirstName(firstName));

    lastNamesInputTextController.setOutputLableValue("Prénom(s)");
    lastNamesInputTextController.getInputText()
        .addValueConsumer(lastNames -> filter.setLastNames(lastNames));
  }

  @Override
  public void filter() {
    super.filter();
    administrativeUnitSelectOneController.getAutoComplete().writeValue(null);
  }
}

