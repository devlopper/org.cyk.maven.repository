package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentCategoryDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentCategoryRequestMapperImpl implements PayrollComponentCategoryRequestMapper {

    @Override
    public PayrollComponentCategoryService.PayrollComponentCategoryCreateRequestDto mapCreate(PayrollComponentCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentCategoryService.PayrollComponentCategoryCreateRequestDto payrollComponentCategoryCreateRequestDto = new PayrollComponentCategoryService.PayrollComponentCategoryCreateRequestDto();

        payrollComponentCategoryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentCategoryCreateRequestDto.setCode( arg0.getCode() );
        payrollComponentCategoryCreateRequestDto.setName( arg0.getName() );

        return payrollComponentCategoryCreateRequestDto;
    }

    @Override
    public PayrollComponentCategoryService.PayrollComponentCategoryUpdateRequestDto mapUpdate(PayrollComponentCategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentCategoryService.PayrollComponentCategoryUpdateRequestDto payrollComponentCategoryUpdateRequestDto = new PayrollComponentCategoryService.PayrollComponentCategoryUpdateRequestDto();

        payrollComponentCategoryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentCategoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentCategoryUpdateRequestDto.setCode( arg0.getCode() );
        payrollComponentCategoryUpdateRequestDto.setName( arg0.getName() );

        return payrollComponentCategoryUpdateRequestDto;
    }
}
