package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;

/**
 * Cette classe représente la base de page de liste d'unités administratives partagées de
 * l'utilisateur connecté.
 *
 * @author Christian
 *
 */
public abstract class AbstractConnectedUserSharedBudgetSpecializationUnitListPage
    extends AbstractConnectedUserSharedResourceListPage {

  /**
   * Cette méthode permet de construire.
   */
  protected AbstractConnectedUserSharedBudgetSpecializationUnitListPage() {
    super(Location.BUDGETARY_CLASSIFICATION, ResourceType.BUDGET_SPECIALIZATION_UNIT);
    selectOneControllerFilterConsumer =
        SharingSessionController
          .BUDGET_SPECIALIZATION_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER;
  }

  @Override
  protected String resourceTypeName() {
    return "unités de spécialisation de budget partagées";
  }
}
