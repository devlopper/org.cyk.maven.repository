package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de libellé du groupe d'utilisateurs à
 * créer (module Utilisateur).
 *
 * @author Arnaud
 */
public interface HasUsersGroupNameDto extends HasUsersGroupName {

  /**
   * Identifiant json du libellé du groupe d'utilisateurs.
   */
  String JSON_USERS_GROUP_NAME = "libelleGroupeUtilisateurs";
}
