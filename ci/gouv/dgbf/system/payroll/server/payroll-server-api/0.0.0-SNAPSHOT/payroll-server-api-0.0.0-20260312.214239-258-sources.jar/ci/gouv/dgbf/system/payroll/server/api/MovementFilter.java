package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasFunctionaryRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRemunerableIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayslipIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollElementInstanceIdentifierDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class MovementFilter extends AbstractIdentifiableFilter
    implements FilterHasRemunerableIdentifier, FilterHasPayslipIdentifier,
    FilterHasFunctionaryRegistrationNumber, FilterHasTypeIdentifier {

  private String remunerableIdentifier;

  /**
   * Matricule du fonctionnaire.
   */
  String functionaryRegistrationNumber;

  /**
   * Identifiant du type de mouvement.
   */
  String typeIdentifier;

  /**
   * Identifiant de l'occurence d'élément de paie.
   */
  String payrollElementInstanceIdentifier;

  private String payslipIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public MovementFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public MovementFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateRemunerableIdentifier(filter);
    updateFunctionaryRegistrationNumber(filter);
    updateTypeIdentifier(filter);
    updatePayslipIdentifier(filter);
    payrollElementInstanceIdentifier = getPayrollElementInstanceIdentifier(filter);

  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterRemunerableIdentifier(filter);
    updateFilterTypeIdentifier(filter);
    updateFilterFunctionaryRegistrationNumber(filter);
    updateFilterPayslipIdentifier(filter);
    setPayrollElementInstanceIdentifier(filter, payrollElementInstanceIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'occurence d'un élément de paie.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPayrollElementInstanceIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'occurence d'un élément de paie.
   *
   * @param filter filtre
   * @return identifiant de l'occurence d'un élément de paie
   */
  public static String getPayrollElementInstanceIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link MovementFilter#payrollElementInstanceIdentifier}.
   */
  public static final String JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER =
      HasPayrollElementInstanceIdentifierDto.JSON_PAYROLL_ELEMENT_INSTANCE_IDENTIFIER;



}
