package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un propriétaire.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@Accessors(chain = true)
public class OwnerDto extends AbstractIdentifiableCodableNamableAuditableDto {
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "propriétaire";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
