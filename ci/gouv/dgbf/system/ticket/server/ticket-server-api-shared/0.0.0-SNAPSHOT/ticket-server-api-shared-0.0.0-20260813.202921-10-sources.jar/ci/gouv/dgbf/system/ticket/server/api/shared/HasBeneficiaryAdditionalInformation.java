package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'informations complémentaires sur le
 * bénéficiaire, saisies librement lorsque le bénéficiaire n'est pas une identité connue.
 *
 * @author Christian
 */
public interface HasBeneficiaryAdditionalInformation extends HasField {

  /**
   * Cette méthode permet d'obtenir les informations complémentaires sur le bénéficiaire.
   *
   * @return les informations complémentaires sur le bénéficiaire
   */
  String getBeneficiaryAdditionalInformation();

  /**
   * Cette méthode permet d'assigner les informations complémentaires sur le bénéficiaire.
   *
   * @param beneficiaryAdditionalInformation les informations complémentaires sur le bénéficiaire
   */
  void setBeneficiaryAdditionalInformation(String beneficiaryAdditionalInformation);

  /**
   * Identifiant java des informations complémentaires sur le bénéficiaire.
   */
  String FIELD_BENEFICIARY_ADDITIONAL_INFORMATION = "beneficiaryAdditionalInformation";
}
