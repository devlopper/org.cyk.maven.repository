package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FileDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FileDto}.

    @author Christian
               """)
public interface FileRequestMapper
    extends RequestMapper<FileDto, FileCreateRequestDto, FileUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper le support d'origine ({@link MediumNature}) vers son code.
   *
   * @param originalMedium support d'origine
   * @return code du support d'origine
   */
  default String map(MediumNature originalMedium) {
    return originalMedium == null ? null : originalMedium.getCode();
  }
}
