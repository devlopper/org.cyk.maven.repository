package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractIconManager;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class IconManager extends AbstractIconManager {

  String identity;
  String programming;
  String expenditure;
  String revenue;
  
  /**
   * Cette méthode permet d'instancier.
   */
  public IconManager() {
    identity = "pi pi-user";
  }
}
