package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action
 * Accepter (RG_REP_PEC_08) sur une réponse de traitement (motif R44/R45).
 *
 * @author akm
 *
 */
public interface HasAcceptableDto {

  /**
   * Identifiant json de {@link #getAcceptable()}.
   */
  String JSON_ACCEPTABLE = "acceptable";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Accepter.
   *
   * @return indicateur de disponibilité de l'action Accepter
   */
  Boolean getAcceptable();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Accepter.
   *
   * @param acceptable indicateur de disponibilité de l'action Accepter
   */
  void setAcceptable(Boolean acceptable);
}
