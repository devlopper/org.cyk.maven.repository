package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasEmailAddress;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.identity.server.api.shared.FilterHasIdentityIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityEmailAddressDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityEmailAddressFilter extends AbstractIdentifiableFilter
    implements FilterHasIdentityIdentifier, FilterHasEmailAddress {

  String identityIdentifier;

  String emailAddress;
  
  @Override
  protected void doInitialize(FilterDto filter) {
    updateIdentityIdentifier(filter);
    updateEmailAddress(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterIdentityIdentifier(filter);
    updateFilterEmailAddress(filter);
  }
}
