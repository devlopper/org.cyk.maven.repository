package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FunctionGroupDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FunctionGroupDto}.

    @author Arnaud
     """)
public interface FunctionGroupRequestMapper
    extends RequestMapper<FunctionGroupDto, FunctionGroupCreateRequestDto,
                          FunctionGroupUpdateRequestDto> {

}
