package ci.gouv.dgbf.system.sharing.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ResourceVisibilityLevelDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-04T12:21:41+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ResourceVisibilityLevelRequestMapperImpl implements ResourceVisibilityLevelRequestMapper {

    @Override
    public ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto mapCreate(ResourceVisibilityLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto resourceVisibilityLevelCreateRequestDto = new ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto();

        resourceVisibilityLevelCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceVisibilityLevelCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceVisibilityLevelCreateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        resourceVisibilityLevelCreateRequestDto.setVisibilityLevel( arg0.getVisibilityLevel() );

        return resourceVisibilityLevelCreateRequestDto;
    }

    @Override
    public ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto mapUpdate(ResourceVisibilityLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto resourceVisibilityLevelUpdateRequestDto = new ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto();

        resourceVisibilityLevelUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        resourceVisibilityLevelUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        resourceVisibilityLevelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        resourceVisibilityLevelUpdateRequestDto.setResourceIdentifier( arg0.getResourceIdentifier() );
        resourceVisibilityLevelUpdateRequestDto.setVisibilityLevel( arg0.getVisibilityLevel() );

        return resourceVisibilityLevelUpdateRequestDto;
    }
}
