package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un emploi de paie.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollJobDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_GRADE_IDENTIFIER)
  private String gradeIdentifier;

  @JsonbProperty(JSON_GRADE_AS_STRING)
  private String gradeAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEmploiPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "emploiPaieChaine";

  /**
   * Identifiant json de {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
      PayrollJobGroupDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING =
      PayrollJobGroupDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #gradeIdentifier}.
   */
  public static final String JSON_GRADE_IDENTIFIER = "idGrade";

  /**
   * Identifiant json de {@link #gradeAsString}.
   */
  public static final String JSON_GRADE_AS_STRING = "gradeChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "emploi paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "emplois paie";
}
