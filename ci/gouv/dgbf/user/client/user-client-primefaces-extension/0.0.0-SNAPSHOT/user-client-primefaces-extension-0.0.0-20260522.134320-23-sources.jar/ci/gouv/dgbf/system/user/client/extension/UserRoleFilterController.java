package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserRoleFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link UserDto}.
 *
 * @author Christian
 */
@Dependent
public class UserRoleFilterController extends AbstractFilterController<UserRoleFilter> {

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  UserSelectOneController userSelectOneController;

  @Inject
  @Getter
  RoleSelectOneController roleSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public UserRoleFilterController() {
    super(UserRoleFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setUserIdentifier(getRequestParameter(UserRoleFilter.JSON_USER_IDENTIFIER));

    userSelectOneController.getSelectOneMenu().addValueConsumer(
        identifier -> filter.setUserIdentifier(identifier)
    );

    roleSelectOneController.getSelectOneMenu().addValueConsumer(
        identifier -> filter.setRoleIdentifier(identifier)
    );
  }
}
