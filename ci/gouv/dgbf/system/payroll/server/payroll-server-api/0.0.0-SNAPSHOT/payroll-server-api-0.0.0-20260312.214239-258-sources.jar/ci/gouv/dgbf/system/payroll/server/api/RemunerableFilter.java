package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasFunctionaryIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsEnabled;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RemunerableDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class RemunerableFilter extends AbstractIdentifiableFilter
    implements FilterHasFunctionaryIdentifier, FilterHasRegistrationNumber, FilterHasIsEnabled {

  private String functionaryIdentifier;

  private String registrationNumber;

  private Boolean isEnabled;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RemunerableFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RemunerableFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateFunctionaryIdentifier(filter);
    updateRegistrationNumber(filter);
    updateIsEnabled(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterFunctionaryIdentifier(filter);
    updateFilterRegistrationNumber(filter);
    updateFilterIsEnabled(filter);
  }
}
