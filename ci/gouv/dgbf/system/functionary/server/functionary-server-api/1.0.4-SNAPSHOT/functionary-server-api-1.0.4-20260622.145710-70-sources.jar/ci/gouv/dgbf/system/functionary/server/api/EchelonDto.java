package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EchelonDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_CIVIL_SERVICE_STATUS_IDENTIFIER)
  private String civilServiceStatusIdentifier;

  @JsonbProperty(JSON_CIVIL_SERVICE_STATUS_AS_STRING)
  private String civilServiceStatusAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEchelon";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "echelonChaine";

  /**
   * Identifiant json de {@link #civilServiceStatusIdentifier}.
   */
  public static final String JSON_CIVIL_SERVICE_STATUS_IDENTIFIER =
      CivilServiceStatusDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #civilServiceStatusAsString}.
   */
  public static final String JSON_CIVIL_SERVICE_STATUS_AS_STRING =
      CivilServiceStatusDto.JSON_THIS_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "echélon";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
