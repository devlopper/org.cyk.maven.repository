package ci.gouv.dgbf.system.budgetaryclassification.client.extension.act;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.AbstractExpenditureOrResourceItemDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureItemService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ExpenditureItemDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ExpenditureItemController extends AbstractController {

  @Inject
  ExpenditureItemClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ExpenditureItemFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ExpenditureItemDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(ExpenditureItemDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ExpenditureItemService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractExpenditureOrResourceItemDto.JSON_EXERCISE_AS_STRING,
        ExpenditureItemDto.JSON_ACTIVITY_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_ECONOMIC_NATURE_AS_STRING,
        ExpenditureItemDto.JSON_FUNDING_SOURCE_AS_STRING, ExpenditureItemDto.JSON_LESSOR_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_INITIAL_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_ACTUAL_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_EXECUTION_PRERESERVED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_PRERESERVED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_ELABORATION_RESERVED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_EXECUTION_RESERVED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_RESERVED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_EXECUTED_PLANNED_BUDGET_AS_STRING,
        AbstractExpenditureOrResourceItemDto.JSON_REMAINING_EXECUTED_PLANNED_BUDGET_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getShowCreateDialogButton().setRendered(false);
    listController.getDataTable().getActionColumn().setRendered(false);
  }
}
