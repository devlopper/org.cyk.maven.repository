package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipTypeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayslipTypeFilter extends AbstractIdentifiableFilter {

  /**
   * Cette méthode permet d'instantier.
   *
   * @param dto {@link FilterDto}
   */
  public PayslipTypeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier.
   *
   */
  public PayslipTypeFilter() {}
}
