package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.GeographicZoneService.GeographicZoneCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.GeographicZoneService.GeographicZoneGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.GeographicZoneService.GeographicZoneUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link GeographicZoneService}.
 *
 * @author arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class GeographicZoneClient extends AbstractClient<GeographicZoneService>
        implements GetByIdentifier<GeographicZoneDto>, GetMany<GeographicZoneGetManyResponseDto>,
        DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public GeographicZoneClient service(GeographicZoneService service) {
    return (GeographicZoneClient) super.service(service);
  }

  /**
   * {@link GeographicZoneService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(GeographicZoneCreateRequestDto request) {
    return new CreateExecutor(GeographicZoneService.CREATE_IDENTIFIER)
                .execute(() -> service().create(request));
  }

  /**
   * {@link GeographicZoneService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GeographicZoneGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GeographicZoneGetManyResponseDto>(
        GeographicZoneGetManyResponseDto.class,
            GeographicZoneService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link GeographicZoneService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GeographicZoneGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
        PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link GeographicZoneService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public GeographicZoneDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<GeographicZoneDto>(GeographicZoneDto.class,
            GeographicZoneService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link GeographicZoneService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public GeographicZoneDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
        String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link GeographicZoneService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public GeographicZoneDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<GeographicZoneDto>(GeographicZoneDto.class,
            GeographicZoneService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link GeographicZoneService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GeographicZoneDto getByIdentifier(String identifier, 
        ProjectionDto projection, String auditWho,
            String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link GeographicZoneService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(GeographicZoneUpdateRequestDto request) {
    return new IdentifiableExecutor(GeographicZoneService.UPDATE_IDENTIFIER)
                .execute(() -> service().update(request));
  }

  /**
   * {@link GeographicZoneService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(GeographicZoneService.DELETE_IDENTIFIER)
                .execute(() -> service().delete(request));
  }

  /**
   * {@link GeographicZoneService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
            String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}