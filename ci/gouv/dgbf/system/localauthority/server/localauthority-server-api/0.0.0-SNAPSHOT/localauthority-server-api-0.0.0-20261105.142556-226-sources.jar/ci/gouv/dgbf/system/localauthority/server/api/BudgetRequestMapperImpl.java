package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetDto}.
*
* @author Donsylla
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T14:26:42+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetRequestMapperImpl implements BudgetRequestMapper {

    @Override
    public BudgetService.BudgetCreateRequestDto mapCreate(BudgetDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetService.BudgetCreateRequestDto budgetCreateRequestDto = new BudgetService.BudgetCreateRequestDto();

        budgetCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetCreateRequestDto.setType( arg0.getType() );
        budgetCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        budgetCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        budgetCreateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );

        return budgetCreateRequestDto;
    }

    @Override
    public BudgetService.BudgetUpdateRequestDto mapUpdate(BudgetDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetService.BudgetUpdateRequestDto budgetUpdateRequestDto = new BudgetService.BudgetUpdateRequestDto();

        budgetUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        budgetUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        budgetUpdateRequestDto.setTriennialProgramIdentifier( arg0.getTriennialProgramIdentifier() );

        return budgetUpdateRequestDto;
    }
}
