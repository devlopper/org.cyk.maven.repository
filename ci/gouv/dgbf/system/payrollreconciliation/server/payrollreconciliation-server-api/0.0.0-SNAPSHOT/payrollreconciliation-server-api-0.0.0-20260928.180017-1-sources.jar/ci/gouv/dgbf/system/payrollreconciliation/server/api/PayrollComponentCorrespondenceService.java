package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollComponentCorrespondenceDto}.
 * Référentiel propre à RAP avec CRUD complet.
 *
 * @author desysoft
 *
 */
@Path(value = PayrollComponentCorrespondenceService.PATH)
@Tag(name = "Gestion des correspondances poste solde AN 2000 → poste de paie")
public interface PayrollComponentCorrespondenceService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "correspondances-poste-solde-an-2000";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollComponentCorrespondenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une correspondance",
      description = "Création d'une correspondance poste solde AN 2000 → poste de paie")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollComponentCorrespondenceCreateRequestDto request);

  /**
   * Cette interface représente les données d'enregistrement (création et mise à jour) d'une
   * correspondance.
   *
   * @author desysoft
   *
   */
  interface PayrollComponentCorrespondenceSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir le code du poste solde AN 2000.
     *
     * @return code du poste solde AN 2000
     */
    String getLegacyComponentCode();

    /**
     * Cette méthode permet d'assigner le code du poste solde AN 2000.
     *
     * @param legacyComponentCode code du poste solde AN 2000
     */
    void setLegacyComponentCode(String legacyComponentCode);

    /**
     * Cette méthode permet d'obtenir le code de la catégorie solde AN 2000.
     *
     * @return code de la catégorie solde AN 2000
     */
    String getLegacyCategoryCode();

    /**
     * Cette méthode permet d'assigner le code de la catégorie solde AN 2000.
     *
     * @param legacyCategoryCode code de la catégorie solde AN 2000
     */
    void setLegacyCategoryCode(String legacyCategoryCode);

    /**
     * Cette méthode permet d'obtenir le code de l'échelle corps(emploi) solde AN 2000.
     *
     * @return code de l'échelle corps(emploi) solde AN 2000
     */
    String getLegacyScaleCode();

    /**
     * Cette méthode permet d'assigner le code de l'échelle corps(emploi) solde AN 2000.
     *
     * @param legacyScaleCode code de l'échelle corps(emploi) solde AN 2000
     */
    void setLegacyScaleCode(String legacyScaleCode);

    /**
     * Cette méthode permet d'obtenir le code du poste de paie.
     *
     * @return code du poste de paie
     */
    String getPayrollComponentCode();

    /**
     * Cette méthode permet d'assigner le code du poste de paie.
     *
     * @param payrollComponentCode code du poste de paie
     */
    void setPayrollComponentCode(String payrollComponentCode);

    /**
     * Cette méthode permet d'obtenir si le poste est un gain.
     *
     * @return si le poste est un gain
     */
    Boolean getEarning();

    /**
     * Cette méthode permet d'assigner si le poste est un gain.
     *
     * @param earning si le poste est un gain
     */
    void setEarning(Boolean earning);
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author desysoft
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {
      PayrollComponentCorrespondenceDto.JSON_LEGACY_COMPONENT_CODE,
      PayrollComponentCorrespondenceDto.JSON_LEGACY_CATEGORY_CODE,
      PayrollComponentCorrespondenceDto.JSON_LEGACY_SCALE_CODE,
      PayrollComponentCorrespondenceDto.JSON_PAYROLL_COMPONENT_CODE,
      PayrollComponentCorrespondenceDto.JSON_EARNING,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION
  })
  class PayrollComponentCorrespondenceCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayrollComponentCorrespondenceSaveRequestDto {
    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_COMPONENT_CODE)
    private String legacyComponentCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_CATEGORY_CODE)
    private String legacyCategoryCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_SCALE_CODE)
    private String legacyScaleCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_PAYROLL_COMPONENT_CODE)
    private String payrollComponentCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_EARNING)
    private Boolean earning;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollComponentCorrespondenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des correspondances")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = PayrollComponentCorrespondenceGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de
   * plusieurs.
   *
   * @author desysoft
   *
   */
  @Getter
  @Setter
  public static class PayrollComponentCorrespondenceGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollComponentCorrespondenceDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollComponentCorrespondenceDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PayrollComponentCorrespondenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une correspondance")
  @APIResponse(responseCode = "200",
      content = {@Content(schema =
          @Schema(implementation = PayrollComponentCorrespondenceDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de comptage.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Chemin du service de comptage.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le nombre de correspondances correspondant au filtre.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN, MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollComponentCorrespondenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une correspondance")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollComponentCorrespondenceUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author desysoft
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {
      ByIdentifierRequestDto.FIELD_IDENTIFIER,
      PayrollComponentCorrespondenceDto.JSON_LEGACY_COMPONENT_CODE,
      PayrollComponentCorrespondenceDto.JSON_LEGACY_CATEGORY_CODE,
      PayrollComponentCorrespondenceDto.JSON_LEGACY_SCALE_CODE,
      PayrollComponentCorrespondenceDto.JSON_PAYROLL_COMPONENT_CODE,
      PayrollComponentCorrespondenceDto.JSON_EARNING,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_WHO,
      AbstractAuditedRequestJsonDto.FIELD_AUDIT_SESSION
  })
  class PayrollComponentCorrespondenceUpdateRequestDto extends ByIdentifierRequestDto
      implements PayrollComponentCorrespondenceSaveRequestDto {
    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_COMPONENT_CODE)
    private String legacyComponentCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_CATEGORY_CODE)
    private String legacyCategoryCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_LEGACY_SCALE_CODE)
    private String legacyScaleCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_PAYROLL_COMPONENT_CODE)
    private String payrollComponentCode;

    @JsonbProperty(PayrollComponentCorrespondenceDto.JSON_EARNING)
    private Boolean earning;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CORRESPONDANCE_POSTE_SOLDE_AN_2000";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollComponentCorrespondenceDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une correspondance")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
