package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ResourceVisibilityLevelFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link ResourceDto}.
   */
  private String resourceIdentifier;

  /**
   * {@link VisibilityLevel} par défaut.
   */
  private VisibilityLevel visibilityLevel;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ResourceVisibilityLevelFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ResourceVisibilityLevelFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    resourceIdentifier = getResourceIdentifier(filter);
    visibilityLevel = getVisibilityLevel(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setResourceIdentifier(filter, resourceIdentifier);
    setVisibilityLevel(filter, visibilityLevel);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ResourceDto}.
   *
   * @param filter filtre
   * @param resourceIdentifier identifiant {@link ResourceDto}
   */
  public static void setResourceIdentifier(FilterDto filter, String resourceIdentifier) {
    set(filter, JSON_RESOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(resourceIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ResourceDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ResourceDto}
   */
  public static String getResourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_RESOURCE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le {@link VisibilityLevel}.
   *
   * @param filter filtre
   * @param visibilityLevel {@link VisibilityLevel}
   */
  public static void setVisibilityLevel(FilterDto filter, VisibilityLevel visibilityLevel) {
    set(filter, JSON_VISIBILITY_LEVEL, f -> f.getValueAsString(),
        f -> f.setValueAsEnum(visibilityLevel));
  }

  /**
   * Cette méthode permet d'obtenir le {@link VisibilityLevel}.
   *
   * @param filter filtre
   * @return {@link VisibilityLevel}
   */
  public static VisibilityLevel getVisibilityLevel(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_VISIBILITY_LEVEL, VisibilityLevel.class));
  }

  /**
   * Identifiant json champ {@link #resourceIdentifier}.
   */
  public static final String JSON_RESOURCE_IDENTIFIER =
      ResourceVisibilityLevelDto.JSON_RESOURCE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #visibilityLevel}.
   */
  public static final String JSON_VISIBILITY_LEVEL =
      ResourceVisibilityLevelDto.JSON_VISIBILITY_LEVEL;
}
