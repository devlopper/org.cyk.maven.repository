package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette classe représente les codes de {@link PayrollStatus}.
 *
 * @author A.K.M
 *
 */
public class PayrollStatusCode {

  private PayrollStatusCode() {
    
  }
    
  /**
   * Créée.
   */
  public static final String CREATED = "CREEE";
  
  /**
   * Initialisée.
   */
  public static final String INITIALIZED = "INITIALISEE";
  
  /**
   * Transmis pour Controle.
   */
  public static final String TRANSMITTED_FOR_CONTROL = "TRANSMIS_POUR_CONTROLE";
  
  /**
   * Controlée.
   */
  public static final String CONTROLLED = "CONTROLEE";
  
  /**
   * Transmis pour arbitrage.
   */
  public static final String TRANSMITTED_FOR_ARBITRATION = "TRANSMIS_POUR_ARBITRAGE";
  
  /**
   * Arbitrée.
   */
  public static final String ARBITRATED = "ARBITREE";
  
  /**
   * Clôturée.
   */
  public static final String CLOSED = "CLOTUREE";
}
