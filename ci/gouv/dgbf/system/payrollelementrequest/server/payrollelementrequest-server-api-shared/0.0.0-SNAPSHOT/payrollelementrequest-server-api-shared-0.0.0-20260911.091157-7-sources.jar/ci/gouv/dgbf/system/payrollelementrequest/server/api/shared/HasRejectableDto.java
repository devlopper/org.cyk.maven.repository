package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action
 * Rejeter (RG_REP_PEC_05) sur une réponse de traitement (motif R44/R45).
 *
 * @author akm
 *
 */
public interface HasRejectableDto {

  /**
   * Identifiant json de {@link #getRejectable()}.
   */
  String JSON_REJECTABLE = "rejetable";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Rejeter.
   *
   * @return indicateur de disponibilité de l'action Rejeter
   */
  Boolean getRejectable();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Rejeter.
   *
   * @param rejectable indicateur de disponibilité de l'action Rejeter
   */
  void setRejectable(Boolean rejectable);
}
