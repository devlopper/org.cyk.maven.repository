package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasValueSelectorIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ValueSelectorDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ValueSelectorFilterAttributeService.PATH)
@Tag(name = "Gestion d'attribut de filtre de sélecteur de valeur")
public interface ValueSelectorFilterAttributeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "attributs-filtres-selecteurs-valeurs";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ValueSelectorFilterAttributeSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du sélecteur de valeur.
     *
     * @return l'identifiant du sélecteur de valeur
     */
    String getValueSelectorIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du sélecteur de valeur.
     *
     * @param valueSelectorIdentifier l'identifiant du sélecteur de valeur
     */
    void setValueSelectorIdentifier(String valueSelectorIdentifier);

    /**
     * {@link HasValueSelectorIdentifierDto#JSON_VALUE_SELECTOR_IDENTIFIER}.
     */
    String JSON_VALUE_SELECTOR_IDENTIFIER =
        HasValueSelectorIdentifierDto.JSON_VALUE_SELECTOR_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ValueSelectorFilterAttributeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorFilterAttributeCreateRequestDto
      extends AbstractCodableNamableCreateRequestJsonDto
      implements ValueSelectorFilterAttributeSaveRequestDto {

    @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
    private String valueSelectorIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = ValueSelectorFilterAttributeGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ValueSelectorFilterAttributeGetManyResponseDto
      extends AbstractGetByPageResponseDto<ValueSelectorFilterAttributeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ValueSelectorFilterAttributeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ValueSelectorDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ValueSelectorFilterAttributeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ValueSelectorFilterAttributeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ValueSelectorFilterAttributeUpdateRequestDto
      extends AbstractCodableNamableUpdateRequestJsonDto
      implements ValueSelectorFilterAttributeSaveRequestDto {

    @JsonbProperty(JSON_VALUE_SELECTOR_IDENTIFIER)
    private String valueSelectorIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ATTRIBUT_FILTRE_SELECTEUR_VALEUR";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ValueSelectorFilterAttributeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
