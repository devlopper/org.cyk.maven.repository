package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.FilterSearchTextController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentGroupFilterController extends AbstractFilterController<DocumentGroupFilter> {

  @Inject
  @Getter
  FilterSearchTextController searchTextController;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentGroupFilterController() {
    super(DocumentGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    searchTextController.initialize(filter);
  }
}
