package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupService.DocumentGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentGetManyResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentService.DocumentUpdateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de dépôt des pièces attendues d'un groupe de types de
 * document.
 *
 * <p>À la sélection d'un groupe de types de document, elle construit un dépôt attendu par type
 * de document rattaché à ce groupe. Chaque fichier déposé devient un
 * {@link ci.gouv.dgbf.system.documentation.server.api.DocumentDto} rattaché au groupe créé, via
 * {@link #createDocuments(String)} appelé après la création du groupe. Une indisponibilité du
 * module {@code documentation} ou {@code file} est journalisée sans bloquer l'ouverture du
 * formulaire.
 *
 * <p>Le fragment associé est {@code /private/documenttypegroup/component/upload.xhtml}, livré par
 * ce même module ; il est piloté par le {@code ui:param name="controller"} pointant vers une
 * instance de cette classe.
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentTypeGroupUploadController extends AbstractController {

  /**
   * Classe CSS portée par le {@code p:dataTable} du fragment.
   */
  public static final String PANEL_STYLE_CLASS = "expected-documents-panel";

  /**
   * Sélecteur PrimeFaces du panneau des dépôts, à utiliser comme cible de rafraîchissement ajax
   * ({@code update}) depuis le contrôleur de la page hôte.
   */
  public static final String PANEL_SELECTOR = "@(." + PANEL_STYLE_CLASS + ")";

  @Inject
  DocumentTypeGroupClient documentTypeGroupClient;

  @Inject
  DocumentGroupClient documentGroupClient;

  @Inject
  DocumentClient documentClient;

  @Inject
  FileClient fileClient;

  @Getter
  List<Upload> uploads;

  /**
   * Identifiant du groupe de types ayant servi à construire {@link #uploads}, pour ne
   * reconstruire les dépôts que lorsque la sélection change réellement.
   */
  String currentTypesGroupIdentifier;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentTypeGroupUploadController() {
    uploads = new ArrayList<>();
  }

  /**
   * Cette méthode permet de reconstruire la liste des dépôts attendus à partir du groupe de
   * types de document sélectionné. Une indisponibilité du module {@code documentation} est
   * journalisée et retombe sur une liste vide.
   *
   * <p>La reconstruction n'a lieu que si le groupe de types a changé : le consommateur de valeur
   * du sélecteur est aussi invoqué à la soumission du formulaire (phase de mise à jour du
   * modèle), et reconstruire à ce moment-là perdrait les fichiers déjà déposés avant que
   * {@link #createDocuments(String)} ne s'exécute.
   *
   * @param typesGroupIdentifier identifiant du groupe de types de document
   */
  public void refresh(String typesGroupIdentifier) {
    if (Objects.equals(currentTypesGroupIdentifier, typesGroupIdentifier)) {
      return;
    }
    currentTypesGroupIdentifier = typesGroupIdentifier;
    uploads.clear();
    if (typesGroupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentTypeGroupDto.JSON_TYPE_IDENTIFIER, DocumentTypeGroupDto.JSON_TYPE_AS_STRING);
    FilterDto filter = new FilterDto().addCriteria(DocumentTypeGroupDto.JSON_GROUP_IDENTIFIER,
        typesGroupIdentifier);
    DocumentTypeGroupGetManyResponseDto response;
    try {
      response = documentTypeGroupClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des pièces attendues pour le groupe de types " + typesGroupIdentifier
              + " en échec.",
          exception);
      return;
    }
    if (response != null && response.getDatas() != null) {
      response.getDatas().forEach(rattachement -> uploads.add(
          new Upload(rattachement.getTypeIdentifier(), rattachement.getTypeAsString())));
    }
  }

  /**
   * Cette méthode permet de compléter la liste des dépôts attendus (déjà reconstruite via
   * {@link #refresh(String)}) avec les documents déjà déposés dans un groupe de document
   * existant — utilisé à l'ouverture d'un formulaire de modification d'une entité existante. Une
   * indisponibilité du module {@code documentation} ne doit pas empêcher cette ouverture : on se
   * contente de journaliser et de retomber sur la liste des dépôts attendus sans documents déjà
   * déposés, comme {@link #refresh(String)}/{@link #resolveFile(String)}.
   *
   * @param groupIdentifier identifiant du groupe de document
   */
  public void loadExistingDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        DocumentDto.JSON_TYPE_IDENTIFIER, DocumentDto.JSON_FILE_IDENTIFIER);
    FilterDto filter =
        new FilterDto().addCriteria(DocumentDto.JSON_GROUP_IDENTIFIER, groupIdentifier);
    DocumentGetManyResponseDto response;
    try {
      response = documentClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des documents du groupe " + groupIdentifier + " en échec.", exception);
      return;
    }
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(document -> uploads.stream()
        .filter(upload -> upload.getTypeIdentifier().equals(document.getTypeIdentifier()))
        .findFirst().ifPresent(upload -> {
          // Conservés pour permettre à syncDocuments(String) de distinguer un dépôt déjà
          // persisté (à mettre à jour ou supprimer) d'un dépôt nouvellement déposé (à créer), et
          // de détecter un remplacement de fichier.
          upload.setDocumentIdentifier(document.getIdentifier());
          upload.setOriginalFileIdentifier(document.getFileIdentifier());
          upload.setFileIdentifier(document.getFileIdentifier());
          FileDto file = resolveFile(document.getFileIdentifier());
          upload.setFileName(file == null ? document.getFileIdentifier() : file.getName());
        }));
  }

  /**
   * Cette méthode permet d'obtenir le fichier déjà déposé pour un document existant, à partir de
   * son identifiant — une indisponibilité du module {@code file} ne doit pas empêcher l'ouverture
   * du formulaire de modification (le dépôt reste consultable/modifiable même si son nom de
   * fichier ne peut pas être affiché) : on se contente de journaliser et de retomber sur
   * l'identifiant brut du fichier (cf. {@link #loadExistingDocuments(String)}).
   *
   * @param fileIdentifier identifiant du fichier
   * @return le fichier, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private FileDto resolveFile(String fileIdentifier) {
    try {
      return fileClient.getByIdentifier(fileIdentifier,
          new ProjectionDto().addNames(FileDto.JSON_NAME), userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention du fichier " + fileIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de déposer un fichier pour un dépôt attendu. Le dépôt concerné est
   * retrouvé via l'attribut {@code typeIdentifier} posé sur le composant ({@code p:fileUpload}
   * n'expose pas de variable EL implicite permettant de le passer autrement).
   *
   * @param event évènement de dépôt de fichier
   */
  public void upload(FileUploadEvent event) {
    String typeIdentifier =
        (String) event.getComponent().getAttributes().get(ATTRIBUTE_TYPE_IDENTIFIER);
    Upload upload = uploads.stream()
        .filter(candidate -> candidate.getTypeIdentifier().equals(typeIdentifier)).findFirst()
        .orElse(null);
    if (upload == null) {
      Logger.getLogger(getClass().getName()).log(Level.WARNING,
          "Dépôt de fichier reçu pour un type de pièce non résolu : {0}", typeIdentifier);
      return;
    }
    try {
      String fileIdentifier = fileClient.getIdentifierByBytesOrByCreate(
          event.getFile().getFileName(), event.getFile().getContent(), userIdentifier, null);
      upload.setFileIdentifier(fileIdentifier);
      upload.setFileName(event.getFile().getFileName());
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Dépôt du fichier " + event.getFile().getFileName() + " pour la pièce "
              + typeIdentifier + " en échec.",
          exception);
      throw exception;
    }
  }

  /**
   * Nom de l'attribut du composant {@code p:fileUpload} portant l'identifiant du type de document
   * concerné.
   */
  public static final String ATTRIBUTE_TYPE_IDENTIFIER = "typeIdentifier";

  /**
   * Cette méthode permet de retirer le fichier déposé pour un dépôt attendu.
   *
   * @param upload dépôt attendu
   */
  public void remove(Upload upload) {
    upload.setFileIdentifier(null);
    upload.setFileName(null);
  }

  /**
   * Cette méthode permet de créer le groupe de document porteur des pièces attendues. L'entité
   * consommatrice n'existe pas encore à cet instant lorsqu'elle a besoin de connaître
   * l'identifiant du groupe dès sa propre création (ex. pour le stocker sur elle-même) :
   * l'identifiant d'enregistrement transmis au module {@code documentation} est donc un
   * identifiant de corrélation généré ici, sans lien de clé étrangère avec l'entité
   * consommatrice.
   *
   * @param typesGroupIdentifier identifiant du groupe de types de document attendu
   * @param processIdentifier identifiant du processus métier consommateur
   * @param sourceIdentifier identifiant du module source consommateur
   * @param operationIdentifier identifiant de l'opération métier consommatrice
   * @return identifiant du groupe de document créé
   */
  public String createDocumentGroup(String typesGroupIdentifier, String processIdentifier,
      String sourceIdentifier, String operationIdentifier) {
    DocumentGroupCreateRequestDto request = new DocumentGroupCreateRequestDto();
    request.setTypeGroupIdentifier(typesGroupIdentifier);
    request.setProcessIdentifier(processIdentifier);
    request.setSourceIdentifier(sourceIdentifier);
    request.setRecordIdentifier(UUID.randomUUID().toString());
    request.setOperationIdentifier(operationIdentifier);
    request.setAuditWho(userIdentifier);
    CreateResponseDto response = documentGroupClient.create(request);
    return response.getIdentifier();
  }

  /**
   * Cette méthode permet de créer, dans le groupe de document, un document pour chaque dépôt
   * attendu dont un fichier a été déposé.
   *
   * @param groupIdentifier identifiant du groupe de document créé
   */
  public void createDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    uploads.stream().filter(upload -> upload.getFileIdentifier() != null)
        .forEach(upload -> {
          DocumentCreateRequestDto request = new DocumentCreateRequestDto();
          request.setTypeIdentifier(upload.getTypeIdentifier());
          request.setGroupIdentifier(groupIdentifier);
          request.setFileIdentifier(upload.getFileIdentifier());
          request.setAuditWho(userIdentifier);
          documentClient.create(request);
        });
    reset();
  }

  /**
   * Cette méthode permet de synchroniser, en modification d'une entité existante, les documents
   * du groupe avec l'état courant des dépôts attendus : création des pièces nouvellement
   * déposées, mise à jour de celles dont le fichier a été remplacé, et suppression de celles
   * retirées par l'utilisateur.
   *
   * @param groupIdentifier identifiant du groupe de document
   */
  public void syncDocuments(String groupIdentifier) {
    if (groupIdentifier == null) {
      return;
    }
    uploads.forEach(upload -> {
      if (upload.getDocumentIdentifier() == null) {
        if (upload.getFileIdentifier() != null) {
          DocumentCreateRequestDto request = new DocumentCreateRequestDto();
          request.setTypeIdentifier(upload.getTypeIdentifier());
          request.setGroupIdentifier(groupIdentifier);
          request.setFileIdentifier(upload.getFileIdentifier());
          request.setAuditWho(userIdentifier);
          documentClient.create(request);
        }
      } else if (upload.getFileIdentifier() == null) {
        documentClient.deleteByIdentifier(upload.getDocumentIdentifier(), userIdentifier, null);
      } else if (!upload.getFileIdentifier().equals(upload.getOriginalFileIdentifier())) {
        DocumentUpdateRequestDto request = new DocumentUpdateRequestDto();
        request.setIdentifier(upload.getDocumentIdentifier());
        request.setTypeIdentifier(upload.getTypeIdentifier());
        request.setGroupIdentifier(groupIdentifier);
        request.setFileIdentifier(upload.getFileIdentifier());
        request.setAuditWho(userIdentifier);
        documentClient.update(request);
      }
    });
  }

  /**
   * Cette méthode permet de vider les dépôts, afin que la prochaine création reparte d'un
   * formulaire vierge.
   */
  public void reset() {
    uploads.clear();
    currentTypesGroupIdentifier = null;
  }

  /**
   * Cette classe représente un dépôt attendu (un type de pièce), avec le fichier éventuellement
   * déposé.
   *
   * @author si.kimou
   *
   */
  @Getter
  @Setter
  public static class Upload {

    String typeIdentifier;
    String typeAsString;
    String fileIdentifier;
    String fileName;

    /**
     * Identifiant du document déjà persisté pour ce dépôt (renseigné par
     * {@link #loadExistingDocuments(String)}), ou {@code null} si aucun document n'existe encore
     * en base pour ce dépôt.
     */
    String documentIdentifier;

    /**
     * Identifiant du fichier tel que chargé depuis le document existant (renseigné par
     * {@link #loadExistingDocuments(String)}), utilisé par {@link #syncDocuments(String)} pour
     * détecter un remplacement de fichier.
     */
    String originalFileIdentifier;

    /**
     * Cette méthode permet de construire.
     *
     * @param typeIdentifier identifiant du type de document attendu
     * @param typeAsString libellé du type de document attendu
     */
    public Upload(String typeIdentifier, String typeAsString) {
      this.typeIdentifier = typeIdentifier;
      this.typeAsString = typeAsString;
    }
  }
}
