package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasConditionsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasOrderNumberDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesMapDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une valeur conditionnée.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ConditionalValueDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasGroupIdentifierDto, HasGroupAsStringDto, HasStringValueDto, HasValueTypeDto,
    HasValueTypeAsStringDto, HasConditionsCountAsStringDto, HasOrderNumberDto,
    HasValuesMapDto<String, Object> {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_VALUE)
  private String value;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  @JsonbProperty(JSON_CONDITIONS_COUNT_AS_STRING)
  private String conditionsCountAsString;

  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  private Map<String, Object> valuesMap;
  
  /**
   * Valeur de filtre.
   */
  private String filterValue;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idValeurConditionnee";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "valeurConditionneeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "valeur conditionée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "valeurs conditionée";
}
