package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasIntegratedAmountN}.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountNDto extends HasIntegratedAmountN {

  /**
   * Identifiant json du montant intégré à l'horizon N.
   */
  String JSON_INTEGRATED_AMOUNT_N = "montantIntegreN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
