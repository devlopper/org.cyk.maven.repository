package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.SsoApplicationService.SsoApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.SsoApplicationService.SsoApplicationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SsoApplicationDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SsoApplicationDto}.
    
    @author BoobaCool
    """)
public interface SsoApplicationRequestMapper extends
    RequestMapper<SsoApplicationDto, SsoApplicationCreateRequestDto,
        SsoApplicationUpdateRequestDto> {

}
