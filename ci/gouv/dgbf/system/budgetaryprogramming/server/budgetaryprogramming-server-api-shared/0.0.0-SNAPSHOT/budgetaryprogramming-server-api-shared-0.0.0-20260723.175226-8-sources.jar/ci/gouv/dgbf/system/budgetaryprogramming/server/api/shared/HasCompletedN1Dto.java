package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+1 est complétée.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN1Dto extends HasCompletedN1 {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N+1 est complétée.
   */
  String JSON_COMPLETED_N1 = "completeN1";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
