package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ExpenditureActivityDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class ExpenditureActivitySelectOneController extends AbstractSelectOneIdentifiableController<
    ExpenditureActivityDto, GetManyResponseDto, ExpenditureActivityClient> {

  @Inject
  @Getter
  ExpenditureActivityClient client;

  protected ExpenditureActivitySelectOneController() {
    super(ExpenditureActivityDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
