package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat du partage du travail : quels types de mouvement un membre d'équipe instruit.
 *
 * <p><strong>Confier et retirer, jamais modifier.</strong> Une association ne porte que ses deux
 * extrémités : la modifier reviendrait à la remplacer par une autre sous le même identifiant, et
 * l'audit ne saurait plus lire ce qui a été décidé.</p>
 *
 * <p><strong>Ce lien restreint, il n'accorde pas.</strong> Le droit d'instruire vient du jeton, et
 * de lui seul. Confier les rappels à quelqu'un qui ne porte pas {@code TRAITER_REGULARISATION} ne
 * lui ouvre rien ; le partage décrit qui fait quoi <em>parmi</em> ce que le jeton permet déjà.</p>
 *
 * <p><strong>Aucun lien vaut tout le périmètre du jeton.</strong> Un membre à qui l'on n'a rien
 * confié particulièrement instruit toute sa famille, comme avant que cette table n'existe. Sans
 * cette règle, le jour où la table naît vide, plus personne n'instruirait rien.</p>
 *
 * @author Christian
 *
 */
@Path(value = ArbitrationTeamMemberMovementTypeService.PATH)
@Tag(name = "Gestion des types de mouvement des membres")
public interface ArbitrationTeamMemberMovementTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "types-mouvements-membres";

  /**
   * Ce que porte la requête, au-delà de ce que la classe parente apporte.
   *
   * <p>Le concept n'expose pas de mise à jour : l'interface ne factorise donc
   * rien, mais elle tient le contrat des champs et dispense la requête de
   * nommer le {@link ArbitrationTeamMemberMovementTypeDto} à chaque clé.</p>
   *
   * <p>Il n'y a pas de {@code ArbitrationTeamMemberMovementTypeRequestMapper} pour autant :
   * R50 ne le prévoit
   * que là où la création <em>et</em> la mise à jour existent toutes deux, un mapper
   * à un seul type de requête supposant une nouvelle classe générique dans
   * l'extension.</p>
   */
  interface ArbitrationTeamMemberMovementTypeSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le membre d'équipe.
     *
     * @return le membre d'équipe
     */
    String getMemberIdentifier();

    /**
     * Cette méthode permet d'assigner le membre d'équipe.
     *
     * @param memberIdentifier le membre d'équipe
     */
    void setMemberIdentifier(String memberIdentifier);

    /**
     * Cette méthode permet d'obtenir le type de mouvement.
     *
     * @return le type de mouvement
     */
    String getMovementTypeIdentifier();

    /**
     * Cette méthode permet d'assigner le type de mouvement.
     *
     * @param movementTypeIdentifier le type de mouvement
     */
    void setMovementTypeIdentifier(String movementTypeIdentifier);

    /**
     * {@link ArbitrationTeamMemberMovementTypeDto#JSON_MEMBER_IDENTIFIER}.
     */
    String JSON_MEMBER_IDENTIFIER = ArbitrationTeamMemberMovementTypeDto.JSON_MEMBER_IDENTIFIER;

    /**
     * {@link ArbitrationTeamMemberMovementTypeDto#JSON_MOVEMENT_TYPE_IDENTIFIER}.
     */
    String JSON_MOVEMENT_TYPE_IDENTIFIER =
        ArbitrationTeamMemberMovementTypeDto.JSON_MOVEMENT_TYPE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ArbitrationTeamMemberMovementTypeDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_TYPE_MOUVEMENT_MEMBRE";

  /**
   * Chemin du service de création unitaire de {@link ArbitrationTeamMemberMovementTypeDto}.
   */
  String CREATE_PATH = "";

  /**
   * Confie un type de mouvement à un membre d'équipe.
   *
   * @param request le type à confier
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Affectation d'un type de mouvement à un membre d'équipe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ArbitrationTeamMemberMovementTypeCreateRequestDto request);

  /**
   * Requête d'affectation d'un type de mouvement à un membre.
   */
  @Getter
  @Setter
  class ArbitrationTeamMemberMovementTypeCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ArbitrationTeamMemberMovementTypeSaveRequestDto {

    @JsonbProperty(JSON_MEMBER_IDENTIFIER)
    private String memberIdentifier;

    @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
    private String movementTypeIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ArbitrationTeamMemberMovementTypeDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_MOUVEMENT_MEMBRE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ArbitrationTeamMemberMovementTypeDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère du partage.
   *
   * @param request critères, projection et pagination
   * @return les types confiés correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation des types de mouvement confiés aux membres")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = ArbitrationTeamMemberMovementTypeGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de types confiés.
   */
  @Getter
  @Setter
  public static class ArbitrationTeamMemberMovementTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<ArbitrationTeamMemberMovementTypeDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ArbitrationTeamMemberMovementTypeDto> datas;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link
   * ArbitrationTeamMemberMovementTypeDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TYPE_MOUVEMENT_MEMBRE";

  /**
   * Chemin du service de suppression unitaire de {@link ArbitrationTeamMemberMovementTypeDto}.
   */
  String DELETE_PATH = "";

  /**
   * Retire un type de mouvement à un membre d'équipe.
   *
   * @param request l'identifiant de l'affectation à retirer
   * @return l'identifiant retiré
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      summary = "Retrait d'un type de mouvement à un membre d'équipe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
