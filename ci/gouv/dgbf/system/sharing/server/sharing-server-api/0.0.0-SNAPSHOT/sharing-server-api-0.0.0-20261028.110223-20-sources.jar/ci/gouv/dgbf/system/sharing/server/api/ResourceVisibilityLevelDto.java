package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le niveau de visibilité par défaut d'une ressource.
 * <p>
 * Une ressource sans niveau de visibilité par défaut est {@link VisibilityLevel#FULL}.
 * </p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceVisibilityLevelDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
  private String resourceIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ResourceDto}.
   */
  @JsonbProperty(JSON_RESOURCE_AS_STRING)
  private String resourceAsString;

  /**
   * {@link VisibilityLevel} par défaut.
   */
  @JsonbProperty(JSON_VISIBILITY_LEVEL)
  private VisibilityLevel visibilityLevel;

  /**
   * Représentation en chaine de caractères de {@link #visibilityLevel}.
   */
  @JsonbProperty(JSON_VISIBILITY_LEVEL_AS_STRING)
  private String visibilityLevelAsString;

  /**
   * Identifiant champ json {@link #resourceIdentifier}.
   */
  public static final String JSON_RESOURCE_IDENTIFIER = SharingDto.JSON_RESOURCE_IDENTIFIER;

  /**
   * Identifiant champ json {@link #resourceAsString}.
   */
  public static final String JSON_RESOURCE_AS_STRING = SharingDto.JSON_RESOURCE_AS_STRING;

  /**
   * Identifiant champ json {@link #visibilityLevel}.
   */
  public static final String JSON_VISIBILITY_LEVEL = SharingDto.JSON_VISIBILITY_LEVEL;

  /**
   * Identifiant champ json {@link #visibilityLevelAsString}.
   */
  public static final String JSON_VISIBILITY_LEVEL_AS_STRING =
      SharingDto.JSON_VISIBILITY_LEVEL_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "niveau de visibilité de ressource";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "niveaux de visibilité de ressource";
}
