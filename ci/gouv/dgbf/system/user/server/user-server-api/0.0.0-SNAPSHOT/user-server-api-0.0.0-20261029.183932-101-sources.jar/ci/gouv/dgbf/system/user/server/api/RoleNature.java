package ci.gouv.dgbf.system.user.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente la Nature de {@link RoleDto} (RG_UTI_ROL_18) : applicatif
 * (atomique, sans composant) ou métier (composite, au moins un composant). Modifiable après
 * création, exclusivement par l'Administrateur Applicatif (RG_UTI_ROL_21).
 *
 * @author Christian
 */
@Getter
public enum RoleNature {

  /**
   * {@link RoleNatureCode#APPLICATION_ROLE}.
   */
  APPLICATION_ROLE(RoleNatureCode.APPLICATION_ROLE, "Applicatif"),

  /**
   * {@link RoleNatureCode#BUSINESS_ROLE}.
   */
  BUSINESS_ROLE(RoleNatureCode.BUSINESS_ROLE, "Métier");

  private RoleNature(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link RoleNature} par code.
   *
   * @param code code
   * @return {@link RoleNature}
   */
  public static RoleNature getByCode(String code) {
    return Stream.of(RoleNature.values())
        .filter(nature -> nature.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
