package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractStatusManager;
import ci.gouv.dgbf.system.sharing.server.api.ConfidentialityLevel;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;

/** Gestionnaire des niveaux de confidentialite. */
@Named
@ApplicationScoped
public class ConfidentialityLevelManager extends AbstractStatusManager<ConfidentialityLevel> {
  /** Construit le gestionnaire. */
  public ConfidentialityLevelManager() {
    super(ConfidentialityLevel.class, ConfidentialityLevel::getName);
  }
}
