package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionUnitService.PartitionUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PartitionUnitDto}.
 *
 * @author Arnaud
 */
@Mapper
@Javadoc("""
                Cette interface représente le mapping de requête et {@link PartitionUnitDto}.

                @author Arnaud
                """)
public interface PartitionUnitRequestMapper extends
                RequestMapper<PartitionUnitDto, PartitionUnitCreateRequestDto, 
                PartitionUnitUpdateRequestDto> {

}
