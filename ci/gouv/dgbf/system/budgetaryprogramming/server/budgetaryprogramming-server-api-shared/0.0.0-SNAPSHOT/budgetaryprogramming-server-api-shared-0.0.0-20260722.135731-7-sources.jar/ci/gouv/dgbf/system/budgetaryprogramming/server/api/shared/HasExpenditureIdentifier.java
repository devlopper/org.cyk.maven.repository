package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de dépense.
 *
 * @author Christian
 */
public interface HasExpenditureIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la dépense.
   *
   * @return identifiant de la dépense
   */
  String getExpenditureIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la dépense.
   *
   * @param identifier identifiant de la dépense
   */
  void setExpenditureIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de la dépense.
   */
  String FIELD_EXPENDITURE_IDENTIFIER = "expenditureIdentifier";
}
