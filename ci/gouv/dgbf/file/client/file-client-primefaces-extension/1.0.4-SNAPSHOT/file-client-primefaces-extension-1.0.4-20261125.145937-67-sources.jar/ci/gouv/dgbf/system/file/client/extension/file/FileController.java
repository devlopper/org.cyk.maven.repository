package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController.FormLayout;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDescriptionProposalDto;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService;
import ci.gouv.dgbf.system.file.server.api.FileService.FileConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileStatus;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Set;
import java.util.function.UnaryOperator;
import lombok.Getter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileController extends AbstractController {

  @Inject
  FileClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileRequestMapper requestMapper;

  @Inject
  @Getter
  FileFilterController filterController;

  /**
   * Contrôleur du bouton de Confirmation (RG_FILE_FIC_09), affiché dans la colonne Action de la
   * liste. Sa priorité secondaire le place dans le menu « plus » lorsque la limite de trois
   * actions visibles est atteinte (RG_FILE_UI_03).
   */
  @Inject
  @Getter
  IdentifiableProcessingController confirmProcessingController;

  @Inject
  @Getter
  FileJournalDialogController journalDialogController;

  @Inject
  @Getter
  FileEvolutionController evolutionController;

  /**
   * Contrôleur partagé des champs de création d'un Fichier (natures autorisées, dépôt binaire,
   * proposition de description et exemplaire papier).
   */
  @Getter
  final FileCreateFormController fileCreateFormController = new FileCreateFormController();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Fichiers";

    fileCreateFormController.configure(client, () -> userIdentifier, this::createEntity);

    listController.setEntityClass(FileDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileDto.JSON_MODULE_IDENTIFIER,
        FileDto.JSON_NAME, FileDto.JSON_CONTENT_TYPE,
        FileDto.JSON_NUMBER_OF_BYTES_AS_STRING, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING,
        FileDto.JSON_MEDIUM_NATURE, FileDto.JSON_MEDIUM_NATURE_AS_STRING,
        FileDto.JSON_CONTENT_FORM, FileDto.JSON_CONTENT_FORM_AS_STRING,
        FileDto.JSON_DESCRIPTION, FileDto.JSON_PRODUCTION_DATE_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(6);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.getDataTable().setHeaderRendered(false);
    listController.getDataTable().setGlobalFilterRendered(true);
    listController.setFormLayout(FormLayout.STACKED);
    listController.initialize();

    initializeConfirmProcessing();
    evolutionController.setListController(listController);

    listController.getCreateController().setFunction(entity -> {
      FileCreateRequestDto request =
          fileCreateFormController.buildCreateRequest((FileDto) entity, userIdentifier);
      return client.create(request);
    });

    // Depuis l'onglet d'un module (TCH_FILE_554), le Fichier y est rattaché sans saisie : le module
    // de l'onglet est celui du filtre, renseigné par FileFilterController.
    listController.getCreateController().addEntityConsumer(entity -> {
      ((FileDto) entity).setModuleIdentifier(filterController.getFilter().getModuleIdentifier());
      resetPhysicalItemFields();
    });

    // Voir, Exemplaire papier (Fichier hybride), Journal, Supprimer, et Confirmer (Fichier Créé).
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(6);
    listController.getShowUpdateDialogButton().setRendered(false);
  }

  /**
   * Obtient les natures de support autorisées à la création.
   *
   * @return natures autorisées
   */
  public Set<MediumNature> getAllowedMediumNatures() {
    return fileCreateFormController.getAllowedMediumNatures();
  }

  /**
   * Définit les natures de support autorisées dans le formulaire de création.
   *
   * @param natures ensemble non vide des natures autorisées
   */
  public void setAllowedMediumNatures(Set<MediumNature> natures) {
    fileCreateFormController.setAllowedMediumNatures(natures);
  }

  /**
   * Autorise toutes les natures de support (numérique, papier et hybride) dans le formulaire de
   * création.
   */
  public void allowAllMediumNatures() {
    fileCreateFormController.allowAllMediumNatures();
  }

  /**
   * Indique si la section de choix de la nature du support est affichée.
   *
   * @return {@code true} si au moins deux natures sont autorisées
   */
  public boolean isMediumNatureSelectionRendered() {
    return fileCreateFormController.isMediumNatureSelectionRendered();
  }

  /**
   * Options de nature du support affichées dans le formulaire de création.
   *
   * @return liste des options
   */
  public List<SelectItem> getMediumNatureSelectItems() {
    return fileCreateFormController.getMediumNatureSelectItems();
  }

  /**
   * Description affichée en tête du formulaire de création, adaptée au module et aux natures
   * autorisées.
   *
   * @return texte descriptif
   */
  public String getCreateFormDescription() {
    if (!isModuleInputRendered()) {
      return fileCreateFormController.describeAllowedNatures(
          "pour le module " + filterController.getFilter().getModuleIdentifier() + ".");
    }
    return fileCreateFormController.describeAllowedNatures("et rattachez-le à son module.");
  }

  /**
   * Message affiché lorsque le contenu numérique obligatoire n'a pas été déposé.
   *
   * @return message de validation
   */
  public String getBinaryContentRequiredMessage() {
    return fileCreateFormController.getBinaryContentRequiredMessage();
  }

  public String getMediumNatureCode() {
    return fileCreateFormController.getMediumNatureCode();
  }

  public void setMediumNatureCode(String mediumNatureCode) {
    fileCreateFormController.setMediumNatureCode(mediumNatureCode);
  }

  public String getPhysicalItemHolder() {
    return fileCreateFormController.getPhysicalItemHolder();
  }

  public void setPhysicalItemHolder(String physicalItemHolder) {
    fileCreateFormController.setPhysicalItemHolder(physicalItemHolder);
  }

  public String getPhysicalItemContainer() {
    return fileCreateFormController.getPhysicalItemContainer();
  }

  public void setPhysicalItemContainer(String physicalItemContainer) {
    fileCreateFormController.setPhysicalItemContainer(physicalItemContainer);
  }

  public String getPhysicalItemExtent() {
    return fileCreateFormController.getPhysicalItemExtent();
  }

  public void setPhysicalItemExtent(String physicalItemExtent) {
    fileCreateFormController.setPhysicalItemExtent(physicalItemExtent);
  }

  public String getPhysicalItemCondition() {
    return fileCreateFormController.getPhysicalItemCondition();
  }

  public void setPhysicalItemCondition(String physicalItemCondition) {
    fileCreateFormController.setPhysicalItemCondition(physicalItemCondition);
  }

  public String getOriginalMediumCode() {
    return fileCreateFormController.getOriginalMediumCode();
  }

  public void setOriginalMediumCode(String originalMediumCode) {
    fileCreateFormController.setOriginalMediumCode(originalMediumCode);
  }

  public String getUploadedFileName() {
    return fileCreateFormController.getUploadedFileName();
  }

  public FileDescriptionProposalDto getDescriptionProposal() {
    return fileCreateFormController.getDescriptionProposal();
  }

  /**
   * Réinitialise les champs de saisie du support physique.
   */
  public void resetPhysicalItemFields() {
    fileCreateFormController.reset();
  }

  /**
   * Cette méthode permet de réagir au téléchargement d'un fichier : le contenu est gardé pour la
   * création et la description proposée est demandée au serveur (RG_FILE_FIC_24).
   *
   * @param event évènement
   */
  public void handleFileUpload(FileUploadEvent event) {
    fileCreateFormController.handleFileUpload(event);
  }

  /**
   * Indique si un fichier a été téléversé pour la création en cours.
   *
   * @return {@code true} si le fichier peut être retiré avant l'enregistrement
   */
  public boolean hasUploadedFile() {
    return fileCreateFormController.hasUploadedFile();
  }

  /**
   * Indique si la nature choisie attend un contenu binaire (Numérique ou Hybride).
   *
   * @return {@code true} si la section de dépôt est affichée
   */
  public boolean isBinaryContentExpected() {
    return fileCreateFormController.isBinaryContentExpected();
  }

  /**
   * Indique si la nature choisie attend un Exemplaire physique (Physique ou Hybride).
   *
   * @return {@code true} si la section du papier est affichée
   */
  public boolean isPhysicalItemExpected() {
    return fileCreateFormController.isPhysicalItemExpected();
  }

  /**
   * Indique si la nature choisie est Hybride (contenu binaire et papier).
   *
   * @return {@code true} si le choix de l'original est affiché
   */
  public boolean isHybrid() {
    return fileCreateFormController.isHybrid();
  }

  /**
   * Réagit au changement de nature : un contenu binaire déjà déposé est retiré si la nature n'en
   * attend plus (Physique), pour que l'écran montre ce qui sera vraiment envoyé.
   */
  public void onMediumNatureChange() {
    fileCreateFormController.onMediumNatureChange();
  }

  /**
   * Témoin du contenu binaire déposé, lu par un champ caché obligatoire du formulaire.
   *
   * @return une valeur non vide si un contenu binaire est déposé, {@code null} sinon
   */
  public String getBinaryContentMarker() {
    return fileCreateFormController.getBinaryContentMarker();
  }

  /**
   * Sans effet : le témoin se déduit du contenu déposé (requis par le champ caché).
   *
   * @param marker valeur soumise, ignorée
   */
  public void setBinaryContentMarker(String marker) {
    fileCreateFormController.setBinaryContentMarker(marker);
  }

  /** Retire le fichier téléversé de la création en cours, avant toute persistance. */
  public void removeUploadedFile() {
    fileCreateFormController.removeUploadedFile();
  }

  /**
   * Indique si le champ Module est saisi : seulement hors de l'onglet d'un module, qui le fixe.
   *
   * @return {@code true} sur l'onglet « Tout »
   */
  public boolean isModuleInputRendered() {
    return filterController.getFilter().getModuleIdentifier() == null;
  }

  private FileDto createEntity() {
    return (FileDto) listController.getCreateController().getEntity();
  }

  /**
   * Cette méthode permet de savoir si un Fichier peut être confirmé dans l'état où il se trouve
   * (RG_FILE_FIC_09) : encore "Créé" (provisoire), jamais une fois "Confirmé" (RG_FILE_FIC_08,
   * statut terminal).
   *
   * @param file fichier
   * @return {@code true} si le fichier peut être confirmé
   */
  public boolean confirmable(FileDto file) {
    return FileStatus.CREATED.equals(file.getStatus());
  }

  /**
   * Cette méthode permet d'initialiser {@link #confirmProcessingController}, affiché dans la
   * colonne Action de la liste (RG_FILE_FIC_09), selon le mécanisme déjà établi pour ce type de
   * bouton d'action de statut (cf. {@code PayrollElementClaimController} du module
   * {@code payrollelementrequest}).
   */
  void initializeConfirmProcessing() {
    confirmProcessingController.setListController(listController);
    confirmProcessingController.prepareConfirmation(FileDto.class, "Confirmer", "pi pi-thumbs-up",
        confirmFunction());
    confirmProcessingController
        .setSubmitButtonControllerRenderedFunction(entity -> confirmable((FileDto) entity));
    confirmProcessingController.initialize();
  }

  /**
   * Cette méthode permet de confirmer un Fichier par son identifiant (RG_FILE_FIC_09).
   *
   * @return fonction de confirmation
   */
  UnaryOperator<Object> confirmFunction() {
    return identifier -> {
      FileConfirmRequestDto request = new FileConfirmRequestDto();
      request.setIdentifier((String) identifier);
      request.setAuditWho(userIdentifier);
      return client.confirm(request);
    };
  }
}
