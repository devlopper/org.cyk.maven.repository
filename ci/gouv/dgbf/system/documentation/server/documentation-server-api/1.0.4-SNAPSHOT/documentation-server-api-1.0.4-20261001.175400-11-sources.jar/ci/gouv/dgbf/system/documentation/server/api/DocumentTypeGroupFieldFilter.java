package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupIdentifier;
import ci.gouv.dgbf.extension.core.segregation.HasTypeGroupIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les champs de groupe de type de document.
 *
 * @author si.kimou
 *
 */
@Getter
@Setter
public class DocumentTypeGroupFieldFilter extends AbstractIdentifiableFilter
    implements HasTypeGroupIdentifier {

  /**
   * Identifiant du {@link DocumentTypeGroupDto} pour lequel les champs sont configurés.
   */
  String typeGroupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DocumentTypeGroupFieldFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DocumentTypeGroupFieldFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeGroupIdentifier = getTypeGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTypeGroupIdentifier(filter, typeGroupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de type de document.
   *
   * @param filter filtre
   * @param typeGroupIdentifier identifiant du groupe de type de document
   */
  public static void setTypeGroupIdentifier(FilterDto filter, String typeGroupIdentifier) {
    set(filter, JSON_TYPE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(typeGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de type de document -- sans elle, le
   * critère envoyé par le client pour lister les champs configurés d'une combinaison type/groupe
   * serait silencieusement ignoré : {@code DocumentTypeGroupFieldClient.getMany(...)} retournerait
   * tous les champs configurés, tous groupes de type de document confondus.
   *
   * @param filter filtre
   * @return identifiant du groupe de type de document
   */
  public static String getTypeGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #typeGroupIdentifier}.
   */
  public static final String JSON_TYPE_GROUP_IDENTIFIER =
      HasTypeGroupIdentifierDto.JSON_TYPE_GROUP_IDENTIFIER;
}
