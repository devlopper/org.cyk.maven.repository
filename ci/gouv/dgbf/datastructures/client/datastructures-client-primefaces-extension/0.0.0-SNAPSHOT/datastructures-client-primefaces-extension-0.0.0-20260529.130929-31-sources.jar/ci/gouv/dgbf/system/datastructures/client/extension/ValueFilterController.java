package ci.gouv.dgbf.system.datastructures.client.extension;


import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.datastructures.server.api.ValueDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link ValueDto}.
 *
 * @author Christian
 */
@Dependent
public class ValueFilterController extends AbstractFilterController<ValueFilter> {

  @Inject
  @Getter
  ValueSourceSelectOneController sourceSelectOneController;

  /**
   * Cette méthode permet d'instantier.
   */
  public ValueFilterController() {
    super(ValueFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    sourceSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setSourceIdentifier(identifier));

  }



}
