package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SectionDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class SectionSelectOneController extends AbstractSelectOneIdentifiableController<
    SectionDto, GetManyResponseDto, SectionClient> {

  @Inject
  @Getter
  SectionClient client;

  protected SectionSelectOneController() {
    super(SectionDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
