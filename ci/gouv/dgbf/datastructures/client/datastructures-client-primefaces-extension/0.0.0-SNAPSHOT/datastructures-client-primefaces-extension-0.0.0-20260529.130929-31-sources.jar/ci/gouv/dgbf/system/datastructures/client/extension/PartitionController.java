package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionClient;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService.PartitionCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.PartitionService.PartitionUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link PartitionDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class PartitionController extends AbstractController {

  @Inject
  PartitionClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  PartitionRequestMapper requestMapper;

  @Inject
  @Getter
  PartitionTypeSelectOneController typeSelectOneController;

  @Inject
  @Getter
  ValueSelectOneController valueSelectOneController;

  @Inject
  @Getter
  PartitionFilterController filterController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = PartitionDto.NAME;

    listController.setEntityClass(PartitionDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(PartitionService.PATH);
    listController.setFilterController(filterController);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            PartitionDto.JSON_TYPE_AS_STRING, PartitionDto.JSON_VALUE_AS_STRING));

    listController.getDataTable().getFilterButton().setRendered(true);
    
    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      PartitionCreateRequestDto request = requestMapper.mapCreate((PartitionDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            PartitionDto.JSON_TYPE_IDENTIFIER, PartitionDto.JSON_VALUE_IDENTIFIER));

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());

    typeSelectOneController.getSelectOneMenu().addValueConsumer(typeConsumer());

    valueSelectOneController.getSelectOneMenu().getOutputLabel().setValue("Référence");
    valueSelectOneController.getSelectOneMenu().addValueConsumer(referenceConsumer());

  }

  Consumer<String> typeConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionDto.class)
        .setTypeIdentifier(identifier);
  }

  Consumer<String> referenceConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(PartitionDto.class)
        .setValueIdentifier(identifier);
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      typeSelectOneController.getSelectOneMenu()
          .writeValue(((PartitionDto) entity).getTypeIdentifier());
      valueSelectOneController.getSelectOneMenu()
          .writeValue(((PartitionDto) entity).getValueIdentifier());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      PartitionUpdateRequestDto request = requestMapper.mapUpdate((PartitionDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List
        .of(typeSelectOneController.getSelectOneMenu(),
            valueSelectOneController.getSelectOneMenu())
        .stream().map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
