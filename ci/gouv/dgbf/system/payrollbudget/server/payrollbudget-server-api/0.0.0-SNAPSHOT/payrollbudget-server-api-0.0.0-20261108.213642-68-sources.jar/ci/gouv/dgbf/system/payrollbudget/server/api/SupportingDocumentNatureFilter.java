package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des natures de pièces justificatives.
 *
 * <p>Le type de mouvement est le critère du contrôle : « quelles pièces cette ligne doit-elle
 * présenter ? » se répond en filtrant par son type.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SupportingDocumentNatureFilter extends AbstractIdentifiableFilter {

  /**
   * Nature de l'élément concerné.
   */
  String elementType;

  /**
   * Code du type de mouvement concerné.
   */
  String movementTypeCode;

  public SupportingDocumentNatureFilter() {
    super();
  }

  public SupportingDocumentNatureFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setElementType(read(filter, SupportingDocumentNatureDto.JSON_ELEMENT_TYPE));
    setMovementTypeCode(read(filter, SupportingDocumentNatureDto.JSON_MOVEMENT_TYPE_CODE));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, SupportingDocumentNatureDto.JSON_ELEMENT_TYPE, getElementType());
    write(filter, SupportingDocumentNatureDto.JSON_MOVEMENT_TYPE_CODE, getMovementTypeCode());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
