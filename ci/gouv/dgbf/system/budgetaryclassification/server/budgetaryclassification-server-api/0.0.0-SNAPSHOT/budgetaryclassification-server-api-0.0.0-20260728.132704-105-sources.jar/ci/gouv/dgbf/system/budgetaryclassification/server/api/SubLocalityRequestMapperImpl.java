package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SubLocalityDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-28T13:27:31+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SubLocalityRequestMapperImpl implements SubLocalityRequestMapper {

    @Override
    public SubLocalityService.SubLocalityCreateRequestDto mapCreate(SubLocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubLocalityService.SubLocalityCreateRequestDto subLocalityCreateRequestDto = new SubLocalityService.SubLocalityCreateRequestDto();

        subLocalityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        subLocalityCreateRequestDto.setName( arg0.getName() );
        subLocalityCreateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );

        return subLocalityCreateRequestDto;
    }

    @Override
    public SubLocalityService.SubLocalityUpdateRequestDto mapUpdate(SubLocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubLocalityService.SubLocalityUpdateRequestDto subLocalityUpdateRequestDto = new SubLocalityService.SubLocalityUpdateRequestDto();

        subLocalityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        subLocalityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        subLocalityUpdateRequestDto.setName( arg0.getName() );
        subLocalityUpdateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );

        return subLocalityUpdateRequestDto;
    }
}
