package ci.gouv.dgbf.system.processing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.StatisticCard;
import ci.gouv.dgbf.system.processing.server.api.ProcessingDto;
import ci.gouv.dgbf.system.processing.server.api.ProcessingStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur des statistiques des {@link ProcessingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ProcessingsStatisticsController extends AbstractController {

  @Getter
  @Setter
  StatisticCard startWaitingCard;

  @Getter
  @Setter
  StatisticCard runningCard;

  @Getter
  @Setter
  StatisticCard doneCard;

  @Inject
  ProcessingStatusIconManager statusIconManager;

  @Getter
  @Setter
  StatisticCard.Data startWaitingState;

  @Getter
  @Setter
  StatisticCard.Data lateState;

  @Getter
  @Setter
  StatisticCard.Data notLateState;

  @Getter
  @Setter
  StatisticCard.Data createdState;

  @Getter
  @Setter
  StatisticCard.Data startedState;

  @Getter
  @Setter
  StatisticCard.Data stoppedState;

  @Getter
  @Setter
  StatisticCard.Data doneState;

  @Getter
  @Setter
  StatisticCard.Data canceledState;

  @Getter
  @Setter
  StatisticCard.Data terminatedState;

  /**
   * Cette méthode permet d'instantier.
   */
  public ProcessingsStatisticsController() {
    createdState = new StatisticCard.Data(ProcessingStatus.CREATED.getName(), "0");
    startedState = new StatisticCard.Data(ProcessingStatus.STARTED.getName(), "0");
    stoppedState = new StatisticCard.Data(ProcessingStatus.STOPPED.getName(), "0");
    canceledState = new StatisticCard.Data(ProcessingStatus.CANCELLED.getName(), "0");
    terminatedState = new StatisticCard.Data(ProcessingStatus.TERMINATED.getName(), "0");

    startWaitingState = new StatisticCard.Data("En attente de démarrage", "0");
    doneState = new StatisticCard.Data("Fini", "0");

    lateState = new StatisticCard.Data("En retard", "0");
    notLateState = new StatisticCard.Data("Dans le temps", "0");

  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    startWaitingCard = instantiateStatisticCard(startWaitingState.getName(),
        startWaitingState.getValue(), "bg-attentedemarage", statusIconManager.getStartWaiting());
    runningCard = instantiateStatisticCard(startedState.getName(), startedState.getValue(),
        "bg-encours", statusIconManager.getRunning());
    doneCard = instantiateStatisticCard(doneState.getName(), doneState.getValue(), "bg-fini",
        statusIconManager.getDone());
  }

  StatisticCard instantiateStatisticCard(String title, String count, String backgroundColorClass,
      String iconClass) {
    StatisticCard statisticCard = new StatisticCard();
    statisticCard.setTitle(title);
    statisticCard.setValue(count);
    statisticCard.setBackgroundColorClass(backgroundColorClass + " m-0");
    statisticCard.setValueTextColorClass("text-white");
    statisticCard.setIconClass(iconClass);
    return statisticCard;
  }
}
