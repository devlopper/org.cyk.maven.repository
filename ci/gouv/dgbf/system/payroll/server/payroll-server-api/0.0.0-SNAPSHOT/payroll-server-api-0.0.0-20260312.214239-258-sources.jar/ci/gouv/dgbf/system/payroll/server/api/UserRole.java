package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // --- Role ---

  /**
   * Administrateur système.
   */
  SYSTEM_ADMINISTRATOR("ADMINISTRATEUR_SYSTEME"),

  // --- Actions ---

  // Paie

  /**
   * Gérer {@link PayrollDto}.
   */
  MANAGE_PAYROLL("GERER_PAIE"),

  /**
   * Initialiser {@link PayrollDto}.
   */
  INITIALIZE_PAYROLL("INITIALISER_PAIE"),

  /**
   * Transmettre {@link PayrollDto} pour contrôle.
   */
  TRANSMIT_PAYROLL_FOR_CONTROL("TRANSMETTRE_PAIE_POUR_CONTROLE"),

  /**
   * Contrôler {@link PayrollDto}.
   */
  CONTROL_PAYROLL("CONTROLER_PAIE"),

  /**
   * Calculer {@link PayrollDto}.
   */
  CALCULATE_PAYROLL("CALCULER_PAIE"),

  /**
   * Transmettre {@link PayrollDto} pour ajustement.
   */
  TRANSMIT_PAYROLL_FOR_ADJUSTMENT("TRANSMETTRE_PAIE_POUR_ARBITRAGE"),

  /**
   * Cloturer {@link PayrollDto}.
   */
  CLOSE_PAYROLL("CLOTURER_PAIE"),

  // Bulletin

  /**
   * Gérer {@link PayslipDto}.
   */
  MANAGE_PAYSLIP("GERER_BULLETIN_PAIE"),

  /**
   * Transmettre {@link PayslipDto} pour contrôle.
   */
  TRANSMIT_PAYSLIP_FOR_CONTROL("TRANSMETTRE_BULLETIN_PAIE_POUR_CONTROLE"),

  /**
   * Contrôler {@link PayslipDto}.
   */
  CONTROL_PAYSLIP("CONTROLER_BULLETIN_PAIE"),

  /**
   * Proposer correction {@link PayslipDto}.
   */
  PROPOSE_CORRECTION("PROPOSER_CORRECTION"),

  /**
   * Corriger {@link PayslipDto}.
   */
  CORRECT("CORRIGER"),

  /**
   * Transmettre {@link PayslipDto} au contentieux.
   */
  TRANSMIT_PAYSLIP_TO_LITIGATION("TRANSMETTRE_BULLETIN_AU_CONTENTIEUX"),
    
  /**
   * Changer le mouvement du {@link PayslipDto}.
   */
  CHANGE_PAYSLIP_MOVEMENT("CHANGER_MOUVEMENT_BULLETIN"),

  /**
   * Réintégrer {@link PayslipDto}.
   */
  REINTEGRATE_PAYSLIP_FROM_LITIGATION("REINTEGRER_DU_CONTENTIEUX"),

  /**
   * Accpeter {@link PayslipDto}.
   */
  ACCEPT_PAYSLIP("ACCEPTER_BULLETIN_PAIE"),

  /**
   * Calculer {@link PayslipDto}.
   */
  CALCULATE_PAYSLIP("CALCULER_BULLETIN_PAIE"),

  /**
   * Valider {@link PayslipDto}.
   */
  VALIDATE_PAYSLIP("VALIDER_BULLETIN_PAIE"),

  /**
   * Transmettre {@link PayslipDto} pour ajustement.
   */
  TRANSMIT_PAYSLIP_FOR_ADJUSTMENT("TRANSMETTRE_BULLETIN_PAIE_POUR_ARBITRAGE")

  ;

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;
}
