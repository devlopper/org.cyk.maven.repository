package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileJournalEntryClient;
import ci.gouv.dgbf.system.file.server.api.FileJournalEntryDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente le contrôleur du dialogue du Journal d'un Fichier (DEC_FILE_01 bloc B2a,
 * RG_FILE_FIC_23, TCH_FILE_627) : lecture seule des évolutions du document (ajout du contenu,
 * déclaration de l'exemplaire papier, modification des informations ou du Détenteur), de la plus
 * ancienne à la plus récente. Le journal reste lisible après la suppression du Fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileJournalDialogController extends AbstractController {

  /**
   * Nombre maximal de lignes affichées : le journal d'un document reste court, la lecture n'est
   * donc pas paginée à l'écran.
   */
  static final int MAXIMAL_ROWS = 500;

  @Inject
  FileJournalEntryClient client;

  @Getter
  @Setter
  String widgetVar;

  @Getter
  @Setter
  String title;

  @Getter
  String fileIdentifier;

  @Getter
  List<FileJournalEntryDto> entries = new ArrayList<>();

  /**
   * Cette méthode permet de construire une instance.
   */
  public FileJournalDialogController() {
    widgetVar = "fileJournalDialog";
    title = "Journal du fichier";
  }

  /**
   * Cette méthode permet d'ouvrir le journal d'un Fichier.
   *
   * @param identifier identifiant du Fichier
   */
  public void open(String identifier) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L'identifiant du fichier est obligatoire");
    }
    fileIdentifier = identifier;
    entries = new ArrayList<>(read(identifier));
    entries.sort(Comparator.comparing(FileJournalEntryDto::getOrder,
        Comparator.nullsLast(Comparator.naturalOrder())));
    showDialog();
  }

  List<FileJournalEntryDto> read(String identifier) {
    ProjectionDto projection = new ProjectionDto().addNames(FileJournalEntryDto.JSON_ORDER,
        FileJournalEntryDto.JSON_EVENT_DATE, FileJournalEntryDto.JSON_EVENT_TYPE,
        FileJournalEntryDto.JSON_FIELD_KIND, FileJournalEntryDto.JSON_OLD_VALUE,
        FileJournalEntryDto.JSON_VALUE, FileJournalEntryDto.JSON_ACTOR_IDENTIFIER);
    List<FileJournalEntryDto> datas = client.getManyByFileIdentifier(identifier, projection,
        new PageDto(0, MAXIMAL_ROWS), userIdentifier, null).getDatas();
    return datas == null ? List.of() : datas;
  }

  /**
   * Cette méthode permet de savoir si le journal est vide.
   *
   * @return vrai si aucune évolution n'est enregistrée
   */
  public boolean isWithoutEntries() {
    return entries.isEmpty();
  }

  /**
   * Affiche le dialogue PrimeFaces si l'instance PrimeFaces est disponible.
   */
  void showDialog() {
    PrimeFaces primeFaces = getPrimeFaces();
    if (primeFaces != null) {
      // Par le widgetVar : l'identifiant client du dialogue dépend du formulaire englobant.
      primeFaces.ajax().update("@widgetVar(" + widgetVar + ")");
      primeFaces.executeScript("PF('" + widgetVar + "').show();");
    }
  }

  /**
   * Obtient l'instance courante de PrimeFaces.
   *
   * @return instance {@link PrimeFaces}
   */
  PrimeFaces getPrimeFaces() {
    return PrimeFaces.current();
  }
}
