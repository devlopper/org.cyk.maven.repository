package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PolicyDto}.
 *
 * @author Desysoft
 *
 */
@Path(value = PolicyService.PATH)
@Tag(name = "Gestion des Politiques")
public interface PolicyService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "politiques";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface PolicySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du type de politique.
     *
     * @return identifiant du type de politique
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du type de politique.
     *
     * @param typeIdentifier identifiant du type de politique
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * {@link PolicyDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = PolicyDto.JSON_TYPE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link PolicyDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_POLITIQUE";

  /**
   * Chemin du service de création unitaire de {@link PolicyDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une politique",
      description = "Ce service permet de créer une politique")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PolicyCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link PolicyDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PolicySaveRequestDto {

    /**
     * {@link PolicyDto#getTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    /**
     * Identifiant du fichier portant le contenu de la première version de la politique
     * (RG_IDT_POL_03), créée automatiquement lors de la création de la politique (RU_IDT_002).
     *
     * @see PolicyVersionService.PolicyVersionSaveRequestDto#getFileIdentifier()
     */
    @JsonbProperty(PolicyVersionDto.JSON_FILE_IDENTIFIER)
    private String fileIdentifier;

    /**
     * Date de publication de la première version de la politique. Si non renseignée, la date de
     * création est utilisée.
     *
     * @see PolicyVersionService.PolicyVersionSaveRequestDto#getPublicationDate()
     */
    @JsonbProperty(PolicyVersionDto.JSON_PUBLICATION_DATE)
    private LocalDateTime publicationDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link PolicyDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POLITIQUE";

  /**
   * Chemin du service d'obtention de plusieurs {@link PolicyDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs politiques")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link PolicyDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  public static class PolicyGetManyResponseDto
      extends AbstractGetByPageResponseDto<PolicyDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PolicyDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link PolicyDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_POLITIQUE";

  /**
   * Chemin du service d'obtention unitaire de {@link PolicyDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link PolicyDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POLITIQUE";

  /**
   * Chemin du service d'obtention par identifiant de {@link PolicyDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link PolicyDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_POLITIQUE";

  /**
   * Chemin du service de mise à jour unitaire de {@link PolicyDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PolicyUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link PolicyDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PolicySaveRequestDto {

    /**
     * {@link PolicyDto#getTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link PolicyDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_POLITIQUE";

  /**
   * Chemin du service de suppression unitaire de {@link PolicyDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link PolicyDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
