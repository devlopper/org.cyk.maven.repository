package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasApplicationDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasApplicationDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasEffectiveDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasEffectiveDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasFunctionaryRegistrationNumberDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessedDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessedDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasRetroactiveProcessedDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRetroactiveProcessedDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de mouvement.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractMovementDto extends AbstractIdentifiableAuditableDto
    implements HasFunctionaryRegistrationNumberDto, HasStatusAsStringDto,
    HasEffectiveDateDto<LocalDate>, HasEffectiveDateAsStringDto, HasApplicationDateDto<LocalDate>,
    HasApplicationDateAsStringDto, HasProcessedDateDto<LocalDate>, HasProcessedDateAsStringDto,
    HasRetroactiveProcessedDateDto<LocalDate>, HasRetroactiveProcessedDateAsStringDto {

  @JsonbProperty(JSON_FUNCTIONARY_REGISTRATION_NUMBER)
  private String functionaryRegistrationNumber;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  // Dates

  // Effet

  @JsonbProperty(JSON_EFFECTIVE_DATE)
  private LocalDate effectiveDate;

  @JsonbProperty(JSON_EFFECTIVE_DATE_AS_STRING)
  private String effectiveDateAsString;

  // Application

  @JsonbProperty(JSON_APPLICATION_DATE)
  private LocalDate applicationDate;

  @JsonbProperty(JSON_APPLICATION_DATE_AS_STRING)
  private String applicationDateAsString;

  // Prise en compte

  @JsonbProperty(JSON_PROCESSED_DATE)
  private LocalDate processedDate;

  @JsonbProperty(JSON_PROCESSED_DATE_AS_STRING)
  private String processedDateAsString;

  // Prise en compte du rappel

  @JsonbProperty(JSON_RETROACTIVE_PROCESSED_DATE)
  private LocalDate retroactiveProcessedDate;

  @JsonbProperty(JSON_RETROACTIVE_PROCESSED_DATE_AS_STRING)
  private String retroactiveProcessedDateAsString;
}
