package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un moyen de financement d'une activité de programmme triennal.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TriennialProgramActivityFundingTypeDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
  private String fundingTypeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FundingTypeDto}.
   */
  @JsonbProperty(JSON_FUNDING_TYPE_AS_STRING)
  private String fundingTypeAsString;

  /**
   * Identifiant {@link TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
  private String triennialProgramActivityIdentifier;


  /**
   * Représentation en chaine de caractères de TriennialProgramActivityDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING)
  private String triennialProgramActivityAsString;

  /**
   * Identifiant de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
  private String triennialProgramIdentifier;

  /**
   * Représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_TRIENNIAL_PROGRAM_AS_STRING)
  private String triennialProgramAsString;

  /**
   * Identifiant de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1)
  private Long amount1;

  /**
   * Représentation en chaine de caractères de Montant 1.
   */
  @JsonbProperty(JSON_AMOUNT_1_AS_STRING)
  private String amount1AsString;

  /**
   * Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2)
  private Long amount2;

  /**
   * Représentation en chaine de caractères de Montant 2.
   */
  @JsonbProperty(JSON_AMOUNT_2_AS_STRING)
  private String amount2AsString;

  /**
   * Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3)
  private Long amount3;

  /**
   * Représentation en chaine de caractères de Montant 3.
   */
  @JsonbProperty(JSON_AMOUNT_3_AS_STRING)
  private String amount3AsString;

  /**
   * Montant utilisé 1 : somme des montants 1 des financements de ce type.
   */
  @JsonbProperty(JSON_USED_AMOUNT_1)
  private Long usedAmount1;

  /**
   * Représentation en chaine de caractères de Montant utilisé 1.
   */
  @JsonbProperty(JSON_USED_AMOUNT_1_AS_STRING)
  private String usedAmount1AsString;

  /**
   * Montant utilisé 2 : somme des montants 2 des financements de ce type.
   */
  @JsonbProperty(JSON_USED_AMOUNT_2)
  private Long usedAmount2;

  /**
   * Représentation en chaine de caractères de Montant utilisé 2.
   */
  @JsonbProperty(JSON_USED_AMOUNT_2_AS_STRING)
  private String usedAmount2AsString;

  /**
   * Montant utilisé 3 : somme des montants 3 des financements de ce type.
   */
  @JsonbProperty(JSON_USED_AMOUNT_3)
  private Long usedAmount3;

  /**
   * Représentation en chaine de caractères de Montant utilisé 3.
   */
  @JsonbProperty(JSON_USED_AMOUNT_3_AS_STRING)
  private String usedAmount3AsString;

  /**
   * Montant restant 1 : montant 1 moins montant utilisé 1.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_1)
  private Long remainingAmount1;

  /**
   * Représentation en chaine de caractères de Montant restant 1.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_1_AS_STRING)
  private String remainingAmount1AsString;

  /**
   * Montant restant 2 : montant 2 moins montant utilisé 2.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_2)
  private Long remainingAmount2;

  /**
   * Représentation en chaine de caractères de Montant restant 2.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_2_AS_STRING)
  private String remainingAmount2AsString;

  /**
   * Montant restant 3 : montant 3 moins montant utilisé 3.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_3)
  private Long remainingAmount3;

  /**
   * Représentation en chaine de caractères de Montant restant 3.
   */
  @JsonbProperty(JSON_REMAINING_AMOUNT_3_AS_STRING)
  private String remainingAmount3AsString;

  /**
   * Représentation en chaine de caractères du montant de l'activité.
   */
  @JsonbProperty(JSON_ACTIVITY_AMOUNT_AS_STRING)
  private String activityAmountAsString;

  /**
   * Montant modifiable.
   */
  @JsonbProperty(JSON_AMOUNTS_INPUTABLE)
  private Boolean amountsInputable;

  /**
   * Catégorie d'activité.
   */
  @JsonbProperty(JSON_ACTIVITY_CATEGORY)
  private ActivityCategory activityCategory;


  /**
   * Identifiant json {@link #fundingTypeIdentifier}.
   */
  public static final String JSON_FUNDING_TYPE_IDENTIFIER = "idTypeFinancement";

  /**
   * Identifiant json {@link #fundingTypeAsString}.
   */
  public static final String JSON_FUNDING_TYPE_AS_STRING = "typeFinancementChaine";

  /**
   * Identifiant json {@link #triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
      "identifiantActiviteProgrammeTriennal";

  /**
   * Identifiant json {@link #triennialProgramActivityAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_AS_STRING =
      "activiteProgrammeTriennalChaine";


  /**
   * Identifiant json {@link #amount1}.
   */
  public static final String JSON_AMOUNT_1 = "montant1";

  /**
   * Identifiant json {@link #amount1AsString}.
   */
  public static final String JSON_AMOUNT_1_AS_STRING = "montant1Chaine";

  /**
   * Identifiant json {@link #amount2}.
   */
  public static final String JSON_AMOUNT_2 = "montant2";

  /**
   * Identifiant json {@link #amount2AsString}.
   */
  public static final String JSON_AMOUNT_2_AS_STRING = "montant2Chaine";

  /**
   * Identifiant json {@link #amount3}.
   */
  public static final String JSON_AMOUNT_3 = "montant3";

  /**
   * Identifiant json {@link #amount3AsString}.
   */
  public static final String JSON_AMOUNT_3_AS_STRING = "montant3Chaine";

  /**
   * Identifiant json {@link #usedAmount1}.
   */
  public static final String JSON_USED_AMOUNT_1 = "montantUtilise1";

  /**
   * Identifiant json {@link #usedAmount1AsString}.
   */
  public static final String JSON_USED_AMOUNT_1_AS_STRING = "montantUtilise1Chaine";

  /**
   * Identifiant json {@link #usedAmount2}.
   */
  public static final String JSON_USED_AMOUNT_2 = "montantUtilise2";

  /**
   * Identifiant json {@link #usedAmount2AsString}.
   */
  public static final String JSON_USED_AMOUNT_2_AS_STRING = "montantUtilise2Chaine";

  /**
   * Identifiant json {@link #usedAmount3}.
   */
  public static final String JSON_USED_AMOUNT_3 = "montantUtilise3";

  /**
   * Identifiant json {@link #usedAmount3AsString}.
   */
  public static final String JSON_USED_AMOUNT_3_AS_STRING = "montantUtilise3Chaine";

  /**
   * Identifiant json {@link #remainingAmount1}.
   */
  public static final String JSON_REMAINING_AMOUNT_1 = "montantRestant1";

  /**
   * Identifiant json {@link #remainingAmount1AsString}.
   */
  public static final String JSON_REMAINING_AMOUNT_1_AS_STRING = "montantRestant1Chaine";

  /**
   * Identifiant json {@link #remainingAmount2}.
   */
  public static final String JSON_REMAINING_AMOUNT_2 = "montantRestant2";

  /**
   * Identifiant json {@link #remainingAmount2AsString}.
   */
  public static final String JSON_REMAINING_AMOUNT_2_AS_STRING = "montantRestant2Chaine";

  /**
   * Identifiant json {@link #remainingAmount3}.
   */
  public static final String JSON_REMAINING_AMOUNT_3 = "montantRestant3";

  /**
   * Identifiant json {@link #remainingAmount3AsString}.
   */
  public static final String JSON_REMAINING_AMOUNT_3_AS_STRING = "montantRestant3Chaine";

  /**
   * Identifiant json {@link #activityAmountAsString}.
   */
  public static final String JSON_ACTIVITY_AMOUNT_AS_STRING = "montantActiviteChaine";

  /**
   * Identifiant json {@link #amountsInputable}.
   */
  public static final String JSON_AMOUNTS_INPUTABLE = "montantsModifiable";

  /**
   * Identifiant json {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #triennialProgramAsString}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_AS_STRING =
      TriennialProgramDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = ActivityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY = "categorieActivite";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type financement activité programme triennal";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types financement par activité programme triennal";
}
