package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link AdministrativeUnitPunctualMeasureDto}.
 *
 * @author Christian
 *
 */
@Path(value = AdministrativeUnitPunctualMeasureService.PATH)
@Tag(name = "Gestion des mesures ponctuelles d'unités administratives")
public interface AdministrativeUnitPunctualMeasureService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "unites-administratives-mesures-ponctuelles";

  /**
   * Cette interface représente la requête d'enregistrement.
   */
  interface AdministrativeUnitPunctualMeasureSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant du budget.
     *
     * @return identifiant du budget
     */
    String getBudgetIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du budget.
     *
     * @param budgetIdentifier identifiant du budget
     */
    void setBudgetIdentifier(String budgetIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'unité administrative.
     *
     * @return identifiant de l'unité administrative
     */
    String getAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'unité administrative.
     *
     * @param administrativeUnitIdentifier identifiant de l'unité administrative
     */
    void setAdministrativeUnitIdentifier(String administrativeUnitIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la mesure ponctuelle.
     *
     * @return identifiant de la mesure ponctuelle
     */
    String getPunctualMeasureIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la mesure ponctuelle.
     *
     * @param punctualMeasureIdentifier identifiant de la mesure ponctuelle
     */
    void setPunctualMeasureIdentifier(String punctualMeasureIdentifier);

    /**
     * Cette méthode permet d'obtenir le montant.
     *
     * @return montant
     */
    Integer getAmount();

    /**
     * Cette méthode permet d'assigner le montant.
     *
     * @param amount montant
     */
    void setAmount(Integer amount);

    /**
     * {@link AdministrativeUnitPunctualMeasureDto#JSON_BUDGET_IDENTIFIER}.
     */
    String JSON_BUDGET_IDENTIFIER = AdministrativeUnitPunctualMeasureDto.JSON_BUDGET_IDENTIFIER;

    /**
     * {@link AdministrativeUnitPunctualMeasureDto#JSON_ADMINISTRATIVE_UNIT_IDENTIFIER}.
     */
    String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
        AdministrativeUnitPunctualMeasureDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER;

    /**
     * {@link AdministrativeUnitPunctualMeasureDto#JSON_PUNCTUAL_MEASURE_IDENTIFIER}.
     */
    String JSON_PUNCTUAL_MEASURE_IDENTIFIER =
        AdministrativeUnitPunctualMeasureDto.JSON_PUNCTUAL_MEASURE_IDENTIFIER;

    /**
     * {@link AdministrativeUnitPunctualMeasureDto#JSON_AMOUNT}.
     */
    String JSON_AMOUNT = AdministrativeUnitPunctualMeasureDto.JSON_AMOUNT;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Création d'une mesure ponctuelle d'unité administrative")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(AdministrativeUnitPunctualMeasureCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitPunctualMeasureCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements AdministrativeUnitPunctualMeasureSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_PUNCTUAL_MEASURE_IDENTIFIER)
    String punctualMeasureIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    Integer amount;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = AdministrativeUnitPunctualMeasureGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class AdministrativeUnitPunctualMeasureGetManyResponseDto
      extends AbstractGetByPageResponseDto<AdministrativeUnitPunctualMeasureDto> {

    @JsonbProperty(JSON_DATAS)
    private List<AdministrativeUnitPunctualMeasureDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = AdministrativeUnitPunctualMeasureDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = AdministrativeUnitPunctualMeasureDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(AdministrativeUnitPunctualMeasureUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class AdministrativeUnitPunctualMeasureUpdateRequestDto extends ByIdentifierRequestDto
      implements AdministrativeUnitPunctualMeasureSaveRequestDto {

    @JsonbProperty(JSON_BUDGET_IDENTIFIER)
    String budgetIdentifier;

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
    String administrativeUnitIdentifier;

    @JsonbProperty(JSON_PUNCTUAL_MEASURE_IDENTIFIER)
    String punctualMeasureIdentifier;

    @JsonbProperty(JSON_AMOUNT)
    Integer amount;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UNITE_ADMINISTRATIVE_MESURE_PONCTUELLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link AdministrativeUnitPunctualMeasureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
