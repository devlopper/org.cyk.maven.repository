package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'imputation.
 *
 * @author Christian
 */
public interface HasImputationAsStringDto extends HasImputationAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'imputation.
   */
  String JSON_IMPUTATION_AS_STRING = "imputationChaine";
}
