package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModuleService.ModuleCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModuleService.ModuleGetManyResponseDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModuleService.ModuleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ModuleDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class ModuleClient extends AbstractClient<ModuleService>
    implements GetByIdentifier<ModuleDto>, GetMany<ModuleGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ModuleService}
   * @return client {@link ModuleClient}
   */
  @Override
  public ModuleClient service(ModuleService service) {
    return (ModuleClient) super.service(service);
  }

  /**
   * {@link ModuleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ModuleCreateRequestDto request) {
    return new CreateExecutor(ModuleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ModuleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ModuleGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ModuleGetManyResponseDto>(
        ModuleGetManyResponseDto.class,
        ModuleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ModuleService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModuleGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ModuleService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModuleDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    return new GetOneExecutor<ModuleDto>(ModuleDto.class,
        ModuleService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link ModuleService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModuleDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    return new GetOneExecutor<ModuleDto>(ModuleDto.class,
        ModuleService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link ModuleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ModuleUpdateRequestDto request) {
    return new IdentifiableExecutor(ModuleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ModuleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ModuleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
