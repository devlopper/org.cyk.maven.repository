package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette classe représente le code de {@link PersonType}.
 *
 * @author Desysoft
 *
 */
public class PersonTypeCode {

  private PersonTypeCode() {

  }

  /**
   * Personne physique.
   */
  public static final String NATURAL_PERSON = "PERSONNE_PHYSIQUE";


  /**
   * Personne morale.
   */
  public static final String LEGAL_PERSON = "PERSONNE_MORALE";



}
