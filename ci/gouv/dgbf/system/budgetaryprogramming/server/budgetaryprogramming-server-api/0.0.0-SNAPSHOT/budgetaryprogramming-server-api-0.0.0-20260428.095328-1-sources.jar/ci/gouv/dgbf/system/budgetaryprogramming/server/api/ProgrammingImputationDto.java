package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasLockAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLockIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une imputation de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingImputationDto extends AbstractIdentifiableAuditableDto
    implements HasProgrammingIdentifierDto, HasProgrammingAsStringDto, HasImputationIdentifierDto,
    HasImputationAsStringDto, HasLockIdentifierDto, HasLockAsStringDto {

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  private String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  private String programmingAsString;

  @JsonbProperty(JSON_IMPUTATION_IDENTIFIER)
  private String imputationIdentifier;

  @JsonbProperty(JSON_IMPUTATION_AS_STRING)
  private String imputationAsString;

  @JsonbProperty(JSON_LOCK_IDENTIFIER)
  private String lockIdentifier;

  @JsonbProperty(JSON_LOCK_AS_STRING)
  private String lockAsString;

  /**
   * Indique si l'imputation est une dépense.
   */
  @JsonbProperty(JSON_EXPENDITURE)
  private Boolean expenditure;

  /**
   * Montant saisi pour l'horizon N.
   */
  @JsonbProperty(JSON_INPUTTED_AMOUNT_N)
  private Long inputtedAmountN;

  /**
   * Montant saisi pour l'horizon N+1.
   */
  @JsonbProperty(JSON_INPUTTED_AMOUNT_N1)
  private Long inputtedAmountN1;

  /**
   * Montant saisi pour l'horizon N+2.
   */
  @JsonbProperty(JSON_INPUTTED_AMOUNT_N2)
  private Long inputtedAmountN2;

  /**
   * Montant arbitré pour l'horizon N.
   */
  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N)
  private Long arbitratedAmountN;

  /**
   * Montant arbitré pour l'horizon N+1.
   */
  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1)
  private Long arbitratedAmountN1;

  /**
   * Montant arbitré pour l'horizon N+2.
   */
  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2)
  private Long arbitratedAmountN2;

  /**
   * Montant validé pour l'horizon N.
   */
  @JsonbProperty(JSON_VALIDATED_AMOUNT_N)
  private Long validatedAmountN;

  /**
   * Montant validé pour l'horizon N+1.
   */
  @JsonbProperty(JSON_VALIDATED_AMOUNT_N1)
  private Long validatedAmountN1;

  /**
   * Montant validé pour l'horizon N+2.
   */
  @JsonbProperty(JSON_VALIDATED_AMOUNT_N2)
  private Long validatedAmountN2;

  /**
   * Montant intégré pour l'horizon N.
   */
  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N)
  private Long integratedAmountN;

  /**
   * Montant intégré pour l'horizon N+1.
   */
  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N1)
  private Long integratedAmountN1;

  /**
   * Montant intégré pour l'horizon N+2.
   */
  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N2)
  private Long integratedAmountN2;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idImputationProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "imputationProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "imputation de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "imputations de programmation";

  /**
   * Identifiant json pour {@link #expenditure}.
   */
  public static final String JSON_EXPENDITURE = "estDepense";

  /**
   * Identifiant json pour {@link #inputtedAmountN}.
   */
  public static final String JSON_INPUTTED_AMOUNT_N = "montantSaisiN";

  /**
   * Identifiant json pour {@link #inputtedAmountN1}.
   */
  public static final String JSON_INPUTTED_AMOUNT_N1 = "montantSaisiN1";

  /**
   * Identifiant json pour {@link #inputtedAmountN2}.
   */
  public static final String JSON_INPUTTED_AMOUNT_N2 = "montantSaisiN2";

  /**
   * Identifiant json pour {@link #arbitratedAmountN}.
   */
  public static final String JSON_ARBITRATED_AMOUNT_N = "montantArbitreN";

  /**
   * Identifiant json pour {@link #arbitratedAmountN1}.
   */
  public static final String JSON_ARBITRATED_AMOUNT_N1 = "montantArbitreN1";

  /**
   * Identifiant json pour {@link #arbitratedAmountN2}.
   */
  public static final String JSON_ARBITRATED_AMOUNT_N2 = "montantArbitreN2";

  /**
   * Identifiant json pour {@link #validatedAmountN}.
   */
  public static final String JSON_VALIDATED_AMOUNT_N = "montantValideN";

  /**
   * Identifiant json pour {@link #validatedAmountN1}.
   */
  public static final String JSON_VALIDATED_AMOUNT_N1 = "montantValideN1";

  /**
   * Identifiant json pour {@link #validatedAmountN2}.
   */
  public static final String JSON_VALIDATED_AMOUNT_N2 = "montantValideN2";

  /**
   * Identifiant json pour {@link #integratedAmountN}.
   */
  public static final String JSON_INTEGRATED_AMOUNT_N = "montantIntegreN";

  /**
   * Identifiant json pour {@link #integratedAmountN1}.
   */
  public static final String JSON_INTEGRATED_AMOUNT_N1 = "montantIntegreN1";

  /**
   * Identifiant json pour {@link #integratedAmountN2}.
   */
  public static final String JSON_INTEGRATED_AMOUNT_N2 = "montantIntegreN2";

}