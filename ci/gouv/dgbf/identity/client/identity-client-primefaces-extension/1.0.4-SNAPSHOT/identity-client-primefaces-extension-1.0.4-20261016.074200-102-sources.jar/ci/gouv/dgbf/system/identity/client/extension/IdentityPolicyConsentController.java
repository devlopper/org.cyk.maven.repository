package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.IdentifiableActionController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentAcceptRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRefuseRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentUpdateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentStatus;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionClient;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionFilter;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityAsStringDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de {@link IdentityPolicyConsentDto}. L'étendue de la
 * liste - tous les consentements, ou seulement ceux de l'identité connectée
 * ({@link #connectedUserOnly}) - est fixée par la page appelante. Aucune notion de rôle ne
 * conditionne ce qui est vu ou fait (retrait temporaire, TCH_IDT_763) : tous les boutons
 * (Ajouter, Mettre à jour, Supprimer, Accepter, Refuser) sont proposés partout, sauf en lecture
 * seule ({@link #readOnly}).
 *
 * @author desysoft
 *
 */
@Dependent
public class IdentityPolicyConsentController extends AbstractController {

  static final String EMPTY_CONTENT_FILE_PATH = "/extension/empty.xhtml";

  /**
   * Identifiant ne correspondant à aucune {@link IdentityDto} réelle, utilisé en repli à
   * l'initialisation de {@link #filterController} en self-service quand
   * {@link #identityIdentifier} n'a pas pu être résolu.
   */
  static final String UNRESOLVABLE_IDENTITY_IDENTIFIER = "00000000-0000-0000-0000-000000000000";

  @Inject
  IdentityPolicyConsentClient client;

  @Inject
  IdentityClient identityClient;

  @Inject
  PolicyVersionClient policyVersionClient;

  @Inject
  IdentityPolicyConsentRequestMapper requestMapper;

  /**
   * Identifiant réel (PK) de l'{@link IdentityDto} de l'utilisateur connecté, distinct de
   * {@link #userIdentifier} qui porte le login Keycloak (ex. email), résolu par
   * {@link #resolveConnectedIdentityIdentifier()}.
   */
  String identityIdentifier;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentityPolicyConsentFilterController filterController;

  @Inject
  @Getter
  IdentifiableActionController acceptActionController;

  @Inject
  @Getter
  IdentifiableActionController refuseActionController;

  /**
   * Accepter une ligne de la liste : bascule du statut de ce consentement-là, quelle que soit son
   * identité (mise à jour, TCH_IDT_749/763).
   */
  @Inject
  @Getter
  IdentifiableActionController acceptRecordActionController;

  /**
   * Refuser une ligne de la liste (même principe que {@link #acceptRecordActionController}).
   */
  @Inject
  @Getter
  IdentifiableActionController refuseRecordActionController;

  /**
   * Vrai pour « Mes consentements » : la liste est restreinte à l'identité connectée et propose
   * les politiques en attente de décision. Fixé par la page appelante, avant
   * {@link #initialize()} - jamais déduit d'un rôle (TCH_IDT_763).
   */
  @Getter
  @Setter
  boolean connectedUserOnly;

  /**
   * Force la lecture seule (ex. onglet Consentements de la fiche identité, en attendant la
   * refonte maître / détail). À positionner avant {@link #initialize()}.
   */
  @Setter
  boolean readOnly;

  /**
   * Vrai si la liste propose la création, la mise à jour, la suppression, l'acceptation et le
   * refus — DÉROGATION TEMPORAIRE à RG_IDT_CST_02, à retirer avant la mise en production
   * (TCH_IDT_749).
   */
  @Getter
  boolean editable;

  /* Champs du formulaire d'enregistrement (distincts de ceux du filtre) */

  @Inject
  @Getter
  IdentitySelectOneController identitySelectOneController;

  @Inject
  @Getter
  PolicyVersionSelectOneController policyVersionSelectOneController;

  @Inject
  @Getter
  IdentityPolicyConsentDecisionStatusSelectOneController statusSelectOneController;

  /**
   * Politiques actives pour lesquelles l'identité connectée n'a exprimé aucune décision
   * (RU_IDT_004) — calculée côté client par différence entre les versions de politique actives
   * et les versions déjà couvertes par un consentement de l'identité (TCH_IDT_534, décision de
   * conception du 2026-09-02 : pas de nouveau verbe API, composition de deux lectures
   * existantes). Toujours vide en back-office.
   */
  @Getter
  List<PolicyVersionDto> undecidedActivePolicyVersions = Collections.emptyList();

  /**
   * Cette méthode permet d'initialiser. Appelée explicitement par la page appelante (jamais
   * automatiquement depuis {@link #postConstruct()}), afin de lui laisser l'occasion de
   * pré-positionner {@link #filterController}'s filter (ex. {@code identityIdentifier}) avant
   * l'initialisation — même patron que {@code IdentitiesGroupReadPage}/{@code
   * IdentityGroupReadPage}.
   */
  public void initialize() {
    editable = !readOnly;
    name = connectedUserOnly ? "Mes consentements" : "Consentements";

    listController.setEntityClass(IdentityPolicyConsentDto.class);
    listController.setClient(client);

    ProjectionDto projection = new ProjectionDto();
    listController.setFilterController(filterController);
    filterController.initialize();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER,
        IdentityPolicyConsentDto.JSON_POLICY_VERSION_AS_STRING, HasStatusDto.JSON_STATUS,
        HasStatusAsStringDto.JSON_STATUS_AS_STRING);
    if (connectedUserOnly) {
      identityIdentifier = resolveConnectedIdentityIdentifier();
      /*
       * DynamicQueryParameters.Predicate.addable() ignore silencieusement un prédicat de valeur
       * nulle (au lieu de ne renvoyer aucun résultat) : si identityIdentifier n'a pas pu être
       * résolu, un identifiant improbable garantit une liste vide plutôt qu'une requête non
       * filtrée montrant les consentements de toutes les identités.
       */
      filterController.getFilter().setIdentityIdentifier(
          Core.getOrDefaultIfNull(identityIdentifier, UNRESOLVABLE_IDENTITY_IDENTIFIER));
      undecidedActivePolicyVersions = computeUndecidedActivePolicyVersions();
    } else {
      projection.addNames(HasIdentityAsStringDto.JSON_IDENTITY_AS_STRING);
    }
    listController.getReadController().setProjection(projection);

    /*
     * useAsReadOnly() masque aussi le bouton de filtre, utile dans tous les cas : on le réaffiche
     * explicitement (VC9). Ceci doit précéder listController.initialize(), qui résout le chemin
     * du formulaire de filtre selon l'état "rendered" du bouton à cet instant précis.
     */
    if (!editable) {
      listController.useAsReadOnly();
    }
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    if (!editable) {
      /*
       * useAsReadOnly() masque les boutons Ajouter/Modifier mais ListController.initialize()
       * pointe quand même createDialog/updateDialog vers component/saveForm.xhtml : on redirige
       * ces dialogues vers le composant vide partagé.
       */
      listController.getCreateDialog().setContentFilePath(EMPTY_CONTENT_FILE_PATH);
      listController.getUpdateDialog().setContentFilePath(EMPTY_CONTENT_FILE_PATH);
      return;
    }

    initializeAdministration();
    initializeDecisions();
  }

  /**
   * Cette méthode permet de brancher l'acceptation et le refus : par ligne (statut du
   * consentement de la ligne) et, pour « Mes consentements », sur les politiques en attente de
   * décision de l'identité connectée (find-or-create, RG_IDT_CST_02).
   */
  void initializeDecisions() {
    acceptRecordActionController.setFunction(decideRecordFunction(
        IdentityPolicyConsentStatus.ACCEPTED));
    listController.configureAction(acceptRecordActionController);

    refuseRecordActionController.setFunction(decideRecordFunction(
        IdentityPolicyConsentStatus.REFUSED));
    listController.configureAction(refuseRecordActionController);

    acceptActionController.setFunction(acceptFunction());
    listController.configureAction(acceptActionController);
    acceptActionController
        .addResponseConsumer(response -> refreshUndecidedActivePolicyVersions());

    refuseActionController.setFunction(refuseFunction());
    listController.configureAction(refuseActionController);
    refuseActionController
        .addResponseConsumer(response -> refreshUndecidedActivePolicyVersions());

    /*
     * ListController.initialize() dimensionne la colonne d'actions sur les seuls boutons CRUD
     * standards : sans cet élargissement, les boutons Accepter/Refuser n'ont pas de place.
     */
    listController.getDataTable().getActionColumn().setWidth("320px");
  }

  /**
   * Cette méthode permet de brancher la création, la mise à jour (statut seul) et la suppression
   * par l'administrateur — DÉROGATION TEMPORAIRE à RG_IDT_CST_02 (TCH_IDT_749). Les règles
   * (version active, couple unique, bascule Accepté / Refusé seule) sont contrôlées côté serveur.
   */
  void initializeAdministration() {
    /*
     * Pré-remplissage depuis le filtre : l'onglet Consentements de la fiche version de politique
     * (TCH_IDT_756) fixe la version, que le formulaire ne propose alors plus de choisir.
     */
    listController.getCreateController().addEntityConsumer(entity -> {
      ((IdentityPolicyConsentDto) entity)
          .setIdentityIdentifier(filterController.getFilter().getIdentityIdentifier());
      ((IdentityPolicyConsentDto) entity)
          .setPolicyVersionIdentifier(filterController.getFilter().getPolicyVersionIdentifier());
    });
    listController.getCreateController().setFunction(entity -> {
      IdentityPolicyConsentCreateRequestDto request =
          requestMapper.mapCreate((IdentityPolicyConsentDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasStatusDto.JSON_STATUS));
    listController.getUpdateController().addEntityConsumer(entity -> {
      IdentityPolicyConsentStatus status = ((IdentityPolicyConsentDto) entity).getStatus();
      statusSelectOneController.getSelectOneMenu()
          .writeValue(status == null ? null : status.name());
    });
    listController.getUpdateController().setFunction(entity -> {
      IdentityPolicyConsentUpdateRequestDto request =
          requestMapper.mapUpdate((IdentityPolicyConsentDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });

    // Recherche par saisie, jamais la liste complète des identités (TCH_IDT_764).
    identitySelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityPolicyConsentDto.class)
            .setIdentityIdentifier(identifier));
    policyVersionSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityPolicyConsentDto.class)
            .setPolicyVersionIdentifier(identifier));
    statusSelectOneController.getSelectOneMenu()
        .addValueConsumer(name -> listController
            .getCreateControllerOrUpdateControllerEntityAs(IdentityPolicyConsentDto.class)
            .setStatus(name == null ? null : IdentityPolicyConsentStatus.valueOf(name)));
  }

  void refreshUndecidedActivePolicyVersions() {
    undecidedActivePolicyVersions = computeUndecidedActivePolicyVersions();
  }

  /**
   * Cette méthode permet de calculer les politiques actives pour lesquelles l'identité connectée
   * n'a exprimé aucune décision (RU_IDT_004) — versions actives moins celles déjà couvertes par
   * un consentement existant de cette identité, sans rien persister (RG_IDT_CST_02). Composition
   * côté client de deux lectures existantes plutôt qu'un nouveau verbe API dédié (TCH_IDT_534,
   * décision de conception du 2026-09-02).
   *
   * @return politiques actives sans décision, ou liste vide si l'identité n'a pas pu être résolue
   */
  @SuppressWarnings("unchecked")
  List<PolicyVersionDto> computeUndecidedActivePolicyVersions() {
    if (identityIdentifier == null) {
      return Collections.emptyList();
    }
    PolicyVersionFilter activeFilter = new PolicyVersionFilter();
    activeFilter.setIsActive(true);
    ProjectionDto activeProjection = new ProjectionDto();
    activeProjection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        PolicyVersionDto.JSON_POLICY_AS_STRING);
    List<PolicyVersionDto> activePolicyVersions =
        (List<PolicyVersionDto>) AbstractGetByPageResponseDto.getDatas(policyVersionClient
            .getMany(activeProjection, activeFilter.toDto(), null, userIdentifier, null));

    IdentityPolicyConsentFilter consentFilter = new IdentityPolicyConsentFilter();
    consentFilter.setIdentityIdentifier(identityIdentifier);
    ProjectionDto consentProjection = new ProjectionDto();
    consentProjection.addNames(IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER);
    List<IdentityPolicyConsentDto> consents =
        (List<IdentityPolicyConsentDto>) AbstractGetByPageResponseDto.getDatas(client
            .getMany(consentProjection, consentFilter.toDto(), null, userIdentifier, null));
    Set<String> decidedPolicyVersionIdentifiers = consents.stream()
        .map(IdentityPolicyConsentDto::getPolicyVersionIdentifier).collect(Collectors.toSet());

    return activePolicyVersions.stream()
        .filter(policyVersion -> !decidedPolicyVersionIdentifiers
            .contains(policyVersion.getIdentifier()))
        .toList();
  }

  /**
   * Cette méthode permet de résoudre le PK {@link IdentityDto} de l'utilisateur connecté à partir
   * de son login Keycloak ({@link #userIdentifier}, ex. email) : les deux espaces d'identifiants
   * sont distincts, {@link IdentityDto#getIdentifier()} n'est jamais généré à partir du login
   * (voir {@code AbstractIdentifiable.generateIdentifier()}, toujours un UUID aléatoire).
   *
   * @return identifiant {@link IdentityDto} correspondant à {@link #userIdentifier}, ou
   *         {@code null} si aucune identité ne correspond
   */
  String resolveConnectedIdentityIdentifier() {
    IdentityFilter filter = new IdentityFilter();
    filter.setEmailAddress(userIdentifier);
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    IdentityDto identity = identityClient.getOne(projection, filter.toDto(), userIdentifier, null);
    return identity == null ? null : identity.getIdentifier();
  }

  // Visibilité des actions selon le statut courant (bascule libre Accepté <-> Refusé,
  // RG_IDT_CST_04) ; aucune condition de rôle (TCH_IDT_763). Toujours faux en lecture seule.

  /**
   * Cette méthode permet de savoir si un consentement peut être accepté (déjà Refusé, bascule
   * vers Accepté).
   *
   * @param record consentement
   * @return si le consentement peut être accepté
   */
  public boolean isAcceptable(Object record) {
    return editable && isStatus(record, IdentityPolicyConsentStatus.REFUSED);
  }

  /**
   * Cette méthode permet de savoir si un consentement peut être refusé (déjà Accepté, bascule
   * vers Refusé — couvre aussi l'ancien "retrait volontaire", fusionné ici).
   *
   * @param record consentement
   * @return si le consentement peut être refusé
   */
  public boolean isRefusable(Object record) {
    return editable && isStatus(record, IdentityPolicyConsentStatus.ACCEPTED);
  }

  boolean isStatus(Object record, IdentityPolicyConsentStatus status) {
    return status.equals(((IdentityPolicyConsentDto) record).getStatus());
  }

  // Actions

  Function<String, IdentifiableResponseDto> acceptFunction() {
    return policyVersionIdentifier -> {
      IdentityPolicyConsentAcceptRequestDto request = new IdentityPolicyConsentAcceptRequestDto();
      request.setIdentityIdentifier(identityIdentifier);
      request.setPolicyVersionIdentifier(policyVersionIdentifier);
      request.setFrontEndBaseUri("");
      request.setAuditWho(userIdentifier);
      return client.accept(request);
    };
  }

  Function<String, IdentifiableResponseDto> refuseFunction() {
    return policyVersionIdentifier -> {
      IdentityPolicyConsentRefuseRequestDto request = new IdentityPolicyConsentRefuseRequestDto();
      request.setIdentityIdentifier(identityIdentifier);
      request.setPolicyVersionIdentifier(policyVersionIdentifier);
      request.setFrontEndBaseUri("");
      request.setAuditWho(userIdentifier);
      return client.refuse(request);
    };
  }

  /**
   * Cette méthode permet de fixer le statut du consentement d'une ligne (Accepter / Refuser de la
   * liste), par la mise à jour administrateur - les règles serveur s'appliquent : version active,
   * bascule Accepté / Refusé seule (TCH_IDT_749/763).
   *
   * @param status statut visé
   * @return fonction par identifiant de consentement
   */
  Function<String, IdentifiableResponseDto> decideRecordFunction(
      IdentityPolicyConsentStatus status) {
    return identifier -> {
      IdentityPolicyConsentUpdateRequestDto request = new IdentityPolicyConsentUpdateRequestDto();
      request.setIdentifier(identifier);
      request.setStatus(status);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }
}
