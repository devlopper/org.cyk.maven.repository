/* Integration explicite avec un p:dialog : open(widgetVar), cancel(element),
   saved(element,args). Les valeurs ne sont jamais envoyees ou stockees ici. */
(function (global) {
  'use strict';
  if (global.DgbfForms) return;
  const states = new WeakMap();
  let pendingOpener = null;
  function values(root) {
    return JSON.stringify(Array.from(root.querySelectorAll('input,select,textarea'))
      .filter(field => (field.name || field.type === 'file') && !field.disabled && field.type !== 'submit'
        && !field.name.includes('jakarta.faces.ViewState') && !field.name.includes('javax.faces.ViewState'))
      .map(field => [field.name || field.id, field.type === 'file'
        ? Array.from(field.files || []).map(file => [file.name,file.size,file.lastModified])
        : (field.type === 'checkbox' || field.type === 'radio') ? [field.value,field.checked] : field.value]));
  }
  function rootOf(element) { return element.closest('[data-dgbf-form]'); }
  function describeFields(root) {
    root.querySelectorAll('.dgbf-form-field').forEach((field,index) => {
      const descriptions = Array.from(field.querySelectorAll('.dgbf-field-help,.ui-message'))
        .filter(node => node.textContent.trim());
      descriptions.forEach((node,descriptionIndex) => {
        if (!node.id) node.id = root.id + '-field-' + index + '-description-' + descriptionIndex;
      });
      field.querySelectorAll('input:not([type=hidden]),textarea,[role=combobox]').forEach(control => {
        const original = (control.getAttribute('aria-describedby') || '').split(/\s+/)
          .filter(id => id && document.getElementById(id));
        const ids = Array.from(new Set(original.concat(descriptions.map(node => node.id))));
        if (ids.length) control.setAttribute('aria-describedby',ids.join(' '));
      });
    });
  }
  function initialize(root, widget) {
    let state = states.get(root);
    if (state) return state;
    state = { baseline: values(root), widget: widget, confirming: false };
    states.set(root,state);
    describeFields(root);
    root.querySelector('[data-form-keep]').addEventListener('click',() => keep(root));
    root.querySelector('[data-form-abandon]').addEventListener('click',() => close(root));
    return state;
  }
  function close(root) {
    const state = states.get(root);
    keep(root, false);
    if (state.widget) state.widget.hide();
    else if (root.dataset.cancelUrl) global.location.assign(root.dataset.cancelUrl);
  }
  function keep(root, restoreFocus) {
    const state = states.get(root);
    root.querySelector('[data-form-discard]').hidden = true;
    root.querySelector('[data-form-main]').hidden = false;
    state.confirming = false;
    if (state.scrollTop != null) root.querySelector('.dgbf-form-body').scrollTop = state.scrollTop;
    if (state.widget) {
      state.widget.jq.removeClass('dgbf-discarding').attr('aria-labelledby',state.labelledBy);
    }
    if (restoreFocus !== false && state.previousFocus && state.previousFocus.isConnected) state.previousFocus.focus();
  }
  function cancel(element) {
    const root = rootOf(element);
    if (!root) return;
    const state = initialize(root);
    if (state.confirming) return;
    if (values(root) === state.baseline) { close(root); return; }
    state.previousFocus = document.activeElement;
    state.scrollTop = root.querySelector('.dgbf-form-body').scrollTop;
    state.confirming = true;
    const confirmation = root.querySelector('[data-form-discard]');
    const title = confirmation.querySelector('[data-discard-title]');
    title.id = root.id + '-discard-title';
    confirmation.setAttribute('aria-labelledby',title.id);
    root.querySelector('[data-form-main]').hidden = true;
    confirmation.hidden = false;
    if (state.widget) state.widget.jq.addClass('dgbf-discarding').attr('aria-labelledby',title.id);
    confirmation.querySelector('[data-form-keep]').focus();
  }
  function open(widgetVar) {
    const widget = global.PF(widgetVar);
    const root = widget.jq[0].querySelector('[data-dgbf-form]');
    if (!root) return;
    const state = initialize(root,widget);
    state.widget = widget;
    state.labelledBy = widget.jq.attr('aria-labelledby');
    state.baseline = values(root);
    state.opener = widget.jq.data('dgbf-form-opener') ||
      (pendingOpener && pendingOpener.isConnected ? pendingOpener : document.activeElement);
    pendingOpener = null;
    keep(root, false);
    const title = widget.jq[0].querySelector('.ui-dialog-title');
    if (title) { title.setAttribute('tabindex','-1'); title.focus(); }
  }
  function closed(widgetVar) {
    const widget = global.PF(widgetVar);
    const root = widget.jq[0].querySelector('[data-dgbf-form]');
    if (!root) return;
    const state = states.get(root);
    if (state && state.opener && state.opener.isConnected) state.opener.focus();
  }
  function saved(element,args) {
    const root = rootOf(element);
    if (!root) return;
    const state = initialize(root);
    describeFields(root);
    if (args && args.validationFailed) {
      const feedback = root.querySelector('[data-form-feedback]');
      if (feedback) feedback.focus();
    } else if (args && args.dgbfFormSaved === true) {
      state.baseline = values(root);
    }
  }
  // Intercepter la croix avant le gestionnaire jQuery de PrimeFaces.
  document.addEventListener('click',event => {
    const trigger = event.target.closest('.crud-list-button-create,.crud-list-button-update');
    if (trigger) pendingOpener = trigger;
  },true);
  document.addEventListener('click',event => {
    const closeButton = event.target.closest('.dgbf-form-dialog .ui-dialog-titlebar-close');
    if (!closeButton) return;
    const root = closeButton.closest('.ui-dialog').querySelector('[data-dgbf-form]');
    if (!root || !states.has(root)) return;
    event.preventDefault(); event.stopImmediatePropagation(); cancel(root);
  },true);
  document.addEventListener('keydown',event => {
    if (event.key !== 'Escape' || event.defaultPrevented) return;
    const dialog = event.target.closest('.dgbf-form-dialog');
    if (!dialog) return;
    // Laisser d'abord PrimeFaces fermer ses listes, calendriers et suggestions.
    if (global.jQuery('.ui-selectonemenu-panel:visible,.ui-datepicker:visible,.ui-autocomplete-panel:visible,.ui-selectcheckboxmenu-panel:visible').length) return;
    const root = dialog.querySelector('[data-dgbf-form]');
    const state = states.get(root);
    if (!state) return;
    event.preventDefault(); event.stopPropagation();
    state.confirming ? keep(root) : cancel(root);
  });
  global.addEventListener('beforeunload',event => {
    const dirty = Array.from(document.querySelectorAll('[data-dgbf-form]')).some(root => root.getClientRects().length && states.has(root) && values(root) !== states.get(root).baseline);
    if (dirty) { event.preventDefault(); event.returnValue = ''; }
  });
  global.DgbfForms = {open:open,closed:closed,cancel:cancel,saved:saved,
    show:function (widgetVar,trigger) { const widget=global.PF(widgetVar); widget.jq.data('dgbf-form-opener',trigger); widget.show(); },
    page:function (element,url) { const root = rootOf(element); root.dataset.cancelUrl=url; initialize(root); }};
})(window);
