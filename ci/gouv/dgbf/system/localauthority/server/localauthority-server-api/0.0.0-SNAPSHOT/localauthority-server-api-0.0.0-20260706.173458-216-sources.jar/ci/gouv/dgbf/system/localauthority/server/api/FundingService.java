package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link FundingDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = FundingService.PATH)
@Tag(name = "Gestion des financements")
public interface FundingService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "financements";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_FINANCEMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un financement",
      description = "Ce service permet de créer un financement")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(FundingCreateRequestDto request);

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface SaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant {@link FundingTypeDto}.
     *
     * @return identifiant {@link FundingTypeDto}
     */
    String getFundingTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link FundingTypeDto}.
     *
     * @param modeIdentifier identifiant {@link FundingTypeDto}
     */
    void setFundingTypeIdentifier(String modeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link LessorDto}.
     *
     * @return identifiant {@link LessorDto}
     */
    String getLessorIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link LessorDto}.
     *
     * @param lessorIdentifier identifiant {@link LessorDto}
     */
    void setLessorIdentifier(String lessorIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
     *
     * @return identifiant {@link TriennialProgramActivityDto}
     */
    String getTriennialProgramActivityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
     *
     * @param triennialProgramActivityIdentifier identifiant {@link TriennialProgramActivityDto}
     */
    void setTriennialProgramActivityIdentifier(String triennialProgramActivityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant {@link EconomicNatureDto}.
     *
     * @return identifiant {@link EconomicNatureDto}
     */
    String getEconomicNatureIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant {@link EconomicNatureDto}.
     *
     * @param economicNatureIdentifier identifiant {@link EconomicNatureDto}
     */
    void setEconomicNatureIdentifier(String economicNatureIdentifier);

    /**
     * Cette méthode permet d'obtenir le le montant 1.
     *
     * @return montant 1
     */
    long getAmount1();

    /**
     * Cette méthode permet d'assigner le le montant 1.
     *
     * @param amount1 montant 1
     */
    void setAmount1(long amount1);

    /**
     * Cette méthode permet d'obtenir le le montant 1.
     *
     * @return montant 2
     */
    long getAmount2();

    /**
     * Cette méthode permet d'assigner le le montant 1.
     *
     * @param amount2 montant 2
     */
    void setAmount2(long amount2);

    /**
     * Cette méthode permet d'obtenir le le montant 2.
     *
     * @return montant 3
     */
    long getAmount3();

    /**
     * Cette méthode permet d'assigner le le montant 2.
     *
     * @param amount3 montant 3
     */
    void setAmount3(long amount3);

    /**
     * Identifiant champ json de {@link FundingTypeDto}.
     */
    String JSON_FUNDING_TYPE_IDENTIFIER = FundingDto.JSON_FUNDING_TYPE_IDENTIFIER;

    /**
     * Identifiant champ json de {@link LessorDto}.
     */
    String JSON_LESSOR_IDENTIFIER = FundingDto.JSON_LESSOR_IDENTIFIER;

    /**
     * Identifiant champ json de {@link EconomicNatureDto}.
     */
    String JSON_ECONOMIC_NATURE_IDENTIFIER = FundingDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

    /**
     * Identifiant champ json de {@link TriennialProgramActivityDto}.
     */
    String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
        FundingDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;

    /**
     * Identifiant champ json du montant 1.
     */
    String JSON_AMOUNT_1 = FundingDto.JSON_AMOUNT_1;

    /**
     * Identifiant champ json du montant 2.
     */
    String JSON_AMOUNT_2 = FundingDto.JSON_AMOUNT_2;

    /**
     * Identifiant champ json du montant 3.
     */
    String JSON_AMOUNT_3 = FundingDto.JSON_AMOUNT_3;
  }


  /**
   * Identifiant du service de création.
   */
  String CREATE_FOR_ACTION_IDENTIFIER = "CREATION_FINANCEMENT_POUR_ACTION";


  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FundingCreateRequestDto extends AbstractAuditedRequestJsonDto implements SaveRequestDto {
    @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }



  /**
   * Identifiant du service de création par {@link TriennialProgramDto} et {@link ActivityDto}.
   */
  String CREATE_BY_TRIENNIAL_PROGRAM_BY_ACTIVITY_IDENTIFIER =
      "CREATION_PAR_PROGRAMME_TRIENNAL_PAR_ACTIVITE_FINANCEMENT";

  /**
   * Chemin du service de création par {@link TriennialProgramDto} et {@link ActivityDto}.
   */
  String CREATE_BY_TRIENNIAL_PROGRAM_BY_ACTIVITY_PATH = "par-programme-triennal-par-activite";

  /**
   * Cette méthode permet de créer {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_TRIENNIAL_PROGRAM_BY_ACTIVITY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_TRIENNIAL_PROGRAM_BY_ACTIVITY_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByTriennialProgramByActivity(
      FundingCreateByTriennialProgramByActivityRequestDto request);

  /**
   * Cette classe représente la requête de création par {@link TriennialProgramDto} et
   * {@link ActivityDto} .
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FundingCreateByTriennialProgramByActivityRequestDto extends AbstractAuditedRequestJsonDto {
    @JsonbProperty(JSON_MODE_IDENTIFIER)
    private String modeIdentifier;

    @JsonbProperty(JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    /**
     * Identifiant champ json de {@link FundingTypeDto}.
     */
    public static final String JSON_MODE_IDENTIFIER = FundingDto.JSON_FUNDING_TYPE_IDENTIFIER;

    /**
     * Identifiant champ json de {@link LessorDto}.
     */
    public static final String JSON_LESSOR_IDENTIFIER = FundingDto.JSON_LESSOR_IDENTIFIER;

    /**
     * Identifiant champ json de {@link EconomicNatureDto}.
     */
    public static final String JSON_ECONOMIC_NATURE_IDENTIFIER =
        FundingDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

    /**
     * Identifiant champ json de {@link TriennialProgramDto}.
     */
    public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
        FundingDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

    /**
     * Identifiant champ json de {@link ActivityDto}.
     */
    public static final String JSON_ACTIVITY_IDENTIFIER = FundingDto.JSON_ACTIVITY_IDENTIFIER;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_FINANCEMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des financements")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = GetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class GetManyResponseDto extends AbstractGetByPageResponseDto<FundingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<FundingDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_FINANCEMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un financement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FundingDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_FINANCEMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un financement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = FundingDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_FINANCEMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un financement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(FundingUpdateRequestDto request);


  /**
   * Cette classe représente la requête de mise à jour du commentaire d'un financement.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FundingUpdateRequestDto extends ByIdentifierRequestDto implements SaveRequestDto {
    @JsonbProperty(JSON_FUNDING_TYPE_IDENTIFIER)
    private String fundingTypeIdentifier;

    @JsonbProperty(JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER)
    private String triennialProgramActivityIdentifier;

    @JsonbProperty(JSON_AMOUNT_1)
    private long amount1;

    @JsonbProperty(JSON_AMOUNT_2)
    private long amount2;

    @JsonbProperty(JSON_AMOUNT_3)
    private long amount3;
  }

  /**
   * Identifiant du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_IDENTIFIER = "MISE_A_JOUR_MONTANT_FINANCEMENT";

  /**
   * Chemin du service de mise à jour de montant.
   */
  String UPDATE_AMOUNT_PATH = FundingUpdateAmountRequestDto.JSON_AMOUNT;

  /**
   * Cette méthode permet de mettre à jour montant de {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_AMOUNT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_AMOUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateAmount(FundingUpdateAmountRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour de montant.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class FundingUpdateAmountRequestDto extends ByIdentifierRequestDto {
    /**
     * Montant.
     */
    @JsonbProperty(JSON_AMOUNT)
    private long amount;

    /**
     * Index.
     */
    @JsonbProperty(JSON_INDEX)
    private int index;

    /**
     * Identifiant json {@link #amount}.
     */
    public static final String JSON_AMOUNT = "montant";

    /**
     * Identifiant json {@link #index}.
     */
    public static final String JSON_INDEX = "index";
  }

  /**
   * Identifiant du service de mise à jour du commentaire d'un financement.
   */
  String UPDATE_COMMENT_IDENTIFIER = "MISE_A_JOUR_COMMENTAIRE_FINANCEMENT";

  /**
   * Chemin du service de mise à jour du commentaire d'un financement.
   */
  String UPDATE_COMMENT_PATH = FundingUpdateCommentRequestDto.JSON_COMMENT;

  /**
   * Cette méthode permet de mettre à jour le commentaire d'un {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_COMMENT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_COMMENT_IDENTIFIER,
      description = "Ce service permet de mettre à jour le commentaire")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response updateComment(FundingUpdateCommentRequestDto request);

  /**
   * Cette classe représente la requête de création du commentaire d'un financement.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class FundingUpdateCommentRequestDto extends ByIdentifierRequestDto {
    /**
     * Commentaire.
     */
    @JsonbProperty(JSON_COMMENT)
    private String comment;

    /**
     * Identifiant json {@link #comment}.
     */
    public static final String JSON_COMMENT = "commentaire";
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_FINANCEMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link FundingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un financement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
