package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipConstantDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T09:54:21+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipConstantRequestMapperImpl implements PayslipConstantRequestMapper {

    @Override
    public PayslipConstantService.PayslipConstantCreateRequestDto mapCreate(PayslipConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipConstantService.PayslipConstantCreateRequestDto payslipConstantCreateRequestDto = new PayslipConstantService.PayslipConstantCreateRequestDto();

        payslipConstantCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipConstantCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipConstantCreateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipConstantCreateRequestDto.setPayrollConstantIdentifier( arg0.getPayrollConstantIdentifier() );
        payslipConstantCreateRequestDto.setValue( arg0.getValue() );

        return payslipConstantCreateRequestDto;
    }

    @Override
    public PayslipConstantService.PayslipConstantUpdateRequestDto mapUpdate(PayslipConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipConstantService.PayslipConstantUpdateRequestDto payslipConstantUpdateRequestDto = new PayslipConstantService.PayslipConstantUpdateRequestDto();

        payslipConstantUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipConstantUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipConstantUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipConstantUpdateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipConstantUpdateRequestDto.setPayrollConstantIdentifier( arg0.getPayrollConstantIdentifier() );
        payslipConstantUpdateRequestDto.setValue( arg0.getValue() );

        return payslipConstantUpdateRequestDto;
    }
}
