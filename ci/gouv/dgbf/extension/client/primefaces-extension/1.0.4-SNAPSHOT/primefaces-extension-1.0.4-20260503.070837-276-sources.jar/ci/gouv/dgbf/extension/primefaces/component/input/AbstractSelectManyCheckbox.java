package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une sélection de plusieurs valeurs par checkbox.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectManyCheckbox<T> extends AbstractSelectMany<T> {

  private String layout;
  private Integer columns;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectManyCheckbox() {
    layout = "lineDirection";
    columns = 12;
  }
}
