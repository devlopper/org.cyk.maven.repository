package ci.gouv.dgbf.extension.primefaces.component.chart;

import ci.gouv.dgbf.extension.core.ColorPalette;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.ChartManager;
import ci.gouv.dgbf.extension.primefaces.FilterDtoGetter;
import ci.gouv.dgbf.extension.primefaces.Style;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de graphique.
 *
 * @author Christian
 *
 */
@Dependent
public class ChartController extends AbstractController {

  @Getter
  @Setter
  Object client;

  @Getter
  @Setter
  Object filter;

  @Getter
  ChartDto chart;

  @Getter
  @Setter
  String keyName;

  @Getter
  @Setter
  String valueName;

  @Getter
  @Setter
  String variationName;

  @Getter
  LineChart.Builder lineChartBuilder;

  @Getter
  LineChart lineChart;

  @Getter
  PieChart.Builder pieChartBuilder;

  @Getter
  PieChart pieChart;

  @Getter
  BarChart.Builder barChartBuilder;

  @Getter
  BarChart barChart;

  @Getter
  @Setter
  Consumer<Object> consumer;

  @Getter
  @Setter
  Supplier<GetChartResponseDto> supplier;

  @Getter
  @Setter
  Supplier<Object> filterSupplier;

  @Inject
  FilterDtoGetter filterDtoGetter;

  @Getter
  @Setter
  ColorPalette colorPalette;

  @Inject
  ChartManager manager;

  @Getter
  @Setter
  Style containerStyle;

  /**
   * Affichage du titre dans le graphique ; vrai si nul.
   */
  @Getter
  @Setter
  Boolean titleDisplayed;

  /**
   * Affichage de la légende ; comportement du composant graphique si nul.
   */
  @Getter
  @Setter
  Boolean legendDisplayed;

  /**
   * Une seule couleur pour un histogramme à une série ; faux si nul.
   */
  @Getter
  @Setter
  Boolean uniformColor;

  /**
   * Graduations entières sur l'axe des valeurs (barres et courbes), pour des effectifs ; faux si
   * nul.
   */
  @Getter
  @Setter
  Boolean integerValues;

  /**
   * Couleurs imposées par clé (hexadécimal, ex. "#dc2626").
   */
  @Getter
  @Setter
  Map<String, String> keyColors;

  /**
   * Cette méthode est le constructeur par défaut.
   */
  public ChartController() {
    variationName = "Variation";
    colorPalette = new ColorPalette();
    containerStyle = Style.newBuilder().build();
  }

  void prepareColors() {
    colorPalette.getRgbList().addAll(manager.getColors());
    colorPalette.getRgbaList().addAll(manager.getColorsWithReducedAlpha());
  }

  /**
   * Cette méthode permet de construire {@link LineChart}.
   *
   * @return this
   */
  public ChartController buildLineChart() {
    return buildModel(() -> {
      lineChartBuilder().modelBuilder().chart(chart);
      lineChartBuilder().modelBuilder().colorPalette(colorPalette);
      lineChartBuilder().modelBuilder().titleDisplayed(titleDisplayed);
      lineChartBuilder().modelBuilder().legendDisplayed(legendDisplayed);
      lineChartBuilder().modelBuilder().keyColors(keyColors);
      lineChartBuilder().modelBuilder().integerValues(integerValues);
      lineChart = lineChartBuilder().build();
      return lineChart.getModel();
    });
  }

  /**
   * Cette méthode permet d'obtenir {@link LineChart.Builder} non nul.
   *
   * @return {@link LineChart.Builder} non nul
   */
  public LineChart.Builder lineChartBuilder() {
    if (lineChartBuilder == null) {
      lineChartBuilder = LineChart.newBuilder();
      lineChartBuilder.modelBuilder(new LineChart.ModelBuilder());
    }
    return lineChartBuilder;
  }

  /**
   * Cette méthode permet de construire {@link BarChart}.
   *
   * @return this
   */
  public ChartController buildBarChart() {
    return buildModel(() -> {
      barChartBuilder().modelBuilder().chart(chart);
      barChartBuilder().modelBuilder().colorPalette(colorPalette);
      barChartBuilder().modelBuilder().titleDisplayed(titleDisplayed);
      barChartBuilder().modelBuilder().uniformColor(uniformColor);
      barChartBuilder().modelBuilder().legendDisplayed(legendDisplayed);
      barChartBuilder().modelBuilder().keyColors(keyColors);
      barChartBuilder().modelBuilder().integerValues(integerValues);
      barChart = barChartBuilder().build();
      return barChart.getModel();
    });
  }

  /**
   * Cette méthode permet d'obtenir {@link BarChart.Builder} non nul.
   *
   * @return {@link BarChart.Builder} non nul
   */
  public BarChart.Builder barChartBuilder() {
    if (barChartBuilder == null) {
      barChartBuilder = BarChart.newBuilder();
      barChartBuilder.modelBuilder(new BarChart.ModelBuilder());
    }
    return barChartBuilder;
  }

  /**
   * Cette méthode permet de construire {@link PieChart}.
   *
   * @return this
   */
  public ChartController buildPieChart() {
    return buildModel(() -> {
      pieChartBuilder().modelBuilder().chart(chart);
      pieChartBuilder().modelBuilder().colorPalette(colorPalette);
      pieChartBuilder().modelBuilder().titleDisplayed(titleDisplayed);
      pieChartBuilder().modelBuilder().legendDisplayed(legendDisplayed);
      pieChartBuilder().modelBuilder().keyColors(keyColors);
      pieChart = pieChartBuilder().build();
      return pieChart.getModel();
    });
  }

  /**
   * Cette méthode permet d'obtenir {@link PieChart.Builder} non nul.
   *
   * @return {@link PieChart.Builder} non nul
   */
  public PieChart.Builder pieChartBuilder() {
    if (pieChartBuilder == null) {
      pieChartBuilder = PieChart.newBuilder();
      pieChartBuilder.modelBuilder(new PieChart.ModelBuilder());
    }
    return pieChartBuilder;
  }

  ChartController buildModel(Supplier<Object> supplier) {
    GetChartResponseDto response = supply();
    if (GetChartResponseDto.isDatasEmpty(response)) {
      chart = null;
    } else {
      prepareColors();
      chart = response.getChart();
      Object result = supplier.get();
      consume(result);
    }
    return this;
  }

  GetChartResponseDto supply() {
    FilterDto dto = filterDtoGetter.get(filter, filterSupplier);
    if (client instanceof GetChart<?> getter) {
      supplier = () -> (GetChartResponseDto) getter.getChart(dto, userIdentifier, null);
    }
    if (supplier == null) {
      throw new IllegalStateException(
          "Le fournisseur de réponse d'obtention de graphique ne doit pas être nul.");
    }
    return new ActionExecutor<GetChartResponseDto>(this, "Obtention graphique",
        () -> supplier.get()).execute();
  }

  void consume(Object chart) {
    if (chart != null && consumer != null) {
      consumer.accept(chart);
    }
  }
}
