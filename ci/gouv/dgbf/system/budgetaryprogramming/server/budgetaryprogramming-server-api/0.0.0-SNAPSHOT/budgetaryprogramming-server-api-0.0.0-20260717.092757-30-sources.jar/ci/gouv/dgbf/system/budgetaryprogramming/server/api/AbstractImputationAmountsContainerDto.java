package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasLockAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLockIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsYearDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountNDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants d'imputation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractImputationAmountsContainerDto extends AbstractIdentifiableAuditableDto
    implements HasProgrammingIdentifierDto, HasProgrammingAsStringDto, HasExerciseAsYearDto,
    HasImputationIdentifierDto, HasImputationAsStringDto, HasActivityAsStringDto,
    HasEconomicNatureAsStringDto, HasInputtedAmountNDto, HasInputtedAmountN1Dto,
    HasInputtedAmountN2Dto, HasArbitratedAmountNDto, HasArbitratedAmountN1Dto,
    HasArbitratedAmountN2Dto, HasValidatedAmountNDto, HasValidatedAmountN1Dto,
    HasValidatedAmountN2Dto, HasIntegratedAmountNDto, HasIntegratedAmountN1Dto,
    HasIntegratedAmountN2Dto, HasLockIdentifierDto, HasLockAsStringDto {

  // Programming

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  protected String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  protected String programmingAsString;

  // Exercise

  @JsonbProperty(JSON_EXERCISE_YEAR)
  protected Integer exerciseYear;

  // Imputation

  @JsonbProperty(JSON_IMPUTATION_IDENTIFIER)
  private String imputationIdentifier;

  @JsonbProperty(JSON_IMPUTATION_AS_STRING)
  private String imputationAsString;

  // Activity

  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  protected String activityAsString;

  // Economic nature

  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  protected String economicNatureAsString;

  // ------- Amounts -------

  // Inputted amount

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N)
  protected Long inputtedAmountN;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N1)
  protected Long inputtedAmountN1;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N2)
  protected Long inputtedAmountN2;

  // Arbitrated amount

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N)
  protected Long arbitratedAmountN;

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1)
  protected Long arbitratedAmountN1;

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2)
  protected Long arbitratedAmountN2;

  // Validated amount

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N)
  protected Long validatedAmountN;

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N1)
  protected Long validatedAmountN1;

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N2)
  protected Long validatedAmountN2;

  // Integrated amount

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N)
  protected Long integratedAmountN;

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N1)
  protected Long integratedAmountN1;

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N2)
  protected Long integratedAmountN2;

  // Lock

  @JsonbProperty(JSON_LOCK_IDENTIFIER)
  protected String lockIdentifier;

  @JsonbProperty(JSON_LOCK_AS_STRING)
  protected String lockAsString;
}
