package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasName;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ActivityDto}.
 *
 * @author Christian Yao Komenan
 *
 */
@Path(value = ActivityService.PATH)
@Tag(name = "Gestion des activités")
public interface ActivityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette interface représente les données d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ActivitySaveRequestDto {
    /**
     * Cette méthode permet d'obtenir le libellé.
     *
     * @return libellé
     */
    String getName();

    /**
     * Cette méthode permet d'assigner le libellé.
     *
     * @param name libellé
     */
    void setName(String name);

    /**
     * Cette méthode permet d'obtenir la description.
     *
     * @return description
     */
    String getDescription();
    
    /**
     * Cette méthode permet d'assigner la description.
     *
     * @param description description
     */
    void setDescription(String description);
    
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ActivityTypeDto}.
     *
     * @return identifiant de {@link ActivityTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ActivityTypeDto}.
     *
     * @param typeIdentifier identifiant de {@link ActivityTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link FolderDto}.
     *
     * @return identifiant de {@link FolderDto}
     */
    String getFolderIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link FolderDto}.
     *
     * @param folderIdentifier identifiant de {@link FolderDto}
     */
    void setFolderIdentifier(String folderIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'identité du responsable.
     *
     * @return identifiant de l'identité du responsable
     */
    String getResponsibleIdentityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'identité du responsable.
     *
     * @param responsibleIdentityIdentifier identifiant de l'identité du responsable
     */
    void setResponsibleIdentityIdentifier(String responsibleIdentityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la sous-unité administrative.
     *
     * @return identifiant de la sous-unité administrative
     */
    String getSubAdministrativeUnitIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la sous-unité administrative.
     *
     * @param subAdministrativeUnitIdentifier identifiant de la sous-unité administrative
     */
    void setSubAdministrativeUnitIdentifier(String subAdministrativeUnitIdentifier);

    /**
     * Identifiant json champ nom.
     */
    String JSON_NAME = AbstractIdentifiableCodableNamableDto.JSON_NAME;

    /**
     * Identifiant json champ identifiant de {@link ActivityTypeDto}.
     */
    String JSON_TYPE_IDENTIFIER = ActivityDto.JSON_TYPE_IDENTIFIER;

    /**
     * Identifiant json champ identifiant de {@link FolderDto}.
     */
    String JSON_FOLDER_IDENTIFIER = ActivityDto.JSON_FOLDER_IDENTIFIER;

    /**
     * Identifiant json champ identifiant de l'identité du responsable.
     */
    String JSON_RESPONSIBLE_IDENTITY_IDENTIFIER = ActivityDto.JSON_RESPONSIBLE_IDENTITY_IDENTIFIER;

    /**
     * Identifiant json champ description.
     */
    String JSON_DESCRIPTION = ActivityDto.JSON_DESCRIPTION;

    /**
     * Identifiant json champ identifiant de la sous-unité administrative.
     */
    String JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER = ActivityDto
        .JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER;

  }

  /**
   * Cette méthode permet de créer {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'une activité",
      description = "Ce service permet de créer une activité")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ActivityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ActivityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements HasName, ActivitySaveRequestDto {

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_FOLDER_IDENTIFIER)
    private String folderIdentifier;

    @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
    private String responsibleIdentityIdentifier;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String subAdministrativeUnitIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des dossiers")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ActivityGetManyResponseDto extends AbstractGetByPageResponseDto<ActivityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ActivityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ActivityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ActivityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ActivityUpdateRequestDto extends ByIdentifierRequestDto
      implements HasName, ActivitySaveRequestDto {

    @JsonbProperty(JSON_NAME)
    private String name;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_FOLDER_IDENTIFIER)
    private String folderIdentifier;

    @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_IDENTIFIER)
    private String responsibleIdentityIdentifier;

    @JsonbProperty(JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER)
    private String subAdministrativeUnitIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer une activité")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
  
  /**
   * Identifiant du service d'obtention de graphique.
   */
  String GET_CHART_IDENTIFIER = "OBTENTION_GRAPHIQUE_ACTIVITE";

  /**
   * Chemin du service d'obtention de graphique.
   */
  String GET_CHART_PATH = "obtention/graphique";

  /**
   * Cette méthode permet d'obtenir un graphique.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_CHART_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_CHART_IDENTIFIER,
      description = "Ce service permet d'obtenir un graphique")
  Response getChart(GetChartRequestDto request);

  /**
   * Identifiant du service de démarrage.
   */
  String START_IDENTIFIER = "DEMARRAGE_ACTIVITE";

  /**
   * Chemin du service de démarrage.
   */
  String START_PATH = "demarrage";

  /**
   * Cette méthode permet de démarrer {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(START_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = START_IDENTIFIER,
             description = "Ce service permet de démarrer une activité")
  @APIResponse(responseCode = "200",
               content = {@Content(schema = @Schema(
                   implementation = IdentifiableResponseDto.class))})
  Response start(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'arrêt.
   */
  String STOP_IDENTIFIER = "ARRET_ACTIVITE";

  /**
   * Chemin du service d'arrêt.
   */
  String STOP_PATH = "arret";

  /**
   * Cette méthode permet d'arrêter {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(STOP_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = STOP_IDENTIFIER,
             description = "Ce service permet d'arrêter une activité")
  @APIResponse(responseCode = "200",
               content = {@Content(schema = @Schema(
                   implementation = IdentifiableResponseDto.class))})
  Response stop(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de suspension.
   */
  String SUSPEND_IDENTIFIER = "SUSPENSION_ACTIVITE";

  /**
   * Chemin du service de suspension.
   */
  String SUSPEND_PATH = "suspension";

  /**
   * Cette méthode permet de suspendre {@link ActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(SUSPEND_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = SUSPEND_IDENTIFIER,
             description = "Ce service permet de suspendre une activité")
  @APIResponse(responseCode = "200",
               content = {@Content(schema = @Schema(
                   implementation = IdentifiableResponseDto.class))})
  Response suspend(ByIdentifierRequestDto request);
}
