package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.ComponentManager;
import ci.gouv.dgbf.extension.primefaces.EntityManager;
import ci.gouv.dgbf.extension.primefaces.GetByIdentifierController;
import ci.gouv.dgbf.extension.primefaces.MessageManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.primefaces.component.Button;
import ci.gouv.dgbf.extension.primefaces.component.Confirm;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.DataTable.RecordComponentController;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import ci.gouv.dgbf.extension.primefaces.component.MenuButton;
import ci.gouv.dgbf.extension.primefaces.component.MenuItem;
import ci.gouv.dgbf.extension.primefaces.segregation.Componentable;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Optional;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de traitement d'identifiable.
 *
 * @author Christian
 *
 */
@Dependent
public class IdentifiableProcessingController extends AbstractController {

  @Getter
  @Setter
  Class<?> identifiableClass;

  @Inject
  @Getter
  UpdateController controller;

  @Getter
  @Setter
  Viewer viewer;

  /* Dialog */

  @Getter
  @Setter
  Dialog dialog;

  @Getter
  @Setter
  Button showDialogButton;

  @Getter
  @Setter
  DataTable.RecordComponentController showDialogButtonController;

  @Getter
  @Setter
  Consumer<String> showDialogConsumer;

  @Getter
  @Setter
  String formFileName;

  @Getter
  @Setter
  Button submitButton;

  @Getter
  @Setter
  DataTable.RecordComponentController submitButtonController;

  @Getter
  @Setter
  ListController listController;

  @Getter
  @Setter
  MenuButton.Builder menuButtonBuilder;

  @Inject
  EntityManager entityManager;

  @Inject
  ComponentManager componentManager;

  @Inject
  MessageManager messageManager;

  @Inject
  ScriptManager scriptManager;

  @Deprecated(forRemoval = true)
  Collection<Componentable> updatablesComponents;

  @Getter
  @Setter
  Function<Object, Object> getRecordValueFunction;

  @Inject
  @Getter
  GetByIdentifierController getByIdentifierController;

  @Getter
  @Setter
  boolean reloadPageOnSuccess;

  public IdentifiableProcessingController() {
    viewer = Viewer.DIALOG;
  }

  void validateViewer() {
    Core.throwIllegalArgumentExceptionIfNull(viewer, "Le visualisateur est requis");
  }

  /**
   * Cette méthode permet d'obtenir {@link Dialog} non nul.
   *
   * @return {@link Dialog} non nul
   */
  public Dialog dialog() {
    validateViewer();
    dialog = Core.getOrInstantiateIfNull(dialog, Dialog::new);
    return dialog;
  }

  /**
   * Cette méthode permet d'obtenir le contrôleur de bouton d'affichage du dialogue non nul.
   *
   * @return le contrôleur de bouton d'affichage du dialogue non nul
   */
  public DataTable.RecordComponentController showDialogButtonController() {
    validateViewer();
    showDialogButtonController = Core.getOrInstantiateIfNull(showDialogButtonController,
        DataTable.RecordComponentController::new);
    return showDialogButtonController;
  }

  /**
   * Cette méthode permet d'obtenir le bouton d'affichage du dialogue non nul.
   *
   * @return le bouton d'affichage du dialogue non nul
   */
  public Button showDialogButton() {
    validateViewer();
    showDialogButton = Core.getOrInstantiateIfNull(showDialogButton, Button::new);
    return showDialogButton;
  }

  /**
   * Cette méthode permet d'obtenir le bouton d'envoi non nul.
   *
   * @return le bouton de d'envoi non nul
   */
  public Button submitButton() {
    validateViewer();
    submitButton = Core.getOrInstantiateIfNull(submitButton, Button::new);
    return submitButton;
  }

  /**
   * Cette méthode permet d'obtenir le contrôleur de bouton d'envoi non nul.
   *
   * @return le contrôleur de bouton d'envoi non nul
   */
  public DataTable.RecordComponentController submitButtonController() {
    validateViewer();
    submitButtonController = Core.getOrInstantiateIfNull(submitButtonController,
        DataTable.RecordComponentController::new);
    return submitButtonController;
  }

  /**
   * Cette méthode permet d'assigner la fonction d'affichage du bouton d'affichage du dialogue.
   *
   * @param renderedFunction fonction d'affichage du bouton d'affichage du dialogue
   * @return {@link IdentifiableProcessingController}
   */
  public IdentifiableProcessingController setShowDialogButtonControllerRenderedFunction(
      Function<Object, Boolean> renderedFunction) {
    showDialogButtonController().setRenderedFunction(renderedFunction);
    return this;
  }

  /**
   * Cette méthode permet d'assigner la fonction d'affichage du bouton d'affichage du dialogue.
   *
   * @param renderedFunction fonction d'affichage du bouton d'affichage du dialogue
   * @return {@link IdentifiableProcessingController}
   */
  public IdentifiableProcessingController setShowDialogButtonControllerRenderedFunctionIfNull(
      Function<Object, Boolean> renderedFunction) {
    if (showDialogButtonController == null
        || showDialogButtonController.getRenderedFunction() == null) {
      showDialogButtonController().setRenderedFunctionIfNull(renderedFunction);
    }
    return this;
  }

  /**
   * Cette méthode permet d'assigner la fonction d'affichage du bouton d'envoi.
   *
   * @param renderedFunction fonction d'affichage du bouton d'envoi
   * @return {@link IdentifiableProcessingController}
   */
  public IdentifiableProcessingController setSubmitButtonControllerRenderedFunction(
      Function<Object, Boolean> renderedFunction) {
    submitButtonController().setRenderedFunction(renderedFunction);
    return this;
  }

  /**
   * Cette méthode permet d'assigner la fonction d'affichage du bouton d'envoi.
   *
   * @param renderedFunction fonction d'affichage du bouton d'envoi
   * @return {@link IdentifiableProcessingController}
   */
  public IdentifiableProcessingController setSubmitButtonControllerRenderedFunctionIfNull(
      Function<Object, Boolean> renderedFunction) {
    if (submitButtonController == null || submitButtonController.getRenderedFunction() == null) {
      submitButtonController().setRenderedFunctionIfNull(renderedFunction);
    }
    return this;
  }

  /**
   * Cette méthode permet d'obtenir {@link Dialog} non nul.
   *
   * @return {@link Dialog} non nul
   */
  @Deprecated(forRemoval = true)
  public Collection<Componentable> updatablesComponents() {
    updatablesComponents = Core.getOrInstantiateIfNull(updatablesComponents, ArrayList::new);
    return updatablesComponents;
  }

  /**
   * Cette méthode permet d'ajouter un consommateur d'affichage de dialogue.
   *
   * @param consumer consommateur
   * @return this
   */
  public IdentifiableProcessingController addShowDialogConsumer(Consumer<String> consumer) {
    showDialogConsumer = Core.combineConsumersTo(showDialogConsumer, consumer);
    return this;
  }

  /**
   * Cette méthode permet d'assigner le nom du bouton d'affichage du dialogue.
   *
   * @param name nom
   * @return this
   */
  public IdentifiableProcessingController setShowDialogButtonValue(String name) {
    showDialogButton().setValue(name);
    controller.setName("Mise à jour " + name);
    return this;
  }

  void initializeDialog() {
    Core.throwIllegalArgumentExceptionIfStringBlank(formFileName,
        "Le nom du fichier du formulaire est requis");
    Core.runIfNotNull(listController,
        () -> controller.updatablesComponents().add(listController.getDataTable()));
    dialog().setIdentifier(formFileName + "Dialog");
    dialog().setWidgetVar(dialog().getIdentifier() + "WidgetVar");
    dialog().setHeader(Core.getByCondition(listController == null, showDialogButton().getValue(),
        showDialogButton().getTitle()));
  }

  void initializeNone() {
    Core.runIfNotNull(listController,
        () -> controller.updatablesComponents().add(listController.getDataTable()));
    // Core.runIfNotNull(listController, () -> listController.configureAction(controller));
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   */
  public void initialize() {
    validateViewer();
    initialize(viewer);
  }

  void initialize(Viewer viewer) {
    if (Viewer.DIALOG.equals(viewer)) {
      initializeDialog();
    } else if (Viewer.NONE.equals(viewer)) {
      initializeNone();
    } else {
      throw new IllegalStateException(String
          .format("L'initialisation du visualisateur %s n'a pas été encore implémentée", viewer));
    }
    prepareController();
  }

  /**
   * Cette méthode permet d'exécuter par identifiant.
   *
   * @return navigation
   */
  public String executeByIdentifier(String identifier) {
    Core.throwIllegalArgumentExceptionIfStringBlank(identifier,
        "L'identifiant de l'entité à traiter est requis");
    return execute(identifier);
  }

  /**
   * Cette méthode permet d'afficher {@link #dialog}.
   *
   * @param identifier identifiant
   */
  public void showDialog(String identifier) {
    controller.setEntity(new ActionExecutor<Object>(this, "Obtention par identifiant",
        () -> getByIdentifierController.get(identifier, controller.projection)).execute());
    controller.consumeEntity();
    componentManager.update(dialog);
    scriptManager.show(dialog);
    Core.runIfNotNull(showDialogConsumer, () -> showDialogConsumer.accept(identifier));
  }

  /**
   * Cette méthode permet d'ajouter une action au menu déroulant d'enregistrement, en se basant
   * sur {@link #viewer} : affichage de {@link #dialog} si {@link Viewer#DIALOG}, exécution directe
   * avec confirmation si {@link Viewer#NONE}.
   *
   * @param recordMenuButton menu déroulant d'enregistrement
   * @return this
   */
  public IdentifiableProcessingController addToRecordMenuButton(MenuButton recordMenuButton) {
    validateViewer();
    String action = isViewerDialog() ? showDialogButton().getTitle() : submitButton().getTitle();
    String icon = isViewerDialog() ? showDialogButton().getIcon() : submitButton().getIcon();
    Function<Object, Boolean> renderedFunction = isViewerDialog()
        ? this::getShowDialogButtonRenderedByRecord
        : this::getSubmitButtonRenderedByRecord;
    recordMenuButton.buttonBuilder()
        .menuItemBuilder((MenuItem.Builder) MenuItem.newBuilder()
            .value(action)
            .icon(icon)
            .actionFunction(identifier -> {
              if (isViewerDialog()) {
                showDialog((String) identifier);
                return null;
              }
              return executeByIdentifier((String) identifier);
            })
            .confirmBuilder(isViewerDialog() ? null : Confirm.builder().action(action)))
        .renderedFunction(renderedFunction)
        .build();
    return this;
  }

  /**
   * Cette méthode permet d'exécuter.
   *
   * @return navigation
   */
  public String execute(Object object) {
    Core.throwIllegalArgumentExceptionIfNull(object, "L'entité à traiter est requise");
    Core.throwIllegalArgumentExceptionIfNull(controller.getFunction(),
        "La fonction de traitement est requise");
    controller.setEntity(object);
    controller.execute();
    return null;
  }

  /**
   * Cette méthode permet de préparer une confirmation.
   */
  public IdentifiableProcessingController prepareConfirmation(String action, String icon) {
    viewer = Viewer.NONE;
    submitButton().initializeConfirm(action);
    submitButton().setValue(null); // value is set to null , it has to be recomputed
    return prepareSubmitButton(action, icon);
  }

  /**
   * Cette méthode permet de préparer un traitement par boite de confirmation.
   *
   * @param identifiableClass classe de l'identifiable
   * @param action action
   * @param icon icône
   * @param function fonction
   * @return this
   */
  public IdentifiableProcessingController prepareConfirmation(Class<?> identifiableClass,
      String action, String icon, UnaryOperator<Object> function) {
    this.identifiableClass = identifiableClass;
    prepareConfirmation(action, icon);
    controller.function = function;
    return this;
  }

  /**
   * Cette méthode permet de préparer {@link #submitButton}.
   */
  public IdentifiableProcessingController prepareSubmitButton(String action, String icon) {
    return prepareButton(submitButton(), action, icon);
  }

  /**
   * Cette méthode permet de préparer {@link #showDialogButton}.
   */
  public IdentifiableProcessingController prepareShowDialogButton(String action, String icon) {
    return prepareButton(showDialogButton(), action, icon);
  }

  IdentifiableProcessingController prepareButton(Button button, String action, String icon) {
    if (listController == null) {
      button.setValue(action);
    }
    button.setTitle(action);
    button.setIcon(icon);
    return this;
  }

  void prepareController() {
    computeControllerName();
    controller.getNotificationPublishController().setEnabled(false);
    controller.addResponseConsumer(response -> {
      if (reloadPageOnSuccess) {
        scriptManager.reloadPage();
      } else {
        scriptManager.hide(dialog);
        messageManager.addGrowlMessageFromResponse(response);
        componentManager.update(updatablesComponents);
        componentManager.updateByExpressions(messageManager.getGrowlContainerIdentifier());
      }
    });
  }

  /**
   * Cette méthode permet d'assigner vrai à {@link #reloadPageOnSuccess} si {@link #listController}
   * est null sinon faux.
   *
   * @return vrai à {@link #reloadPageOnSuccess} si {@link #listController} est null sinon faux
   */
  public IdentifiableProcessingController setReloadOnSuccessIfListControllerNull() {
    reloadPageOnSuccess = listController == null;
    return this;
  }

  void computeControllerName() {
    if (identifiableClass == null) {
      return;
    }
    if (Viewer.DIALOG.equals(viewer)) {
      controller.setName(String.format("%s %s", showDialogButton().getTitle(),
          Core.getHumanReadableClassName(identifiableClass)));
    } else {
      controller.setName(String.format("%s %s", submitButton().getTitle(),
          Core.getHumanReadableClassName(identifiableClass)));
    }
  }

  /**
   * Cette méthode permet de préparer un traitement par boite de dialogue.
   *
   * @param identifiableClass classe de l'identifiable
   * @param action action
   * @param icon icône
   * @param function fonction
   * @param formFileName nom du fichier du formulaire
   * @param client client
   * @return this
   */
  public IdentifiableProcessingController prepareDialog(Class<?> identifiableClass, String action,
      String icon, UnaryOperator<Object> function, String formFileName, Object client) {
    this.identifiableClass = identifiableClass;
    prepareShowDialogButton(action, icon);
    this.formFileName = formFileName;
    getByIdentifierController.setClient(client);
    Core.runIfNull(controller.projection, () -> controller.projection =
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER));
    controller.function = function;
    prepareDialog();
    return this;
  }

  /**
   * Cette méthode permet de préparer {@link Dialog}.
   *
   */
  public void prepareDialog() {
    computeDialogContentPath();
    Core.runIfStringBlank(dialog().getHeader(), () -> dialog().setHeader(controller.getName()));
  }

  void computeDialogContentPath() {
    dialog()
        .setContentFilePath(entityManager.formatEntityFormPath(identifiableClass, formFileName));
  }

  /**
   * Cette méthode permet d'obtenir la valeur de l'enregistrement.
   *
   * @param identifiable identifiable
   * @return valeur
   */
  public Object getRecordValue(Object identifiable) {
    if (getRecordValueFunction != null) {
      return getRecordValueFunction.apply(identifiable);
    }
    if (identifiable instanceof IdentifiableByString identifiableByString) {
      return identifiableByString.getIdentifier();
    }
    return identifiable;
  }

  public boolean getSubmitButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, submitButton, submitButtonController)
        && Optional.ofNullable(controller.getIsEnabledFunction()).orElse(o -> true).apply(object);
  }

  public boolean getShowDialogButtonRenderedByRecord(Object object) {
    return RecordComponentController.rendered(object, showDialogButton, showDialogButtonController)
        && Optional.ofNullable(controller.getIsEnabledFunction()).orElse(o -> true).apply(object);
  }

  public boolean isViewerDialog() {
    return Viewer.DIALOG.equals(viewer);
  }

  public boolean isViewerNone() {
    return Viewer.NONE.equals(viewer);
  }

  public boolean isViewerPage() {
    return Viewer.PAGE.equals(viewer);
  }

  /**
   * Cette énumération représente les visualisateurs.
   *
   * @author Christian
   *
   */
  public enum Viewer {
    /**
     * Dialogue.
     */
    DIALOG,

    /**
     * Aucun.
     */
    NONE,

    /**
     * Page.
     */
    PAGE
  }
}
