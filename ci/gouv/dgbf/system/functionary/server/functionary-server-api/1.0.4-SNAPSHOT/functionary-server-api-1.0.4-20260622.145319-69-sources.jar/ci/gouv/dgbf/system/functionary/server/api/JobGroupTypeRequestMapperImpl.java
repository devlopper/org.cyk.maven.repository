package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link JobGroupTypeDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:53:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class JobGroupTypeRequestMapperImpl implements JobGroupTypeRequestMapper {

    @Override
    public JobGroupTypeService.JobGroupTypeCreateRequestDto mapCreate(JobGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobGroupTypeService.JobGroupTypeCreateRequestDto jobGroupTypeCreateRequestDto = new JobGroupTypeService.JobGroupTypeCreateRequestDto();

        jobGroupTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobGroupTypeCreateRequestDto.setCode( arg0.getCode() );
        jobGroupTypeCreateRequestDto.setName( arg0.getName() );

        return jobGroupTypeCreateRequestDto;
    }

    @Override
    public JobGroupTypeService.JobGroupTypeUpdateRequestDto mapUpdate(JobGroupTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobGroupTypeService.JobGroupTypeUpdateRequestDto jobGroupTypeUpdateRequestDto = new JobGroupTypeService.JobGroupTypeUpdateRequestDto();

        jobGroupTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobGroupTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        jobGroupTypeUpdateRequestDto.setCode( arg0.getCode() );
        jobGroupTypeUpdateRequestDto.setName( arg0.getName() );

        return jobGroupTypeUpdateRequestDto;
    }
}
