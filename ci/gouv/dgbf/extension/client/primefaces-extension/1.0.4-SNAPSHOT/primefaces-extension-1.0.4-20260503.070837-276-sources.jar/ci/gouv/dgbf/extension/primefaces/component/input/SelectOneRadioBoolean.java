package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur booléenne par des boutons radio.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SelectOneRadioBoolean extends AbstractSelectOneBoolean {

}
