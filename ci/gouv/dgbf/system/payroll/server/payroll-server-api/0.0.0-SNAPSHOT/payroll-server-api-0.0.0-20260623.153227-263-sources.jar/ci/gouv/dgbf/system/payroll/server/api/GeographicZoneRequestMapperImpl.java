package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link LocalityDto}.
*
* @author arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T15:33:03+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class GeographicZoneRequestMapperImpl implements GeographicZoneRequestMapper {

    @Override
    public GeographicZoneService.GeographicZoneCreateRequestDto mapCreate(GeographicZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GeographicZoneService.GeographicZoneCreateRequestDto geographicZoneCreateRequestDto = new GeographicZoneService.GeographicZoneCreateRequestDto();

        geographicZoneCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        geographicZoneCreateRequestDto.setCode( arg0.getCode() );
        geographicZoneCreateRequestDto.setName( arg0.getName() );

        return geographicZoneCreateRequestDto;
    }

    @Override
    public GeographicZoneService.GeographicZoneUpdateRequestDto mapUpdate(GeographicZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GeographicZoneService.GeographicZoneUpdateRequestDto geographicZoneUpdateRequestDto = new GeographicZoneService.GeographicZoneUpdateRequestDto();

        geographicZoneUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        geographicZoneUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        geographicZoneUpdateRequestDto.setCode( arg0.getCode() );
        geographicZoneUpdateRequestDto.setName( arg0.getName() );

        return geographicZoneUpdateRequestDto;
    }
}
