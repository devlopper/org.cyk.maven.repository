package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptRelationDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptRelationRequestMapperImpl implements ScriptRelationRequestMapper {

    @Override
    public ScriptRelationService.ScriptRelationCreateRequestDto mapCreate(ScriptRelationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptRelationService.ScriptRelationCreateRequestDto scriptRelationCreateRequestDto = new ScriptRelationService.ScriptRelationCreateRequestDto();

        scriptRelationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptRelationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptRelationCreateRequestDto.setParentIdentifier( arg0.getParentIdentifier() );
        scriptRelationCreateRequestDto.setChildIdentifier( arg0.getChildIdentifier() );

        return scriptRelationCreateRequestDto;
    }

    @Override
    public ScriptRelationService.ScriptRelationUpdateRequestDto mapUpdate(ScriptRelationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptRelationService.ScriptRelationUpdateRequestDto scriptRelationUpdateRequestDto = new ScriptRelationService.ScriptRelationUpdateRequestDto();

        scriptRelationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptRelationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptRelationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptRelationUpdateRequestDto.setParentIdentifier( arg0.getParentIdentifier() );
        scriptRelationUpdateRequestDto.setChildIdentifier( arg0.getChildIdentifier() );

        return scriptRelationUpdateRequestDto;
    }
}
