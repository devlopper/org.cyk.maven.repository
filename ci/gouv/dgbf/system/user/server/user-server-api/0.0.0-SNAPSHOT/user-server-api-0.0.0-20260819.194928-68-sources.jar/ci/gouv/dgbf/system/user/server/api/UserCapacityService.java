package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link UserCapacityDto}.
 *
 * @author BoobaCool
 */
@Path(value = UserCapacityService.PATH)
@Tag(name = "Gestion des Qualités d'Utilisateur")
public interface UserCapacityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "qualites-utilisateur";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface UserCapacitySaveRequestDto {

  }

  /**
   * Identifiant du service de création unitaire de {@link UserCapacityDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_QUALITE_UTILISATEUR";

  /**
   * Chemin du service de création unitaire de {@link UserCapacityDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(UserCapacityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link UserCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserCapacityCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements UserCapacitySaveRequestDto {

  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link UserCapacityDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_QUALITE_UTILISATEUR";

  /**
   * Chemin du service d'obtention de plusieurs {@link UserCapacityDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = UserCapacityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link UserCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class UserCapacityGetManyResponseDto
      extends AbstractGetByPageResponseDto<UserCapacityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<UserCapacityDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link UserCapacityDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_QUALITE_UTILISATEUR";

  /**
   * Chemin du service d'obtention unitaire de {@link UserCapacityDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserCapacityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link UserCapacityDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_QUALITE_UTILISATEUR";

  /**
   * Chemin du service d'obtention par identifiant de {@link UserCapacityDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserCapacityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link UserCapacityDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_QUALITE_UTILISATEUR";

  /**
   * Chemin du service de mise à jour unitaire de {@link UserCapacityDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(UserCapacityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link UserCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserCapacityUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements UserCapacitySaveRequestDto {

  }

  /**
   * Identifiant du service de suppression unitaire de {@link UserCapacityDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_QUALITE_UTILISATEUR";

  /**
   * Chemin du service de suppression unitaire de {@link UserCapacityDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link UserCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
