package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.LogLevel;
import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de {@link LogLevel}.
 *
 * @author Christian
 */
public interface HasLevel extends HasField {

  /**
   * Cette méthode permet d'obtenir {@link LogLevel}.
   *
   * @return {@link LogLevel}
   */
  LogLevel getLevel();
  
  /**
   * Cette méthode permet d'assigner {@link LogLevel}.
   *
   * @param logLevel {@link LogLevel}
   */
  void setLevel(LogLevel logLevel);
  
  /**
   * Identifiant java de {@link LogLevel}.
   */
  String FIELD_LEVEL = "level";
}
