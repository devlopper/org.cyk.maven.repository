package ci.gouv.dgbf.system.user.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link UserGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-21T08:50:50+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class UserGroupRequestMapperImpl implements UserGroupRequestMapper {

    @Override
    public UserGroupService.UserGroupCreateRequestDto mapCreate(UserGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserGroupService.UserGroupCreateRequestDto userGroupCreateRequestDto = new UserGroupService.UserGroupCreateRequestDto();

        userGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        userGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        userGroupCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        userGroupCreateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        userGroupCreateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return userGroupCreateRequestDto;
    }

    @Override
    public UserGroupService.UserGroupUpdateRequestDto mapUpdate(UserGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        UserGroupService.UserGroupUpdateRequestDto userGroupUpdateRequestDto = new UserGroupService.UserGroupUpdateRequestDto();

        userGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        userGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        userGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        userGroupUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        userGroupUpdateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        userGroupUpdateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return userGroupUpdateRequestDto;
    }
}
