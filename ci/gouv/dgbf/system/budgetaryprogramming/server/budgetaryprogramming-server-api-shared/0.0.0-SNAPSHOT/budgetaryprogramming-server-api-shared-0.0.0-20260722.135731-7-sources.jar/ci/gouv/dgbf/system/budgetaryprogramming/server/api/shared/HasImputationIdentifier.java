package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'imputation.
 *
 * @author Christian
 */
public interface HasImputationIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'imputation.
   *
   * @return identifiant de l'imputation
   */
  String getImputationIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de l'imputation.
   *
   * @param identifier identifiant de l'imputation
   */
  void setImputationIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de l'imputation.
   */
  String FIELD_IMPUTATION_IDENTIFIER = "imputationIdentifier";
}