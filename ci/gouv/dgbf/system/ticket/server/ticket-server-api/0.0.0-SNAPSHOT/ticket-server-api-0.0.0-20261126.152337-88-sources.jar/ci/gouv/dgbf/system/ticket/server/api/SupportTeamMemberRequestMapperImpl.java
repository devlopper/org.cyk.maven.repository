package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupportTeamMemberDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-26T15:22:04+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.20.1 (Eclipse Adoptium)"
)
@ApplicationScoped
public class SupportTeamMemberRequestMapperImpl implements SupportTeamMemberRequestMapper {

    @Override
    public SupportTeamMemberService.SupportTeamMemberCreateRequestDto mapCreate(SupportTeamMemberDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamMemberService.SupportTeamMemberCreateRequestDto supportTeamMemberCreateRequestDto = new SupportTeamMemberService.SupportTeamMemberCreateRequestDto();

        supportTeamMemberCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamMemberCreateRequestDto.setSupportTeamIdentifier( arg0.getSupportTeamIdentifier() );
        supportTeamMemberCreateRequestDto.setUserIdentifier( arg0.getUserIdentifier() );
        supportTeamMemberCreateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return supportTeamMemberCreateRequestDto;
    }

    @Override
    public SupportTeamMemberService.SupportTeamMemberUpdateRequestDto mapUpdate(SupportTeamMemberDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamMemberService.SupportTeamMemberUpdateRequestDto supportTeamMemberUpdateRequestDto = new SupportTeamMemberService.SupportTeamMemberUpdateRequestDto();

        supportTeamMemberUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamMemberUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportTeamMemberUpdateRequestDto.setCapacityIdentifier( arg0.getCapacityIdentifier() );

        return supportTeamMemberUpdateRequestDto;
    }
}
