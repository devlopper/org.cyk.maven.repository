package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link AdministrativeUnitDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-09T22:27:13+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class AdministrativeUnitRequestMapperImpl implements AdministrativeUnitRequestMapper {

    @Override
    public AdministrativeUnitService.AdministrativeUnitCreateRequestDto mapCreate(AdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitService.AdministrativeUnitCreateRequestDto administrativeUnitCreateRequestDto = new AdministrativeUnitService.AdministrativeUnitCreateRequestDto();

        administrativeUnitCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitCreateRequestDto.setCode( arg0.getCode() );
        administrativeUnitCreateRequestDto.setName( arg0.getName() );
        administrativeUnitCreateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );
        administrativeUnitCreateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );
        administrativeUnitCreateRequestDto.setServiceGroupIdentifier( arg0.getServiceGroupIdentifier() );
        administrativeUnitCreateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );

        return administrativeUnitCreateRequestDto;
    }

    @Override
    public AdministrativeUnitService.AdministrativeUnitUpdateRequestDto mapUpdate(AdministrativeUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitService.AdministrativeUnitUpdateRequestDto administrativeUnitUpdateRequestDto = new AdministrativeUnitService.AdministrativeUnitUpdateRequestDto();

        administrativeUnitUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        administrativeUnitUpdateRequestDto.setCode( arg0.getCode() );
        administrativeUnitUpdateRequestDto.setName( arg0.getName() );
        administrativeUnitUpdateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );
        administrativeUnitUpdateRequestDto.setLocalityIdentifier( arg0.getLocalityIdentifier() );
        administrativeUnitUpdateRequestDto.setServiceGroupIdentifier( arg0.getServiceGroupIdentifier() );
        administrativeUnitUpdateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );

        return administrativeUnitUpdateRequestDto;
    }
}
