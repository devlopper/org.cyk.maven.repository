package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de fichier.
 *
 * @author Christian
 *
 */
@Dependent
public class FileController extends AbstractController {

  @Inject
  FileClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileRequestMapper requestMapper;

  @Inject
  @Getter
  OwnerSelectOneController ownerSelectOneController;

  @Inject
  @Getter
  FileFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Fichiers";

    listController.setEntityClass(FileDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, FileDto.JSON_OWNER_IDENTIFIER,
        FileDto.JSON_OWNER_AS_STRING, FileDto.JSON_NAME, FileDto.JSON_CONTENT_TYPE,
        FileDto.JSON_NUMBER_OF_BYTES_AS_STRING);
    listController.getReadController().setProjection(projection);
    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(4);
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      FileCreateRequestDto request = new FileCreateRequestDto();
      request.setOwnerIdentifier(((FileDto) entity).getOwnerIdentifier());
      request.setName(((FileDto) entity).getName());
      request.setBytes(((FileDto) entity).getBytes());
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(3);
    listController.getShowUpdateDialogButton().setRendered(false);

    ownerSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> listController
            .getCreateControllerOrUpdateControllerEntityAs(FileDto.class)
            .setOwnerIdentifier(identifier));
  }

  /**
   * Cette méthode permet de réagir au téléchargement d'un fichier.
   *
   * @param event évènement
   */
  public void handleFileUpload(FileUploadEvent event) {
    ((FileDto) listController.getCreateController().getEntity())
        .setName(event.getFile().getFileName());
    ((FileDto) listController.getCreateController().getEntity())
        .setBytes(event.getFile().getContent());
  }
}
