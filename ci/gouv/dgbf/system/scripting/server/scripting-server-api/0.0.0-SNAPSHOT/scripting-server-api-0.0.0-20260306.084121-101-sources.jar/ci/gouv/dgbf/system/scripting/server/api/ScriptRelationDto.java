package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une relation de script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptRelationDto extends AbstractIdentifiableAuditableDto {

  @JsonbProperty(JSON_PARENT_IDENTIFIER)
  private String parentIdentifier;

  @JsonbProperty(JSON_PARENT_AS_STRING)
  private String parentAsString;

  @JsonbProperty(JSON_CHILD_IDENTIFIER)
  private String childIdentifier;

  @JsonbProperty(JSON_CHILD_AS_STRING)
  private String childAsString;
  
  /**
   * Identifiant json de identifiant de {@link ScriptRelationDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRelationScript";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ScriptRelationDto}.
   */
  public static final String JSON_THIS_AS_STRING = "relationScriptChaine";

  /**
   * Identifiant json {@link #parentIdentifier}.
   */
  public static final String JSON_PARENT_IDENTIFIER = "idParent";

  /**
   * Identifiant json {@link #parentAsString}.
   */
  public static final String JSON_PARENT_AS_STRING = "parentChaine";
  
  /**
   * Identifiant json {@link #childIdentifier}.
   */
  public static final String JSON_CHILD_IDENTIFIER = "idEnfant";

  /**
   * Identifiant json {@link #childAsString}.
   */
  public static final String JSON_CHILD_AS_STRING = "enfantChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "relation de script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "relations de script";
}
