package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // Role utilisateur
  /**
   * Assigner.
   */
  ASSIGN_USER_ROLE("ASSIGNER_ROLE_UTILISATEUR"),

  /**
   * Revoquer.
   */
  REVOKE_USER_ROLE("REVOQUER_ROLE_UTILISATEUR"),

  // UserRole
  /**
   * Assigner rôle administrateur applicatif.
   */
  ASSIGN_APPLICATION_ADMINISTRATOR_USER_ROLE("ASSIGNER_ADMINISTRATEUR_APPLICATIF"),

  /**
   * Assigner rôle administrateur système.
   */
  ASSIGN_SYSTEM_ADMINISTRATOR_USER_ROLE("ASSIGNER_ADMINISTRATEUR_SYSTEME"),

  // Application

  /**
   * Gérer.
   */
  MANAGE_APPLICATION("GERER_APPLICATION");

  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;

}
