package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputDateController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.TypeIdentifierFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableInstanceClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableInstanceDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableInstanceFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableInstanceService.ClaimableInstanceGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueClient;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueFilter;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimedValueService.ClaimedValueUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de choix des Éléments de Paie/Constantes de Paie
 * concernés par une réclamation, en Mode de Saisie FAE, avec leur nouvelle valeur (RG_REP_CIB_01
 * à 03, RG_REP_SOU_01). Le FAE ne raisonne pas en Réclamables de Type de Réclamation techniques :
 * chaque ligne porte le libellé métier du Réclamable (résolu via {@code TA_RECLAMABLE},
 * RG_REP_CIB_07) et le simple fait d'y renseigner une valeur vaut choix -- pas de case à cocher
 * séparée. La Date d'effet est unique pour tout le formulaire (RG_REP_CIB_02/03, les Constantes
 * n'en ont pas). Les Éléments et Constantes concernés partagent une seule {@link ClaimedValueDto}.
 *
 * @author akm
 *
 */
@Dependent
public class ConcernedClaimableController extends AbstractController {

  @Inject
  ClaimTypeClaimableClient claimTypeClaimableClient;

  @Inject
  ClaimableInstanceClient claimableInstanceClient;

  @Inject
  ClaimedValueClient claimedValueClient;

  @Getter
  List<ConcernedClaimable> concernedClaimables;

  /**
   * Date d'effet commune à toutes les Valeurs Réclamées d'Élément de Paie du formulaire (le FAE
   * ne raisonne pas en Réclamables de Type de Réclamation distincts, il saisit une seule fois la
   * date -- les Constantes de Paie n'ont pas de date d'effet, RG_REP_CIB_02/03).
   */
  @Getter
  @Setter
  LocalDate sharedEffectiveDate;

  /**
   * Widget de saisie de {@link #sharedEffectiveDate}.
   */
  @Getter
  InputDateController sharedEffectiveDateInputController;

  /**
   * Cette méthode permet de constuire.
   */
  public ConcernedClaimableController() {
    concernedClaimables = new ArrayList<>();
    initializeSharedEffectiveDateInputController();
  }

  /**
   * Cette méthode permet de rafraichir la liste des Réclamables de Type de Réclamation en Mode de
   * Saisie FAE pour le Type de Réclamation choisi (RG_REP_CIB_01/04/05) -- ceux en Mode Agent ne
   * sont ni affichés ni demandés à ce stade. Triés par ordre d'affichage explicite
   * (RG_REP_CIB_01), configuré par l'administrateur, plutôt que l'ordre de retour du service, non
   * garanti.
   *
   * @param typeIdentifier identifiant du Type de Réclamation
   */
  public void refresh(String typeIdentifier) {
    concernedClaimables.clear();
    sharedEffectiveDate = null;
    // Réinitialiser la seule valeur, sans reconstruire le widget : celui-ci doit rester la
    // même instance tout au long de la vue pour que le message de validation associé
    // (identifiant aléatoire, cf. AbstractWidget) reste celui enregistré une fois pour toutes
    // dans InputsGroupController par le contrôleur appelant.
    sharedEffectiveDateInputController.getInputLocalDate().writeValue(null);
    if (typeIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_NATURE, ClaimTypeClaimableDto.JSON_CLAIMABLE_IDENTIFIER,
        ClaimTypeClaimableDto.JSON_CLAIMABLE_AS_STRING, ClaimTypeClaimableDto.JSON_VALUE_INPUT_MODE,
        ClaimTypeClaimableDto.JSON_RANK);
    FilterDto filter = new FilterDto().addCriteria(TypeIdentifierFilter.JSON_KEY, typeIdentifier);
    ClaimTypeClaimableGetManyResponseDto response =
        claimTypeClaimableClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().stream()
        .filter(target -> ValueInputModeSelectOneController.VALUE_FAE
            .equals(target.getValueInputMode()))
        .forEach(target -> {
          ConcernedClaimable concernedClaimable = new ConcernedClaimable(target.getIdentifier(),
              target.getNature(), target.getClaimableIdentifier());
          concernedClaimable.setObjectLabel(target.getClaimableAsString() == null
              ? target.getClaimableIdentifier() : target.getClaimableAsString());
          concernedClaimable.setRank(target.getRank());
          if (ELEMENT_PAIE.equals(target.getNature())) {
            concernedClaimable
                .setInstanceOptions(instanceOptionsOf(target.getClaimableIdentifier()));
          }
          concernedClaimables.add(concernedClaimable);
        });
    concernedClaimables.sort(Comparator.comparing(ConcernedClaimable::getRank,
        Comparator.nullsLast(Integer::compareTo)));
  }

  /**
   * Cette méthode permet de (re)construire le widget de saisie de {@link #sharedEffectiveDate}
   * (RG_REP_CIB_02/03).
   */
  private void initializeSharedEffectiveDateInputController() {
    sharedEffectiveDateInputController = new InputDateController();
    sharedEffectiveDateInputController.setOutputLableValue("Date d'effet");
    sharedEffectiveDateInputController.getInputLocalDate().setRequired(true);
    sharedEffectiveDateInputController.getInputLocalDate()
        .addValueConsumer(value -> sharedEffectiveDate = value);
    sharedEffectiveDateInputController.getInputLocalDate().setIdentifier("sharedEffectiveDate");
    sharedEffectiveDateInputController.getInputLocalDate().setWidgetVar("wvSharedEffectiveDate");
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Élément de Paie (RG_REP_CIB_01).
   *
   * @return les Cibles de nature Élément de Paie
   */
  public List<ConcernedClaimable> getElementTargets() {
    return concernedClaimables.stream().filter(target -> ELEMENT_PAIE.equals(target.getNature()))
        .toList();
  }

  /**
   * Cette méthode permet d'obtenir les seules Cibles Constante de Paie -- voir
   * {@link #getElementTargets()}.
   *
   * @return les Cibles de nature Constante de Paie
   */
  public List<ConcernedClaimable> getConstantTargets() {
    return concernedClaimables.stream()
        .filter(target -> CONSTANTE_PAIE.equals(target.getNature())).toList();
  }

  /**
   * Cette méthode permet de savoir si la liste contient au moins une Cible Élément de Paie --
   * détermine si le champ Date d'effet (partagé, sans objet pour les Constantes seules) doit être
   * affiché.
   *
   * @return {@code true} si au moins une Cible est un Élément de Paie
   */
  public boolean hasElementTargets() {
    return concernedClaimables.stream()
        .anyMatch(target -> ELEMENT_PAIE.equals(target.getNature()));
  }

  /**
   * Nature Élément de Paie.
   */
  public static final String ELEMENT_PAIE = "ELEMENT_PAIE";

  /**
   * Nature Constante de Paie.
   */
  public static final String CONSTANTE_PAIE = "CONSTANTE_PAIE";

  /**
   * Type de {@link ConcernedClaimable#getValue()} pour la Valeur Réclamée d'une Constante de
   * Paie -- les montants saisis dans ce formulaire sont toujours décimaux ({@code ValueType},
   * {@code core-extension}).
   */
  private static final String VALUE_TYPE_FLOAT = "FLOAT";

  /**
   * Cette méthode permet d'obtenir les instances possibles d'un Élément de Paie, à partir de
   * l'identifiant de son {@code TA_RECLAMABLE} -- résolues via {@code TA_INSTANCE_RECLAMABLE}
   * (synchronisées depuis {@code payroll} au même titre que les Éléments/Constantes eux-mêmes,
   * RG_REP_CIB_07), sans appel synchrone au module {@code payroll}.
   *
   * @param elementClaimableIdentifier identifiant {@code TA_RECLAMABLE} de l'Élément de Paie
   * @return les instances possibles, en options de sélection
   */
  private List<SelectItem> instanceOptionsOf(String elementClaimableIdentifier) {
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableNamableDto.JSON_NAME);
    FilterDto filter = new FilterDto();
    ClaimableInstanceFilter.setClaimableIdentifier(filter, elementClaimableIdentifier);
    ClaimableInstanceGetManyResponseDto response;
    try {
      response = claimableInstanceClient.getMany(projection, filter, null, userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention des instances de l'Élément de Paie " + elementClaimableIdentifier
              + " en échec.",
          exception);
      return List.of();
    }
    if (response == null || response.getDatas() == null) {
      return List.of();
    }
    return response.getDatas().stream()
        .map(instance -> new SelectItem(instance.getIdentifier(), instance.getName())).toList();
  }

  /**
   * Cette méthode permet d'obtenir une instance d'Élément de Paie à partir de son identifiant
   * {@code TA_INSTANCE_RECLAMABLE} -- résolue sans appel synchrone au module {@code payroll}
   * (RG_REP_CIB_07).
   *
   * @param instanceIdentifier identifiant {@code TA_INSTANCE_RECLAMABLE} de l'instance
   * @return l'instance, ou {@code null} si aucune correspondance ou en cas d'échec
   */
  private ClaimableInstanceDto resolveClaimableInstance(String instanceIdentifier) {
    if (instanceIdentifier == null || instanceIdentifier.isBlank()) {
      return null;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableNamableDto.JSON_NAME);
    try {
      return claimableInstanceClient.getByIdentifier(instanceIdentifier, projection,
          userIdentifier, null);
    } catch (RuntimeException exception) {
      Logger.getLogger(getClass().getName()).log(Level.SEVERE,
          "Obtention de l'instance " + instanceIdentifier + " en échec.", exception);
      return null;
    }
  }

  /**
   * Cette méthode permet de compléter la liste des Cibles concernées (déjà rafraîchie via
   * {@link #refresh(String)}) avec les Valeurs Réclamées déjà enregistrées pour une réclamation
   * existante -- utilisé à l'ouverture d'une réclamation existante en modification.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void loadExistingValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    ProjectionDto projection = new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        ClaimedValueDto.JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER, ClaimedValueDto.JSON_NATURE,
        ClaimedValueDto.JSON_ELEMENT_INSTANCE_IDENTIFIER, ClaimedValueDto.JSON_EFFECTIVE_DATE,
        ClaimedValueDto.JSON_VALUE);
    FilterDto filter =
        new FilterDto().addCriteria(ClaimedValueFilter.JSON_CLAIM_IDENTIFIER, claimIdentifier);
    ClaimedValueGetManyResponseDto response =
        claimedValueClient.getMany(projection, filter, null, userIdentifier, null);
    if (response == null || response.getDatas() == null) {
      return;
    }
    response.getDatas().forEach(value -> concernedClaimables.stream()
        .filter(target -> target.getClaimTypeClaimableIdentifier()
            .equals(value.getClaimTypeClaimableIdentifier()))
        .findFirst().ifPresent(target -> {
          target.setValueIdentifier(value.getIdentifier());
          if (ELEMENT_PAIE.equals(value.getNature())) {
            target.setElementInstanceIdentifier(value.getElementInstanceIdentifier());
            ClaimableInstanceDto instance =
                resolveClaimableInstance(value.getElementInstanceIdentifier());
            target.setInstanceLabel(instance == null ? value.getElementInstanceIdentifier()
                : instance.getName());
            if (sharedEffectiveDate == null) {
              sharedEffectiveDate = value.getEffectiveDate();
              sharedEffectiveDateInputController.getInputLocalDate()
                  .writeValue(value.getEffectiveDate());
            }
          } else if (CONSTANTE_PAIE.equals(value.getNature())) {
            target
                .setValue(value.getValue() == null ? null : new BigDecimal(value.getValue()));
          }
        }));
  }

  /**
   * Cette méthode permet de synchroniser les Valeurs Réclamées des Cibles concernées avec l'état
   * courant de la liste (valeur renseignée/vidée par l'utilisateur) : création de celles
   * nouvellement renseignées, mise à jour de celles dont la valeur a changé, et suppression de
   * celles vidées (RG_REP_CIB_02/03) -- utilisée aussi bien à la Création (aucune Cible n'a
   * encore de {@code valueIdentifier}, le comportement se réduit alors à une simple création) qu'à
   * la Modification d'une réclamation existante.
   *
   * @param claimIdentifier identifiant de la réclamation
   */
  public void syncValues(String claimIdentifier) {
    if (claimIdentifier == null) {
      return;
    }
    concernedClaimables.forEach(target -> {
      if (ELEMENT_PAIE.equals(target.getNature())) {
        syncElementValue(claimIdentifier, target);
      } else if (CONSTANTE_PAIE.equals(target.getNature())) {
        syncConstantValue(claimIdentifier, target);
      }
    });
  }

  private void syncElementValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      request.setElementInstanceIdentifier(target.getElementInstanceIdentifier());
      request.setEffectiveDate(sharedEffectiveDate);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(ELEMENT_PAIE);
      request.setElementInstanceIdentifier(target.getElementInstanceIdentifier());
      request.setEffectiveDate(sharedEffectiveDate);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  private void syncConstantValue(String claimIdentifier, ConcernedClaimable target) {
    if (target.getValueIdentifier() == null) {
      if (!target.isConcerned()) {
        return;
      }
      ClaimedValueCreateRequestDto request = new ClaimedValueCreateRequestDto();
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      request.setValue(target.getValue().toString());
      request.setValueType(VALUE_TYPE_FLOAT);
      request.setAuditWho(userIdentifier);
      CreateResponseDto response = claimedValueClient.create(request);
      target.setValueIdentifier(response.getIdentifier());
    } else if (!target.isConcerned()) {
      claimedValueClient.deleteByIdentifier(target.getValueIdentifier(), userIdentifier, null);
      target.setValueIdentifier(null);
    } else {
      ClaimedValueUpdateRequestDto request = new ClaimedValueUpdateRequestDto();
      request.setIdentifier(target.getValueIdentifier());
      request.setClaimIdentifier(claimIdentifier);
      request.setClaimTypeClaimableIdentifier(target.getClaimTypeClaimableIdentifier());
      request.setNature(CONSTANTE_PAIE);
      request.setValue(target.getValue().toString());
      request.setValueType(VALUE_TYPE_FLOAT);
      request.setAuditWho(userIdentifier);
      claimedValueClient.update(request);
    }
  }

  /**
   * Cette classe représente un Réclamable de Type de Réclamation en Mode FAE, avec son éventuelle
   * Valeur Réclamée. Pas de case à cocher séparée : {@link #isConcerned()} se déduit directement
   * de la valeur renseignée (RG_REP_CIB_01) -- une instance choisie pour un Élément de Paie, une
   * valeur saisie pour une Constante de Paie.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ConcernedClaimable {

    String claimTypeClaimableIdentifier;
    String nature;
    String objectIdentifier;

    /**
     * Libellé métier du Réclamable ciblé (résolu via {@code TA_RECLAMABLE}), affiché au FAE à la
     * place de tout identifiant technique.
     */
    String objectLabel;

    /**
     * Ordre d'affichage (RG_REP_CIB_01), configuré par l'administrateur -- sert à trier les
     * Cibles sur l'écran de saisie de la réclamation.
     */
    Integer rank;

    /**
     * Identifiant de la Valeur Réclamée déjà persistée (renseigné par
     * {@link #loadExistingValues(String)}), ou {@code null} si aucune n'existe encore.
     */
    String valueIdentifier;

    /* Élément de Paie */

    List<SelectItem> instanceOptions = List.of();
    String elementInstanceIdentifier;

    /**
     * Libellé métier de l'instance choisie (résolu via {@code TA_RECLAMABLE}), affiché en
     * consultation à la place de l'identifiant technique de {@link #elementInstanceIdentifier}.
     */
    String instanceLabel;

    /* Constante de Paie */

    BigDecimal value;

    /**
     * Cette méthode permet de constuire.
     *
     * @param claimTypeClaimableIdentifier identifiant du Réclamable de Type de Réclamation
     * @param nature nature de l'objet ciblé
     * @param objectIdentifier identifiant de l'objet ciblé
     */
    public ConcernedClaimable(String claimTypeClaimableIdentifier, String nature,
        String objectIdentifier) {
      this.claimTypeClaimableIdentifier = claimTypeClaimableIdentifier;
      this.nature = nature;
      this.objectIdentifier = objectIdentifier;
    }

    /**
     * Cette méthode permet de savoir si cette Cible est concernée par la réclamation -- vaut le
     * simple fait d'avoir renseigné une valeur, sans case à cocher séparée (RG_REP_CIB_01).
     *
     * @return {@code true} si une valeur est renseignée
     */
    public boolean isConcerned() {
      return ConcernedClaimableController.ELEMENT_PAIE.equals(nature)
          ? elementInstanceIdentifier != null : value != null;
    }
  }
}
