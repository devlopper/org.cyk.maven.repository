package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FunctionaryFilter extends AbstractIdentifiableFilter
    implements FilterHasRegistrationNumber {

  private String registrationNumber;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FunctionaryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FunctionaryFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateRegistrationNumber(filter);

  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterRegistrationNumber(filter);
  }
}

