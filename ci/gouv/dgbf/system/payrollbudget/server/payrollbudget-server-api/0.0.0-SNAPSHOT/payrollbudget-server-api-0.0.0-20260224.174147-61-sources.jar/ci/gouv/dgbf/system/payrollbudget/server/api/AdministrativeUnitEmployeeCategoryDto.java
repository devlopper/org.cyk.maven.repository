package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie de fonctionnaire d'unité administrative.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AdministrativeUnitEmployeeCategoryDto extends AbstractIdentifiableDto
    implements PayrollComponentProjectionContainerDto, EmployeeContainerDto {

  /**
   * Identifiant de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_IDENTIFIER)
  String budgetIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_AS_STRING)
  String budgetAsString;

  /**
   * Identifiant de {@link ExerciseDto} de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_EXERCISE_IDENTIFIER)
  String budgetExerciseIdentifier;

  /**
   * Représentation en chaine de caractères de {@link ExerciseDto} de {@link BudgetDto}.
   */
  @JsonbProperty(JSON_BUDGET_EXERCISE_AS_STRING)
  String budgetExerciseAsString;

  /**
   * Identifiant de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER)
  String budgetAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link BudgetAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING)
  String budgetAdministrativeUnitAsString;

  /**
   * Identifiant de la catégorie de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_CATEGORY_IDENTIFIER)
  String employeeCategoryIdentifier;

  /**
   * Représentation en chaine de caractères de la catégorie d'employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_CATEGORY_AS_STRING)
  String employeeCategoryAsString;

  /**
   * Nombre d'employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT)
  Integer employeeCount;
  
  /**
   * Représentation en chaine de caractères du nombre de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT_AS_STRING)
  String employeeCountAsString;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @Transient
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;
  
  /**
   * Montant.
   */
  @JsonbProperty(JSON_AMOUNT)
  Integer amount;
  
  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Représentation en chaine de caractères de la variance du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVarianceAsString;
  
  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   */
  @JsonbProperty(JSON_INCOMING_EMPLOYEE_COUNT_AS_STRING)
  String incomingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   */
  @JsonbProperty(JSON_OUTGOING_EMPLOYEE_COUNT_AS_STRING)
  String outgoingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé ayant
   * {@link MovementDto} ayant {@link MovementTypeDto} avec
   * {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CHANGE_EMPLOYEE_COUNT_AS_STRING)
  String administrativeUnitChangeEmployeeCountAsString;

  /**
   * Identifiant json de identifiant de {@link AdministrativeUnitEmployeeCategoryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCategorieEmployeUniteAdministrative";

  /**
   * Identifiant json de représentation en chaine de caractères de
   * {@link AdministrativeUnitEmployeeCategoryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "categorieEmployeUniteAdministrativeChaine";

  /**
   * Identifiant json {@link #budgetExerciseIdentifier}.
   */
  public static final String JSON_BUDGET_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetExerciseAsString}.
   */
  public static final String JSON_BUDGET_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER = BudgetDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAsString}.
   */
  public static final String JSON_BUDGET_AS_STRING = BudgetDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitIdentifier}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_IDENTIFIER =
      BudgetAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #budgetAdministrativeUnitAsString}.
   */
  public static final String JSON_BUDGET_ADMINISTRATIVE_UNIT_AS_STRING =
      BudgetAdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #employeeCategoryIdentifier}.
   */
  public static final String JSON_EMPLOYEE_CATEGORY_IDENTIFIER = "idCategorieEmploye";

  /**
   * Identifiant json {@link #employeeCategoryAsString}.
   */
  public static final String JSON_EMPLOYEE_CATEGORY_AS_STRING = "categorieEmployeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie d'employé d'unité administrative";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories d'employés d'unité administrative";
}
