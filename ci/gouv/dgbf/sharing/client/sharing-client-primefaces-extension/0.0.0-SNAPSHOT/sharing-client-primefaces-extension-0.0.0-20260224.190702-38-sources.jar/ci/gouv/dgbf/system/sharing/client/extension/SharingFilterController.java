package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link SharingDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class SharingFilterController extends AbstractFilterController<SharingFilter> {

  @Inject
  @Getter
  ResourceSelectOneController resourceSelectOneController;

  @Inject
  @Getter
  ReceiverSelectOneController receiverSelectOneController;

  /**
   * Cette méthode permet de construire.
   */
  public SharingFilterController() {
    super(SharingFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setResourceIdentifier(getRequestParameter(SharingFilter.JSON_RESOURCE_IDENTIFIER));
    filter.setReceiverIdentifier(getRequestParameter(SharingFilter.JSON_RECEIVER_IDENTIFIER));

    resourceSelectOneController.getSelectOneMenu().writeValue(filter.getResourceIdentifier());
    resourceSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setResourceIdentifier(identifier));

    receiverSelectOneController.getSelectOneMenu().writeValue(filter.getReceiverIdentifier());
    receiverSelectOneController.getSelectOneMenu()
        .addValueConsumer(identifier -> filter.setReceiverIdentifier(identifier));
  }
}

