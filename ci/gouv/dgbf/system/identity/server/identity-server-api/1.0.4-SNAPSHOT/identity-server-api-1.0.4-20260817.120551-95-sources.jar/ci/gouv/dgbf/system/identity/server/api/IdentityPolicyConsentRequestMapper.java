package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentSendConsentRequestMailRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentityPolicyConsentDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentityPolicyConsentDto}.

    @author Desysoft
               """)
public interface IdentityPolicyConsentRequestMapper extends RequestMapper<IdentityPolicyConsentDto,
    IdentityPolicyConsentSendConsentRequestMailRequestDto,
    IdentityPolicyConsentSendConsentRequestMailRequestDto> {

}
