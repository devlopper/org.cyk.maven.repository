package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ValueConditionDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ValueConditionRequestMapperImpl implements ValueConditionRequestMapper {

    @Override
    public ValueConditionService.ValueConditionCreateRequestDto mapCreate(ValueConditionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueConditionService.ValueConditionCreateRequestDto valueConditionCreateRequestDto = new ValueConditionService.ValueConditionCreateRequestDto();

        valueConditionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueConditionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueConditionCreateRequestDto.setValueSelectorIdentifier( arg0.getValueSelectorIdentifier() );
        valueConditionCreateRequestDto.setValueMapKey( arg0.getValueMapKey() );
        valueConditionCreateRequestDto.setConditionalValueIdentifier( arg0.getConditionalValueIdentifier() );
        valueConditionCreateRequestDto.setComparisonOperator( arg0.getComparisonOperator() );
        valueConditionCreateRequestDto.setValuesSeparator( arg0.getValuesSeparator() );
        valueConditionCreateRequestDto.setValue( arg0.getValue() );

        return valueConditionCreateRequestDto;
    }

    @Override
    public ValueConditionService.ValueConditionUpdateRequestDto mapUpdate(ValueConditionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ValueConditionService.ValueConditionUpdateRequestDto valueConditionUpdateRequestDto = new ValueConditionService.ValueConditionUpdateRequestDto();

        valueConditionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        valueConditionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        valueConditionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        valueConditionUpdateRequestDto.setValueSelectorIdentifier( arg0.getValueSelectorIdentifier() );
        valueConditionUpdateRequestDto.setValueMapKey( arg0.getValueMapKey() );
        valueConditionUpdateRequestDto.setConditionalValueIdentifier( arg0.getConditionalValueIdentifier() );
        valueConditionUpdateRequestDto.setComparisonOperator( arg0.getComparisonOperator() );
        valueConditionUpdateRequestDto.setValuesSeparator( arg0.getValuesSeparator() );
        valueConditionUpdateRequestDto.setValue( arg0.getValue() );

        return valueConditionUpdateRequestDto;
    }

    @Override
    public ValueConditionService.ValueConditionVerifyRequestDto mapVerify(ValueConditionDto valueCondition) {
        if ( valueCondition == null ) {
            return null;
        }

        ValueConditionService.ValueConditionVerifyRequestDto valueConditionVerifyRequestDto = new ValueConditionService.ValueConditionVerifyRequestDto();

        valueConditionVerifyRequestDto.setAuditWho( valueCondition.getAuditWho() );
        valueConditionVerifyRequestDto.setAuditSession( valueCondition.getAuditSession() );
        valueConditionVerifyRequestDto.setIdentifier( valueCondition.getIdentifier() );
        valueConditionVerifyRequestDto.setValueSelectorFilterAttributeValue( valueCondition.getValueSelectorFilterAttributeValue() );
        Map<String, Object> map = valueCondition.getValuesMap();
        if ( map != null ) {
            valueConditionVerifyRequestDto.setValuesMap( new LinkedHashMap<String, Object>( map ) );
        }

        return valueConditionVerifyRequestDto;
    }
}
