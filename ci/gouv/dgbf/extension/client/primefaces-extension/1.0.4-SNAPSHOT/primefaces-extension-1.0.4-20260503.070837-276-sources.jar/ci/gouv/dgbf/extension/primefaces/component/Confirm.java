package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente une confirmation.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Confirm {

  String header;
  String message;
  String icon;
  Boolean disabled;

  /**
   * Cette méthode permet d'instanctier.
   */
  public Confirm() {
    header = "Confirmation";
    icon = "pi pi-exclamation-triangle";
    disabled = false;
  }

  public void setMessageAreYouSureTo(String action) {
    message =
        "Êtes vous sur de vouloir %s?".formatted(Core.getOrDefaultIfBlank(action, "procéder"));
  }

  public static Builder builder() {
    return new Builder();
  }

  /**
   * Cette classe représente un constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {
    String header;
    String message;
    String icon;
    Boolean disabled;

    String action;

    /**
     * Cette méthode permet de construire.
     */
    public Builder() {
      header = "Confirmation";
      icon = "pi pi-exclamation-triangle";
      disabled = false;
    }

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link Confirm}
     */
    public Confirm build() {
      Confirm confirm = new Confirm();
      confirm.header = header;
      confirm.message = message;
      confirm.icon = icon;
      confirm.disabled = disabled;
      confirm.setMessageAreYouSureTo(action);
      return confirm;
    }
  }
}
