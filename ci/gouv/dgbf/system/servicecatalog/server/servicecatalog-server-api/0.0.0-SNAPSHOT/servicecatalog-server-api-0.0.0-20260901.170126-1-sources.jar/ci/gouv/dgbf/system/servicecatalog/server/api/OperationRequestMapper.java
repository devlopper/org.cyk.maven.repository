package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.servicecatalog.server.api.OperationService.OperationCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.OperationService.OperationUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link OperationDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link OperationDto}.

    @author Christian
               """)
public interface OperationRequestMapper
    extends RequestMapper<OperationDto, OperationCreateRequestDto,
        OperationUpdateRequestDto> {

}
