package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableService.ClaimableGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableClient extends AbstractClient<ClaimableService>
    implements GetByIdentifier<ClaimableDto>, GetMany<ClaimableGetManyResponseDto> {

  @Override
  public ClaimableClient service(ClaimableService service) {
    return (ClaimableClient) super.service(service);
  }

  /**
   * {@link ClaimableService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableGetManyResponseDto>(ClaimableGetManyResponseDto.class,
        ClaimableService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableDto>(ClaimableDto.class,
        ClaimableService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
