package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService.PayIndexCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.PayIndexService.PayIndexUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayIndexDto}.
 *
 * @author A.K.M
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayIndexDto}.

    @author AKM
               """)
public interface PayIndexRequestMapper
    extends RequestMapper<PayIndexDto, PayIndexCreateRequestDto, PayIndexUpdateRequestDto> {

}
