package ci.gouv.dgbf.extension.primefaces.component.input;

import java.time.LocalDate;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un {@link LocalDate}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputLocalDate extends AbstractInputOneDate<LocalDate> {

  protected String pattern = "dd/MM/yyyy";
  protected boolean showIcon = true;

  /**
   * Cette méthode permet d'obtenir l'aide de saisie du format, déduite du motif.
   *
   * @return aide, par exemple « Format : JJ/MM/AAAA. »
   */
  public String getPatternHelp() {
    return "Format : " + pattern.replace("dd", "JJ").replace("yyyy", "AAAA") + ".";
  }
}
