package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link DictionaryService}.
 *
 * @author Boobacool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class DictionaryClient extends AbstractClient<DictionaryService>
    implements GetByIdentifier<DictionaryDto>,
    GetMany<DictionaryService.DictionaryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public DictionaryClient service(DictionaryService service) {
    return (DictionaryClient) super.service(service);
  }

  /**
   * {@link DictionaryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(DictionaryService.DictionaryCreateRequestDto request) {
    return new CreateExecutor(DictionaryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link DictionaryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public DictionaryService.DictionaryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<DictionaryService.DictionaryGetManyResponseDto>(
        DictionaryService.DictionaryGetManyResponseDto.class,
        DictionaryService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link DictionaryService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DictionaryService.DictionaryGetManyResponseDto getMany(ProjectionDto projection,
                                                                FilterDto filter,
                                                                PageDto page, String auditWho,
                                                                String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link DictionaryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public DictionaryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<DictionaryDto>(DictionaryDto.class,
        DictionaryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link DictionaryService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DictionaryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                              String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link DictionaryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public DictionaryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<DictionaryDto>(DictionaryDto.class,
        DictionaryService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link DictionaryService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DictionaryDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
                                       String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link DictionaryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(DictionaryService.DictionaryUpdateRequestDto request) {
    return new IdentifiableExecutor(DictionaryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link DictionaryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(DictionaryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link DictionaryService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

