package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des pièces justificatives.
 *
 * <p>Deux axes, ceux du contrôle : toutes les pièces d'un dossier, ou celles d'une ligne.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class SupportingDocumentFilter extends AbstractIdentifiableFilter {

  /**
   * Dossier dont on veut les pièces.
   */
  String dossierIdentifier;

  /**
   * Ligne d'arbitrage dont on veut les pièces.
   */
  String movementIdentifier;

  public SupportingDocumentFilter() {
    super();
  }

  public SupportingDocumentFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setDossierIdentifier(read(filter, SupportingDocumentDto.JSON_DOSSIER_IDENTIFIER));
    setMovementIdentifier(read(filter, SupportingDocumentDto.JSON_MOVEMENT_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, SupportingDocumentDto.JSON_DOSSIER_IDENTIFIER, getDossierIdentifier());
    write(filter, SupportingDocumentDto.JSON_MOVEMENT_IDENTIFIER, getMovementIdentifier());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
