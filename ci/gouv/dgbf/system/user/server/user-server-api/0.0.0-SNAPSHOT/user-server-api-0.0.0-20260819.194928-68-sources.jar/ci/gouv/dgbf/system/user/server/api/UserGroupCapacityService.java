package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCapacityIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link UserGroupCapacityDto}.
 *
 * @author BoobaCool
 */
@Path(value = UserGroupCapacityService.PATH)
@Tag(name = "Gestion des Qualités de l'Utilisateur de Groupe")
public interface UserGroupCapacityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "qualites-utilisateur-groupe";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface UserGroupCapacitySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link UserGroupDto}.
     *
     * @return identifiant de {@link UserGroupDto}
     */
    String getUserGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link UserGroupDto}.
     *
     * @param userGroupIdentifier identifiant de {@link UserGroupDto}
     */
    void setUserGroupIdentifier(String userGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link UserCapacityDto}.
     *
     * @return identifiant de {@link UserCapacityDto}
     */
    String getCapacityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link UserCapacityDto}.
     *
     * @param capacityIdentifier identifiant de {@link UserCapacityDto}
     */
    void setCapacityIdentifier(String capacityIdentifier);

    /**
     * Identifiant json identifiant de {@link UserGroupDto}.
     */
    String JSON_USER_GROUP_IDENTIFIER = HasUserGroupIdentifierDto.JSON_USER_GROUP_IDENTIFIER;

    /**
     * Identifiant json identifiant de {@link UserCapacityDto}.
     */
    String JSON_CAPACITY_IDENTIFIER = HasCapacityIdentifierDto.JSON_CAPACITY_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link UserGroupCapacityDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de création unitaire de {@link UserGroupCapacityDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(UserGroupCapacityCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link UserGroupCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserGroupCapacityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements UserGroupCapacitySaveRequestDto {

    @JsonbProperty(JSON_USER_GROUP_IDENTIFIER)
    private String userGroupIdentifier;

    @JsonbProperty(JSON_CAPACITY_IDENTIFIER)
    private String capacityIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link UserGroupCapacityDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention de plusieurs {@link UserGroupCapacityDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = UserGroupCapacityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link UserGroupCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  public static class UserGroupCapacityGetManyResponseDto
      extends AbstractGetByPageResponseDto<UserGroupCapacityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<UserGroupCapacityDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link UserGroupCapacityDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention unitaire de {@link UserGroupCapacityDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserGroupCapacityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link UserGroupCapacityDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service d'obtention par identifiant de {@link UserGroupCapacityDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = UserGroupCapacityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link UserGroupCapacityDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de mise à jour unitaire de {@link UserGroupCapacityDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(UserGroupCapacityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link UserGroupCapacityDto}.
   *
   * @author BoobaCool
   */
  @Getter
  @Setter
  class UserGroupCapacityUpdateRequestDto extends ByIdentifierRequestDto
      implements UserGroupCapacitySaveRequestDto {

    @JsonbProperty(JSON_USER_GROUP_IDENTIFIER)
    private String userGroupIdentifier;

    @JsonbProperty(JSON_CAPACITY_IDENTIFIER)
    private String capacityIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link UserGroupCapacityDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_QUALITE_UTILISATEUR_GROUPE";

  /**
   * Chemin du service de suppression unitaire de {@link UserGroupCapacityDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link UserGroupCapacityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
