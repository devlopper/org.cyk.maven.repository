package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileGroupArchivalJournalEventType}.
 *
 * @author Christian
 *
 */
public class FileGroupArchivalJournalEventTypeCode {

  private FileGroupArchivalJournalEventTypeCode() {

  }

  /**
   * Création d'une demande.
   */
  public static final String SOLICITATION_CREATION = "CREATION_DEMANDE";

  /**
   * Acceptation.
   */
  public static final String ACCEPTANCE = "ACCEPTATION";

  /**
   * Refus.
   */
  public static final String REFUSAL = "REFUS";

  /**
   * Annulation.
   */
  public static final String CANCELLATION = "ANNULATION";

  /**
   * Correction d'une information.
   */
  public static final String INFORMATION_CORRECTION = "CORRECTION_INFORMATION";

  /**
   * Archivage direct.
   */
  public static final String DIRECT_ARCHIVING = "ARCHIVAGE_DIRECT";

  /**
   * Désarchivage direct.
   */
  public static final String DIRECT_UNARCHIVING = "DESARCHIVAGE_DIRECT";

  /**
   * Suppression du rattachement.
   */
  public static final String ATTACHMENT_DELETION = "SUPPRESSION_RATTACHEMENT";
}
