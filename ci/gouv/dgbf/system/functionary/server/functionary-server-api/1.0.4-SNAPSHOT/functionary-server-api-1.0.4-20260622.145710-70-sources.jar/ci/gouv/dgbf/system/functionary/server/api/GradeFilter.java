package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasPayScaleIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link GradeDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class GradeFilter extends AbstractIdentifiableFilter implements FilterHasPayScaleIdentifier {

  private String payScaleIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public GradeFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public GradeFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayScaleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayScaleIdentifier(filter);
  }
}
