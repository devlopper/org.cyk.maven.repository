package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link IdentityPolicyConsentDto}.
 *
 * @author Desysoft
 *
 */
@Getter
public enum IdentityPolicyConsentStatus {

  /**
   * #{@link IdentityPolicyConsentStatusCode#ACCEPTED}. Statut initial possible (naissance directe
   * sur décision, RG_IDT_CST_01) ou bascule depuis {@link #REFUSED} (RG_IDT_CST_04).
   */
  ACCEPTED(IdentityPolicyConsentStatusCode.ACCEPTED, "Accepté", "Acceptation"),

  /**
   * #{@link IdentityPolicyConsentStatusCode#REFUSED}. Statut initial possible (naissance directe
   * sur décision, RG_IDT_CST_01) ou bascule depuis {@link #ACCEPTED} (RG_IDT_CST_04).
   */
  REFUSED(IdentityPolicyConsentStatusCode.REFUSED, "Refusé", "Refus"),

  /**
   * #{@link IdentityPolicyConsentStatusCode#EXPIRED}. Péremption déclenchée par le système lors
   * de la republication d'une politique (RG_IDT_CST_03) — jamais déclenché par l'identité.
   */
  EXPIRED(IdentityPolicyConsentStatusCode.EXPIRED, "Périmé", "Péremption");


  private IdentityPolicyConsentStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<IdentityPolicyConsentStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link IdentityPolicyConsentStatus} par code.
   *
   * @param code code
   * @return {@link IdentityPolicyConsentStatus}
   */
  public static IdentityPolicyConsentStatus getByCode(String code) {
    return Stream.of(IdentityPolicyConsentStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(IllegalArgumentException::new);
  }

  static {
    ACCEPTED.previous = Core.getSet(List.of(REFUSED));
    REFUSED.previous = Core.getSet(List.of(ACCEPTED));
    EXPIRED.previous = Core.getSet(List.of(ACCEPTED, REFUSED));
  }
}
