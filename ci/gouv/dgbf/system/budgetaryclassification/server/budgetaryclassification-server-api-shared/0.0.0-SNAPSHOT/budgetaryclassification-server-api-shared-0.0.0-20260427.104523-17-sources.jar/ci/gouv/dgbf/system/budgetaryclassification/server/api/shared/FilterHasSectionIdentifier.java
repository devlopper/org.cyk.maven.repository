package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de section.
 *
 * @author Arnaud
 */
public interface FilterHasSectionIdentifier extends HasSectionIdentifier {

  /**
   * Cette méthode permet de mettre à jour identifiant section.
   *
   * @param filter {@link FilterDto}
   */
  default void updateSectionIdentifier(FilterDto filter) {
    setSectionIdentifier(SectionIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour identifiant section de
   * {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterSectionIdentifier(FilterDto filter) {
    SectionIdentifierFilter.set(filter, getSectionIdentifier());
  }

}
