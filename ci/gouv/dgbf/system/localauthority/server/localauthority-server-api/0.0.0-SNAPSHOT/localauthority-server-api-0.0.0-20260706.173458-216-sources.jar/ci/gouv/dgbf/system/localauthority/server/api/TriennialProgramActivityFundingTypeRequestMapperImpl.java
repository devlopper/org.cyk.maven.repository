package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête
* et {@link TriennialProgramActivityFundingTypeDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-06T17:35:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TriennialProgramActivityFundingTypeRequestMapperImpl implements TriennialProgramActivityFundingTypeRequestMapper {

    @Override
    public TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeCreateRequestDto mapCreate(TriennialProgramActivityFundingTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeCreateRequestDto triennialProgramActivityFundingTypeCreateRequestDto = new TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeCreateRequestDto();

        triennialProgramActivityFundingTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramActivityFundingTypeCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        triennialProgramActivityFundingTypeCreateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        triennialProgramActivityFundingTypeCreateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        if ( arg0.getAmount1() != null ) {
            triennialProgramActivityFundingTypeCreateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            triennialProgramActivityFundingTypeCreateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            triennialProgramActivityFundingTypeCreateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return triennialProgramActivityFundingTypeCreateRequestDto;
    }

    @Override
    public TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateRequestDto mapUpdate(TriennialProgramActivityFundingTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateRequestDto triennialProgramActivityFundingTypeUpdateRequestDto = new TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateRequestDto();

        triennialProgramActivityFundingTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        triennialProgramActivityFundingTypeUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        triennialProgramActivityFundingTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        triennialProgramActivityFundingTypeUpdateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        triennialProgramActivityFundingTypeUpdateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        if ( arg0.getAmount1() != null ) {
            triennialProgramActivityFundingTypeUpdateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            triennialProgramActivityFundingTypeUpdateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            triennialProgramActivityFundingTypeUpdateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return triennialProgramActivityFundingTypeUpdateRequestDto;
    }
}
