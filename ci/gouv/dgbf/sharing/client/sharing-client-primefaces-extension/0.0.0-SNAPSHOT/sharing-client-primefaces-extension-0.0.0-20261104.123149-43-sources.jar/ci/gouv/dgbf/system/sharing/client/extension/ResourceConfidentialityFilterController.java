package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceConfidentialityFilter;
import jakarta.enterprise.context.Dependent;

/** Controleur de filtre de la confidentialite par ressource. */
@Dependent
public class ResourceConfidentialityFilterController
    extends AbstractFilterController<ResourceConfidentialityFilter> {
  /** Construit le controleur. */
  public ResourceConfidentialityFilterController() {
    super(ResourceConfidentialityFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
  }
}
