package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RoleDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class RoleFilter extends AbstractIdentifiableFilter {

  /**
   * {@link Role}.
   */
  Role enumeration;
  
  /**
   * Est responsable.
   */
  Boolean isResponsible;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public RoleFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public RoleFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isResponsible = getIsResponsible(filter);
    enumeration = getEnumeration(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsResponsible(filter, isResponsible);
    setEnumeration(filter, enumeration);
  }

  /**
   * Cette méthode permet d'assigner la {@link Role}.
   *
   * @param filter filtre
   * @param enumeration {@link Role}
   */
  public static void setEnumeration(FilterDto filter, Role enumeration) {
    set(filter, JSON_ENUMERATION, f -> f.getValueAsString(), f -> f.setValueAsEnum(enumeration));
  }

  /**
   * Cette méthode permet d'obtenir {@link Role}.
   *
   * @param filter filtre
   * @return {@link Role}
   */
  public static Role getEnumeration(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_ENUMERATION, Role.class));
  }
  
  /**
   * Cette méthode permet d'assigner si oui ou non {@link RoleDto} est responsable.
   *
   * @param filter filtre
   * @param value valeur
   */
  public static void setIsResponsible(FilterDto filter, Boolean value) {
    set(filter, JSON_IS_RESPONSIBLE, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(value));
  }

  /**
   * Cette méthode permet d'obtenir si oui ou non {@link RoleDto} est responsable.
   *
   * @param filter filtre
   * @return est responsable
   */
  public static Boolean getIsResponsible(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_RESPONSIBLE));
  }

  /**
   * Identifiant json champ {@link #enumeration}.
   */
  public static final String JSON_ENUMERATION = RoleDto.JSON_ENUMERATION;
  
  /**
   * Identifiant json champ {@link RoleFilter#isResponsible}.
   */
  public static final String JSON_IS_RESPONSIBLE = RoleDto.JSON_IS_RESPONSIBLE;

}
