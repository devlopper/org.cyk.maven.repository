package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SubLocalityZoneDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SubLocalityZoneRequestMapperImpl implements SubLocalityZoneRequestMapper {

    @Override
    public SubLocalityZoneService.SubLocalityZoneCreateRequestDto mapCreate(SubLocalityZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubLocalityZoneService.SubLocalityZoneCreateRequestDto subLocalityZoneCreateRequestDto = new SubLocalityZoneService.SubLocalityZoneCreateRequestDto();

        subLocalityZoneCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        subLocalityZoneCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        subLocalityZoneCreateRequestDto.setSubLocalityIdentifier( arg0.getSubLocalityIdentifier() );
        subLocalityZoneCreateRequestDto.setZoneIdentifier( arg0.getZoneIdentifier() );

        return subLocalityZoneCreateRequestDto;
    }

    @Override
    public SubLocalityZoneService.SubLocalityZoneUpdateRequestDto mapUpdate(SubLocalityZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SubLocalityZoneService.SubLocalityZoneUpdateRequestDto subLocalityZoneUpdateRequestDto = new SubLocalityZoneService.SubLocalityZoneUpdateRequestDto();

        subLocalityZoneUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        subLocalityZoneUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        subLocalityZoneUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        subLocalityZoneUpdateRequestDto.setSubLocalityIdentifier( arg0.getSubLocalityIdentifier() );
        subLocalityZoneUpdateRequestDto.setZoneIdentifier( arg0.getZoneIdentifier() );

        return subLocalityZoneUpdateRequestDto;
    }
}
