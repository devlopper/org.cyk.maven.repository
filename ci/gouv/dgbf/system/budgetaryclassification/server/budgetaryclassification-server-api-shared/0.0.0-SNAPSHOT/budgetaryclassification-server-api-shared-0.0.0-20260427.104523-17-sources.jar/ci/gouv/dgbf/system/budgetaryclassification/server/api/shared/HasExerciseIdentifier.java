package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'exercice.
 *
 * @author Christian
 */
public interface HasExerciseIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'exercice.
   *
   * @return identifiant de l'exercice
   */
  String getExerciseIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de l'exercice.
   *
   * @param identifier identifiant de l'exercice
   */
  void setExerciseIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de l'exercice.
   */
  String FIELD_EXERCISE_IDENTIFIER = "exerciseIdentifier";
}