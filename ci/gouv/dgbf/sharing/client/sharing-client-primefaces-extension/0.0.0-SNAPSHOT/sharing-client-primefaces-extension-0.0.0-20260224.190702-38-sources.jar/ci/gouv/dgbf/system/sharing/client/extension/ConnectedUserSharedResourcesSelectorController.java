package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection des resources paratgées.
 *
 * @author Christian
 *
 */
@SessionScoped
@Named
public class ConnectedUserSharedResourcesSelectorController extends AbstractController {

  /**
   * Sélecteur d'unité administrative.
   */
  @Inject
  @Getter
  ConnectedUserSharedResourceSelectorController administrativeUnitSelectorController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    administrativeUnitSelectorController.prepareAdministrativeUnit();
    administrativeUnitSelectorController.initialize();
  }
}
