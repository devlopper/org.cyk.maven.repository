package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BeneficiaryDto}.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class BeneficiaryFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  String localAuthorityIdentifier;


  /**
   * {@link PersonType}.
   */
  PersonType personType;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BeneficiaryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BeneficiaryFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    localAuthorityIdentifier = getLocalAuthorityIdentifier(filter);
    personType = getCategory(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLocalAuthorityIdentifier(filter, localAuthorityIdentifier);
    setPersonType(filter, personType);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant de {@link LocalAuthorityDto}
   */
  public static void setLocalAuthorityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LOCAL_AUTHORITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LocalAuthorityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LocalAuthorityDto}
   */
  public static String getLocalAuthorityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LOCAL_AUTHORITY_IDENTIFIER));
  }


  /**
   * Cette méthode permet d'assigner la {@link PersonType}.
   *
   * @param filter   filtre
   * @param personType {@link PersonType}
   */
  public static void setPersonType(FilterDto filter, PersonType personType) {
    set(filter, JSON_PERSON_TYPE, f -> f.getValueAsString(), f -> f.setValueAsEnum(personType));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link PersonType}.
   *
   * @param filter filtre
   * @return {@link PersonType}
   */
  public static PersonType getCategory(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_PERSON_TYPE, PersonType.class));
  }

  /**
   * Identifiant json champ {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #personType}.
   */
  public static final String JSON_PERSON_TYPE = BeneficiaryDto.JSON_PERSON_TYPE;
}

