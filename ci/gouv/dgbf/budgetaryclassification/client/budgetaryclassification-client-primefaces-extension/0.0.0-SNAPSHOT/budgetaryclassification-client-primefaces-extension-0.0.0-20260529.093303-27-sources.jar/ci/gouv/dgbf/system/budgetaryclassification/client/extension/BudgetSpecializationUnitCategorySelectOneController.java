package ci.gouv.dgbf.system.budgetaryclassification.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitCategoryClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitCategoryDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitCategoryService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de.
 * {@link BudgetSpecializationUnitCategoryDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class BudgetSpecializationUnitCategorySelectOneController extends
    AbstractSelectOneIdentifiableController<
    BudgetSpecializationUnitCategoryDto, GetManyResponseDto,
    BudgetSpecializationUnitCategoryClient> {

  @Inject
  @Getter
  BudgetSpecializationUnitCategoryClient client;

  protected BudgetSpecializationUnitCategorySelectOneController() {
    super(BudgetSpecializationUnitCategoryDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
