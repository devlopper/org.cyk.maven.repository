package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Set;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_EVALUATOR_IDENTIFIER)
  private String evaluatorIdentifier;

  @JsonbProperty(JSON_EVALUATOR_CODE)
  private String evaluatorCode;
  
  @JsonbProperty(JSON_EVALUATOR_ENGINE_NAME)
  private String evaluatorEngineName;
  
  @JsonbProperty(JSON_EVALUATOR_AS_STRING)
  private String evaluatorAsString;

  @JsonbProperty(JSON_TEXT)
  private String text;

  @JsonbProperty(JSON_TEXT_AS_HTML)
  private String textAsHtml;
  
  @JsonbProperty(JSON_PARAMETERS)
  private Set<String> parameters;
  
  @JsonbProperty(JSON_PARAMETERS_COUNT)
  private Integer parametersCount;

  @JsonbProperty(JSON_PARAMETERS_COUNT_AS_STRING)
  private String parametersCountAsString;
  
  @JsonbProperty(JSON_RESULT_TYPE)
  private ValueType resultType;

  @JsonbProperty(JSON_RESULT_TYPE_AS_STRING)
  private String resultTypeAsString;

  @JsonbProperty(JSON_EVALUATIONS_COUNT)
  private Integer evaluationsCount;

  @JsonbProperty(JSON_EVALUATIONS_COUNT_AS_STRING)
  private String evaluationsCountAsString;
  
  @JsonbProperty(JSON_RELATIONS_COUNT)
  private Integer relationsCount;

  @JsonbProperty(JSON_RELATIONS_COUNT_AS_STRING)
  private String relationsCountAsString;
  
  /**
   * Identifiant json de identifiant de {@link ScriptDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idScript";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ScriptDto}.
   */
  public static final String JSON_THIS_AS_STRING = "scriptChaine";

  /**
   * Identifiant json {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = DomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #domainAsString}.
   */
  public static final String JSON_DOMAIN_AS_STRING = DomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #evaluatorIdentifier}.
   */
  public static final String JSON_EVALUATOR_IDENTIFIER = ScriptEvaluatorDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #evaluatorCode}.
   */
  public static final String JSON_EVALUATOR_CODE = ScriptEvaluatorDto.JSON_THIS_CODE;
  
  /**
   * Identifiant json {@link #evaluatorEngineName}.
   */
  public static final String JSON_EVALUATOR_ENGINE_NAME = "nomMoteurEvaluateurScript";
  
  /**
   * Identifiant json {@link #evaluatorAsString}.
   */
  public static final String JSON_EVALUATOR_AS_STRING = ScriptEvaluatorDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #text}.
   */
  public static final String JSON_TEXT = "texte";

  /**
   * Identifiant json {@link #textAsHtml}.
   */
  public static final String JSON_TEXT_AS_HTML = "texteHtml";
  
  /**
   * Identifiant json {@link #parameters}.
   */
  public static final String JSON_PARAMETERS = "parametres";
  
  /**
   * Identifiant json {@link #parametersCount}.
   */
  public static final String JSON_PARAMETERS_COUNT = "nombreParametres";
  
  /**
   * Identifiant json {@link #parametersCountAsString}.
   */
  public static final String JSON_PARAMETERS_COUNT_AS_STRING = JSON_PARAMETERS_COUNT + "Chaine";
  
  /**
   * Identifiant json {@link #evaluationsCount}.
   */
  public static final String JSON_EVALUATIONS_COUNT = "nombreEvaluations";
  
  /**
   * Identifiant json {@link #evaluationsCountAsString}.
   */
  public static final String JSON_EVALUATIONS_COUNT_AS_STRING = JSON_EVALUATIONS_COUNT + "Chaine";
  
  /**
   * Identifiant json {@link #relationsCount}.
   */
  public static final String JSON_RELATIONS_COUNT = "nombreRelations";
  
  /**
   * Identifiant json {@link #evaluationsCountAsString}.
   */
  public static final String JSON_RELATIONS_COUNT_AS_STRING = JSON_RELATIONS_COUNT + "Chaine";
  
  /**
   * Identifiant json {@link #resultType}.
   */
  public static final String JSON_RESULT_TYPE = "typeResultat";

  /**
   * Identifiant json {@link #resultTypeAsString}.
   */
  public static final String JSON_RESULT_TYPE_AS_STRING = "typeResultatChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
