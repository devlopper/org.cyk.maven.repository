package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un saut d'une cascade ({@link ClaimableCascadeDependencyDto}) : une
 * valeur courante est posée comme critère {@link #filterFieldKey} sur le Client {@link #clientKey},
 * et le champ {@link #outputFieldKey} de chaque résultat devient la valeur courante du saut suivant
 * (ou le résultat final si {@link #rank} est le plus élevé de la cascade).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableCascadeHopDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de la cascade ({@link ClaimableCascadeDependencyDto}) à laquelle ce saut
   * appartient.
   */
  @JsonbProperty(JSON_CASCADE_DEPENDENCY_IDENTIFIER)
  private String cascadeDependencyIdentifier;

  /**
   * Rang d'exécution du saut au sein de sa cascade (ordre croissant, premier saut = 1).
   */
  @JsonbProperty(JSON_RANK)
  private Integer rank;

  /**
   * Clé fermée identifiant le Client à appeler pour ce saut, voir le registre des Clients
   * utilisables.
   */
  @JsonbProperty(JSON_CLIENT_KEY)
  private String clientKey;

  /**
   * Clé json du critère à poser sur le Client, valant la valeur courante du saut.
   */
  @JsonbProperty(JSON_FILTER_FIELD_KEY)
  private String filterFieldKey;

  /**
   * Clé json du champ à extraire de chaque résultat du Client, devenant la valeur courante du
   * saut suivant.
   */
  @JsonbProperty(JSON_OUTPUT_FIELD_KEY)
  private String outputFieldKey;

  /**
   * Identifiant json {@link #cascadeDependencyIdentifier}.
   */
  public static final String JSON_CASCADE_DEPENDENCY_IDENTIFIER = "idCascade";

  /**
   * Identifiant json {@link #rank}.
   */
  public static final String JSON_RANK = "rang";

  /**
   * Identifiant json {@link #clientKey}.
   */
  public static final String JSON_CLIENT_KEY = "cleClient";

  /**
   * Identifiant json {@link #filterFieldKey}.
   */
  public static final String JSON_FILTER_FIELD_KEY = "cleChampCritere";

  /**
   * Identifiant json {@link #outputFieldKey}.
   */
  public static final String JSON_OUTPUT_FIELD_KEY = "cleChampSortie";

  /**
   * Clé du Client {@code SubLocalityClient} ({@code budgetaryclassification}).
   */
  public static final String CLIENT_SUB_LOCALITY = "SOUS_LOCALITE";

  /**
   * Clé du Client {@code PayrollJobClient} ({@code payroll}).
   */
  public static final String CLIENT_PAYROLL_JOB = "EMPLOI";

  /**
   * Clé du Client {@code PayIndexClient} ({@code functionary}).
   */
  public static final String CLIENT_PAY_INDEX = "INDICE";

  /**
   * Clé du Client {@code GradeClassClient} ({@code functionary}).
   */
  public static final String CLIENT_GRADE_CLASS = "CLASSE";

  /**
   * Clé du Client {@code EchelonClient} ({@code functionary}).
   */
  public static final String CLIENT_ECHELON = "ECHELON";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "saut de cascade de réclamable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sauts de cascade de réclamables";
}
