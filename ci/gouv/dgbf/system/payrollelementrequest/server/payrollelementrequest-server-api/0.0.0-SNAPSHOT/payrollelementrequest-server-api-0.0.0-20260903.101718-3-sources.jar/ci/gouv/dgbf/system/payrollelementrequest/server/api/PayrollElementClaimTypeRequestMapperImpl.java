package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementClaimTypeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-03T10:17:52+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementClaimTypeRequestMapperImpl implements PayrollElementClaimTypeRequestMapper {

    @Override
    public PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto mapCreate(PayrollElementClaimTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto payrollElementClaimTypeCreateRequestDto = new PayrollElementClaimTypeService.PayrollElementClaimTypeCreateRequestDto();

        payrollElementClaimTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeCreateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeCreateRequestDto.setName( arg0.getName() );
        payrollElementClaimTypeCreateRequestDto.setClaimTypeGroupIdentifier( arg0.getClaimTypeGroupIdentifier() );
        payrollElementClaimTypeCreateRequestDto.setRoleTraitement( arg0.getRoleTraitement() );
        payrollElementClaimTypeCreateRequestDto.setTreasuryTransmittable( arg0.getTreasuryTransmittable() );
        payrollElementClaimTypeCreateRequestDto.setFunctionaryDepositAuthorized( arg0.getFunctionaryDepositAuthorized() );
        payrollElementClaimTypeCreateRequestDto.setExpectedDocumentTypesGroupIdentifier( arg0.getExpectedDocumentTypesGroupIdentifier() );

        return payrollElementClaimTypeCreateRequestDto;
    }

    @Override
    public PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto mapUpdate(PayrollElementClaimTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto payrollElementClaimTypeUpdateRequestDto = new PayrollElementClaimTypeService.PayrollElementClaimTypeUpdateRequestDto();

        payrollElementClaimTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementClaimTypeUpdateRequestDto.setCode( arg0.getCode() );
        payrollElementClaimTypeUpdateRequestDto.setName( arg0.getName() );
        payrollElementClaimTypeUpdateRequestDto.setClaimTypeGroupIdentifier( arg0.getClaimTypeGroupIdentifier() );
        payrollElementClaimTypeUpdateRequestDto.setRoleTraitement( arg0.getRoleTraitement() );
        payrollElementClaimTypeUpdateRequestDto.setTreasuryTransmittable( arg0.getTreasuryTransmittable() );
        payrollElementClaimTypeUpdateRequestDto.setFunctionaryDepositAuthorized( arg0.getFunctionaryDepositAuthorized() );
        payrollElementClaimTypeUpdateRequestDto.setExpectedDocumentTypesGroupIdentifier( arg0.getExpectedDocumentTypesGroupIdentifier() );

        return payrollElementClaimTypeUpdateRequestDto;
    }
}
