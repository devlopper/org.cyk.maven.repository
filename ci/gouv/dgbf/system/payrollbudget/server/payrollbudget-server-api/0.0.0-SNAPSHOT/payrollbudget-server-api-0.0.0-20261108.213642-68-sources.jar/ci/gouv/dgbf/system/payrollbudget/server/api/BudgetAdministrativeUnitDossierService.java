package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat de consultation des dossiers de masse salariale.
 *
 * <p>Un dossier ne se crée pas depuis l'extérieur : il naît de l'expression des besoins de
 * l'EPN, et son état n'avance que par les opérations du circuit. <strong>Aucune mise à jour
 * générique n'est exposée</strong> : elle laisserait contourner le cycle de vie. Les six
 * écritures sont des transitions nommées — réception, validation du traitement, validation,
 * consolidation — auxquelles s'ajoutent la prise en charge et son abandon, qui désignent qui
 * instruit sans faire avancer l'état.</p>
 *
 * <p>Le chemin, les clés JSON et les identifiants d'opération portent tous le même nom que
 * le concept : <em>dossier de masse salariale</em>. Le chemin suivait auparavant celui de
 * l'unité administrative de budget, dont le dossier est la face transactionnelle — les deux
 * désignent bien le même objet du monde réel, mais l'URL disait alors un nom que ni les clés
 * ni la documentation n'employaient.</p>
 *
 * @author Christian
 *
 */
@Path(value = BudgetAdministrativeUnitDossierService.PATH)
@Tag(name = "Gestion des dossiers de masse salariale")
public interface BudgetAdministrativeUnitDossierService extends SpecificService {

  /*
   * ECART ASSUME A R45c, comme pour la ligne d'arbitrage : les six transitions rendent un
   * IdentifiableResponseDto. Voir la note de ArbitrationMovementService.
   */

  /**
   * Chemin de base des services.
   */
  String PATH = "dossiers-masse-salariale";

  /**
   * Identifiant du service d'obtention de plusieurs {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service d'obtention de plusieurs {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des dossiers.
   *
   * @param request critères, projection et pagination
   * @return les dossiers correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation des dossiers de masse salariale")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitDossierGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de dossiers.
   */
  @Getter
  @Setter
  public static class BudgetAdministrativeUnitDossierGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetAdministrativeUnitDossierDto> {
    @JsonbProperty(JSON_DATAS)
    private List<BudgetAdministrativeUnitDossierDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service d'obtention unitaire de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Recherche d'un dossier unique.
   *
   * @param request critères et projection
   * @return le dossier correspondant
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitDossierDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de
   * {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service d'obtention par identifiant de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'un dossier par son identifiant.
   *
   * @param request identifiant et projection
   * @return le dossier correspondant
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitDossierDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de réception de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String RECEIVE_IDENTIFIER = "RECEPTION_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service de réception de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String RECEIVE_PATH = "reception";

  /**
   * Réceptionne un dossier transmis (CU01).
   *
   * <p>La date et l'heure de prise en charge sont arrêtées par le serveur, jamais fournies par
   * l'appelant : c'est ce qui rend l'accusé de réception opposable. Un dossier sans bordereau ne
   * peut pas être réceptionné (RG01).</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(RECEIVE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = RECEIVE_IDENTIFIER,
      summary = "Réception d'un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response receive(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Identifiant du service de validation du traitement de {@link
   * BudgetAdministrativeUnitDossierDto}.
   */
  String VALIDATE_PROCESSING_IDENTIFIER = "VALIDATION_TRAITEMENT_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service de validation du traitement de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String VALIDATE_PROCESSING_PATH = "validation-traitement";

  /**
   * Valide le traitement d'un dossier : l'étape de traitement est close.
   *
   * <p>Geste du <strong>chef d'équipe</strong>. Il ne décide de rien sur les lignes : il constate
   * que chacune a été traitée, et c'est ce constat qui ouvre leur validation. Tant qu'il n'est pas
   * posé, aucune ligne du dossier ne peut être validée.</p>
   *
   * <p>Il suppose <strong>chaque ligne traitée</strong>. Une ligne encore réceptionnée retient le
   * dossier — sans quoi le chef fermerait une étape que des lignes n'ont pas franchie, et
   * celles-ci resteraient en arrière sans que rien ne le signale. Les lignes rejetées au
   * traitement et les lignes différées ne retiennent rien : la première est sortie du circuit, la
   * seconde attend l'EPN et peut ne jamais revenir.</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(VALIDATE_PROCESSING_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = VALIDATE_PROCESSING_IDENTIFIER,
      summary = "Valider le traitement d'un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response validateProcessing(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Identifiant du service de validation de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String VALIDATE_IDENTIFIER = "VALIDATION_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service de validation de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String VALIDATE_PATH = "validation";

  /**
   * Valide un dossier : il part en consolidation.
   *
   * <p>Geste du <strong>chef d'équipe</strong>, et le second des trois qui lui appartiennent. Il
   * envoie le dossier et ses lignes à la consolidation ; tant qu'il n'est pas posé, aucune ligne
   * ne peut être consolidée.</p>
   *
   * <p>Il suppose <strong>chaque ligne validée</strong>, selon la même règle que la validation du
   * traitement.</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(VALIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = VALIDATE_IDENTIFIER,
      summary = "Valider un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response validate(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Identifiant du service de consolidation de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String CONSOLIDATE_IDENTIFIER = "CONSOLIDATION_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service de consolidation de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String CONSOLIDATE_PATH = "consolidation";

  /**
   * Consolide un dossier : l'arbitrage est clos.
   *
   * <p>Geste du <strong>chef d'équipe</strong>, et le dernier : c'est la consolidation finale,
   * celle qui constitue la masse salariale de l'EPN. Elle ne se prend que sur un dossier
   * <em>Validé</em>, et lorsque <strong>plus aucune de ses lignes n'attend de choix</strong>.
   * Consolider alors qu'une ligne validée reste à trancher reviendrait à arrêter une masse
   * salariale dont on sait qu'elle est incomplète.</p>
   *
   * <p>L'opération <strong>ferme le dossier et tout son contenu</strong> : plus aucune transition
   * n'est acceptée sur ses lignes, pas même la retransmission d'une ligne différée pour
   * correction. Elle est sans retour.</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(CONSOLIDATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CONSOLIDATE_IDENTIFIER,
      summary = "Consolider un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response consolidate(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Identifiant du service de prise en charge de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String TAKE_CHARGE_IDENTIFIER = "PRISE_EN_CHARGE_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service de prise en charge de {@link BudgetAdministrativeUnitDossierDto}.
   */
  String TAKE_CHARGE_PATH = "prise-en-charge";

  /**
   * Attribue un dossier réceptionné à l'agent qui l'appelle (RG3).
   *
   * <p>L'agent retenu est celui de l'audit — jamais un nom fourni dans la requête : on prend
   * un dossier en charge pour soi, on n'en charge pas quelqu'un d'autre à son insu. Un dossier
   * déjà tenu par un tiers est refusé ; le reprendre pour soi ne l'est pas, la reprise étant
   * sans effet.</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(TAKE_CHARGE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TAKE_CHARGE_IDENTIFIER,
      summary = "Prise en charge d'un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response takeCharge(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Identifiant du service d'abandon de la prise en charge de {@link
   * BudgetAdministrativeUnitDossierDto}.
   */
  String RELEASE_IDENTIFIER = "ABANDON_DOSSIER_MASSE_SALARIALE";

  /**
   * Chemin du service d'abandon de la prise en charge de {@link
   * BudgetAdministrativeUnitDossierDto}.
   */
  String RELEASE_PATH = "abandon";

  /**
   * Libère un dossier pris en charge.
   *
   * <p>Les décisions déjà rendues restent : abandonner, c'est rendre le dossier disponible,
   * pas défaire ce qu'on y a fait. Seul celui qui le tient peut le relâcher.</p>
   *
   * @param request identifiant du dossier
   * @return l'identifiant du dossier touché
   */
  @Path(RELEASE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = RELEASE_IDENTIFIER,
      summary = "Abandon d'un dossier de masse salariale")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response release(BudgetAdministrativeUnitDossierTransitionRequestDto request);

  /**
   * Requête d'une transition d'état du dossier : l'identifiant suffit, l'état visé est porté par
   * l'opération elle-même.
   */
  @Getter
  @Setter
  class BudgetAdministrativeUnitDossierTransitionRequestDto extends ByIdentifierRequestDto {
  }
}
