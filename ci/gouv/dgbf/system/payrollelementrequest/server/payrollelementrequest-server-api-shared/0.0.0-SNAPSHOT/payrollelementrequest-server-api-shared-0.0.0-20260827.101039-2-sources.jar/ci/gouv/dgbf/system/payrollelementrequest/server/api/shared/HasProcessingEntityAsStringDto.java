package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de
 * caractères d'entité traitante.
 *
 * @author akm
 *
 */
public interface HasProcessingEntityAsStringDto {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'entité traitante.
   */
  String JSON_PROCESSING_ENTITY_AS_STRING = "entiteTraitanteChaine";

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'entité
   * traitante.
   *
   * @return représentation en chaine de caractères de l'entité traitante
   */
  String getProcessingEntityAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'entité
   * traitante.
   *
   * @param processingEntityAsString représentation en chaine de caractères de l'entité traitante
   */
  void setProcessingEntityAsString(String processingEntityAsString);
}
