package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingUpdateCommentRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.FundingService.FundingUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FundingDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FundingDto}.

    @author Christian
               """)
public interface FundingRequestMapper
    extends RequestMapper<FundingDto, FundingCreateRequestDto, FundingUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper la requête de mise à jour de commentaire.
   *
   * @param funding {@link FundingDto}.
   * @return requête de mise à jour de commentaire
   */
  FundingUpdateCommentRequestDto mapUpdateComment(FundingDto funding);
}
