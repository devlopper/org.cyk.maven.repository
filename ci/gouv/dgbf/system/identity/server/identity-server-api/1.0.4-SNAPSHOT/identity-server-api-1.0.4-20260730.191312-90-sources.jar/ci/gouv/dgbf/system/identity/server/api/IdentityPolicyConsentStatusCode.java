package ci.gouv.dgbf.system.identity.server.api;

/**
 * Cette classe représente les codes de {@link IdentityPolicyConsentStatus}.
 *
 * @author Desysoft
 *
 */
public class IdentityPolicyConsentStatusCode {

  private IdentityPolicyConsentStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Accepté.
   */
  public static final String ACCEPTED = "ACCEPTE";

  /**
   * Refusé.
   */
  public static final String REFUSED = "REFUSE";

  /**
   * Révoqué.
   */
  public static final String REVOKED = "REVOQUE";
}
