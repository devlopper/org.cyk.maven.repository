package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.SessionManager;
import ci.gouv.dgbf.extension.primefaces.component.CommandUpdatePropertyValueBuilder;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionFilter;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceService;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import jakarta.servlet.http.HttpSession;
import java.util.function.UnaryOperator;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceController extends AbstractController {

  @Inject
  ResourceClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ResourceFilterController filterController;

  @Inject
  @Getter
  IdentifiableProcessingController storeInSessionProcessingController;

  @Inject
  SharingSessionController sessionController;

  @Inject
  HttpSession session;

  @Inject
  SessionManager sessionManager;

  @Inject
  SharingManager manager;

  @Inject
  SectionClient sectionClient;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ResourceDto.NAME;
    requestParameterRedirectUrlValue = requestManager.getParameterRedirectUrl();
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(ResourceDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ResourceService.PATH);
    listController.setFilterController(filterController);

    listController.getShowCreateDialogButton().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
    // listController.getDataTable().getActionColumn().setRendered(false);

    ProjectionDto projection = new ProjectionDto();
    projection.addNamesIfNull(filterController.getFilter().getType(),
        AbstractResourceOrReceiverDto.JSON_TYPE_AS_STRING);
    projection.addNamesIfNull(filterController.getFilter().getLocation(),
        AbstractResourceOrReceiverDto.JSON_LOCATION_AS_STRING);
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME);
    listController.getReadController().setProjection(projection);

    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    listController.getDataTable().getActionColumn().computeWithForButtonsWithIconOnly(5);

    storeInSessionProcessingController.prepareConfirmation(ResourceDto.class, "Définir en session",
        "pi pi-check", storeInSessionFunction());

    storeInSessionProcessingController.getController()
        .setEventIdentifier("defaultResourceChangedEvent");
    storeInSessionProcessingController.submitButton().addUpdates(CommandUpdatePropertyValueBuilder
        .formatObserver(storeInSessionProcessingController.getController().getEventIdentifier()));

    storeInSessionProcessingController.initialize();
  }

  UnaryOperator<Object> storeInSessionFunction() {
    return identifier -> {
      ResourceDto resource = sessionController.setAttributeResource((String) identifier);
      if (Core.and(ResourceType.ADMINISTRATIVE_UNIT.equals(resource.getType()),
          manager.getIsSetSectionWhenSetAdministrativeUnit())) {
        SectionFilter filter = new SectionFilter();
        filter.setAdministrativeUnitIdentifier(resource.getReference());
        SectionDto section = sectionClient
            .getOne(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
                AbstractIdentifiableDto.JSON_AS_STRING), filter.toDto(), userIdentifier, null);
        ResourceDto sectionResource = new ResourceDto();
        sectionResource.setAsString(section.getAsString());
        sectionResource.setReference(section.getIdentifier());
        sessionController.setAttributeResource(ResourceType.SECTION,
            Location.BUDGETARY_CLASSIFICATION, sectionResource);
      }
      Core.acceptConsumer(manager.getOnResourceStoredInSession(), resource);
      return buildStoreInSessionFunctionResponse(resource);
    };
  }

  IdentifiableResponseDto buildStoreInSessionFunctionResponse(ResourceDto resource) {
    if (ResourceController.this.redirectIfUrlNotBlank()) {
      sessionManager.removeAttributeRedirectUrl(session);
      return null;
    }
    IdentifiableResponseDto response = new IdentifiableResponseDto();
    response.setIdentifier(resource.getIdentifier());
    response.setMessage("%s a été stocké en session".formatted(ResourceDto.NAME));
    return response;
  }
}
