package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupConfirmResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateCategoriesRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service FileGroupService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileGroupClient extends AbstractClient<FileGroupService>
    implements GetMany<FileGroupGetManyResponseDto>, GetByIdentifier<FileGroupDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FileGroupClient service(FileGroupService service) {
    return (FileGroupClient) super.service(service);
  }

  /**
   * {@link FileGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FileGroupCreateRequestDto request) {
    return new CreateExecutor(FileGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FileGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FileGroupGetManyResponseDto>(FileGroupGetManyResponseDto.class,
        FileGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FileGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FileGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FileGroupDto>(FileGroupDto.class, FileGroupService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link FileGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FileGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FileGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return {@link FilesGroupDto}
   */
  public FileGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FileGroupDto>(FileGroupDto.class,
        FileGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FileGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return {@link FileGroupDto}
   */
  @Override
  public FileGroupDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FileGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FileGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(FileGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }
  
  /**
   * {@link FileGroupService#updateCategories}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateCategories(FileGroupUpdateCategoriesRequestDto request) {
    return new IdentifiableExecutor(FileGroupService.UPDATE_CATEGORIES_IDENTIFIER)
        .execute(() -> service().updateCategories(request));
  }

  /**
   * {@link FileGroupService#confirm}.
   *
   * @param request requête
   * @return réponse
   */
  public FileGroupConfirmResponseDto confirm(FileGroupConfirmRequestDto request) {
    return new GetOneExecutor<>(FileGroupConfirmResponseDto.class,
        FileGroupService.CONFIRM_IDENTIFIER).execute(() -> service().confirm(request));
  }

  /**
   * {@link FileGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FileGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un fichier de groupe.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
