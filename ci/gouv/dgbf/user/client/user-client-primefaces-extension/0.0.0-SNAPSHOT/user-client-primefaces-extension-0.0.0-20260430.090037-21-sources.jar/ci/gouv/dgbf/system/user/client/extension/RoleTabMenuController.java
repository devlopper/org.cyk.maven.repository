package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.TabMenu;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RoleTabMenuController extends AbstractController {

  @Getter
  TabMenu menu;

  @Inject
  IconManager iconManager;

  @Getter
  RoleDto role;

  String isToBeControlledInPriorityParameterName;

  String statusParameterName;

  protected RoleTabMenuController() {
    menu = new TabMenu();
    menu.setMenuItemStyleClassPrefix("roleDto");
    menu.getOutcomesMap().put(UserRoleListPage.class, RoleReadUsersPage.OUTCOME);

  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    menu.tabBuilder().menuItemValue("Utilisateur")
        .menuItemIcon(iconManager.getUser()).type(UserRoleListPage.class)
        .addMenuItemParameter(requestParameterIdentifierName, role.getIdentifier())
        .build();
    menu.initialize();
  }

}
