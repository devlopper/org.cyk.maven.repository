package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.EmployeePayrollComponentService.CreateManyRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.EmployeePayrollComponentService.EmployeePayrollComponentGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link EmployeePayrollComponentService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class EmployeePayrollComponentClient extends AbstractClient<EmployeePayrollComponentService>
    implements GetByIdentifier<EmployeePayrollComponentDto>,
    GetMany<EmployeePayrollComponentGetManyResponseDto> {

  @Override
  public EmployeePayrollComponentClient service(EmployeePayrollComponentService service) {
    return (EmployeePayrollComponentClient) super.service(service);
  }

  /**
   * {@link EmployeePayrollComponentService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public EmployeePayrollComponentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<EmployeePayrollComponentGetManyResponseDto>(
        EmployeePayrollComponentGetManyResponseDto.class,
        EmployeePayrollComponentService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link EmployeePayrollComponentService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmployeePayrollComponentGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link EmployeePayrollComponentService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public EmployeePayrollComponentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<EmployeePayrollComponentDto>(EmployeePayrollComponentDto.class,
        EmployeePayrollComponentService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link EmployeePayrollComponentService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public EmployeePayrollComponentDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link EmployeePayrollComponentService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public EmployeePayrollComponentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<EmployeePayrollComponentDto>(EmployeePayrollComponentDto.class,
        EmployeePayrollComponentService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link EmployeePayrollComponentService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public EmployeePayrollComponentDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
  
  /**
   * {@link EmployeePayrollComponentService#createMany}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createMany(CreateManyRequestDto request) {
    return new CreateExecutor(
            EmployeePayrollComponentService.CREATE_MANY_IDENTIFIER)
        .execute(() -> service().createMany(request));
  }
}
