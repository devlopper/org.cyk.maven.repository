package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N+2 est complétée.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedN2Dto extends HasCompletedN2 {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N+2 est complétée.
   */
  String JSON_COMPLETED_N2 = "completeN2";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName