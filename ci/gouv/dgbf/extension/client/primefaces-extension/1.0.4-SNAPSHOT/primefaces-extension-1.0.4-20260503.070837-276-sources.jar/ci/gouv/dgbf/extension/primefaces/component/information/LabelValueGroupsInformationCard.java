package ci.gouv.dgbf.extension.primefaces.component.information;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.primefaces.LabelValue;
import ci.gouv.dgbf.extension.primefaces.Style;
import ci.gouv.dgbf.extension.primefaces.Text;
import ci.gouv.dgbf.extension.primefaces.Text.RenderComponentType;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Objects;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la carte d'informations des groupes de libellé et valeurs.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LabelValueGroupsInformationCard extends AbstractInformationCard {

  Text headerText;

  Collection<Group> groups;

  Style groupsStyle;

  Text footerText;

  String labelValueStyleClassFormat;

  String labelTemplateFilePath;

  String valueTemplateFilePath;

  /**
   * Constructeur.
   */
  public LabelValueGroupsInformationCard() {
    setTemplateFilePath("/extension/component/information/card/v1/main.xhtml");
    labelValueStyleClassFormat = "label-value-information-%s";
    addStylesClasses(labelValueStyleClassFormat.formatted("card"), "w-100", "h-100");
    headerText =
        Text.Builder.instantiate(null, null, labelValueStyleClassFormat.formatted("header"));

    groupsStyle =
        Style.Builder.instantiate(null, labelValueStyleClassFormat.formatted("content")).build();
  }

  /**
   * Cette méthode permet de savoir si vide.
   *
   * @return vrai si vide sinon faux.
   */
  public boolean isEmpty() {
    return Objects.isNull(groups);
  }

  /**
   * Cette méthode permet d'obtenir un groupe non nul.
   *
   * @return groupe non nul
   */
  public Group group() {
    Group group = new Group();
    groups().add(group);
    return group;
  }

  Collection<Group> groups() {
    if (groups == null) {
      groups = new ArrayList<>();
    }
    return groups;
  }

  /**
   * Cette méthode permet d'obtenir {@link LabelValue} par index de {@link Group} et index de
   * {@link LabelValue}.
   *
   * @param groupIndex index de {@link Group}
   * @param index index de {@link LabelValue}
   * @return {@link LabelValue}
   */
  public LabelValue getLabelValueByGroupIndexByIndex(int groupIndex, int index) {
    Group group = CollectionCore.getElementAt(groups, groupIndex);
    if (group == null) {
      return null;
    }
    return CollectionCore.getElementAt(group.labelValues, index);
  }

  /**
   * Cette classe représente un groupe.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public class Group {
    Style style;

    Text headerText;

    Collection<LabelValue> labelValues;

    Text footerText;

    /**
     * Cette méthode permet d'ajouter.
     *
     * @param labelValue {@link LabelValue}
     * @return {@link Group}
     */
    public Group add(LabelValue labelValue) {
      if (labelValue != null) {
        labelValue.setStyleClass(labelValueStyleClassFormat.formatted("row"));
        labelValue.getLabelText().setStyleClass(labelValueStyleClassFormat.formatted("label"));
        labelValue.setLabelTemplateFilePath(labelTemplateFilePath);
        labelValue.getValueText().setStyleClass(labelValueStyleClassFormat.formatted("value"));
        labelValue.setValueTemplateFilePath(valueTemplateFilePath);
        labelValues().add(labelValue);
      }
      return this;
    }

    /**
     * Cette méthode permet d'ajouter.
     *
     * @param label libellé
     * @param value valeur
     * @return {@link Group}
     */
    public Group add(String label, String value) {
      LabelValue labelValue = LabelValue.newBuilder().label(label).value(value).build();
      add(labelValue);
      return this;
    }

    /**
     * Cette méthode permet d'ajouter si la valeur n'est pas blanc.
     *
     * @param labelValue {@link LabelValue}
     * @return {@link Group}
     */
    public Group addIfValueNotBlank(LabelValue labelValue) {
      if (labelValue != null && !StringCore.isBlank(labelValue.getValueText().getValue())) {
        add(labelValue);
      }
      return this;
    }

    /**
     * Cette méthode permet d'ajouter si la valeur n'est pas blanc.
     *
     * @param label libellé
     * @param value valeur
     * @return {@link Group}
     */
    public Group addIfValueNotBlank(String label, String value) {
      if (!StringCore.isBlank(value)) {
        add(label, value);
      }
      return this;
    }

    /**
     * {@link Style#getClassesAsString(Style)}.
     *
     * @return classes du style
     */
    public String getStyleClass() {
      return Style.getClassesAsString(style);
    }

    public Group styleClass(String styleClass) {
      style().setClasses(styleClass);
      return this;
    }

    Style style() {
      if (style == null) {
        style = new Style();
      }
      return style;
    }

    Collection<LabelValue> labelValues() {
      if (labelValues == null) {
        labelValues = new ArrayList<>();
      }
      return labelValues;
    }
  }

  /**
   * Cette méthode permet de tager une valeur.
   *
   * @param index index
   * @param severity sévérité
   * @param rounded bordure arrondie
   * @param icon icône
   */
  public void tagValue(Integer index, String severity, boolean rounded, String icon) {
    if (index == null) {
      return;
    }
    LabelValue labelValue = getLabelValueByGroupIndexByIndex(0, index);
    if (labelValue == null) {
      return;
    }
    labelValue.getValueText().setRenderComponentType(RenderComponentType.TAG);
    labelValue.getValueText().setSeverity(severity);
    labelValue.getValueText().setRounded(rounded);
    labelValue.getValueText().setIcon(icon);
  }

  /**
   * Cette méthode permet de styliser un tag.
   *
   * @param index index
   * @param styleClass classe de style
   */
  public void tagStyleClass(Integer index, String styleClass) {
    if (index == null) {
      return;
    }
    LabelValue labelValue = getLabelValueByGroupIndexByIndex(0, index);
    if (labelValue == null) {
      return;
    }
    labelValue.getValueText().setStyleClass(styleClass);
  }

  public static final LabelValueGroupsInformationCard NULL = new LabelValueGroupsInformationCard();
}
