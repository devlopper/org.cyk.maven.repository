package ci.gouv.dgbf.system.datastructures.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant d'intervalle de période.
 *
 * @author Christian
 */
public interface HasPeriodIntervalIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'intervalle de période.
   *
   * @return identifiant de l'intervalle de période
   */
  String getPeriodIntervalIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant de l'intervalle de période.
   *
   * @param identifier identifiant de l'intervalle de période
   */
  void setPeriodIntervalIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant de l'intervalle de période.
   */
  String FIELD_PERIOD_INTERVAL_IDENTIFIER = "periodIntervalIdentifier";
}