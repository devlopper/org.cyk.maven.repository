package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToArbitrateNAsStringDto extends HasTotalAmountToArbitrateNAsString {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N_AS_STRING = "montantTotalAArbitrerNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
