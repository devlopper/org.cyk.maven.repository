package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat du rattachement des dossiers aux équipes : qui instruit quoi.
 *
 * <p>C'est ce rattachement qui borne le périmètre de chacun. Le chef prend les dossiers qu'il
 * confie à son équipe, et ses membres les voient apparaître sur leurs écrans.</p>
 *
 * <p>Un dossier ne va qu'à une équipe : le service refuse de le confier deux fois, et nomme
 * celle qui le détient. Deux équipes sur un dossier, ce sont deux chefs qui peuvent en valider
 * le traitement, et le premier arrivé décide pour l'autre.</p>
 *
 * @author Christian
 *
 */
@Path(value = ArbitrationTeamDossierService.PATH)
@Tag(name = "Gestion des dossiers d'équipe")
public interface ArbitrationTeamDossierService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "dossiers-equipe";

  /**
   * Ce que porte la requête, au-delà de ce que la classe parente apporte.
   *
   * <p>Le concept n'expose pas de mise à jour : l'interface ne factorise donc
   * rien, mais elle tient le contrat des champs et dispense la requête de
   * nommer le {@link ArbitrationTeamDossierDto} à chaque clé.</p>
   *
   * <p>Il n'y a pas de {@code ArbitrationTeamDossierRequestMapper} pour autant : R50 ne le prévoit
   * que là où la création <em>et</em> la mise à jour existent toutes deux, un mapper
   * à un seul type de requête supposant une nouvelle classe générique dans
   * l'extension.</p>
   */
  interface ArbitrationTeamDossierSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'équipe.
     *
     * @return l'équipe
     */
    String getTeamIdentifier();

    /**
     * Cette méthode permet d'assigner l'équipe.
     *
     * @param teamIdentifier l'équipe
     */
    void setTeamIdentifier(String teamIdentifier);

    /**
     * Cette méthode permet d'obtenir le dossier.
     *
     * @return le dossier
     */
    String getDossierIdentifier();

    /**
     * Cette méthode permet d'assigner le dossier.
     *
     * @param dossierIdentifier le dossier
     */
    void setDossierIdentifier(String dossierIdentifier);

    /**
     * {@link ArbitrationTeamDossierDto#JSON_TEAM_IDENTIFIER}.
     */
    String JSON_TEAM_IDENTIFIER = ArbitrationTeamDossierDto.JSON_TEAM_IDENTIFIER;

    /**
     * {@link ArbitrationTeamDossierDto#JSON_DOSSIER_IDENTIFIER}.
     */
    String JSON_DOSSIER_IDENTIFIER = ArbitrationTeamDossierDto.JSON_DOSSIER_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ArbitrationTeamDossierDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_DOSSIER_EQUIPE";

  /**
   * Chemin du service de création unitaire de {@link ArbitrationTeamDossierDto}.
   */
  String CREATE_PATH = "";

  /**
   * Confie un dossier à une équipe.
   *
   * @param request l'équipe et le dossier
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Rattachement d'un dossier à une équipe")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ArbitrationTeamDossierCreateRequestDto request);

  /**
   * Requête de rattachement d'un dossier.
   */
  @Getter
  @Setter
  class ArbitrationTeamDossierCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ArbitrationTeamDossierSaveRequestDto {

    @JsonbProperty(JSON_TEAM_IDENTIFIER)
    private String teamIdentifier;

    @JsonbProperty(JSON_DOSSIER_IDENTIFIER)
    private String dossierIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ArbitrationTeamDossierDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DOSSIER_EQUIPE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ArbitrationTeamDossierDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des rattachements.
   *
   * @param request critères, projection et pagination
   * @return les rattachements correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER, summary = "Consultation des dossiers d'équipe")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ArbitrationTeamDossierGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de rattachements.
   */
  @Getter
  @Setter
  public static class ArbitrationTeamDossierGetManyResponseDto
      extends AbstractGetByPageResponseDto<ArbitrationTeamDossierDto> {
    @JsonbProperty(JSON_DATAS)
    private List<ArbitrationTeamDossierDto> datas;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ArbitrationTeamDossierDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DOSSIER_EQUIPE";

  /**
   * Chemin du service de suppression unitaire de {@link ArbitrationTeamDossierDto}.
   */
  String DELETE_PATH = "";

  /**
   * Retire un dossier d'une équipe.
   *
   * <p>Rien de ce qui a été instruit n'est défait : le dossier sort du périmètre de l'équipe,
   * ses lignes gardent leurs décisions et leurs auteurs.</p>
   *
   * @param request l'identifiant à retirer
   * @return l'identifiant retiré
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER, summary = "Retrait d'un dossier d'une équipe")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
