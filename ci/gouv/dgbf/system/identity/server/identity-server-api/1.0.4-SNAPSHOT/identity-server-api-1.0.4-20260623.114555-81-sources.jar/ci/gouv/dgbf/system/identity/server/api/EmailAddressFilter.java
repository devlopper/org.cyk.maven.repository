package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStringValue;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link EmailAddressDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class EmailAddressFilter extends AbstractIdentifiableFilter
    implements FilterHasStringValue {

  String value;
  
  @Override
  protected void doInitialize(FilterDto filter) {
    updateValue(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterValue(filter);
  }
}
