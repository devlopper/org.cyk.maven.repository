package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementClient;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementService.SalaryElementGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SalaryElementDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class SalaryElementSelectOneController extends AbstractSelectOneIdentifiableController<
    SalaryElementDto, SalaryElementGetManyResponseDto, SalaryElementClient> {

  @Getter
  @Inject
  SalaryElementClient client;

  protected SalaryElementSelectOneController() {
    super(SalaryElementDto.class, SelectItemLabelStrategy.NAME);
  }
}
