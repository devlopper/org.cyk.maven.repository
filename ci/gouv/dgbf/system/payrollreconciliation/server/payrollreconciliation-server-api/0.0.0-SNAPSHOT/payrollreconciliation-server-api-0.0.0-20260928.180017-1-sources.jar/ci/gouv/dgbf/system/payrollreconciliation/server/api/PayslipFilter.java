package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipDto}.
 *
 * @author desysoft
 *
 */
@Getter
@Setter
public class PayslipFilter extends AbstractIdentifiableFilter {

  /**
   * Exercice fiscal.
   */
  private String fiscalYear;

  /**
   * Période (mois).
   */
  private Integer period;

  /**
   * Indicateur Fonctionnaire/Agent non-fonctionnaire.
   */
  private Boolean civilServant;

  /**
   * Corps.
   */
  private String corps;

  /**
   * Emploi.
   */
  private String job;

  /**
   * Type de montant (MONTANT_BRUT / MONTANT_NET / MONTANT_RETENUES).
   */
  private String amountType;

  /**
   * Filtre sur écarts uniquement.
   */
  private Boolean onlyVariances;

  /**
   * Recherche libre.
   */
  private String query;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    fiscalYear = getFiscalYear(filter);
    period = getPeriod(filter);
    civilServant = getCivilServant(filter);
    corps = getCorps(filter);
    job = getJob(filter);
    amountType = getAmountType(filter);
    onlyVariances = getOnlyVariances(filter);
    query = getQuery(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFiscalYear(filter, fiscalYear);
    setPeriod(filter, period);
    setCivilServant(filter, civilServant);
    setCorps(filter, corps);
    setJob(filter, job);
    setAmountType(filter, amountType);
    setOnlyVariances(filter, onlyVariances);
    setQuery(filter, query);
  }

  /**
   * Cette méthode permet d'assigner l'exercice fiscal.
   *
   * @param filter filtre
   * @param fiscalYear exercice fiscal
   */
  public static void setFiscalYear(FilterDto filter, String fiscalYear) {
    set(filter, JSON_FISCAL_YEAR, f -> f.getValueAsString(),
        f -> f.setValueAsString(fiscalYear));
  }

  /**
   * Cette méthode permet d'obtenir l'exercice fiscal.
   *
   * @param filter filtre
   * @return exercice fiscal
   */
  public static String getFiscalYear(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FISCAL_YEAR));
  }

  /**
   * Cette méthode permet d'assigner la période.
   *
   * @param filter filtre
   * @param period période
   */
  public static void setPeriod(FilterDto filter, Integer period) {
    set(filter, JSON_PERIOD, f -> f.getValueAsInteger(), f -> f.setValueAsInteger(period));
  }

  /**
   * Cette méthode permet d'obtenir la période.
   *
   * @param filter filtre
   * @return période
   */
  public static Integer getPeriod(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_PERIOD));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur Fonctionnaire/Agent non-fonctionnaire.
   *
   * @param filter filtre
   * @param civilServant indicateur Fonctionnaire/Agent non-fonctionnaire
   */
  public static void setCivilServant(FilterDto filter, Boolean civilServant) {
    set(filter, JSON_CIVIL_SERVANT, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(civilServant));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur Fonctionnaire/Agent non-fonctionnaire.
   *
   * @param filter filtre
   * @return indicateur Fonctionnaire/Agent non-fonctionnaire
   */
  public static Boolean getCivilServant(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_CIVIL_SERVANT));
  }

  /**
   * Cette méthode permet d'assigner le corps.
   *
   * @param filter filtre
   * @param corps corps
   */
  public static void setCorps(FilterDto filter, String corps) {
    set(filter, JSON_CORPS, f -> f.getValueAsString(), f -> f.setValueAsString(corps));
  }

  /**
   * Cette méthode permet d'obtenir le corps.
   *
   * @param filter filtre
   * @return corps
   */
  public static String getCorps(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CORPS));
  }

  /**
   * Cette méthode permet d'assigner l'emploi.
   *
   * @param filter filtre
   * @param job emploi
   */
  public static void setJob(FilterDto filter, String job) {
    set(filter, JSON_JOB, f -> f.getValueAsString(), f -> f.setValueAsString(job));
  }

  /**
   * Cette méthode permet d'obtenir l'emploi.
   *
   * @param filter filtre
   * @return emploi
   */
  public static String getJob(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_JOB));
  }

  /**
   * Cette méthode permet d'assigner le type de montant.
   *
   * @param filter filtre
   * @param amountType type de montant
   */
  public static void setAmountType(FilterDto filter, String amountType) {
    set(filter, JSON_AMOUNT_TYPE, f -> f.getValueAsString(),
        f -> f.setValueAsString(amountType));
  }

  /**
   * Cette méthode permet d'obtenir le type de montant.
   *
   * @param filter filtre
   * @return type de montant
   */
  public static String getAmountType(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_AMOUNT_TYPE));
  }

  /**
   * Cette méthode permet d'assigner le filtre sur écarts uniquement.
   *
   * @param filter filtre
   * @param onlyVariances écarts uniquement
   */
  public static void setOnlyVariances(FilterDto filter, Boolean onlyVariances) {
    set(filter, JSON_ONLY_VARIANCES, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(onlyVariances));
  }

  /**
   * Cette méthode permet d'obtenir le filtre sur écarts uniquement.
   *
   * @param filter filtre
   * @return écarts uniquement
   */
  public static Boolean getOnlyVariances(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_ONLY_VARIANCES));
  }

  /**
   * Cette méthode permet d'assigner la recherche libre.
   *
   * @param filter filtre
   * @param query recherche libre
   */
  public static void setQuery(FilterDto filter, String query) {
    set(filter, JSON_QUERY, f -> f.getValueAsString(), f -> f.setValueAsString(query));
  }

  /**
   * Cette méthode permet d'obtenir la recherche libre.
   *
   * @param filter filtre
   * @return recherche libre
   */
  public static String getQuery(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_QUERY));
  }

  /**
   * Identifiant json champ {@link PayslipFilter#fiscalYear}.
   */
  public static final String JSON_FISCAL_YEAR = PayslipDto.JSON_FISCAL_YEAR;

  /**
   * Identifiant json champ {@link PayslipFilter#period}.
   */
  public static final String JSON_PERIOD = PayslipDto.JSON_PERIOD;

  /**
   * Identifiant json champ {@link PayslipFilter#civilServant}.
   */
  public static final String JSON_CIVIL_SERVANT = PayslipDto.JSON_CIVIL_SERVANT;

  /**
   * Identifiant json champ {@link PayslipFilter#corps}.
   */
  public static final String JSON_CORPS = PayslipDto.JSON_CORPS;

  /**
   * Identifiant json champ {@link PayslipFilter#job}.
   */
  public static final String JSON_JOB = PayslipDto.JSON_JOB;

  /**
   * Identifiant json champ {@link PayslipFilter#amountType}.
   */
  public static final String JSON_AMOUNT_TYPE = PayslipDto.JSON_AMOUNT_TYPE;

  /**
   * Identifiant json champ {@link PayslipFilter#onlyVariances}.
   */
  public static final String JSON_ONLY_VARIANCES = "ecartUniquement";

  /**
   * Identifiant json champ {@link PayslipFilter#query}.
   */
  public static final String JSON_QUERY = "recherche";

}
