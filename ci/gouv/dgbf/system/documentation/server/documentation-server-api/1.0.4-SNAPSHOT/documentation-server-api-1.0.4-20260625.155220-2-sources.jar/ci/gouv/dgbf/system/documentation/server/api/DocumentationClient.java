package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationGetManyResponseDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationUpdateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentationService.DocumentationUpdateTextRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client du service DocumentationService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class DocumentationClient extends AbstractClient<DocumentationService>
    implements GetByIdentifier<DocumentationDto>, GetMany<DocumentationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public DocumentationClient service(DocumentationService service) {
    return (DocumentationClient) super.service(service);
  }

  /**
   * {@link DocumentationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(DocumentationCreateRequestDto request) {
    return new CreateExecutor(DocumentationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link DocumentationService#getMany}.
   *
   * @param request requête
   * @return {@link DocumentationGetManyResponseDto}
   */
  public DocumentationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<DocumentationGetManyResponseDto>(
        DocumentationGetManyResponseDto.class, DocumentationService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link DocumentationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DocumentationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link DocumentationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public DocumentationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<DocumentationDto>(DocumentationDto.class,
        DocumentationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link DocumentationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DocumentationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link DocumentationService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public DocumentationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<DocumentationDto>(DocumentationDto.class,
        DocumentationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link DocumentationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DocumentationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link DocumentationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(DocumentationUpdateRequestDto request) {
    return new IdentifiableExecutor(DocumentationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link DocumentationService#updateText}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateText(DocumentationUpdateTextRequestDto request) {
    return new IdentifiableExecutor(DocumentationService.UPDATE_TEXT_IDENTIFIER)
        .execute(() -> service().updateText(request));
  }

  /**
   * {@link DocumentationService#updateFilesGroupIdentifierToNonNull}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateFilesGroupIdentifierToNonNull(
      ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(
        DocumentationService.UPDATE_FILES_GROUP_IDENTIFIER_TO_NON_NULL_IDENTIFIER)
            .execute(() -> service().updateFilesGroupIdentifierToNonNull(request));
  }

  /**
   * {@link DocumentationService#updateFilesGroupIdentifierToNull}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateFilesGroupIdentifierToNull(ByIdentifierRequestDto request) {
    return new IdentifiableExecutor(
        DocumentationService.UPDATE_FILES_GROUP_IDENTIFIER_TO_NULL_IDENTIFIER)
            .execute(() -> service().updateFilesGroupIdentifierToNull(request));
  }

  /**
   * {@link DocumentationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(DocumentationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link DocumentationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
