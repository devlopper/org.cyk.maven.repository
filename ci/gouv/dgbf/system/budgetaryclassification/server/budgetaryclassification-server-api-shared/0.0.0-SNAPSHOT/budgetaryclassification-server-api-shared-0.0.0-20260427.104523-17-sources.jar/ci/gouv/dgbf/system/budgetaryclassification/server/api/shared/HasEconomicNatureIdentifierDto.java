package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de la nature economique.
 *
 * @author Arnaud
 */
public interface HasEconomicNatureIdentifierDto
       extends HasEconomicNatureIdentifier {

  /**
   * Identifiant json de l'identifiant de la nature economique.
   */
  String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureEconomique";
}