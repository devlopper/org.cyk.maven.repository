package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ExpenditureDto}.
 *
 * @author Christian
 */
@Path(value = ExpenditureService.PATH)
@Tag(name = "Gestion des Dépenses")
public interface ExpenditureService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "depenses";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ExpenditureSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de l'exercice.
     *
     * @return identifiant de l'exercice
     */
    String getExerciseIdentifier();

    /**
     * Définit l'identifiant de l'exercice.
     *
     * @param exerciseIdentifier l'identifiant de l'exercice
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir ldentifiant de l'activité.
     *
     * @return identifiant de l'exercice
     */
    String getActivityIdentifier();

    /**
     * Définit l'identifiant de l'activité.
     *
     * @param activityIdentifier l'identifiant de l'activité
     */
    void setActivityIdentifier(String activityIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la nature économique.
     *
     * @return identifiant de la nature économique
     */
    String getEconomicNatureIdentifier();

    /**
     * Définit l'identifiant de la nature économique.
     *
     * @param economicNatureIdentifier l'identifiant de la nature économique
     */
    void setEconomicNatureIdentifier(String economicNatureIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la source de financement.
     *
     * @return identifiant de la source de financement
     */
    String getFundingSourceIdentifier();

    /**
     * Définit l'identifiant de la source de financement.
     *
     * @param fundingSourceIdentifier l'identifiant de la source de financement
     */
    void setFundingSourceIdentifier(String fundingSourceIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du bailleur.
     *
     * @return identifiant du bailleur
     */
    String getLessorIdentifier();

    /**
     * Définit l'identifiant du bailleur.
     *
     * @param lessorIdentifier l'identifiant du bailleur
     */
    void setLessorIdentifier(String lessorIdentifier);

    /**
     * Identifiant de l'exercice.
     */
    String JSON_EXERCISE_IDENTIFIER = ExpenditureDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * Identifiant de l'activité.
     */
    String JSON_ACTIVITY_IDENTIFIER = ExpenditureDto.JSON_ACTIVITY_IDENTIFIER;

    /**
     * Identifiant de la nature économique.
     */
    String JSON_ECONOMIC_NATURE_IDENTIFIER = ExpenditureDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

    /**
     * Identifiant de la source de financement.
     */
    String JSON_FUNDING_SOURCE_IDENTIFIER = ExpenditureDto.JSON_FUNDING_SOURCE_IDENTIFIER;

    /**
     * Identifiant du bailleur.
     */
    String JSON_LESSOR_IDENTIFIER = ExpenditureDto.JSON_LESSOR_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ExpenditureDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_DEPENSE";

  /**
   * Chemin du service de création unitaire de {@link ExpenditureDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ExpenditureCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ExpenditureCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ExpenditureSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_FUNDING_SOURCE_IDENTIFIER)
    private String fundingSourceIdentifier;

    @JsonbProperty(JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ExpenditureDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DEPENSE";

  /**
   * Chemin du service d'obtention de plusieurs {@link ExpenditureDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ExpenditureGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ExpenditureGetManyResponseDto
      extends AbstractGetByPageResponseDto<ExpenditureDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ExpenditureDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ExpenditureDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DEPENSE";

  /**
   * Chemin du service d'obtention unitaire de {@link ExpenditureDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ExpenditureDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ExpenditureDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DEPENSE";

  /**
   * Chemin du service d'obtention par identifiant de {@link ExpenditureDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ExpenditureDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ExpenditureDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DEPENSE";

  /**
   * Chemin du service de mise à jour unitaire de {@link ExpenditureDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ExpenditureUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ExpenditureDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ExpenditureUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ExpenditureSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
    private String economicNatureIdentifier;

    @JsonbProperty(JSON_FUNDING_SOURCE_IDENTIFIER)
    private String fundingSourceIdentifier;

    @JsonbProperty(JSON_LESSOR_IDENTIFIER)
    private String lessorIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ExpenditureDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_DEPENSE";

  /**
   * Chemin du service de suppression unitaire de {@link ExpenditureDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ExpenditureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
