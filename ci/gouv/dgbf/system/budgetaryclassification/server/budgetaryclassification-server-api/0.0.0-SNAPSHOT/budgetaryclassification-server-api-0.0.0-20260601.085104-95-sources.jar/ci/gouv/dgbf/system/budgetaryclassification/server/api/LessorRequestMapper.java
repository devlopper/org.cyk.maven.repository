package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.LessorService.LessorUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link LessorDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link LessorDto}.

    @author Arnaud
               """)
public interface LessorRequestMapper extends RequestMapper<LessorDto,
    LessorCreateRequestDto, LessorUpdateRequestDto> {

}
