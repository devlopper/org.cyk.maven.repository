package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'utilisateurs sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasUserCountAsStringDto extends HasUserCountAsString {

  /**
   * Identifiant json du nombre d'utilisateurs sous forme de chaîne.
   */
  String JSON_USER_COUNT_AS_STRING = "nombreUtilisateursChaine";
}
