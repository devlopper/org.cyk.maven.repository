package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateNAsStringDto
    extends HasRemainingAmountToArbitrateNAsString {

  /**
   * Identifiant json du montant restant à arbitrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_ARBITRATE_N_AS_STRING =
      "montantResteAArbitrerNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName