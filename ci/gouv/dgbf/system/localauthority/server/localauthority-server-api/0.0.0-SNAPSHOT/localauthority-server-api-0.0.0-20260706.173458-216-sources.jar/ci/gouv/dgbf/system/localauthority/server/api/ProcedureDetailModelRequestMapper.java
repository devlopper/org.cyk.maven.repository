package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailModelService.ProcedureDetailModelCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ProcedureDetailModelService.ProcedureDetailModelUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcedureDetailModelDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ProcedureDetailModelDto}.

    @author Desysoft
               """)
public interface ProcedureDetailModelRequestMapper extends RequestMapper<ProcedureDetailModelDto,
    ProcedureDetailModelCreateRequestDto, ProcedureDetailModelUpdateRequestDto> {

}

