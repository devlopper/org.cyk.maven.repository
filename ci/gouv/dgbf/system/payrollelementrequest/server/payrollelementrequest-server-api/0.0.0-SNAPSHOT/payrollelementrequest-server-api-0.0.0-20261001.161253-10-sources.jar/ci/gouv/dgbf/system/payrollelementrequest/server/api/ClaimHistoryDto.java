package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une ligne d'historique de {@link PayrollElementClaimDto} (RG_REP_TRA_02)
 * -- une ligne par changement de statut, Suspension ou Reprise ({@link #eventType}), jamais mise à
 * jour ni supprimée. Lecture seule : aucune opération de création/modification/suppression n'est
 * exposée ici, l'enregistrement restant interne au serveur (déclenché par les transitions de
 * {@link PayrollElementClaimDto}).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimHistoryDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link PayrollElementClaimDto}.
   */
  @JsonbProperty(JSON_CLAIM_IDENTIFIER)
  private String claimIdentifier;

  /**
   * Statut de la réclamation au moment de cet événement.
   */
  @JsonbProperty(JSON_STATUS)
  private PayrollElementClaimStatus status;

  /**
   * Discriminant de l'événement.
   */
  @JsonbProperty(JSON_EVENT_TYPE)
  private ClaimHistoryEventType eventType;

  /**
   * Date et heure de l'événement.
   */
  @JsonbProperty(JSON_EVENT_DATE)
  private LocalDateTime eventDate;

  /**
   * Identifiant de l'Utilisateur ou de l'identité ayant déclenché l'événement.
   */
  @JsonbProperty(JSON_ACTOR)
  private String actor;

  /**
   * Renseigné pour {@link PayrollElementClaimStatus#REJECTED} (obligatoire) et
   * {@link PayrollElementClaimStatus#DEFERRED} (facultatif) ; {@code null} sinon.
   */
  @JsonbProperty(JSON_MOTIF)
  private String motif;

  /**
   * Identifiant json {@link #claimIdentifier}.
   */
  public static final String JSON_CLAIM_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json {@link #eventType}.
   */
  public static final String JSON_EVENT_TYPE = "typeEvenement";

  /**
   * Identifiant json {@link #eventDate}.
   */
  public static final String JSON_EVENT_DATE = "dateEvenement";

  /**
   * Identifiant json {@link #actor}.
   */
  public static final String JSON_ACTOR = "acteur";

  /**
   * Identifiant json {@link #motif}.
   */
  public static final String JSON_MOTIF = "motif";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "historique de réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "historiques de réclamation";
}
