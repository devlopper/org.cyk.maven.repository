package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasAccessToken;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasEmailAddress;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.FilterHasReporterIdentityIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link DeclarationDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class DeclarationFilter extends AbstractIdentifiableFilter
    implements FilterHasReporterIdentityIdentifier, FilterHasEmailAddress, FilterHasAccessToken {

  private String reporterIdentityIdentifier;

  private String emailAddress;
  
  private String accessToken;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DeclarationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DeclarationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateReporterIdentityIdentifier(filter);
    updateEmailAddress(filter);
    updateAccessToken(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterReporterIdentityIdentifier(filter);
    updateFilterAccessToken(filter);
    updateFilterEmailAddress(filter);
  }

}
