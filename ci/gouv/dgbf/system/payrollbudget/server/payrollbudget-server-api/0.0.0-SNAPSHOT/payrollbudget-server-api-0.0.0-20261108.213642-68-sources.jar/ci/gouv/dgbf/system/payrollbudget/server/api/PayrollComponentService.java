package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat du référentiel des postes de paie.
 *
 * <p><strong>Lecture seule, et c'est une décision.</strong> Le poste de paie appartient au
 * référentiel de la rémunération, où il est créé, codifié et rattaché à sa nature économique.
 * L'ouvrir à l'écriture depuis la budgétisation ferait diverger deux vérités sur le même objet.
 * Ce module le lit, le paramètre — et ne le touche pas.</p>
 *
 * <p>Ce contrat n'existe que pour l'écran de paramétrage des mouvements : il sert la liste sur
 * laquelle on désigne les postes qu'un type de mouvement impacte. Aucune création, aucune
 * modification, aucune suppression n'est exposée, parce qu'aucune n'est légitime.</p>
 *
 * @author Christian
 *
 */
@Path(value = PayrollComponentService.PATH)
@Tag(name = "Gestion des postes de paie")
public interface PayrollComponentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "postes-paie";

  /**
   * Identifiant du service d'obtention de plusieurs {@link PayrollComponentDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs {@link PayrollComponentDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des postes de paie.
   *
   * @param request critères, projection et pagination
   * @return les postes correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER, summary = "Consultation des postes de paie")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = PayrollComponentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de postes de paie.
   */
  @Getter
  @Setter
  public static class PayrollComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<PayrollComponentDto> {
    @JsonbProperty(JSON_DATAS)
    private List<PayrollComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de {@link PayrollComponentDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de {@link PayrollComponentDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'un poste par son identifiant.
   *
   * @param request identifiant et projection
   * @return le poste correspondant
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);
}
