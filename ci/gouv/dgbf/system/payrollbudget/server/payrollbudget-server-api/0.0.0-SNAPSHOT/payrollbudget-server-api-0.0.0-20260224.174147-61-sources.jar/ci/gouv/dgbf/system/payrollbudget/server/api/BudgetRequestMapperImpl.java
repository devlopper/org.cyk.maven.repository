package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-02-24T17:42:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetRequestMapperImpl implements BudgetRequestMapper {

    @Override
    public BudgetService.BudgetCreateRequestDto mapCreate(BudgetDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetService.BudgetCreateRequestDto budgetCreateRequestDto = new BudgetService.BudgetCreateRequestDto();

        budgetCreateRequestDto.setCode( arg0.getCode() );
        budgetCreateRequestDto.setName( arg0.getName() );
        budgetCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );

        return budgetCreateRequestDto;
    }

    @Override
    public BudgetService.BudgetUpdateRequestDto mapUpdate(BudgetDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetService.BudgetUpdateRequestDto budgetUpdateRequestDto = new BudgetService.BudgetUpdateRequestDto();

        budgetUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetUpdateRequestDto.setCode( arg0.getCode() );
        budgetUpdateRequestDto.setName( arg0.getName() );
        budgetUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );

        return budgetUpdateRequestDto;
    }
}
