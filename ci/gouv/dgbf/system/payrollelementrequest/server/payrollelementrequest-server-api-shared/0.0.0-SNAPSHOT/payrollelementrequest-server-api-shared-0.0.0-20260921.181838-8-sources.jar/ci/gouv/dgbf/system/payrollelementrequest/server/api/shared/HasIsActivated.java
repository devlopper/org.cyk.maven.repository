package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'interrupteur d'activation (R48,
 * RG_REP_SOU_15) d'un référentiel sans workflow.
 *
 * @author akm
 *
 */
public interface HasIsActivated {

  /**
   * Identifiant java de {@link #getIsActivated()}.
   */
  String FIELD_IS_ACTIVATED = "isActivated";

  /**
   * Cette méthode permet d'obtenir l'interrupteur d'activation.
   *
   * @return interrupteur d'activation
   */
  Boolean getIsActivated();

  /**
   * Cette méthode permet d'assigner l'interrupteur d'activation.
   *
   * @param isActivated interrupteur d'activation
   */
  void setIsActivated(Boolean isActivated);
}
