package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de {@link ActivityDto}.
 *
 * @author Christian
 *
 */
public interface ActivityContainerableDto extends ActivityContainerable {

  /**
   * Identifiant json {@link ActivityContainerableDto#getCreatedActivityCountAsString()}.
   */
  String JSON_CREATED_ACTIVITY_COUNT_AS_STRING = "nombreActiviteCreeeChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getSuspendedActivityCountAsString()}.
   */
  String JSON_SUSPENDED_ACTIVITY_COUNT_AS_STRING = "nombreActiviteSuspendueChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getStartedActivityCount()}.
   */
  String JSON_STARTED_ACTIVITY_COUNT = "nombreActiviteDemarree";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getStartedActivityCountAsString()}.
   */
  String JSON_STARTED_ACTIVITY_COUNT_AS_STRING = "nombreActiviteDemarreeChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getStoppedActivityCountAsString()}.
   */
  String JSON_STOPPED_ACTIVITY_COUNT_AS_STRING = "nombreActiviteArreteeChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getRealizedActivityCount()}.
   */
  String JSON_REALIZED_ACTIVITY_COUNT = "nombreActiviteRealisee";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getRealizedActivityCountAsString()}.
   */
  String JSON_REALIZED_ACTIVITY_COUNT_AS_STRING = "nombreActiviteRealiseeChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getLateActivityCount()}.
   */
  String JSON_LATE_ACTIVITY_COUNT = "nombreActiviteEnRetard";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getLateActivityCountAsString()}.
   */
  String JSON_LATE_ACTIVITY_COUNT_AS_STRING = "nombreActiviteEnRetardChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getNotLateActivityCountAsString()}.
   */
  String JSON_NOT_LATE_ACTIVITY_COUNT_AS_STRING = "nombreActiviteNonEnRetardChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getActivityCount()}.
   */
  String JSON_ACTIVITY_COUNT = "nombreActivite";

  /**
   * Identifiant json {@link ActivityContainerableDto#getActivityCountAsString()}.
   */
  String JSON_ACTIVITY_COUNT_AS_STRING = "nombreActiviteChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getPendingStartActivityCountAsString()}.
   */
  String JSON_PENDING_START_ACTIVITY_COUNT_AS_STRING = "nombreActiviteEnAttenteDemarrageChaine";

  /**
   * Identifiant json {@link ActivityContainerableDto#getPendingStartActivityCount()}.
   */
  String JSON_PENDING_START_ACTIVITY_COUNT = "nombreActiviteEnAttenteDemarrage";
    
  /**
   * Identifiant json {@link ActivityContainerableDto#getDoneActivityCount()}.
   */
  String JSON_DONE_ACTIVITY_COUNT = "nombreActiviteEffeftuee";

  /**
   * Identifiant json {@link ActivityContainerableDto#getDoneActivityCountAsString()}.
   */
  String JSON_DONE_ACTIVITY_COUNT_AS_STRING = "nombreActiviteEffeftueeChaine";
  
  /**
   * Identifiant json {@link ActivityContainerableDto#getNotDoneActivityCountAsString()}.
   */
  String JSON_NOT_DONE_ACTIVITY_COUNT_AS_STRING = "nombreActiviteNonEffeftueeChaine";
}
