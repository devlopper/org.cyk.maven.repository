package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcedureModelDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ProcedureModelDto}.

    @author Christian
               """)
public interface ProcedureModelRequestMapper
    extends
    RequestMapper<ProcedureModelDto,
        ProcedureModelService.ProcedureModelCreateRequestDto,
        ProcedureModelService.ProcedureModelUpdateRequestDto> {

}
