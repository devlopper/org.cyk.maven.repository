package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TriennialProgramActivityFundingTypeDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class TriennialProgramActivityFundingTypeFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramDto}.
   */
  String triennialProgramIdentifier;


  /**
   * Identifiant {@link ActivityDto}.
   */
  String activityIdentifier;

  /**
   * Identifiant {@link TriennialProgramActivityDto}.
   */
  String triennialProgramActivityIdentifier;


  /**
   * Identifiant {@link FundingTypeDto}.
   */
  String fundingTypeIdentifier;

  /**
   * {@link ActivityCategory}.
   */
  ActivityCategory activityCategory;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public TriennialProgramActivityFundingTypeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public TriennialProgramActivityFundingTypeFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    triennialProgramActivityIdentifier = getTriennialProgramActivityIdentifier(filter);
    triennialProgramIdentifier = getTriennialProgramIdentifier(filter);
    activityIdentifier = getActivityIdentifier(filter);
    fundingTypeIdentifier = getFundingTypeIdentifier(filter);
    activityCategory = getActivityCategory(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTriennialProgramActivityIdentifier(filter, triennialProgramActivityIdentifier);
    setTriennialProgramIdentifier(filter, triennialProgramIdentifier);
    setActivityIdentifier(filter, activityIdentifier);
    setFundingTypeIdentifier(filter, fundingTypeIdentifier);
    setActivityCategory(filter, activityCategory);
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramActivityDto}
   */
  public static String getTriennialProgramActivityIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link TriennialProgramActivityDto}
   */
  public static void setTriennialProgramActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramActivityDto}
   */
  public static String getFundingTypeIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_FUNDING_TYPE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link TriennialProgramActivityDto}
   */
  public static void setFundingTypeIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FUNDING_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramDto}
   */
  public static String getTriennialProgramIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link TriennialProgramDto}
   */
  public static void setTriennialProgramIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link ActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link ActivityDto}
   */
  public static String getActivityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link ActivityDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link ActivityDto}
   */
  public static void setActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'assigner la {@link ActivityCategory}.
   *
   * @param filter   filtre
   * @param category {@link ActivityCategory}
   */
  public static void setActivityCategory(FilterDto filter, ActivityCategory category) {
    set(filter, JSON_ACTIVITY_CATEGORY, f -> f.getValueAsString(), f -> f.setValueAsEnum(category));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ActivityCategory}.
   *
   * @param filter filtre
   * @return {@link ActivityCategory}
   */
  public static ActivityCategory getActivityCategory(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsEnum(JSON_ACTIVITY_CATEGORY, ActivityCategory.class));
  }

  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
      TriennialProgramActivityFundingTypeDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;


  /**
   * Identifiant json champ {@link #triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
      TriennialProgramActivityFundingTypeDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;


  /**
   * Identifiant json champ {@link #triennialProgramIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER =
      TriennialProgramActivityFundingTypeDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #fundingTypeIdentifier}.
   */
  public static final String JSON_FUNDING_TYPE_IDENTIFIER =
      TriennialProgramActivityFundingTypeDto.JSON_FUNDING_TYPE_IDENTIFIER;

  /**
   * Identifiant json champ {@link TriennialProgramActivityFundingTypeFilter#activityCategory}.
   */
  public static final String JSON_ACTIVITY_CATEGORY =
      TriennialProgramActivityFundingTypeDto.JSON_ACTIVITY_CATEGORY;
}

