package ci.gouv.dgbf.extension.primefaces.component.output;

/**
 * Cette classe représente la pastille d'une information booléenne (libellé, icône et sévérité
 * pour vrai et pour faux).
 *
 * @author Christian
 */
public class BooleanTagRepresentation extends AbstractTagRepresentation<Boolean> {

  private final String trueLabel;
  private final String falseLabel;
  private final String trueIcon;
  private final String falseIcon;
  private final String trueSeverity;
  private final String falseSeverity;

  /**
   * Constructeur.
   *
   * @param trueLabel libellé si vrai
   * @param falseLabel libellé si faux
   * @param trueIcon icône si vrai
   * @param falseIcon icône si faux
   * @param trueSeverity sévérité si vrai
   * @param falseSeverity sévérité si faux
   */
  public BooleanTagRepresentation(String trueLabel, String falseLabel, String trueIcon,
      String falseIcon, String trueSeverity, String falseSeverity) {
    this.trueLabel = trueLabel;
    this.falseLabel = falseLabel;
    this.trueIcon = trueIcon;
    this.falseIcon = falseIcon;
    this.trueSeverity = trueSeverity;
    this.falseSeverity = falseSeverity;
  }

  @Override
  protected String getLabel(Boolean value) {
    return value ? trueLabel : falseLabel;
  }

  @Override
  protected String getIcon(Boolean value) {
    return value ? trueIcon : falseIcon;
  }

  @Override
  protected String getSeverity(Boolean value) {
    return value ? trueSeverity : falseSeverity;
  }
}
