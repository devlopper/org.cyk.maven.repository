package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ModulesGroupDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ModulesGroupFilter extends AbstractIdentifiableFilter {

}
