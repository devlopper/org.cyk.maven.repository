package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.report.server.api.ReportGroupService.ReportGroupCreateRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportGroupService.ReportGroupGetManyResponseDto;
import ci.gouv.dgbf.system.report.server.api.ReportGroupService.ReportGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ReportGroupService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ReportGroupClient extends
    AbstractClient<ReportGroupService>
    implements GetByIdentifier<ReportGroupDto>,
    GetMany<ReportGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ReportGroupClient service(
      ReportGroupService service) {
    return (ReportGroupClient) super.service(service);
  }

  /**
   * {@link ReportGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ReportGroupCreateRequestDto request) {
    return new CreateExecutor(ReportGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ReportGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ReportGroupGetManyResponseDto>(
        ReportGroupGetManyResponseDto.class,
        ReportGroupService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link ReportGroupService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReportGroupGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ReportGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ReportGroupDto>(
        ReportGroupDto.class, ReportGroupService
        .GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ReportGroupService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReportGroupDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ReportGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ReportGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ReportGroupDto>(
        ReportGroupDto.class,
        ReportGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ReportGroupService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReportGroupDto getByIdentifier(String identifier,
      ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ReportGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ReportGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ReportGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ReportGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ReportGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ReportGroupService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

