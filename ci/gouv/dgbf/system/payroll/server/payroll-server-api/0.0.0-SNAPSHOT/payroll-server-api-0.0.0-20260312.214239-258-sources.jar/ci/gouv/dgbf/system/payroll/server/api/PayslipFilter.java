package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsCalculable;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsCessibleAmountLessThanMax;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasRemunerableIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCodes;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollServiceTypeCode;
import ci.gouv.dgbf.system.payroll.server.api.shared.FilterHasPayrollServiceTypeIdentifier;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollIdentifierDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayslipFilter extends AbstractIdentifiableFilter
    implements FilterHasRemunerableIdentifier, FilterHasRegistrationNumber,
    FilterHasPayrollServiceTypeIdentifier, FilterHasPayrollServiceTypeCode, FilterHasIsCalculable,
    FilterHasStatusCode, FilterHasStatusCodes, FilterHasIsCessibleAmountLessThanMax {
  
  /**
   * Identifiant de {@link PayrollDto}.
   */
  String payrollIdentifier;

  private String payrollServiceTypeIdentifier;

  private String payrollServiceTypeCode;

  private String registrationNumber;

  private String remunerableIdentifier;

  private Boolean isCalculable;

  private Boolean isCessibleAmountLessThanMax;

  private Boolean isLitigatable;
  
  /**
   * Identifiant de {@link FunctionaryBudgetarySectionUnitDto}.
   */
  private String functionaryBudgetarySectionUnitIdentifier;

  /**
   * Est à controler prioritairement.
   */
  private Boolean isToBeControlledInPriority;

  private String statusCode;

  private Set<String> statusCodes;

  /**
   * Variation montant brut.
   */
  private Integer grossAmountVariation;

  /**
   * Est recalculable.
   */
  private Boolean isRecalculable;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayslipFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayslipFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateRegistrationNumber(filter);
    updateRemunerableIdentifier(filter);
    updatePayrollServiceTypeIdentifier(filter);
    updatePayrollServiceTypeCode(filter);
    updateIsCalculable(filter);
    updateStatusCode(filter);
    updateStatusCodes(filter);
    updateIsCessibleAmountLessThanMax(filter);

    payrollIdentifier = getPayrollIdentifier(filter);
    functionaryBudgetarySectionUnitIdentifier =
        getFunctionaryBudgetarySectionUnitIdentifier(filter);
    isToBeControlledInPriority = getIsToBeControlledInPriority(filter);
    grossAmountVariation = getGrossAmountVariation(filter);
    isRecalculable = getIsRecalculable(filter);
    isLitigatable = getIsLitigatable(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterRegistrationNumber(filter);
    updateFilterRemunerableIdentifier(filter);
    updateFilterPayrollServiceTypeIdentifier(filter);
    updateFilterPayrollServiceTypeCode(filter);
    updateFilterIsCalculable(filter);
    updateFilterStatusCode(filter);
    updateFilterStatusCodes(filter);
    updateFilterIsCessibleAmountLessThanMax(filter);

    setPayrollIdentifier(filter, payrollIdentifier);
    setFunctionaryBudgetarySectionUnitIdentifier(filter, functionaryBudgetarySectionUnitIdentifier);
    setIsToBeControlledInPriority(filter, isToBeControlledInPriority);
    setGrossAmountVariation(filter, grossAmountVariation);
    setIsRecalculable(filter, isRecalculable);
    setIsLitigatable(filter, isLitigatable);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link PayrollDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setPayrollIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_PAYROLL_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link PayrollDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link PayrollDto}
   */
  public static String getPayrollIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PAYROLL_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FunctionaryBudgetarySectionUnitDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFunctionaryBudgetarySectionUnitIdentifier(FilterDto filter,
      String identifier) {
    set(filter, JSON_FUNCTIONARY_BUDGETARY_SECTION_UNIT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FunctionaryBudgetarySectionUnitDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FunctionaryBudgetarySectionUnitDto}
   */
  public static String getFunctionaryBudgetarySectionUnitIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_FUNCTIONARY_BUDGETARY_SECTION_UNIT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner est à controler prioritairement.
   *
   * @param filter filtre
   * @param isToBeControlledInPriority est à controler prioritairement
   */
  public static void setIsToBeControlledInPriority(FilterDto filter,
      Boolean isToBeControlledInPriority) {
    set(filter, JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isToBeControlledInPriority));
  }

  /**
   * Cette méthode permet d'obtenir est à controler prioritairement.
   *
   * @param filter filtre
   * @return est à controler prioritairement
   */
  public static Boolean getIsToBeControlledInPriority(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY));
  }

  /**
   * Cette méthode permet d'assigner la variation montant brut.
   *
   * @param filter filtre
   * @param grossAmountVariation variation montant brut
   */
  public static void setGrossAmountVariation(FilterDto filter, Integer grossAmountVariation) {
    set(filter, JSON_GROSS_AMOUNT_VARIATION, f -> f.getValueAsInteger(),
        f -> f.setValueAsInteger(grossAmountVariation));
  }

  /**
   * Cette méthode permet d'obtenir la variation montant brut.
   *
   * @param filter filtre
   * @return variation montant brut
   */
  public static Integer getGrossAmountVariation(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsIntegerByName(JSON_GROSS_AMOUNT_VARIATION));
  }

  /**
   * Cette méthode permet d'assigner est récalculable.
   *
   * @param filter filtre
   * @param isRecalculable est recalculable
   */
  public static void setIsRecalculable(FilterDto filter, Boolean isRecalculable) {
    set(filter, JSON_IS_RECALCULABLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isRecalculable));
  }

  /**
   * Cette méthode permet d'obtenir est recalculable.
   *
   * @param filter filtre
   * @return est recalculable
   */
  public static Boolean getIsRecalculable(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_RECALCULABLE));
  }

  /**
   * Cette méthode permet d'assigner est récalculable.
   *
   * @param filter filtre
   * @param isLitigatable est litigatable
   */
  public static void setIsLitigatable(FilterDto filter, Boolean isLitigatable) {
    set(filter, JSON_IS_LITIGATABLE, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isLitigatable));
  }

  /**
   * Cette méthode permet d'obtenir est recalculable.
   *
   * @param filter filtre
   * @return est recalculable
   */
  public static Boolean getIsLitigatable(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_LITIGATABLE));
  }

  /**
   * Identifiant json champ {@link PayslipFilter#payrollIdentifier}.
   */
  public static final String JSON_PAYROLL_IDENTIFIER =
      HasPayrollIdentifierDto.JSON_PAYROLL_IDENTIFIER;

  /**
   * Identifiant json champ {@link PayslipFilter#functionaryBudgetarySectionUnitIdentifier}.
   */
  public static final String JSON_FUNCTIONARY_BUDGETARY_SECTION_UNIT_IDENTIFIER =
      FunctionaryBudgetarySectionUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link PayslipFilter#isToBeControlledInPriority}.
   */
  public static final String JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY =
      PayslipDto.JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY;

  /**
   * Identifiant json champ {@link PayslipFilter#grossAmountVariation}.
   */
  public static final String JSON_GROSS_AMOUNT_VARIATION =
      PayslipContainerDto.JSON_GROSS_AMOUNT_VARIATION;

  /**
   * Identifiant JSON {@link #isRecalculable}.
   */
  public static final String JSON_IS_RECALCULABLE = PayslipDto.JSON_IS_RECALCULABLE;

  /**
   * Identifiant JSON {@link #isLitigatable}.
   */
  public static final String JSON_IS_LITIGATABLE = PayslipDto.JSON_IS_LITIGATABLE;
}
