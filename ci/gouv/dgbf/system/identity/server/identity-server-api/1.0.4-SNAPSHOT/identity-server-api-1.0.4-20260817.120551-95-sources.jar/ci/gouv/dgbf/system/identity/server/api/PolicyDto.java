package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une politique.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PolicyDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant du type de politique.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Identifiant json pour {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER = "idTypePolitique";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPolitique";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "politiqueChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "politique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "politiques";
}
