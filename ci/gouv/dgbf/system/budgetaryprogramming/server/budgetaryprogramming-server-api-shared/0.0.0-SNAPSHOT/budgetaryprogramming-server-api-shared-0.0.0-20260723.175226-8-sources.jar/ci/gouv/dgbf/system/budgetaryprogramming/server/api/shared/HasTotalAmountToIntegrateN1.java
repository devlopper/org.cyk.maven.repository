package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToIntegrateN1 {

  /**
   * Obtient le montant total à intégrer pour l'année N+1.
   *
   * @return le montant total à intégrer pour l'année N+1
   */
  Long getTotalAmountToIntegrateN1();

  /**
   * Définit le montant total à intégrer pour l'année N+1.
   *
   * @param totalAmountToIntegrateN1 le montant total à intégrer pour l'année N+1
   */
  void setTotalAmountToIntegrateN1(Long totalAmountToIntegrateN1);

  /**
   * Identifiant java du montant total à intégrer pour l'année N+1.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N1 = "totalAmountToIntegrateN1";
}