package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayIndexDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayIndexFilter extends AbstractIdentifiableFilter {

  /**
   * Grade.
   */
  @JsonbProperty(value = JSON_GRADE_IDENTIFIER)
  String gradeIdentifier;

  /**
   * Identifiant de {@link GradeClassDto}.
   */
  @JsonbProperty(value = JSON_GRADE_CLASS_IDENTIFIER)
  String gradeClassIdentifier;

  /**
   * Identifiant de {@link EchelonDto}.
   */
  @JsonbProperty(value = JSON_ECHELON_IDENTIFIER)
  String echelonIdentifier;

  /**
   * Identifiant de {@link PayScaleDto}.
   */
  @JsonbProperty(value = JSON_PAY_SCALE_IDENTIFIER)
  String payScaleIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public PayIndexFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public PayIndexFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    gradeIdentifier = getGradeIdentifier(filter);
    gradeClassIdentifier = getGradeClassIdentifier(filter);
    echelonIdentifier = getEchelonIdentifier(filter);
    payScaleIdentifier = getPayScaleIdentifier(filter);
  
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGradeIdentifier(filter, gradeIdentifier);
    setGradeClassIdentifier(filter, gradeClassIdentifier);
    setEchelonIdentifier(filter, echelonIdentifier);
    setPayScaleIdentifier(filter, payScaleIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #gradeIdentifier}.
   *
   * @param filter filtre
   * @param gradeIdentifier {@link #gradeIdentifier}
   */
  public static void setGradeIdentifier(FilterDto filter, String gradeIdentifier) {
    set(filter, JSON_GRADE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(gradeIdentifier));
  }

  /**
   * Cette méthode permet d'assigner {@link #gradeClassIdentifier}.
   *
   * @param filter filtre
   * @param gradeClassIdentifier {@link #gradeClassIdentifier}
   */
  public static void setGradeClassIdentifier(FilterDto filter, String gradeClassIdentifier) {
    set(filter, JSON_GRADE_CLASS_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(gradeClassIdentifier));
  }

  /**
   * Cette méthode permet d'assigner {@link #echelonIdentifier}.
   *
   * @param filter filtre
   * @param echelonIdentifier {@link #echelonIdentifier}
   */
  public static void setEchelonIdentifier(FilterDto filter, String echelonIdentifier) {
    set(filter, JSON_ECHELON_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(echelonIdentifier));
  }

  /**
   * Cette méthode permet d'assigner {@link #payScaleIdentifier}.
   *
   * @param filter filtre
   * @param payScaleIdentifier {@link #payScaleIdentifier}
   */
  public static void setPayScaleIdentifier(FilterDto filter, String payScaleIdentifier) {
    set(filter, JSON_PAY_SCALE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(payScaleIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #gradeIdentifier}.
   *
   * @param filter filtre
   * @return {@link #gradeIdentifier}
   */
  public static String getGradeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GRADE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir {@link #gradeClassIdentifier}.
   *
   * @param filter filtre
   * @return {@link #gradeClassIdentifier}
   */
  public static String getGradeClassIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GRADE_CLASS_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir {@link #echelonIdentifier}.
   *
   * @param filter filtre
   * @return {@link #echelonIdentifier}
   */
  public static String getEchelonIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ECHELON_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'obtenir {@link #payScaleIdentifier}.
   *
   * @param filter filtre
   * @return {@link #payScaleIdentifier}
   */
  public static String getPayScaleIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PAY_SCALE_IDENTIFIER));
  }

  /**
   * Identifiant json du {@link #gradeIdentifier}.
   */
  public static final String JSON_GRADE_IDENTIFIER = PayIndexDto.JSON_GRADE_IDENTIFIER;

  /**
   * Identifiant json du {@link #gradeClassIdentifier}.
   */
  public static final String JSON_GRADE_CLASS_IDENTIFIER = PayIndexDto.JSON_GRADE_CLASS_IDENTIFIER;

  /**
   * Identifiant json du {@link #echelonIdentifier}.
   */
  public static final String JSON_ECHELON_IDENTIFIER = PayIndexDto.JSON_ECHELON_IDENTIFIER;

  /**
   * Identifiant json du {@link #payScaleIdentifier}.
   */
  public static final String JSON_PAY_SCALE_IDENTIFIER = PayIndexDto.JSON_PAY_SCALE_IDENTIFIER;
 
}

