package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;

/**
 * Cette classe représente la base de gestionnaire d'icône.
 *
 * @author Christian
 */
@Getter
public abstract class AbstractIconManager {

  protected String home;
  protected String dashboard;
  protected String history;
  protected String isEnabled;
  protected String isNotEnabled;
  
  /**
   * Cette méthode permet de construire.
   */
  public AbstractIconManager() {
    home = "pi pi-home";
    dashboard = "pi pi-chart-bar";
    history = "pi pi-history";
    isEnabled = "pi pi-check-circle";
    isNotEnabled = "pi pi-delete-left";
  }
  
}
