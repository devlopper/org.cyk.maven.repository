package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyService.PolicyUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PolicyDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link PolicyDto}.

    @author Desysoft
               """)
public interface PolicyRequestMapper
    extends RequestMapper<PolicyDto, PolicyCreateRequestDto, PolicyUpdateRequestDto> {

}
