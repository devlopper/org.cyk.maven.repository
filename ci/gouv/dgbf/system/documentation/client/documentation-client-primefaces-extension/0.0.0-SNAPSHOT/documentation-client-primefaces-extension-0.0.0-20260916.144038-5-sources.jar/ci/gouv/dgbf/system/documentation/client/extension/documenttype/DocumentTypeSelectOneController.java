package ci.gouv.dgbf.system.documentation.client.extension.documenttype;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeService.DocumentTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DocumentTypeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    DocumentTypeDto, DocumentTypeGetManyResponseDto, DocumentTypeClient> {

  @Inject
  @Getter
  protected DocumentTypeClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected DocumentTypeSelectOneController() {
    super(DocumentTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
