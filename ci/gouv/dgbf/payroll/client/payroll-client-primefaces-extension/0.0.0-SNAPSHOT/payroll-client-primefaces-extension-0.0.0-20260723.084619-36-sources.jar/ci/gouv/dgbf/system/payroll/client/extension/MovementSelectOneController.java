package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.MovementClient;
import ci.gouv.dgbf.system.payroll.server.api.MovementDto;
import ci.gouv.dgbf.system.payroll.server.api.MovementService.MovementGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link MovementDto}.
 *
 * @author akm
 *
 */
@Dependent
public class MovementSelectOneController extends AbstractSelectOneIdentifiableController<
    MovementDto, MovementGetManyResponseDto, MovementClient> {

  @Getter
  @Inject
  MovementClient client;

  protected MovementSelectOneController() {
    super(MovementDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
