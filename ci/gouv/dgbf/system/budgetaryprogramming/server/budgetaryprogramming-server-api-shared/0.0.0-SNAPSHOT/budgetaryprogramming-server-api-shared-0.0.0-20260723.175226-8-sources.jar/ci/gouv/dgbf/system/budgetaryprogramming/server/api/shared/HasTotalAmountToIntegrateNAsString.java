package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateNAsString {

  /**
   * Obtient le montant total à intégrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant total à intégrer pour l'année N sous forme de chaîne de caractères
   */
  String getTotalAmountToIntegrateNAsString();

  /**
   * Définit le montant total à intégrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @param totalAmountToIntegrateNAsString le montant total à intégrer pour l'année N sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToIntegrateNAsString(String totalAmountToIntegrateNAsString);

  /**
   * Identifiant java du montant total à intégrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N_AS_STRING =
      "totalAmountToIntegrateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName