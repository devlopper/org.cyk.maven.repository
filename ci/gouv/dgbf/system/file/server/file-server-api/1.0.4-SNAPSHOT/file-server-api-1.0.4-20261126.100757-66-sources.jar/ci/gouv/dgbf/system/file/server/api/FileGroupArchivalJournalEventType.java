package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Types d'événements du journal d'Archivage d'un fichier de groupe.
 */
@Getter
public enum FileGroupArchivalJournalEventType {

  /** Création d'une demande d'Archivage ou de Retrait. */
  SOLICITATION_CREATION(FileGroupArchivalJournalEventTypeCode.SOLICITATION_CREATION,
      "Création de la demande"),
  /** Acceptation d'une demande. */
  ACCEPTANCE(FileGroupArchivalJournalEventTypeCode.ACCEPTANCE, "Acceptation"),
  /** Refus d'une demande. */
  REFUSAL(FileGroupArchivalJournalEventTypeCode.REFUSAL, "Refus"),
  /** Annulation d'une demande par son créateur. */
  CANCELLATION(FileGroupArchivalJournalEventTypeCode.CANCELLATION, "Annulation"),
  /** Correction d'une information déclarative existante. */
  INFORMATION_CORRECTION(FileGroupArchivalJournalEventTypeCode.INFORMATION_CORRECTION,
      "Correction d'une information"),
  /** Archivage direct, sans demande. */
  DIRECT_ARCHIVING(FileGroupArchivalJournalEventTypeCode.DIRECT_ARCHIVING, "Archivage direct"),
  /** Désarchivage direct, sans demande. */
  DIRECT_UNARCHIVING(FileGroupArchivalJournalEventTypeCode.DIRECT_UNARCHIVING,
      "Désarchivage direct"),
  /** Suppression autorisée du rattachement et de son historique métier. */
  ATTACHMENT_DELETION(FileGroupArchivalJournalEventTypeCode.ATTACHMENT_DELETION,
      "Suppression du rattachement");

  private final String code;
  private final String name;

  private FileGroupArchivalJournalEventType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Obtient le type correspondant au code stocké.
   *
   * @param code code du type
   * @return type correspondant
   */
  public static FileGroupArchivalJournalEventType getByCode(String code) {
    return Stream.of(values()).filter(type -> type.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
