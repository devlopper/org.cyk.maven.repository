package ci.gouv.dgbf.system.file.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de groupe de fichiers.
 *
 * @author Christian
 */
public interface HasFilesGroupAsStringDto extends HasFilesGroupAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères du groupe de fichiers.
   */
  String JSON_FILES_GROUP_AS_STRING = "groupeFichiersChaine";
}
