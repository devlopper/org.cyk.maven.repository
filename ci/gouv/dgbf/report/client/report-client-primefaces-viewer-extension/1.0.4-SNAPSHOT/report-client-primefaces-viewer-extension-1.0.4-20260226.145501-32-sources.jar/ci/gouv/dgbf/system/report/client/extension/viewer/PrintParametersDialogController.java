package ci.gouv.dgbf.system.report.client.extension.viewer;

import ci.gouv.dgbf.extension.core.StringHelper;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Dialog;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur du dialogue de paramètres d'impression de rapport.
 *
 * @author Christian
 *
 */
@Dependent
public class PrintParametersDialogController extends AbstractController {

  @Getter
  @Setter
  Dialog dialog;
  
  @Getter
  @Setter
  String reportIdentifier;
  
  @Getter
  @Setter
  String fileType;

  @Getter
  @Setter
  List<SelectItem> fileTypeChoices;

  @Getter
  @Setter
  Map<String, Boolean> booleanMap;

  @Getter
  @Setter
  Map<String, String> booleanMapIdentifiers;

  @Getter
  @Setter
  Map<String, List<SelectItem>> booleanMapChoices;

  @Setter
  Consumer<ViewerOpener> viewerOpenerConsumer;

  @Getter
  @Setter
  String booleanValueShowGraphicIdentifier;

  @Inject
  StringHelper stringHelper;

  /**
   * Cette méthode permet de construire une instance.
   */
  public PrintParametersDialogController() {
    name = "Paramètres d'édition";
    dialog = new Dialog();
    dialog.setHeader(name);
    
    fileTypeChoices = new ArrayList<>();
    fileTypeChoices.addAll(List.of(new SelectItem("pdf", "Pdf"), new SelectItem("xls", "Excel"),
        new SelectItem("docx", "Word")));

    booleanValueShowGraphicIdentifier = "showGrpahic";
  }

  /**
   * Cette méthode permet d'ouvrir la vue du rapport.
   *
   */
  public void open() {
    if (viewerOpenerConsumer == null) {
      throw new IllegalStateException(
          "Le consommateur de l'ouvreur du visualisateur ne doit pas être null");
    }
    ViewerOpener opener = new ViewerOpener();
    opener.scriptBuilder().uriBuilder().reportIdentifier(reportIdentifier);
    opener.scriptBuilder().uriBuilder().fileType(fileType);
    addBooleanMapIdentifiersQueryParameters(opener);
    opener.scriptBuilder().uriBuilder().auditWho(userIdentifier);
    viewerOpenerConsumer.accept(opener);
    opener.open();
  }

  void addBooleanMapIdentifiersQueryParameters(ViewerOpener opener) {
    if (booleanMapIdentifiers != null) {
      booleanMapIdentifiers.entrySet().stream()
          .filter(entry -> isBooleanMapContains(entry.getKey()))
          .forEach(entry -> opener.scriptBuilder().uriBuilder().reportParametersAsJsonBuilder()
              .map().add(entry.getValue(), Boolean.toString(isBooleanValueTrue(entry.getValue()))));
    }
  }

  boolean isBooleanMapContains(String key) {
    if (booleanMap == null) {
      return false;
    }
    return booleanMap.containsKey(key);
  }

  /**
   * Cette méthode permet d'assigner des choix.
   *
   * @param identifier identifiant
   * @param defaultValue valeur par défaut
   * @param choices choix
   * @return this
   */
  public PrintParametersDialogController putBooleanValue(String identifier, boolean defaultValue,
      List<SelectItem> choices) {
    booleanMap().put(identifier, defaultValue);
    booleanMapChoices().put(identifier, choices);
    return this;
  }

  Map<String, Boolean> booleanMap() {
    if (booleanMap == null) {
      booleanMap = new LinkedHashMap<>();
    }
    return booleanMap;
  }

  Map<String, List<SelectItem>> booleanMapChoices() {
    if (booleanMapChoices == null) {
      booleanMapChoices = new LinkedHashMap<>();
    }
    return booleanMapChoices;
  }

  Map<String, String> booleanMapIdentifiers() {
    if (booleanMapIdentifiers == null) {
      booleanMapIdentifiers = new HashMap<>();
    }
    return booleanMapIdentifiers;
  }

  /**
   * Cette méthode permet de savoir si un boolean est vrai.
   *
   * @param identifier identifiant
   * @return vrai ou faux
   */
  public boolean isBooleanValueTrue(String identifier) {
    if (booleanMap == null) {
      return false;
    }
    /*
     * La valeur est de type chaine de caractère. ce qui est étrange. La valeur sera donc deduite de
     * la chaine de caractère.
     */
    Object object = booleanMap.get(identifier);
    if (object == null) {
      return false;
    }
    return Boolean.TRUE.equals(Boolean.valueOf(object.toString()));
  }

  /**
   * Cette méthode permet d'assigner les choix d'affichage de graphique.
   *
   * @return this
   */
  public PrintParametersDialogController putBooleanValueShowGraphic() {
    putBooleanValueByIdentifier(booleanValueShowGraphicIdentifier,
        List.of(new SelectItem(true, "Editer avec le graphe"),
            new SelectItem(false, "Editer sans le graphe")),
        "afficherGraphique");
    return this;
  }

  void putBooleanValueByIdentifier(String identifier, List<SelectItem> items,
      String defaultIdentifierValue) {
    if (!isBooleanMapContains(identifier)) {
      putBooleanValue(identifier, true, items);
    }
    if (!isBooleanMapIdentifiersContains(identifier)) {
      booleanMapIdentifiers().put(identifier,
          stringHelper.defaultToIfBlank(identifier, defaultIdentifierValue));
    }
  }

  boolean isBooleanMapIdentifiersContains(String key) {
    if (booleanMapIdentifiers == null) {
      return false;
    }
    return booleanMapIdentifiers.containsKey(key);
  }
}
