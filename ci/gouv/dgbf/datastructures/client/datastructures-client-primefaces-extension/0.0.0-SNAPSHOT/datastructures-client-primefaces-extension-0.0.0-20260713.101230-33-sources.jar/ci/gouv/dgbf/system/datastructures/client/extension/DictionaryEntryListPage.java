package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Named
@ViewScoped
public class DictionaryEntryListPage extends AbstractDictionaryEntryListPage {

  @Override
  protected void postConstruct() {
    super.postConstruct();
  }

  public static final String OUTCOME = "dictionaryEntryListPage";
}
