package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.ClassCore;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import java.util.function.Consumer;
import java.util.function.Predicate;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un accesseur de filtre.
 *
 * @author Christian
 *
 */
public class IdentifiableFilterGetter<T extends AbstractIdentifiableFilter> {

  Class<T> clazz;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  Consumer<T> onBlankIdentifier;

  @Setter
  @Accessors(chain = true, fluent = true)
  Predicate<T> isFilterBlank;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  Consumer<T> onFilterPresent;
  
  @Setter
  @Accessors(chain = true, fluent = true)
  ViewParameterValueGetter viewParameterValueGetter;

  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  String connectedUserSharedSelectionPageOutcome;

  /**
   * Cette méthode permet de construire.
   *
   * @param clazz classe
   */
  public IdentifiableFilterGetter(Class<T> clazz) {
    this.clazz = clazz;
    isFilterBlank = isFilterBlank();
    viewParameterValueGetter = viewParameterValueGetter();
  }

  /**
   * Cette méthode permet d'obtenir {@link #isFilterBlank} non nul.
   *
   * @return {@link #isFilterBlank} non nul
   */
  public Predicate<T> isFilterBlank() {
    if (isFilterBlank == null) {
      isFilterBlank = filter -> StringCore.isBlank(filter.getIdentifier());
    }
    return isFilterBlank;
  }
  
  public IdentifiableFilterGetter<T> isFilterBlankAnd(Predicate<T> predicate) {
    isFilterBlank = isFilterBlank().and(predicate);
    return this;
  }
  
  /**
   * Cette méthode permet d'obtenir {@link ViewParameterValueGetter} non nul.
   *
   * @return {@link ViewParameterValueGetter} non nul
   */
  public ViewParameterValueGetter viewParameterValueGetter() {
    if (viewParameterValueGetter == null) {
      viewParameterValueGetter = new ViewParameterValueGetter().requestParameterNameIsIdentifier();
    }
    return viewParameterValueGetter;
  }

  public IdentifiableFilterGetter<T> viewParameterValueGetterAuthorized(Boolean authorized) {
    viewParameterValueGetter().authorized(authorized);
    return this;
  }

  /**
   * Cette méthode permet d'obtenir T.
   *
   * @return T
   */
  public T get() {
    String identifier = getIdentifier();
    T filter = instantiateFilter(identifier);
    filter = validateFilter(filter);
    if (filter != null) {
      Core.acceptConsumer(onFilterPresent, filter);
    }
    return filter;
  }

  String getIdentifier() {
    Core.doThrowIfNull(IllegalArgumentException.class, "Accesseur <<valeur identifiant>> requis",
        viewParameterValueGetter);
    return viewParameterValueGetter.get();
  }

  T instantiateFilter(String identifier) {
    T filter = ClassCore.instantiate(clazz, null, null);
    if (StringCore.isBlank(identifier)) {
      Core.acceptConsumer(onBlankIdentifier, filter);
    } else {
      filter.setIdentifier(identifier);
    }
    return filter;
  }

  T validateFilter(T filter) {
    Core.doThrowIfNull(IllegalArgumentException.class,
        "Fonction <<détection de filtre blanc>> requise", isFilterBlank);
    /*
     * Si le filtre est blanc, c'est à dire aucun critère, alors on redirige vers la page de
     * sélection assigné à l'utilisateur connecté
     */
    if (Boolean.TRUE.equals(isFilterBlank.test(filter))) {
      String url = JsfCore.buildRelativeUrlFromCurrentRequest();
      SessionCore.setAttributeRedirectUrl(url);
      new Navigator().outcome(connectedUserSharedSelectionPageOutcome).dispatch(true).navigate();
      filter = null;
    }
    return filter;
  }
}
