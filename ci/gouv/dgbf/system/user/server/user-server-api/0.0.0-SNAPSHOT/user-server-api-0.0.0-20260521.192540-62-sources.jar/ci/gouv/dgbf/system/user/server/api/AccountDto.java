package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un compte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AccountDto extends AbstractIdentifiableNamableDto {

  /**
   * Identifiant de {@link UserDto}.
   */
  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;
  
  /**
   * Identifiant de {@link DomainDto}.
   */
  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link DomainDto}.
   */
  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;
  
  /**
   * Passe.
   */
  @JsonbProperty(JSON_PASS)
  private String pass;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCompte";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "compteChaine";

  /**
   * Identifiant champ java {@link #userIdentifier}.
   */
  public static final String JSON_USER_IDENTIFIER = UserDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant champ java {@link #domainIdentifier}.
   */
  public static final String JSON_DOMAIN_IDENTIFIER = DomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #domainAsString}.
   */
  public static final String JSON_DOMAIN_AS_STRING = DomainDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant champ java {@link #pass}.
   */
  public static final String JSON_PASS = "passe";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "compte";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
