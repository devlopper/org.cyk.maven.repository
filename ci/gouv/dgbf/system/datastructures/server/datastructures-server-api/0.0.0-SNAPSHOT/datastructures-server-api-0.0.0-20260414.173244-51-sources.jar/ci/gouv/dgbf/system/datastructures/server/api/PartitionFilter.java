package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStringValueData;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PartitionDto}.
 *
 * @author Arnaud
 */
@Getter
@Setter
public class PartitionFilter extends AbstractIdentifiableFilter
    implements FilterHasStringValueData, FilterHasTypeCode {

  private String typeCode;

  private String valueData;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PartitionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PartitionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeCode(filter);
    updateValueData(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeCode(filter);
    updateFilterValueData(filter);
  }
  
}
