package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.Core.ConcatenateArguments;
import ci.gouv.dgbf.extension.core.NonBlankStringList;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifier;
import ci.gouv.dgbf.extension.core.segregation.IdentifiableByString;
import ci.gouv.dgbf.extension.primefaces.AutoUpdate;
import ci.gouv.dgbf.extension.primefaces.Form;
import ci.gouv.dgbf.extension.primefaces.Style;
import ci.gouv.dgbf.extension.primefaces.segregation.Componentable;
import ci.gouv.dgbf.extension.primefaces.segregation.Widgetable;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente la base des composants.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractWidget
    implements Widgetable, Componentable, IdentifiableByString, HasIdentifier {

  Form form;

  String identifier;

  String completeIdentifier;

  protected String widgetVar;

  String templateFilePath;

  protected String contentFilePath;

  String styleClass;

  String style;

  String onClick;

  boolean rendered;

  AutoUpdate autoUpdate;

  protected AbstractWidget() {
    identifier = generateIdentifier();
    widgetVar = generateIdentifier();
    rendered = true;
  }

  /**
   * Cette méthode permet d'ajouter des classes de styles.
   *
   * @param stylesClasses classes de styles
   * @return this
   */
  public AbstractWidget addStylesClasses(List<String> stylesClasses) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(styleClass).add(stylesClasses);
    styleClass = Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(" "));
    return this;
  }

  public AbstractWidget addStylesClasses(String... stylesClasses) {
    return addStylesClasses(
        Arrays.stream(Optional.ofNullable(stylesClasses).orElse(new String[] {})).toList());
  }

  public AbstractWidget addStyleClass(String styleClass) {
    return addStylesClasses(styleClass);
  }

  /**
   * Cette méthode permet d'ajouter des styles.
   *
   * @param styles styles
   * @return this
   */
  public AbstractWidget addStyles(List<String> styles) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(style).add(styles);
    style = Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(";"));
    return this;
  }

  public AbstractWidget addStyles(String... styles) {
    return addStyles(Arrays.stream(Optional.ofNullable(styles).orElse(new String[] {})).toList());
  }

  public AbstractWidget addStyle(String style) {
    return addStyles(style);
  }

  /**
   * Cette méthode permet d'obtenir {@link AutoUpdate}.
   *
   * @return {@link AutoUpdate}
   */
  public AutoUpdate autoUpdate() {
    if (autoUpdate == null) {
      autoUpdate = new AutoUpdate();
    }
    return autoUpdate;
  }

  /**
   * Cette classe représentente la base de constructeur.
   *
   * @author Christian
   *
   * @param <M> Type de modèle
   * @param <O> Type d'options
   * @param <B> type de constructeur de modèle
   * @param <T> Type de graphique
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public abstract static class AbstractWidgetBuilder<T extends AbstractWidget> {

    Style.Builder styleBuilder;

    /**
     * Cette méthode permet de contruire.
     *
     * @return graphique
     */
    public T build() {
      validate();
      T widget = instantiateWidget();
      processWidget(widget);
      return widget;
    }

    protected void validate() {

    }

    protected abstract T instantiateWidget();

    protected void processWidget(T widget) {
      style(widget);
    }

    void style(T widget) {
      if (styleBuilder == null) {
        return;
      }
      Style style = styleBuilder.build();
      widget.styleClass = style.getClassesAsString();
      widget.style = style.getValue();
    }

    /**
     * Cette méthode permet d'obtenir {@link Style.Builder} non nul.
     *
     * @return {@link Style.Builder} non nul
     */
    public Style.Builder styleBuilder() {
      if (styleBuilder == null) {
        styleBuilder = new Style.Builder();
      }
      return styleBuilder;
    }
  }

  /**
   * Cette méthode permet de générer un identifiant.
   *
   * @param prefix préfixe
   * @return identifiant
   */
  public static String generateIdentifier(String prefix) {
    return prefix + RANDOM.nextInt(1000, 9999);
  }
  
  /**
   * Cette méthode permet de générer un identifiant.
   *
   * @return identifiant
   */
  public static String generateIdentifier() {
    return generateIdentifier("id");
  }
  
  /**
   * Cette méthode permet de générer une variable de widget.
   *
   * @return variable de widget
   */
  public static String generateWidgetVar() {
    return generateIdentifier("wv");
  }
  
  private static final Random RANDOM = new Random();
}
