package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FundDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FundFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du groupe de caisses.
   */
  String groupIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FundFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FundFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupIdentifier = getGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupIdentifier(filter, groupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de caisses.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de caisses.
   *
   * @param filter filtre
   * @return identifiant du groupe de caisses
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link FundFilter#groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
          FundDto.JSON_GROUP_IDENTIFIER;

}
