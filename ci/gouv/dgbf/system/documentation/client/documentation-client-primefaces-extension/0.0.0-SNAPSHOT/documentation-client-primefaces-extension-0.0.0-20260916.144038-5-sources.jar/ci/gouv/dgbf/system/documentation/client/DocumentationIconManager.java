package ci.gouv.dgbf.system.documentation.client;

import ci.gouv.dgbf.extension.primefaces.AbstractIconManager;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente le gestionnaire d'icône.
 *
 * @author Christian
 *
 */
@Named
@ApplicationScoped
@Getter
public class DocumentationIconManager extends AbstractIconManager {

  String documentType;
  String documentTypesGroup;
  String documentTypeGroup;
  String documentGroup;
  String document;

  /**
   * Cette méthode permet d'instancier.
   */
  public DocumentationIconManager() {
    documentType = "pi pi-list";
    documentTypesGroup = "pi pi-folder";
    documentTypeGroup = "pi pi-sitemap";
    documentGroup = "pi pi-folder-open";
    document = "pi pi-file";
  }
}
