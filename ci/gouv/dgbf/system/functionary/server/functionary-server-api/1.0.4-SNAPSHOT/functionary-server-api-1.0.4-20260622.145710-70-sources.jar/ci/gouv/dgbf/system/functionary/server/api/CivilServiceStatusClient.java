package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusGetManyResponseDto;
import ci.gouv.dgbf.system.functionary.server.api.CivilServiceStatusService.CivilServiceStatusUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link CivilServiceStatusService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class CivilServiceStatusClient extends 
             AbstractClient<CivilServiceStatusService>
    implements GetByIdentifier<CivilServiceStatusDto>, 
               GetMany<CivilServiceStatusGetManyResponseDto>,
               DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public CivilServiceStatusClient service(CivilServiceStatusService service) {
    return (CivilServiceStatusClient) super.service(service);
  }


  /**
   * {@link CivilServiceStatusService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetOneExecutor<>(Long.class, 
        CivilServiceStatusService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link CivilServiceStatusService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(CivilServiceStatusCreateRequestDto request) {
    return new CreateExecutor(CivilServiceStatusService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link CivilServiceStatusService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public CivilServiceStatusGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<CivilServiceStatusGetManyResponseDto>(
           CivilServiceStatusGetManyResponseDto.class,
        CivilServiceStatusService.GET_MANY_IDENTIFIER).execute(() -> service()
          .getMany(request));
  }

  /**
   * {@link CivilServiceStatusService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public CivilServiceStatusGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link CivilServiceStatusService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public CivilServiceStatusDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<CivilServiceStatusDto>(CivilServiceStatusDto.class,
        CivilServiceStatusService.GET_ONE_IDENTIFIER).execute(() -> 
        service().getOne(request));
  }

  /**
   * {@link CivilServiceStatusService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CivilServiceStatusDto getOne(ProjectionDto projection, 
                            FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link CivilServiceStatusService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public CivilServiceStatusDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<CivilServiceStatusDto>(CivilServiceStatusDto.class,
        CivilServiceStatusService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link CivilServiceStatusService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public CivilServiceStatusDto getByIdentifier(String identifier, 
          ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link CivilServiceStatusService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(CivilServiceStatusUpdateRequestDto request) {
    return new IdentifiableExecutor(CivilServiceStatusService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link CivilServiceStatusService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(CivilServiceStatusService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link CivilServiceStatusService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
