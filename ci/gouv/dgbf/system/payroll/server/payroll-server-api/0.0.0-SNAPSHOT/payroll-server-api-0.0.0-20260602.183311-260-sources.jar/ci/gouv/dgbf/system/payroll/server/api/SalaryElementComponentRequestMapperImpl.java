package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SalaryElementComponentDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T18:33:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SalaryElementComponentRequestMapperImpl implements SalaryElementComponentRequestMapper {

    @Override
    public SalaryElementComponentService.SalaryElementComponentCreateRequestDto mapCreate(SalaryElementComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementComponentService.SalaryElementComponentCreateRequestDto salaryElementComponentCreateRequestDto = new SalaryElementComponentService.SalaryElementComponentCreateRequestDto();

        salaryElementComponentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        salaryElementComponentCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        salaryElementComponentCreateRequestDto.setSalaryElementIdentifier( arg0.getSalaryElementIdentifier() );
        salaryElementComponentCreateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        salaryElementComponentCreateRequestDto.setEmployeeRate( arg0.getEmployeeRate() );
        salaryElementComponentCreateRequestDto.setEmployerRate( arg0.getEmployerRate() );
        salaryElementComponentCreateRequestDto.setFloor( arg0.getFloor() );
        salaryElementComponentCreateRequestDto.setCap( arg0.getCap() );

        return salaryElementComponentCreateRequestDto;
    }

    @Override
    public SalaryElementComponentService.SalaryElementComponentUpdateRequestDto mapUpdate(SalaryElementComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementComponentService.SalaryElementComponentUpdateRequestDto salaryElementComponentUpdateRequestDto = new SalaryElementComponentService.SalaryElementComponentUpdateRequestDto();

        salaryElementComponentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        salaryElementComponentUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        salaryElementComponentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        salaryElementComponentUpdateRequestDto.setSalaryElementIdentifier( arg0.getSalaryElementIdentifier() );
        salaryElementComponentUpdateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        salaryElementComponentUpdateRequestDto.setEmployeeRate( arg0.getEmployeeRate() );
        salaryElementComponentUpdateRequestDto.setEmployerRate( arg0.getEmployerRate() );
        salaryElementComponentUpdateRequestDto.setFloor( arg0.getFloor() );
        salaryElementComponentUpdateRequestDto.setCap( arg0.getCap() );

        return salaryElementComponentUpdateRequestDto;
    }
}
