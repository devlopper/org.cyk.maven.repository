package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasBodyHtmlDto;
import ci.gouv.dgbf.extension.core.segregation.HasBodyTextDto;
import ci.gouv.dgbf.extension.core.segregation.HasCodeDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsRenderedAsHtmlDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link MailLayoutDto}.
 *
 * @author Christian
 */
@Path(value = MailLayoutService.PATH)
@Tag(name = "Gestion des gabarits de mail")
public interface MailLayoutService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "gabarits-mail";

  /**
   * Cette interface représente une requête de sauvegarde (création ou mise à jour).
   */
  interface MailLayoutSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le corps HTML.
     *
     * @return corps HTML
     */
    String getBodyHtml();

    /**
     * Cette méthode permet d'assigner le corps HTML.
     *
     * @param bodyHtml corps HTML
     */
    void setBodyHtml(String bodyHtml);

    /**
     * Cette méthode permet d'obtenir le corps texte.
     *
     * @return corps texte
     */
    String getBodyText();

    /**
     * Cette méthode permet d'assigner le corps texte.
     *
     * @param bodyText corps texte
     */
    void setBodyText(String bodyText);

    /**
     * Cette méthode permet d'obtenir si le gabarit est par défaut.
     *
     * @return vrai si par défaut
     */
    Boolean getIsDefault();

    /**
     * Cette méthode permet d'assigner si le gabarit est par défaut.
     *
     * @param isDefault vrai si par défaut
     */
    void setIsDefault(Boolean isDefault);
  }

  /**
   * Identifiant de création.
   */
  String CREATE_IDENTIFIER = "CREATION_GABARIT_MAIL";

  /**
   * Chemin de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer un gabarit.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MailLayoutCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link MailLayoutDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class MailLayoutCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements MailLayoutSaveRequestDto {

    @JsonbProperty(JSON_BODY_HTML)
    private String bodyHtml;

    @JsonbProperty(JSON_BODY_TEXT)
    private String bodyText;

    @JsonbProperty(JSON_IS_DEFAULT)
    private Boolean isDefault;

    public static final String JSON_BODY_HTML = HasBodyHtmlDto.JSON_BODY_HTML;
    public static final String JSON_BODY_TEXT = HasBodyTextDto.JSON_BODY_TEXT;
    public static final String JSON_IS_DEFAULT = MailLayoutDto.JSON_IS_DEFAULT;
  }

  /**
   * Identifiant d'obtention de plusieurs gabarits.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GABARIT_MAIL";

  /**
   * Chemin d'obtention de plusieurs gabarits.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs gabarits.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MailLayoutGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse de récupération de plusieurs gabarits.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class MailLayoutGetManyResponseDto extends AbstractGetByPageResponseDto<MailLayoutDto> {

    @JsonbProperty(JSON_DATAS)
    private List<MailLayoutDto> datas;
  }

  /**
   * Identifiant d'obtention d'un gabarit.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GABARIT_MAIL";

  /**
   * Chemin d'obtention d'un gabarit.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un gabarit.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MailLayoutDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GABARIT_MAIL";

  /**
   * Chemin d'obtention par identifiant.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir un gabarit par identifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = MailLayoutDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant de l'opération d'obtention de l'aperçu du corps.
   */
  String GET_BODY_PREVIEW_IDENTIFIER = "OBTENTION_APERÇU_CORPS_GABARIT_MAIL";

  /**
   * Chemin d'obtention de l'aperçu du corps.
   */
  String GET_BODY_PREVIEW_PATH = "apercu-corps";

  /**
   * Cette méthode permet d'obtenir l'aperçu du corps d'un gabarit.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BODY_PREVIEW_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces({MediaType.TEXT_HTML, MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_BODY_PREVIEW_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.TEXT_HTML),
      @Content(mediaType = MediaType.TEXT_PLAIN)})
  Response getBodyPreview(MailLayoutGetBodyPreviewRequestDto request);

  /**
   * Cette classe représente la requête d'obtention de l'aperçu du corps.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class MailLayoutGetBodyPreviewRequestDto extends ByIdentifierRequestDto
      implements HasCodeDto, HasIsRenderedAsHtmlDto {

    @JsonbProperty(JSON_CODE)
    private String code;

    @JsonbProperty(JSON_IS_RENDERED_AS_HTML)
    private Boolean isRenderedAsHtml;

    @JsonbProperty(JSON_SAMPLE_CONTENT)
    private String sampleContent;

    public static final String JSON_CODE = HasCodeDto.JSON_CODE;
    public static final String JSON_IS_RENDERED_AS_HTML =
        HasIsRenderedAsHtmlDto.JSON_IS_RENDERED_AS_HTML;
    public static final String JSON_SAMPLE_CONTENT = "contenuExemple";
  }

  /**
   * Identifiant de modification.
   */
  String UPDATE_IDENTIFIER = "MODIFICATION_GABARIT_MAIL";

  /**
   * Chemin de modification.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour un gabarit.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(MailLayoutUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link MailLayoutDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class MailLayoutUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements MailLayoutSaveRequestDto {

    @JsonbProperty(JSON_BODY_HTML)
    private String bodyHtml;

    @JsonbProperty(JSON_BODY_TEXT)
    private String bodyText;

    @JsonbProperty(JSON_IS_DEFAULT)
    private Boolean isDefault;

    public static final String JSON_BODY_HTML = HasBodyHtmlDto.JSON_BODY_HTML;
    public static final String JSON_BODY_TEXT = HasBodyTextDto.JSON_BODY_TEXT;
    public static final String JSON_IS_DEFAULT = MailLayoutDto.JSON_IS_DEFAULT;
  }

  /**
   * Identifiant de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GABARIT_MAIL";

  /**
   * Chemin de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer un gabarit.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
