package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente l'objet de transfert de donnée des groupes de matricules.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RegistrationNumberGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Motif de matricule.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER_PATTERN)
  private String registrationNumberPattern;


  /**
   * Identifiant json champ {@link #registrationNumberPattern}.
   */
  public static final String JSON_REGISTRATION_NUMBER_PATTERN = "motifMatricule";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe de matricule";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de matricule";
}
