package ci.gouv.dgbf.system.budgetaryclassification.server.api;

/**
 * Cette classe représente les codes de {@link ActCategoryGroup}.
 *
 * @author AKM
 *
 */
public class ActCategoryGroupCode {

  private ActCategoryGroupCode() {

  }

  /**
   * Intégration de ressources .
   */
  public static final String RESOURCE_INTEGRATION = "INTEGRATION_RESSOURCE";

  /**
   * Répartition de crédits.
   */
  public static final String CREDIT_DISTRIBUTION = "REPARTITION_CREDIT";

  /**
   * Répartition de ressources.
   */
  public static final String RESOURCE_DISTRIBUTION = "REPARTITION_RESSOURCE";
}
