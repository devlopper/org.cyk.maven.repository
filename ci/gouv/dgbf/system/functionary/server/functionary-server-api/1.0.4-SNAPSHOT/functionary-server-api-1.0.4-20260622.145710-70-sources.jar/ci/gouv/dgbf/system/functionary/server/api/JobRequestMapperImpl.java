package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link JobDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class JobRequestMapperImpl implements JobRequestMapper {

    @Override
    public JobService.JobCreateRequestDto mapCreate(JobDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobService.JobCreateRequestDto jobCreateRequestDto = new JobService.JobCreateRequestDto();

        jobCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobCreateRequestDto.setCode( arg0.getCode() );
        jobCreateRequestDto.setName( arg0.getName() );
        jobCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        jobCreateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );

        return jobCreateRequestDto;
    }

    @Override
    public JobService.JobUpdateRequestDto mapUpdate(JobDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        JobService.JobUpdateRequestDto jobUpdateRequestDto = new JobService.JobUpdateRequestDto();

        jobUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        jobUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        jobUpdateRequestDto.setCode( arg0.getCode() );
        jobUpdateRequestDto.setName( arg0.getName() );
        jobUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        jobUpdateRequestDto.setGradeIdentifier( arg0.getGradeIdentifier() );

        return jobUpdateRequestDto;
    }
}
