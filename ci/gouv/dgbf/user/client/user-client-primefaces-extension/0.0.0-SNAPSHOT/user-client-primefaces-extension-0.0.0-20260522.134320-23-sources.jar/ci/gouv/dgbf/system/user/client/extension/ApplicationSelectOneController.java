package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.ApplicationClient;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.DomainDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link DomainDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class ApplicationSelectOneController extends AbstractSelectOneIdentifiableController<
    ApplicationDto, ApplicationGetManyResponseDto, ApplicationClient> {

  @Getter
  @Inject
  ApplicationClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected ApplicationSelectOneController() {
    super(ApplicationDto.class, SelectItemLabelStrategy.NAME);
  }
}
