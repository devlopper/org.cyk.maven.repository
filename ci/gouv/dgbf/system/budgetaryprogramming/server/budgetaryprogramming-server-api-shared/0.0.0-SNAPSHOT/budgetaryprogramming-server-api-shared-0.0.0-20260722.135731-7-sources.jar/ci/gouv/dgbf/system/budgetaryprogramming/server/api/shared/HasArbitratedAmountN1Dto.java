package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasArbitratedAmountN1}.
 *
 * @author Christian
 */
public interface HasArbitratedAmountN1Dto extends HasArbitratedAmountN1 {

  /**
   * Identifiant json du montant arbitré à l'horizon N1.
   */
  String JSON_ARBITRATED_AMOUNT_N1 = "montantArbitreN1";
}
