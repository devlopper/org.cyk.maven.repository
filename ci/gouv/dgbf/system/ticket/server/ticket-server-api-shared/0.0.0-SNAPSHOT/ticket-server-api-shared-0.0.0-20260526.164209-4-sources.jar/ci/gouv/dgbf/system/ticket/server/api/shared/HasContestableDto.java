package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de peut être contesté.
 *
 * @author Christian
 */
public interface HasContestableDto extends HasContestable {

  /**
   * Identifiant json de peut être contesté.
   */
  String JSON_CONTESTABLE = "peutEtreConteste";
}