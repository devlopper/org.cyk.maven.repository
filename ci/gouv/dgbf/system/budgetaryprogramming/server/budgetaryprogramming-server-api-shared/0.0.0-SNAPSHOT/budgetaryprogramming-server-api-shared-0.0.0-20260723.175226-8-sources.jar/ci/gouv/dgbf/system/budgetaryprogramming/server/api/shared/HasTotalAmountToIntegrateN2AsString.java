package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToIntegrateN2AsString {

  /**
   * Obtient le montant total à intégrer pour l'année N+2 sous forme de chaîne de caractères.
   *
   * @return le montant total à intégrer pour l'année N+2 sous forme de chaîne de caractères
   */
  String getTotalAmountToIntegrateN2AsString();

  /**
   * Définit le montant total à intégrer pour l'année N+2 sous forme de chaîne de caractères.
   *
   * @param totalAmountToIntegrateN2AsString le montant total à intégrer pour l'année N+2
   *        sous forme de chaîne de caractères
   */
  void setTotalAmountToIntegrateN2AsString(String totalAmountToIntegrateN2AsString);

  /**
   * Identifiant java du montant total à intégrer pour l'année N+2 sous forme de chaîne.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N2_AS_STRING =
      "totalAmountToIntegrateN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName