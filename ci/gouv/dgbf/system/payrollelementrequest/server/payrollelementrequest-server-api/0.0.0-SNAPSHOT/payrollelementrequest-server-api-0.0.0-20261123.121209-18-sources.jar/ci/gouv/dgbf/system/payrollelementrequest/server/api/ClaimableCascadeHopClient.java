package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeHopService.ClaimableCascadeHopCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeHopService.ClaimableCascadeHopGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimableCascadeHopService.ClaimableCascadeHopUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimableCascadeHopService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimableCascadeHopClient extends AbstractClient<ClaimableCascadeHopService>
    implements GetByIdentifier<ClaimableCascadeHopDto>,
    GetMany<ClaimableCascadeHopGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimableCascadeHopClient service(ClaimableCascadeHopService service) {
    return (ClaimableCascadeHopClient) super.service(service);
  }

  /**
   * {@link ClaimableCascadeHopService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableCascadeHopGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeHopGetManyResponseDto>(
        ClaimableCascadeHopGetManyResponseDto.class, ClaimableCascadeHopService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimableCascadeHopService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableCascadeHopGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimableCascadeHopService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimableCascadeHopCreateRequestDto request) {
    return new CreateExecutor(ClaimableCascadeHopService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimableCascadeHopService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimableCascadeHopUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimableCascadeHopService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimableCascadeHopService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimableCascadeHopDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeHopDto>(ClaimableCascadeHopDto.class,
        ClaimableCascadeHopService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimableCascadeHopService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimableCascadeHopDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimableCascadeHopService#getByIdentifier}.
   *
   * @param request requête
   * @return saut de cascade de réclamable
   */
  public ClaimableCascadeHopDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimableCascadeHopDto>(ClaimableCascadeHopDto.class,
        ClaimableCascadeHopService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimableCascadeHopService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimableCascadeHopDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimableCascadeHopService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimableCascadeHopService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimableCascadeHopService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
