package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Dossier confié à une équipe d'arbitrage.
 *
 * <p>C'est cette table qui donne son effet à l'équipe : un agent ne voit, sur ses écrans, que
 * les dossiers qui y figurent pour son équipe. Sans elle, l'équipe ne serait qu'un annuaire.</p>
 *
 * <p><strong>Un dossier ne va qu'à une équipe à la fois.</strong> La base autorise le contraire
 * — sa clé unique porte sur le couple — mais le métier, non : deux équipes sur un même dossier,
 * ce sont deux chefs qui peuvent en valider le traitement, et le premier arrivé décide pour
 * l'autre. Le service le refuse donc, et dit laquelle le détient déjà.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ArbitrationTeamDossierDto extends AbstractIdentifiableDto {

  /**
   * Équipe à laquelle le dossier est confié.
   */
  @JsonbProperty(JSON_TEAM_IDENTIFIER)
  private String teamIdentifier;

  /**
   * Libellé de l'équipe, alimenté par jointure.
   */
  @JsonbProperty(JSON_TEAM_AS_STRING)
  private String teamAsString;

  /**
   * Dossier de masse salariale confié.
   */
  @JsonbProperty(JSON_DOSSIER_IDENTIFIER)
  private String dossierIdentifier;

  /**
   * Libellé du dossier, alimenté par jointure.
   */
  @JsonbProperty(JSON_DOSSIER_AS_STRING)
  private String dossierAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDossierEquipe";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "dossierEquipeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "dossier d'équipe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "dossiers d'équipe";

  /**
   * Identifiant json pour {@link #teamIdentifier}.
   */
  public static final String JSON_TEAM_IDENTIFIER = ArbitrationTeamMemberDto.JSON_TEAM_IDENTIFIER;

  /**
   * Identifiant json pour {@link #teamAsString}.
   */
  public static final String JSON_TEAM_AS_STRING = ArbitrationTeamDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #dossierIdentifier}.
   */
  public static final String JSON_DOSSIER_IDENTIFIER =
      BudgetAdministrativeUnitDossierDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #dossierAsString}.
   */
  public static final String JSON_DOSSIER_AS_STRING =
      BudgetAdministrativeUnitDossierDto.JSON_THIS_AS_STRING;
}
