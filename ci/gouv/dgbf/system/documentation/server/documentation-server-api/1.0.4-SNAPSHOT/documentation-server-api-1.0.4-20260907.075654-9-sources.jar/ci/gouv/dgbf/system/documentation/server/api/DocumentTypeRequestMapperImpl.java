package ci.gouv.dgbf.system.documentation.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DocumentTypeDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-07T07:57:10+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DocumentTypeRequestMapperImpl implements DocumentTypeRequestMapper {

    @Override
    public DocumentTypeService.DocumentTypeCreateRequestDto mapCreate(DocumentTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeService.DocumentTypeCreateRequestDto documentTypeCreateRequestDto = new DocumentTypeService.DocumentTypeCreateRequestDto();

        documentTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeCreateRequestDto.setCode( arg0.getCode() );
        documentTypeCreateRequestDto.setName( arg0.getName() );

        return documentTypeCreateRequestDto;
    }

    @Override
    public DocumentTypeService.DocumentTypeUpdateRequestDto mapUpdate(DocumentTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DocumentTypeService.DocumentTypeUpdateRequestDto documentTypeUpdateRequestDto = new DocumentTypeService.DocumentTypeUpdateRequestDto();

        documentTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        documentTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        documentTypeUpdateRequestDto.setCode( arg0.getCode() );
        documentTypeUpdateRequestDto.setName( arg0.getName() );

        return documentTypeUpdateRequestDto;
    }
}
