package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link RoleSolicitationDto}.
 *
 * @author BoobaCool
 */
@Getter
public enum RoleSolicitationStatus {

  /**
   * {@link RoleSolicitationStatusCode#CREATED}.
   */
  CREATED(RoleSolicitationStatusCode.CREATED, "Créée", "Création", "Créer",
      "Demander un rôle"),

  /**
   * {@link RoleSolicitationStatusCode#ACCEPTED}.
   */
  ACCEPTED(RoleSolicitationStatusCode.ACCEPTED, "Acceptée", "Acceptation", "Accepter"),

  /**
   * {@link RoleSolicitationStatusCode#REFUSED}.
   */
  REFUSED(RoleSolicitationStatusCode.REFUSED, "Refusée", "Refus", "Refuser"),

  /**
   * {@link RoleSolicitationStatusCode#CANCELLED}.
   */
  CANCELLED(RoleSolicitationStatusCode.CANCELLED, "Annulée", "Annulation", "Annuler");

  private RoleSolicitationStatus(String code, String name, String actionName, String actionVerb,
      String actionLabel) {
    this.code = code;
    this.name = name;
    this.actionName = actionName;
    this.actionVerb = actionVerb;
    this.actionLabel = actionLabel;
  }

  private RoleSolicitationStatus(String code, String name, String actionName, String actionVerb) {
    this(code, name, actionName, actionVerb, actionVerb);
  }

  private String code;
  private String name;
  private String actionName;
  private String actionVerb;
  private String actionLabel;
  private Set<RoleSolicitationStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link RoleSolicitationStatus} par code.
   *
   * @param code code
   * @return {@link RoleSolicitationStatus}
   */
  public static RoleSolicitationStatus getByCode(String code) {
    return Stream.of(RoleSolicitationStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    ACCEPTED.previous = Core.getSet(List.of(CREATED));
    REFUSED.previous = Core.getSet(List.of(CREATED));
    CANCELLED.previous = Core.getSet(List.of(CREATED));
  }
}
