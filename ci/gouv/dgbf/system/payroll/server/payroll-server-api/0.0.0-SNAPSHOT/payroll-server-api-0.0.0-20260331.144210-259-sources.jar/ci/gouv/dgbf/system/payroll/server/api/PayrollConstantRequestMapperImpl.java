package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollConstantDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-31T14:42:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollConstantRequestMapperImpl implements PayrollConstantRequestMapper {

    @Override
    public PayrollConstantService.PayrollConstantCreateRequestDto mapCreate(PayrollConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollConstantService.PayrollConstantCreateRequestDto payrollConstantCreateRequestDto = new PayrollConstantService.PayrollConstantCreateRequestDto();

        payrollConstantCreateRequestDto.setCode( arg0.getCode() );
        payrollConstantCreateRequestDto.setName( arg0.getName() );

        return payrollConstantCreateRequestDto;
    }

    @Override
    public PayrollConstantService.PayrollConstantUpdateRequestDto mapUpdate(PayrollConstantDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollConstantService.PayrollConstantUpdateRequestDto payrollConstantUpdateRequestDto = new PayrollConstantService.PayrollConstantUpdateRequestDto();

        payrollConstantUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollConstantUpdateRequestDto.setCode( arg0.getCode() );
        payrollConstantUpdateRequestDto.setName( arg0.getName() );

        return payrollConstantUpdateRequestDto;
    }
}
