package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetActivityDto}.
 *
 * @author Donsylla
 */
@Getter
@Setter
public class BudgetActivityFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link BudgetDto}.
   */
  String budgetIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetActivityFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetActivityFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    budgetIdentifier = getBudgetIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setBudgetIdentifier(filter, budgetIdentifier);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link BudgetDto}.
   *
   * @param filter filtre
   * @return identifiant {@link BudgetDto}
   */
  public static String getBudgetIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_BUDGET_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link BudgetDto}.
   *
   * @param filter     filtre
   * @param identifier identifiant {@link BudgetDto}
   */
  public static void setBudgetIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_BUDGET_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Identifiant json champ {@link #budgetIdentifier}.
   */
  public static final String JSON_BUDGET_IDENTIFIER =
      BudgetActivityDto.JSON_BUDGET_IDENTIFIER;
}
