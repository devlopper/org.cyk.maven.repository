package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre cumulé d'insatisfactions
 * constatées sur des tickets (indicateur qualité).
 *
 * @author Christian
 */
public interface HasTicketDissatisfactionActionsCountDto
    extends HasTicketDissatisfactionActionsCount {

  /**
   * Identifiant json du nombre cumulé d'insatisfactions constatées sur des tickets.
   */
  String JSON_TICKET_DISSATISFACTION_ACTIONS_COUNT = "nombreActionsInsatisfactionTicket";
}
