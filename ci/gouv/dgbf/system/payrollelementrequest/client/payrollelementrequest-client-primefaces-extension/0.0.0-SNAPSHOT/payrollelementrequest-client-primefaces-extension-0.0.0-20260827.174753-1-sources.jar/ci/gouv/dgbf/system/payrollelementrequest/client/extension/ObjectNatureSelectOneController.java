package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente le contrôleur de sélection de la nature de l'objet ciblé par un Effet
 * Attendu (référentiel {@code TR_NATURE_OBJET_PAIE}, les 3 valeurs). Pour un Rattachement,
 * utiliser {@link ClaimTypeObjectNatureSelectOneController} -- un Poste ne peut pas être rattaché
 * avec un Mode de Saisie (contrainte {@code TA_TYPE_RECLAMATION_OBJET_NATURE_CK}).
 *
 * @author akm
 *
 */
@Dependent
public class ObjectNatureSelectOneController extends AbstractSelectOneController {

  protected ObjectNatureSelectOneController() {
    outputLableValue = "Nature de l'objet";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem("ELEMENT_PAIE", "Element de Paie"),
        new SelectItem("CONSTANTE_PAIE", "Constante de Paie"),
        new SelectItem("POSTE", "Poste"));
  }
}
