package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant intégré à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountNAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant intégré à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @return le montant intégré à l'horizon N, sous forme de chaîne de caractères
   */
  String getIntegratedAmountNAsString();

  /**
   * Cette méthode permet d'assigner le montant intégré à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @param amount le montant intégré à l'horizon N, sous forme de chaîne de caractères
   */
  void setIntegratedAmountNAsString(String amount);

  /**
   * Identifiant java du montant intégré à l'horizon N, sous forme de chaîne de caractères.
   */
  String FIELD_INTEGRATED_AMOUNT_N_AS_STRING = "integratedAmountNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
