package ci.gouv.dgbf.system.payrollelementrequest.server.api.shared;

/**
 * Cette interface représente une classe portant l'indicateur de disponibilité de l'action
 * Envoyer au contentieux (RG_REP_SOU_07/RG_REP_PEC_07) sur une réponse de traitement (motif
 * R44/R45).
 *
 * @author akm
 *
 */
public interface HasSendableToLitigationDto {

  /**
   * Identifiant json de {@link #getSendableToLitigation()}.
   */
  String JSON_SENDABLE_TO_LITIGATION = "envoyableAuContentieux";

  /**
   * Cette méthode permet d'obtenir l'indicateur de disponibilité de l'action Envoyer au
   * contentieux.
   *
   * @return indicateur de disponibilité de l'action Envoyer au contentieux
   */
  Boolean getSendableToLitigation();

  /**
   * Cette méthode permet d'assigner l'indicateur de disponibilité de l'action Envoyer au
   * contentieux.
   *
   * @param sendableToLitigation indicateur de disponibilité de l'action Envoyer au contentieux
   */
  void setSendableToLitigation(Boolean sendableToLitigation);
}
