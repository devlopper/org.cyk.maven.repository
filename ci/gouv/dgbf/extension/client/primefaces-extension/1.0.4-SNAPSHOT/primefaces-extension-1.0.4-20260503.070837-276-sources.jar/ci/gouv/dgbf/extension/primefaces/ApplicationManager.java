package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le gestionnaire de l'application.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ApplicationManager {

  Map<Object, String> rolesHomePagesPaths;

  @Getter
  @Setter
  String homePagePath;

  /**
   * Cette méthode permet d'instantier.
   */
  public ApplicationManager() {
    rolesHomePagesPaths = new HashMap<>();
    homePagePath = Constant.SLASH + "private/index.xhtml";
  }

  public void setRoleHomePagePath(Object role, String path) {
    rolesHomePagesPaths.put(role, path);
  }

  public void setRolesHomePagePath(Set<Object> roles, String path) {
    Optional.ofNullable(roles).orElse(Collections.emptySet())
        .forEach(role -> rolesHomePagesPaths.put(role, path));
  }

  public void setRolesHomePagePath(String path, Object... roles) {
    setRolesHomePagePath(roles == null ? null : Arrays.stream(roles).collect(Collectors.toSet()),
        path);
  }

  public String getRoleHomePagePath(Object role) {
    return Optional.ofNullable(rolesHomePagesPaths.get(role)).orElse(homePagePath);
  }

  public String getRoleHomePagePathByCode(String roleCode) {
    return Optional.ofNullable(rolesHomePagesPaths.get(getRoleByCode(roleCode)))
        .orElse(homePagePath);
  }

  Object getRoleByCode(String code) {
    for (Object role : rolesHomePagesPaths.keySet()) {
      if (code.equals(getRoleCode(role))) {
        return role;
      }
    }
    return null;
  }

  String getRoleCode(Object role) {
    if (role instanceof CodableByStringWithGetterOnly codable) {
      return codable.getCode();
    }
    return null;
  }

  public Set<String> getRolesCodes() {
    return rolesHomePagesPaths.keySet().stream().map(this::getRoleCode).collect(Collectors.toSet());
  }

  /**
   * Cette méthode permet d'obtenir le chemin de la page d'accueil.
   *
   * @param rolesCodes codes des rôles
   * @return chemin de la page d'accueil
   */
  public String getRoleHomePagePathOrHomePagePath(Set<String> rolesCodes) {
    for (String roleCode : getRolesCodes()) {
      if (Core.isCollectionContains(rolesCodes, roleCode)) {
        return getRoleHomePagePathByCode(roleCode);
      }
    }
    return homePagePath;
  }
}
