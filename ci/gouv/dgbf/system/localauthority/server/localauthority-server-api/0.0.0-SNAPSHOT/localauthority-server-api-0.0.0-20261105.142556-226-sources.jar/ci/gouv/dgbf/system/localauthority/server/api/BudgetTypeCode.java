package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette classe représente le code de {@link BudgetType}.
 *
 * @author Donsylla
 *
 */
public class BudgetTypeCode {

  private BudgetTypeCode() {

  }

  /**
   * Primitif.
   */
  public static final String INITIAL = "PRIMITIF";
}
