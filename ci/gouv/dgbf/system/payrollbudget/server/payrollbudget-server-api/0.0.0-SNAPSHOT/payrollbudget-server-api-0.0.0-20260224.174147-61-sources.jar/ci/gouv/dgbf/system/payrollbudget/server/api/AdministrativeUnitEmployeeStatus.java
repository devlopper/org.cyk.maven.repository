package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum AdministrativeUnitEmployeeStatus {

  /**
   * Entrant.
   */
  INCOMING(AdministrativeUnitEmployeeStatusCode.INCOMING, "Entrant"),

  /**
   * Présent.
   */
  PRESENT(AdministrativeUnitEmployeeStatusCode.PRESENT, "Présent"),

  /**
   * Sortant.
   */
  OUTGOING(AdministrativeUnitEmployeeStatusCode.OUTGOING, "Sortant")

  ;

  private AdministrativeUnitEmployeeStatus(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;
  private Set<AdministrativeUnitEmployeeStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link AdministrativeUnitEmployeeStatus} par code.
   *
   * @param code code
   * @return statut
   */
  public static AdministrativeUnitEmployeeStatus getByCode(String code) {
    return Stream.of(AdministrativeUnitEmployeeStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    INCOMING.previous = Collections.emptySet();
    PRESENT.previous = Core.getSet(List.of(OUTGOING));
    OUTGOING.previous = Core.getSet(List.of(PRESENT));
  }
}
