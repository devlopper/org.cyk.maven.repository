package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link TokenDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum TokenStatus {

  /**
   * #{@link TokenStatusCode#ISSUED}.
   */
  ISSUED(TokenStatusCode.ISSUED, "Émis", "Émission"),

  /**
   * #{@link TokenStatusCode#CONSUMED}.
   */
  CONSUMED(TokenStatusCode.CONSUMED, "Consommé", "Consommation"),

  /**
   * #{@link TokenStatusCode#EXPIRED}.
   */
  EXPIRED(TokenStatusCode.EXPIRED, "Expiré", "Expiration"),

  /**
   * #{@link TokenStatusCode#REVOKED}.
   */
  REVOKED(TokenStatusCode.REVOKED, "Révoqué", "Révocation");


  private TokenStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<TokenStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link TokenStatus} par code.
   *
   * @param code code
   * @return {@link TokenStatus}
   */
  public static TokenStatus getByCode(String code) {
    return Stream.of(TokenStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }

  static {
    ISSUED.previous = Collections.emptySet();
    CONSUMED.previous = Core.getSet(List.of(ISSUED));
    EXPIRED.previous = Core.getSet(List.of(ISSUED));
    REVOKED.previous = Core.getSet(List.of(ISSUED));
  }
}
