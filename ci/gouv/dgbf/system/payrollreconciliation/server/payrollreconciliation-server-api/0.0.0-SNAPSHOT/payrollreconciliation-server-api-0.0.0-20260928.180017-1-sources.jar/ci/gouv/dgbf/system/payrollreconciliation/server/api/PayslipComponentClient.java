package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollreconciliation.server.api.PayslipComponentService.PayslipComponentGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayslipComponentService}.
 *
 * @author desysoft
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayslipComponentClient extends AbstractClient<PayslipComponentService>
    implements GetByIdentifier<PayslipComponentDto>,
               GetMany<PayslipComponentGetManyResponseDto> {

  @Override
  public PayslipComponentClient service(PayslipComponentService service) {
    return (PayslipComponentClient) super.service(service);
  }

  /**
   * {@link PayslipComponentService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipComponentGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayslipComponentGetManyResponseDto>(
        PayslipComponentGetManyResponseDto.class,
        PayslipComponentService.GET_MANY_IDENTIFIER)
          .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayslipComponentService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipComponentGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayslipComponentService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipComponentDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayslipComponentDto>(PayslipComponentDto.class,
        PayslipComponentService.GET_ONE_IDENTIFIER)
          .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayslipComponentService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipComponentDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayslipComponentService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipComponentDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayslipComponentDto>(PayslipComponentDto.class,
        PayslipComponentService.GET_BY_IDENTIFIER_IDENTIFIER)
          .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayslipComponentService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayslipComponentDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayslipComponentService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetOneExecutor<Long>(Long.class,
        PayslipComponentService.GET_COUNT_IDENTIFIER)
          .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayslipComponentService#getCount}.
   *
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public Long getCount(FilterDto filter, String auditWho, String auditSession) {
    GetCountRequestDto request = new GetCountRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getCount(request);
  }

  /**
   * {@link PayslipComponentService#getSummary}.
   *
   * @param request requête
   * @return réponse
   */
  public PayslipComponentSummaryDto getSummary(GetCountRequestDto request) {
    return new GetOneExecutor<PayslipComponentSummaryDto>(PayslipComponentSummaryDto.class,
        PayslipComponentService.GET_SUMMARY_IDENTIFIER)
          .execute(() -> service().getSummary(request));
  }

  /**
   * {@link PayslipComponentService#getSummary}.
   *
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayslipComponentSummaryDto getSummary(FilterDto filter, String auditWho,
      String auditSession) {
    GetCountRequestDto request = new GetCountRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getSummary(request);
  }

}
