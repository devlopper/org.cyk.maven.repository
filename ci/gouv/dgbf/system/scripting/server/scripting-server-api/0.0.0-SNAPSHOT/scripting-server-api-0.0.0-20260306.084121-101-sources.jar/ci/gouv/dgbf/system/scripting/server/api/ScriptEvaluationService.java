package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ScriptEvaluationDto}.
 *
 * @author Christian
 *
 */
@Path(value = ScriptEvaluationService.PATH)
@Tag(name = "Gestion des évaluations de scripts")
public interface ScriptEvaluationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "evaluations-scripts";

  /**
   * Cette interface représente la base de requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ScriptEvaluationBaseSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir les arguments.
     *
     * @return arguments
     */
    Map<String, Object> getArguments();

    /**
     * Cette méthode permet d'assigner les arguments.
     *
     * @param arguments Arguments
     */
    void setArguments(Map<String, Object> arguments);

    /**
     * Cette méthode permet d'obtenir {@link StringFormat} du résultat.
     *
     * @return {@link StringFormat} du résultat
     */
    StringFormat getResultAsStringFormat();

    /**
     * Cette méthode permet d'assigner {@link StringFormat} du résultat.
     *
     * @param resultAsStringFormat {@link StringFormat} du résultat
     */
    void setResultAsStringFormat(StringFormat resultAsStringFormat);

    /**
     * Identifiant json des arguments.
     */
    String JSON_ARGUMENTS = ScriptEvaluationDto.JSON_ARGUMENTS;

    /**
     * Identifiant json du format de la représenation en chaine de caractères du résultat.
     */
    String JSON_RESULT_AS_STRING_FORMAT = ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;
  }

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Christian
   *
   */
  interface ScriptEvaluationSaveRequestDto extends ScriptEvaluationBaseSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ScriptDto}.
     *
     * @return identifiant de {@link ScriptDto}
     */
    String getScriptIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ScriptDto}.
     *
     * @param scriptIdentifier identifiant de {@link ScriptDto}
     */
    void setScriptIdentifier(String scriptIdentifier);

    /**
     * Identifiant json identifiant de {@link ScriptDto}.
     */
    String JSON_SCRIPT_IDENTIFIER = ScriptEvaluationDto.JSON_SCRIPT_IDENTIFIER;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements ScriptEvaluationSaveRequestDto {
    @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
    private String scriptIdentifier;

    @JsonbProperty(JSON_ARGUMENTS)
    private Map<String, Object> arguments;

    @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
    private StringFormat resultAsStringFormat;
  }

  /**
   * Cette classe représente la réponse de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ScriptEvaluationCreateResponseDto extends CreateResponseDto {
    /**
     * Représentation en chaine de caractères du résultat.
     */
    @JsonbProperty(JSON_RESULT_AS_STRING)
    private String resultAsString;

    /**
     * Format de {@link #resultAsString}.
     */
    @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
    private StringFormat resultAsStringFormat;

    /**
     * Résultat en entier.
     */
    @JsonbProperty(JSON_RESULT_AS_INTEGER)
    private Integer resultAsInteger;

    /**
     * Résultat en booléen.
     */
    @JsonbProperty(JSON_RESULT_AS_BOOLEAN)
    private Boolean resultAsBoolean;

    /**
     * Identifiant json {@link #resultAsString}.
     */
    public static final String JSON_RESULT_AS_STRING = ScriptEvaluationDto.JSON_RESULT_AS_STRING;

    /**
     * Identifiant json {@link #resultAsStringFormat}.
     */
    public static final String JSON_RESULT_AS_STRING_FORMAT =
        ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;

    /**
     * Identifiant json {@link #resultAsInteger}.
     */
    public static final String JSON_RESULT_AS_INTEGER = ScriptEvaluationDto.JSON_RESULT_AS_INTEGER;

    /**
     * Identifiant json {@link #resultAsBoolean}.
     */
    public static final String JSON_RESULT_AS_BOOLEAN = ScriptEvaluationDto.JSON_RESULT_AS_BOOLEAN;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_EVALUATION_SCRIPT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201", content = {
      @Content(schema = @Schema(implementation = ScriptEvaluationCreateResponseDto.class))})
  Response create(ScriptEvaluationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluationCreateManyRequestDto extends AbstractAuditedRequestJsonDto {
    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty(JSON_GROUPS)
    private Collection<GroupDto> groups;

    /**
     * {@link StringFormat} de la représentation en chaine de caractères du résultat.
     */
    @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
    private StringFormat resultAsStringFormat;

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param orderNumber numéro d'ordre
     * @param scriptIdentifiers identifiants {@link ScriptDto}
     * @param arguments arguments
     */
    public void addGroup(int orderNumber, Collection<String> scriptIdentifiers,
        Map<String, Object> arguments) {
      GroupDto group = group();
      group.orderNumber = orderNumber;
      group.addScriptIdentifiers(scriptIdentifiers);
      group.arguments = arguments;
    }

    /**
     * Cette méthode permet d'ajouter {@link GroupDto}.
     *
     * @param scriptIdentifiers identifiants {@link ScriptDto}
     * @param arguments arguments
     */
    public void addGroup(Collection<String> scriptIdentifiers, Map<String, Object> arguments) {
      addGroup(Optional.ofNullable(groups).orElse(Collections.emptyList()).size(),
          scriptIdentifiers, arguments);
    }

    /**
     * Cette méthode permet d'obtenir une collection de groupe non nulle.
     *
     * @return collection de groupe non nulle
     */
    public Collection<GroupDto> groups() {
      if (groups == null) {
        groups = new ArrayList<GroupDto>();
      }
      return groups;
    }

    /**
     * Cette méthode permet d'obtenir {@link GroupDto}.
     *
     * @return {@link GroupDto}
     */
    public GroupDto group() {
      GroupDto group = new GroupDto();
      groups().add(group);
      return group;
    }

    /**
     * Identifiant json {@link #groups}.
     */
    public static final String JSON_GROUPS = "groupes";

    /**
     * Identifiant json {@link #resultAsStringFormat}.
     */
    public static final String JSON_RESULT_AS_STRING_FORMAT =
        ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;

    /**
     * Cette classe représente un groupe.
     *
     * @author Christian
     */
    @Getter
    @Setter
    public static class GroupDto {
      /**
       * Numéro d'ordre.
       */
      @JsonbProperty(JSON_ORDER_NUMBER)
      private Integer orderNumber;

      /**
       * Carte d'identifiants {@link ScriptDto} et index.
       */
      @JsonbProperty(JSON_SCRIPT_IDENTIFIERS)
      private Map<String, Integer> scriptIdentifiers;

      /**
       * Arguments.
       */
      @JsonbProperty(JSON_ARGUMENTS)
      private Map<String, Object> arguments;

      /**
       * Cette méthode permet d'ajouter des identifiants de {@link ScriptDto}.
       *
       * @param identifiers identifiants de {@link ScriptDto}
       */
      public void addScriptIdentifiers(Collection<String> identifiers) {
        Optional.ofNullable(identifiers).orElse(Collections.emptyList()).forEach(identifier -> {
          scriptIdentifiers().put(identifier, scriptIdentifiers.size());
        });
      }

      /**
       * Cette méthode permet d'obtenir une carte non nulle.
       *
       * @return carte non nulle
       */
      public Map<String, Integer> scriptIdentifiers() {
        if (scriptIdentifiers == null) {
          scriptIdentifiers = new HashMap<>();
        }
        return scriptIdentifiers;
      }

      /**
       * Identifiant json {@link #orderNumber}.
       */
      public static final String JSON_ORDER_NUMBER = "numeroOrdre";

      /**
       * Identifiant json {@link #scriptIdentifiers}.
       */
      public static final String JSON_SCRIPT_IDENTIFIERS = ScriptDto.JSON_THIS_IDENTIFIER;

      /**
       * Identifiant json {@link #arguments}.
       */
      public static final String JSON_ARGUMENTS = ScriptEvaluationDto.JSON_ARGUMENTS;
    }
  }

  /**
   * Cette classe représente la réponse de création de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ScriptEvaluationCreateManyResponseDto extends CreateManyResponseDto {

    /**
     * Collection de {@link GroupDto}.
     */
    @JsonbProperty("groupes")
    private Collection<GroupDto> groups;

    /**
     * Cette méthode permet d'obtenir {@link GroupDto} par numéro d'ordre.
     *
     * @param orderNumber numéro d'ordre
     * @return {@link GroupDto}
     */
    public GroupDto getGroupByOrderNumber(Integer orderNumber) {
      return Optional.ofNullable(groups).orElse(Collections.emptyList()).stream()
          .filter(group -> Objects.equals(group.orderNumber, orderNumber)).findFirst().orElse(null);
    }

    /**
     * Cette classe représente un groupe.
     *
     * @author Christian
     */
    @Getter
    @Setter
    @ToString
    @EqualsAndHashCode(of = {"orderNumber"})
    public static class GroupDto {
      /**
       * Numéro d'ordre.
       */
      @JsonbProperty(JSON_ORDER_NUMBER)
      private Integer orderNumber;

      /**
       * Collection de {@link ResultDto}.
       */
      @JsonbProperty(JSON_RESULTS)
      private Collection<ResultDto> results;

      /**
       * Cette méthode permet d'obtenir {@link ResultDto} par numéro d'ordre.
       *
       * @param orderNumber numéro d'ordre
       * @return {@link ResultDto}
       */
      public ResultDto getResultByOrderNumber(Integer orderNumber) {
        return Optional.ofNullable(results).orElse(Collections.emptyList()).stream()
            .filter(result -> Objects.equals(result.getOrderNumber(), orderNumber)).findFirst()
            .orElse(null);
      }

      /**
       * Identifiant json {@link #orderNumber}.
       */
      public static final String JSON_ORDER_NUMBER = "numeroOrdre";

      /**
       * Identifiant json {@link #results}.
       */
      public static final String JSON_RESULTS = "resultats";
    }

    /**
     * Format de {@link ResultDto#valueAsString}.
     */
    @JsonbProperty(JSON_RESULT_VALUE_AS_STRING_FORMAT)
    private StringFormat resultValueAsStringFormat;

    /**
     * Identifiant json {@link #resultValueAsStringFormat}.
     */
    public static final String JSON_RESULT_VALUE_AS_STRING_FORMAT =
        ScriptEvaluationDto.JSON_RESULT_AS_STRING_FORMAT;

    /**
     * Cette classe représente un résultat.
     *
     * @author Christian
     */
    @Getter
    @Setter
    @ToString
    @EqualsAndHashCode(callSuper = true)
    public static class ResultDto extends OrderedIdentifierDto {
      /**
       * Représentation en chaine de caractères de la valeur.
       */
      @JsonbProperty(JSON_VALUE_AS_STRING)
      private String valueAsString;

      /**
       * Valeur en entier.
       */
      @JsonbProperty(JSON_VALUE_AS_INTEGER)
      private Integer valueAsInteger;

      /**
       * Valeur en booléen.
       */
      @JsonbProperty(JSON_VALUE_AS_BOOLEAN)
      private Boolean valueAsBoolean;
      
      /**
       * Identifiant json {@link #valueAsString}.
       */
      public static final String JSON_VALUE_AS_STRING = "valeurChaine";
      
      /**
       * Identifiant json {@link #valueAsInteger}.
       */
      public static final String JSON_VALUE_AS_INTEGER = "valeurEntier";
      
      /**
       * Identifiant json {@link #valueAsBoolean}.
       */
      public static final String JSON_VALUE_AS_BOOLEAN = "valeurBooleen";
    }
  }

  /**
   * Identifiant du service de création de plusieurs.
   */
  String CREATE_MANY_IDENTIFIER = "CREATION_PLUSIEURS_EVALUATION_SCRIPT";

  /**
   * Chemin du service de création de plusieurs.
   */
  String CREATE_MANY_PATH = "creation/plusieurs";

  /**
   * Cette méthode permet de créer plusieurs {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ScriptEvaluationCreateManyResponseDto.class))})
  Response createMany(ScriptEvaluationCreateManyRequestDto request);

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_EVALUATION_SCRIPT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ScriptEvaluationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ScriptEvaluationGetManyResponseDto
      extends AbstractGetByPageResponseDto<ScriptEvaluationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ScriptEvaluationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_EVALUATION_SCRIPT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptEvaluationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_EVALUATION_SCRIPT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ScriptEvaluationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_EVALUATION_SCRIPT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ScriptEvaluationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ScriptEvaluationUpdateRequestDto extends ByIdentifierRequestDto
      implements ScriptEvaluationSaveRequestDto {
    @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
    private String scriptIdentifier;

    @JsonbProperty(JSON_ARGUMENTS)
    private Map<String, Object> arguments;

    @JsonbProperty(JSON_RESULT_AS_STRING_FORMAT)
    private StringFormat resultAsStringFormat;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_EVALUATION_SCRIPT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ScriptEvaluationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
