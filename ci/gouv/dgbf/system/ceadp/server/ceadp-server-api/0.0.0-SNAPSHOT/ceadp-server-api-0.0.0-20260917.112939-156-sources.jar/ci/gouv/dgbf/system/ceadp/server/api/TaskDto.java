package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une tâche.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TaskDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String administrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link AdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;

  /**
   * Identifiant de l'unité administrative d'exécution.
   */
  @JsonbProperty(JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String executionAdministrativeUnitIdentifier;

  /**
   * Identifiant de {@link SubAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER)
  private String subAdministrativeUnitIdentifier;

  /**
   * Représentation en chaine de caractères de {@link SubAdministrativeUnitDto}.
   */
  @JsonbProperty(JSON_SUB_ADMINISTRATIVE_UNIT_AS_STRING)
  private String subAdministrativeUnitAsString;

  /**
   * Identifiant de {@link FolderDto}.
   */
  @JsonbProperty(JSON_FOLDER_IDENTIFIER)
  private String folderIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FolderDto}.
   */
  @JsonbProperty(JSON_FOLDER_AS_STRING)
  private String folderAsString;

  /**
   * Identifiant de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  /**
   * Réprésentation chaine de caractère de {@link ActivityDto}.
   */
  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  /**
   * Description.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Fichier Manageable quand la tâche est terminé.
   */
  @JsonbProperty(JSON_FILE_MANAGEABLE_WHEN_TERMINATED)
  private Boolean fileManageableWhenTerminated;

  /* Processing */

  /**
   * Identifiant traitement.
   */
  @JsonbProperty(JSON_PROCESSING_IDENTIFIER)
  private String processingIdentifier;

  /**
   * Statut traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_CODE)
  private String processingStatusCode;

  /**
   * Statut traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_AS_STRING)
  private String processingStatusAsString;

  /**
   * Historique Statut traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_HISTORY_AS_STRING)
  private String processingStatusHistoryAsString;

  /**
   * Historique date traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_DATE_HISTORY_AS_STRING)
  private String processingDateHistoryAsString;

  /**
   * Historique acteur traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_ACTOR_HISTORY_AS_STRING)
  private String processingActorHistoryAsString;

  /**
   * Date du traitement.
   */
  @JsonbProperty(JSON_PROCESSING_DATE)
  private LocalDateTime processingDate;

  /**
   * Date du traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_DATE_AS_STRING)
  private String processingDateAsString;

  /**
   * Date du statut du traitement.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_DATE)
  private LocalDateTime processingStatusDate;

  /**
   * Date du statut du traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_DATE_AS_STRING)
  private String processingStatusDateAsString;

  /**
   * Date sans l'heure du statut du traitement au format chaine de caractères.
   */
  @JsonbProperty(JSON_PROCESSING_STATUS_DATE_WITHOUT_TIME_AS_STRING)
  private String processingStatusDateWithoutTimeAsString;

  /**
   * Date de création.
   */
  @JsonbProperty(JSON_CREATION_DATE)
  private LocalDateTime creationDate;

  /**
   * Date de création au format chaine de caractères.
   */
  @JsonbProperty(JSON_CREATION_DATE_AS_STRING)
  private String creationDateAsString;

  /**
   * Date de création sans l'heure au format chaine de caractères.
   */
  @JsonbProperty(JSON_CREATION_DATE_WITHOUT_TIME_AS_STRING)
  private String creationDateWithoutTimeAsString;

  /**
   * Oui ou non si traitement démarrable.
   */
  @JsonbProperty(JSON_PROCESSING_STARTABLE)
  private Boolean processingStartable;

  /**
   * Oui ou non si traitement stoppable.
   */
  @JsonbProperty(JSON_PROCESSING_STOPPABLE)
  private Boolean processingStoppable;

  /**
   * Oui ou non si traitement annuable.
   */
  @JsonbProperty(JSON_PROCESSING_CANCELABLE)
  private Boolean processingCancelable;

  /**
   * Oui ou non si traitement terminable.
   */
  @JsonbProperty(JSON_PROCESSING_TERMINATABLE)
  private Boolean processingTerminatable;

  /* Files */

  /**
   * Identifiant groupe de fichiers.
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Identifiant groupe d'identités.
   */
  @JsonbProperty(JSON_IDENTITIES_GROUP_IDENTIFIER)
  private String identitiesGroupIdentifier;

  /**
   * Date de début.
   */
  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;

  /**
   * Représentation en chaine de caractère de {@link #fromDateAsString}.
   */
  @JsonbProperty(JSON_FROM_DATE_AS_STRING)
  private String fromDateAsString;

  /**
   * Représentation en chaine de caractère de {@link #fromDateAsString} sans l'heure.
   */
  @JsonbProperty(JSON_FROM_DATE_WITHOUT_TIME_AS_STRING)
  private String fromDateWithoutTimeAsString;

  /**
   * Date de fin.
   */
  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;

  /**
   * Représentation en chaine de caractère de {@link #toDate}.
   */
  @JsonbProperty(JSON_TO_DATE_AS_STRING)
  private String toDateAsString;

  /**
   * Représentation en chaine de caractère de {@link #toDate} sans l'heure.
   */
  @JsonbProperty(JSON_TO_DATE_WITHOUT_TIME_AS_STRING)
  private String toDateWithoutTimeAsString;

  /**
   * Représentation en chaine de caractère du délai en nombre de jour.
   */
  @JsonbProperty(JSON_DEADLINE_DAYS_COUNT_AS_STRING)
  private String deadlineDaysCountAsString;

  /**
   * Nombre {@link IdentityDto}.
   */
  @JsonbProperty(JSON_IDENTITY_COUNT_AS_STRING)
  private String identityCountAsString;

  /**
   * Nombre de fichier.
   */
  @JsonbProperty(JSON_FILE_COUNT_AS_STRING)
  private String fileCountAsString;

  /**
   * Représentation en chaine de caractère de l'identité du responsble.
   */
  @JsonbProperty(JSON_RESPONSIBLE_IDENTITY_AS_STRING)
  private String responsibleIdentityAsString;

  /**
   * Est en retard.
   */
  @JsonbProperty(JSON_IS_LATE)
  private Boolean isLate;

  /**
   * Identifiant de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Représentation en chaîne de caractères de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant json de identifiant de {@link TaskDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTache";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link TaskDto}.
   */
  public static final String JSON_THIS_AS_STRING = "tacheChaine";

  /**
   * Identifiant json {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING =
      AdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #administrativeUnitIdentifier}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_IDENTIFIER =
      AdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json champ {@link #fileManageableWhenTerminated}.
   */
  public static final String JSON_FILE_MANAGEABLE_WHEN_TERMINATED = "fichierGerableQuandTerminee";

  /**
   * Identifiant json champ {@link #executionAdministrativeUnitIdentifier}.
   */
  public static final String JSON_EXECUTION_ADMINISTRATIVE_UNIT_IDENTIFIER =
      "idUniteAdministrativeExecution";

  /**
   * Identifiant json champ {@link #subAdministrativeUnitIdentifier}.
   */
  public static final String JSON_SUB_ADMINISTRATIVE_UNIT_IDENTIFIER =
      SubAdministrativeUnitDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #subAdministrativeUnitAsString}.
   */
  public static final String JSON_SUB_ADMINISTRATIVE_UNIT_AS_STRING =
      SubAdministrativeUnitDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ActivityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #activityAsString}.
   */
  public static final String JSON_ACTIVITY_AS_STRING = ActivityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #folderIdentifier}.
   */
  public static final String JSON_FOLDER_IDENTIFIER = FolderDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #folderAsString}.
   */
  public static final String JSON_FOLDER_AS_STRING = FolderDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #processingIdentifier}.
   */
  public static final String JSON_PROCESSING_IDENTIFIER = "idTraitement";

  /**
   * Identifiant json champ {@link #processingStatusCode}.
   */
  public static final String JSON_PROCESSING_STATUS_CODE = "codeStatutTraitement";

  /**
   * Identifiant json champ {@link #processingStatusAsString}.
   */
  public static final String JSON_PROCESSING_STATUS_AS_STRING = "statutTraitementChaine";

  /**
   * Identifiant json champ {@link #processingStatusHistoryAsString}.
   */
  public static final String JSON_PROCESSING_STATUS_HISTORY_AS_STRING =
      "historiqueStatutTraitementChaine";

  /**
   * Identifiant json champ {@link #processingActorHistoryAsString}.
   */
  public static final String JSON_PROCESSING_ACTOR_HISTORY_AS_STRING =
      "historiqueActeurTraitementChaine";

  /**
   * Identifiant json champ {@link #processingDateHistoryAsString}.
   */
  public static final String JSON_PROCESSING_DATE_HISTORY_AS_STRING =
      "historiqueDateTraitementChaine";

  /**
   * Identifiant json champ {@link #creationDate}.
   */
  public static final String JSON_CREATION_DATE = "dateCreation";

  /**
   * Identifiant json champ {@link #creationDateAsString}.
   */
  public static final String JSON_CREATION_DATE_AS_STRING = "dateCreationChaine";

  /**
   * Identifiant json champ {@link #creationDateWithoutTimeAsString}.
   */
  public static final String JSON_CREATION_DATE_WITHOUT_TIME_AS_STRING =
      "dateSansHeureCCreationhaine";

  /**
   * Identifiant json champ {@link #processingDate}.
   */
  public static final String JSON_PROCESSING_DATE = "dateTraitement";

  /**
   * Identifiant json champ {@link #processingDateAsString}.
   */
  public static final String JSON_PROCESSING_DATE_AS_STRING = "dateTraitementChaine";

  /**
   * Identifiant json champ {@link #processingStatusDate}.
   */
  public static final String JSON_PROCESSING_STATUS_DATE = "dateStatutTraitement";

  /**
   * Identifiant json champ {@link #processingStatusDateAsString}.
   */
  public static final String JSON_PROCESSING_STATUS_DATE_AS_STRING = "dateStatutTraitementChaine";

  /**
   * Identifiant json champ {@link #processingStatusDateWithoutTimeAsString}.
   */
  public static final String JSON_PROCESSING_STATUS_DATE_WITHOUT_TIME_AS_STRING =
      "dateSansHeureStatutTraitementChaine";

  /**
   * Identifiant json champ {@link #processingStartable}.
   */
  public static final String JSON_PROCESSING_STARTABLE = "traitementDemarrable";

  /**
   * Identifiant json champ {@link #processingStoppable}.
   */
  public static final String JSON_PROCESSING_STOPPABLE = "traitementStoppable";

  /**
   * Identifiant json champ {@link #processingCancelable}.
   */
  public static final String JSON_PROCESSING_CANCELABLE = "traitementAnnulable";

  /**
   * Identifiant json champ {@link #processingTerminatable}.
   */
  public static final String JSON_PROCESSING_TERMINATABLE = "traitementTerminable";

  /**
   * Identifiant json champ {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "idGroupeFichiers";

  /**
   * Identifiant json champ {@link #identitiesGroupIdentifier}.
   */
  public static final String JSON_IDENTITIES_GROUP_IDENTIFIER = "idGroupeIdentites";

  /**
   * Identifiant json champ {@link #fromDate}.
   */
  public static final String JSON_FROM_DATE = "dateDebut";

  /**
   * Identifiant json champ {@link #fromDateAsString}.
   */
  public static final String JSON_FROM_DATE_AS_STRING = "dateDebutChaine";

  /**
   * Identifiant json champ {@link #fromDateWithoutTimeAsString}.
   */
  public static final String JSON_FROM_DATE_WITHOUT_TIME_AS_STRING = "dateSansHeureDebutChaine";

  /**
   * Identifiant json champ {@link #toDate}.
   */
  public static final String JSON_TO_DATE = "dateFin";

  /**
   * Identifiant json champ {@link #toDateAsString}.
   */
  public static final String JSON_TO_DATE_AS_STRING = "dateFinChaine";

  /**
   * Identifiant json champ {@link #toDateWithoutTimeAsString}.
   */
  public static final String JSON_TO_DATE_WITHOUT_TIME_AS_STRING = "dateSansHeureFinChaine";

  /**
   * Identifiant json champ {@link #deadlineDaysCountAsString}.
   */
  public static final String JSON_DEADLINE_DAYS_COUNT_AS_STRING = "delaiNombreJourChaine";

  /**
   * Identifiant json champ {@link #identityCountAsString}.
   */
  public static final String JSON_IDENTITY_COUNT_AS_STRING = "nombreIdentite";

  /**
   * Identifiant json champ {@link #fileCountAsString}.
   */
  public static final String JSON_FILE_COUNT_AS_STRING = "nombreFichier";

  /**
   * Identifiant json champ {@link #responsibleIdentityAsString}.
   */
  public static final String JSON_RESPONSIBLE_IDENTITY_AS_STRING = "identiteResponsableChaine";

  /**
   * Identifiant json champ {@link #isLate}.
   */
  public static final String JSON_IS_LATE = "estEnRetard";

  /**
   * Identifiant json de l'identifiant de l'exercice budgétaire.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = "idExercice";

  /**
   * Identifiant json de la représentation en chaîne de caractères de l'exercice budgétaire.
   */
  public static final String JSON_EXERCISE_AS_STRING = "exerciceChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "tâche";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
