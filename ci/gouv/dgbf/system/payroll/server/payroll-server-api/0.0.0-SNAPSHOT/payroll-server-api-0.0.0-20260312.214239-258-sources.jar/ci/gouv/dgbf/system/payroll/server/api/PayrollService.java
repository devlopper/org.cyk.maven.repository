package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PayrollDto}.
 *
 * @author A.K.M
 *
 */
@Path(value = PayrollService.PATH)
@Tag(name = "Gestion des paies")
public interface PayrollService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "paies";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author A.K.M
   *
   */
  interface PayrollSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollPeriodGroupDto}.
     *
     * @return identifiant de {@link PayrollPeriodGroupDto}
     */
    String getPeriodGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollPeriodGroupDto}.
     *
     * @param periodGroupIdentifier identifiant de {@link PayrollPeriodGroupDto}
     */
    void setPeriodGroupIdentifier(String periodGroupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ExerciseDto}.
     *
     * @return identifiant de {@link ExerciseDto}
     */
    String getExerciseIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ExerciseDto}.
     *
     * @param exerciseIdentifier identifiant de {@link ExerciseDto}
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link PayrollTypeDto}.
     *
     * @return identifiant de {@link PayrollTypeDto}
     */
    String getTypeIdentifier();
    
    /**
     * Cette méthode permet d'assigner l'identifiant de {@link PayrollTypeDto}.
     *
     * @param typeIdentifier identifiant de {@link PayrollTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir la date de début.
     *
     * @return date de début
     */
    LocalDate getStartDate();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param startDate date de début
     */
    void setStartDate(LocalDate startDate);

    /**
     * Cette méthode permet d'obtenir la date de fin.
     *
     * @return date de fin
     */
    LocalDate getEndDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param endDate date de fin
     */
    void setEndDate(LocalDate endDate);

    /**
     * {@link PayrollDto#JSON_PERIOD_GROUP_IDENTIFIER}.
     */
    public static final String JSON_PERIOD_GROUP_IDENTIFIER =
        PayrollDto.JSON_PERIOD_GROUP_IDENTIFIER;

    /**
     * {@link PayrollDto#JSON_EXERCISE_IDENTIFIER}.
     */
    public static final String JSON_EXERCISE_IDENTIFIER = PayrollDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * {@link PayrollDto#JSON_TYPE_IDENTIFIER}.
     */
    public static final String JSON_TYPE_IDENTIFIER =
        PayrollDto.JSON_TYPE_IDENTIFIER;

    /**
     * {@link PayrollDto#JSON_START_DATE}.
     */
    public static final String JSON_START_DATE = PayrollDto.JSON_START_DATE;

    /**
     * {@link PayrollDto#JSON_END_DATE}.
     */
    public static final String JSON_END_DATE = PayrollDto.JSON_END_DATE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PAIE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PayrollCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class PayrollCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements PayrollSaveRequestDto {
    /**
     * {@link PayrollDto#getPeriodGroupIdentifier()}.
     */
    @JsonbProperty(JSON_PERIOD_GROUP_IDENTIFIER)
    private String periodGroupIdentifier;

    /**
     * {@link PayrollDto#getExerciseIdentifier()}.
     */
    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;
    /**
     * {@link PayrollDto#getPayrollTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    /**
     * {@link PayrollDto#getStartDate()}.
     */
    @JsonbProperty(JSON_START_DATE)
    private LocalDate startDate;
    /**
     * {@link PayrollDto#getEndDate()}.
     */
    @JsonbProperty(JSON_END_DATE)
    private LocalDate endDate;

  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PAIE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  public static class PayrollGetManyResponseDto extends AbstractGetByPageResponseDto<PayrollDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PayrollDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PAIE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PAIE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PAIE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PayrollUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author A.K.M
   *
   */
  @Getter
  @Setter
  class PayrollUpdateRequestDto extends ByIdentifierRequestDto implements PayrollSaveRequestDto {
    /**
     * {@link PayrollDto#getPeriodGroupIdentifier()}.
     */
    @JsonbProperty(JSON_PERIOD_GROUP_IDENTIFIER)
    private String periodGroupIdentifier;

    /**
     * {@link PayrollDto#getExerciseIdentifier()}.
     */
    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    /**
     * {@link PayrollDto#getTypeIdentifier()}.
     */
    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    /**
     * {@link PayrollDto#getStartDate()}.
     */
    @JsonbProperty(JSON_START_DATE)
    private LocalDate startDate;
    /**
     * {@link PayrollDto#getEndDate()}.
     */
    @JsonbProperty(JSON_END_DATE)
    private LocalDate endDate;

    /**
     * {@link PayrollDto#JSON_START_DATE}.
     */
    public static final String JSON_START_DATE = PayrollDto.JSON_START_DATE;

    /**
     * {@link PayrollDto#JSON_END_DATE}.
     */
    public static final String JSON_END_DATE = PayrollDto.JSON_END_DATE;

  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PAIE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service de création des {@link PayslipDto}.
   */
  String CREATE_PAYSLIPS_IDENTIFIER = "CREATION_BULLETINS_PAIE";

  /**
   * Chemin du service de création des {@link PayslipDto}.
   */
  String CREATE_PAYSLIPS_PATH = "creation-bulletins";

  /**
   * Cette méthode permet de créer des {@link PayslipDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PAYSLIPS_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CREATE_PAYSLIPS_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayrollCreatePayslipsResponseDto.class))})
  Response createPayslips(PayrollCreatePayslipsRequestDto request);

  /**
   * Cette classe représente la requête de création des {@link PayslipDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollCreatePayslipsRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de création des {@link PayslipDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollCreatePayslipsResponseDto extends ProcessResponseDto {

    @JsonbProperty(JSON_PROCESSED_REMUNERABLES_COUNT)
    private Integer processedRemunerablesCount;

    @JsonbProperty(JSON_CREATED_PAYSLIPS_COUNT)
    private Integer createdPayslipsCount;

    /**
     * Identifiant json {@link #processedRemunerablesCount}.
     */
    public static final String JSON_PROCESSED_REMUNERABLES_COUNT = "nombreRemunerableTraites";

    /**
     * Identifiant json {@link #createdPayslipsCount}.
     */
    public static final String JSON_CREATED_PAYSLIPS_COUNT = "nombreBulletinPaieCree";
  }

  /**
   * Identifiant du service de démarrage du calcul.
   */
  String START_CALCULATION_IDENTIFIER = "DEMARRER_CALCUL_PAIE";

  /**
   * Chemin du service de démarrage du calcul.
   */
  String START_CALCULATION_PATH = "demarrage-calcul";

  /**
   * Cette méthode permet de démarrer la calcul de {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(START_CALCULATION_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = START_CALCULATION_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PayrollStartCalculationResponseDto.class))})
  Response startCalculation(PayrollStartCalculationRequestDto request);

  /**
   * Cette classe représente la requête de démarrage de calcul.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollStartCalculationRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de démarrage de calcul.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollStartCalculationResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de calcul.
   */
  String CALCULATE_IDENTIFIER = "CALCUL_PAIE";

  /**
   * Chemin du service de calcul.
   */
  String CALCULATE_PATH = "calcul";

  /**
   * Cette méthode permet de calculer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CALCULATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = CALCULATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PayrollCalculateResponseDto.class))})
  Response calculate(PayrollCalculateRequestDto request);

  /**
   * Cette classe représente la requête de calcul.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollCalculateRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de calcul.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class PayrollCalculateResponseDto extends ProcessResponseDto {

  }

  /**
   * Cette classe représente la réponse de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto {

    /**
     * {@link PayrollDto#getStatus()}.
     */
    @JsonbProperty(JSON_STATUS)
    private PayrollStatus status;

    /**
     * {@link PayrollDto#getInitializable()}.
     */
    @JsonbProperty(JSON_INITIALIZABLE)
    private Boolean initializable;

    /**
     * {@link PayrollDto#getTransmittableForControl()}.
     */
    @JsonbProperty(JSON_TRANSMITTABLE_FOR_CONTROL)
    private Boolean transmittableForControl;

    /**
     * {@link PayrollDto#getControllable()}.
     */
    @JsonbProperty(JSON_CONTROLLABLE)
    private Boolean controllable;

    /**
     * {@link PayrollDto#getTransmittableForArbitration()}.
     */
    @JsonbProperty(JSON_TRANSMITTABLE_FOR_ARBITRATION)
    private Boolean transmittableForArbitration;

    /**
     * {@link PayrollDto#getArbitrable()}.
     */
    @JsonbProperty(JSON_ARBITRABLE)
    private Boolean arbitrable;

    /**
     * {@link PayrollDto#getClosable()}.
     */
    @JsonbProperty(JSON_CLOSABLE)
    private Boolean closable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir du statut.
     *
     * @param status {@link PayrollStatus}
     */
    public void initialize(PayrollStatus status) {
      this.status = status;
      initializable = PayrollStatus.INITIALIZED.getPrevious().contains(status);
      transmittableForControl =
          PayrollStatus.TRANSMITTED_FOR_CONTROL.getPrevious().contains(status);
      controllable = PayrollStatus.CONTROLLED.getPrevious().contains(status);
      transmittableForArbitration =
          PayrollStatus.TRANSMITTED_FOR_ARBITRATION.getPrevious().contains(status);
      arbitrable = PayrollStatus.ARBITRATED.getPrevious().contains(status);
      closable = PayrollStatus.CLOSED.getPrevious().contains(status);
    }

    /**
     * {@link PayrollDto#JSON_STATUS}.
     */
    public static final String JSON_STATUS = PayrollDto.JSON_STATUS;

    /**
     * {@link PayrollDto#JSON_INITIALIZABLE}.
     */
    public static final String JSON_INITIALIZABLE = PayrollDto.JSON_INITIALIZABLE;

    /**
     * {@link PayrollDto#JSON_TRANSMITTABLE_FOR_CONTROL}.
     */
    public static final String JSON_TRANSMITTABLE_FOR_CONTROL =
        PayrollDto.JSON_TRANSMITTABLE_FOR_CONTROL;

    /**
     * {@link PayrollDto#JSON_CONTROLLABLE}.
     */
    public static final String JSON_CONTROLLABLE = PayrollDto.JSON_CONTROLLABLE;

    /**
     * {@link PayrollDto#JSON_TRANSMITTABLE_FOR_ARBITRATION}.
     */
    public static final String JSON_TRANSMITTABLE_FOR_ARBITRATION =
        PayrollDto.JSON_TRANSMITTABLE_FOR_ARBITRATION;

    /**
     * {@link PayrollDto#JSON_ARBITRABLE}.
     */
    public static final String JSON_ARBITRABLE = PayrollDto.JSON_ARBITRABLE;

    /**
     * {@link PayrollDto#JSON_CLOSABLE}.
     */
    public static final String JSON_CLOSABLE = PayrollDto.JSON_CLOSABLE;
  }

  /**
   * Identifiant du service de démarrage de l'initialisation.
   */
  String START_INITIALIZATION_IDENTIFIER = "DEMARRER_INITIALISATION_PAIE";

  /**
   * Chemin du service de démarrage de l'initialisation.
   */
  String START_INITIALIZATION_PATH = "demarrage-initialisation";

  /**
   * Cette méthode permet de démarrer l'initialisation {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(START_INITIALIZATION_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = START_INITIALIZATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response startInitialization(ByIdentifierRequestDto request);

  /**
   * Identifiant du service d'initialisation.
   */
  String INITIALIZE_IDENTIFIER = "INITIALISATION_PAIE";

  /**
   * Chemin du service d'initialisation.
   */
  String INITIALIZE_PATH = "initialisation";

  /**
   * Cette méthode permet d'initialiser {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(INITIALIZE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = INITIALIZE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response initialize(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de reprise de l'initialisation à partir d'un point.
   */
  String RESUME_INITIALIZATION_FROM_CHECKPOINT_IDENTIFIER =
      "REPRISE_INITIALISATION_A_PARTIR_POINT_PAIE";

  /**
   * Chemin du service de reprise d'initialisation à partir d'un point.
   */
  String RESUME_INITIALIZATION_FROM_CHECKPOINT_PATH = "reprise-initialisation-a-partir-point";

  /**
   * Cette méthode permet de reprendre l'initialisation à partir d'un point.
   *
   * @param request requête
   * @return réponse
   */
  @Path(RESUME_INITIALIZATION_FROM_CHECKPOINT_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = RESUME_INITIALIZATION_FROM_CHECKPOINT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response resumeInitializationFromCheckpoint(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de transmission de paie pour controle.
   */
  String TRANSMIT_FOR_CONTROL_IDENTIFIER = "TRANSMISSION_POUR_CONTROLE_PAIE";

  /**
   * Chemin du service de transmission de paie pour controle.
   */
  String TRANSMIT_FOR_CONTROL_PATH = "transmission-pour-controle-paie";

  /**
   * Cette méthode permet de transmettre une paie pour controle {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_FOR_CONTROL_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TRANSMIT_FOR_CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response transmitForControl(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de controle paie.
   */
  String CONTROL_IDENTIFIER = "CONTROLE_PAIE";

  /**
   * Chemin du service de controle paie.
   */
  String CONTROL_PATH = "controle-paie";

  /**
   * Cette méthode permet dcontroler une paie {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONTROL_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = CONTROL_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ByIdentifierRequestDto.class))})
  Response control(ByIdentifierRequestDto request);

  /**
   * Identifiant du service de transmission de paie pour arbitrage.
   */
  String TRANSMIT_FOR_ARBITRATION_IDENTIFIER = "TRANSMISSION_POUR_ARBITRAGE_PAIE";

  /**
   * Chemin du service de transmission de paie pour arbitrage.
   */
  String TRANSMIT_FOR_ARBITRATION_PATH = "transmission-pour-arbitrage-paie";

  /**
   * Cette méthode permet de transmettre une paie pour arbitrage {@link PayrollDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(TRANSMIT_FOR_ARBITRATION_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = TRANSMIT_FOR_ARBITRATION_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response transmitForArbitration(ByIdentifierRequestDto request);
}
