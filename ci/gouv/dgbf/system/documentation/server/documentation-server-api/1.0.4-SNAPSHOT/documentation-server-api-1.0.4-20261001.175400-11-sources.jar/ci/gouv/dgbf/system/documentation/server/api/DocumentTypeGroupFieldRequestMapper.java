package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldService.DocumentTypeGroupFieldCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFieldService.DocumentTypeGroupFieldUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DocumentTypeGroupFieldDto}.
 *
 * @author si.kimou
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link DocumentTypeGroupFieldDto}.

    @author si.kimou
               """)
public interface DocumentTypeGroupFieldRequestMapper
    extends RequestMapper<DocumentTypeGroupFieldDto, DocumentTypeGroupFieldCreateRequestDto,
        DocumentTypeGroupFieldUpdateRequestDto> {

}
