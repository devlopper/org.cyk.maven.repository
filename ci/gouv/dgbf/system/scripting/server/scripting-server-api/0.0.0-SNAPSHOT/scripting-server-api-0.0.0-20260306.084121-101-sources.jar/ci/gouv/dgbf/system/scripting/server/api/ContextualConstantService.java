package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCreateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ContextualConstantDto}.
 *
 * @author Christian
 *
 */
@Path(value = ContextualConstantService.PATH)
@Tag(name = "Gestion des constantes contextuelles")
public interface ContextualConstantService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "constantes-contextuelles";

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface ContextualConstantSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de la constante.
     *
     * @return l'identifiant de la constante
     */
    String getConstantIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la constante.
     *
     * @param constantIdentifier l'identifiant de la constante
     */
    void setConstantIdentifier(String constantIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant du groupe.
     *
     * @return l'identifiant du groupe
     */
    String getGroupIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du groupe.
     *
     * @param groupIdentifier l'identifiant du groupe
     */
    void setGroupIdentifier(String groupIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de la catégorie.
     *
     * @return l'identifiant de la catégorie
     */
    String getCategoryIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la catégorie.
     *
     * @param categoryIdentifier l'identifiant de la catégorie
     */
    void setCategoryIdentifier(String categoryIdentifier);

    /**
     * Cette méthode permet d'obtenir la date de début.
     *
     * @return la date de début
     */
    LocalDateTime getFromDate();

    /**
     * Cette méthode permet d'assigner la date de début.
     *
     * @param fromDate la date de début
     */
    void setFromDate(LocalDateTime fromDate);

    /**
     * Cette méthode permet d'obtenir la date de fin.
     *
     * @return la date de fin
     */
    LocalDateTime getToDate();

    /**
     * Cette méthode permet d'assigner la date de fin.
     *
     * @param toDate la date de fin
     */
    void setToDate(LocalDateTime toDate);

    /**
     * {@link HasConstantIdentifierDto#JSON_CONSTANT_IDENTIFIER}.
     */
    String JSON_CONSTANT_IDENTIFIER = HasConstantIdentifierDto.JSON_CONSTANT_IDENTIFIER;

    /**
     * {@link HasGroupIdentifierDto#JSON_GROUP_IDENTIFIER}.
     */
    String JSON_GROUP_IDENTIFIER = HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER;

    /**
     * {@link HasCategoryIdentifierDto#JSON_CATEGORY_IDENTIFIER}.
     */
    String JSON_CATEGORY_IDENTIFIER = HasCategoryIdentifierDto.JSON_CATEGORY_IDENTIFIER;

    /**
     * {@link HasFromDateDto#JSON_FROM_DATE}.
     */
    String JSON_FROM_DATE = HasFromDateDto.JSON_FROM_DATE;

    /**
     * {@link HasToDateDto#JSON_TO_DATE}.
     */
    String JSON_TO_DATE = HasToDateDto.JSON_TO_DATE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ContextualConstantCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ContextualConstantCreateRequestDto extends AbstractCreateRequestDto
      implements ContextualConstantSaveRequestDto {

    @JsonbProperty(JSON_CONSTANT_IDENTIFIER)
    private String constantIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ContextualConstantGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class ContextualConstantGetManyResponseDto
      extends AbstractGetByPageResponseDto<ContextualConstantDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ContextualConstantDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ConstantDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ContextualConstantUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ContextualConstantUpdateRequestDto extends ByIdentifierRequestDto
      implements ContextualConstantSaveRequestDto {

    @JsonbProperty(JSON_CONSTANT_IDENTIFIER)
    private String constantIdentifier;

    @JsonbProperty(JSON_GROUP_IDENTIFIER)
    private String groupIdentifier;

    @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
    private String categoryIdentifier;

    @JsonbProperty(JSON_FROM_DATE)
    private LocalDateTime fromDate;

    @JsonbProperty(JSON_TO_DATE)
    private LocalDateTime toDate;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_CONSTANTE_CONTEXTUELLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ConstantDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
