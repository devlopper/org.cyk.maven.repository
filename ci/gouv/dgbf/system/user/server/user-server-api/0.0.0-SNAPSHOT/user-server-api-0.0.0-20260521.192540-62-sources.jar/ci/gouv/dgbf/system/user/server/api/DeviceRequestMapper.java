package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.DeviceService.DeviceCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.DeviceService.DeviceUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link DeviceDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link DeviceDto}.

    @author Arnaud
               """)
public interface DeviceRequestMapper
    extends RequestMapper<DeviceDto, DeviceCreateRequestDto, DeviceUpdateRequestDto> {

}