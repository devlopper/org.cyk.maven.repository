package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant arbitré pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasArbitratedAmountN1AsStringDto extends HasArbitratedAmountN1AsString {

  /**
   * Identifiant json du montant arbitré pour l'année N+1.
   */
  String JSON_ARBITRATED_AMOUNT_N1_AS_STRING = "montantArbitreN1Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName