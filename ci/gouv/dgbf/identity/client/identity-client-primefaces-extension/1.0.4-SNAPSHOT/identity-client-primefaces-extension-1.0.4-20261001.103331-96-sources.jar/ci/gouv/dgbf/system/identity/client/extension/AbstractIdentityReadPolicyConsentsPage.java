package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Base de pages de lecture des {@link IdentityPolicyConsentDto} d'une identité.
 *
 * @author Christian
 *
 */
public abstract class AbstractIdentityReadPolicyConsentsPage
    extends AbstractIdentityReadDatasPage {

  @Inject
  @Getter
  IdentityPolicyConsentController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    initializeController();
  }

  void initializeController() {
    controller.getFilterController().getFilter().setIdentityIdentifier(instance.getIdentifier());
    controller.initialize();
  }
}
