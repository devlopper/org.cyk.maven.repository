package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.mailer.server.api.MailService.GetManyResponseDto;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailSendFromTemplateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailSendRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailService.MailUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client du service MailService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class MailClient extends AbstractClient<MailService> implements GetByIdentifier<MailDto>,
    GetMany<GetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public MailClient service(MailService service) {
    return (MailClient) super.service(service);
  }

  /**
   * {@link MailService#send(MailSendRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto send(MailSendRequestDto request) {
    return new CreateExecutor(MailService.SEND_IDENTIFIER).execute(() -> service().send(request));
  }

  /**
   * {@link #send(MailSendRequestDto)}.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto send(String subjet, String body, String receiverAddress,
      String attachmentName, byte[] attachmentBytes, String auditWho, String auditSession) {
    MailSendRequestDto request = new MailSendRequestDto();
    request.setSubject(subjet);
    request.setBody(body);
    request.setReceiverAddress(receiverAddress);
    request.setAttachmentName(attachmentName);
    request.setAttachmentBytes(attachmentBytes);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return send(request);
  }

  /**
   * {@link MailService#sendFromTemplate}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto sendFromTemplate(MailSendFromTemplateRequestDto request) {
    return new CreateExecutor(MailService.SEND_FROM_TEMPLATE_IDENTIFIER)
        .execute(() -> service().sendFromTemplate(request));
  }

  /**
   * Cette méthode permet de créer un mail.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(MailCreateRequestDto request) {
    return new CreateExecutor(MailService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Cette méthode permet de créer un mail.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String subject, String body, String auditWho,
      String auditSession) {
    MailCreateRequestDto request = new MailCreateRequestDto();
    request.setSubject(subject);
    request.setBody(body);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link MailService#getMany(GetManyRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        MailService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * Cette méthode permet d'obtenir des mails.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link MailService#getOne(GetOneRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public MailDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<MailDto>(MailDto.class, MailService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * Cette méthode permet d'obtenir un mail.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public MailDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link MailService#getByIdentifier(GetByIdentifierRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public MailDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<MailDto>(MailDto.class, MailService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * Cette méthode permet d'obtenir par identifiant un mail.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public MailDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link MailService#update(MailUpdateRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(MailUpdateRequestDto request) {
    return new IdentifiableExecutor(MailService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * Cette méthode permet de mettre à jour un mail.
   *
   * @param identifier identifiant
   * @param subject sujet
   * @param body corps
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String subject, String body,
      String auditWho, String auditSession) {
    MailUpdateRequestDto request = new MailUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setSubject(subject);
    request.setBody(body);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link MailService#delete(DeleteOneRequestDto)}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(MailService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un mail.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
