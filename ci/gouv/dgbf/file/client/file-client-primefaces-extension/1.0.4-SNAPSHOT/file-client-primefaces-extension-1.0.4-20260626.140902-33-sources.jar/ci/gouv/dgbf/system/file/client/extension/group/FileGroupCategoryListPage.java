package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link FileGroupCategoryDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class FileGroupCategoryListPage extends AbstractPage {

  @Inject
  @Getter
  FileGroupCategoryController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + FileGroupCategoryDto.NAME;
    controller.initialize();
  }

  public static final String OUTCOME = "fileGroupCategoryListPage";
}
