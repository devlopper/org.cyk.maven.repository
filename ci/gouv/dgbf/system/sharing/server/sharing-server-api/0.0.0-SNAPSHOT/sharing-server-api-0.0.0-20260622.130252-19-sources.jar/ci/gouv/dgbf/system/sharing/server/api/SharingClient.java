package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingGetManyResponseDto;
import ci.gouv.dgbf.system.sharing.server.api.SharingService.SharingUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SharingService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SharingClient extends AbstractClient<SharingService>
    implements GetByIdentifier<SharingDto>, GetMany<SharingGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SharingClient service(SharingService service) {
    return (SharingClient) super.service(service);
  }

  /**
   * {@link SharingService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SharingCreateRequestDto request) {
    return new CreateExecutor(SharingService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SharingService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SharingGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SharingGetManyResponseDto>(SharingGetManyResponseDto.class,
        SharingService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SharingService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SharingGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SharingService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SharingDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SharingDto>(SharingDto.class, SharingService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link SharingService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SharingDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Cette méthode permet d'obtenir l'unité administrative par nom d'utilisateur.
   *
   * @param userName nom d'utilisateur
   * @param auditWho audit acteur
   * @return unité administrative
   */
  public SharingDto getAdministrativeUnitByUserName(String userName, String auditWho) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        SharingDto.JSON_RESOURCE_IDENTIFIER, SharingDto.JSON_RESOURCE_REFERENCE,
        SharingDto.JSON_RESOURCE_NAME);
    SharingFilter filter = new SharingFilter();
    filter.setResourceType(ResourceType.ADMINISTRATIVE_UNIT);
    filter.setResourceLocation(Location.BUDGETARY_CLASSIFICATION);
    filter.setUserName(userName);
    request.setFilter(filter.toDto());
    request.setUseFirstResultIfManyGot(true);
    request.setAuditWho(auditWho);
    return getOne(request);
  }

  /**
   * {@link #getAdministrativeUnitByUserName(String, String)}.
   *
   * @param userName nom d'utilisateur
   * @return unité administrative
   */
  public SharingDto getAdministrativeUnitByUserName(String userName) {
    return getAdministrativeUnitByUserName(userName, userName);
  }

  /**
   * {@link SharingService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SharingDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SharingDto>(SharingDto.class,
        SharingService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SharingService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SharingDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SharingService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SharingUpdateRequestDto request) {
    return new IdentifiableExecutor(SharingService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SharingService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SharingService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SharingService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
