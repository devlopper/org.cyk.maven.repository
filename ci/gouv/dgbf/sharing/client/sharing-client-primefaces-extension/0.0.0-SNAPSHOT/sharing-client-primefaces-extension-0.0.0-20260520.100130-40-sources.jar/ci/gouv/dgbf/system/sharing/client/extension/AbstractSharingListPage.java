package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Classe de base pour toutes les pages de liste Sharing.
 */
abstract class AbstractSharingListPage extends AbstractPage {

  @Inject
  @Getter
  protected SharingController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = buildTitle();
    controller.initialize();
  }

  protected String buildTitle() {
    return "Liste " + SharingDto.NAME;
  }
}
