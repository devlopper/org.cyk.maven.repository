package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDefaultConstantAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultConstantIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie de constante.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ConstantCategoryDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasDefaultConstantIdentifierDto,
    HasDefaultConstantAsStringDto, HasGroupIdentifierDto, HasFromDateDto<LocalDateTime>,
    HasToDateDto<LocalDateTime> {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  @JsonbProperty(JSON_DEFAULT_CONSTANT_IDENTIFIER)
  private String defaultConstantIdentifier;

  @JsonbProperty(JSON_DEFAULT_CONSTANT_AS_STRING)
  private String defaultConstantAsString;
  
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;

  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCategorieConstante";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "categorieConstanteChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie de constante";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories de constante";
}
