package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasInputtedAmountN1}.
 *
 * @author Christian
 */
public interface HasInputtedAmountN1Dto extends HasInputtedAmountN1 {

  /**
   * Identifiant json du montant saisi à l'horizon N1.
   */
  String JSON_INPUTTED_AMOUNT_N1 = "montantSaisiN1";
}