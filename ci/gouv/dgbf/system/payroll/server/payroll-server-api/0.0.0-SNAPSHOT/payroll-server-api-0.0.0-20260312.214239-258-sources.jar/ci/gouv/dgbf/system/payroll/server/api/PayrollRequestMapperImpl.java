package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollDto}.
*
* @author A.K.M
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-12T21:43:27+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollRequestMapperImpl implements PayrollRequestMapper {

    @Override
    public PayrollService.PayrollCreateRequestDto mapCreate(PayrollDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollService.PayrollCreateRequestDto payrollCreateRequestDto = new PayrollService.PayrollCreateRequestDto();

        payrollCreateRequestDto.setPeriodGroupIdentifier( arg0.getPeriodGroupIdentifier() );
        payrollCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        payrollCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollCreateRequestDto.setStartDate( arg0.getStartDate() );
        payrollCreateRequestDto.setEndDate( arg0.getEndDate() );

        return payrollCreateRequestDto;
    }

    @Override
    public PayrollService.PayrollUpdateRequestDto mapUpdate(PayrollDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollService.PayrollUpdateRequestDto payrollUpdateRequestDto = new PayrollService.PayrollUpdateRequestDto();

        payrollUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollUpdateRequestDto.setPeriodGroupIdentifier( arg0.getPeriodGroupIdentifier() );
        payrollUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        payrollUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollUpdateRequestDto.setStartDate( arg0.getStartDate() );
        payrollUpdateRequestDto.setEndDate( arg0.getEndDate() );

        return payrollUpdateRequestDto;
    }
}
