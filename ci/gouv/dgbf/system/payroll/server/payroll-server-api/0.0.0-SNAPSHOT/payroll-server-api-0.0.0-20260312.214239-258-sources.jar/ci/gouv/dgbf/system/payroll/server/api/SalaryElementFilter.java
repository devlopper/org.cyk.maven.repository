package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SalaryElementDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class SalaryElementFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du groupe d'éléments de salaire.
   */
  String salaryElementGroupIdentifier;

  /**
   * Est un élément de salaire de gain.
   */
  Boolean isEarning;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SalaryElementFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SalaryElementFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    salaryElementGroupIdentifier = getSalaryElementGroupIdentifier(filter);
    isEarning = getIsEarning(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setSalaryElementGroupIdentifier(filter, salaryElementGroupIdentifier);
    setIsEarning(filter, isEarning);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe d'éléments de salaire.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setSalaryElementGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_SALARY_ELEMENT_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe d'éléments de salaire.
   *
   * @param filter filtre
   * @return identifiant du groupe d'éléments de salaire
   */
  public static String getSalaryElementGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SALARY_ELEMENT_GROUP_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner est gain.
   *
   * @param filter {@link FilterDto}
   * @param isEarning est gain
   */
  public static void setIsEarning(FilterDto filter, Boolean isEarning) {
    set(filter, JSON_IS_EARNING, f -> f.getValueAsString(), f -> f.setValueAsBoolean(isEarning));
  }

  /**
   * Cette méthode permet d'obtenir est gain.
   *
   * @param filter {@link FilterDto}
   * @return vrai si est gain sinon faux
   */
  public static Boolean getIsEarning(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_EARNING));
  }

  /**
   * Identifiant json champ {@link SalaryElementFilter#salaryElementGroupIdentifier}.
   */
  public static final String JSON_SALARY_ELEMENT_GROUP_IDENTIFIER =
          SalaryElementDto.JSON_SALARY_ELEMENT_GROUP_IDENTIFIER;

  /**
   * Identifiant json {@link #isEarning}.
   */
  public static final String JSON_IS_EARNING = SalaryElementDto.JSON_IS_EARNING;

}
