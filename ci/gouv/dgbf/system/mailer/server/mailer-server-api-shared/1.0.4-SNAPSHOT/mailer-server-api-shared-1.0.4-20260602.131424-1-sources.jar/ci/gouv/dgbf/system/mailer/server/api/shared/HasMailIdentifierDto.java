package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de mail.
 *
 * @author Christian
 */
public interface HasMailIdentifierDto extends HasMailIdentifier {

  /**
   * Identifiant json de l'identifiant du mail.
   */
  String JSON_MAIL_IDENTIFIER = "idMail";
}