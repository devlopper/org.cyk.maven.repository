/*
 * Panneau de navigation du maitre-detail (constitution-ui.md, paragraphe 3.8).
 * PrimeFaces 13 ne rend pas l'attribut filterPlaceholder de la colonne : le champ de recherche du panneau
 * n'avait aucune indication. Le texte est porte par data-filter-placeholder (layout/listdetail/main.xhtml) et
 * pose sur le champ au chargement et apres chaque mise a jour Ajax (filtre, pagination).
 */
(function () {
  function placeholders() {
    document.querySelectorAll('.dgbf-list-detail-panel').forEach(function (panel) {
      var text = panel.getAttribute('data-filter-placeholder');
      if (!text) {
        return;
      }
      panel.querySelectorAll('input.ui-column-filter').forEach(function (input) {
        if (!input.getAttribute('placeholder')) {
          input.setAttribute('placeholder', text);
        }
      });
    });
  }

  document.addEventListener('DOMContentLoaded', placeholders);
  if (window.jQuery) {
    window.jQuery(document).on('pfAjaxComplete', placeholders);
  }
})();
