package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.validation.constraints.NotEmpty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un ticket .
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TicketDto extends AbstractIdentifiableAuditableDto {


  /**
   * Identifiant de {@link SupportTeamMemberDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER)
  private String supportTeamMemberIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamMemberDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_MEMBER_AS_STRING)
  private String supportTeamMemberAsString;

  /**
   * Identifiant de {@link TicketPriorityDto}.
   */
  @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
  private String priorityIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link TicketPriorityDto}.
   */
  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;

  /**
   * {@link TicketStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private TicketStatus status;

  /**
   * Représentation en chaine de caractères de {@link TicketStatus}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant de {@link TicketCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link TicketCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  /**
   * reference.
   */
  @JsonbProperty(JSON_REFERENCE)
  private String reference;

  /**
   *  objet.
   */
  @JsonbProperty(JSON_OBJECT)
  private String object;

  /**
   * description.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * commentaire statut .
   */
  @JsonbProperty(JSON_STATUS_COMMENT)
  private String statusComment;

  /**
   * Identifiant diagnotic .
   */
  @JsonbProperty(JSON_DIAGNOSIS)
  private String diagnosis;

  /**
   * actions réalisées .
   */
  @JsonbProperty(JSON_ACTIONS_PERFORMED)
  private String actionsPerformed;

  /**
   * Identifiant solution .
   */
  @JsonbProperty(JSON_SOLUTION)
  private String solution;

  /**
   * Nom du fichier.
   */
  @JsonbProperty(JSON_FILE_NAME)
  private String fileName;

  /**
   * Type de contenu du fichier.
   */
  @JsonbProperty(JSON_FILE_CONTENT_TYPE)
  private String fileContentType;

  /**
   * Octets.
   */

  @NotEmpty
  @JsonbProperty(value = JSON_FILE_BYTES)
  private byte[] fileBytes;

  /**
   * Identifiant identifiant identité de l'identifiant de groupe de fichiers .
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * pris en charge.
   */
  @JsonbProperty(JSON_IN_PROGRESS)
  private Boolean inProgress;

  /**
   * résolu.
   */
  @JsonbProperty(JSON_RESOLVED)
  private Boolean resolved;

  /**
   * satisfait.
   */
  @JsonbProperty(JSON_SATISFIED)
  private Boolean satisfied;

  /**
   * non satisfait.
   */
  @JsonbProperty(JSON_UNSATISFIED)
  private Boolean unsatisfied;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTicket";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "ticketChaine";


  /**
   * Identifiant champ java {@link #supportTeamMemberIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER =
      SupportTeamMemberDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamMemberAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_MEMBER_AS_STRING =
      SupportTeamMemberDto.JSON_THIS_AS_STRING;


  /**
   * Identifiant champ java {@link #priorityIdentifier}.
   */
  public static final String JSON_PRIORITY_IDENTIFIER =
      TicketPriorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #priorityAsString}.
   */
  public static final String JSON_PRIORITY_AS_STRING = TicketPriorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER =
      TicketCategoryDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = TicketCategoryDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant champ java {@link #reference}.
   */
  public static final String JSON_REFERENCE = "reference";

  /**
   * Identifiant champ java {@link #object}.
   */
  public static final String JSON_OBJECT = "objet";

  /**
   * Identifiant champ java {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant champ java {@link #statusComment}.
   */
  public static final String JSON_STATUS_COMMENT = "commentaireStatut";

  /**
   * Identifiant champ java {@link #diagnosis}.
   */
  public static final String JSON_DIAGNOSIS = "diagnostic";

  /**
   * Identifiant champ java {@link #actionsPerformed}.
   */
  public static final String JSON_ACTIONS_PERFORMED = "actionsRealisees";

  /**
   * Identifiant champ java {@link #solution}.
   */
  public static final String JSON_SOLUTION = "solution";

  /**
   * Identifiant champ java {@link #fileName}.
   */
  public static final String JSON_FILE_NAME = "nomFichier";
  /**
   * Identifiant champ java {@link #fileContentType}.
   */
  public static final String JSON_FILE_CONTENT_TYPE = "typeContenuFichier";

  /**
   * Identifiant champ java {@link #fileBytes}.
   */
  public static final String JSON_FILE_BYTES = "octetsFichier";

  /**
   * Identifiant champ java {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "identifiantGroupeFichiers";

  /**
   * Identifiant json champ {@link #inProgress}.
   */
  public static final String JSON_IN_PROGRESS = "prisEnCharge";

  /**
   * Identifiant json champ {@link #resolved}.
   */
  public static final String JSON_RESOLVED = "resolu";

  /**
   * Identifiant json champ {@link #satisfied}.
   */
  public static final String JSON_SATISFIED = "satisfait";

  /**
   * Identifiant json champ {@link #unsatisfied}.
   */
  public static final String JSON_UNSATISFIED = "insatisfait";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ticket";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

}
