package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetChartRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetChart;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service {@link FileDashboardService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileDashboardClient extends AbstractClient<FileDashboardService>
    implements GetChart<GetChartResponseDto> {

  @Override
  public FileDashboardClient service(FileDashboardService service) {
    return (FileDashboardClient) super.service(service);
  }

  /**
   * {@link FileDashboardService#getChart}.
   *
   * @param request requête
   * @return réponse
   */
  public GetChartResponseDto getChart(GetChartRequestDto request) {
    return new GetOneExecutor<GetChartResponseDto>(GetChartResponseDto.class,
        FileDashboardService.GET_CHART_IDENTIFIER)
            .execute(() -> service().getChart(request));
  }

  /**
   * {@link FileDashboardService#getChart}.
   *
   * @param filter filtre ({@link FileDashboardFilter#toDto()})
   * @param auditActor audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetChartResponseDto getChart(FilterDto filter, String auditActor,
      String auditSession) {
    GetChartRequestDto request = new GetChartRequestDto();
    request.setFilter(filter);
    request.setAuditWho(auditActor);
    request.setAuditSession(auditSession);
    return getChart(request);
  }
}
