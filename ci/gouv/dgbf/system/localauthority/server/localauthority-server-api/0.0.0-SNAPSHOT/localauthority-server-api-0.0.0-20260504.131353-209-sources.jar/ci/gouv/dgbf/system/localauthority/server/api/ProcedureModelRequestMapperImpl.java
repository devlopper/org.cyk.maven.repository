package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcedureModelDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-04T13:14:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcedureModelRequestMapperImpl implements ProcedureModelRequestMapper {

    @Override
    public ProcedureModelService.ProcedureModelCreateRequestDto mapCreate(ProcedureModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureModelService.ProcedureModelCreateRequestDto procedureModelCreateRequestDto = new ProcedureModelService.ProcedureModelCreateRequestDto();

        procedureModelCreateRequestDto.setName( arg0.getName() );
        procedureModelCreateRequestDto.setOrder( arg0.getOrder() );

        return procedureModelCreateRequestDto;
    }

    @Override
    public ProcedureModelService.ProcedureModelUpdateRequestDto mapUpdate(ProcedureModelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureModelService.ProcedureModelUpdateRequestDto procedureModelUpdateRequestDto = new ProcedureModelService.ProcedureModelUpdateRequestDto();

        procedureModelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        procedureModelUpdateRequestDto.setName( arg0.getName() );
        procedureModelUpdateRequestDto.setOrder( arg0.getOrder() );

        return procedureModelUpdateRequestDto;
    }
}
