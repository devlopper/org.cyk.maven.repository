package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de source de financement.
 *
 * @author Christian
 */
public interface HasFundingSourceAsStringDto extends HasFundingSourceAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la source de financement.
   */
  String JSON_FUNDING_SOURCE_AS_STRING = "sourceFinancementChaine";
}
