package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureNatureService.GetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ExpenditureNatureService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ExpenditureNatureClient extends AbstractClient<ExpenditureNatureService>
    implements GetByIdentifier<ExpenditureNatureDto>, GetMany<GetManyResponseDto> {

  @Override
  public ExpenditureNatureClient service(ExpenditureNatureService service) {
    return (ExpenditureNatureClient) super.service(service);
  }

  /**
   * {@link ExpenditureNatureService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        ExpenditureNatureService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ExpenditureNatureService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ExpenditureNatureService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ExpenditureNatureDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ExpenditureNatureDto>(ExpenditureNatureDto.class,
        ExpenditureNatureService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ExpenditureNatureService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ExpenditureNatureDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
