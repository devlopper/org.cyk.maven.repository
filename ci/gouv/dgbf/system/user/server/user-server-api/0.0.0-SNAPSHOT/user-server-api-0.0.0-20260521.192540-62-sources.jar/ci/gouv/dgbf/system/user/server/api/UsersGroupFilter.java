package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UsersGroupDto}.
 *
 * @author kimou
 *
 */
@Getter
@Setter
public class UsersGroupFilter extends AbstractIdentifiableFilter {
  
}
