package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProcedureModelDto}.
 *
 * @author Desysoft
 */
@Path(value = ProcedureModelService.PATH)
@Tag(name = "Gestion des modeles de procédure")
public interface ProcedureModelService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "modeles-de-procedure";


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_MODELE_PROCEDURE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";
  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MODELE_PROCEDURE";
  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";
  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MODELE_PROCEDURE";
  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";
  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MODELE_PROCEDURE";
  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";
  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MODELE_PROCEDURE";
  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";
  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MODELE_PROCEDURE";
  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProcedureModelCreateRequestDto request);

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = ProcedureModelGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette méthode permet d'obtenir {@link ProcedureModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureModelDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Cette méthode permet d'obtenir par identrifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureModelDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcedureModelUpdateRequestDto request);

  /**
   * Cette méthode permet de supprimer {@link ProcedureModelDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Christian
   */
  interface ProcedureModelSaveRequestDto {

    /**
     * Identifiant json du champ d'ordre.
     */
    String JSON_ORDER = ProcedureModelDto.JSON_ORDER;

    /**
     * Cette méthode permet d'obtenir l'ordre de {@link ProcedureModelDto}.
     *
     * @return order de {@link ProcedureModelDto}
     */
    Integer getOrder();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ProcedureModelDto}.
     *
     * @param order identifiant de {@link ProcedureModelDto}
     */
    void setOrder(Integer order);

  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcedureModelCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ProcedureModelSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;

  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProcedureModelGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcedureModelDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcedureModelDto> datas;
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcedureModelUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ProcedureModelSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;

  }
}
