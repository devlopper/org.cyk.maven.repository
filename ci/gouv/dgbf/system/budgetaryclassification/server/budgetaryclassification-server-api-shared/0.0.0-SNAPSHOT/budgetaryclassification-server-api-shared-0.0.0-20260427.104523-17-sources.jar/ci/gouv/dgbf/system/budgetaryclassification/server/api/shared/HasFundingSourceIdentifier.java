package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de source de financement.
 *
 * @author Christian
 */
public interface HasFundingSourceIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la source de financement.
   *
   * @return identifiant de la source de financement
   */
  String getFundingSourceIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la source de financement.
   *
   * @param identifier identifiant de la source de financement
   */
  void setFundingSourceIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de la source de financement.
   */
  String FIELD_FUNDING_SOURCE_IDENTIFIER = "fundingSourceIdentifier";
}
