package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link HierarchyDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-14T17:33:09+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class HierarchyRequestMapperImpl implements HierarchyRequestMapper {

    @Override
    public HierarchyService.HierarchyCreateRequestDto mapCreate(HierarchyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        HierarchyService.HierarchyCreateRequestDto hierarchyCreateRequestDto = new HierarchyService.HierarchyCreateRequestDto();

        hierarchyCreateRequestDto.setCode( arg0.getCode() );
        hierarchyCreateRequestDto.setName( arg0.getName() );
        hierarchyCreateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return hierarchyCreateRequestDto;
    }

    @Override
    public HierarchyService.HierarchyUpdateRequestDto mapUpdate(HierarchyDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        HierarchyService.HierarchyUpdateRequestDto hierarchyUpdateRequestDto = new HierarchyService.HierarchyUpdateRequestDto();

        hierarchyUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        hierarchyUpdateRequestDto.setCode( arg0.getCode() );
        hierarchyUpdateRequestDto.setName( arg0.getName() );
        hierarchyUpdateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return hierarchyUpdateRequestDto;
    }
}
