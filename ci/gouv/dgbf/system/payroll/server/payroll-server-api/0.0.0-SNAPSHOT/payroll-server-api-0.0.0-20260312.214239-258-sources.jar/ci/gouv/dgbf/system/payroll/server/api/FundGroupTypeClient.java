package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link FundGroupTypeService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class FundGroupTypeClient extends AbstractClient<FundGroupTypeService> implements
    GetByIdentifier<FundGroupTypeDto>, GetMany<FundGroupTypeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FundGroupTypeClient service(FundGroupTypeService service) {
    return (FundGroupTypeClient) super.service(service);
  }

  /**
   * {@link FundGroupTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FundGroupTypeCreateRequestDto request) {
    return new CreateExecutor(FundGroupTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FundGroupTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FundGroupTypeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FundGroupTypeGetManyResponseDto>(
        FundGroupTypeGetManyResponseDto.class, FundGroupTypeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link FundGroupTypeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FundGroupTypeGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FundGroupTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FundGroupTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FundGroupTypeDto>(FundGroupTypeDto.class,
        FundGroupTypeService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FundGroupTypeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FundGroupTypeDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FundGroupTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FundGroupTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FundGroupTypeDto>(FundGroupTypeDto.class,
        FundGroupTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FundGroupTypeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FundGroupTypeDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FundGroupTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FundGroupTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(FundGroupTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FundGroupTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FundGroupTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FundGroupTypeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
