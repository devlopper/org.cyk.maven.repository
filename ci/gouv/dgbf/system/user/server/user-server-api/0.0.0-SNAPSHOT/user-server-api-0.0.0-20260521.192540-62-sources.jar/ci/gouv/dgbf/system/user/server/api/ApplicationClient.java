package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ApplicationService}.
 *
 * @author Boobacool
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ApplicationClient extends AbstractClient<ApplicationService>
    implements GetByIdentifier<ApplicationDto>,
    GetMany<ApplicationService.ApplicationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ApplicationClient service(ApplicationService service) {
    return (ApplicationClient) super.service(service);
  }

  /**
   * {@link ApplicationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ApplicationService.ApplicationCreateRequestDto request) {
    return new CreateExecutor(ApplicationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ApplicationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ApplicationService.ApplicationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ApplicationService.ApplicationGetManyResponseDto>(
        ApplicationService.ApplicationGetManyResponseDto.class,
        ApplicationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ApplicationService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ApplicationService.ApplicationGetManyResponseDto getMany(ProjectionDto projection,
                                                                  FilterDto filter,
                                                                  PageDto page, String auditWho,
                                                                  String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ApplicationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ApplicationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ApplicationDto>(ApplicationDto.class,
        ApplicationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ApplicationService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ApplicationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                               String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ApplicationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ApplicationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ApplicationDto>(ApplicationDto.class,
        ApplicationService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ApplicationService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ApplicationDto getByIdentifier(String identifier, ProjectionDto projection,
                                        String auditWho,
                                        String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ApplicationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(
      ApplicationService.ApplicationUpdateRequestDto request) {
    return new IdentifiableExecutor(ApplicationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ApplicationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ApplicationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ApplicationService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ApplicationService#assignAdministrator}.
   *
   * @param request requête
   * @return réponse
   */
  public ApplicationService.ApplicationAssignAdministratorResponseDto assignAdministrator(
      ApplicationService.ApplicationAssignAdministratorRequestDto request) {
    return new GetOneExecutor<ApplicationService.ApplicationAssignAdministratorResponseDto>(
        ApplicationService.ApplicationAssignAdministratorResponseDto.class,
        ApplicationService.ASSIGN_ADMINISTRATOR_IDENTIFIER)
        .execute(() -> service().assignAdministrator(request));
  }
}
