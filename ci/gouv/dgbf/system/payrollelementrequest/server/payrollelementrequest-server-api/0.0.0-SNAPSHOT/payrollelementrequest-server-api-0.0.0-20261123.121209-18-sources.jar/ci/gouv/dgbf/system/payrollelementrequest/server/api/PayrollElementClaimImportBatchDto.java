package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un Lot d'Import de réclamations (RG_REP_SOU_12) : le regroupement de
 * traçabilité créé par le dépôt d'un fichier. Il ne porte aucun statut propre (RG_REP_SOU_14) :
 * sa progression se lit en agrégeant les statuts des réclamations qui le composent. Lecture
 * seule : le Lot naît uniquement du traitement d'un fichier.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimImportBatchDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de l'émetteur du Lot, le tiers habilité qui a déposé le fichier.
   */
  @JsonbProperty(JSON_SUBMITTER_IDENTIFIER)
  private String submitterIdentifier;

  /**
   * Nom du fichier déposé.
   */
  @JsonbProperty(JSON_FILE_NAME)
  private String fileName;

  /**
   * Date et heure du dépôt.
   */
  @JsonbProperty(JSON_DEPOSIT_DATE)
  private LocalDateTime depositDate;

  /**
   * Période du FUR : premier jour du mois que le fichier concerne.
   */
  @JsonbProperty(JSON_PERIOD)
  private LocalDate period;

  /**
   * Type de FUR, c'est-à-dire sa source : fonction publique, police, etc.
   */
  @JsonbProperty(JSON_FUR_TYPE)
  private String furType;

  /**
   * Nature du fichier : {@link #NATURE_INITIAL}, {@link #NATURE_ADDITIVE} ou
   * {@link #NATURE_CORRECTIVE}.
   */
  @JsonbProperty(JSON_NATURE)
  private String nature;

  /**
   * Identifiant du Lot que celui-ci complète ou corrige, {@code null} pour un fichier initial.
   */
  @JsonbProperty(JSON_PARENT_IDENTIFIER)
  private String parentIdentifier;

  /**
   * État du Lot : {@link #STATE_DEPOSITED} ou {@link #STATE_PROCESSED}.
   */
  @JsonbProperty(JSON_STATE)
  private String state;

  /**
   * Nombre de lignes d'origine que le fichier déposé porte, {@code null} pour un Lot créé avant
   * l'ajout de cette colonne.
   */
  @JsonbProperty(JSON_EXPECTED_ORIGIN_LINE_COUNT)
  private Integer expectedOriginLineCount;

  /**
   * Identifiant json {@link #submitterIdentifier}.
   */
  public static final String JSON_SUBMITTER_IDENTIFIER = "idEmetteur";

  /**
   * Identifiant json {@link #fileName}.
   */
  public static final String JSON_FILE_NAME = "fichier";

  /**
   * Identifiant json {@link #depositDate}.
   */
  public static final String JSON_DEPOSIT_DATE = "dateDepot";

  /**
   * Identifiant json {@link #period}.
   */
  public static final String JSON_PERIOD = "periode";

  /**
   * Identifiant json {@link #furType}.
   */
  public static final String JSON_FUR_TYPE = "typeFur";

  /**
   * Identifiant json {@link #nature}.
   */
  public static final String JSON_NATURE = "nature";

  /**
   * Identifiant json {@link #parentIdentifier}.
   */
  public static final String JSON_PARENT_IDENTIFIER = "idLotParent";

  /**
   * Identifiant json {@link #state}.
   */
  public static final String JSON_STATE = "etat";

  /**
   * Identifiant json {@link #expectedOriginLineCount}.
   */
  public static final String JSON_EXPECTED_ORIGIN_LINE_COUNT = "lignesOrigineAttendues";

  /**
   * État d'un Lot dont le fichier est conservé et dont aucune réclamation n'est générée.
   */
  public static final String STATE_DEPOSITED = "DEPOSE";

  /**
   * État d'un Lot dont la génération a été lancée au moins une fois.
   */
  public static final String STATE_PROCESSED = "TRAITE";

  /**
   * Nature d'un fichier FUR initial du mois.
   */
  public static final String NATURE_INITIAL = "INITIAL";

  /**
   * Nature d'un fichier FUR additif, du même mois qu'un fichier déjà déposé.
   */
  public static final String NATURE_ADDITIVE = "ADDITIF";

  /**
   * Nature d'un fichier de corrections renvoyé par la Fonction publique.
   */
  public static final String NATURE_CORRECTIVE = "CORRECTIF";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "lot d'import";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "lots d'import";
}
