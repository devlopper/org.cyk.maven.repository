package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationLockAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationLockIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasExerciseIdentifierDto, HasExerciseAsStringDto, HasTypeIdentifierDto,
    HasTypeAsStringDto, HasStatusDto<ProgrammingStatus>, HasStatusAsStringDto,
    HasImputationLockIdentifierDto, HasImputationLockAsStringDto {

  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  @JsonbProperty(JSON_STATUS)
  private ProgrammingStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_IMPUTATION_LOCK_IDENTIFIER)
  private String imputationLockIdentifier;

  @JsonbProperty(JSON_IMPUTATION_LOCK_AS_STRING)
  private String imputationLockAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "programmationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "programmations";

}
