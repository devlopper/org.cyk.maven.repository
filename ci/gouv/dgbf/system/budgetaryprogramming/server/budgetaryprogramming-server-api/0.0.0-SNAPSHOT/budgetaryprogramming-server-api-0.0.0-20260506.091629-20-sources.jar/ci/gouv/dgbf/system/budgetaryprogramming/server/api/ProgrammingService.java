package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingService.PATH)
@Tag(name = "Gestion des Programmations")
public interface ProgrammingService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "programmations";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ProgrammingExerciseDto}.
     *
     * @return identifiant de {@link ProgrammingExerciseDto}
     */
    String getExerciseIdentifier();

    /**
     * Définit l'identifiant de {@link ProgrammingExerciseDto}.
     *
     * @param exerciseIdentifier l'identifiant de {@link ProgrammingExerciseDto}
     */
    void setExerciseIdentifier(String exerciseIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ProgrammingTypeDto}.
     *
     * @return identifiant de {@link ProgrammingTypeDto}
     */
    String getTypeIdentifier();

    /**
     * Définit l'identifiant de {@link ProgrammingTypeDto}.
     *
     * @param typeIdentifier l'identifiant de {@link ProgrammingTypeDto}
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ImputationLockDto}.
     *
     * @return identifiant de {@link ImputationLockDto}
     */
    String getImputationLockIdentifier();

    /**
     * Définit l'identifiant de {@link ImputationLockDto}.
     *
     * @param imputationLockIdentifier l'identifiant de {@link ImputationLockDto}
     */
    void setImputationLockIdentifier(String imputationLockIdentifier);

    /**
     * Identifiant de {@link ProgrammingExerciseDto}.
     */
    String JSON_EXERCISE_IDENTIFIER = ProgrammingDto.JSON_EXERCISE_IDENTIFIER;

    /**
     * Identifiant de {@link ProgrammingTypeDto}.
     */
    String JSON_TYPE_IDENTIFIER = ProgrammingDto.JSON_TYPE_IDENTIFIER;

    /**
     * Identifiant de {@link ImputationLockDto}.
     */
    String JSON_IMPUTATION_LOCK_IDENTIFIER = ProgrammingDto.JSON_IMPUTATION_LOCK_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_IMPUTATION_LOCK_IDENTIFIER)
    private String imputationLockIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProgrammingDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingSaveRequestDto {

    @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
    private String exerciseIdentifier;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;

    @JsonbProperty(JSON_IMPUTATION_LOCK_IDENTIFIER)
    private String imputationLockIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
