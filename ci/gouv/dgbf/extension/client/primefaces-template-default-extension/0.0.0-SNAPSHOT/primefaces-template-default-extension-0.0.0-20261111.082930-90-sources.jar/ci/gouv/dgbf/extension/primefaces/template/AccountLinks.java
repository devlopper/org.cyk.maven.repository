package ci.gouv.dgbf.extension.primefaces.template;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Cette classe calcule les liens vers les écrans « de compte » hébergés par un autre module
 * (constitution-client-quarkus-primefaces.md §5.5) : Mon profil (module user) et Mon activité
 * (module logging).
 *
 * <p>Les applications d'un environnement sont servies par un même hôte, sous des contextes
 * différents (https://hôte/utilisateur, https://hôte/logging). Le lien se déduit donc de l'adresse
 * de la requête en cours, sans variable d'environnement : il vaut dans chaque environnement. Une
 * adresse configurée l'emporte (poste de développement, où chaque application a son port).
 *
 * @author Christian
 */
public final class AccountLinks {
  static final String KEYCLOAK_ACCOUNT_PASSWORD_PATH = "/account/password";
  private static final int HTTP_PORT = 80;
  private static final int HTTPS_PORT = 443;

  private AccountLinks() {}

  /**
   * Construit le lien vers l'écran « Mot de passe et sécurité » de la console de compte Keycloak,
   * avec les paramètres {@code referrer} et {@code referrer_uri} permettant le retour à
   * l'application appelante.
   *
   * @param configured adresse configurée prioritaire, ou null / vide
   * @param authServerUrl URL du royaume OIDC ({@code quarkus.oidc.auth-server-url}), ou null / vide
   * @param clientId identifiant du client OIDC ({@code quarkus.oidc.client-id}), ou null / vide
   * @param scheme protocole public de la requête, ou null hors requête HTTP
   * @param serverName nom d'hôte de la requête, ou null hors requête HTTP
   * @param port port public de la requête
   * @param currentContextPath contexte de l'application courante
   * @return le lien complet, ou null si ni {@code configured} ni {@code authServerUrl} ne sont
   *         renseignés
   */
  public static String resolveSecurity(String configured, String authServerUrl, String clientId,
      String scheme, String serverName, int port, String currentContextPath) {
    String base = resolveSecurityBase(configured, authServerUrl);
    if (base == null || clientId == null || clientId.isBlank()) {
      return base;
    }
    String result = base + (base.contains("?") ? '&' : '?') + "referrer="
        + URLEncoder.encode(clientId.strip(), StandardCharsets.UTF_8);
    if (scheme == null || serverName == null) {
      return result;
    }
    String current = currentContextPath == null ? "" : currentContextPath;
    String referrerUri = origin(scheme, serverName, port) + current;
    return result + "&referrer_uri=" + URLEncoder.encode(referrerUri, StandardCharsets.UTF_8);
  }

  private static String resolveSecurityBase(String configured, String authServerUrl) {
    if (configured != null && !configured.isBlank()) {
      return configured.strip();
    }
    if (authServerUrl == null || authServerUrl.isBlank()) {
      return null;
    }
    String server = authServerUrl.strip();
    if (server.endsWith("/")) {
      server = server.substring(0, server.length() - 1);
    }
    return server + KEYCLOAK_ACCOUNT_PASSWORD_PATH;
  }

  /**
   * Cette méthode donne le lien vers une page d'un autre module.
   *
   * @param configured adresse configurée, ou null / vide pour la déduire
   * @param scheme protocole de la requête (http, https)
   * @param serverName nom d'hôte de la requête
   * @param port port de la requête
   * @param currentContextPath contexte de l'application courante (vide si elle est à la racine)
   * @param targetContextPath contexte de l'application qui héberge la page
   * @param targetPath chemin de la page dans l'application qui l'héberge (commence par « / »)
   * @return le lien ; relatif à l'hôte si l'application courante est l'hébergeur, absolu sinon
   */
  public static String resolve(String configured, String scheme, String serverName, int port,
      String currentContextPath, String targetContextPath, String targetPath) {
    if (configured != null && !configured.isBlank()) {
      return configured.strip();
    }
    String current = currentContextPath == null ? "" : currentContextPath;
    if (current.equals(targetContextPath)) {
      return current + targetPath;
    }
    return origin(scheme, serverName, port) + targetContextPath + targetPath;
  }

  /**
   * Construit un lien vers un hébergeur en transportant l'application d'origine.
   * L'hébergeur doit valider cette adresse contre sa liste blanche avant de l'afficher.
   */
  public static String resolveWithReturn(String configured, String scheme, String serverName,
      int port, String currentContextPath, String targetContextPath, String targetPath) {
    String link = resolve(configured, scheme, serverName, port, currentContextPath,
        targetContextPath, targetPath);
    String current = currentContextPath == null ? "" : currentContextPath;
    if (current.equals(targetContextPath)) {
      return link;
    }
    String returnUrl = origin(scheme, serverName, port) + current;
    return link + (link.contains("?") ? '&' : '?') + "return="
        + URLEncoder.encode(returnUrl, StandardCharsets.UTF_8);
  }

  static String origin(String scheme, String serverName, int port) {
    boolean defaultPort = port <= 0 || ("http".equalsIgnoreCase(scheme) && port == HTTP_PORT)
        || ("https".equalsIgnoreCase(scheme) && port == HTTPS_PORT);
    return scheme + "://" + serverName + (defaultPort ? "" : ":" + port);
  }
}
