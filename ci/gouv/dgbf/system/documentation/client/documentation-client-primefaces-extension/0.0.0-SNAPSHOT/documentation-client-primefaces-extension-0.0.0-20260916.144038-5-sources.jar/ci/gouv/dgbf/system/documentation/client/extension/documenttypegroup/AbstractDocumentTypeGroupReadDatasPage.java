package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.DataTable;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.primefaces.component.layout.ListDetailLayoutController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.client.DocumentationIconManager;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base de page de liste de données de
 * {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 *
 */
public abstract class AbstractDocumentTypeGroupReadDatasPage extends AbstractPage {

  @Inject
  DocumentTypeGroupClient client;

  @Getter
  DocumentTypeGroupDto instance;

  @Getter
  LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  @Getter
  DocumentTypeGroupTabMenuController tabMenuController;

  @Inject
  DocumentationIconManager iconManager;

  @Inject
  @Getter
  ListDetailLayoutController listDetailLayoutController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Lecture " + DocumentTypeGroupDto.NAME;
    instance = client.getByIdentifier(getRequestParameterIdentifier(),
        new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            HasTypeAsStringDto.JSON_TYPE_AS_STRING,
            HasGroupAsStringDto.JSON_GROUP_AS_STRING),
        userIdentifier, null);

    buildLabelValueGroupsInformationCard();

    tabMenuController.setInstance(instance);
    tabMenuController.initialize();

    listDetailLayoutController.instantiateDetailsAsLazyDataModel(DocumentTypeGroupDto.class,
        client, userIdentifier);

    listDetailLayoutController.initialize();
  }

  void buildLabelValueGroupsInformationCard() {
    DocumentTypeGroupLabelValueGroupsInformationCardBuilder builder =
        new DocumentTypeGroupLabelValueGroupsInformationCardBuilder(iconManager);
    builder.type(instance.getTypeAsString());
    builder.group(instance.getGroupAsString());
    labelValueGroupsInformationCard = builder.build();
  }

  void configureDataTable(DataTable dataTable) {
    dataTable.setHeaderRendered(false);
    dataTable.getFilterButton().setRendered(false);
    dataTable.getExportButton().setRendered(false);
  }
}
