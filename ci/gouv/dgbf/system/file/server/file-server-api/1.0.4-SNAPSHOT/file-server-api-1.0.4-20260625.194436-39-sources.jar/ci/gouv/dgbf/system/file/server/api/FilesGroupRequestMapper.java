package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FilesGroupDto}.

    @author Christian
               """)
public interface FilesGroupRequestMapper
    extends RequestMapper<FilesGroupDto, FilesGroupCreateRequestDto, FilesGroupUpdateRequestDto> {

}
