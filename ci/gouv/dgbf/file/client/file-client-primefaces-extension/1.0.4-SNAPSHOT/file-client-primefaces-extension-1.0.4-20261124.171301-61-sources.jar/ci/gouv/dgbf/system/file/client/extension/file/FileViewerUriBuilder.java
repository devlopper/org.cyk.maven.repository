package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasOwnerIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.ViewerUriBuilder;
import ci.gouv.dgbf.extension.primefaces.ViewerUriBuilder.Parameters;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.system.file.server.api.ContentForm;
import jakarta.annotation.PostConstruct;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.net.URI;
import lombok.Getter;

/**
 * Cette classe représente un constructeur d'URI de visualisateur de fichier, piloté par la forme
 * du contenu (RG_FILE_FIC_18, spec-api § 9.6). Rejette toute tentative de construction pour un
 * fichier descriptif.
 *
 * @author Christian
 *
 */
@Dependent
public class FileViewerUriBuilder {

  @Getter
  @Inject
  ViewerUriBuilder uriBuilder;

  @PostConstruct
  void postConstruct() {
    uriBuilder.setServletPath(PATH);
    uriBuilder.initialize("file");
  }

  /**
   * Cette méthode permet de construire l'URI du visualisateur de fichier.
   *
   * @return URI
   */
  public URI build(String identifier, String ownerIdentifier, String auditWho,
      String auditSession) {
    return build(identifier, ownerIdentifier, null, auditWho, auditSession);
  }

  /**
   * Cette méthode permet de construire l'URI du visualisateur de fichier selon la forme du contenu.
   *
   * @param identifier identifiant
   * @param ownerIdentifier identifiant propriétaire
   * @param contentForm forme du contenu (rejeté si DESCRIPTIF)
   * @param auditWho utilisateur
   * @param auditSession session
   * @return URI
   */
  public URI build(String identifier, String ownerIdentifier, ContentForm contentForm,
      String auditWho, String auditSession) {
    validate(identifier, contentForm);
    Parameters parameters = new Parameters();
    parameters.auditWho(auditWho);
    parameters.auditSession(auditSession);
    parameters.queryBuilder().map().add(ByIdentifierRequestDto.JSON_IDENTIFIER, identifier);
    parameters.queryBuilder().map().add(HasOwnerIdentifierDto.JSON_OWNER_IDENTIFIER,
        ownerIdentifier);
    return uriBuilder.build(parameters);
  }

  void validate(String identifier) {
    validate(identifier, null);
  }

  void validate(String identifier, ContentForm contentForm) {
    if (Core.isStringBlank(identifier)) {
      throw new IllegalArgumentException("L'identifiant du fichier est obligatoire");
    }
    if (ContentForm.DESCRIPTIVE.equals(contentForm)) {
      throw new IllegalArgumentException(
          "Un fichier descriptif ne peut pas être ouvert dans le visualisateur");
    }
  }

  public static final String PATH = "fileviewer";
}
