package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurOrganismService.FurOrganismCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurOrganismService.FurOrganismGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurOrganismService.FurOrganismUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link FurOrganismService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class FurOrganismClient extends AbstractClient<FurOrganismService>
    implements GetByIdentifier<FurOrganismDto>,
    GetMany<FurOrganismGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FurOrganismClient service(FurOrganismService service) {
    return (FurOrganismClient) super.service(service);
  }

  /**
   * {@link FurOrganismService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FurOrganismGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FurOrganismGetManyResponseDto>(
        FurOrganismGetManyResponseDto.class,
        FurOrganismService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FurOrganismService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FurOrganismGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FurOrganismService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FurOrganismCreateRequestDto request) {
    return new CreateExecutor(FurOrganismService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FurOrganismService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FurOrganismUpdateRequestDto request) {
    return new IdentifiableExecutor(FurOrganismService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FurOrganismService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FurOrganismDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FurOrganismDto>(FurOrganismDto.class,
        FurOrganismService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FurOrganismService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FurOrganismDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FurOrganismService#getByIdentifier}.
   *
   * @param request requête
   * @return dépendance entre réclamables
   */
  public FurOrganismDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FurOrganismDto>(FurOrganismDto.class,
        FurOrganismService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FurOrganismService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FurOrganismDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FurOrganismService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FurOrganismService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FurOrganismService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
