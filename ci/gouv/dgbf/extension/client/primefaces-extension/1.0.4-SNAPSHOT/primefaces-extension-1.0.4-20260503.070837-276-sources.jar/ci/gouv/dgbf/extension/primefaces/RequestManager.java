package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.faces.context.FacesContext;
import java.util.HashSet;
import java.util.Set;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le gestionnaire de requête.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class RequestManager {

  static final String PARAMETER_REDIRECT_URL_NAME = "urlRedirection";

  Set<String> sessionableNames = new HashSet<>();

  public RequestManager() {
    sessionableNames.add(PARAMETER_REDIRECT_URL_NAME);
  }

  public String getParameterRedirectUrl() {
    return getParameter(PARAMETER_REDIRECT_URL_NAME);
  }

  public String getParameter(String name) {
    return getParameter(new GetParameterArguments().name(name));
  }

  /**
   * Cette méthode permet d'obtenir la valeur d'un paramètre.
   *
   * @param arguments {@link GetParameterArguments}
   * @return valeur
   */
  String getParameter(GetParameterArguments arguments) {
    if (arguments == null || Core.isStringBlank(arguments.name)) {
      return null;
    }
    String value = getParameterValue(arguments.name);
    if (isGetParameterFromSession(value, arguments)) {
      value = (String) FacesContext.getCurrentInstance().getExternalContext().getSessionMap()
          .get(arguments.name);
    }
    return value;
  }

  public static String getParameterValue(String name) {
    return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap()
        .get(name);
  }

  boolean isGetParameterFromSession(String value, GetParameterArguments arguments) {
    return Core.isStringBlank(value) && arguments.isSessionable();
  }

  public GetParameterArguments getParameterArguments() {
    return new GetParameterArguments();
  }

  /**
   * Cette classe représente les paramètres d'obtention de valeur de paramètre.
   *
   * @author Christian
   *
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  class GetParameterArguments {
    String name;
    Boolean sessionable;

    /**
     * Cette méthode permet d'exécuter {RequestManager#get}.
     *
     * @return valeur
     */
    public String execute() {
      return getParameter(this);
    }

    boolean isSessionable() {
      return sessionable == null ? sessionableNames.contains(name) : sessionable;
    }
  }
}
