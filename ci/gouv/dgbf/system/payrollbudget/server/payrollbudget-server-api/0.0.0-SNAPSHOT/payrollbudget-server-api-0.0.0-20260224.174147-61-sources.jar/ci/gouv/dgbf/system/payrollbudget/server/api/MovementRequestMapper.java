package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementService.MovementCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementService.MovementUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link MovementDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link MovementDto}.

    @author Christian
               """)
public interface MovementRequestMapper
    extends RequestMapper<MovementDto, MovementCreateRequestDto, MovementUpdateRequestDto> {

}
