package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link LessorDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LessorFilter extends AbstractIdentifiableFilter {
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public LessorFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public LessorFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
  }
}
