package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.AbstractTabMenuController;
import ci.gouv.dgbf.extension.server.service.api.filter.StatusCodeFilter;
import ci.gouv.dgbf.system.identity.server.api.EmailAddressDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityEmailAddressStatus;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de menu en onglet de collection de
 * {@link EmailAddressDto}.
 *
 * @author Christian
 */
@Dependent
public class EmailAddressCollectionTabMenuController extends AbstractTabMenuController {

  @Getter
  @Inject
  IconManager iconManager;

  @Getter
  String statucCodeParameterName;

  /**
   * Cette méthode permet de construire.
   */
  public EmailAddressCollectionTabMenuController() {
    menu.setMenuItemStyleClassPrefix("email-address");
    addPage(EmailAddressListPage.class, EmailAddressListPage.OUTCOME);
    statucCodeParameterName = StatusCodeFilter.JSON_KEY;
  }

  @Override
  protected void addMenuTabs() {
    super.addMenuTabs();

    menu.tabBuilder().menuItemValue("Tout").type(EmailAddressListPage.class)
        .menuItemIcon("pi pi-list").build();

    addMenuTabsFromStatuses();
  }

  void addMenuTabsFromStatuses() {
    addMenuTabsFromStatuses(IdentityEmailAddressStatus.VERIFIED, "pi pi-thumbs-up-fill");
    addMenuTabsFromStatuses(IdentityEmailAddressStatus.CREATED, "pi pi-question-circle");
    addMenuTabsFromStatuses(IdentityEmailAddressStatus.REVOKED, "pi pi-thumbs-down");
  }

  void addMenuTabsFromStatuses(IdentityEmailAddressStatus status, String icon) {
    menu.tabBuilder().menuItemValue(String.valueOf(status.getName())).menuItemIcon(icon)
        .type(EmailAddressListPage.class)
        .addMenuItemParameter(statucCodeParameterName, status.getCode()).build();
  }
}
