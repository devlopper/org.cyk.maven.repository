package ci.gouv.dgbf.extension.primefaces;

/**
 * Cette interface représente la session d'un utilisateur.
 *
 * @author Christian
 *
 */
public interface UserSession {

  User getUser();

  String getUserIdentifier();

  String logout();

  default boolean hasRole(Object role) {
    return User.hasRole(getUser(), role);
  }
}
