package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.RoleClient;
import ci.gouv.dgbf.system.identity.server.api.RoleDto;
import ci.gouv.dgbf.system.identity.server.api.RoleService.RoleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RoleDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class RoleSelectOneController
    extends AbstractSelectOneIdentifiableController<RoleDto, RoleGetManyResponseDto, RoleClient> {

  @Inject
  @Getter
  RoleClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected RoleSelectOneController() {
    super(RoleDto.class, SelectItemLabelStrategy.NAME);
  }
}
