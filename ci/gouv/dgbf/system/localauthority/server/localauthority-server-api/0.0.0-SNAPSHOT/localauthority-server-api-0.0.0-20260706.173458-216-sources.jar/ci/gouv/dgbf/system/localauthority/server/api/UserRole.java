package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.core.segregation.CodableByStringWithGetterOnly;
import lombok.Getter;

/**
 * Cette énumération représente les rôles des utilisateurs.
 *
 * @author Christian
 *
 */
@Getter
public enum UserRole implements CodableByStringWithGetterOnly {

  // --- Actions ---

  // Activité

  /**
   * Gérer {@link ActivityDto}.
   */
  MANAGE_ACTIVITY("GERER_ACTIVITE"),

  // Programme triennal.

  /**
   * Gérer {@link TriennialProgramDto}.
   */
  MANAGE_TRIENNIAL_PROGRAM("GERER_PROGRAMME_TRIENNAL"),

  /**
   * Saisir {@link TriennialProgramDto}.
   */
  INPUT_TRIENNIAL_PROGRAM("SAISIR_PROGRAMME_TRIENNAL"),

  /**
   * Transmettre {@link TriennialProgramDto}.
   */
  TRANSMIT_TRIENNIAL_PROGRAM("TRANSMETTRE_PROGRAMME_TRIENNAL"),

  /**
   * Valider {@link TriennialProgramDto}.
   */
  VALIDATE_TRIENNIAL_PROGRAM("VALIDER_PROGRAMME_TRIENNAL"),

  /**
   * Approuver {@link TriennialProgramDto}.
   */
  APPROVE_TRIENNIAL_PROGRAM("APPROUVER_PROGRAMME_TRIENNAL"),

  // Activité de programme triennal

  /**
   * Gérer {@link ActivityDto}.
   */
  MANAGE_TRIENNIAL_PROGRAM_ACTIVITY("GERER_PROGRAMME_TRIENNAL_ACTIVITE"),

  // Financemment

  /**
   * Commenter {@link FundingDto}.
   */
  COMMENT_FUNDING("COMMENTER_FINANCEMENT"),

  // --- Groupe d'actions ---

  /**
   * Agent technique.
   */
  TECHNICAL_AGENT("AGENT_TECHNIQUE"),
  
  /**
   * Responsable technique.
   */
  TECHNICAL_MANAGER("RESPONSABLE_TECHNIQUE"),
  
  /**
   * Validateur.
   */
  VALIDATOR("VALIDATEUR"),
  
  /**
   * Approbateur.
   */
  APPROVER("APPROBATEUR");
  
  private UserRole(String code) {
    this.code = code;
  }

  /**
   * Code.
   */
  String code;
}
