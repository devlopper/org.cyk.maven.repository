package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe de periode de paie.
 *
 * @author arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollPeriodGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link PayrollPeriodGroupDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupePeriodePaie";

  
  /**
   * Identifiant json de représentation en chaine de caractères de {@link PayrollPeriodGroupDto}.
   */
  public static final String JSON_THIS_AS_STRING = "groupePeriodePaieChaine";

  /**
   * Identifiant json {@link PayrollPeriodGroupDto#orderNumber}.
   */
  public static final String JSON_ORDER_NUMBER = "numeroOrdre";

  /**
   * Numéro d'ordre {@link PayrollPeriodGroupDto}.
   */
  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe période paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes de périodes de paie";
}
