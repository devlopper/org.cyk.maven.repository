package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères d'unité
 * administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'unité
   * administrative.
   *
   * @return représentation en chaine de caractères de l'unité administrative
   */
  String getAdministrativeUnitAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'unité
   * administrative.
   *
   * @param asString représentation en chaine de caractères de l'unité administrative
   */
  void setAdministrativeUnitAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'unité administrative.
   */
  String FIELD_ADMINISTRATIVE_UNIT_AS_STRING = "administrativeUnitAsString";
}
