package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.Service;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link EmployeePayrollComponentDto}.
 *
 * @author Christian
 *
 */
@Path(EmployeePayrollComponentService.PATH)
@Tag(name = "Gestion des postes de paie d'employé")
public interface EmployeePayrollComponentService extends Service {

  /**
   * Chemin de base.
   */
  String PATH = "postes-paies-employes";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_PAIE_EMPLOYE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class EmployeePayrollComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<EmployeePayrollComponentDto> {

    @JsonbProperty(JSON_DATAS)
    private List<EmployeePayrollComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_POSTE_PAIE_EMPLOYE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_PAIE_EMPLOYE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link EmployeePayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = EmployeePayrollComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette classe représente la requête de création de plusieurs postes de paie.
   *
   * @author misat
   *
   */
  @Getter
  @Setter
  class CreateManyRequestDto extends AbstractAuditedRequestJsonDto {

    @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER)
    private String administrativeUnitEmployeeIdentifier;

    @JsonbProperty(JSON_PAYROLL_COMPONENTS)
    private List<ProjectionDto> payrollComponents;
    
    /**
     * Cette classe représente la projection des postes de paie.
     */
    @Getter
    @Setter
    public static class ProjectionDto {
      /**
       * Identifiant du poste de paie.
       */
      @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
      private String payrollComponentIdentifier;

      /**
       * Montant.
       */
      @JsonbProperty(JSON_AMOUNT)
      private Integer amount;

      /**
       * Identifiant json champ {@link #payrollComponentIdentifier}.
       */
      static final String JSON_PAYROLL_COMPONENT_IDENTIFIER = "idPostePaie";

      /**
       * Identifiant json champ {@link #amount}.
       */
      static final String JSON_AMOUNT = "montant";
    }

    /**
     * Identifiant json de l'identifiant de {@link AdministrativeUnitEmployeeDto}.
     */
    static final String JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER =
        PayrollComponentProjectionDto.JSON_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER;

    /**
     * Identifiant json des postes de paie.
     */
    static final String JSON_PAYROLL_COMPONENTS = "postesPaie";

  }

  /**
   * Identifiant du service de création de plusieurs.
   */
  String CREATE_MANY_IDENTIFIER = "CREATION_PLUSIEURS_POSTE_PAIE_EMPLOYE";

  /**
   * Chemin du service de création de plusieurs.
   */
  String CREATE_MANY_PATH = "plusieurs";

  /**
   * Cette méthode permet de créer plusieurs {@link EmployeePayrollComponentDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_MANY_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateManyRequestDto.class))})
  Response createMany(CreateManyRequestDto request);
}
