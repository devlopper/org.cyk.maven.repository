package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.ReimbursementScheduleService.GetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.ReimbursementScheduleService.ReimbursementScheduleUpdateAmountRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.ReimbursementScheduleService.ReimbursementScheduleUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ReimbursementScheduleService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ReimbursementScheduleClient extends AbstractClient<ReimbursementScheduleService>
    implements GetByIdentifier<ReimbursementScheduleDto>, GetMany<GetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ReimbursementScheduleClient service(ReimbursementScheduleService service) {
    return (ReimbursementScheduleClient) super.service(service);
  }

  /**
   * {@link ReimbursementScheduleService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(
      ReimbursementScheduleService.ReimbursementScheduleCreateRequestDto request) {
    return new CreateExecutor(ReimbursementScheduleService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ReimbursementScheduleService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        ReimbursementScheduleService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ReimbursementScheduleService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
                                    String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ReimbursementScheduleService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ReimbursementScheduleDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ReimbursementScheduleDto>(ReimbursementScheduleDto.class,
        ReimbursementScheduleService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link ReimbursementScheduleService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReimbursementScheduleDto getOne(ProjectionDto projection, FilterDto filter,
                                         String auditWho,
                                         String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ReimbursementScheduleService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ReimbursementScheduleDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ReimbursementScheduleDto>(ReimbursementScheduleDto.class,
        ReimbursementScheduleService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ReimbursementScheduleService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReimbursementScheduleDto getByIdentifier(String identifier, ProjectionDto projection,
                                                  String auditWho,
                                                  String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ReimbursementScheduleService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ReimbursementScheduleUpdateRequestDto request) {
    return new IdentifiableExecutor(ReimbursementScheduleService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ReimbursementScheduleService#updateAmount}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateAmount(ReimbursementScheduleUpdateAmountRequestDto request) {
    return new IdentifiableExecutor(ReimbursementScheduleService.UPDATE_AMOUNT_IDENTIFIER)
        .execute(() -> service().updateAmount(request));
  }

  /**
   * {@link ReimbursementScheduleService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ReimbursementScheduleService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ReimbursementScheduleService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

