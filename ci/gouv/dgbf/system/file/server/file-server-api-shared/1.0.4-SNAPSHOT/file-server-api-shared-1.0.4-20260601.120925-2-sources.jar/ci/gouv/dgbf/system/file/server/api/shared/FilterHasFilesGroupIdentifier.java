package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de groupe de fichiers.
 *
 * @author Christian
 */
public interface FilterHasFilesGroupIdentifier extends HasFilesGroupIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe de fichiers.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilesGroupIdentifier(FilterDto filter) {
    setFilesGroupIdentifier(FilesGroupIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe de fichiers de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterFilesGroupIdentifier(FilterDto filter) {
    FilesGroupIdentifierFilter.set(filter, getFilesGroupIdentifier());
  }

}
