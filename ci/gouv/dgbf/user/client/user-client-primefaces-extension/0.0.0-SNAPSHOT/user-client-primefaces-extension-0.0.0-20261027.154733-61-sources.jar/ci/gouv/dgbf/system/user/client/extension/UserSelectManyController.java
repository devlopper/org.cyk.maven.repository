package ci.gouv.dgbf.system.user.client.extension;


import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectManyIdentifiableController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur d'autocomplete de {@link UserDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class UserSelectManyController extends
    AbstractSelectManyIdentifiableController<UserDto, UserGetManyResponseDto, UserClient> {

  @Inject
  @Getter
  UserClient client;

  /**
   * Cette méthode permet de construire.
   */
  public UserSelectManyController() {
    super(UserDto.class);
  }

  /**
   * Cette méthode permet de proposer les utilisateurs dont le nom contient la saisie.
   *
   * @param query            saisie
   * @param actorIdentifier  identifiant de l'acteur (audit)
   * @return les utilisateurs correspondants (20 au plus), vide si la saisie est vide
   */
  public List<UserDto> complete(String query, String actorIdentifier) {
    if (query == null || query.trim().isEmpty()) {
      return List.of();
    }
    UserFilter filter = new UserFilter();
    filter.setNameContains("%" + query + "%");
    PageDto page = new PageDto();
    page.setIndex(0);
    page.setSize(20);
    ProjectionDto projection = new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER, AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING);
    UserGetManyResponseDto response =
        client.getMany(projection, filter.toDto(), page, actorIdentifier, null);
    return response != null && response.getDatas() != null ? response.getDatas() : List.of();
  }
}
