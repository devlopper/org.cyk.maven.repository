package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionUnitService.SectionUnitUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SectionUnitDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SectionUnitDto}.

    @author stephane
               """)
public interface SectionUnitRequestMapper extends RequestMapper<SectionUnitDto,
    SectionUnitCreateRequestDto, SectionUnitUpdateRequestDto> {

}
