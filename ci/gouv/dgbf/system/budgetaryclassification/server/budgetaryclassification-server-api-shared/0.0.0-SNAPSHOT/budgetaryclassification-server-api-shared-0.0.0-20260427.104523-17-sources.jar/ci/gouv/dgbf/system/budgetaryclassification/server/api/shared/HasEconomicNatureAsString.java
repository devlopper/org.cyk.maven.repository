package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de la nature économique.
 *
 * @author Arnaud
 */
public interface HasEconomicNatureAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères
   * de la nature économique.
   *
   * @return représentation en chaine de caractères de la nature économique
   */
  String getEconomicNatureAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères
   * de la nature économique.
   *
   * @param asString représentation en chaine de caractères de la nature économique
   */
  void setEconomicNatureAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de la nature économique.
   */
  String FIELD_ECONOMIC_NATURE_AS_STRING = "economicNatureAsString";
}
