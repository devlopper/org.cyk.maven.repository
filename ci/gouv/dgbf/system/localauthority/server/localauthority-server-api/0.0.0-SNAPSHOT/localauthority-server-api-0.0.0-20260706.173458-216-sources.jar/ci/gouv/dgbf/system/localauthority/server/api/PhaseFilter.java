package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PhaseDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class PhaseFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link TriennialProgramActivityDto}.
   */
  String triennialProgramActivityIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PhaseFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PhaseFilter() {}
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    triennialProgramActivityIdentifier = getTriennialProgramActivityIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTriennialProgramActivityIdentifier(filter, triennialProgramActivityIdentifier);
  }


  /**
   * Cette méthode permet d'obtenir l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @return identifiant {@link TriennialProgramActivityDto}
   */
  public static String getTriennialProgramActivityIdentifier(FilterDto filter) {
    return get(filter,
        d -> d.getFieldValueAsStringByName(JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link TriennialProgramActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link TriennialProgramActivityDto}
   */
  public static void setTriennialProgramActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }


  /**
   * Identifiant json champ {@link #triennialProgramActivityIdentifier}.
   */
  public static final String JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER =
      PhaseDto.JSON_TRIENNIAL_PROGRAM_ACTIVITY_IDENTIFIER;
}
