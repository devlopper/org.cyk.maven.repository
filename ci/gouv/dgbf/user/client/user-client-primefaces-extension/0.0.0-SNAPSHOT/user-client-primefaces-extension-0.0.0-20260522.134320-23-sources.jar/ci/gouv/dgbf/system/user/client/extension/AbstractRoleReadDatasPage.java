package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la classe dont herite les autres classes.
 *
 * @author Arnaud
 *
 */
public abstract class AbstractRoleReadDatasPage extends AbstractPage {

  @Inject
  protected RoleClient client;

  @Getter
  protected RoleDto role;

  @Inject
  @Getter
  protected RoleTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + RoleDto.NAME;
    String identifier = getRequestParameterIdentifier();

    role = client.getByIdentifier(identifier, instantiateProjection(), userIdentifier, null);

    tabMenuController.role = role;
    tabMenuController.initialize();
  }

  /**
   * Cette méthode permet d'instancier {@link ProjectionDto}.
   *
   * @return {@link ProjectionDto}
   */
  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        RoleDto.JSON_DESCRIPTION, RoleDto.JSON_APPLICATION_AS_STRING);
  }
}
