package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de verrou d'imputation.
 *
 * @author Christian
 */
public interface HasImputationLockIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant du verrou d'imputation.
   *
   * @return identifiant du verrou d'imputation
   */
  String getImputationLockIdentifier();
  
  /**
   * Cette méthode permet d'assigner l'identifiant du verrou d'imputation.
   *
   * @param identifier identifiant du verrou d'imputation
   */
  void setImputationLockIdentifier(String identifier);
  
  /**
   * Identifiant java de l'identifiant du verrou d'imputation.
   */
  String FIELD_IMPUTATION_LOCK_IDENTIFIER = "imputationLockIdentifier";
}