/*
 * Indicateur d'attente non bloquant de la charte (constitution-ui.md, paragraphe 3.5), niveau 1.
 *
 * Barre discrete en haut de page, affichee seulement si une requete Ajax dure plus de SHOW_DELAY ms,
 * et maintenue au moins MIN_VISIBLE ms une fois apparue (pas de clignotement). Rien n'est bloque.
 * Le texte d'etat est annonce aux lecteurs d'ecran par une zone role="status".
 * Le niveau 2 (bouton occupe) est natif dans PrimeFaces 13 (classe ui-state-loading) ; la charte
 * n'en ajuste que le rendu (workInProgress.css).
 *
 * Branche par p:ajaxStatus (extension/workInProgress/nonBlocking.xhtml) : start() et stop().
 */
var DgbfWorkInProgress = (function () {
  var SHOW_DELAY = 300;
  var MIN_VISIBLE = 400;
  // Texte annonce aux lecteurs d'ecran (libelle d'interface, en francais).
  var STATUS_TEXT = 'Chargement…';

  var pending = 0;
  var showTimer = null;
  var hideTimer = null;
  var shownAt = 0;

  function toggle(active) {
    var bar = document.getElementById('dgbf-work-in-progress');
    if (bar) {
      bar.classList.toggle('dgbf-work-in-progress-active', active);
    }
    var status = document.getElementById('dgbf-work-in-progress-status');
    if (status) {
      status.textContent = active ? STATUS_TEXT : '';
    }
  }

  function show() {
    showTimer = null;
    shownAt = Date.now();
    toggle(true);
  }

  function hide() {
    hideTimer = null;
    shownAt = 0;
    toggle(false);
  }

  function start() {
    pending++;
    if (hideTimer) {
      // Une nouvelle requete arrive pendant le maintien minimal : la barre reste affichee.
      clearTimeout(hideTimer);
      hideTimer = null;
      return;
    }
    if (!shownAt && !showTimer) {
      showTimer = setTimeout(show, SHOW_DELAY);
    }
  }

  function stop() {
    pending = Math.max(0, pending - 1);
    if (pending > 0) {
      return;
    }
    if (showTimer) {
      // Requete plus rapide que le delai : rien n'a ete montre, rien a masquer.
      clearTimeout(showTimer);
      showTimer = null;
      return;
    }
    if (shownAt) {
      hideTimer = setTimeout(hide, Math.max(0, MIN_VISIBLE - (Date.now() - shownAt)));
    }
  }

  return { start: start, stop: stop };
})();
