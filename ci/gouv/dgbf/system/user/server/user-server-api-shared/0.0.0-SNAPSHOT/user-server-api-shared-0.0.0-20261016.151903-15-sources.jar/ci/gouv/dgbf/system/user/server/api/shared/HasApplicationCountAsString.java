package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'applications sous forme de
 * chaîne.
 *
 * @author Christian Yao Komenan
 */
public interface HasApplicationCountAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'applications sous forme de chaîne.
   *
   * @return le nombre d'applications sous forme de chaîne
   */
  String getApplicationCountAsString();

  /**
   * Cette méthode permet d'assigner le nombre d'applications sous forme de chaîne.
   *
   * @param applicationCountAsString le nombre d'applications sous forme de chaîne
   */
  void setApplicationCountAsString(String applicationCountAsString);

  /**
   * Identifiant java du nombre d'applications sous forme de chaîne.
   */
  String FIELD_APPLICATION_COUNT_AS_STRING = "applicationCountAsString";
}
