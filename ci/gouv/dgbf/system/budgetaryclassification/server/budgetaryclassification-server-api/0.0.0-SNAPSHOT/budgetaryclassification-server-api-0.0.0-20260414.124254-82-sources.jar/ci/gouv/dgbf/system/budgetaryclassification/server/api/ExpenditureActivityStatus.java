package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Statuts de {@link ExpenditureActivityDto}.
 *
 * @author Arnaud
 *
 */
@Getter
public enum ExpenditureActivityStatus {

  /**
   * {@link ExpenditureActivityStatusCode#ACTIVATED}.
   */
  ACTIVATED(ExpenditureActivityStatusCode.ACTIVATED, "Activé", "Activation"),

  /**
   * {@link ExpenditureActivityStatusCode#SUSPENDED}.
   */
  SUSPENDED(ExpenditureActivityStatusCode.SUSPENDED, "Suspendu", "Suspension"),

  /**
   * {@link ExpenditureActivityStatusCode#CLOSED}.

   */
  CLOSED(ExpenditureActivityStatusCode.CLOSED, "Clôturé", "Clôture");

  private final String code;
  private final String name;
  private final String action;
  private Set<ExpenditureActivityStatus> previous;

  ExpenditureActivityStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Obtenir un statut par code.
   */
  public static ExpenditureActivityStatus getByCode(String code) {
    return Stream.of(values())
        .filter(status -> status.getCode().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Unknown code: " + code));
  }

  static {
    // État initial
    ACTIVATED.previous = Collections.emptySet();

    // Suspendre / réactiver
    SUSPENDED.previous = Core.getSet(List.of(ACTIVATED));

    // Suppression possible depuis actif ou suspendu
    CLOSED.previous = Core.getSet(List.of(ACTIVATED, SUSPENDED));
  }
}