package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationCreateManyRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationCreateManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationCreateResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ScriptEvaluationService.ScriptEvaluationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ScriptEvaluationService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ScriptEvaluationClient extends AbstractClient<ScriptEvaluationService>
    implements GetByIdentifier<ScriptEvaluationDto>, GetMany<ScriptEvaluationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ScriptEvaluationClient service(ScriptEvaluationService service) {
    return (ScriptEvaluationClient) super.service(service);
  }

  /**
   * {@link ScriptEvaluationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluationCreateResponseDto create(ScriptEvaluationCreateRequestDto request) {
    return new ScriptEvaluationCreateExecutor().execute(() -> service().create(request));
  }

  /**
   * {@link ScriptEvaluationService#createMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluationCreateManyResponseDto createMany(
      ScriptEvaluationCreateManyRequestDto request) {
    return new ScriptEvaluationCreateManyExecutor().execute(() -> service().createMany(request));
  }

  /**
   * {@link ScriptEvaluationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ScriptEvaluationGetManyResponseDto>(
        ScriptEvaluationGetManyResponseDto.class, ScriptEvaluationService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ScriptEvaluationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptEvaluationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ScriptEvaluationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ScriptEvaluationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ScriptEvaluationDto>(ScriptEvaluationDto.class,
        ScriptEvaluationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ScriptEvaluationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ScriptEvaluationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ScriptEvaluationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ScriptEvaluationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ScriptEvaluationDto>(ScriptEvaluationDto.class,
        ScriptEvaluationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ScriptEvaluationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ScriptEvaluationDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ScriptEvaluationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ScriptEvaluationUpdateRequestDto request) {
    return new IdentifiableExecutor(ScriptEvaluationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ScriptEvaluationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ScriptEvaluationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ScriptEvaluationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * Cette classe représente un exécuteur de création d'un.
   *
   * @author Christian
   */
  class ScriptEvaluationCreateExecutor extends GetOneExecutor<ScriptEvaluationCreateResponseDto> {

    /**
     * Cette méthode permet de construire.
     */
    public ScriptEvaluationCreateExecutor() {
      super(ScriptEvaluationCreateResponseDto.class, ScriptEvaluationService.CREATE_IDENTIFIER);
      expectedResponseStatusCode = Response.Status.CREATED.getStatusCode();
    }

  }

  /**
   * Cette classe représente un exécuteur de création de plusieurs.
   *
   * @author Christian
   */
  class ScriptEvaluationCreateManyExecutor
      extends GetOneExecutor<ScriptEvaluationCreateManyResponseDto> {

    /**
     * Cette méthode permet de construire.
     */
    public ScriptEvaluationCreateManyExecutor() {
      super(ScriptEvaluationCreateManyResponseDto.class,
          ScriptEvaluationService.CREATE_MANY_IDENTIFIER);
      expectedResponseStatusCode = Response.Status.OK.getStatusCode();
    }

  }
}
