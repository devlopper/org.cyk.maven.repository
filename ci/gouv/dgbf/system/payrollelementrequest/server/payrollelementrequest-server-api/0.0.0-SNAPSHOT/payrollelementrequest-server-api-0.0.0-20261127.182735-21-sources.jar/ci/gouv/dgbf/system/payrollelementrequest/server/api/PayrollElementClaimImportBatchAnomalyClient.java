package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchAnomalyService.PayrollElementClaimImportBatchAnomalyExtractionResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchAnomalyService.PayrollElementClaimImportBatchAnomalyGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link PayrollElementClaimImportBatchAnomalyService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class PayrollElementClaimImportBatchAnomalyClient
    extends AbstractClient<PayrollElementClaimImportBatchAnomalyService>
    implements GetMany<PayrollElementClaimImportBatchAnomalyGetManyResponseDto> {

  @Override
  public PayrollElementClaimImportBatchAnomalyClient service(
      PayrollElementClaimImportBatchAnomalyService service) {
    return (PayrollElementClaimImportBatchAnomalyClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimImportBatchAnomalyService#getCount}.
   *
   * @param request requête
   * @return nombre
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(PayrollElementClaimImportBatchAnomalyService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchAnomalyService#extract}.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  public PayrollElementClaimImportBatchAnomalyExtractionResponseDto extract(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchAnomalyExtractionResponseDto>(
        PayrollElementClaimImportBatchAnomalyExtractionResponseDto.class,
        PayrollElementClaimImportBatchAnomalyService.EXTRACT_IDENTIFIER)
            .execute(() -> service().extract(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchAnomalyService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchAnomalyGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchAnomalyGetManyResponseDto>(
        PayrollElementClaimImportBatchAnomalyGetManyResponseDto.class,
        PayrollElementClaimImportBatchAnomalyService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchAnomalyService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimImportBatchAnomalyGetManyResponseDto getMany(
      ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }
}
