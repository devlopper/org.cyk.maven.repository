package ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ServiceClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ServiceDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ServiceService.ServiceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ServiceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ServiceSelectOneController extends AbstractSelectOneIdentifiableController<
    ServiceDto, ServiceGetManyResponseDto, ServiceClient> {

  @Inject
  @Getter
  ServiceClient client;

  protected ServiceSelectOneController() {
    super(ServiceDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
