package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExpenditureItemDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ExpenditureItemFilter extends AbstractExpenditureOrResourceItemFilter {

  /**
   * Identifiant de {@link ExpenditureActivityDto}.
   */
  String activityIdentifier;

  /**
   * Code de {@link ExpenditureActivityDto}.
   */
  String activityCode;

  /**
   * Identifiant de {@link FundingSourceDto}.
   */
  String fundingSourceIdentifier;

  /**
   * Code de {@link FundingSourceDto}.
   */
  String fundingSourceCode;

  /**
   * Identifiant de {@link LessorDto}.
   */
  String lessorIdentifier;

  /**
   * Code de {@link LessorDto}.
   */
  String lessorCode;

  /**
   * Code {@link ExpenditureActivityDto} {@link EconomicNatureDto}.
   */
  String activityAndEconomicNatureCode;

  /**
   * Identifiant de {@link SectionDto}.
   */
  String sectionIdentifier;
  
  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ExpenditureItemFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ExpenditureItemFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    activityIdentifier = getActivityIdentifier(filter);
    activityCode = getActivityCode(filter);
    fundingSourceIdentifier = getFundingSourceIdentifier(filter);
    fundingSourceCode = getFundingSourceCode(filter);
    lessorIdentifier = getLessorIdentifier(filter);
    lessorCode = getLessorCode(filter);
    activityAndEconomicNatureCode = getActivityAndEconomicNatureCode(filter);
    sectionIdentifier = getSectionIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setActivityIdentifier(filter, activityIdentifier);
    setActivityCode(filter, activityCode);
    setFundingSourceIdentifier(filter, fundingSourceIdentifier);
    setFundingSourceCode(filter, fundingSourceCode);
    setLessorIdentifier(filter, lessorIdentifier);
    setLessorCode(filter, lessorCode);
    setActivityAndEconomicNatureCode(filter, activityAndEconomicNatureCode);
    setSectionIdentifier(filter, sectionIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link ExpenditureActivityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setActivityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ACTIVITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link ExpenditureActivityDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link ExpenditureActivityDto}
   */
  public static String getActivityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link ExpenditureActivityDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setActivityCode(FilterDto filter, String code) {
    set(filter, JSON_ACTIVITY_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link ExpenditureActivityDto}.
   *
   * @param filter filtre
   * @return code de {@link ExpenditureActivityDto}
   */
  public static String getActivityCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code {@link ExpenditureActivityDto}
   * {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setActivityAndEconomicNatureCode(FilterDto filter, String code) {
    set(filter, JSON_ACTIVITY_AND_ECONOMIC_NATURE_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code {@link ExpenditureActivityDto}
   * {@link EconomicNatureDto}.
   *
   * @param filter filtre
   * @return code {@link ExpenditureActivityDto} {@link EconomicNatureDto}
   */
  public static String getActivityAndEconomicNatureCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ACTIVITY_AND_ECONOMIC_NATURE_CODE));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link FundingSourceDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setFundingSourceIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FUNDING_SOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link FundingSourceDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link FundingSourceDto}
   */
  public static String getFundingSourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUNDING_SOURCE_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link FundingSourceDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setFundingSourceCode(FilterDto filter, String code) {
    set(filter, JSON_FUNDING_SOURCE_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link FundingSourceDto}.
   *
   * @param filter filtre
   * @return code de {@link FundingSourceDto}
   */
  public static String getFundingSourceCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FUNDING_SOURCE_CODE));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LessorDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setLessorIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_LESSOR_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link LessorDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link LessorDto}
   */
  public static String getLessorIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LESSOR_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le code de {@link LessorDto}.
   *
   * @param filter filtre
   * @param code code
   */
  public static void setLessorCode(FilterDto filter, String code) {
    set(filter, JSON_LESSOR_CODE, f -> f.getValueAsString(), f -> f.setValueAsString(code));
  }

  /**
   * Cette méthode permet d'obtenir le code de {@link LessorDto}.
   *
   * @param filter filtre
   * @return code de {@link LessorDto}
   */
  public static String getLessorCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LESSOR_CODE));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de {@link LessorDto}.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setSectionIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_SECTION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de {@link SectionDto}.
   *
   * @param filter filtre
   * @return identifiant de {@link SectionDto}
   */
  public static String getSectionIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SECTION_IDENTIFIER));
  }
  
  /**
   * Identifiant json champ {@link ExpenditureItemFilter#activityIdentifier}.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = ExpenditureItemDto.JSON_ACTIVITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link ExpenditureItemFilter#activityCode}.
   */
  public static final String JSON_ACTIVITY_CODE = ExpenditureItemDto.JSON_ACTIVITY_CODE;

  /**
   * Identifiant json champ {@link ExpenditureItemFilter#fundingSourceIdentifier}.
   */
  public static final String JSON_FUNDING_SOURCE_IDENTIFIER =
      ExpenditureItemDto.JSON_FUNDING_SOURCE_IDENTIFIER;

  /**
   * Identifiant json champ {@link ExpenditureItemFilter#fundingSourceCode}.
   */
  public static final String JSON_FUNDING_SOURCE_CODE = ExpenditureItemDto.JSON_FUNDING_SOURCE_CODE;

  /**
   * Identifiant json champ {@link ExpenditureItemFilter#lessorIdentifier}.
   */
  public static final String JSON_LESSOR_IDENTIFIER = ExpenditureItemDto.JSON_LESSOR_IDENTIFIER;

  /**
   * Identifiant json champ {@link ExpenditureItemFilter#lessorCode}.
   */
  public static final String JSON_LESSOR_CODE = ExpenditureItemDto.JSON_LESSOR_CODE;
  
  /**
   * Identifiant json champ {@link ExpenditureItemFilter#sectionIdentifier}.
   */
  public static final String JSON_SECTION_IDENTIFIER = SectionDto.JSON_THIS_IDENTIFIER;
}
