package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link ClaimableCascadeHopDto}. N'étend
 * pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link ClaimableCascadeHopDto} n'a ni code ni nom propres.
 *
 * @author akm
 *
 */
@Path(ClaimableCascadeHopService.PATH)
@Tag(name = "Gestion des sauts de cascade de réclamables")
public interface ClaimableCascadeHopService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "sauts-cascades-reclamables";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface ClaimableCascadeHopSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'identifiant de la cascade.
     *
     * @return l'identifiant de la cascade
     */
    String getCascadeDependencyIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la cascade.
     *
     * @param cascadeDependencyIdentifier l'identifiant de la cascade
     */
    void setCascadeDependencyIdentifier(String cascadeDependencyIdentifier);

    /**
     * Cette méthode permet d'obtenir le rang.
     *
     * @return le rang
     */
    Integer getRank();

    /**
     * Cette méthode permet d'assigner le rang.
     *
     * @param rank le rang
     */
    void setRank(Integer rank);

    /**
     * Cette méthode permet d'obtenir la clé du Client.
     *
     * @return la clé du Client
     */
    String getClientKey();

    /**
     * Cette méthode permet d'assigner la clé du Client.
     *
     * @param clientKey la clé du Client
     */
    void setClientKey(String clientKey);

    /**
     * Cette méthode permet d'obtenir la clé du champ critère.
     *
     * @return la clé du champ critère
     */
    String getFilterFieldKey();

    /**
     * Cette méthode permet d'assigner la clé du champ critère.
     *
     * @param filterFieldKey la clé du champ critère
     */
    void setFilterFieldKey(String filterFieldKey);

    /**
     * Cette méthode permet d'obtenir la clé du champ de sortie.
     *
     * @return la clé du champ de sortie
     */
    String getOutputFieldKey();

    /**
     * Cette méthode permet d'assigner la clé du champ de sortie.
     *
     * @param outputFieldKey la clé du champ de sortie
     */
    void setOutputFieldKey(String outputFieldKey);

    /**
     * {@link ClaimableCascadeHopDto#JSON_CASCADE_DEPENDENCY_IDENTIFIER}.
     */
    String JSON_CASCADE_DEPENDENCY_IDENTIFIER =
        ClaimableCascadeHopDto.JSON_CASCADE_DEPENDENCY_IDENTIFIER;

    /**
     * {@link ClaimableCascadeHopDto#JSON_RANK}.
     */
    String JSON_RANK = ClaimableCascadeHopDto.JSON_RANK;

    /**
     * {@link ClaimableCascadeHopDto#JSON_CLIENT_KEY}.
     */
    String JSON_CLIENT_KEY = ClaimableCascadeHopDto.JSON_CLIENT_KEY;

    /**
     * {@link ClaimableCascadeHopDto#JSON_FILTER_FIELD_KEY}.
     */
    String JSON_FILTER_FIELD_KEY = ClaimableCascadeHopDto.JSON_FILTER_FIELD_KEY;

    /**
     * {@link ClaimableCascadeHopDto#JSON_OUTPUT_FIELD_KEY}.
     */
    String JSON_OUTPUT_FIELD_KEY = ClaimableCascadeHopDto.JSON_OUTPUT_FIELD_KEY;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ClaimableCascadeHopDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ClaimableCascadeHopCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableCascadeHopCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ClaimableCascadeHopSaveRequestDto {

    @JsonbProperty(JSON_CASCADE_DEPENDENCY_IDENTIFIER)
    private String cascadeDependencyIdentifier;

    @JsonbProperty(JSON_RANK)
    private Integer rank;

    @JsonbProperty(JSON_CLIENT_KEY)
    private String clientKey;

    @JsonbProperty(JSON_FILTER_FIELD_KEY)
    private String filterFieldKey;

    @JsonbProperty(JSON_OUTPUT_FIELD_KEY)
    private String outputFieldKey;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimableCascadeHopGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimableCascadeHopDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimableCascadeHopDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimableCascadeHopDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimableCascadeHopDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ClaimableCascadeHopDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ClaimableCascadeHopUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimableCascadeHopUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ClaimableCascadeHopSaveRequestDto {

    @JsonbProperty(JSON_CASCADE_DEPENDENCY_IDENTIFIER)
    private String cascadeDependencyIdentifier;

    @JsonbProperty(JSON_RANK)
    private Integer rank;

    @JsonbProperty(JSON_CLIENT_KEY)
    private String clientKey;

    @JsonbProperty(JSON_FILTER_FIELD_KEY)
    private String filterFieldKey;

    @JsonbProperty(JSON_OUTPUT_FIELD_KEY)
    private String outputFieldKey;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_SAUT_CASCADE_RECLAMABLE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ClaimableCascadeHopDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
