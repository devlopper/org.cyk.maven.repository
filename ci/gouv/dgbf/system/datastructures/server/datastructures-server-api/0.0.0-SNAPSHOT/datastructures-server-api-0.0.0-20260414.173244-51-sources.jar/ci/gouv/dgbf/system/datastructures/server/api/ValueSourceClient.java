package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceGetValuesCountResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceGetValuesRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceGetValuesResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSourceService.ValueSourceUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ValueSourceService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ValueSourceClient extends AbstractClient<ValueSourceService>
    implements GetByIdentifier<ValueSourceDto>, GetMany<ValueSourceGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ValueSourceClient service(ValueSourceService service) {
    return (ValueSourceClient) super.service(service);
  }

  /**
   * {@link ValueSourceService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ValueSourceCreateRequestDto request) {
    return new CreateExecutor(ValueSourceService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ValueSourceService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ValueSourceGetManyResponseDto>(ValueSourceGetManyResponseDto.class,
        ValueSourceService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ValueSourceService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSourceGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ValueSourceService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGetValuesResponseDto getValues(ValueSourceGetValuesRequestDto request) {
    return new GetOneExecutor<ValueSourceGetValuesResponseDto>(
        ValueSourceGetValuesResponseDto.class, ValueSourceService.GET_VALUES_IDENTIFIER)
            .execute(() -> service().getValues(request));
  }

  /**
   * {@link ValueSourceService#getValues}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceGetValuesCountResponseDto getValuesCount(ByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSourceGetValuesCountResponseDto>(
        ValueSourceGetValuesCountResponseDto.class, ValueSourceService.GET_VALUES_COUNT_IDENTIFIER)
            .execute(() -> service().getValuesCount(request));
  }

  /**
   * {@link ValueSourceService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSourceDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ValueSourceDto>(ValueSourceDto.class,
        ValueSourceService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ValueSourceService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ValueSourceDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ValueSourceService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ValueSourceDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSourceDto>(ValueSourceDto.class,
        ValueSourceService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ValueSourceService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSourceDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ValueSourceService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ValueSourceUpdateRequestDto request) {
    return new IdentifiableExecutor(ValueSourceService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ValueSourceService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ValueSourceService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ValueSourceService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
