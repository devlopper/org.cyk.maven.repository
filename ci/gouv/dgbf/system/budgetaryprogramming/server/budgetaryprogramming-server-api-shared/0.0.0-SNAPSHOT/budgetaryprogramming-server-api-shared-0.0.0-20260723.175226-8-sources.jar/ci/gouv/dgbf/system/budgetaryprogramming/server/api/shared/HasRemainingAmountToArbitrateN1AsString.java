package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateN1AsString {

  /**
   * Obtient le montant restant à arbitrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant restant à arbitrer pour l'année N+1 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToArbitrateN1AsString();

  /**
   * Définit le montant restant à arbitrer pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToArbitrateN1AsString le montant restant à arbitrer pour l'année N+1
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToArbitrateN1AsString(String remainingAmountToArbitrateN1AsString);

  /**
   * Identifiant java du montant restant à arbitrer pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_ARBITRATE_N1_AS_STRING =
      "remainingAmountToArbitrateN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName