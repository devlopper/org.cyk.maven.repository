package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de d'employé d'unité administrative.
 *
 * @author Christian
 */
public interface HasAdministrativeUnitEmployeeIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant d'employé d'unité administrative.
   *
   * @return identifiant de d'employé d'unité administrative
   */
  String getAdministrativeUnitEmployeeIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant d'employé d'unité administrative.
   *
   * @param identifier identifiant d'employé d'unité administrative
   */
  void setAdministrativeUnitEmployeeIdentifier(String identifier);

  /**
   * Identifiant java de l'identifiant de l'employé de l'unité administrative.
   */
  String FIELD_ADMINISTRATIVE_UNIT_EMPLOYEE_IDENTIFIER = "administrativeUnitEmployeeIdentifier";
}
