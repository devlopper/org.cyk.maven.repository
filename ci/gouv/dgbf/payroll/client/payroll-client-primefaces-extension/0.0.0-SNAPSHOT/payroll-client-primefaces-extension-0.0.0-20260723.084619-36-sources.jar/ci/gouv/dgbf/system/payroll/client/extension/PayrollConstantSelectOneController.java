package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollConstantClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollConstantDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollConstantService.PayrollConstantGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollConstantDto}.
 *
 * @author stephane
 *
 */
@Dependent
public class PayrollConstantSelectOneController extends AbstractSelectOneIdentifiableController<
    PayrollConstantDto, PayrollConstantGetManyResponseDto, PayrollConstantClient> {

  @Getter
  @Inject
  PayrollConstantClient client;

  protected PayrollConstantSelectOneController() {
    super(PayrollConstantDto.class, SelectItemLabelStrategy.NAME);
  }
}
