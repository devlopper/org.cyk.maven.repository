package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/** Confidentialité propre à une ressource. */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ResourceConfidentialityDto extends AbstractIdentifiableAuditableDto {

  public static final String NAME = "confidentialiteRessource";
  public static final String PLURAL_NAME = "confidentialitesRessource";

  @JsonbProperty(JSON_RESOURCE_IDENTIFIER)
  private String resourceIdentifier;

  @JsonbProperty(JSON_RESOURCE_AS_STRING)
  private String resourceAsString;

  @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL)
  private ConfidentialityLevel confidentialityLevel;

  @JsonbProperty(JSON_CONFIDENTIALITY_LEVEL_AS_STRING)
  private String confidentialityLevelAsString;

  public static final String JSON_RESOURCE_IDENTIFIER = SharingDto.JSON_RESOURCE_IDENTIFIER;
  public static final String JSON_RESOURCE_AS_STRING = SharingDto.JSON_RESOURCE_AS_STRING;
  public static final String JSON_CONFIDENTIALITY_LEVEL = "niveauConfidentialite";
  public static final String JSON_CONFIDENTIALITY_LEVEL_AS_STRING = "niveauConfidentialiteChaine";
}
