package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de budget.
 *
 * @author Christian
 */
public interface HasBudgetAsStringDto extends HasBudgetAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de budget.
   */
  String JSON_BUDGET_AS_STRING = "budgetChaine";
}
