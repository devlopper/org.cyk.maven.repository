package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationDto;
import ci.gouv.dgbf.system.logging.server.api.RecordOperationFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link RecordOperationDto}.
 *
 * @author Christian
 */
@Dependent
public class RecordOperationFilterController
    extends AbstractFilterController<RecordOperationFilter> {

  @Inject
  @Getter
  InputTextController processIdentifierInputTextController;

  @Inject
  @Getter
  InputTextController sourceIdentifierInputTextController;

  @Inject
  @Getter
  InputTextController recordIdentifierInputTextController;

  @Inject
  @Getter
  InputTextController userNameInputTextController;

  @Inject
  @Getter
  InputTextController auditSessionInputTextController;

  /**
   * Cette méthode permet d'instantier.
   */
  public RecordOperationFilterController() {
    super(RecordOperationFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();

    processIdentifierInputTextController.setOutputLableValue("Identifiant du processus");
    processIdentifierInputTextController.getInputText()
        .addValueConsumer(identifier -> filter.setProcessIdentifier(identifier));

    sourceIdentifierInputTextController.setOutputLableValue("Identifiant de la source");
    sourceIdentifierInputTextController.getInputText()
        .addValueConsumer(identifier -> filter.setSourceIdentifier(identifier));

    recordIdentifierInputTextController.setOutputLableValue("Identifiant de l'enregistrement");
    recordIdentifierInputTextController.getInputText()
        .addValueConsumer(identifier -> filter.setRecordIdentifier(identifier));

    userNameInputTextController.setOutputLableValue("Nom de l'utilisateur");
    userNameInputTextController.getInputText()
        .addValueConsumer(userName -> filter.setUserName(userName));

    auditSessionInputTextController.setOutputLableValue("Session d'audit");
    auditSessionInputTextController.getInputText()
        .addValueConsumer(session -> filter.setAuditSession(session));
  }
}
