package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.SupplierService.SupplierCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.SupplierService.SupplierGetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.SupplierService.SupplierUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link SupplierService}.
 *
 * @author Christian
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SupplierClient extends AbstractClient<SupplierService>
    implements GetByIdentifier<SupplierDto>, GetMany<SupplierGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SupplierClient service(SupplierService service) {
    return (SupplierClient) super.service(service);
  }

  /**
   * {@link SupplierService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SupplierCreateRequestDto request) {
    return new CreateExecutor(SupplierService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SupplierService#create}.
   *
   * @param code         code
   * @param name         nom
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    SupplierCreateRequestDto request = new SupplierCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link SupplierService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SupplierGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SupplierGetManyResponseDto>(SupplierGetManyResponseDto.class,
        SupplierService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link SupplierService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupplierGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                            PageDto page,
                                            String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SupplierService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SupplierDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SupplierDto>(SupplierDto.class,
        SupplierService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SupplierService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SupplierDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                            String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SupplierService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SupplierDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SupplierDto>(SupplierDto.class,
        SupplierService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SupplierService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SupplierDto getByIdentifier(String identifier, ProjectionDto projection,
                                     String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SupplierService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SupplierUpdateRequestDto request) {
    return new IdentifiableExecutor(SupplierService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SupplierService#update}.
   *
   * @param identifier   identifiant
   * @param name         nom
   * @param code         code
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
                                        String auditWho, String auditSession) {
    SupplierUpdateRequestDto request = new SupplierUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link SupplierService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SupplierService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SupplierService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
