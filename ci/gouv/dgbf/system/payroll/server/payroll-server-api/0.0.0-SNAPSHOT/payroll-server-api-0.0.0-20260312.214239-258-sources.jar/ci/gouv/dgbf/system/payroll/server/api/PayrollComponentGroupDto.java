package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un groupe poste de paie.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollComponentGroupDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idGroupePostePaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "groupePostePaieChaine";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "groupe poste de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "groupes postes de paie";
}
