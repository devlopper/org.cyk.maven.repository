package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketClaimRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketDissatisfyRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketResolveRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketSatisfyRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.TicketService.TicketUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TicketDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TicketDto}.

    @author Arnaud
               """)
public interface TicketRequestMapper
    extends RequestMapper<TicketDto, TicketCreateRequestDto,
     TicketUpdateRequestDto> {

  /**
   * Cette méthode permet de mapper {@link TicketClaimRequestDto}.
   *
   * @param ticket {@link TicketDto}
   * @return {@link TicketClaimRequestDto}
   */
  TicketClaimRequestDto mapClaimRequest(TicketDto ticket);
  
  /**
   * Cette méthode permet de mapper {@link TicketResolveRequestDto}.
   *
   * @param ticket {@link TicketDto}
   * @return {@link TicketResolveRequestDto}
   */
  TicketResolveRequestDto mapResolveRequest(TicketDto ticket);
  
  /**
   * Cette méthode permet de mapper {@link TicketSatisfyRequestDto}.
   *
   * @param ticket {@link TicketDto}
   * @return {@link TicketSatisfyRequestDto}
   */
  TicketSatisfyRequestDto mapSatisfyRequest(TicketDto ticket);
  
  /**
   * Cette méthode permet de mapper {@link TicketDissatisfyRequestDto}.
   *
   * @param ticket {@link TicketDto}
   * @return {@link TicketDissatisfyRequestDto}
   */
  TicketDissatisfyRequestDto mapUnsatisfyRequest(TicketDto ticket);
}
