package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupportLevelDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-22T17:24:13+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupportLevelRequestMapperImpl implements SupportLevelRequestMapper {

    @Override
    public SupportLevelService.SupportLevelCreateRequestDto mapCreate(SupportLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportLevelService.SupportLevelCreateRequestDto supportLevelCreateRequestDto = new SupportLevelService.SupportLevelCreateRequestDto();

        supportLevelCreateRequestDto.setCode( arg0.getCode() );
        supportLevelCreateRequestDto.setName( arg0.getName() );
        supportLevelCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return supportLevelCreateRequestDto;
    }

    @Override
    public SupportLevelService.SupportLevelUpdateRequestDto mapUpdate(SupportLevelDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportLevelService.SupportLevelUpdateRequestDto supportLevelUpdateRequestDto = new SupportLevelService.SupportLevelUpdateRequestDto();

        supportLevelUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportLevelUpdateRequestDto.setCode( arg0.getCode() );
        supportLevelUpdateRequestDto.setName( arg0.getName() );
        supportLevelUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return supportLevelUpdateRequestDto;
    }
}
