package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ReportGroupDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ReportGroupDto}.
    
    @author Desysoft
    """)
public interface ReportGroupRequestMapper
    extends
    RequestMapper<ReportGroupDto,
        ReportGroupService.ReportGroupCreateRequestDto,
        ReportGroupService.ReportGroupUpdateRequestDto> {

}

