package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RoleDto}.
 *
 * @author BoobaCool
 *
 */
@Dependent
public class RoleSelectOneController extends AbstractSelectOneIdentifiableController<
    RoleDto, RoleGetManyResponseDto, RoleClient> {

  @Getter
  @Inject
  RoleClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected RoleSelectOneController() {
    super(RoleDto.class, SelectItemLabelStrategy.NAME);
  }
}
