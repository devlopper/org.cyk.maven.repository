package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionService.PolicyVersionCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionService.PolicyVersionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PolicyVersionDto}.
 *
 * @author Desysoft
 *
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link PolicyVersionDto}.

    @author Desysoft
               """)
public interface PolicyVersionRequestMapper
    extends RequestMapper<PolicyVersionDto, PolicyVersionCreateRequestDto,
        PolicyVersionUpdateRequestDto> {

}
