package ci.gouv.dgbf.system.budgetaryclassification.client.extension.administrative;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubLocalityClient;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubLocalityDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SubLocalityService.GetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SubLocalityDto}.
 *
 * @author akm
 *
 */
@Dependent
public class SubLocalitySelectOneController extends AbstractSelectOneIdentifiableController<
    SubLocalityDto, GetManyResponseDto, SubLocalityClient> {

  @Inject
  @Getter
  SubLocalityClient client;

  protected SubLocalitySelectOneController() {
    super(SubLocalityDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
