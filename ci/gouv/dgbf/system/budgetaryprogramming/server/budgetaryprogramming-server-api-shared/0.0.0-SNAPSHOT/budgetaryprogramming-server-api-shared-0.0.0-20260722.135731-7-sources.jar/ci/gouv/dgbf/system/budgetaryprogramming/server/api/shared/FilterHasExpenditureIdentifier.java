package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de dépense.
 *
 * @author Christian
 */
public interface FilterHasExpenditureIdentifier extends HasExpenditureIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la dépense.
   *
   * @param filter {@link FilterDto}
   */
  default void updateExpenditureIdentifier(FilterDto filter) {
    setExpenditureIdentifier(ExpenditureIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la dépense de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterExpenditureIdentifier(FilterDto filter) {
    ExpenditureIdentifierFilter.set(filter, getExpenditureIdentifier());
  }

}
