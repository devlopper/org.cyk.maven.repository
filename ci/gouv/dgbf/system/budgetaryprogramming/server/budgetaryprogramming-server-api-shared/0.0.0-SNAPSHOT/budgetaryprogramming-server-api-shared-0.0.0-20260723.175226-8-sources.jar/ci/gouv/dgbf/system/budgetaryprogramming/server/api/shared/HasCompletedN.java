package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente la capacité à indiquer si l'année N est complétée.
 *
 * @author Christian
 */
public interface HasCompletedN extends HasField {

  /**
   * Obtient l'indicateur indiquant si l'année N est complétée.
   *
   * @return {@code true} si l'année N est complétée, sinon {@code false}
   */
  Boolean getCompletedN();

  /**
   * Définit l'indicateur indiquant si l'année N est complétée.
   *
   * @param completedN indicateur indiquant si l'année N est complétée
   */
  void setCompletedN(Boolean completedN);

  /**
   * Identifiant java de l'indicateur indiquant si l'année N est complétée.
   */
  String FIELD_COMPLETED_N = "completedN";
}
