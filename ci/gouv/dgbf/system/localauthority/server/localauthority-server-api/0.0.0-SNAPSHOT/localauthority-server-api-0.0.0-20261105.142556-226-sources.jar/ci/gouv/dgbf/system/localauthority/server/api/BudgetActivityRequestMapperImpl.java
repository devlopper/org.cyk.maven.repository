package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetActivityDto}.
*
* @author Donsylla
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-05T14:26:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetActivityRequestMapperImpl implements BudgetActivityRequestMapper {

    @Override
    public BudgetActivityService.BudgetActivityCreateRequestDto mapCreate(BudgetActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetActivityService.BudgetActivityCreateRequestDto budgetActivityCreateRequestDto = new BudgetActivityService.BudgetActivityCreateRequestDto();

        budgetActivityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetActivityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetActivityCreateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        budgetActivityCreateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        budgetActivityCreateRequestDto.setName( arg0.getName() );
        budgetActivityCreateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );
        budgetActivityCreateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        budgetActivityCreateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );

        return budgetActivityCreateRequestDto;
    }

    @Override
    public BudgetActivityService.BudgetActivityUpdateRequestDto mapUpdate(BudgetActivityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetActivityService.BudgetActivityUpdateRequestDto budgetActivityUpdateRequestDto = new BudgetActivityService.BudgetActivityUpdateRequestDto();

        budgetActivityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        budgetActivityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        budgetActivityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetActivityUpdateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        budgetActivityUpdateRequestDto.setActivityIdentifier( arg0.getActivityIdentifier() );
        budgetActivityUpdateRequestDto.setName( arg0.getName() );
        budgetActivityUpdateRequestDto.setActionIdentifier( arg0.getActionIdentifier() );
        budgetActivityUpdateRequestDto.setFunctionalAccountIdentifier( arg0.getFunctionalAccountIdentifier() );
        budgetActivityUpdateRequestDto.setNatureIdentifier( arg0.getNatureIdentifier() );

        return budgetActivityUpdateRequestDto;
    }
}
