package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TemplateDto}.
 *
 * @author Christian
 *
 */
@Path(value = TemplateService.PATH)
@Tag(name = "Gestion des modèles de mail")
public interface TemplateService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "modeles-mail";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface TemplateSaveRequestDto {
  }

  /**
   * Identifiant du service de création unitaire de {@link TemplateDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_MODELE_MAIL";

  /**
   * Chemin du service de création unitaire de {@link TemplateDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TemplateCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link TemplateDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TemplateCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements TemplateSaveRequestDto {
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link TemplateDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_MODELE_MAIL";

  /**
   * Chemin du service d'obtention de plusieurs {@link TemplateDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TemplateGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link TemplateDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class TemplateGetManyResponseDto extends AbstractGetByPageResponseDto<TemplateDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TemplateDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link TemplateDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_MODELE_MAIL";

  /**
   * Chemin du service d'obtention unitaire de {@link TemplateDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TemplateDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link TemplateDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_MODELE_MAIL";

  /**
   * Chemin du service d'obtention par identifiant de {@link TemplateDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TemplateDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  // ========== APERCU DU SUJET ==========

  /**
   * Identifiant du service d'obtention de l'aperçu du sujet de {@link TemplateDto}.
   */
  String GET_SUBJECT_PREVIEW_IDENTIFIER = "OBTENTION_APERCU_SUJET_MODELE_MAIL";

  /**
   * Chemin du service d'obtention de l'aperçu du sujet de {@link TemplateDto}.
   */
  String GET_SUBJECT_PREVIEW_PATH = "obtention/apercu/sujet";

  /**
   * Cette méthode permet d'obtenir l'aperçu du sujet de {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_SUBJECT_PREVIEW_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_SUBJECT_PREVIEW_IDENTIFIER,
      summary = "Obtention de l'aperçu du sujet d'un modèle de mail",
      description = "Ce service permet d'obtenir l'aperçu rendu du sujet "
          + "d'un modèle de mail avec ses valeurs exemples")
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.TEXT_PLAIN)})
  Response getSubjectPreview(ByIdentifierRequestDto request);

  // ========== APERCU DU CORPS ==========

  /**
   * Identifiant du service d'obtention de l'aperçu du corps de {@link TemplateDto}.
   */
  String GET_BODY_PREVIEW_IDENTIFIER = "OBTENTION_APERCU_CORPS_MODELE_MAIL";

  /**
   * Chemin du service d'obtention de l'aperçu du corps de {@link TemplateDto}.
   */
  String GET_BODY_PREVIEW_PATH = "obtention/apercu/corps";

  /**
   * Cette méthode permet d'obtenir l'aperçu du corps de {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BODY_PREVIEW_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces({MediaType.TEXT_HTML, MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_BODY_PREVIEW_IDENTIFIER,
      summary = "Obtention de l'aperçu du corps d'un modèle de mail",
      description = "Ce service permet d'obtenir l'aperçu rendu du corps "
          + "d'un modèle de mail avec ses valeurs exemples. "
          + "Utiliser le header Accept: text/html pour le rendu "
          + "HTML ou Accept: text/plain pour le rendu texte.")
  @APIResponse(responseCode = "200", content = {@Content(mediaType = MediaType.TEXT_HTML),
      @Content(mediaType = MediaType.TEXT_PLAIN)})
  Response getBodyPreview(TemplateGetBodyPreviewRequestDto request);

  /**
   * Cette classe représente la requête d'obtention de l'aperçu du corps de {@link TemplateDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TemplateGetBodyPreviewRequestDto extends ByIdentifierRequestDto {
    
    @JsonbProperty("rendreHtml")
    private Boolean renderAsHtml;
    
  }
  
  /**
   * Identifiant du service de mise à jour unitaire de {@link TemplateDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_MODELE_MAIL";

  /**
   * Chemin du service de mise à jour unitaire de {@link TemplateDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TemplateUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link TemplateDto}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TemplateUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements TemplateSaveRequestDto {
  }

  /**
   * Identifiant du service de suppression unitaire de {@link TemplateDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_MODELE_MAIL";

  /**
   * Chemin du service de suppression unitaire de {@link TemplateDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link TemplateDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
