package ci.gouv.dgbf.system.logging.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.ChartDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.GetChartResponseDto;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventClient;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventDto;
import ci.gouv.dgbf.system.logging.server.api.TraceabilityEventService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/** Contrôleur de consultation du journal transverse. */
@Dependent
public class TraceabilityEventController extends AbstractController {

  @Inject TraceabilityEventClient client;
  @Inject @Getter ListController listController;
  @Inject @Getter TraceabilityEventFilterController filterController;
  private ChartDto chart;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = "Événements de traçabilité";
    initialize();
  }

  /** Initialise la liste et sa projection de lecture. */
  public void initialize() {
    listController.setEntityClass(TraceabilityEventDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(TraceabilityEventService.PATH);
    listController.setFilterController(filterController);
    listController.getReadController().setProjection(new ProjectionDto().addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        "type", "sourceIdentifier", "processIdentifier", "level", "source", "record",
        "operation", "actionType", "containsMaskedData", "messageSummary",
        AbstractIdentifiableAuditableDto.JSON_AUDIT_AS_STRING));
    listController.getDataTable().getFilterButton().setRendered(true);
    listController.initialize();
    listController.getDataTable().getActionColumn().setRendered(false);
    listController.getShowCreateDialogButton().setRendered(false);
    listController.getShowUpdateDialogButton().setRendered(false);
    listController.getDeleteButton().setRendered(false);
  }

  /** Obtient les statistiques correspondant aux filtres courants. */
  public ChartDto getChart() {
    if (chart == null) {
      GetChartResponseDto response = client.getChart(filterController.getFilter().toDto(),
          userIdentifier, null);
      chart = response == null ? null : response.getChart();
    }
    return chart;
  }
}
