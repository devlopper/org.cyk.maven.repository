package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un champ de saisie d'un texte.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class InputText extends AbstractInputText {

}
