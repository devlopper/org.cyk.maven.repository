package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Poste de paie, avec ce qui permet de le situer : sa nature économique et sa catégorie.
 *
 * <p>Le poste est l'unité de rémunération élémentaire — « Indemnité de logement », « Prime de
 * recherche », « Pensions CGRAE part employeur ». Il vit au référentiel de la paie et ne
 * s'administre pas ici : ce contrat le donne à lire, jamais à modifier.</p>
 *
 * <p>La <strong>nature économique</strong> est son imputation budgétaire : c'est elle qu'on
 * retrouve en ligne du tableau des entrées et sorties, sous son code à six chiffres — 663910 pour
 * la prime de recherche, 661100 pour les fonctionnaires de catégorie A. Mille quatre cent
 * dix-huit postes sur mille quatre cent quarante-deux en affichent une, réparties sur
 * trente-neuf natures. Ce lien existait déjà en base ; il n'était modélisé nulle part.</p>
 *
 * <p>Les vingt-quatre autres ne sont pas tous logés à la même enseigne : dix-sept ne portent
 * aucune nature, et sept en désignent une qui a disparu du référentiel. Ce contrat les rend
 * quand même, nature vide : les taire les rendrait introuvables à l'écran, et le défaut de
 * données passerait pour une absence de poste.</p>
 *
 * <p>La <strong>catégorie</strong> regroupe les postes par famille de paie. C'est à elle, et non
 * à la nature économique, que les activités budgétaires se rattachent
 * ({@code TA_CATEGORIE_POSTE_PAIE_ACTIVITE}) — une correction utile à la lecture du modèle :
 * nature et catégorie sont deux axes parallèles du poste, non deux niveaux emboîtés.</p>
 *
 * <p>L'<strong>activité</strong> ne figure pas parmi les attributs du poste, et c'est délibéré :
 * elle se rattache à la catégorie, si bien qu'un poste de « Traitement et salaire » en compte
 * près de mille. La porter ici multiplierait chaque poste par autant. Elle existe en revanche
 * comme <em>critère</em> de recherche, servi par une seconde vue.</p>
 *
 * <p>Ce critère est volontairement ouvert alors que le rattachement des activités aux
 * catégories relève d'un autre module et reste à faire pour cinq catégories sur sept. Il lit
 * la table de liaison en direct : le jour où elle se remplira, ce contrat couvrira les postes
 * nouvellement liés sans qu'une ligne change ici.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollComponentDto extends AbstractIdentifiableCodableNamableDto {

  /**
   * Identifiant de la nature économique du poste.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Code de la nature économique : ce qui apparaît en ligne du tableau des entrées et sorties.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_CODE)
  private String economicNatureCode;

  /**
   * Libellé de la nature économique.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;

  /**
   * Identifiant de la catégorie de poste de paie.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  /**
   * Libellé de la catégorie de poste de paie.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  /**
   * Identifiant de la nature du poste de paie.
   */
  @JsonbProperty(JSON_PAYROLL_NATURE_IDENTIFIER)
  private String payrollNatureIdentifier;

  /**
   * Nature du poste de paie : <em>Normal</em>, <em>Rappel</em> ou <em>Régularisation</em>.
   *
   * <p>La distinction que le tableau des entrées et sorties porte en toutes lettres : il oppose
   * le <em>glissement catégoriel</em> de l'exercice au <em>rappel de glissement</em> de
   * l'exercice précédent, l'un en entrée et l'autre en sortie. Le référentiel de la paie la
   * porte déjà, poste par poste : quatre cent soixante-dix-huit régularisations, quatre cent
   * soixante-seize rappels, quatre cent cinquante-quatre normaux.</p>
   */
  @JsonbProperty(JSON_PAYROLL_NATURE_AS_STRING)
  private String payrollNatureAsString;

  /**
   * Vrai pour un gain, faux pour une retenue.
   */
  @JsonbProperty(JSON_GAIN)
  private Boolean gain;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idPostePaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "postePaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "poste de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "postes de paie";

  /**
   * Identifiant json pour {@link #economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureEconomique";

  /**
   * Identifiant json pour {@link #economicNatureCode}.
   */
  public static final String JSON_ECONOMIC_NATURE_CODE = "codeNatureEconomique";

  /**
   * Identifiant json pour {@link #economicNatureAsString}.
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING = "natureEconomiqueChaine";

  /**
   * Identifiant json pour {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = "idCategoriePostePaie";

  /**
   * Identifiant json pour {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = "categoriePostePaieChaine";

  /**
   * Identifiant json de activity_identifier.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = "idActivite";

  /**
   * Identifiant json pour {@link #payrollNatureIdentifier}.
   */
  public static final String JSON_PAYROLL_NATURE_IDENTIFIER = "idNaturePostePaie";

  /**
   * Identifiant json pour {@link #payrollNatureAsString}.
   */
  public static final String JSON_PAYROLL_NATURE_AS_STRING = "naturePostePaieChaine";

  /**
   * Identifiant json pour {@link #gain}.
   */
  public static final String JSON_GAIN = "estGain";
}
