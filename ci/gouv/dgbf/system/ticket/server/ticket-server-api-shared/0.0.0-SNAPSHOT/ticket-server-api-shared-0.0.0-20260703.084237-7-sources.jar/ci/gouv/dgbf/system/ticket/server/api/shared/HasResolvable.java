package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être résolu.
 *
 * @author Christian
 */
public interface HasResolvable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être résolu.
   *
   * @return peut être résolu
   */
  Boolean getResolvable();

  /**
   * Cette méthode permet d'assigner peut être résolu.
   *
   * @param resolvable peut être résolu
   */
  void setResolvable(Boolean resolvable);

  /**
   * Identifiant java de peut être résolu.
   */
  String FIELD_RESOLVABLE = "resolvable";
}