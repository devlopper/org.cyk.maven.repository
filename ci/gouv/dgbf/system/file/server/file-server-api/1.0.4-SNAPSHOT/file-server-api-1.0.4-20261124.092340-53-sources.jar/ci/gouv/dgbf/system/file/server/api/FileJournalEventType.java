package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types d'événement du journal du Fichier (RG_FILE_FIC_23).
 *
 * @author Christian
 */
@Getter
public enum FileJournalEventType {

  /** {@link FileJournalEventTypeCode#BYTES_ADDITION}. */
  BYTES_ADDITION(FileJournalEventTypeCode.BYTES_ADDITION, "Ajout du contenu numérique"),

  /** {@link FileJournalEventTypeCode#PHYSICAL_ITEM_DECLARATION}. */
  PHYSICAL_ITEM_DECLARATION(FileJournalEventTypeCode.PHYSICAL_ITEM_DECLARATION,
      "Déclaration de l'exemplaire papier"),

  /** {@link FileJournalEventTypeCode#INFORMATION_UPDATE}. */
  INFORMATION_UPDATE(FileJournalEventTypeCode.INFORMATION_UPDATE,
      "Modification des informations"),

  /** {@link FileJournalEventTypeCode#PHYSICAL_ITEM_UPDATE}. */
  PHYSICAL_ITEM_UPDATE(FileJournalEventTypeCode.PHYSICAL_ITEM_UPDATE,
      "Modification de l'exemplaire papier");

  private final String code;
  private final String name;

  private FileJournalEventType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le type d'événement par code.
   *
   * @param code code stocké
   * @return type d'événement
   */
  public static FileJournalEventType getByCode(String code) {
    return Stream.of(values()).filter(type -> type.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
