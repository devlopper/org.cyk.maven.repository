package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FundingDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-21T12:27:55+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FundingRequestMapperImpl implements FundingRequestMapper {

    @Override
    public FundingService.FundingCreateRequestDto mapCreate(FundingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundingService.FundingCreateRequestDto fundingCreateRequestDto = new FundingService.FundingCreateRequestDto();

        fundingCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundingCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        fundingCreateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        fundingCreateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );
        fundingCreateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        fundingCreateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        if ( arg0.getAmount1() != null ) {
            fundingCreateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            fundingCreateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            fundingCreateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return fundingCreateRequestDto;
    }

    @Override
    public FundingService.FundingUpdateRequestDto mapUpdate(FundingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FundingService.FundingUpdateRequestDto fundingUpdateRequestDto = new FundingService.FundingUpdateRequestDto();

        fundingUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fundingUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        fundingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        fundingUpdateRequestDto.setFundingTypeIdentifier( arg0.getFundingTypeIdentifier() );
        fundingUpdateRequestDto.setLessorIdentifier( arg0.getLessorIdentifier() );
        fundingUpdateRequestDto.setEconomicNatureIdentifier( arg0.getEconomicNatureIdentifier() );
        fundingUpdateRequestDto.setTriennialProgramActivityIdentifier( arg0.getTriennialProgramActivityIdentifier() );
        if ( arg0.getAmount1() != null ) {
            fundingUpdateRequestDto.setAmount1( arg0.getAmount1() );
        }
        if ( arg0.getAmount2() != null ) {
            fundingUpdateRequestDto.setAmount2( arg0.getAmount2() );
        }
        if ( arg0.getAmount3() != null ) {
            fundingUpdateRequestDto.setAmount3( arg0.getAmount3() );
        }

        return fundingUpdateRequestDto;
    }

    @Override
    public FundingService.FundingUpdateCommentRequestDto mapUpdateComment(FundingDto funding) {
        if ( funding == null ) {
            return null;
        }

        FundingService.FundingUpdateCommentRequestDto fundingUpdateCommentRequestDto = new FundingService.FundingUpdateCommentRequestDto();

        fundingUpdateCommentRequestDto.setAuditWho( funding.getAuditWho() );
        fundingUpdateCommentRequestDto.setAuditSession( funding.getAuditSession() );
        fundingUpdateCommentRequestDto.setIdentifier( funding.getIdentifier() );
        fundingUpdateCommentRequestDto.setComment( funding.getComment() );

        return fundingUpdateCommentRequestDto;
    }
}
