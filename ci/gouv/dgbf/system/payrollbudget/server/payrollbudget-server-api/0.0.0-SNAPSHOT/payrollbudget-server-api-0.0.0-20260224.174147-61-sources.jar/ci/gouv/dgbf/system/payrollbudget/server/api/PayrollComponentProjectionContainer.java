package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette interface représente un conteneur de {@link PayrollComponentProjectionDto}.
 */
public interface PayrollComponentProjectionContainer {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant de
   * référence.
   *
   * @return représentation en chaine de caractères du montant de référence
   */
  String getReferenceAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du montant.
   *
   * @return représentation en chaine de caractères du montant
   */
  String getAmountAsString();

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de la variance du
   * montant.
   *
   * @return représentation en chaine de caractères de la variance du montant
   */
  String getAmountVarianceAsString();

  /**
   * Identifiant java du montant de référence.
   */
  String FIELD_REFERENCE_AMOUNT = "referenceAmount";

  /**
   * Identifiant java de la représentation en chaine de caractères du montant de référence.
   */
  String FIELD_REFERENCE_AMOUNT_AS_STRING = "referenceAmountAsString";

  /**
   * Identifiant java du montant.
   */
  String FIELD_AMOUNT = "amount";

  /**
   * Identifiant java de la représentation en chaine de caractères du montant.
   */
  String FIELD_AMOUNT_AS_STRING = "amountAsString";

  /**
   * Identifiant java de la variance du montant.
   */
  String FIELD_AMOUNT_VARIANCE = "amountVariance";

  /**
   * Identifiant java de la représentation en chaine de caractères de la variance du montant.
   */
  String FIELD_AMOUNT_VARIANCE_AS_STRING = "amountVarianceAsString";
}
