package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.ValueTypeSelectOneController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryClient;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryDto;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryRequestMapper;
import ci.gouv.dgbf.system.datastructures.server.api.DictionaryEntryService;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DictionaryEntryDto}.
 *
 * @author Desysoft
 *
 */
@Dependent
public class DictionaryEntryController extends AbstractController {

  @Inject
  DictionaryEntryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  DictionaryEntryRequestMapper requestMapper;

  @Inject
  @Getter
  DictionaryEntryFilterController filterController;

  @Inject
  @Getter
  ValueTypeSelectOneController valueTypeSelectOneController;

  @Inject
  @Getter
  DictionarySelectOneController dictionarySelectOneController;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DictionaryEntryDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser le contrôleur.
   */
  public void initialize() {
    listController.setEntityClass(DictionaryEntryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DictionaryEntryService.PATH);
    listController.setFilterController(filterController);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE,
        DictionaryEntryDto.JSON_VALUE_TYPE,
        DictionaryEntryDto.JSON_DEFAULT_VALUE,
        AbstractIdentifiableCodableNamableDto.JSON_NAME,
        DictionaryEntryDto.JSON_DICTIONARY_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    dictionarySelectOneController.visibleWhenListControllerReadControllerHasProjectionName(
        listController, DictionaryEntryDto.JSON_DICTIONARY_AS_STRING);

    dictionarySelectOneController.setRenderable(
        Core.isStringBlank(filterController.getFilter().getDictionaryIdentifier()));

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    AbstractIdentifiableCodableDto.JSON_CODE,
                    AbstractIdentifiableCodableNamableDto.JSON_NAME,
                    DictionaryEntryDto.JSON_VALUE_TYPE,
                    DictionaryEntryDto.JSON_DEFAULT_VALUE,
                    DictionaryEntryDto.JSON_DICTIONARY_IDENTIFIER
                )
        );

    listController.getCreateController().addEntityConsumer(
        entity -> ((DictionaryEntryDto) entity).setDictionaryIdentifier(
            filterController.getFilter().getDictionaryIdentifier()));

    listController.getCreateController().setFunction(entity -> {
      DictionaryEntryService.DictionaryEntryCreateRequestDto request =
          requestMapper.mapCreate((DictionaryEntryDto) entity);
      request.setValueType(
          ValueType.valueOf(valueTypeSelectOneController.getSelectOneMenu().getValue()));
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController()
        .setFunction(entity -> {
          DictionaryEntryService.DictionaryEntryUpdateRequestDto request = requestMapper.mapUpdate(
              (DictionaryEntryDto) entity);
          request.setValueType(
              ValueType.valueOf(valueTypeSelectOneController.getSelectOneMenu().getValue()));
          request.setAuditWho(userIdentifier);
          return client.update(request);
        });

    listController.getUpdateController().addEntityConsumer(entity -> {
      dictionarySelectOneController.getSelectOneMenu()
          .writeValue(((DictionaryEntryDto) entity).getDictionaryIdentifier());

      valueTypeSelectOneController.getSelectOneMenu()
          .writeValue(((DictionaryEntryDto) entity).getValueType().name());
    });

    dictionarySelectOneController
        .getSelectOneMenu()
        .addValueConsumer(dictionaryIdentifierConsumer());
  }

  Consumer<String> dictionaryIdentifierConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DictionaryEntryDto.class)
        .setDictionaryIdentifier(identifier);
  }

}

