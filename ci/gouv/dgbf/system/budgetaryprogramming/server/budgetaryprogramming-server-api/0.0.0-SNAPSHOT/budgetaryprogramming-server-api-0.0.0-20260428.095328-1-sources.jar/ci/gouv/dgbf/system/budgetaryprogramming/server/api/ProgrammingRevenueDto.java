package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRevenueAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasRevenueIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un revenu de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingRevenueDto extends AbstractIdentifiableAuditableDto
    implements HasProgrammingIdentifierDto, HasProgrammingAsStringDto, HasRevenueIdentifierDto,
    HasRevenueAsStringDto {

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  private String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  private String programmingAsString;
  
  @JsonbProperty(JSON_REVENUE_IDENTIFIER)
  private String revenueIdentifier;

  @JsonbProperty(JSON_REVENUE_AS_STRING)
  private String revenueAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRevenuProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "revenuProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "revenu de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "revenus de programmation";

}
