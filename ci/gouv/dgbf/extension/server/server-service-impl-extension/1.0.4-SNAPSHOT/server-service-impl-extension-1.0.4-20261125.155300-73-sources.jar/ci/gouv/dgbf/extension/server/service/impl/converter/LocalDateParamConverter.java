package ci.gouv.dgbf.extension.server.service.impl.converter;

import ci.gouv.dgbf.extension.core.StringHelper;
import jakarta.inject.Inject;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

/**
 * Cette classe représente le convertisseur du type LocalDate.
 *
 * @author Christian
 *
 */
public class LocalDateParamConverter
    implements jakarta.ws.rs.ext.ParamConverter<LocalDate> {
  private static final Logger LOGGER = Logger.getLogger(LocalDateParamConverter.class.getName());

  @Inject
  StringHelper stringHelper;

  String formatterPattern;
  DateTimeFormatter formatter;

  /**
   * Cette méthode permet de construire un convertisseur de type LocalDate.
   *
   * @param formatterPattern le patterne
   * @param stringHelper l'aide du type chaine de caractère
   */
  public LocalDateParamConverter(String formatterPattern, StringHelper stringHelper) {
    this.formatterPattern = formatterPattern;
    formatter = DateTimeFormatter.ofPattern(formatterPattern);
    this.stringHelper = stringHelper;
  }
  
  @Override
  public LocalDate fromString(String string) {
    if (Boolean.TRUE.equals(stringHelper.isBlank(string))) {
      return null;
    }
    try {
      return LocalDate.parse(string, formatter);
    } catch (Exception exception) {
      LOGGER.severe(String.format("Impossible de formatter %s en date. %s. Le format doit être %s",
          string, exception, formatterPattern));
      return null;
    }
  }

  @Override
  public String toString(LocalDate localDate) {
    if (localDate == null) {
      return null;
    }
    return formatter.format(localDate);
  }
}
