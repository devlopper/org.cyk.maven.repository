package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.SubLocalityZoneService.SubLocalityZoneCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.SubLocalityZoneService.SubLocalityZoneGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.SubLocalityZoneService.SubLocalityZoneUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un modèle de paie.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class SubLocalityZoneClient extends AbstractClient<SubLocalityZoneService>
    implements GetByIdentifier<SubLocalityZoneDto>, GetMany<SubLocalityZoneGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public SubLocalityZoneClient service(SubLocalityZoneService service) {
    return (SubLocalityZoneClient) super.service(service);
  }

  /**
   * {@link SubLocalityZoneService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(SubLocalityZoneCreateRequestDto request) {
    return new CreateExecutor(SubLocalityZoneService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link SubLocalityZoneService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public SubLocalityZoneGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<SubLocalityZoneGetManyResponseDto>(
        SubLocalityZoneGetManyResponseDto.class, SubLocalityZoneService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link SubLocalityZoneService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SubLocalityZoneGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link SubLocalityZoneService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public SubLocalityZoneDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<SubLocalityZoneDto>(SubLocalityZoneDto.class,
        SubLocalityZoneService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link SubLocalityZoneService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public SubLocalityZoneDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link SubLocalityZoneService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public SubLocalityZoneDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<SubLocalityZoneDto>(SubLocalityZoneDto.class,
        SubLocalityZoneService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link SubLocalityZoneService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public SubLocalityZoneDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link SubLocalityZoneService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(SubLocalityZoneUpdateRequestDto request) {
    return new IdentifiableExecutor(SubLocalityZoneService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link SubLocalityZoneService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(SubLocalityZoneService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link SubLocalityZoneService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
