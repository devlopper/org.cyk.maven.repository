package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+1.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN1 {

  /**
   * Obtient le montant total à arbitrer pour l'année N+1.
   *
   * @return le montant total à arbitrer pour l'année N+1
   */
  Long getTotalAmountToArbitrateN1();

  /**
   * Définit le montant total à arbitrer pour l'année N+1.
   *
   * @param totalAmountToArbitrateN1 le montant total à arbitrer pour l'année N+1
   */
  void setTotalAmountToArbitrateN1(Long totalAmountToArbitrateN1);

  /**
   * Identifiant java du montant total à arbitrer pour l'année N+1.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N1 = "totalAmountToArbitrateN1";
}