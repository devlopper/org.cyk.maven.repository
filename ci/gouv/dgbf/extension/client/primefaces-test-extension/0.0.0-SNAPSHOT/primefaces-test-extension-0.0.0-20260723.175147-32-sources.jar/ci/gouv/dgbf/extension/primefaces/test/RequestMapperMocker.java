package ci.gouv.dgbf.extension.primefaces.test;

import static org.mockito.ArgumentMatchers.any;

import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link ListController}.
 *
 * @author Christian
 *
 * @param <T> type mapper
 * @param <C> type requête création
 * @param <U> type requête mise à jour
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class RequestMapperMocker<T extends RequestMapper<?, C, U>, C, U> {

  /**
   * classe mapper.
   */
  Class<T> clazz;
  
  /**
   * requête de création.
   */
  C create;
  
  /**
   * requête de mise à jour.
   */
  U update;
  
  /**
   * Cette méthode permet de construire.
   *
   * @param clazz classe
   */
  public RequestMapperMocker(Class<T> clazz) {
    this.clazz = clazz;
  }
  
  /**
   * Cette méthode permet de mocker.
   *
   * @return mapper
   */
  public T mock() {
    T mapper = Mockito.mock(clazz);
    Mockito.when(mapper.mapCreate(any())).thenReturn(create);
    Mockito.when(mapper.mapUpdate(any())).thenReturn(update);
    return mapper;
  }

}
