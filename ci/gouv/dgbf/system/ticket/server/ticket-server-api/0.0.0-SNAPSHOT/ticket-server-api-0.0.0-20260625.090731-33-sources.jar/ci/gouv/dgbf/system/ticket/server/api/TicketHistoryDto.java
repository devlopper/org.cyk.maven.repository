package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCategoryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusCommentDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasDiagnosticDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSolutionDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un historique de ticket.
 *
 * @author Christian
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TicketHistoryDto extends AbstractIdentifiableAuditableDto
    implements HasTicketIdentifierDto, HasTicketAsStringDto, HasDomainIdentifierDto,
    HasDomainAsStringDto, HasLevelIdentifierDto, HasLevelAsStringDto, HasStatusDto<TicketStatus>,
    HasStatusAsStringDto, HasStatusCommentDto, HasCategoryIdentifierDto, HasCategoryAsStringDto,
    HasPriorityIdentifierDto, HasPriorityAsStringDto, HasDiagnosticDto, HasSolutionDto,
    HasUserIdentifierDto, HasUserAsStringDto, HasUsersGroupAsStringDto {

  // Ticket

  @JsonbProperty(JSON_TICKET_IDENTIFIER)
  private String ticketIdentifier;

  @JsonbProperty(JSON_TICKET_AS_STRING)
  private String ticketAsString;

  // Domain

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  // Status

  @JsonbProperty(JSON_STATUS)
  private TicketStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_STATUS_COMMENT)
  private String statusComment;

  // Category

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  // Priority

  @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
  private String priorityIdentifier;

  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;

  // Claim result

  @JsonbProperty(JSON_DIAGNOSTIC)
  private String diagnostic;

  @JsonbProperty(JSON_SOLUTION)
  private String solution;

  // Users
  
  @JsonbProperty(JSON_USERS_GROUP_AS_STRING)
  private String usersGroupAsString;
  
  // User

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  // Level

  @JsonbProperty(JSON_LEVEL_IDENTIFIER)
  private String levelIdentifier;

  @JsonbProperty(JSON_LEVEL_AS_STRING)
  private String levelAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idHistoriqueTicket";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "historiqueTicketChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "historique de ticket";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "historiques de ticket";

}

