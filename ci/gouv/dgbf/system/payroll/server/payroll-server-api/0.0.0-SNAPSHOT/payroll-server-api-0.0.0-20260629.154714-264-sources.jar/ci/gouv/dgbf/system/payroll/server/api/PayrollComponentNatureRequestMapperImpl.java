package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentNatureDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentNatureRequestMapperImpl implements PayrollComponentNatureRequestMapper {

    @Override
    public PayrollComponentNatureService.PayrollComponentNatureCreateRequestDto mapCreate(PayrollComponentNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentNatureService.PayrollComponentNatureCreateRequestDto payrollComponentNatureCreateRequestDto = new PayrollComponentNatureService.PayrollComponentNatureCreateRequestDto();

        payrollComponentNatureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentNatureCreateRequestDto.setCode( arg0.getCode() );
        payrollComponentNatureCreateRequestDto.setName( arg0.getName() );

        return payrollComponentNatureCreateRequestDto;
    }

    @Override
    public PayrollComponentNatureService.PayrollComponentNatureUpdateRequestDto mapUpdate(PayrollComponentNatureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentNatureService.PayrollComponentNatureUpdateRequestDto payrollComponentNatureUpdateRequestDto = new PayrollComponentNatureService.PayrollComponentNatureUpdateRequestDto();

        payrollComponentNatureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentNatureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentNatureUpdateRequestDto.setCode( arg0.getCode() );
        payrollComponentNatureUpdateRequestDto.setName( arg0.getName() );

        return payrollComponentNatureUpdateRequestDto;
    }
}
