package ci.gouv.dgbf.system.logging.server.api;

/** Codes stables des types d’action de traçabilité. */
public interface TraceabilityActionTypeCode {

  String LECTURE = "LECTURE";

  String CREATION = "CREATION";

  String MODIFICATION = "MODIFICATION";

  String SUPPRESSION = "SUPPRESSION";

  String EXECUTION = "EXECUTION";

  String ENVOI = "ENVOI";

  String AUTRE = "AUTRE";
}
