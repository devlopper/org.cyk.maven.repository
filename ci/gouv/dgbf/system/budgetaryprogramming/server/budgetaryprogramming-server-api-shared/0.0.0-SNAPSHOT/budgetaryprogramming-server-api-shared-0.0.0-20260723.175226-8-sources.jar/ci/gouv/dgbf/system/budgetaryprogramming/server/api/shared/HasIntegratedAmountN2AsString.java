package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant intégré pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasIntegratedAmountN2AsString {

  /**
   * Obtient le montant intégré pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant intégré pour l'année N+2 sous forme de chaîne de caractères
   */
  String getIntegratedAmountN2AsString();

  /**
   * Définit le montant intégré pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param integratedAmountN2AsString le montant intégré pour l'année N+2 sous forme de chaîne de
   *        caractères
   */
  void setIntegratedAmountN2AsString(String integratedAmountN2AsString);

  /**
   * Identifiant java du montant intégré pour l'année N+2, sous forme de chaîne de caractères.
   */
  String FIELD_INTEGRATED_AMOUNT_N2_AS_STRING =
      "integratedAmountN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName