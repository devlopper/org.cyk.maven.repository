package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ServiceGroupDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class ServiceGroupFilter extends AbstractIdentifiableFilter {
  
}
