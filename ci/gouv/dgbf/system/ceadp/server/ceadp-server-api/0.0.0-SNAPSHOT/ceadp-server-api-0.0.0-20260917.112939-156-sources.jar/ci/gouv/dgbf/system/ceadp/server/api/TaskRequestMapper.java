package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.TaskService.TaskUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link TaskDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link TaskDto}.

    @author Christian
               """)
public interface TaskRequestMapper
    extends RequestMapper<TaskDto, TaskCreateRequestDto, TaskUpdateRequestDto> {

}
