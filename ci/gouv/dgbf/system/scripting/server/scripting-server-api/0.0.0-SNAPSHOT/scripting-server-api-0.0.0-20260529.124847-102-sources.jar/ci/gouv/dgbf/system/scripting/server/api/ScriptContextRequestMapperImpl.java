package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptContextDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:49:47+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptContextRequestMapperImpl implements ScriptContextRequestMapper {

    @Override
    public ScriptContextService.ScriptContextCreateRequestDto mapCreate(ScriptContextDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptContextService.ScriptContextCreateRequestDto scriptContextCreateRequestDto = new ScriptContextService.ScriptContextCreateRequestDto();

        scriptContextCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptContextCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptContextCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        scriptContextCreateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptContextCreateRequestDto.setMultiplier( arg0.getMultiplier() );
        scriptContextCreateRequestDto.setMinValue( arg0.getMinValue() );
        scriptContextCreateRequestDto.setMaxValue( arg0.getMaxValue() );

        return scriptContextCreateRequestDto;
    }

    @Override
    public ScriptContextService.ScriptContextUpdateRequestDto mapUpdate(ScriptContextDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptContextService.ScriptContextUpdateRequestDto scriptContextUpdateRequestDto = new ScriptContextService.ScriptContextUpdateRequestDto();

        scriptContextUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        scriptContextUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        scriptContextUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptContextUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        scriptContextUpdateRequestDto.setScriptIdentifier( arg0.getScriptIdentifier() );
        scriptContextUpdateRequestDto.setMultiplier( arg0.getMultiplier() );
        scriptContextUpdateRequestDto.setMinValue( arg0.getMinValue() );
        scriptContextUpdateRequestDto.setMaxValue( arg0.getMaxValue() );

        return scriptContextUpdateRequestDto;
    }
}
