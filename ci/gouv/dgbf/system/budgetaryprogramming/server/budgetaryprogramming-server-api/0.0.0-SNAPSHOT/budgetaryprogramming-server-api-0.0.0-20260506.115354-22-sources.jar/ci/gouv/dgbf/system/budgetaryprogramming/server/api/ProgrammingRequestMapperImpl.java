package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProgrammingDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-06T11:54:12+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProgrammingRequestMapperImpl implements ProgrammingRequestMapper {

    @Override
    public ProgrammingService.ProgrammingCreateRequestDto mapCreate(ProgrammingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingService.ProgrammingCreateRequestDto programmingCreateRequestDto = new ProgrammingService.ProgrammingCreateRequestDto();

        programmingCreateRequestDto.setCode( arg0.getCode() );
        programmingCreateRequestDto.setName( arg0.getName() );
        programmingCreateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        programmingCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        programmingCreateRequestDto.setImputationLockIdentifier( arg0.getImputationLockIdentifier() );

        return programmingCreateRequestDto;
    }

    @Override
    public ProgrammingService.ProgrammingUpdateRequestDto mapUpdate(ProgrammingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProgrammingService.ProgrammingUpdateRequestDto programmingUpdateRequestDto = new ProgrammingService.ProgrammingUpdateRequestDto();

        programmingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        programmingUpdateRequestDto.setCode( arg0.getCode() );
        programmingUpdateRequestDto.setName( arg0.getName() );
        programmingUpdateRequestDto.setExerciseIdentifier( arg0.getExerciseIdentifier() );
        programmingUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        programmingUpdateRequestDto.setImputationLockIdentifier( arg0.getImputationLockIdentifier() );

        return programmingUpdateRequestDto;
    }
}
