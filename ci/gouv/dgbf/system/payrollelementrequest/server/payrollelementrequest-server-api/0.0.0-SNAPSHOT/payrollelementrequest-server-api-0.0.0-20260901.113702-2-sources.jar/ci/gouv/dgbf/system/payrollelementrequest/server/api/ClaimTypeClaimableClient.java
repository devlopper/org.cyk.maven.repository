package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ClaimTypeClaimableService.ClaimTypeClaimableUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ClaimTypeClaimableService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ClaimTypeClaimableClient extends AbstractClient<ClaimTypeClaimableService>
    implements GetByIdentifier<ClaimTypeClaimableDto>,
    GetMany<ClaimTypeClaimableGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ClaimTypeClaimableClient service(ClaimTypeClaimableService service) {
    return (ClaimTypeClaimableClient) super.service(service);
  }

  /**
   * {@link ClaimTypeClaimableService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimTypeClaimableGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ClaimTypeClaimableGetManyResponseDto>(
        ClaimTypeClaimableGetManyResponseDto.class, ClaimTypeClaimableService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ClaimTypeClaimableService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimTypeClaimableGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ClaimTypeClaimableService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ClaimTypeClaimableCreateRequestDto request) {
    return new CreateExecutor(ClaimTypeClaimableService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ClaimTypeClaimableService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ClaimTypeClaimableUpdateRequestDto request) {
    return new IdentifiableExecutor(ClaimTypeClaimableService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ClaimTypeClaimableService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ClaimTypeClaimableDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ClaimTypeClaimableDto>(ClaimTypeClaimableDto.class,
        ClaimTypeClaimableService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ClaimTypeClaimableService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ClaimTypeClaimableDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ClaimTypeClaimableService#getByIdentifier}.
   *
   * @param request requête
   * @return réclamable de type de réclamation
   */
  public ClaimTypeClaimableDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ClaimTypeClaimableDto>(ClaimTypeClaimableDto.class,
        ClaimTypeClaimableService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ClaimTypeClaimableService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ClaimTypeClaimableDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ClaimTypeClaimableService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ClaimTypeClaimableService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ClaimTypeClaimableService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
