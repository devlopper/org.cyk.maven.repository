package ci.gouv.dgbf.system.logging.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RecordOperationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-26T11:33:40+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RecordOperationRequestMapperImpl implements RecordOperationRequestMapper {

    @Override
    public RecordOperationService.RecordOperationCreateRequestDto mapCreate(RecordOperationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RecordOperationService.RecordOperationCreateRequestDto recordOperationCreateRequestDto = new RecordOperationService.RecordOperationCreateRequestDto();

        recordOperationCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        recordOperationCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        recordOperationCreateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        recordOperationCreateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        recordOperationCreateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        recordOperationCreateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        recordOperationCreateRequestDto.setArguments( arg0.getArguments() );
        recordOperationCreateRequestDto.setArgumentsFormat( arg0.getArgumentsFormat() );
        recordOperationCreateRequestDto.setResult( arg0.getResult() );
        recordOperationCreateRequestDto.setResultFormat( arg0.getResultFormat() );
        recordOperationCreateRequestDto.setMessage( arg0.getMessage() );

        return recordOperationCreateRequestDto;
    }

    @Override
    public RecordOperationService.RecordOperationUpdateRequestDto mapUpdate(RecordOperationDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RecordOperationService.RecordOperationUpdateRequestDto recordOperationUpdateRequestDto = new RecordOperationService.RecordOperationUpdateRequestDto();

        recordOperationUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        recordOperationUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        recordOperationUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        recordOperationUpdateRequestDto.setProcessIdentifier( arg0.getProcessIdentifier() );
        recordOperationUpdateRequestDto.setSourceIdentifier( arg0.getSourceIdentifier() );
        recordOperationUpdateRequestDto.setOperationIdentifier( arg0.getOperationIdentifier() );
        recordOperationUpdateRequestDto.setRecordIdentifier( arg0.getRecordIdentifier() );
        recordOperationUpdateRequestDto.setArguments( arg0.getArguments() );
        recordOperationUpdateRequestDto.setArgumentsFormat( arg0.getArgumentsFormat() );
        recordOperationUpdateRequestDto.setResult( arg0.getResult() );
        recordOperationUpdateRequestDto.setResultFormat( arg0.getResultFormat() );
        recordOperationUpdateRequestDto.setMessage( arg0.getMessage() );

        return recordOperationUpdateRequestDto;
    }
}
