package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.GetManyResponseDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateAmountRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramActivityFundingTypeService.TriennialProgramActivityFundingTypeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link TriennialProgramActivityFundingTypeService}.
 *
 * @author Desysoft
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class TriennialProgramActivityFundingTypeClient
    extends AbstractClient<TriennialProgramActivityFundingTypeService>
    implements GetByIdentifier<TriennialProgramActivityFundingTypeDto>, GetMany<GetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public TriennialProgramActivityFundingTypeClient service(
      TriennialProgramActivityFundingTypeService service) {
    return (TriennialProgramActivityFundingTypeClient) super.service(service);
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(
      TriennialProgramActivityFundingTypeCreateRequestDto request) {
    return new CreateExecutor(TriennialProgramActivityFundingTypeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        TriennialProgramActivityFundingTypeService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
                                    String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public TriennialProgramActivityFundingTypeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<TriennialProgramActivityFundingTypeDto>(
        TriennialProgramActivityFundingTypeDto.class,
        TriennialProgramActivityFundingTypeService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public TriennialProgramActivityFundingTypeDto getOne(ProjectionDto projection, FilterDto filter,
                                                       String auditWho,
                                                       String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public TriennialProgramActivityFundingTypeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<TriennialProgramActivityFundingTypeDto>(
        TriennialProgramActivityFundingTypeDto.class,
        TriennialProgramActivityFundingTypeService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public TriennialProgramActivityFundingTypeDto getByIdentifier(String identifier,
                                                                ProjectionDto projection,
                                                                String auditWho,
                                                                String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(
      TriennialProgramActivityFundingTypeUpdateRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramActivityFundingTypeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#updateAmount}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateAmount(
      TriennialProgramActivityFundingTypeUpdateAmountRequestDto request) {
    return new IdentifiableExecutor(
        TriennialProgramActivityFundingTypeService.UPDATE_AMOUNT_IDENTIFIER)
        .execute(() -> service().updateAmount(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(TriennialProgramActivityFundingTypeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link TriennialProgramActivityFundingTypeService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

