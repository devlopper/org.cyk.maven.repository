package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PartitionTypeDto}.
*
* @author Boobacool
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PartitionTypeRequestMapperImpl implements PartitionTypeRequestMapper {

    @Override
    public PartitionTypeService.PartitionTypeCreateRequestDto mapCreate(PartitionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionTypeService.PartitionTypeCreateRequestDto partitionTypeCreateRequestDto = new PartitionTypeService.PartitionTypeCreateRequestDto();

        partitionTypeCreateRequestDto.setCode( arg0.getCode() );
        partitionTypeCreateRequestDto.setName( arg0.getName() );
        partitionTypeCreateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        partitionTypeCreateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return partitionTypeCreateRequestDto;
    }

    @Override
    public PartitionTypeService.PartitionTypeUpdateRequestDto mapUpdate(PartitionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PartitionTypeService.PartitionTypeUpdateRequestDto partitionTypeUpdateRequestDto = new PartitionTypeService.PartitionTypeUpdateRequestDto();

        partitionTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        partitionTypeUpdateRequestDto.setCode( arg0.getCode() );
        partitionTypeUpdateRequestDto.setName( arg0.getName() );
        partitionTypeUpdateRequestDto.setDomainIdentifier( arg0.getDomainIdentifier() );
        partitionTypeUpdateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return partitionTypeUpdateRequestDto;
    }
}
