package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverClient;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.ReceiverService.ReceiverGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ReceiverSelectOneController extends AbstractSelectOneIdentifiableController<
    ReceiverDto, ReceiverGetManyResponseDto, ReceiverClient> {

  @Inject
  @Getter
  ReceiverClient client;

  /**
   * Cette methode permet de construire.
   */
  protected ReceiverSelectOneController() {
    super(ReceiverDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
