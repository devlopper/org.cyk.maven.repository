package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollComponentStaffProjectionDto}.
*
* @author parfait
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-23T18:24:45+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollComponentStaffProjectionRequestMapperImpl implements PayrollComponentStaffProjectionRequestMapper {

    @Override
    public PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionCreateRequestDto mapCreate(PayrollComponentStaffProjectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionCreateRequestDto payrollComponentStaffProjectionCreateRequestDto = new PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionCreateRequestDto();

        payrollComponentStaffProjectionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentStaffProjectionCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentStaffProjectionCreateRequestDto.setBudgetAdministrativeUnitStaffIdentifier( arg0.getBudgetAdministrativeUnitStaffIdentifier() );
        payrollComponentStaffProjectionCreateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payrollComponentStaffProjectionCreateRequestDto.setPayrollPeriodGroupIdentifier( arg0.getPayrollPeriodGroupIdentifier() );
        payrollComponentStaffProjectionCreateRequestDto.setReferenceAmount( arg0.getReferenceAmount() );
        payrollComponentStaffProjectionCreateRequestDto.setAmount( arg0.getAmount() );

        return payrollComponentStaffProjectionCreateRequestDto;
    }

    @Override
    public PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateRequestDto mapUpdate(PayrollComponentStaffProjectionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateRequestDto payrollComponentStaffProjectionUpdateRequestDto = new PayrollComponentStaffProjectionService.PayrollComponentStaffProjectionUpdateRequestDto();

        payrollComponentStaffProjectionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollComponentStaffProjectionUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollComponentStaffProjectionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollComponentStaffProjectionUpdateRequestDto.setBudgetAdministrativeUnitStaffIdentifier( arg0.getBudgetAdministrativeUnitStaffIdentifier() );
        payrollComponentStaffProjectionUpdateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payrollComponentStaffProjectionUpdateRequestDto.setPayrollPeriodGroupIdentifier( arg0.getPayrollPeriodGroupIdentifier() );
        payrollComponentStaffProjectionUpdateRequestDto.setReferenceAmount( arg0.getReferenceAmount() );
        payrollComponentStaffProjectionUpdateRequestDto.setAmount( arg0.getAmount() );

        return payrollComponentStaffProjectionUpdateRequestDto;
    }
}
