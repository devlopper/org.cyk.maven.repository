package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PunctualMeasureDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PunctualMeasureFilter extends AbstractIdentifiableFilter {

  /**
   * Indicateur d'activité.
   */
  Boolean isActive;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public PunctualMeasureFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public PunctualMeasureFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    isActive = getIsActive(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIsActive(filter, isActive);
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur d'activité.
   *
   * @param filter filtre
   * @return indicateur d'activité
   */
  public static Boolean getIsActive(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_ACTIVE));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur d'activité.
   *
   * @param filter filtre
   * @param isActive indicateur d'activité
   */
  public static void setIsActive(FilterDto filter, Boolean isActive) {
    set(filter, JSON_IS_ACTIVE, f -> f.getValueAsBoolean(), f -> f.setValueAsBoolean(isActive));
  }

  /**
   * Clé JSON de {@link #isActive}.
   */
  public static final String JSON_IS_ACTIVE = PunctualMeasureDto.JSON_IS_ACTIVE;
}
