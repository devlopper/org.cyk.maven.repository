package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupCategoryFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link FileGroupCategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileGroupCategoryFilterController
    extends AbstractFilterController<FileGroupCategoryFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public FileGroupCategoryFilterController() {
    super(FileGroupCategoryFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setFileGroupIdentifier(
        getRequestParameter(FileGroupCategoryFilter.JSON_FILE_GROUP_IDENTIFIER));
    filter.setCategoryIdentifier(
        getRequestParameter(FileGroupCategoryFilter.JSON_CATEGORY_IDENTIFIER));
  }
}

