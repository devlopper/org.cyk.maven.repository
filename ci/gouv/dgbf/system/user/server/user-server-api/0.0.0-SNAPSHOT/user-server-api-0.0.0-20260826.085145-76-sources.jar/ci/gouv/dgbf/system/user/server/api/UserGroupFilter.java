package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCapacityIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasGroupIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasIsResponsible;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserGroupDto}.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
public class UserGroupFilter extends AbstractIdentifiableFilter
    implements FilterHasGroupIdentifier, FilterHasCapacityIdentifier, FilterHasIsResponsible {

  /**
   * Identifiant du groupe propriétaire.
   */
  private String groupIdentifier;

  /**
   * Identifiant de la qualité.
   */
  private String capacityIdentifier;

  /**
   * Si responsable.
   */
  private Boolean isResponsible;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public UserGroupFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public UserGroupFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateGroupIdentifier(filter);
    updateCapacityIdentifier(filter);
    updateIsResponsible(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterGroupIdentifier(filter);
    updateFilterCapacityIdentifier(filter);
    updateFilterIsResponsible(filter);
  }

}
