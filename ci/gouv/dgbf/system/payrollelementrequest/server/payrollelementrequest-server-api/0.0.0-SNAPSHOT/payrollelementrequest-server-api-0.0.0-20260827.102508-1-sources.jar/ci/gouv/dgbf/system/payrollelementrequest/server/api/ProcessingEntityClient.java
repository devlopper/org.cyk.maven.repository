package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.ProcessingEntityService.ProcessingEntityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ProcessingEntityService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
public class ProcessingEntityClient extends AbstractClient<ProcessingEntityService>
    implements GetByIdentifier<ProcessingEntityDto>, GetMany<ProcessingEntityGetManyResponseDto> {

  @Override
  public ProcessingEntityClient service(ProcessingEntityService service) {
    return (ProcessingEntityClient) super.service(service);
  }

  /**
   * {@link ProcessingEntityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessingEntityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ProcessingEntityGetManyResponseDto>(
        ProcessingEntityGetManyResponseDto.class, ProcessingEntityService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ProcessingEntityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessingEntityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ProcessingEntityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ProcessingEntityCreateRequestDto request) {
    return new CreateExecutor(ProcessingEntityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ProcessingEntityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ProcessingEntityUpdateRequestDto request) {
    return new IdentifiableExecutor(ProcessingEntityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ProcessingEntityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessingEntityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ProcessingEntityDto>(ProcessingEntityDto.class,
        ProcessingEntityService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ProcessingEntityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ProcessingEntityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ProcessingEntityService#getByIdentifier}.
   *
   * @param request requête
   * @return entité traitante
   */
  public ProcessingEntityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ProcessingEntityDto>(ProcessingEntityDto.class,
        ProcessingEntityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ProcessingEntityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ProcessingEntityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
