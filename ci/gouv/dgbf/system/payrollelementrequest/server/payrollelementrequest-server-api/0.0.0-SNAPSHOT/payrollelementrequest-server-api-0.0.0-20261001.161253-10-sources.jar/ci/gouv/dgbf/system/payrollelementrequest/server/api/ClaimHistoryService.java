package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de lecture de {@link ClaimHistoryDto}. Lecture seule
 * (RG_REP_TRA_02) : ni création, ni mise à jour, ni suppression -- l'enregistrement reste interne
 * au serveur, déclenché par les transitions de {@link PayrollElementClaimDto}.
 *
 * @author akm
 *
 */
@Path(ClaimHistoryService.PATH)
@Tag(name = "Consultation de l'historique des réclamations")
public interface ClaimHistoryService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "historiques-reclamations";

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_HISTORIQUE_RECLAMATION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimHistoryGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimHistoryDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimHistoryDto> datas;
  }
}
