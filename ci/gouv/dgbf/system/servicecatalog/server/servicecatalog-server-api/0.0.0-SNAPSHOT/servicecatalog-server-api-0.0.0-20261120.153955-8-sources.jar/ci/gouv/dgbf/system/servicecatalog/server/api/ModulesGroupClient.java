package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.FilteredCatalogResponseDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.GetFilteredCatalogRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.ModulesGroupCreateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.ModulesGroupGetManyResponseDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.ModulesGroupUpdateRequestDto;
import ci.gouv.dgbf.system.servicecatalog.server.api.ModulesGroupService.PublicCatalogResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link ModulesGroupDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class ModulesGroupClient extends AbstractClient<ModulesGroupService>
    implements GetByIdentifier<ModulesGroupDto>, GetMany<ModulesGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link ModulesGroupService}
   * @return client {@link ModulesGroupClient}
   */
  @Override
  public ModulesGroupClient service(ModulesGroupService service) {
    return (ModulesGroupClient) super.service(service);
  }

  /**
   * {@link ModulesGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ModulesGroupCreateRequestDto request) {
    return new CreateExecutor(ModulesGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ModulesGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ModulesGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ModulesGroupGetManyResponseDto>(
        ModulesGroupGetManyResponseDto.class,
        ModulesGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ModulesGroupService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModulesGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ModulesGroupService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModulesGroupDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ModulesGroupDto>(ModulesGroupDto.class,
        ModulesGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ModulesGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ModulesGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<ModulesGroupDto>(ModulesGroupDto.class,
        ModulesGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ModulesGroupService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(ModulesGroupService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link ModulesGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ModulesGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ModulesGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ModulesGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ModulesGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link ModulesGroupService#getFilteredCatalog}.
   *
   * @param request requête auditée
   * @return catalogue filtré des agents
   */
  public FilteredCatalogResponseDto getFilteredCatalog(GetFilteredCatalogRequestDto request) {
    return new GetOneExecutor<FilteredCatalogResponseDto>(
        FilteredCatalogResponseDto.class,
        ModulesGroupService.GET_FILTERED_CATALOG_IDENTIFIER)
        .execute(() -> service().getFilteredCatalog(request));
  }

  /**
   * {@link ModulesGroupService#getFilteredCatalog}.
   *
   * @param auditWho utilisateur demandeur
   * @param auditSession session d'audit
   * @return catalogue filtré des agents
   */
  public FilteredCatalogResponseDto getFilteredCatalog(String auditWho, String auditSession) {
    GetFilteredCatalogRequestDto request = new GetFilteredCatalogRequestDto();
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getFilteredCatalog(request);
  }

  /**
   * {@link ModulesGroupService#getPublicCatalog}.
   *
   * @return catalogue public minimal
   */
  public PublicCatalogResponseDto getPublicCatalog() {
    return new GetOneExecutor<PublicCatalogResponseDto>(
        PublicCatalogResponseDto.class,
        ModulesGroupService.GET_PUBLIC_CATALOG_IDENTIFIER)
        .execute(() -> service().getPublicCatalog());
  }

}
