package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * de rôle.
 *
 * @author BoobaCool
 */
public interface HasRoleAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du rôle.
   *
   * @return représentation en chaine de caractères du rôle
   */
  String getRoleAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du rôle.
   *
   * @param roleAsString représentation en chaine de caractères du rôle
   */
  void setRoleAsString(String roleAsString);

  /**
   * Identifiant java de représentation en chaine de caractères du rôle.
   */
  String FIELD_ROLE_AS_STRING = "roleAsString";
}
