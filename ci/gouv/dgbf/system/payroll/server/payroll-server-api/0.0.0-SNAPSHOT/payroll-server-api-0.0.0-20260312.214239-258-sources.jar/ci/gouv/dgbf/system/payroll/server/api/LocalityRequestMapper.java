package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.LocalityService.LocalityCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.LocalityService.LocalityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link LocalityDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link LocalityDto}.

    @author stephane
               """)
public interface LocalityRequestMapper extends RequestMapper<LocalityDto,
    LocalityCreateRequestDto, LocalityUpdateRequestDto> {

}
