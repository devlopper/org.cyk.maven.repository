package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant de groupe d'utilisateurs.
 *
 * @author Christian
 */
public interface HasUsersGroupIdentifierDto extends HasUsersGroupIdentifier {

  /**
   * Identifiant json de l'identifiant du groupe d'utilisateurs.
   */
  String JSON_USERS_GROUP_IDENTIFIER = "idGroupeUtilisateurs";
}
