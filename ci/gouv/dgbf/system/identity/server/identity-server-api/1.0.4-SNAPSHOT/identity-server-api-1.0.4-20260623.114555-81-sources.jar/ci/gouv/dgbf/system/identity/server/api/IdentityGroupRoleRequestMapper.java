package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleService.IdentityGroupRoleCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityGroupRoleService.IdentityGroupRoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link IdentityGroupRoleDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link IdentityGroupRoleDto}.

    @author Christian
               """)
public interface IdentityGroupRoleRequestMapper extends RequestMapper<IdentityGroupRoleDto,
    IdentityGroupRoleCreateRequestDto, IdentityGroupRoleUpdateRequestDto> {

}
