package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateManyExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetBooleanExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ExistenceVerificationRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateManyResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryGetManyResponseDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryImportAllRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryImportByRegistrationNumberRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryStrictExistenceVerificationRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;

/**
 * Cette classe représente le client de {@link FunctionaryService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class FunctionaryClient extends AbstractClient<FunctionaryService>
    implements GetByIdentifier<FunctionaryDto>, GetMany<FunctionaryGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FunctionaryClient service(FunctionaryService service) {
    return (FunctionaryClient) super.service(service);
  }

  /**
   * {@link FunctionaryService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetOneExecutor<>(Long.class, 
        FunctionaryService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link FunctionaryService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FunctionaryCreateRequestDto request) {
    return new CreateExecutor(FunctionaryService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FunctionaryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionaryGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FunctionaryGetManyResponseDto>(FunctionaryGetManyResponseDto.class,
        FunctionaryService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FunctionaryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionaryGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FunctionaryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionaryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FunctionaryDto>(FunctionaryDto.class,
        FunctionaryService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FunctionaryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionaryDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FunctionaryService#verifyExistence}.
   *
   * @param request requête
   * @return réponse
   */
  public Boolean verifyExistence(ExistenceVerificationRequestDto request) {
    return new GetBooleanExecutor(FunctionaryService.VERIFY_EXISTENCE_IDENTIFIER)
        .execute(() -> service().verifyExistence(request));
  }

  /**
   * {@link FunctionaryService#verifyExistenceStrict}.
   *
   * @param request requête
   * @return réponse
   */
  public Boolean verifyExistenceStrict(FunctionaryStrictExistenceVerificationRequestDto request) {
    return new GetBooleanExecutor(FunctionaryService.VERIFY_EXISTENCE_STRICT_IDENTIFIER)
        .execute(() -> service().verifyExistenceStrict(request));
  }

  /**
   * {@link FunctionaryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FunctionaryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FunctionaryDto>(FunctionaryDto.class,
        FunctionaryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FunctionaryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionaryDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FunctionaryService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FunctionaryUpdateRequestDto request) {
    return new IdentifiableExecutor(FunctionaryService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FunctionaryService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FunctionaryService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FunctionaryService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link FunctionaryService#importByRegistrationNumber}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto importByRegistrationNumber(
      FunctionaryImportByRegistrationNumberRequestDto request) {
    return new IdentifiableExecutor(FunctionaryService.IMPORT_BY_REGISTRATION_NUMBER_IDENTIFIER)
        .execute(() -> service().importByRegistrationNumber(request));
  }

  /**
   * {@link FunctionaryService#importByRegistrationNumber}.
   *
   * @param registrationNumber matricule
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return identité
   */
  public IdentifiableResponseDto importByRegistrationNumber(String registrationNumber,
      String auditWho, String auditSession) {
    FunctionaryImportByRegistrationNumberRequestDto request =
        new FunctionaryImportByRegistrationNumberRequestDto();
    request.setRegistrationNumber(registrationNumber);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return importByRegistrationNumber(request);
  }

  /**
   * {@link FunctionaryService#importAll}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateManyResponseDto importAll(FunctionaryImportAllRequestDto request) {
    return new CreateManyExecutor(FunctionaryService.IMPORT_ALL_PATH)
        .setExpectedResponseStatusCode(Response.Status.OK.getStatusCode())
        .execute(() -> service().importAll(request));
  }
}
