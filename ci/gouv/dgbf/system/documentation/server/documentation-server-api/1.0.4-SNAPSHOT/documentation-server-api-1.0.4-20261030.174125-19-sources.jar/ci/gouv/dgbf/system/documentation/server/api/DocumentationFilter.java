package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de documentation.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentationFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du processus.
   */
  String processIdentifier;

  /**
   * Identifiant du source.
   */
  String sourceIdentifier;

  /**
   * Identifiant du enregistrement.
   */
  String recordIdentifier;

  /**
   * Identifiant du opération.
   */
  String operationIdentifier;

  /**
   * Cette méthode permet d'instancier.
   *
   * @param filter {@link FilterDto}
   */
  public DocumentationFilter(FilterDto filter) {
    super(filter);
  }

  /**
   * Cette méthode permet d'instancier.
   */
  public DocumentationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    processIdentifier = getProcessIdentifier(filter);
    sourceIdentifier = getSourceIdentifier(filter);
    recordIdentifier = getRecordIdentifier(filter);
    operationIdentifier = getOperationIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setProcessIdentifier(filter, processIdentifier);
    setSourceIdentifier(filter, sourceIdentifier);
    setRecordIdentifier(filter, recordIdentifier);
    setOperationIdentifier(filter, operationIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du processus.
   *
   * @param filter filtre
   * @param processIdentifier identifiant du processus
   */
  public static void setProcessIdentifier(FilterDto filter, String processIdentifier) {
    set(filter, JSON_PROCESS_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(processIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du processus -- sans elle, le critère serait
   * silencieusement ignoré et toutes les documentations seraient retournées.
   *
   * @param filter filtre
   * @return identifiant du processus
   */
  public static String getProcessIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESS_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #processIdentifier}.
   */
  public static final String JSON_PROCESS_IDENTIFIER =
      HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER;

  /**
   * Cette méthode permet d'assigner l'identifiant du source.
   *
   * @param filter filtre
   * @param sourceIdentifier identifiant du source
   */
  public static void setSourceIdentifier(FilterDto filter, String sourceIdentifier) {
    set(filter, JSON_SOURCE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(sourceIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du source -- sans elle, le critère serait
   * silencieusement ignoré et toutes les documentations seraient retournées.
   *
   * @param filter filtre
   * @return identifiant du source
   */
  public static String getSourceIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_SOURCE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #sourceIdentifier}.
   */
  public static final String JSON_SOURCE_IDENTIFIER =
      HasSourceIdentifierDto.JSON_SOURCE_IDENTIFIER;

  /**
   * Cette méthode permet d'assigner l'identifiant du enregistrement.
   *
   * @param filter filtre
   * @param recordIdentifier identifiant du enregistrement
   */
  public static void setRecordIdentifier(FilterDto filter, String recordIdentifier) {
    set(filter, JSON_RECORD_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(recordIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du enregistrement -- sans elle, le critère serait
   * silencieusement ignoré et toutes les documentations seraient retournées.
   *
   * @param filter filtre
   * @return identifiant du enregistrement
   */
  public static String getRecordIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_RECORD_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #recordIdentifier}.
   */
  public static final String JSON_RECORD_IDENTIFIER =
      HasRecordIdentifierDto.JSON_RECORD_IDENTIFIER;

  /**
   * Cette méthode permet d'assigner l'identifiant du opération.
   *
   * @param filter filtre
   * @param operationIdentifier identifiant du opération
   */
  public static void setOperationIdentifier(FilterDto filter, String operationIdentifier) {
    set(filter, JSON_OPERATION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(operationIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du opération -- sans elle, le critère serait
   * silencieusement ignoré et toutes les documentations seraient retournées.
   *
   * @param filter filtre
   * @return identifiant du opération
   */
  public static String getOperationIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_OPERATION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #operationIdentifier}.
   */
  public static final String JSON_OPERATION_IDENTIFIER =
      HasOperationIdentifierDto.JSON_OPERATION_IDENTIFIER;
}
