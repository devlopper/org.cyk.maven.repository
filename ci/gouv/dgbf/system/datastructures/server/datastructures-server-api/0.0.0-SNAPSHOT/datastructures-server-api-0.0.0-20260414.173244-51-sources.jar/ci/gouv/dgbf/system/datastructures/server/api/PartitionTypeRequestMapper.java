package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PartitionTypeDto}.
 *
 * @author Boobacool
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PartitionTypeDto}.
    
    @author Boobacool
    """)
public interface PartitionTypeRequestMapper
    extends
    RequestMapper<PartitionTypeDto, PartitionTypeService.PartitionTypeCreateRequestDto,
        PartitionTypeService.PartitionTypeUpdateRequestDto> {

}
