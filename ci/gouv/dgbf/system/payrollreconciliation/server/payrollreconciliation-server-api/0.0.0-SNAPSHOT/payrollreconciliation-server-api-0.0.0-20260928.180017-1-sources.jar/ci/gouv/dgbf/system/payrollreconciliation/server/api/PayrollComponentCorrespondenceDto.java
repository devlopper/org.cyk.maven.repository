package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une correspondance Poste Solde AN 2000 → Poste de Paie. Référentiel
 * propre à RAP avec CRUD complet.
 *
 * @author desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollComponentCorrespondenceDto extends AbstractIdentifiableAuditableDto {

  /**
   * Code du poste Solde AN 2000.
   */
  @JsonbProperty(JSON_LEGACY_COMPONENT_CODE)
  private String legacyComponentCode;

  /**
   * Code de la catégorie Solde AN 2000.
   */
  @JsonbProperty(JSON_LEGACY_CATEGORY_CODE)
  private String legacyCategoryCode;

  /**
   * Code de l'échelle corps Solde AN 2000.
   */
  @JsonbProperty(JSON_LEGACY_SCALE_CODE)
  private String legacyScaleCode;

  /**
   * Code du poste de paie cible.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_CODE)
  private String payrollComponentCode;

  /**
   * Indicateur Gain/Retenue.
   */
  @JsonbProperty(JSON_EARNING)
  private Boolean earning;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCorrespondance";

  /**
   * Identifiant json de la représentation en chaîne de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "correspondanceChaine";

  /**
   * Identifiant champ json {@link #legacyComponentCode}.
   */
  public static final String JSON_LEGACY_COMPONENT_CODE = "codePosteSoldeAn2000";

  /**
   * Identifiant champ json {@link #legacyCategoryCode}.
   */
  public static final String JSON_LEGACY_CATEGORY_CODE = "codeCategorieSoldeAn2000";

  /**
   * Identifiant champ json {@link #legacyScaleCode}.
   */
  public static final String JSON_LEGACY_SCALE_CODE = "codeEchelleCorpsSoldeAn2000";

  /**
   * Identifiant champ json {@link #payrollComponentCode}.
   */
  public static final String JSON_PAYROLL_COMPONENT_CODE = "postePaie";

  /**
   * Identifiant champ json {@link #earning}.
   */
  public static final String JSON_EARNING = "estGain";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "correspondance poste solde AN 2000";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "correspondances poste solde AN 2000";

}
