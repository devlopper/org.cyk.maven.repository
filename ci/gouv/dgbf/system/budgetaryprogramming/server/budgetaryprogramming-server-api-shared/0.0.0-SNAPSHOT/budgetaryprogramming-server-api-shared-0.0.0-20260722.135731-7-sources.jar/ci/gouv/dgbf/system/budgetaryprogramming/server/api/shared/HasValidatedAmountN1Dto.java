package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui expose la clé JSON de {@link HasValidatedAmountN1}.
 *
 * @author Christian
 */
public interface HasValidatedAmountN1Dto extends HasValidatedAmountN1 {

  /**
   * Identifiant json du montant validé à l'horizon N1.
   */
  String JSON_VALIDATED_AMOUNT_N1 = "montantValideN1";
}
