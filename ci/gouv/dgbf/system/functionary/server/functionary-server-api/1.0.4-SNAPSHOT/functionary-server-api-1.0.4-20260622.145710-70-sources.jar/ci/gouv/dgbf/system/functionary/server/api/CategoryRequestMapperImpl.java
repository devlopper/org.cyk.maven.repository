package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link CategoryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class CategoryRequestMapperImpl implements CategoryRequestMapper {

    @Override
    public CategoryService.CategoryCreateRequestDto mapCreate(CategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CategoryService.CategoryCreateRequestDto categoryCreateRequestDto = new CategoryService.CategoryCreateRequestDto();

        categoryCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        categoryCreateRequestDto.setCode( arg0.getCode() );
        categoryCreateRequestDto.setName( arg0.getName() );
        categoryCreateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return categoryCreateRequestDto;
    }

    @Override
    public CategoryService.CategoryUpdateRequestDto mapUpdate(CategoryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CategoryService.CategoryUpdateRequestDto categoryUpdateRequestDto = new CategoryService.CategoryUpdateRequestDto();

        categoryUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        categoryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        categoryUpdateRequestDto.setCode( arg0.getCode() );
        categoryUpdateRequestDto.setName( arg0.getName() );
        categoryUpdateRequestDto.setCivilServiceStatusIdentifier( arg0.getCivilServiceStatusIdentifier() );

        return categoryUpdateRequestDto;
    }
}
