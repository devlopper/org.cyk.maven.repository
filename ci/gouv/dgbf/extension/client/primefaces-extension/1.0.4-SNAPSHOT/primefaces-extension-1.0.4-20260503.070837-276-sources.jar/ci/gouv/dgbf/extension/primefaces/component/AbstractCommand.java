package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.Core.ConcatenateArguments;
import ci.gouv.dgbf.extension.core.NonBlankStringList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.apache.commons.lang3.StringUtils;

/**
 * Cette classe représente la base des commandes.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractCommand extends AbstractWidget {

  String value;
  String icon;
  String title;
  String update;

  Confirm confirm;

  Function<Object, String> actionFunction;

  /**
   * Cette méthode permet d'obtenir une confirmation.
   *
   * @return confirmation
   */
  public Confirm confirm() {
    if (confirm == null) {
      confirm = new Confirm();
    }
    return confirm;
  }

  /**
   * Cette méthode permet d'initialiser la confirmation.
   *
   * @param action action
   */
  public void initializeConfirm(String action) {
    value = StringUtils.capitalize(action);
    title = value;
    confirm().setMessageAreYouSureTo(action);
  }

  /**
   * Cette méthode permet d'ajouter des updates.
   *
   * @param updates updates
   * @return this
   */
  public AbstractCommand addUpdates(Set<String> updates) {
    NonBlankStringList strings = new NonBlankStringList();
    strings.add(update)
        .add(Optional.ofNullable(updates).orElse(Collections.emptySet()).stream().toList());
    update = Core.concatenate(new ConcatenateArguments(strings.getStrings()).separator(" "));
    return this;
  }

  public AbstractCommand addUpdates(String... updates) {
    return addUpdates(Arrays.stream(Optional.ofNullable(updates).orElse(new String[] {}))
        .collect(Collectors.toSet()));
  }

  public AbstractCommand addUpdate(String update) {
    return addUpdates(update);
  }

  /**
   * Cette méthode permet d'actioner.
   *
   * @param parameter paramètre
   * @return navigation
   */
  public String action(Object parameter) {
    return Core.applyFunction(actionFunction, parameter, null);
  }

  /**
   * Cette classe représente la base de constructeur.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public abstract static class AbstractBuilder<T extends AbstractCommand> {
    String value;
    String icon;
    String title;
    String update;
    Confirm.Builder confirmBuilder;
    Function<Object, String> actionFunction;

    protected T build() {
      T command = instantiate();
      command.value = value;
      command.icon = icon;
      command.title = title;
      command.update = update;
      Core.runIfNotNull(confirmBuilder, () -> command.confirm = confirmBuilder.build());
      command.actionFunction = actionFunction;
      return command;
    }

    protected abstract T instantiate();
  }
}
