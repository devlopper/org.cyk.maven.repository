package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementRequestMapperImpl implements PayrollElementRequestMapper {

    @Override
    public PayrollElementService.PayrollElementCreateRequestDto mapCreate(PayrollElementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementService.PayrollElementCreateRequestDto payrollElementCreateRequestDto = new PayrollElementService.PayrollElementCreateRequestDto();

        payrollElementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementCreateRequestDto.setCode( arg0.getCode() );
        payrollElementCreateRequestDto.setName( arg0.getName() );
        payrollElementCreateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return payrollElementCreateRequestDto;
    }

    @Override
    public PayrollElementService.PayrollElementUpdateRequestDto mapUpdate(PayrollElementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementService.PayrollElementUpdateRequestDto payrollElementUpdateRequestDto = new PayrollElementService.PayrollElementUpdateRequestDto();

        payrollElementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementUpdateRequestDto.setCode( arg0.getCode() );
        payrollElementUpdateRequestDto.setName( arg0.getName() );
        payrollElementUpdateRequestDto.setValueSourceIdentifier( arg0.getValueSourceIdentifier() );

        return payrollElementUpdateRequestDto;
    }
}
