package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link Location}.
 *
 * @author Christian
 *
 */
@Dependent
public class LocationSelectOneController extends AbstractSelectOneEnumerationController<Location> {

  /**
   * Cette méthode permet de construire.
   */
  protected LocationSelectOneController() {
    super(Location.values());
    outputLableValue = "Localisation";
  }
}

