package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityClient;
import ci.gouv.dgbf.system.user.server.api.UserCapacityDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityFilter;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupClient;
import ci.gouv.dgbf.system.user.server.api.UserGroupDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupFilter;
import ci.gouv.dgbf.system.user.server.api.UserGroupService.UserGroupGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupClient;
import ci.gouv.dgbf.system.user.server.api.UsersGroupDto;
import jakarta.inject.Inject;
import java.util.List;
import java.util.Map;
import lombok.Getter;

/**
 * Cette classe représente la classe dont herite les autres classes.
 *
 * @author Christian
 *
 */
public abstract class AbstractUsersGroupReadDatasPage extends AbstractPage {

  @Inject
  protected UsersGroupClient client;

  @Getter
  protected UsersGroupDto usersGroup;

  @Getter
  protected LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  protected UserGroupClient userGroupClient;

  @Inject
  protected UserCapacityClient userCapacityClient;

  @Inject
  protected IconManager iconManager;

  @Inject
  @Getter
  protected UsersGroupTabMenuController tabMenuController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + UsersGroupDto.NAME;
    String identifier = getRequestParameterIdentifier();

    usersGroup = client.getByIdentifier(identifier, instantiateProjection(), userIdentifier, null);

    buildLabelValueGroupsInformationCard();

    tabMenuController.usersGroup = usersGroup;
    tabMenuController.initialize();
  }

  /**
   * Cette méthode permet de construire {@link #labelValueGroupsInformationCard}.
   */
  protected void buildLabelValueGroupsInformationCard() {
    UsersGroupLabelValueGroupsInformationCardBuilder builder =
        new UsersGroupLabelValueGroupsInformationCardBuilder(iconManager);
    builder.code(usersGroup.getCode()).name(usersGroup.getName())
        .module(usersGroup.getModuleAsString()).capacityLines(computeCapacityLines());
    labelValueGroupsInformationCard = builder.build();
  }

  /**
   * Cette méthode permet de lire les membres du Groupe par Qualité (Responsable et Superviseur
   * mis en avant).
   *
   * @return lignes (libellé de la Qualité, noms des membres)
   */
  protected Map<String, String> computeCapacityLines() {
    return UsersGroupMembersByCapacity.lines(readCapacities(), readMembers());
  }

  List<UserCapacityDto> readCapacities() {
    GetManyRequestDto request = new GetManyRequestDto();
    request.useFilter(new UserCapacityFilter());
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME);
    request.setAuditWho(userIdentifier);
    return UserCapacityGetManyResponseDto.getDatas(UserCapacityDto.class,
        userCapacityClient.getMany(request));
  }

  List<UserGroupDto> readMembers() {
    UserGroupFilter filter = new UserGroupFilter();
    filter.setGroupIdentifier(usersGroup.getIdentifier());
    GetManyRequestDto request = new GetManyRequestDto();
    request.useFilter(filter);
    request.projection().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        UserGroupDto.JSON_USER_AS_STRING, UserGroupDto.JSON_CAPACITY_IDENTIFIER);
    request.setAuditWho(userIdentifier);
    return UserGroupGetManyResponseDto.getDatas(UserGroupDto.class,
        userGroupClient.getMany(request));
  }

  /**
   * Cette méthode permet d'instancier {@link ProjectionDto}.
   *
   * @return {@link ProjectionDto}
   */
  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableCodableDto.JSON_CODE, AbstractIdentifiableCodableNamableDto.JSON_NAME,
        UsersGroupDto.JSON_MODULE_AS_STRING);
  }
}
