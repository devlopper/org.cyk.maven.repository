package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page de liste de {@link DocumentGroupDto}.
 *
 * @author Christian
 *
 */
@Named
@ViewScoped
public class DocumentGroupListPage extends AbstractPage {

  @Inject
  @Getter
  DocumentGroupController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + DocumentGroupDto.NAME;
  }

  public static final String OUTCOME = "documentGroupListPage";
}
