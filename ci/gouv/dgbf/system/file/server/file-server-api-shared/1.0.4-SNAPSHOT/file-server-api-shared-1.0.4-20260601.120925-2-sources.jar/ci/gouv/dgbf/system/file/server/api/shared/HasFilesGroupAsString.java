package ci.gouv.dgbf.system.file.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères de groupe
 * de fichiers.
 *
 * @author Christian
 */
public interface HasFilesGroupAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du groupe de fichiers.
   *
   * @return représentation en chaine de caractères du groupe de fichiers
   */
  String getFilesGroupAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du groupe de
   * fichiers.
   *
   * @param asString représentation en chaine de caractères du groupe de fichiers
   */
  void setFilesGroupAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères du groupe de fichiers.
   */
  String FIELD_FILES_GROUP_AS_STRING = "filesGroupAsString";
}
