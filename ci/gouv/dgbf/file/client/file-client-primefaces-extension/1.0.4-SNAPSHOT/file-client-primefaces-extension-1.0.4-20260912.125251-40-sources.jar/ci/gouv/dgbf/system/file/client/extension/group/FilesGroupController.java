package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.segregation.HasFileCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.SelectBooleanController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FilesGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FilesGroupController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FilesGroupRequestMapper requestMapper;

  @Inject
  @Getter
  SelectBooleanController isConfirmedSelectBooleanController;

  @Inject
  @Getter
  FilesGroupUploadController uploadController;
  
  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FilesGroupDto.NAME;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FilesGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FilesGroupService.PATH);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER, HasStatusDto.JSON_STATUS,
        HasPlannedPurgeDateAsStringDto.JSON_PLANNED_PURGE_DATE_AS_STRING,
        HasFileCountAsStringDto.JSON_FILE_COUNT_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.initialize();

    listController.getCreateController().setFunction(createFunction());

    listController.getUpdateController().addEntityConsumer(entity -> uploadController
        .loadExisting(((FilesGroupDto) entity).getIdentifier(), userIdentifier));
    listController.getUpdateController().setFunction(updateFunction());

    listController.getGotoReadPageButton().setOutcome(FilesGroupReadPage.OUTCOME);
    listController.getGotoReadPageButton().setRendered(true);

    isConfirmedSelectBooleanController.setOutputLableValue("Est confirmé ?");
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean().addTrueOrFalseChoices();
    isConfirmedSelectBooleanController.getSelectOneRadioBoolean()
        .addValueConsumer(isConfirmedConsumer());
  }

  Function<Object, Object> createFunction() {
    return entity -> {
      FilesGroupCreateRequestDto request = requestMapper.mapCreate((FilesGroupDto) entity);
      request.setAuditWho(userIdentifier);
      request.setAuditSession(UUID.randomUUID().toString());
      CreateResponseDto response = client.create(request);
      uploadController.createFiles(response.getIdentifier(), request.getAuditSession());
      return response;
    };
  }
  
  Function<Object, Object> updateFunction() {
    return entity -> {
      FilesGroupUpdateRequestDto request = requestMapper.mapUpdate((FilesGroupDto) entity);
      request.setAuditWho(userIdentifier);
      IdentifiableResponseDto response = client.update(request);
      uploadController.update(response.getIdentifier(), userIdentifier);
      return response;
    };
  }

  Consumer<Boolean> isConfirmedConsumer() {
    return value -> listController
        .getCreateControllerOrUpdateControllerEntityAs(FilesGroupDto.class).setIsConfirmed(value);
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(isConfirmedSelectBooleanController.getSelectOneRadioBoolean()).stream()
        .map(input -> input.getMessage().getIdentifier()).collect(Collectors.joining(","));
  }
}
