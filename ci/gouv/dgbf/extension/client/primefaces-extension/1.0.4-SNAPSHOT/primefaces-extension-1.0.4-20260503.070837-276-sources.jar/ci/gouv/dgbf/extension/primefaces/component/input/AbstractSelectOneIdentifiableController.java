package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.NamableByString;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.component.OutputLabel;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.filter.SearchTextFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.HasFilter;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import jakarta.faces.model.SelectItem;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un contrôleur d'un sélecteur d'un identifiable.
 *
 * @author Christian
 *
 */
public abstract class AbstractSelectOneIdentifiableController<T extends AbstractIdentifiableDto,
    R extends AbstractGetByPageResponseDto<T>, C extends GetMany<R>>
    extends AbstractSelectOneController implements HasFilter {

  /* Data */

  @Getter
  @Setter
  protected ProjectionDto projection;

  @Getter
  @Setter
  protected FilterDto filter;

  protected PageDto page;

  Class<T> clazz;

  protected AbstractSelectOneIdentifiableController(Class<T> clazz,
      SelectItemLabelStrategy selectItemLabelStrategy) {
    this.clazz = clazz;
    this.selectItemLabelStrategy =
        Core.getOrDefaultIfNull(selectItemLabelStrategy, SelectItemLabelStrategy.AUTO);
    buildProjection(clazz, this.selectItemLabelStrategy);
  }

  protected AbstractSelectOneIdentifiableController(Class<T> clazz) {
    this(clazz, SelectItemLabelStrategy.AUTO);
  }

  void buildProjection(Class<?> clazz, SelectItemLabelStrategy selectItemLabelStrategy) {
    projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    if (SelectItemLabelStrategy.AS_STRING.equals(selectItemLabelStrategy)) {
      projection.addNames(AbstractIdentifiableDto.JSON_AS_STRING);
    }
    if (SelectItemLabelStrategy.CODE_NAME.equals(selectItemLabelStrategy)) {
      projection.addNames(AbstractIdentifiableCodableDto.JSON_CODE);
    }
    if ((SelectItemLabelStrategy.AUTO.equals(selectItemLabelStrategy)
        && NamableByString.class.isAssignableFrom(clazz))
        || SelectItemLabelStrategy.CODE_NAME.equals(selectItemLabelStrategy)
        || SelectItemLabelStrategy.NAME.equals(selectItemLabelStrategy)) {
      projection.addNames(AbstractIdentifiableCodableNamableDto.JSON_NAME);
    }
  }

  protected abstract C getClient();

  /*  */

  /**
   * Cette méthode permet d'obtenir une page non nulle.
   *
   * @return page non nulle
   */
  public PageDto page() {
    if (page == null) {
      page = new PageDto();
    }
    return page;
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return Optional.ofNullable(instantiateActionExecutor().execute())
        .orElse(Collections.emptyList()).stream().map(this::instantiateSelectItem).toList();
  }

  @SuppressWarnings("unchecked")
  protected ActionExecutor<List<T>> instantiateActionExecutor() {
    return new ActionExecutor<>(this, String.format("Obtention de plusieurs %s", clazz.getName()),
        () -> (List<T>) AbstractGetByPageResponseDto
            .getDatas(getClient().getMany(projection, filter, page, userIdentifier, null)));
  }

  @Override
  protected void processOutputLabel(OutputLabel outputLabel) {
    outputLabel.setValue(Core.getHumanReadableClassName(clazz));
  }

  protected SelectItem instantiateSelectItem(T dto) {
    SelectItem selectItem = new SelectItem();
    processSelectItem(dto, selectItem);
    return selectItem;
  }

  protected void processSelectItem(T dto, SelectItem selectItem) {
    selectItem.setValue(dto.getIdentifier());
    selectItem.setLabel(buildSelectItemLabel(dto));
  }

  protected String buildSelectItemLabel(T dto) {
    String label;
    if (SelectItemLabelStrategy.CODE_NAME.equals(selectItemLabelStrategy)) {
      label = String.format("%s %s", Core.getCode(dto), Core.getName(dto));
    } else if (SelectItemLabelStrategy.AS_STRING.equals(selectItemLabelStrategy)) {
      label = Core.getAsString(dto);
    } else {
      label = Core.getName(dto);
    }
    return label;
  }

  @Override
  protected void processAutoComplete(AutoCompleteString autoComplete) {
    super.processAutoComplete(autoComplete);
    autoComplete.setOnCompleteFunction(this::getAutoCompleteSuggestions);
  }

  @SuppressWarnings("unchecked")
  List<Object> getAutoCompleteSuggestions(String query) {
    List<Object> suggestions;
    if (choicable) {
      filter().setCriteria(SearchTextFilter.JSON_KEY, query);
      page().setIndex(0);
      page().setSize(autoComplete.getMaxResults() + 1); // + 1 is used to enabled moreText option.
      suggestions = (List<Object>) (List<?>) Optional
          .ofNullable(instantiateActionExecutor().execute()).orElse(Collections.emptyList());
    } else {
      suggestions = Collections.emptyList();
    }
    return suggestions;
  }
}
