package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupGetManyResponseDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;

/**
 * Cette classe représente un client de {@link FilesGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class FilesGroupClient extends AbstractClient<FilesGroupService>
    implements GetByIdentifier<FilesGroupDto>, GetMany<FilesGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Inject
  FileGroupClient fileGroupClient;

  @Inject
  FileClient fileClient;

  @Override
  public FilesGroupClient service(FilesGroupService service) {
    return (FilesGroupClient) super.service(service);
  }

  /**
   * {@link FilesGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FilesGroupCreateRequestDto request) {
    return new CreateExecutor(FilesGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FilesGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FilesGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FilesGroupGetManyResponseDto>(FilesGroupGetManyResponseDto.class,
        FilesGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * Cette méthode permet d'obtenir des groupes de fichiers.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FilesGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FilesGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FilesGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FilesGroupDto>(FilesGroupDto.class,
        FilesGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * Cette méthode permet d'obtenir un groupe de fichiers.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FilesGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }
  
  /**
   * {@link FilesGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return {@link FilesGroupDto}
   */
  public FilesGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FilesGroupDto>(FilesGroupDto.class,
        FilesGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FilesGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return {@link FilesGroupDto}
   */
  @Override
  public FilesGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FilesGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FilesGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(FilesGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FilesGroupService#update}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String auditWho, String auditSession) {
    FilesGroupUpdateRequestDto request = new FilesGroupUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link FilesGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FilesGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un groupe de fichier.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
