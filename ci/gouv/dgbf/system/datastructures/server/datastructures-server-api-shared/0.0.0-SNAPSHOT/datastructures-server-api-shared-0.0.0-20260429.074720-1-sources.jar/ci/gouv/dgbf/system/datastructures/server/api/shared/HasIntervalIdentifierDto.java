package ci.gouv.dgbf.system.datastructures.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant d'intervalle.
 *
 * @author Christian
 */
public interface HasIntervalIdentifierDto extends HasIntervalIdentifier {

  /**
   * Identifiant json de l'identifiant de l'intervalle.
   */
  String JSON_INTERVAL_IDENTIFIER = "idIntervalle";
}