package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.Column;
import ci.gouv.dgbf.extension.primefaces.component.ColumnDetail;
import ci.gouv.dgbf.extension.primefaces.component.ColumnType;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.extension.primefaces.crud.IdentifiableProcessingController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController.FormLayout;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationClient;
import ci.gouv.dgbf.system.user.server.api.ApplicationDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationRequestMapper;
import ci.gouv.dgbf.system.user.server.api.ApplicationService;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.ApplicationService.ApplicationUpdateRequestDto;
import ci.gouv.dgbf.system.user.server.api.ReservedRole;
import ci.gouv.dgbf.system.user.server.api.RoleClient;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import ci.gouv.dgbf.system.user.server.api.UserRole;
import ci.gouv.dgbf.system.user.server.api.UserRoleClient;
import ci.gouv.dgbf.system.user.server.api.UserRoleService;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.config.inject.ConfigProperty;

/**
 * Cette classe représente le contrôleur de {@link ApplicationDto}.
 *
 * @author BoobaCool
 */
@Dependent
public class ApplicationController extends AbstractController {
  /** Longueur de la colonne CODE (évolution SQL 007). */
  static final int CODE_MAX_LENGTH = 64;


  @Inject
  ApplicationClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  ApplicationFilterController filterController;

  /** Colonnes de la liste : identité (libellé, code, Domaine) puis nombres (RU_UTI_027 CA7). */
  @Getter
  Column identityColumn;

  @Getter
  Column roleCountColumn;

  @Getter
  Column userCountColumn;

  @Getter
  Column pendingRoleSolicitationCountColumn;

  /** Rôles de l'utilisateur du filtre {@code userName} sur la ligne, rendue si ce filtre existe. */
  @Getter
  Column roleNamesOfUserColumn;

  /** Présentation des Applications dans le profil de l'utilisateur connecté. */
  @Getter
  @Setter
  boolean profileView;

  /** Indicateurs globaux, affichés dans les vues d'administration. */
  @Getter
  @Setter
  boolean statisticsRendered = true;

  @Inject
  ApplicationRequestMapper requestMapper;

  @Inject
  @Getter
  InputTextController codeInputTextController;

  @Inject
  @Getter
  InputTextController nameInputTextController;

  @Inject
  @Getter
  DomainSelectOneController domainSelectOneController;

  @Inject
  @Getter
  IdentifiableProcessingController assignUsersRolesProcessingController;

  @Inject
  UserClient userClient;

  @Inject
  @Getter
  RoleSelectManyController roleSelectManyController;
  @Inject
  @Getter
  UserSelectManyController userSelectManyController;

  @Getter
  @Inject
  UserRoleClient userRoleClient;

  @Inject
  RoleClient roleClient;

  @Inject
  @Getter
  IdentifiableProcessingController assignAdministratorProcessingController;

  @Inject
  @Getter
  UserSelectManyController assignAdministratorUserSelectManyController;

  @Inject
  @Getter
  IdentifiableProcessingController assignTechnicalAdministratorProcessingController;

  @Inject
  @Getter
  UserSelectManyController assignTechnicalAdministratorUserSelectManyController;

  @Inject
  @Getter
  IdentifiableProcessingController assignFunctionalAdministratorProcessingController;

  @Inject
  @Getter
  UserSelectManyController assignFunctionalAdministratorUserSelectManyController;

  @Inject
  @Getter
  UserRoleCreateManyController createManyController;

  @Inject
  UserRights userRights;

  @Inject
  @ConfigProperty(name = "dgbf.user.special-application.code",
      defaultValue = "mic-utilisateur-api")
  String specialApplicationCode;


  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ApplicationDto.NAME;
  }

  void initializeColumns(boolean domainProjected, boolean roleNamesOfUserProjected) {
    identityColumn = new Column();
    identityColumn.initializeAsIdentity();
    if (profileView) {
      identityColumn.setHeaderText("Libellé");
      identityColumn.setCodeFieldName(null);
    }
    ColumnDetail domain = new ColumnDetail();
    domain.setFieldName("domainAsString");
    domain.setTitle("Domaine");
    domain.setRendered(domainProjected);
    identityColumn.addDetail(domain);

    roleCountColumn = newCountColumn("Rôles", "roleCountAsString", "90px");
    userCountColumn = newCountColumn("Utilisateurs", "userCountAsString", "120px");
    pendingRoleSolicitationCountColumn =
        newCountColumn("Demandes en attente", "pendingRoleSolicitationCountAsString", "190px");
    roleCountColumn.setRendered(statisticsRendered);
    userCountColumn.setRendered(statisticsRendered);
    pendingRoleSolicitationCountColumn.setRendered(statisticsRendered);

    roleNamesOfUserColumn = new Column();
    // "Rôles" déjà pris par roleCountColumn (nombre total de Rôles de l'Application)
    roleNamesOfUserColumn.setHeaderText("Mes rôles");
    roleNamesOfUserColumn.setFieldName("roleNamesOfUserAsString");
    roleNamesOfUserColumn.typed(ColumnType.TEXT);
    roleNamesOfUserColumn.setRendered(roleNamesOfUserProjected && !profileView);
  }

  /**
   * Cette méthode fournit le fragment de la cellule d'identité selon la vue.
   *
   * @return chemin du fragment
   */
  public String getIdentityColumnFilePath() {
    return profileView ? "/user/component/application/profileIdentityColumn.xhtml"
        : "/extension/component/column/identity.xhtml";
  }

  static Column newCountColumn(String headerText, String fieldName, String width) {
    Column column = new Column();
    column.setHeaderText(headerText);
    column.setFieldName(fieldName);
    column.setWidth(width);
    column.typed(ColumnType.NUMBER);
    return column;
  }

  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setFilterController(filterController);
    listController.setEntityClass(ApplicationDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ApplicationService.PATH);

    ProjectionDto projection =
        new ProjectionDto()
            .addNames(
                AbstractIdentifiableDto.JSON_IDENTIFIER,
                AbstractIdentifiableCodableDto.JSON_CODE,
                AbstractIdentifiableCodableNamableDto.JSON_NAME,
                ApplicationDto.JSON_DOMAIN_CODE);
    // Domaine connu via filtre → libellé inutile en liste
    if (filterController.getFilter().getDomainIdentifier() == null) {
      projection.addNames(ApplicationDto.JSON_DOMAIN_AS_STRING);
    }

    // Nombres calculés par le serveur avec la lecture de la liste (RU_UTI_027 CA7)
    if (statisticsRendered) {
      projection.addNames(
          ApplicationDto.JSON_ROLE_COUNT_AS_STRING,
          ApplicationDto.JSON_USER_COUNT_AS_STRING,
          ApplicationDto.JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING);
    }

    if (profileView) {
      // L'utilisateur et le Domaine sont imposés par le maître du profil.
      filterController.getDomainSelectOneController().getSelectOneMenu().setRendered(false);
      filterController.getUserIdentifierInputTextController().getInputText().setRendered(false);
    }

    // Rôles de l'utilisateur du filtre sur chaque ligne, seulement si ce filtre est utilisé
    boolean roleNamesOfUserProjected = filterController.getFilter().getUserName() != null;
    if (roleNamesOfUserProjected) {
      projection.addNames(ApplicationDto.JSON_ROLE_NAMES_OF_USER);
    }

    initializeColumns(projection.getNames().contains(ApplicationDto.JSON_DOMAIN_AS_STRING),
        roleNamesOfUserProjected);

    listController.getReadController().setProjection(projection);
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(ApplicationReadUsersPage.OUTCOME);

    listController.setFormLayout(FormLayout.STACKED);
    listController.initialize();

    listController
        .getCreateController()
        .setFunction(
            entity -> {
              ApplicationCreateRequestDto request =
                  requestMapper.mapCreate((ApplicationDto) entity);
              request.setAuditWho(userIdentifier);
              return client.create(request);
            });

    listController
        .getUpdateController()
        .setProjection(
            new ProjectionDto()
                .addNames(
                    AbstractIdentifiableDto.JSON_IDENTIFIER,
                    AbstractIdentifiableCodableDto.JSON_CODE,
                    AbstractIdentifiableCodableNamableDto.JSON_NAME,
                    ApplicationDto.JSON_DOMAIN_IDENTIFIER,
                    ApplicationDto.JSON_DOMAIN_AS_STRING));

    listController.getCreateController().addEntityConsumer(createControllerEntityConsumer());
    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());

    listController.getUpdateController().setFunction(updateControllerFunction());
    // Droits calculés à partir des Rôles réservés, ligne par ligne (RG_UTI_ROL_16)
    listController.getShowCreateDialogButton()
        .setRendered(isUserInRoleOnOwnDomain(UserRole.MANAGE_APPLICATION));
    // Application spéciale du Domaine ni modifiée ni supprimée depuis la liste (RU_UTI_027)
    listController.getShowUpdateDialogButtonController()
        .setRenderedFunction(row -> isUserInRoleOnOrdinary(UserRole.MANAGE_APPLICATION, row));
    listController.getDeleteButtonController()
        .setRenderedFunction(row -> isUserInRoleOnOrdinary(UserRole.MANAGE_APPLICATION, row));

    codeInputTextController.initializeCode(codeConsumer(), CODE_MAX_LENGTH);
    nameInputTextController.initializeName(nameConsumer());

    domainSelectOneController.getSelectOneMenu().setRequired(true);
    domainSelectOneController.getSelectOneMenu().container().addStyleClass("dgbf-form-field-wide");
    domainSelectOneController.getSelectOneMenu().addValueConsumer(domainIdentifierConsumer());

    assignUsersRolesProcessingController.setViewer(IdentifiableProcessingController.Viewer.DIALOG);
    // Liste fournie avant la préparation : bouton de ligne en icône seule, avec infobulle
    assignUsersRolesProcessingController.setListController(listController);
    assignUsersRolesProcessingController.prepareDialog(
        ApplicationDto.class,
        "Assigner un rôle",
        "pi pi-users",
        assignUsersRolesFunction(),
        "assignUsersRolesForm",
        client);
    assignUsersRolesProcessingController.addShowDialogConsumer(loadRoleByApplicationIdentifier());
    assignUsersRolesProcessingController.setShowDialogButtonControllerRenderedFunction(
        row -> isUserInRoleOnOrdinary(UserRole.ASSIGN_USER_ROLE, row));
    assignUsersRolesProcessingController.initialize();

    roleSelectManyController.setOutputLableValue("Rôles à assigner");
    roleSelectManyController.getSelectManyCheckbox().setRequired(true);
    roleSelectManyController.setChoicable(true);
    roleSelectManyController.getSelectManyCheckbox().setLayout("responsive");
    roleSelectManyController.getSelectManyCheckbox().setColumns(3);

    userSelectManyController.setOutputLableValue("Utilisateurs");
    userSelectManyController.getAutoComplete().setMultiple(true);
    userSelectManyController
        .getAutoComplete()
        .setOnCompleteFunction(query -> new ArrayList<>(completeUser(query)));

    prepareAssignAdministrator(assignAdministratorProcessingController,
        assignAdministratorUserSelectManyController, "Désigner administrateur applicatif",
        assignAdministratorFunction(), UserRole.ASSIGN_APPLICATION_ADMINISTRATOR_USER_ROLE,
        "assignAdministratorForm");
    // Désignations Technique et Fonctionnelle indépendantes l'une de l'autre (TCH_UTI_707)
    prepareAssignAdministrator(assignTechnicalAdministratorProcessingController,
        assignTechnicalAdministratorUserSelectManyController,
        "Désigner administrateur technique", assignTechnicalAdministratorFunction(),
        UserRole.ASSIGN_TECHNICAL_ADMINISTRATOR_USER_ROLE, "assignTechnicalAdministratorForm");
    prepareAssignAdministrator(assignFunctionalAdministratorProcessingController,
        assignFunctionalAdministratorUserSelectManyController,
        "Désigner administrateur fonctionnel", assignFunctionalAdministratorFunction(),
        UserRole.ASSIGN_FUNCTIONAL_ADMINISTRATOR_USER_ROLE, "assignFunctionalAdministratorForm");
  }

  void prepareAssignAdministrator(IdentifiableProcessingController processingController,
      UserSelectManyController users, String title, UnaryOperator<Object> function,
      UserRole right, String formName) {
    // Seuls les Utilisateurs du Domaine de l'Application sont proposés (RG_UTI_ROL_15)
    AtomicReference<String> domainIdentifier = new AtomicReference<>();
    users.setOutputLableValue("Utilisateurs");
    users.getAutoComplete().setMultiple(true);
    users.getAutoComplete().setOnCompleteFunction(
        query -> new ArrayList<>(completeUser(query, domainIdentifier.get())));
    processingController.setViewer(IdentifiableProcessingController.Viewer.DIALOG);
    // Liste fournie avant la préparation : bouton de ligne en icône seule, avec infobulle
    processingController.setListController(listController);
    // Nom de formulaire propre à chaque boîte : il en fait l'identifiant
    processingController.prepareDialog(ApplicationDto.class, title, "pi pi-user-plus", function,
        formName, client);
    // Saisie précédente de cette boîte de dialogue effacée à chaque ouverture
    processingController.addShowDialogConsumer(identifier -> {
      users.getAutoComplete().writeValue(new ArrayList<>());
      domainIdentifier.set(getDomainIdentifier(identifier));
    });
    processingController.initialize();
    processingController.setShowDialogButtonControllerRenderedFunction(
        row -> isUserInRole(right, row));
  }

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit sur l'Application d'une ligne
   * (RG_UTI_ROL_16).
   *
   * @param right Droit
   * @param row   ligne ({@link ApplicationDto})
   * @return vrai s'il l'a
   */
  protected boolean isUserInRole(UserRole right, Object row) {
    ApplicationDto application = (ApplicationDto) row;
    return application != null && userRights.isGranted(right, application.getDomainCode(),
        application.getCode());
  }

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit sur l'Application d'une ligne qui
   * n'est pas l'Application spéciale de son Domaine (RU_UTI_027).
   *
   * @param right Droit
   * @param row   ligne ({@link ApplicationDto})
   * @return vrai s'il l'a et que l'Application n'est pas l'Application spéciale
   */
  protected boolean isUserInRoleOnOrdinary(UserRole right, Object row) {
    return row != null
        && !Objects.equals(((ApplicationDto) row).getCode(), specialApplicationCode)
        && isUserInRole(right, row);
  }

  /**
   * Cette méthode indique si l'Utilisateur connecté a un Droit sur son propre Domaine.
   *
   * @param right Droit
   * @return vrai s'il l'a
   */
  protected boolean isUserInRoleOnOwnDomain(UserRole right) {
    return userRights.isGrantedOnOwnDomain(right);
  }

  /**
   * Méthode de complétion pour l'autocomplete des utilisateurs.
   *
   * @param query la chaîne de recherche
   * @return la liste des utilisateurs correspondants
   */
  public List<UserDto> completeUser(String query) {
    return completeUser(query, null);
  }

  /**
   * Méthode de complétion des utilisateurs, restreinte à un Domaine s'il est connu.
   *
   * @param query            la chaîne de recherche
   * @param domainIdentifier identifiant du Domaine, ou null pour tous
   * @return la liste des utilisateurs correspondants
   */
  public List<UserDto> completeUser(String query, String domainIdentifier) {
    if (query == null || query.trim().isEmpty()) {
      return List.of();
    }
    UserFilter filter = new UserFilter();
    filter.setNameContains("%" + query + "%");
    filter.setDomainIdentifier(domainIdentifier);
    PageDto pageDto = new PageDto();
    pageDto.setIndex(0);
    pageDto.setSize(20);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(
        AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME,
        UserDto.JSON_IDENTITY_AS_STRING);
    UserGetManyResponseDto response =
        userClient.getMany(projection, filter.toDto(), pageDto, userIdentifier, null);
    return response != null && response.getDatas() != null
        ? response.getDatas()
        : List.of();
  }

  /**
   * Méthode pour obtenir le label d'affichage d'un utilisateur.
   *
   * @param user l'utilisateur
   * @return le label formaté
   */
  public String getUserLabel(UserDto user) {
    return user.getName() + " (" + user.getIdentityAsString() + ")";
  }

  Consumer<Object> createControllerEntityConsumer() {
    return entity -> setCodeAndDomainDisabled(false);
  }

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      // Code et Domaine ne changent plus après la création : la requête de mise à jour ne
      // les porte pas
      setCodeAndDomainDisabled(true);
      codeInputTextController.getInputText().writeValue(((ApplicationDto) entity).getCode());
      nameInputTextController.getInputText().writeValue(((ApplicationDto) entity).getName());
      domainSelectOneController
          .getSelectOneMenu()
          .writeValue(((ApplicationDto) entity).getDomainIdentifier());
    };
  }

  void setCodeAndDomainDisabled(boolean disabled) {
    codeInputTextController.getInputText().setReadOnly(disabled);
    domainSelectOneController.getSelectOneMenu().setDisabled(disabled);
  }

  Consumer<String> domainIdentifierConsumer() {
    return identifier ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setDomainIdentifier(identifier);
  }

  Consumer<String> codeConsumer() {
    return code ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setCode(code);
  }

  Consumer<String> nameConsumer() {
    return name ->
        listController
            .getCreateControllerOrUpdateControllerEntityAs(ApplicationDto.class)
            .setName(name);
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      ApplicationUpdateRequestDto request = requestMapper.mapUpdate((ApplicationDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }

  /**
   * Cette méthode permet d'obtenir la concatenation des identifiants des messages.
   *
   * @return concatenation des identifiants des messages
   */
  public String getComaSeparatedMessagesIdentifiers() {
    return List.of(codeInputTextController.getInputText(), nameInputTextController.getInputText())
        .stream()
        .map(input -> input.getMessage().getIdentifier())
        .collect(Collectors.joining(","));
  }

  /**
   * Cette méthode permet de charger les rôles par identifiant de l'application.
   */
  Consumer<String> loadRoleByApplicationIdentifier() {
    return applicationIdentifier -> {
      RoleFilter roleFilter = new RoleFilter();
      roleFilter.setApplicationIdentifier(applicationIdentifier);
      // Les Rôles réservés se désignent, ils ne s'attribuent pas (RG_UTI_ROL_17)
      roleFilter.setExcludedCodes(ReservedRole.CODES);
      roleSelectManyController.setFilter(roleFilter.toDto());
      roleSelectManyController.computeSelectManyCheckboxChoices();
    };
  }


  /**
   * Cette méthode permet de créer plusieurs rôles pour plusieurs utilisateurs.
   *
   * @return la fonction de création de plusieurs rôles
   */
  UnaryOperator<Object> assignUsersRolesFunction() {
    return input -> {
      Set<String> selectedRoleIds =
          new HashSet<>(roleSelectManyController.getSelectManyCheckbox().getValue());
      UserRoleService.UserRoleCreateManyRequestDto request =
          new UserRoleService.UserRoleCreateManyRequestDto();
      request.setUserIdentifiers(
          new HashSet<>(userSelectManyController.getAutoComplete().getValue()));
      request.setRoleIdentifiers(selectedRoleIds);
      request.setAuditWho(userIdentifier);
      return userRoleClient.createMany(request);
    };
  }

  /**
   * Fonction d'assignation du rôle administrateur applicatif.
   *
   * @return l'opérateur appliqué à l'entité {@link ApplicationDto} de la ligne courante
   */
  String getDomainIdentifier(String applicationIdentifier) {
    ApplicationDto application = client.getByIdentifier(applicationIdentifier,
        new ProjectionDto().addNames(ApplicationDto.JSON_DOMAIN_IDENTIFIER), userIdentifier,
        null);
    return application == null ? null : application.getDomainIdentifier();
  }

  UnaryOperator<Object> assignAdministratorFunction() {
    return assignFunction(assignAdministratorUserSelectManyController,
        client::assignAdministrator);
  }

  UnaryOperator<Object> assignTechnicalAdministratorFunction() {
    return assignFunction(assignTechnicalAdministratorUserSelectManyController,
        client::assignTechnicalAdministrator);
  }

  UnaryOperator<Object> assignFunctionalAdministratorFunction() {
    return assignFunction(assignFunctionalAdministratorUserSelectManyController,
        client::assignFunctionalAdministrator);
  }

  UnaryOperator<Object> assignFunction(UserSelectManyController users,
      Function<ApplicationService.ApplicationAssignAdministratorRequestDto, Object> call) {
    return input -> {
      ApplicationDto application = (ApplicationDto) input;
      ApplicationService.ApplicationAssignAdministratorRequestDto request =
          new ApplicationService.ApplicationAssignAdministratorRequestDto();
      request.setIdentifier(application.getIdentifier());
      request.setUserIdentifiers(new HashSet<>(users.getAutoComplete().getValue()));
      request.setAuditWho(userIdentifier);
      return call.apply(request);
    };
  }
}
