package ci.gouv.dgbf.system.localauthority.server.api;

/**
 * Cette classe représente le code de {@link BudgetStatus}.
 *
 * @author Donsylla
 *
 */
public class BudgetStatusCode {

  private BudgetStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Validé.
   */
  public static final String VALIDATED = "VALIDE";

  /**
   * Transmis.
   */
  public static final String TRANSMITTED = "TRANSMIS";

  /**
   * Différé.
   */
  public static final String DEFERRED = "DIFFERE";

  /**
   * Approuvé.
   */
  public static final String APPROVED = "APPROUVE";

  /**
   * Clôturé.
   */
  public static final String CLOSED = "CLOTURE";
}
