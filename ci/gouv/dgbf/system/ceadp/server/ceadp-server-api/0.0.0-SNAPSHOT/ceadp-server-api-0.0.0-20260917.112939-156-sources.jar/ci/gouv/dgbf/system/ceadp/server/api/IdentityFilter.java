package ci.gouv.dgbf.system.ceadp.server.api;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityFilter extends AbstractIdentificationFilter {

}

