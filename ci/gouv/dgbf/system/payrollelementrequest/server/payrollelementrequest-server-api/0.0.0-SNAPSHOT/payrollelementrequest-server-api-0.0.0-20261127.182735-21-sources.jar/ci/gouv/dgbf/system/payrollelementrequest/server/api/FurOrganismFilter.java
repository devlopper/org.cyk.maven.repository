package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FurOrganismDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FurOrganismFilter extends AbstractIdentifiableFilter {

  /**
   * Code organisme du FUR.
   */
  String organismCode;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FurOrganismFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FurOrganismFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    organismCode = getOrganismCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setOrganismCode(filter, organismCode);
  }

  /**
   * Cette méthode permet d'assigner le code organisme.
   *
   * @param filter filtre
   * @param organismCode code organisme
   */
  public static void setOrganismCode(FilterDto filter, String organismCode) {
    set(filter, JSON_ORGANISM_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(organismCode));
  }

  /**
   * Cette méthode permet d'obtenir le code organisme.
   *
   * @param filter filtre
   * @return code organisme
   */
  public static String getOrganismCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ORGANISM_CODE));
  }

  /**
   * Identifiant json champ {@link #organismCode}.
   */
  public static final String JSON_ORGANISM_CODE = FurOrganismDto.JSON_ORGANISM_CODE;
}
