package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileStatus}.
 *
 * @author Christian
 *
 */
public class FileStatusCode {

  private FileStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Confirmé.
   */
  public static final String CONFIRMED = "CONFIRME";
}
