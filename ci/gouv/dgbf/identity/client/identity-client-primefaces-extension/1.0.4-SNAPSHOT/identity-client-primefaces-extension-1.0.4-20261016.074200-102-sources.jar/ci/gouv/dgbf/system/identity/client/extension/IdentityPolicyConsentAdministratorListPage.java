package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la liste de tous les consentements (menu Politiques), distincte de
 * « Mes consentements » ({@link IdentityPolicyConsentListPage}) par son étendue, non par un rôle
 * (TCH_IDT_763).
 *
 * @author Christian Yao Komenan
 *
 */
@Named
@ViewScoped
public class IdentityPolicyConsentAdministratorListPage extends AbstractPage {

  @Inject
  @Getter
  IdentityPolicyConsentController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    controller.initialize();
    contentTitle = controller.getName();
  }

  public static final String OUTCOME = "identityPolicyConsentAdministratorListPage";
}
