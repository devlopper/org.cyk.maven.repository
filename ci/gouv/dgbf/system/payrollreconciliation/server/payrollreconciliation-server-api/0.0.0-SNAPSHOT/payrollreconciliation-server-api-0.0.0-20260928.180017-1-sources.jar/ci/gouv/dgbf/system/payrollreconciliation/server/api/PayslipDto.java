package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un bulletin de paie (rapprochement Solde AN 2000 ↔ CALO, écran
 * « Contrôle global »).
 *
 * @author desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipDto extends AbstractIdentifiableDto {

  /**
   * Exercice fiscal.
   */
  @JsonbProperty(JSON_FISCAL_YEAR)
  private String fiscalYear;

  /**
   * Période (mois).
   */
  @JsonbProperty(JSON_PERIOD)
  private Integer period;

  /**
   * Code service.
   */
  @JsonbProperty(JSON_SERVICE_CODE)
  private String serviceCode;

  /**
   * Libellé service.
   */
  @JsonbProperty(JSON_SERVICE_LABEL)
  private String serviceLabel;

  /**
   * Référence externe à un Rémunérable (matricule).
   */
  @JsonbProperty(JSON_REMUNERABLE)
  private String remunerable;

  /**
   * Indicateur Fonctionnaire/Agent non-fonctionnaire.
   */
  @JsonbProperty(JSON_CIVIL_SERVANT)
  private Boolean civilServant;

  /**
   * Corps.
   */
  @JsonbProperty(JSON_CORPS)
  private String corps;

  /**
   * Emploi.
   */
  @JsonbProperty(JSON_JOB)
  private String job;

  /**
   * Type de montant (MONTANT_BRUT / MONTANT_NET / MONTANT_RETENUES).
   */
  @JsonbProperty(JSON_AMOUNT_TYPE)
  private String amountType;

  /**
   * Montant Solde AN 2000.
   */
  @JsonbProperty(JSON_LEGACY_AMOUNT)
  private Long legacyAmount;

  /**
   * Montant CALO.
   */
  @JsonbProperty(JSON_CALO_AMOUNT)
  private Long caloAmount;

  /**
   * Écart (caloAmount - legacyAmount).
   */
  @JsonbProperty(JSON_VARIANCE)
  private Long variance;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBulletinPaie";

  /**
   * Identifiant json de la représentation en chaîne de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "bulletinPaieChaine";

  /**
   * Identifiant champ json {@link #fiscalYear}.
   */
  public static final String JSON_FISCAL_YEAR = "exercice";

  /**
   * Identifiant champ json {@link #period}.
   */
  public static final String JSON_PERIOD = "periode";

  /**
   * Identifiant champ json {@link #serviceCode}.
   */
  public static final String JSON_SERVICE_CODE = "codeService";

  /**
   * Identifiant champ json {@link #serviceLabel}.
   */
  public static final String JSON_SERVICE_LABEL = "service";

  /**
   * Identifiant champ json {@link #remunerable}.
   */
  public static final String JSON_REMUNERABLE = "remunerable";

  /**
   * Identifiant champ json {@link #civilServant}.
   */
  public static final String JSON_CIVIL_SERVANT = "estFonctionnaire";

  /**
   * Identifiant champ json {@link #corps}.
   */
  public static final String JSON_CORPS = "corps";

  /**
   * Identifiant champ json {@link #job}.
   */
  public static final String JSON_JOB = "emploi";

  /**
   * Identifiant champ json {@link #amountType}.
   */
  public static final String JSON_AMOUNT_TYPE = "typeMontant";

  /**
   * Identifiant champ json {@link #legacyAmount}.
   */
  public static final String JSON_LEGACY_AMOUNT = "montantSoldeAn2000";

  /**
   * Identifiant champ json {@link #caloAmount}.
   */
  public static final String JSON_CALO_AMOUNT = "montantCalo";

  /**
   * Identifiant champ json {@link #variance}.
   */
  public static final String JSON_VARIANCE = "ecart";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "bulletins de paie";

}
