package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant validé à l'horizon N.
 *
 * @author Christian
 */
public interface HasValidatedAmountN extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant validé à l'horizon N.
   *
   * @return le montant validé à l'horizon N
   */
  Long getValidatedAmountN();

  /**
   * Cette méthode permet d'assigner le montant validé à l'horizon N.
   *
   * @param amount le montant validé à l'horizon N
   */
  void setValidatedAmountN(Long amount);

  /**
   * Identifiant java du montant validé à l'horizon N.
   */
  String FIELD_VALIDATED_AMOUNT_N = "validatedAmountN";
}
