package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie dépense.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpenditureCategoryDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json de identifiant de {@link ExpenditureCategoryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idCategorieDepense";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExpenditureCategoryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "categorieDepenseChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie depense";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories dépense";
}
