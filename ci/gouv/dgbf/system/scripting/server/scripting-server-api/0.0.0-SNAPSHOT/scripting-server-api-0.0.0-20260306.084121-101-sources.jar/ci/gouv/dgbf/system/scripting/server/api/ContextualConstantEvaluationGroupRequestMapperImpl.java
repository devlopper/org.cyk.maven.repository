package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et.
* {@link ContextualConstantEvaluationGroupDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ContextualConstantEvaluationGroupRequestMapperImpl implements ContextualConstantEvaluationGroupRequestMapper {

    @Override
    public ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupCreateRequestDto mapCreate(ContextualConstantEvaluationGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupCreateRequestDto contextualConstantEvaluationGroupCreateRequestDto = new ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupCreateRequestDto();

        contextualConstantEvaluationGroupCreateRequestDto.setName( arg0.getName() );

        return contextualConstantEvaluationGroupCreateRequestDto;
    }

    @Override
    public ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupUpdateRequestDto mapUpdate(ContextualConstantEvaluationGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupUpdateRequestDto contextualConstantEvaluationGroupUpdateRequestDto = new ContextualConstantEvaluationGroupService.ContextualConstantEvaluationGroupUpdateRequestDto();

        contextualConstantEvaluationGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        contextualConstantEvaluationGroupUpdateRequestDto.setName( arg0.getName() );

        return contextualConstantEvaluationGroupUpdateRequestDto;
    }
}
