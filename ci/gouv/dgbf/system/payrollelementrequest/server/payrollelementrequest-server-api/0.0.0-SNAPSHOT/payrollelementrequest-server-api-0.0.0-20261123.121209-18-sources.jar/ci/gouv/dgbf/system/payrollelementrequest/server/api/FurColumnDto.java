package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la configuration de résolution d'un Réclamable à partir du FUR : le
 * Réclamable qu'elle alimente, le résolveur à utiliser pour lire sa valeur de paie (CALO) et la
 * colonne du fichier qui porte sa date d'effet. Une colonne qui alimente le Réclamable d'une Cible
 * obligatoire d'un Type de Réclamation est obligatoire dans les lignes de ce Type. Un Réclamable
 * n'est alimenté que par une seule configuration.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurColumnDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant du Réclamable alimenté par la colonne.
   */
  @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
  private String claimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimableIdentifier}.
   */
  @JsonbProperty(JSON_CLAIMABLE_AS_STRING)
  private String claimableAsString;

  /**
   * Résolveur de la valeur de paie : {@link #RESOLVER_FILE}, {@link #RESOLVER_GRADE},
   * {@link #RESOLVER_LOCALITY} ou {@link #RESOLVER_ORGANISM}.
   */
  @JsonbProperty(JSON_RESOLVER_KIND)
  private String resolverKind;

  /**
   * Champ de sortie du résolveur.
   */
  @JsonbProperty(JSON_OUTPUT_FIELD)
  private String outputField;

  /**
   * Colonne du fichier portant la date d'effet.
   */
  @JsonbProperty(JSON_DATE_COLUMN)
  private String dateColumn;

  /**
   * Identifiant json {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json {@link #claimableAsString}.
   */
  public static final String JSON_CLAIMABLE_AS_STRING = "reclamableChaine";

  /**
   * Identifiant json {@link #resolverKind}.
   */
  public static final String JSON_RESOLVER_KIND = "resolveur";

  /**
   * Identifiant json {@link #outputField}.
   */
  public static final String JSON_OUTPUT_FIELD = "champSortie";

  /**
   * Identifiant json {@link #dateColumn}.
   */
  public static final String JSON_DATE_COLUMN = "colonneDate";

  /**
   * Résolveur qui lit directement une colonne du fichier.
   */
  public static final String RESOLVER_FILE = "FICHIER";

  /**
   * Résolveur qui lit le référentiel Grade → catégorie.
   */
  public static final String RESOLVER_GRADE = "GRADE";

  /**
   * Résolveur qui lit le référentiel Localité → mode de règlement.
   */
  public static final String RESOLVER_LOCALITY = "LOCALITE";

  /**
   * Résolveur qui lit le référentiel Organisme → section/service.
   */
  public static final String RESOLVER_ORGANISM = "ORGANISME";

  /**
   * Identifiant json de identifiant de {@link FurColumnDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idColonneFur";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link FurColumnDto}.
   */
  public static final String JSON_THIS_AS_STRING = "colonneFurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "colonne du FUR";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "colonnes du FUR";
}
