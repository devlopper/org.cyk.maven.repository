package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasRevokableDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.token.server.api.shared.HasConsumableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.OffsetDateTime;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TokenDto}.
 *
 * @author Christian
 *
 */
@Path(value = TokenService.PATH)
@Tag(name = "Gestion des jetons")
public interface TokenService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "jetons";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_JETON";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = TokenCreateResponseDto.class))})
  Response create(TokenCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenCreateRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant json de la durée de validité en secondes.
     */
    static final String JSON_VALIDITY_DURATION_IN_SECONDS = "dureeValiditeEnSecondes";

    @JsonbProperty(TokenDto.JSON_MODULE_IDENTIFIER)
    private String moduleIdentifier;

    @JsonbProperty(TokenDto.JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(TokenDto.JSON_OPERATION_IDENTIFIER)
    private String operationIdentifier;

    @JsonbProperty(TokenDto.JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(TokenDto.JSON_RECORD_IDENTIFIER)
    private String recordIdentifier;

    @JsonbProperty(JSON_VALIDITY_DURATION_IN_SECONDS)
    private Long validityDurationInSeconds;
  }

  /**
   * Cette classe représente la réponse de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenCreateResponseDto extends CreateResponseDto {

    /**
     * Identifiant json de la valeur.
     */
    static final String JSON_VALUE = "valeur";

    @JsonbProperty(JSON_VALUE)
    private String value;

    @JsonbProperty(TokenDto.JSON_EXPIRATION_DATE)
    private OffsetDateTime expirationDate;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_JETON";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir des jetons")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de
   * plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenGetManyResponseDto extends AbstractGetByPageResponseDto<TokenDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TokenDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_JETON";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir un.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER, description = "Ce service permet d'obtenir un jeton")
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_JETON";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link TokenDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un jeton")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TokenDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_JETON";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir le compte de {@link TokenDto} — utilisé par les
   * compteurs des onglets de l'Écran de Révocation (CU_TOK_004, RG_TOK_JET_12).
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.TEXT_PLAIN)
  @Operation(operationId = GET_COUNT_IDENTIFIER,
      description = "Ce service permet d'obtenir le compte de jetons")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de vérification.
   */
  String VERIFY_IDENTIFIER = "VERIFICATION_JETON";

  /**
   * Chemin du service de vérification.
   */
  String VERIFY_PATH = "verification";

  /**
   * Cette méthode permet de vérifier.
   *
   * @param request requête
   * @return réponse
   */
  @Path(VERIFY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = VERIFY_IDENTIFIER,
      description = "Ce service permet de vérifier un jeton")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TokenVerifyResponseDto.class))})
  Response verify(TokenVerifyRequestDto request);

  /**
   * Cette classe représente la requête de vérification.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenVerifyRequestDto extends AbstractAuditedRequestJsonDto {

    /**
     * Identifiant json de la valeur.
     */
    static final String JSON_VALUE = "valeur";

    @JsonbProperty(JSON_VALUE)
    private String value;
  }

  /**
   * Cette classe représente la réponse de vérification.
   *
   * <p>Étend {@link IdentifiableResponseDto} pour des raisons d'implémentation
   * (`AbstractIdentifiableUpdateBusiness`, comme `revoke`), mais l'identifiant hérité est
   * systématiquement forcé à {@code null} : aucune fuite du contexte du jeton au-delà de
   * valide/motif (RG_TOK_JET_11).
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenVerifyResponseDto extends IdentifiableResponseDto {

    /**
     * Identifiant json de la validité.
     */
    static final String JSON_VALID = "valide";

    /**
     * Identifiant json du motif.
     */
    static final String JSON_REASON = "motif";

    @JsonbProperty(JSON_VALID)
    private Boolean valid;

    @JsonbProperty(JSON_REASON)
    private String reason;
  }

  /**
   * Cette classe représente la base des réponses de traitement.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class ProcessResponseDto extends IdentifiableResponseDto
      implements HasStatusDto<TokenStatus>, HasConsumableDto, HasRevokableDto {

    @JsonbProperty(JSON_STATUS)
    private TokenStatus status;

    @JsonbProperty(JSON_CONSUMABLE)
    private Boolean consumable;

    @JsonbProperty(JSON_REVOKABLE)
    private Boolean revokable;

    /**
     * Cette méthode permet d'initialiser la réponse à partir de {@link TokenStatus}.
     *
     * @param status {@link TokenStatus}
     */
    public void initialize(TokenStatus status) {
      this.status = status;
    }
  }

  /**
   * Identifiant du service de consommation.
   */
  String CONSUME_IDENTIFIER = "CONSOMMATION_JETON";

  /**
   * Chemin du service de consommation.
   */
  String CONSUME_PATH = "consommation";

  /**
   * Cette méthode permet de consommer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CONSUME_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CONSUME_IDENTIFIER,
      description = "Ce service permet de consommer un jeton")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TokenConsumeResponseDto.class))})
  Response consume(TokenConsumeRequestDto request);

  /**
   * Cette classe représente la requête de consommation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenConsumeRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de consommation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenConsumeResponseDto extends ProcessResponseDto {

  }

  /**
   * Identifiant du service de révocation.
   */
  String REVOKE_IDENTIFIER = "REVOCATION_JETON";

  /**
   * Chemin du service de révocation.
   */
  String REVOKE_PATH = "revocation";

  /**
   * Cette méthode permet de révoquer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(REVOKE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = REVOKE_IDENTIFIER,
      description = "Ce service permet de révoquer un jeton")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TokenRevokeResponseDto.class))})
  Response revoke(TokenRevokeRequestDto request);

  /**
   * Cette classe représente la requête de révocation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenRevokeRequestDto extends ByIdentifierRequestDto {

  }

  /**
   * Cette classe représente la réponse de révocation.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  class TokenRevokeResponseDto extends ProcessResponseDto {

  }
}
