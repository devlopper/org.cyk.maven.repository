package ci.gouv.dgbf.system.employee.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.employee.server.api.EmployeeClient;
import ci.gouv.dgbf.system.employee.server.api.EmployeeDto;
import ci.gouv.dgbf.system.employee.server.api.EmployeeService.EmployeeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link EmployeeDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class EmployeeSelectOneController extends AbstractSelectOneIdentifiableController<
    EmployeeDto, EmployeeGetManyResponseDto, EmployeeClient> {

  @Inject
  @Getter
  EmployeeClient client;

  /**
   * Cette methode permet de construire.
   */
  protected EmployeeSelectOneController() {
    super(EmployeeDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
