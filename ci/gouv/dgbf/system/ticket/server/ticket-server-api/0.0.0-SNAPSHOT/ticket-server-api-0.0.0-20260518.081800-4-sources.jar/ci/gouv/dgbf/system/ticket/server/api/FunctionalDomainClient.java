package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.FunctionalDomainService.FunctionalDomainCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.FunctionalDomainService.FunctionalDomainGetManyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.FunctionalDomainService.FunctionalDomainUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FunctionalDomainService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FunctionalDomainClient extends AbstractClient<FunctionalDomainService>
    implements GetByIdentifier<FunctionalDomainDto>,
               GetMany<FunctionalDomainGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FunctionalDomainClient service(FunctionalDomainService service) {
    return (FunctionalDomainClient) super.service(service);
  }

  /**
   * {@link FunctionalDomainService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FunctionalDomainCreateRequestDto request) {
    return new CreateExecutor(FunctionalDomainService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FunctionalDomainService#create}.
   *
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    FunctionalDomainCreateRequestDto request = new FunctionalDomainCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link FunctionalDomainService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionalDomainGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FunctionalDomainGetManyResponseDto>(
      FunctionalDomainGetManyResponseDto.class,
        FunctionalDomainService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FunctionalDomainService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionalDomainGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FunctionalDomainService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FunctionalDomainDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FunctionalDomainDto>(FunctionalDomainDto.class,
        FunctionalDomainService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link FunctionalDomainService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FunctionalDomainDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FunctionalDomainService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FunctionalDomainDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FunctionalDomainDto>(FunctionalDomainDto.class,
        FunctionalDomainService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FunctionalDomainService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FunctionalDomainDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FunctionalDomainService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FunctionalDomainUpdateRequestDto request) {
    return new IdentifiableExecutor(FunctionalDomainService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FunctionalDomainService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    FunctionalDomainUpdateRequestDto request = new FunctionalDomainUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link FunctionalDomainService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FunctionalDomainService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FunctionalDomainService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
