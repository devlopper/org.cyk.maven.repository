package ci.gouv.dgbf.extension.primefaces.component.input;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link ValueType}.
 *
 * @author Christian
 *
 */
@Dependent
public class ValueTypeSelectOneController
    extends AbstractSelectOneEnumerationController<ValueType> {

  protected ValueTypeSelectOneController() {
    super(ValueType.values());
    outputLableValue = "Type de valeur";
  }

  @Override
  protected String computeSelectItemLabel(ValueType type) {
    return type.getName();
  }
}
