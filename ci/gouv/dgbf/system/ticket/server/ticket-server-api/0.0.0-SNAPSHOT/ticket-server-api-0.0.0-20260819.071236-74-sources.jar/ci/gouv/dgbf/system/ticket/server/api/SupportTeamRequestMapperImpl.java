package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SupportTeamDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-19T07:12:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SupportTeamRequestMapperImpl implements SupportTeamRequestMapper {

    @Override
    public SupportTeamService.SupportTeamCreateRequestDto mapCreate(SupportTeamDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamService.SupportTeamCreateRequestDto supportTeamCreateRequestDto = new SupportTeamService.SupportTeamCreateRequestDto();

        supportTeamCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        supportTeamCreateRequestDto.setUsersGroupIdentifier( arg0.getUsersGroupIdentifier() );
        supportTeamCreateRequestDto.setMaxClaimsPerSupport( arg0.getMaxClaimsPerSupport() );

        return supportTeamCreateRequestDto;
    }

    @Override
    public SupportTeamService.SupportTeamUpdateRequestDto mapUpdate(SupportTeamDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SupportTeamService.SupportTeamUpdateRequestDto supportTeamUpdateRequestDto = new SupportTeamService.SupportTeamUpdateRequestDto();

        supportTeamUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        supportTeamUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        supportTeamUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        supportTeamUpdateRequestDto.setUsersGroupIdentifier( arg0.getUsersGroupIdentifier() );
        supportTeamUpdateRequestDto.setMaxClaimsPerSupport( arg0.getMaxClaimsPerSupport() );

        return supportTeamUpdateRequestDto;
    }
}
