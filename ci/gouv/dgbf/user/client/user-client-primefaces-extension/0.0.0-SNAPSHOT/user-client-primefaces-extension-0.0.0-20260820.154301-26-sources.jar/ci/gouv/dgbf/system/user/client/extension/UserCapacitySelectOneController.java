package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.user.server.api.UserCapacityClient;
import ci.gouv.dgbf.system.user.server.api.UserCapacityDto;
import ci.gouv.dgbf.system.user.server.api.UserCapacityService.UserCapacityGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link UserCapacityDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class UserCapacitySelectOneController extends AbstractSelectOneIdentifiableController<
    UserCapacityDto, UserCapacityGetManyResponseDto, UserCapacityClient> {

  @Inject
  @Getter
  UserCapacityClient client;

  /**
   * Cette methode permet de construire.
   */
  protected UserCapacitySelectOneController() {
    super(UserCapacityDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
