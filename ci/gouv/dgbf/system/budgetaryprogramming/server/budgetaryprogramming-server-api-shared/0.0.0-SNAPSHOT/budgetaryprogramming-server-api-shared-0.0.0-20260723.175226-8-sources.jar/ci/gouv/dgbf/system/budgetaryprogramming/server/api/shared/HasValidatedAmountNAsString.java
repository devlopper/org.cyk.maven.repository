package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant validé à l'horizon N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasValidatedAmountNAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant validé à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @return le montant validé à l'horizon N, sous forme de chaîne de caractères
   */
  String getValidatedAmountNAsString();

  /**
   * Cette méthode permet d'assigner le montant validé à l'horizon N, sous forme de chaîne de
   * caractères.
   *
   * @param amount le montant validé à l'horizon N, sous forme de chaîne de caractères
   */
  void setValidatedAmountNAsString(String amount);

  /**
   * Identifiant java du montant validé à l'horizon N, sous forme de chaîne de caractères.
   */
  String FIELD_VALIDATED_AMOUNT_N_AS_STRING = "validatedAmountNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
