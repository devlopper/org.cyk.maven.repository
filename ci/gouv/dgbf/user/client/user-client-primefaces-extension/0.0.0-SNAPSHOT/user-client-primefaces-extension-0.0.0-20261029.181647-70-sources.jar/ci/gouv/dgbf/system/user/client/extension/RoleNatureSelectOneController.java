package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.user.server.api.RoleNature;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link RoleNature}.
 *
 * @author Christian
 */
@Dependent
public class RoleNatureSelectOneController
    extends AbstractSelectOneEnumerationController<RoleNature> {

  /**
   * Cette méthode permet de construire.
   */
  public RoleNatureSelectOneController() {
    super(RoleNature.values());
    outputLableValue = "Nature";
  }

  @Override
  protected String computeSelectItemLabel(RoleNature nature) {
    return nature.getName();
  }
}
