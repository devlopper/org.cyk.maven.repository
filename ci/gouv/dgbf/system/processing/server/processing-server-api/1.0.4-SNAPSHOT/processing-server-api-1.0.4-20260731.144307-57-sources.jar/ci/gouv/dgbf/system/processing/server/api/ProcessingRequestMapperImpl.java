package ci.gouv.dgbf.system.processing.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcessingDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-31T14:43:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcessingRequestMapperImpl implements ProcessingRequestMapper {

    @Override
    public ProcessingService.ProcessingCreateRequestDto mapCreate(ProcessingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessingService.ProcessingCreateRequestDto processingCreateRequestDto = new ProcessingService.ProcessingCreateRequestDto();

        processingCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        processingCreateRequestDto.setDescriptive( arg0.getDescriptive() );
        processingCreateRequestDto.setFromDate( arg0.getFromDate() );
        processingCreateRequestDto.setToDate( arg0.getToDate() );
        processingCreateRequestDto.setReason( arg0.getReason() );
        processingCreateRequestDto.setDate( arg0.getDate() );
        processingCreateRequestDto.setTotalWorkVolume( arg0.getTotalWorkVolume() );
        processingCreateRequestDto.setCompletedWorkVolume( arg0.getCompletedWorkVolume() );
        processingCreateRequestDto.setBatchSize( arg0.getBatchSize() );
        processingCreateRequestDto.setThreadCount( arg0.getThreadCount() );
        processingCreateRequestDto.setPreviousIdentifier( arg0.getPreviousIdentifier() );

        return processingCreateRequestDto;
    }

    @Override
    public ProcessingService.ProcessingUpdateRequestDto mapUpdate(ProcessingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcessingService.ProcessingUpdateRequestDto processingUpdateRequestDto = new ProcessingService.ProcessingUpdateRequestDto();

        processingUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        processingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        processingUpdateRequestDto.setDescriptive( arg0.getDescriptive() );
        processingUpdateRequestDto.setFromDate( arg0.getFromDate() );
        processingUpdateRequestDto.setToDate( arg0.getToDate() );
        processingUpdateRequestDto.setReason( arg0.getReason() );
        processingUpdateRequestDto.setDate( arg0.getDate() );
        processingUpdateRequestDto.setTotalWorkVolume( arg0.getTotalWorkVolume() );
        processingUpdateRequestDto.setCompletedWorkVolume( arg0.getCompletedWorkVolume() );
        processingUpdateRequestDto.setBatchSize( arg0.getBatchSize() );
        processingUpdateRequestDto.setThreadCount( arg0.getThreadCount() );
        processingUpdateRequestDto.setPreviousIdentifier( arg0.getPreviousIdentifier() );

        return processingUpdateRequestDto;
    }

    @Override
    public ProcessingService.ProcessingProcessRequestDto mapProcess(ProcessingDto processing) {
        if ( processing == null ) {
            return null;
        }

        ProcessingService.ProcessingProcessRequestDto processingProcessRequestDto = new ProcessingService.ProcessingProcessRequestDto();

        processingProcessRequestDto.setAuditWho( processing.getAuditWho() );
        processingProcessRequestDto.setIdentifier( processing.getIdentifier() );
        processingProcessRequestDto.setReason( processing.getReason() );
        processingProcessRequestDto.setDate( processing.getDate() );

        return processingProcessRequestDto;
    }

    @Override
    public ProcessingService.ProcessingUpdateCompletedWorkVolumeRequestDto mapUpdateCompletedWorkVolume(ProcessingDto processing) {
        if ( processing == null ) {
            return null;
        }

        ProcessingService.ProcessingUpdateCompletedWorkVolumeRequestDto processingUpdateCompletedWorkVolumeRequestDto = new ProcessingService.ProcessingUpdateCompletedWorkVolumeRequestDto();

        processingUpdateCompletedWorkVolumeRequestDto.setAuditWho( processing.getAuditWho() );
        processingUpdateCompletedWorkVolumeRequestDto.setIdentifier( processing.getIdentifier() );

        return processingUpdateCompletedWorkVolumeRequestDto;
    }
}
