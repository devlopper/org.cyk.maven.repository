package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.YearFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExerciseDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ExerciseFilter extends AbstractIdentifiableFilter {

  /**
   * {@link ExerciseDto#year}.
   */
  Integer year;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public ExerciseFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public ExerciseFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    year = YearFilter.get(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    YearFilter.set(filter, year);
  }

  
}

