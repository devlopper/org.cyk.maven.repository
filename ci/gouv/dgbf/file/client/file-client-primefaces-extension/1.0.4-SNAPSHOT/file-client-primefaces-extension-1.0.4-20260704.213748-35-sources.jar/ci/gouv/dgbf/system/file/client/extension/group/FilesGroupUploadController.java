package ci.gouv.dgbf.system.file.client.extension.group;

import ci.gouv.dgbf.extension.core.ByteCore;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileGroupClient;
import ci.gouv.dgbf.system.file.server.api.FileGroupService.FileGroupCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupClient;
import ci.gouv.dgbf.system.file.server.api.FilesGroupDto;
import ci.gouv.dgbf.system.file.server.api.FilesGroupService.FilesGroupCreateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import lombok.Getter;
import org.primefaces.event.FileUploadEvent;

/**
 * Cette classe représente le contrôleur de téléchargement de {@link FilesGroupDto}.
 *
 * @author Christian
 */
@Dependent
public class FilesGroupUploadController extends AbstractController {

  @Inject
  FilesGroupClient client;

  @Inject
  FileGroupClient fileGroupClient;

  @Inject
  FileClient fileClient;

  @Getter
  Map<String, FileDto> files;

  /**
   * Cette méthode permet de constuire.
   */
  public FilesGroupUploadController() {
    files = new LinkedHashMap<>();
  }

  /**
   * Cette méthode permet d'ajouter un fichier.
   *
   * @param event {@link FileUploadEvent}
   */
  public void add(FileUploadEvent event) {
    FileDto file = new FileDto();
    file.setName(event.getFile().getFileName());
    file.setBytes(event.getFile().getContent());
    file.setHash(ByteCore.digestToString(file.getBytes(), "SHA-256"));
    files.put(file.getHash(), file);
  }

  /**
   * Cette méthode permet de supprimer un fichier.
   *
   * @param key clé
   */
  public void remove(String key) {
    files.remove(key);
  }

  /**
   * Cette méthode permet de créer {@link FilesGroupDto}.
   */
  public String createTemporary() {
    FilesGroupCreateRequestDto request = new FilesGroupCreateRequestDto();
    request.setIsConfirmed(false);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(UUID.randomUUID().toString());
    CreateResponseDto response = client.create(request);
    String identifier = response.getIdentifier();
    files.values().forEach(file -> createFileGroup(file, identifier, request.getAuditSession()));
    files.clear();
    return identifier;
  }

  void createFileGroup(FileDto file, String groupIdentifier, String auditSession) {
    FileGroupCreateRequestDto request = new FileGroupCreateRequestDto();
    request.setGroupIdentifier(groupIdentifier);
    String fileIdentifier = createFileOrGetIdentifier(file, auditSession);
    request.setFileIdentifier(fileIdentifier);
    request.setAuditWho(userIdentifier);
    request.setAuditSession(auditSession);
    fileGroupClient.create(request);
  }

  String createFileOrGetIdentifier(FileDto file, String auditSession) {
    return fileClient.getIdentifierByBytesOrByCreate(file.getName(), file.getBytes(),
        userIdentifier, auditSession);
  }
}
