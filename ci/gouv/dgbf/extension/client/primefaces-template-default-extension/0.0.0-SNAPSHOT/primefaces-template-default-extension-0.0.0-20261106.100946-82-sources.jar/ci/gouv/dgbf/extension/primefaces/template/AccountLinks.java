package ci.gouv.dgbf.extension.primefaces.template;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Cette classe calcule les liens vers les écrans « de compte » hébergés par un autre module
 * (constitution-client-quarkus-primefaces.md §5.5) : Mon profil (module user) et Mon activité
 * (module logging).
 *
 * <p>Les applications d'un environnement sont servies par un même hôte, sous des contextes
 * différents (https://hôte/utilisateur, https://hôte/logging). Le lien se déduit donc de l'adresse
 * de la requête en cours, sans variable d'environnement : il vaut dans chaque environnement. Une
 * adresse configurée l'emporte (poste de développement, où chaque application a son port).
 *
 * @author Christian
 */
public final class AccountLinks {
  private static final int HTTP_PORT = 80;
  private static final int HTTPS_PORT = 443;

  private AccountLinks() {}

  /**
   * Cette méthode donne le lien vers une page d'un autre module.
   *
   * @param configured adresse configurée, ou null / vide pour la déduire
   * @param scheme protocole de la requête (http, https)
   * @param serverName nom d'hôte de la requête
   * @param port port de la requête
   * @param currentContextPath contexte de l'application courante (vide si elle est à la racine)
   * @param targetContextPath contexte de l'application qui héberge la page
   * @param targetPath chemin de la page dans l'application qui l'héberge (commence par « / »)
   * @return le lien ; relatif à l'hôte si l'application courante est l'hébergeur, absolu sinon
   */
  public static String resolve(String configured, String scheme, String serverName, int port,
      String currentContextPath, String targetContextPath, String targetPath) {
    if (configured != null && !configured.isBlank()) {
      return configured.strip();
    }
    String current = currentContextPath == null ? "" : currentContextPath;
    if (current.equals(targetContextPath)) {
      return current + targetPath;
    }
    return origin(scheme, serverName, port) + targetContextPath + targetPath;
  }

  /**
   * Construit un lien vers un hébergeur en transportant l'application d'origine.
   * L'hébergeur doit valider cette adresse contre sa liste blanche avant de l'afficher.
   */
  public static String resolveWithReturn(String configured, String scheme, String serverName,
      int port, String currentContextPath, String targetContextPath, String targetPath) {
    String link = resolve(configured, scheme, serverName, port, currentContextPath,
        targetContextPath, targetPath);
    String current = currentContextPath == null ? "" : currentContextPath;
    if (current.equals(targetContextPath)) {
      return link;
    }
    String returnUrl = origin(scheme, serverName, port) + current;
    return link + (link.contains("?") ? '&' : '?') + "return="
        + URLEncoder.encode(returnUrl, StandardCharsets.UTF_8);
  }

  static String origin(String scheme, String serverName, int port) {
    boolean defaultPort = port <= 0 || ("http".equalsIgnoreCase(scheme) && port == HTTP_PORT)
        || ("https".equalsIgnoreCase(scheme) && port == HTTPS_PORT);
    return scheme + "://" + serverName + (defaultPort ? "" : ":" + port);
  }
}
