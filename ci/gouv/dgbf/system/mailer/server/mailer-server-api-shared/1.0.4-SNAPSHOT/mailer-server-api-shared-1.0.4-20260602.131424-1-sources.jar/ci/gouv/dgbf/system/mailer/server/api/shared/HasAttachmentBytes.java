package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un tableau d'octets de pièce jointe.
 *
 * @author Christian
 */
public interface HasAttachmentBytes extends HasField {

  /**
   * Cette méthode permet d'obtenir le tableau d'octets de la pièce jointe.
   *
   * @return le tableau d'octets de la pièce jointe
   */
  byte[] getAttachmentBytes();

  /**
   * Cette méthode permet d'assigner le tableau d'octets de la pièce jointe.
   *
   * @param attachmentBytes le tableau d'octets de la pièce jointe
   */
  void setAttachmentBytes(byte[] attachmentBytes);

  /**
   * Identifiant java du tableau d'octets de la pièce jointe.
   */
  String FIELD_ATTACHMENT_BYTES = "attachmentBytes";
}
