package ci.gouv.dgbf.system.logging.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RecordOperationDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-11T14:44:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RecordOperationRequestMapperImpl implements RecordOperationRequestMapper {

    @Override
    public RecordOperationService.RecordOperationCreateRequestDto mapCreate(RecordOperationDto dto) {
        if ( dto == null ) {
            return null;
        }

        RecordOperationService.RecordOperationCreateRequestDto recordOperationCreateRequestDto = new RecordOperationService.RecordOperationCreateRequestDto();

        recordOperationCreateRequestDto.setAuditWho( dto.getAuditWho() );
        recordOperationCreateRequestDto.setAuditSession( dto.getAuditSession() );
        recordOperationCreateRequestDto.setProcessIdentifier( dto.getProcessIdentifier() );
        recordOperationCreateRequestDto.setSourceIdentifier( dto.getSourceIdentifier() );
        recordOperationCreateRequestDto.setOperationIdentifier( dto.getOperationIdentifier() );
        recordOperationCreateRequestDto.setRecordIdentifier( dto.getRecordIdentifier() );
        recordOperationCreateRequestDto.setArguments( dto.getArguments() );
        recordOperationCreateRequestDto.setArgumentsFormat( dto.getArgumentsFormat() );
        recordOperationCreateRequestDto.setResult( dto.getResult() );
        recordOperationCreateRequestDto.setResultFormat( dto.getResultFormat() );
        recordOperationCreateRequestDto.setMessage( dto.getMessage() );
        recordOperationCreateRequestDto.setAuditFunctionality( dto.getAuditFunctionality() );

        return recordOperationCreateRequestDto;
    }
}
