package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.AdministrativeUnitBudgetExecutionService.AdministrativeUnitBudgetExecutionGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link AdministrativeUnitBudgetExecutionService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class AdministrativeUnitBudgetExecutionClient
    extends AbstractClient<AdministrativeUnitBudgetExecutionService>
    implements GetByIdentifier<AdministrativeUnitBudgetExecutionDto>,
    GetMany<AdministrativeUnitBudgetExecutionGetManyResponseDto> {

  @Override
  public AdministrativeUnitBudgetExecutionClient service(
      AdministrativeUnitBudgetExecutionService service) {
    return (AdministrativeUnitBudgetExecutionClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitBudgetExecutionGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitBudgetExecutionGetManyResponseDto>(
        AdministrativeUnitBudgetExecutionGetManyResponseDto.class,
        AdministrativeUnitBudgetExecutionService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitBudgetExecutionGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitBudgetExecutionDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitBudgetExecutionDto>(
        AdministrativeUnitBudgetExecutionDto.class,
        AdministrativeUnitBudgetExecutionService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitBudgetExecutionDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AdministrativeUnitBudgetExecutionDto getByIdentifier(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitBudgetExecutionDto>(
        AdministrativeUnitBudgetExecutionDto.class,
        AdministrativeUnitBudgetExecutionService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AdministrativeUnitBudgetExecutionService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AdministrativeUnitBudgetExecutionDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
