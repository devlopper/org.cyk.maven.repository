package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une priorité dossier.
 *
 * @author Dahoud
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FolderPriorityDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /** Nom pour lecture humaine de la classe. */
  public static final String NAME = "priorité de dossier";

  /** Nom au pluriel pour lecture humaine de la classe. */
  public static final String PLURAL_NAME = "priorités de dossier";
}
