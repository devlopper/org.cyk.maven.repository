package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette interface représente une classe avec une notion de nombre d'opérations.
 *
 * @author Christian
 */
public interface HasOperationCountDto extends HasOperationCount {

  /**
   * Identifiant json du nombre d'opérations.
   */
  String JSON_OPERATION_COUNT = "nombreOperations";
}
