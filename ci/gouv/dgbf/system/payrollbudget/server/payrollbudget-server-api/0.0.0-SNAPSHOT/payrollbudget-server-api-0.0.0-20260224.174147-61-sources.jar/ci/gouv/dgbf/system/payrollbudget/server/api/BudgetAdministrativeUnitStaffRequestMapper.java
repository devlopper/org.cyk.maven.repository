package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.BudgetAdministrativeUnitStaffService.BudgetAdministrativeUnitStaffUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link BudgetAdministrativeUnitStaffDto}.
 *
 * @author parfait
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link BudgetAdministrativeUnitStaffDto}.

    @author parfait
               """)
public interface BudgetAdministrativeUnitStaffRequestMapper
    extends RequestMapper<BudgetAdministrativeUnitStaffDto, 
        BudgetAdministrativeUnitStaffCreateRequestDto,
        BudgetAdministrativeUnitStaffUpdateRequestDto> {

}
