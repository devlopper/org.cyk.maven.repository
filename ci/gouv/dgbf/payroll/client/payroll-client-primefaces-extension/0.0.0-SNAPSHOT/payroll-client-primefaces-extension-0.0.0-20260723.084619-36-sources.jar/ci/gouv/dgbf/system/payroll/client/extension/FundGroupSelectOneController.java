package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupClient;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupService.FundGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FundGroupDto}.
 *
 * @author akm
 *
 */
@Dependent
public class FundGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    FundGroupDto, FundGroupGetManyResponseDto, FundGroupClient> {

  @Getter
  @Inject
  FundGroupClient client;

  protected FundGroupSelectOneController() {
    super(FundGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
