package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'identité de bénéficiaire.
 *
 * @author Christian
 */
public interface HasBeneficiaryIdentityIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité du bénéficiaire.
   *
   * @return l'identifiant de l'identité du bénéficiaire
   */
  String getBeneficiaryIdentityIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité du bénéficiaire.
   *
   * @param beneficiaryIdentityIdentifier l'identifiant de l'identité du bénéficiaire
   */
  void setBeneficiaryIdentityIdentifier(String beneficiaryIdentityIdentifier);

  /**
   * Identifiant java de l'identifiant de l'identité du bénéficiaire.
   */
  String FIELD_BENEFICIARY_IDENTITY_IDENTIFIER = "beneficiaryIdentityIdentifier";
}
