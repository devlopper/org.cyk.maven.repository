package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.NavigationManager;
import ci.gouv.dgbf.extension.primefaces.ScriptManager;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasAdministrativeUnitIdentifierDto;
import ci.gouv.dgbf.system.sharing.server.api.AbstractResourceOrReceiverDto;
import ci.gouv.dgbf.system.sharing.server.api.Location;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceFilter;
import ci.gouv.dgbf.system.sharing.server.api.ResourceService.ResourceGetManyResponseDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceType;
import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import jakarta.servlet.http.HttpSession;
import java.util.Optional;
import java.util.function.Consumer;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de session.
 *
 * @author Christian
 *
 */
@SessionScoped
@Named
public class SharingSessionController extends AbstractController {

  @Inject
  HttpSession session;

  @Inject
  NavigationManager navigationManager;

  @Inject
  ResourceClient resourceClient;

  SharingSessionDataDto data;

  @Inject
  @Getter
  ResourceSelectOneController exerciseResourceSelectOneController;

  @Inject
  @Getter
  ResourceSelectOneController administrativeUnitResourceSelectOneController;

  @Inject
  ScriptManager scriptManager;

  /**
   * Cette méthode permet de construire.
   */
  public SharingSessionController() {
    data = new SharingSessionDataDto();
    ResourceFilter resourceFilter = new ResourceFilter();
    resourceFilter.setLocation(Location.BUDGETARY_CLASSIFICATION);
    resourceFilter.setType(ResourceType.ADMINISTRATIVE_UNIT);

  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    initializeExerciseResourceSelectOneController();
    initializeAdministrativeUnitResourceSelectOneController();
  }

  void initializeExerciseResourceSelectOneController() {
    exerciseResourceSelectOneController.getAutoComplete().getOutputLabel().setValue("Exercice");
    ResourceFilter filter = instantiateExerciseResourceSelectOneControllerFilter();
    exerciseResourceSelectOneController.useFilter(filter);
    exerciseResourceSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> data.setExerciseIdentifier(identifier));
    Core.acceptConsumer(EXERCISE_RESOURCE_SELECT_ONE_CONTROLLER_CONSUMER,
        exerciseResourceSelectOneController);
  }

  ResourceFilter instantiateExerciseResourceSelectOneControllerFilter() {
    ResourceFilter filter = new ResourceFilter();
    filter.setLocation(Location.BUDGETARY_CLASSIFICATION);
    filter.setType(ResourceType.EXERCISE);
    filter.setUserName(userIdentifier);
    Core.acceptConsumer(EXERCISE_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER, filter);
    return filter;
  }

  void initializeAdministrativeUnitResourceSelectOneController() {
    administrativeUnitResourceSelectOneController.getAutoComplete().getOutputLabel()
        .setValue("Unité administrative");
    ResourceFilter filter = instantiateAdministrativeUnitResourceSelectOneControllerFilter();
    administrativeUnitResourceSelectOneController.useFilter(filter);
    administrativeUnitResourceSelectOneController.getAutoComplete()
        .addValueConsumer(identifier -> data.setAdministrativeUnitIdentifier(identifier));
    Core.acceptConsumer(ADMINISTRATIVE_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_CONSUMER,
        administrativeUnitResourceSelectOneController);
  }

  ResourceFilter instantiateAdministrativeUnitResourceSelectOneControllerFilter() {
    ResourceFilter filter = new ResourceFilter();
    filter.setLocation(Location.BUDGETARY_CLASSIFICATION);
    filter.setType(ResourceType.ADMINISTRATIVE_UNIT);
    filter.setUserName(userIdentifier);
    Core.acceptConsumer(ADMINISTRATIVE_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER, filter);
    return filter;
  }

  /**
   * Cette méthode permet de stocker la première ressource unité administrative.
   */
  public void storeFirstAdministrativeUnitResource() {
    GetManyRequestDto request = new GetManyRequestDto();
    ResourceFilter filter = instantiateAdministrativeUnitResourceSelectOneControllerFilter();
    request.useFilter(filter);
    request.setPage(new PageDto(0, 1));
    request.setProjection(RESOURCE_PROJECTION);
    request.setAuditWho(userIdentifier);
    ResourceGetManyResponseDto response = resourceClient.getMany(request);
    ResourceDto resource =
        (ResourceDto) Core.getFirstFromCollection(ResourceGetManyResponseDto.getDatas(response));
    setAttributeResource(resource);
  }

  /**
   * Cette méthode permet de stocker {@link ResourceDto} par son identifiant.
   *
   * @param identifier identifiant de {@link ResourceDto} à stocker
   * @return {@link ResourceDto}
   */
  public ResourceDto setAttributeResource(String identifier) {
    ResourceDto resource =
        resourceClient.getByIdentifier(identifier, RESOURCE_PROJECTION, userIdentifier, null);
    setAttributeResource(resource);
    return resource;
  }

  /**
   * Cette méthode permet de stocker {@link ResourceDto}.
   *
   * @param resource {@link ResourceDto}
   */
  public void setAttributeResource(ResourceDto resource) {
    Core.runIfNotNull(resource,
        () -> setAttributeResource(resource.getType(), resource.getLocation(), resource));
  }

  /**
   * Cette méthode permet de stocker {@link ResourceDto}.
   *
   * @param type {@link ResourceType}
   * @param location {@link Location}
   * @param resource {@link ResourceDto}
   */
  public void setAttributeResource(ResourceType type, Location location, ResourceDto resource) {
    setAttributeResource(session, type, location, resource);
  }

  /**
   * Cette méthode permet de stocker {@link ResourceDto}.
   *
   * @param session {@link HttpSession}
   * @param type {@link ResourceType}
   * @param location {@link Location}
   * @param resource {@link ResourceDto}
   */
  public static void setAttributeResource(HttpSession session, ResourceType type, Location location,
      ResourceDto resource) {
    session.setAttribute(buildResourceName(type, location), resource);
  }

  /**
   * Cette méthode permet d'obtenir {@link ResourceDto}.
   *
   * @param type {@link ResourceType}
   * @param location {@link Location}
   *
   * @return {@link ResourceDto}
   */
  public ResourceDto getAttributeResource(ResourceType type, Location location) {
    return getAttributeResource(type, location, session);
  }

  /**
   * Cette méthode permet d'obtenir {@link ResourceDto}.
   *
   * @param type {@link ResourceType}
   * @param location {@link Location}
   * @param session {@link HttpSession}
   * @return {@link ResourceDto}
   */
  public static ResourceDto getAttributeResource(ResourceType type, Location location,
      HttpSession session) {
    if (session == null) {
      return null;
    }
    return (ResourceDto) session
        .getAttribute(SharingSessionController.buildResourceName(type, location));
  }

  /**
   * Cette méthode permet de construire le nom de l'attribut de {@link ResourceDto}.
   *
   * @param type {@link ResourceType}
   * @param location {@link Location}
   * @return nom de l'attribut de {@link ResourceDto}
   */
  public static String buildResourceName(ResourceType type, Location location) {
    return "%s_%s".formatted(type.getCode(), location.getCode());
  }

  /**
   * Cette méthode permet d'obtenir l'exercice en session.
   *
   * @return exercice en session
   */
  public ResourceDto getExercise() {
    return getAttributeResource(ResourceType.EXERCISE, Location.BUDGETARY_CLASSIFICATION);
  }

  /**
   * Cette méthode permet d'obtenir la référence de l'exercice en session.
   *
   * @return référence de l'exercice en session
   */
  public String getExerciseReference() {
    return Optional.ofNullable(getExercise()).map(r -> r.getReference()).orElse(null);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'exercice en session.
   *
   * @return identifiant de l'exercice en session
   */
  public String getExerciseIdentifier() {
    return Optional.ofNullable(getExercise()).map(r -> r.getIdentifier()).orElse(null);
  }

  /**
   * Cette méthode permet d'obtenir l'unité administrative en session.
   *
   * @return unité administrative en session
   */
  public ResourceDto getAdministrativeUnit() {
    return getAttributeResource(ResourceType.ADMINISTRATIVE_UNIT,
        Location.BUDGETARY_CLASSIFICATION);
  }

  /**
   * Cette méthode permet d'obtenir la référence de l'unité administrative en session.
   *
   * @return référence de l'unité administrative en session
   */
  public String getAdministrativeUnitReference() {
    return Optional.ofNullable(getAdministrativeUnit()).map(r -> r.getReference()).orElse(null);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité administrative en session.
   *
   * @return identifiant de l'unité administrative en session
   */
  public String getAdministrativeUnitIdentifier() {
    return Optional.ofNullable(getAdministrativeUnit()).map(r -> r.getIdentifier()).orElse(null);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'unité administrative en session si référence
   * est blanc.
   *
   * @param reference référence
   * @return identifiant de l'unité administrative en session si référence est blanc.
   */
  public String getOrDefaultIfBlankAdministrativeUnitReference(String reference) {
    return Core.getOrDefaultIfBlank(reference, getAdministrativeUnitReference());
  }

  /**
   * Cette méthode permet d'afficher le dialogue des données.
   */
  public void showDataDialog() {

  }

  /**
   * Cette méthode permet de stocker {@link SharingSessionDataDto}.
   */
  public void storeData() {
    setAttributeResource(exerciseResourceSelectOneController.getAutoComplete().getValue());
    exerciseResourceSelectOneController.getAutoComplete().setValue(null);

    setAttributeResource(
        administrativeUnitResourceSelectOneController.getAutoComplete().getValue());
    administrativeUnitResourceSelectOneController.getAutoComplete().setValue(null);

    scriptManager.reloadPage();
  }

  /**
   * Cette classe représente les données de session.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class SharingSessionDataDto implements HasAdministrativeUnitIdentifierDto {

    private String exerciseIdentifier;

    private String administrativeUnitIdentifier;
  }

  /**
   * Consommateur du controleur de sélecteur d'une resource exercice.
   */
  public static Consumer<
      ResourceSelectOneController> EXERCISE_RESOURCE_SELECT_ONE_CONTROLLER_CONSUMER;

  /**
   * Consommateur du filtre du controleur de sélecteur d'une resource exercice.
   */
  public static Consumer<ResourceFilter> EXERCISE_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER;

  /**
   * Consommateur du controleur de sélecteur d'une resource unité administrative.
   */
  public static Consumer<
      ResourceSelectOneController> ADMINISTRATIVE_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_CONSUMER;

  /**
   * Consommateur du filtre du controleur de sélecteur d'une resource unité administrative.
   */
  public static Consumer<
      ResourceFilter> ADMINISTRATIVE_UNIT_RESOURCE_SELECT_ONE_CONTROLLER_FILTER_CONSUMER;

  private static final ProjectionDto RESOURCE_PROJECTION = new ProjectionDto().addNames(
      AbstractIdentifiableDto.JSON_IDENTIFIER, AbstractIdentifiableDto.JSON_AS_STRING,
      AbstractResourceOrReceiverDto.JSON_TYPE, AbstractResourceOrReceiverDto.JSON_LOCATION,
      AbstractResourceOrReceiverDto.JSON_REFERENCE);
}
