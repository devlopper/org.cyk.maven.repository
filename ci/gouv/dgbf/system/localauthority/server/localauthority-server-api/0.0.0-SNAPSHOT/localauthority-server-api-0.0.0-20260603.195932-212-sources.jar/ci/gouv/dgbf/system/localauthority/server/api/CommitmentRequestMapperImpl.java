package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link CommitmentDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-03T19:59:57+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class CommitmentRequestMapperImpl implements CommitmentRequestMapper {

    @Override
    public CommitmentService.CommitmentCreateRequestDto mapCreate(CommitmentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CommitmentService.CommitmentCreateRequestDto commitmentCreateRequestDto = new CommitmentService.CommitmentCreateRequestDto();

        commitmentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        commitmentCreateRequestDto.setName( arg0.getName() );
        commitmentCreateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        commitmentCreateRequestDto.setSupplierIdentifier( arg0.getSupplierIdentifier() );
        commitmentCreateRequestDto.setSubject( arg0.getSubject() );
        commitmentCreateRequestDto.setCommitmentReference( arg0.getCommitmentReference() );
        commitmentCreateRequestDto.setInvoiceReferenceNumber( arg0.getInvoiceReferenceNumber() );
        if ( arg0.getAmount() != null ) {
            commitmentCreateRequestDto.setAmount( arg0.getAmount() );
        }

        return commitmentCreateRequestDto;
    }

    @Override
    public CommitmentService.CommitmentUpdateRequestDto mapUpdate(CommitmentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        CommitmentService.CommitmentUpdateRequestDto commitmentUpdateRequestDto = new CommitmentService.CommitmentUpdateRequestDto();

        commitmentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        commitmentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        commitmentUpdateRequestDto.setName( arg0.getName() );
        commitmentUpdateRequestDto.setLocalAuthorityIdentifier( arg0.getLocalAuthorityIdentifier() );
        commitmentUpdateRequestDto.setSupplierIdentifier( arg0.getSupplierIdentifier() );
        commitmentUpdateRequestDto.setSubject( arg0.getSubject() );
        commitmentUpdateRequestDto.setCommitmentReference( arg0.getCommitmentReference() );
        commitmentUpdateRequestDto.setInvoiceReferenceNumber( arg0.getInvoiceReferenceNumber() );
        if ( arg0.getAmount() != null ) {
            commitmentUpdateRequestDto.setAmount( arg0.getAmount() );
        }

        return commitmentUpdateRequestDto;
    }
}
