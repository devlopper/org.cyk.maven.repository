package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une saisie de date.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInputDate<T> extends AbstractInput<T> {

  protected String placeholder;

  public AbstractInputDate<T> computePlaceholderFromOutputLabelValue() {
    placeholder = "Saisir " + outputLabel().getValue();
    return this;
  }
}
