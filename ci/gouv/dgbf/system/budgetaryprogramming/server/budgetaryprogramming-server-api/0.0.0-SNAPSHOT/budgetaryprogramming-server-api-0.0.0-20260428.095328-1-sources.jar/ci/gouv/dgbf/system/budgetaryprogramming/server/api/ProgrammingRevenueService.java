package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProgrammingRevenueDto}.
 *
 * @author Christian
 */
@Path(value = ProgrammingRevenueService.PATH)
@Tag(name = "Gestion des Revenus de Programmation")
public interface ProgrammingRevenueService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "revenusProgrammation";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ProgrammingRevenueSaveRequestDto {

    /**
     * Identifiant de la programmation.
     */
    String getProgrammingIdentifier();

    /**
     * Définit l'identifiant de la programmation.
     *
     * @param programmingIdentifier l'identifiant de la programmation
     */
    void setProgrammingIdentifier(String programmingIdentifier);

    /**
     * Identifiant du revenu.
     */
    String getRevenueIdentifier();

    /**
     * Définit l'identifiant du revenu.
     *
     * @param revenueIdentifier l'identifiant du revenu
     */
    void setRevenueIdentifier(String revenueIdentifier);

    /**
     * Identifiant de la programmation.
     */
    String JSON_PROGRAMMING_IDENTIFIER = ProgrammingRevenueDto.JSON_PROGRAMMING_IDENTIFIER;

    /**
     * Identifiant du revenu.
     */
    String JSON_REVENUE_IDENTIFIER = ProgrammingRevenueDto.JSON_REVENUE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ProgrammingRevenueDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_REVENU_PROGRAMMATION";

  /**
   * Chemin du service de création unitaire de {@link ProgrammingRevenueDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProgrammingRevenueCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ProgrammingRevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingRevenueCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto 
      implements ProgrammingRevenueSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_REVENUE_IDENTIFIER)
    private String revenueIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ProgrammingRevenueDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REVENU_PROGRAMMATION";

  /**
   * Chemin du service d'obtention de plusieurs {@link ProgrammingRevenueDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingRevenueGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ProgrammingRevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ProgrammingRevenueGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProgrammingRevenueDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProgrammingRevenueDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ProgrammingRevenueDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_REVENU_PROGRAMMATION";

  /**
   * Chemin du service d'obtention unitaire de {@link ProgrammingRevenueDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingRevenueDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ProgrammingRevenueDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REVENU_PROGRAMMATION";

  /**
   * Chemin du service d'obtention par identifiant de {@link ProgrammingRevenueDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ProgrammingRevenueDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ProgrammingRevenueDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_REVENU_PROGRAMMATION";

  /**
   * Chemin du service de mise à jour unitaire de {@link ProgrammingRevenueDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProgrammingRevenueUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ProgrammingRevenueDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProgrammingRevenueUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto 
      implements ProgrammingRevenueSaveRequestDto {

    @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
    private String programmingIdentifier;

    @JsonbProperty(JSON_REVENUE_IDENTIFIER)
    private String revenueIdentifier;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ProgrammingRevenueDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_REVENU_PROGRAMMATION";

  /**
   * Chemin du service de suppression unitaire de {@link ProgrammingRevenueDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ProgrammingRevenueDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
