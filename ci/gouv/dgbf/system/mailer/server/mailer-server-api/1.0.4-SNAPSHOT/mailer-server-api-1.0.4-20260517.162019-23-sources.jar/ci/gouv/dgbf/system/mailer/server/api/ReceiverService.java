package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.json.bind.annotation.JsonbPropertyOrder;
import jakarta.validation.constraints.NotNull;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion des destinataires.
 *
 * @author Christian
 *
 */
@Path(ReceiverService.PATH)
@Tag(name = "Gestion des destinataires")
public interface ReceiverService extends SpecificService {

  String PATH = "destinataires";

  String CREATE_IDENTIFIER = "CREATION_DESTINATAIRE";

  String CREATE_PATH = "";

  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création de destinataire",
      description = "Ce service permet de créer un destinataire")
  @APIResponse(responseCode = "201", content = {@Content(mediaType = MediaType.APPLICATION_JSON,
      schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ReceiverCreateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête de création.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {ReceiverCreateRequestDto.FIELD_MAIL_IDENTIFIER,
      ReceiverCreateRequestDto.FIELD_ADDRESS, AbstractRequestDto.FIELD_AUDIT_WHO})
  class ReceiverCreateRequestDto extends AbstractAuditedRequestJsonDto {

    @NotNull
    @JsonbProperty(value = JSON_MAIL_IDENTIFIER)
    private String mailIdentifier;

    @NotNull
    @JsonbProperty(value = JSON_ADDRESS)
    private String address;

    public static final String FIELD_MAIL_IDENTIFIER = "mailIdentifier";
    public static final String FIELD_ADDRESS = "address";

    public static final String JSON_MAIL_IDENTIFIER = ReceiverDto.JSON_MAIL_IDENTIFIER;
    public static final String JSON_ADDRESS = ReceiverDto.JSON_ADDRESS;
  }

  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_DESTINATAIRE";

  String GET_MANY_PATH = "obtention/plusieurs";

  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet de d'obtenir des destinataires")
  Response getMany(GetManyRequestDto request);
  
  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class GetManyResponseDto
      extends AbstractGetByPageResponseDto<ReceiverDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ReceiverDto> datas;
  }
  
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_DESTINATAIRE";

  String GET_ONE_PATH = "obtention/un";

  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet de d'obtenir des destinataires")
  Response getOne(GetOneRequestDto request);
  
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_DESTINATAIRE";

  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet de d'obtenir par identifiant un destinataire")
  Response getByIdentifier(GetByIdentifierRequestDto request);
  
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_DESTINATAIRE";

  String UPDATE_PATH = "";

  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un destinataire")
  Response update(ReceiverUpdateRequestDto request);

  /**
   * Cette classe représente un objet de transfert de donnée d'une requête de mise à jour.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @JsonbPropertyOrder(value = {ByIdentifierRequestDto.FIELD_IDENTIFIER,
      ReceiverUpdateRequestDto.FIELD_MAIL_IDENTIFIER, ReceiverUpdateRequestDto.FIELD_ADDRESS,
      AbstractRequestDto.FIELD_AUDIT_WHO})
  class ReceiverUpdateRequestDto extends ByIdentifierRequestDto {

    @NotNull
    @JsonbProperty(value = JSON_MAIL_IDENTIFIER)
    private String mailIdentifier;

    @NotNull
    @JsonbProperty(value = JSON_ADDRESS)
    private String address;

    public static final String FIELD_MAIL_IDENTIFIER = "mailIdentifier";
    public static final String FIELD_ADDRESS = "address";

    public static final String JSON_MAIL_IDENTIFIER = ReceiverDto.JSON_MAIL_IDENTIFIER;
    public static final String JSON_ADDRESS = ReceiverDto.JSON_ADDRESS;
  }

  String DELETE_IDENTIFIER = "SUPPRESSION_DESTINATAIRE";

  String DELETE_PATH = "";

  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un destinataire")
  Response delete(DeleteOneRequestDto request);
}
