package ci.gouv.dgbf.system.servicecatalog.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ModuleDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-19T11:17:02+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ModuleRequestMapperImpl implements ModuleRequestMapper {

    @Override
    public ModuleService.ModuleCreateRequestDto mapCreate(ModuleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ModuleService.ModuleCreateRequestDto moduleCreateRequestDto = new ModuleService.ModuleCreateRequestDto();

        moduleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        moduleCreateRequestDto.setCode( arg0.getCode() );
        moduleCreateRequestDto.setName( arg0.getName() );
        moduleCreateRequestDto.setDescription( arg0.getDescription() );
        moduleCreateRequestDto.setVisible( arg0.getVisible() );
        moduleCreateRequestDto.setStrategicClassification( arg0.getStrategicClassification() );
        moduleCreateRequestDto.setGroup( arg0.getGroup() );

        return moduleCreateRequestDto;
    }

    @Override
    public ModuleService.ModuleUpdateRequestDto mapUpdate(ModuleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ModuleService.ModuleUpdateRequestDto moduleUpdateRequestDto = new ModuleService.ModuleUpdateRequestDto();

        moduleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        moduleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        moduleUpdateRequestDto.setCode( arg0.getCode() );
        moduleUpdateRequestDto.setName( arg0.getName() );
        moduleUpdateRequestDto.setDescription( arg0.getDescription() );
        moduleUpdateRequestDto.setVisible( arg0.getVisible() );
        moduleUpdateRequestDto.setStrategicClassification( arg0.getStrategicClassification() );
        moduleUpdateRequestDto.setGroup( arg0.getGroup() );

        return moduleUpdateRequestDto;
    }
}
