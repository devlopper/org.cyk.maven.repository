package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Codes du Statut de Dossier — cycle de vie de l'unité administrative de budget.
 *
 * <p>Six états, un chemin unique, aucun retour. Le Dossier n'est plus seulement un conteneur
 * qui achemine : son statut <strong>ouvre les étapes</strong> que ses lignes peuvent franchir, et
 * c'est le chef d'équipe qui l'avance. Une ligne ne peut pas aller plus loin que son dossier ne
 * l'y autorise.</p>
 *
 * <p>Source : diagrammes d'états du 27/08/2026, annexe 6.1, révisés le 05/10/2026 par la règle
 * de subordination des statuts.</p>
 *
 * @author Christian
 *
 */
public class BudgetAdministrativeUnitStatusCode {

  private BudgetAdministrativeUnitStatusCode() {
  }

  /** Le dossier est ouvert ; son contenu peut encore être complété. */
  public static final String CREATED = "CREE";

  /** Le dossier a quitté l'EPN ; son contenu est figé (RG_PRB_ARB_05). */
  public static final String TRANSMITTED = "TRANSMIS";

  /** La DCB a accusé prise en charge ; l'étape de traitement est ouverte. */
  public static final String RECEIVED = "RECEPTIONNE";

  /** Le chef d'équipe a validé le traitement ; l'étape de validation est ouverte. */
  public static final String PROCESSED = "TRAITE";

  /** Le chef d'équipe a validé le dossier ; l'étape de consolidation est ouverte. */
  public static final String VALIDATED = "VALIDE";

  /**
   * Consolidé — l'arbitrage est clos, le dossier ne bouge plus.
   */
  public static final String CONSOLIDATED = "CONSOLIDE";
}
