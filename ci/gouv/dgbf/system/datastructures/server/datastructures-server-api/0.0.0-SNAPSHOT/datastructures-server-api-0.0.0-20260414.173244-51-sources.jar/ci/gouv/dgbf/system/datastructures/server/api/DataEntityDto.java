package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasCreationScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasDeletionScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasExistenceVerificationScriptDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsExistsDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueSourceGroupsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entité de données.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DataEntityDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasTypeAsStringDto, HasAddressDto, HasCreationScriptDto, HasDeletionScriptDto,
    HasExistenceVerificationScriptDto, HasIsExistsDto, HasValuesCountAsStringDto,
    HasValueSourceGroupsCountAsStringDto {

  @JsonbProperty(JSON_TYPE)
  private DataEntityType type;

  @JsonbProperty(JSON_ADDRESS)
  private String address;
  
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  @JsonbProperty(JSON_CREATION_SCRIPT)
  private String creationScript;

  @JsonbProperty(JSON_DELETION_SCRIPT)
  private String deletionScript;

  @JsonbProperty(JSON_EXISTENCE_VERIFICATION_SCRIPT)
  private String existenceVerificationScript;

  @JsonbProperty(JSON_IS_EXISTS)
  private Boolean isExists;

  @JsonbProperty(JSON_VALUES_COUNT_AS_STRING)
  private String valuesCountAsString;

  @JsonbProperty(JSON_VALUE_SOURCE_GROUPS_COUNT_AS_STRING)
  private String valueSourceGroupsCountAsString;
  
  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEntiteDonnee";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "entiteDonneeChaine";

  /**
   * Identifiant json {@link #type}.
   */
  public static final String JSON_TYPE = "type";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "entité de données";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "entités de données";
}
