package ci.gouv.dgbf.extension.primefaces.component.statistic;

import ci.gouv.dgbf.extension.primefaces.component.AbstractWidget;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base des cartes statistiques.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractStatisticCard extends AbstractWidget {

}
