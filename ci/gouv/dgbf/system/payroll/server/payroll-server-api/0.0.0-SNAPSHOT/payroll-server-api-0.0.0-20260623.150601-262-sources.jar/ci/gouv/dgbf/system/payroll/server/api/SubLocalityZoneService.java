package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link SubLocalityZoneDto}.
 *
 * @author akm
 *
 */
@Path(value = SubLocalityZoneService.PATH)
@Tag(name = "Gestion des zones de sous-localité")
public interface SubLocalityZoneService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "sous-localites-zones";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface SubLocalityZoneSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant de la sous localité.
     *
     * @return identifiant la sous localité
     */
    String getSubLocalityIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la sous localité.
     *
     * @param identifier identifiant de la sous localité
     */
    void setSubLocalityIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link ZoneDto}.
     *
     * @return identifiant {@link ZoneDto}
     */
    String getZoneIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link ZoneDto}.
     *
     * @param identifier identifiant {@link ZoneDto}
     */
    void setZoneIdentifier(String identifier);

    /**
     * {@link SubLocalityZoneDto#JSON_SUB_LOCALITY_IDENTIFIER}.
     */
    public static final String JSON_SUB_LOCALITY_IDENTIFIER =
        SubLocalityZoneDto.JSON_SUB_LOCALITY_IDENTIFIER;

    /**
     * {@link SubLocalityZoneDto#JSON_ZONE_IDENTIFIER}.
     */
    public static final String JSON_ZONE_IDENTIFIER =
        SubLocalityZoneDto.JSON_ZONE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(SubLocalityZoneCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class SubLocalityZoneCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements SubLocalityZoneSaveRequestDto {
    /**
     * Identifiant de {@link SubLocalityDto}.
     */
    @JsonbProperty(JSON_SUB_LOCALITY_IDENTIFIER)
    String subLocalityIdentifier;
    /**
     * Identifiant de {@link ZoneDto}.
     */
    @JsonbProperty(JSON_ZONE_IDENTIFIER)
    String zoneIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = SubLocalityZoneGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class SubLocalityZoneGetManyResponseDto
      extends AbstractGetByPageResponseDto<SubLocalityZoneDto> {

    @JsonbProperty(JSON_DATAS)
    private List<SubLocalityZoneDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SubLocalityZoneDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = SubLocalityZoneDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(SubLocalityZoneUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class SubLocalityZoneUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements SubLocalityZoneSaveRequestDto {
    /**
     * Identifiant de la sous localité.
     */
    @JsonbProperty(JSON_SUB_LOCALITY_IDENTIFIER)
    String subLocalityIdentifier;
    /**
     * Identifiant de {@link ZoneDto}.
     */
    @JsonbProperty(JSON_ZONE_IDENTIFIER)
    String zoneIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ZONE_SOUS_LOCALITE";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link SubLocalityZoneDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
