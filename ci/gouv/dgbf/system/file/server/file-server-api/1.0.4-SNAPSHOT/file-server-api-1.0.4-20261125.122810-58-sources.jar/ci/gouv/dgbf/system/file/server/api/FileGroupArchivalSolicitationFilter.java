package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.LinkedHashSet;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de demande d'archivage de fichier de groupe.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileGroupArchivalSolicitationFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du fichier de groupe maître.
   */
  private String fileGroupIdentifier;

  /**
   * Codes des statuts de la demande.
   */
  private Set<String> statuses;

  /**
   * Indicateur de demande de retrait.
   */
  private Boolean withdrawal;

  /**
   * Identifiant de l'archive d'origine.
   */
  private String originIdentifier;

  /**
   * Identifiant du créateur de la demande.
   */
  private String creatorIdentifier;

  /**
   * Cette méthode permet de construire.
   */
  public FileGroupArchivalSolicitationFilter() {
    super();
  }

  /**
   * Cette méthode permet de construire avec un filtre.
   *
   * @param filter filtre
   */
  public FileGroupArchivalSolicitationFilter(FilterDto filter) {
    super(filter);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    fileGroupIdentifier = getFileGroupIdentifier(filter);
    statuses = getStatuses(filter);
    withdrawal = getWithdrawal(filter);
    originIdentifier = getOriginIdentifier(filter);
    creatorIdentifier = getCreatorIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFileGroupIdentifier(filter, fileGroupIdentifier);
    setStatuses(filter, statuses);
    setWithdrawal(filter, withdrawal);
    setOriginIdentifier(filter, originIdentifier);
    setCreatorIdentifier(filter, creatorIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du fichier de groupe maître.
   *
   * @param filter filtre
   * @param fileGroupIdentifier identifiant du fichier de groupe maître
   */
  public static void setFileGroupIdentifier(FilterDto filter, String fileGroupIdentifier) {
    set(filter, JSON_FILE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(fileGroupIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du fichier de groupe maître.
   *
   * @param filter filtre
   * @return identifiant du fichier de groupe maître
   */
  public static String getFileGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FILE_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les statuts de la demande.
   *
   * @param filter filtre
   * @param statuses statuts de la demande
   */
  public static void setStatuses(FilterDto filter, Set<String> statuses) {
    set(filter, JSON_STATUSES, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSet((LinkedHashSet<String>) Core
            .getOrNullifyIfCollectionEmpty(Core.getLinkedHashSet(statuses))));
  }

  /**
   * Cette méthode permet d'obtenir les statuts de la demande.
   *
   * @param filter filtre
   * @return statuts de la demande
   */
  public static Set<String> getStatuses(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_STATUSES));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur de retrait.
   *
   * @param filter filtre
   * @param withdrawal indicateur de retrait
   */
  public static void setWithdrawal(FilterDto filter, Boolean withdrawal) {
    set(filter, JSON_WITHDRAWAL, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(withdrawal));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur de retrait.
   *
   * @param filter filtre
   * @return indicateur de retrait
   */
  public static Boolean getWithdrawal(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_WITHDRAWAL));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'archive d'origine.
   *
   * @param filter filtre
   * @param originIdentifier identifiant de l'archive d'origine
   */
  public static void setOriginIdentifier(FilterDto filter, String originIdentifier) {
    set(filter, JSON_ORIGIN_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(originIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'archive d'origine.
   *
   * @param filter filtre
   * @return identifiant de l'archive d'origine
   */
  public static String getOriginIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ORIGIN_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du créateur.
   *
   * @param filter filtre
   * @param creatorIdentifier identifiant du créateur
   */
  public static void setCreatorIdentifier(FilterDto filter, String creatorIdentifier) {
    set(filter, JSON_CREATOR_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(creatorIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du créateur.
   *
   * @param filter filtre
   * @return identifiant du créateur
   */
  public static String getCreatorIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CREATOR_IDENTIFIER));
  }

  /**
   * Clé JSON de l'identifiant du fichier de groupe maître.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER =
      FileGroupArchivalSolicitationDto.JSON_FILE_GROUP_IDENTIFIER;

  /**
   * Clé JSON des statuts de la demande.
   */
  public static final String JSON_STATUSES = "statuts";

  /**
   * Clé JSON de l'indicateur de retrait.
   */
  public static final String JSON_WITHDRAWAL = FileGroupArchivalSolicitationDto.JSON_WITHDRAWAL;

  /**
   * Clé JSON de l'identifiant de l'archive d'origine.
   */
  public static final String JSON_ORIGIN_IDENTIFIER =
      FileGroupArchivalSolicitationDto.JSON_ORIGIN_IDENTIFIER;

  /**
   * Clé JSON de l'identifiant du créateur.
   */
  public static final String JSON_CREATOR_IDENTIFIER =
      FileGroupArchivalSolicitationDto.JSON_CREATOR_IDENTIFIER;
}
