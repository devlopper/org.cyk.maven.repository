package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FurLocalityDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T18:26:59+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.20.1 (Eclipse Adoptium)"
)
@ApplicationScoped
public class FurLocalityRequestMapperImpl implements FurLocalityRequestMapper {

    @Override
    public FurLocalityService.FurLocalityCreateRequestDto mapCreate(FurLocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurLocalityService.FurLocalityCreateRequestDto furLocalityCreateRequestDto = new FurLocalityService.FurLocalityCreateRequestDto();

        furLocalityCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        furLocalityCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        furLocalityCreateRequestDto.setLocalityCode( arg0.getLocalityCode() );
        furLocalityCreateRequestDto.setCaloLocalityCode( arg0.getCaloLocalityCode() );
        furLocalityCreateRequestDto.setPaymentModeCode( arg0.getPaymentModeCode() );

        return furLocalityCreateRequestDto;
    }

    @Override
    public FurLocalityService.FurLocalityUpdateRequestDto mapUpdate(FurLocalityDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurLocalityService.FurLocalityUpdateRequestDto furLocalityUpdateRequestDto = new FurLocalityService.FurLocalityUpdateRequestDto();

        furLocalityUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        furLocalityUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        furLocalityUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        furLocalityUpdateRequestDto.setLocalityCode( arg0.getLocalityCode() );
        furLocalityUpdateRequestDto.setCaloLocalityCode( arg0.getCaloLocalityCode() );
        furLocalityUpdateRequestDto.setPaymentModeCode( arg0.getPaymentModeCode() );

        return furLocalityUpdateRequestDto;
    }
}
