package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant saisi pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasInputtedAmountN1AsString {

  /**
   * Obtient le montant saisi pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant saisi pour l'année N+1 sous forme de chaîne de caractères
   */
  String getInputtedAmountN1AsString();

  /**
   * Définit le montant saisi pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param inputtedAmountN1AsString le montant saisi pour l'année N+1 sous forme de chaîne de
   *        caractères
   */
  void setInputtedAmountN1AsString(String inputtedAmountN1AsString);

  /**
   * Identifiant java du montant saisi pour l'année N+1, sous forme de chaîne de caractères.
   */
  String FIELD_INPUTTED_AMOUNT_N1_AS_STRING = "inputtedAmountN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName