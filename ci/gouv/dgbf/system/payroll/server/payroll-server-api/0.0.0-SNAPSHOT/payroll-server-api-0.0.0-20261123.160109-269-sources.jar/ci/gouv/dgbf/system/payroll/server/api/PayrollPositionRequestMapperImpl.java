package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollPositionDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-23T16:01:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollPositionRequestMapperImpl implements PayrollPositionRequestMapper {

    @Override
    public PayrollPositionService.PayrollPositionCreateRequestDto mapCreate(PayrollPositionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollPositionService.PayrollPositionCreateRequestDto payrollPositionCreateRequestDto = new PayrollPositionService.PayrollPositionCreateRequestDto();

        payrollPositionCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollPositionCreateRequestDto.setCode( arg0.getCode() );
        payrollPositionCreateRequestDto.setName( arg0.getName() );

        return payrollPositionCreateRequestDto;
    }

    @Override
    public PayrollPositionService.PayrollPositionUpdateRequestDto mapUpdate(PayrollPositionDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollPositionService.PayrollPositionUpdateRequestDto payrollPositionUpdateRequestDto = new PayrollPositionService.PayrollPositionUpdateRequestDto();

        payrollPositionUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollPositionUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollPositionUpdateRequestDto.setCode( arg0.getCode() );
        payrollPositionUpdateRequestDto.setName( arg0.getName() );

        return payrollPositionUpdateRequestDto;
    }
}
