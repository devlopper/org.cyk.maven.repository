package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de gestion de {@link ClaimDocumentRuleDto}. N'étend
 * pas {@link ci.gouv.dgbf.extension.server.service.api.Service} mais {@link SpecificService} --
 * {@link ClaimDocumentRuleDto} n'a ni code ni nom propres : la règle est identifiée par son code
 * pièce et son préfixe de code document.
 *
 * @author akm
 *
 */
@Path(ClaimDocumentRuleService.PATH)
@Tag(name = "Gestion des règles de type par document")
public interface ClaimDocumentRuleService extends SpecificService {

  /**
   * Chemin de base.
   */
  String PATH = "regles-type-document";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface ClaimDocumentRuleSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le code pièce.
     *
     * @return code pièce
     */
    String getPieceCode();

    /**
     * Cette méthode permet d'assigner le code pièce.
     *
     * @param pieceCode code pièce
     */
    void setPieceCode(String pieceCode);

    /**
     * Cette méthode permet d'obtenir le préfixe du code document.
     *
     * @return préfixe du code document
     */
    String getDocumentPrefix();

    /**
     * Cette méthode permet d'assigner le préfixe du code document.
     *
     * @param documentPrefix préfixe du code document
     */
    void setDocumentPrefix(String documentPrefix);

    /**
     * Cette méthode permet d'obtenir l'identifiant du type de réclamation.
     *
     * @return identifiant du type de réclamation
     */
    String getTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du type de réclamation.
     *
     * @param typeIdentifier identifiant du type de réclamation
     */
    void setTypeIdentifier(String typeIdentifier);

    /**
     * {@link ClaimDocumentRuleDto#JSON_PIECE_CODE}.
     */
    String JSON_PIECE_CODE = ClaimDocumentRuleDto.JSON_PIECE_CODE;

    /**
     * {@link ClaimDocumentRuleDto#JSON_DOCUMENT_PREFIX}.
     */
    String JSON_DOCUMENT_PREFIX = ClaimDocumentRuleDto.JSON_DOCUMENT_PREFIX;

    /**
     * {@link ClaimDocumentRuleDto#JSON_TYPE_IDENTIFIER}.
     */
    String JSON_TYPE_IDENTIFIER = ClaimDocumentRuleDto.JSON_TYPE_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link ClaimDocumentRuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ClaimDocumentRuleCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimDocumentRuleCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ClaimDocumentRuleSaveRequestDto {

    @JsonbProperty(JSON_PIECE_CODE)
    private String pieceCode;

    @JsonbProperty(JSON_DOCUMENT_PREFIX)
    private String documentPrefix;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class ClaimDocumentRuleGetManyResponseDto
      extends AbstractGetByPageResponseDto<ClaimDocumentRuleDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ClaimDocumentRuleDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir une identité.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ClaimDocumentRuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ClaimDocumentRuleDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link ClaimDocumentRuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ClaimDocumentRuleUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class ClaimDocumentRuleUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ClaimDocumentRuleSaveRequestDto {

    @JsonbProperty(JSON_PIECE_CODE)
    private String pieceCode;

    @JsonbProperty(JSON_DOCUMENT_PREFIX)
    private String documentPrefix;

    @JsonbProperty(JSON_TYPE_IDENTIFIER)
    private String typeIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_REGLE_TYPE_DOCUMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link ClaimDocumentRuleDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
