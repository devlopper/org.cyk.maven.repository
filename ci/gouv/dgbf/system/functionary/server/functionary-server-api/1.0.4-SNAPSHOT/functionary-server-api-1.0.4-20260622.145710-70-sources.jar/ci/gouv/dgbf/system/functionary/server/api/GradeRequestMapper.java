package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.functionary.server.api.GradeService.GradeCreateRequestDto;
import ci.gouv.dgbf.system.functionary.server.api.GradeService.GradeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link GradeDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link GradeDto}.

    @author Stéphane
               """)
public interface GradeRequestMapper
    extends RequestMapper<GradeDto, GradeCreateRequestDto, GradeUpdateRequestDto> {

}
