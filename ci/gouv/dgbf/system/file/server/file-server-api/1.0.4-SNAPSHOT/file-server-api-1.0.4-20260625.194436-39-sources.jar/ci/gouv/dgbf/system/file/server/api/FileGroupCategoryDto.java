package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une catégorie de fichier de groupe.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileGroupCategoryDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant {@link FileGroupDto}.
   */
  @JsonbProperty(JSON_FILE_GROUP_IDENTIFIER)
  private String fileGroupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link FileGroupDto}.
   */
  @JsonbProperty(JSON_FILE_GROUP_AS_STRING)
  private String fileGroupAsString;
  
  /**
   * Représentation en chaine de caractères de {@link FileDto}.
   */
  @JsonbProperty(JSON_FILE_AS_STRING)
  private String fileAsString;

  /**
   * Représentation en chaine de caractères de {@link FilesGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;
  
  /**
   * Identifiant de {@link FileCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;
  
  /**
   * Représentation en chaine de caractères de {@link FileCategoryDto}.
   */
  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  /**
   * Champ JSON {@link #fileGroupIdentifier}.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER = "idFichierGroupe";
  
  /**
   * Champ JSON {@link #fileGroupAsString}.
   */
  public static final String JSON_FILE_GROUP_AS_STRING = "fichierGroupeChaine";
  
  /**
   * Champ JSON {@link #fileAsString}.
   */
  public static final String JSON_FILE_AS_STRING = "fichierChaine";
  
  /**
   * Champ JSON {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";
  
  /**
   * Champ JSON {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER = "idCategorie";
  
  /**
   * Champ JSON {@link #categoryAsString}.
   */
  public static final String JSON_CATEGORY_AS_STRING = "categorieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "catégorie de fichier de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "catégories de fichier de groupe";
}
