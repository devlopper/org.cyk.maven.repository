package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToValidateNAsStringDto extends HasTotalAmountToValidateNAsString {

  /**
   * Identifiant json du montant total à valider pour l'année N, sous forme de chaîne de caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_VALIDATE_N_AS_STRING = "montantTotalAValiderNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName