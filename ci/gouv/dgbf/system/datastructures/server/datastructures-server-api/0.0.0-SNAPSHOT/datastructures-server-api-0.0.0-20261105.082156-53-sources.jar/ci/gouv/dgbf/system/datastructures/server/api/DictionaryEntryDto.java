package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDefaultValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.List;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une entrée d'un dictionnaire.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DictionaryEntryDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasValueTypeDto, HasDefaultValueDto<String> {

  /**
   * Identifiant de {@link DictionaryDto}.
   */
  @JsonbProperty(JSON_DICTIONARY_IDENTIFIER)
  private String dictionaryIdentifier;

  /**
   * Représentation en chaine de caractères de {@link DictionaryDto}.
   */
  @JsonbProperty(JSON_DICTIONARY_AS_STRING)
  private String dictionaryAsString;

  /**
   * Valeur par défaut {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_DEFAULT_VALUE)
  private String defaultValue;

  /**
   * Type de valeur {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  /**
   * Nombre minimal d'occurrences {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_MIN_OCCURRENCES)
  private Integer minOccurrences;

  /**
   * Nombre maximal d'occurrences {@link DictionaryEntryDto}, null si illimité.
   */
  @JsonbProperty(JSON_MAX_OCCURRENCES)
  private Integer maxOccurrences;

  /**
   * Rang de l'entrée dans son dictionnaire {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_ORDER)
  private Integer order;

  /**
   * Longueur minimale (STRING) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_MIN_LENGTH)
  private Integer minLength;

  /**
   * Longueur maximale (STRING) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_MAX_LENGTH)
  private Integer maxLength;

  /**
   * Borne minimale (INTEGER, FLOAT, INSTANT) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_MIN_VALUE)
  private String minValue;

  /**
   * Borne maximale (INTEGER, FLOAT, INSTANT) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_MAX_VALUE)
  private String maxValue;

  /**
   * Expression régulière (STRING) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_PATTERN)
  private String pattern;

  /**
   * Valeurs autorisées (STRING, INTEGER) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_ALLOWED_VALUES)
  private List<String> allowedValues;

  /**
   * Précision (FLOAT) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_PRECISION)
  private Integer precision;

  /**
   * Échelle (FLOAT) {@link DictionaryEntryDto}.
   */
  @JsonbProperty(JSON_SCALE)
  private Integer scale;


  /**
   * Identitiant json {@link DictionaryEntryDto#dictionaryIdentifier}.
   */
  public static final String JSON_DICTIONARY_IDENTIFIER = "idDictionnaire";

  /**
   * Identitiant json {@link DictionaryEntryDto#dictionaryAsString}.
   */
  public static final String JSON_DICTIONARY_AS_STRING = "dictionnaireChaine";

  /**
   * Identitiant json {@link DictionaryEntryDto#minOccurrences}.
   */
  public static final String JSON_MIN_OCCURRENCES = "occurrencesMin";

  /**
   * Identitiant json {@link DictionaryEntryDto#maxOccurrences}.
   */
  public static final String JSON_MAX_OCCURRENCES = "occurrencesMax";

  /**
   * Identitiant json {@link DictionaryEntryDto#order}.
   */
  public static final String JSON_ORDER = "ordre";

  /**
   * Identitiant json {@link DictionaryEntryDto#minLength}.
   */
  public static final String JSON_MIN_LENGTH = "longueurMin";

  /**
   * Identitiant json {@link DictionaryEntryDto#maxLength}.
   */
  public static final String JSON_MAX_LENGTH = "longueurMax";

  /**
   * Identitiant json {@link DictionaryEntryDto#minValue}.
   */
  public static final String JSON_MIN_VALUE = "valeurMin";

  /**
   * Identitiant json {@link DictionaryEntryDto#maxValue}.
   */
  public static final String JSON_MAX_VALUE = "valeurMax";

  /**
   * Identitiant json {@link DictionaryEntryDto#pattern}.
   */
  public static final String JSON_PATTERN = "expressionReguliere";

  /**
   * Identitiant json {@link DictionaryEntryDto#allowedValues}.
   */
  public static final String JSON_ALLOWED_VALUES = "valeursAutorisees";

  /**
   * Identitiant json {@link DictionaryEntryDto#precision}.
   */
  public static final String JSON_PRECISION = "precision";

  /**
   * Identitiant json {@link DictionaryEntryDto#scale}.
   */
  public static final String JSON_SCALE = "echelle";


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "entrée Dictionnaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "entrées Dictionnaire";
}
