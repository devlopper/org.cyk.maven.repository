package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementGroupClient;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementGroupDto;
import ci.gouv.dgbf.system.payroll.server.api.SalaryElementGroupService.SalaryElementGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link SalaryElementGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class SalaryElementGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    SalaryElementGroupDto, SalaryElementGroupGetManyResponseDto, SalaryElementGroupClient> {

  @Getter
  @Inject
  SalaryElementGroupClient client;

  protected SalaryElementGroupSelectOneController() {
    super(SalaryElementGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
