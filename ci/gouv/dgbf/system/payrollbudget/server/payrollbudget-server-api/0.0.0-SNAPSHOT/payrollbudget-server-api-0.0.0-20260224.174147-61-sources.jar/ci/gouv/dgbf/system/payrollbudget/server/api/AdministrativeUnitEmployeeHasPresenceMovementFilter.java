package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FieldFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Interface représentant un filtre basé sur la notion d'avoir un mouvement de présence.
 *
 * {@inheritDoc}
 *
 * @author Christian
 */
public interface AdministrativeUnitEmployeeHasPresenceMovementFilter extends FieldFilter {

  /**
   * Cette méthode permet d'obtenir a un mouvement de présence.
   *
   * @param filter {@link FilterDto}
   * @return a un mouvement de présence
   */
  public static Boolean get(FilterDto filter) {
    return FilterValueGetter.get(filter, d -> d.getFieldValueAsBooleanByName(JSON_KEY));
  }

  /**
   * Cette méthode permet d'assigner a un mouvement de présence.
   *
   * @param filter {@link FilterDto}
   * @param hasPresenceMovement a un mouvement de présence
   */
  public static void set(FilterDto filter, Boolean hasPresenceMovement) {
    FilterValueSetter.set(filter, JSON_KEY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(hasPresenceMovement));
  }

  /**
   * Identifiant json dans {@link FilterDto}.
   * 
   */
  static String JSON_KEY = "aMouvementPresence";


}

