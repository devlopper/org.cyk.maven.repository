package ci.gouv.dgbf.system.servicecatalog.server.api;

/**
 * Cette interface représente une classe avec une notion de nombre de processus sous forme de
 * chaîne.
 *
 * @author Christian
 */
public interface HasProcessCountAsStringDto extends HasProcessCountAsString {

  /**
   * Identifiant json du nombre de processus sous forme de chaîne.
   */
  String JSON_PROCESS_COUNT_AS_STRING = "nombreProcessusChaine";
}
