package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionDto}.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
public class FunctionFilter extends AbstractIdentifiableFilter {
  
  /**
   * Identifiant de {@link FunctionTypeDto}.
   */
  @JsonbProperty(value = JSON_TYPE_IDENTIFIER)
  String typeIdentifier;
  
  /**
   * Identifiant de {@link FunctionGroupDto}.
   */
  @JsonbProperty(value = JSON_GROUP_IDENTIFIER)
  String groupIdentifier;


  /**
   * Cette méthode permet d'instancier un objet.
   */
  public FunctionFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public FunctionFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    typeIdentifier = getTypeIdentifier(filter);
    groupIdentifier = getGroupIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setTypeIdentifier(filter, typeIdentifier);
    setGroupIdentifier(filter, groupIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #typeIdentifier}.
   *
   * @param filter filtre
   * @param typeIdentifier {@link #typeIdentifier}
   */
  public static void setTypeIdentifier(FilterDto filter,
      String typeIdentifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
              f -> f.setValueAsString(typeIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #typeIdentifier}.
   *
   * @param filter filtre
   * @return {@link #typeIdentifier}
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d
      .getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner {@link #groupIdentifier}.
   *
   * @param filter filtre
   * @param groupIdentifier {@link #groupIdentifier}
   */
  public static void setGroupIdentifier(FilterDto filter,
      String groupIdentifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
              f -> f.setValueAsString(groupIdentifier));
  }
  
  /**
   * Cette méthode permet d'obtenir {@link #groupIdentifier}.
   *
   * @param filter filtre
   * @return {@link #groupIdentifier}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d
      .getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Identifiant json du {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
      FunctionTypeDto.JSON_THIS_IDENTIFIER;
  
  /**
   * Identifiant json du {@link #typeIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER =
      FunctionGroupDto.JSON_THIS_IDENTIFIER;
}
