package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasAttributeNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRequestAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasSelectorsCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasValuesCountAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une source de valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ValueSourceDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasGroupIdentifierDto, HasGroupAsStringDto, HasAttributeNameDto, HasValueTypeDto,
    HasValueTypeAsStringDto, HasRequestAsStringDto, HasValuesCountAsStringDto,
    HasSelectorsCountAsStringDto {

  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_ATTRIBUTE_NAME)
  private String attributeName;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  @JsonbProperty(JSON_REQUEST_AS_STRING)
  private String requestAsString;

  @JsonbProperty(JSON_VALUES_COUNT_AS_STRING)
  private String valuesCountAsString;

  @JsonbProperty(JSON_SELECTORS_COUNT_AS_STRING)
  private String selectorsCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSourceValeur";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "sourceValeurChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "source de valeur";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "sources de valeur";
}
