package ci.gouv.dgbf.system.report.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ReportGroupDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-04T18:38:29+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ReportGroupRequestMapperImpl implements ReportGroupRequestMapper {

    @Override
    public ReportGroupService.ReportGroupCreateRequestDto mapCreate(ReportGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportGroupService.ReportGroupCreateRequestDto reportGroupCreateRequestDto = new ReportGroupService.ReportGroupCreateRequestDto();

        reportGroupCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        reportGroupCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        reportGroupCreateRequestDto.setReportIdentifier( arg0.getReportIdentifier() );
        reportGroupCreateRequestDto.setReportsGroupIdentifier( arg0.getReportsGroupIdentifier() );

        return reportGroupCreateRequestDto;
    }

    @Override
    public ReportGroupService.ReportGroupUpdateRequestDto mapUpdate(ReportGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportGroupService.ReportGroupUpdateRequestDto reportGroupUpdateRequestDto = new ReportGroupService.ReportGroupUpdateRequestDto();

        reportGroupUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        reportGroupUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        reportGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        reportGroupUpdateRequestDto.setReportIdentifier( arg0.getReportIdentifier() );
        reportGroupUpdateRequestDto.setReportsGroupIdentifier( arg0.getReportsGroupIdentifier() );

        return reportGroupUpdateRequestDto;
    }
}
