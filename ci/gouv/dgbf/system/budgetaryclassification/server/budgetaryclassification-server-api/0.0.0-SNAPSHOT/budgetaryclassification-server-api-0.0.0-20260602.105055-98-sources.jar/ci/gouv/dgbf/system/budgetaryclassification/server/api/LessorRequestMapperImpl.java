package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link LessorDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-02T10:51:22+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class LessorRequestMapperImpl implements LessorRequestMapper {

    @Override
    public LessorService.LessorCreateRequestDto mapCreate(LessorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LessorService.LessorCreateRequestDto lessorCreateRequestDto = new LessorService.LessorCreateRequestDto();

        lessorCreateRequestDto.setCode( arg0.getCode() );
        lessorCreateRequestDto.setName( arg0.getName() );

        return lessorCreateRequestDto;
    }

    @Override
    public LessorService.LessorUpdateRequestDto mapUpdate(LessorDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        LessorService.LessorUpdateRequestDto lessorUpdateRequestDto = new LessorService.LessorUpdateRequestDto();

        lessorUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        lessorUpdateRequestDto.setCode( arg0.getCode() );
        lessorUpdateRequestDto.setName( arg0.getName() );

        return lessorUpdateRequestDto;
    }
}
