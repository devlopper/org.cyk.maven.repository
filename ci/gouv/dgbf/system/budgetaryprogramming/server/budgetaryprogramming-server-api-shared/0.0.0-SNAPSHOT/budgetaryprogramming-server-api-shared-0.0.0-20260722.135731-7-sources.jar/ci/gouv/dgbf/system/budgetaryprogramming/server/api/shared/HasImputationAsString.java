package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * d'imputation.
 *
 * @author Christian
 */
public interface HasImputationAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'imputation.
   *
   * @return représentation en chaine de caractères de l'imputation
   */
  String getImputationAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'imputation.
   *
   * @param asString représentation en chaine de caractères de l'imputation
   */
  void setImputationAsString(String asString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'imputation.
   */
  String FIELD_IMPUTATION_AS_STRING = "imputationAsString";
}
