package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasEmailAddressDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityAsStringDto;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une adresse email d'identité.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityEmailAddressDto extends AbstractIdentifiableAuditableDto implements
    HasIdentityIdentifierDto, HasIdentityAsStringDto, HasEmailAddressDto, HasStatusAsStringDto {

  @JsonbProperty(JSON_IDENTITY_IDENTIFIER)
  private String identityIdentifier;

  @JsonbProperty(JSON_IDENTITY_AS_STRING)
  private String identityAsString;

  @JsonbProperty(JSON_EMAIL_ADDRESS)
  private String emailAddress;

  @JsonbProperty(JSON_STATUS)
  private IdentityEmailAddressStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant JSON de {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "adresse email d'identité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "adresses email d'identité";
}
