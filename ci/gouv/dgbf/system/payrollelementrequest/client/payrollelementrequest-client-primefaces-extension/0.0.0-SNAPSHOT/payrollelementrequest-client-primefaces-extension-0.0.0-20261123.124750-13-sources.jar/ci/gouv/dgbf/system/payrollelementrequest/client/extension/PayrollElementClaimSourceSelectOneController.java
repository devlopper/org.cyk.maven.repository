package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimDto;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente le contrôleur de sélection de la source d'une Réclamation
 * (référentiel {@code TR_SOURCE_RECLAMATION}) -- utilisé en filtre (prise en charge, écrans de
 * traitement), jamais en saisie : la source est entièrement déduite à la création.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementClaimSourceSelectOneController extends AbstractSelectOneController {

  protected PayrollElementClaimSourceSelectOneController() {
    outputLableValue = "Source";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem(PayrollElementClaimDto.SOURCE_FAE, "FAE"),
        new SelectItem(PayrollElementClaimDto.SOURCE_AUTHORIZED_THIRD_PARTY, "Tiers habilité"),
        new SelectItem(PayrollElementClaimDto.SOURCE_FUR, "FUR"));
  }

  /**
   * Cette méthode permet d'obtenir le libellé correspondant à une valeur.
   *
   * @param value valeur
   * @return libellé, ou la valeur elle-même si aucune correspondance
   */
  public String labelOf(String value) {
    return computeSelectItemsWhenChoicable().stream()
        .filter(item -> Objects.equals(item.getValue(), value)).map(SelectItem::getLabel)
        .findFirst().orElse(value);
  }
}
