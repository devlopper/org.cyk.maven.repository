package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * Cette classe représente les codes de {@link AdministrativeUnitEmployeeStatus}.
 *
 * @author Christian
 *
 */
public class AdministrativeUnitEmployeeStatusCode {

  private AdministrativeUnitEmployeeStatusCode() {

  }

  /**
   * Entrant.
   */
  public static final String INCOMING = "ENTRANT";

  /**
   * Présent.
   */
  public static final String PRESENT = "PRESENT";

  /**
   * Sortant.
   */
  public static final String OUTGOING = "SORTANT";
}
