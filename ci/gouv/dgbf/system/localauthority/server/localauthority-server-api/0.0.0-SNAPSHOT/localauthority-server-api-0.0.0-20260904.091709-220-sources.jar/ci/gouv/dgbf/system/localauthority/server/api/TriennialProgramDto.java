package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.localauthority.server.api.TriennialProgramService.TriennialProgramStatusUpdateResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un programme triennal.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TriennialProgramDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /**
   * Année {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_YEAR)
  private Integer exerciseYear;

  /**
   * Représentation en chaine de caractères de l'exercice budgétaire.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /**
   * Identifiant {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Code {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_CODE)
  private String localAuthorityCode;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;

  /**
   * Représentation en chaine de caractères du nombre d'activités.
   */
  @JsonbProperty(JSON_ACTIVITY_COUNT_AS_STRING)
  private String activityCountAsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT1_AS_STRING)
  private String totalFundingAmount1AsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT2_AS_STRING)
  private String totalFundingAmount2AsString;

  /**
   * Représentation en chaine de caractères du total des financements en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT3_AS_STRING)
  private String totalFundingAmount3AsString;


  /**
   * Représentation en chaine de caractères la somme des totaux des financements
   * des montants n, n+1 et n+2.
   */
  @JsonbProperty(JSON_TOTAL_FUNDING_AMOUNT_AS_STRING)
  private String totalFundingAmountAsString;

  /**
   * Représentation en chaine de caractères du nombre d'actions.
   */
  @JsonbProperty(JSON_ACTION_COUNT_AS_STRING)
  private String actionCountAsString;

  /**
   * Représentation en chaine de caractères du total des financements des actions en année N.
   */
  @JsonbProperty(JSON_TOTAL_ACTION_FUNDING_AMOUNT1_AS_STRING)
  private String totalActionFundingAmount1AsString;

  /**
   * Représentation en chaine de caractères du total des financements des actions en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_ACTION_FUNDING_AMOUNT2_AS_STRING)
  private String totalActionFundingAmount2AsString;

  /**
   * Représentation en chaine de caractères du total des financements des actions en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_ACTION_FUNDING_AMOUNT3_AS_STRING)
  private String totalActionFundingAmount3AsString;


  /**
   * Représentation en chaine de caractères la sommes des totaux des financements
   * des années n , n+1 et n+2.
   */
  @JsonbProperty(JSON_TOTAL_ACTION_FUNDING_AMOUNT_AS_STRING)
  private String totalActionFundingAmountAsString;

  /**
   * Représentation en chaine de caractères du nombre d'opérations.
   */
  @JsonbProperty(JSON_OPERATION_COUNT_AS_STRING)
  private String operationCountAsString;

  /**
   * Représentation en chaine de caractères du total des financements des opérations en année N.
   */
  @JsonbProperty(JSON_TOTAL_OPERATION_FUNDING_AMOUNT1_AS_STRING)
  private String totalOperationFundingAmount1AsString;

  /**
   * Représentation en chaine de caractères du total des financements des opérations en année N + 1.
   */
  @JsonbProperty(JSON_TOTAL_OPERATION_FUNDING_AMOUNT2_AS_STRING)
  private String totalOperationFundingAmount2AsString;

  /**
   * Représentation en chaine de caractères du total des financements des opérations en année N + 2.
   */
  @JsonbProperty(JSON_TOTAL_OPERATION_FUNDING_AMOUNT3_AS_STRING)
  private String totalOperationFundingAmount3AsString;


  /**
   * Représentation en chaine de caractères la sommes des totaux des financements des
   * montants n, n+1 et n+2.
   */
  @JsonbProperty(JSON_TOTAL_OPERATION_FUNDING_AMOUNT_AS_STRING)
  private String totalOperationFundingAmountAsString;

  /**
   * Statut du programme triennal.
   */
  @JsonbProperty(JSON_STATUS)
  private TriennialProgramStatus status;


  /**
   * Statut du programme triennal au format chaine de caractère.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Numéro d'approbation du programme triennal au format chaine de caractère.
   */
  @JsonbProperty(JSON_APPROVAL_NUMBER)
  private String approvalNumber;

  /**
   * Date d'approbation metier {@link TriennialProgramDto}.
   */
  @JsonbProperty(JSON_BUSINESS_APPROVAL_DATE)
  private LocalDate businessApprovalDate;

  /**
   * Identifiant du groupe de fichier.
   */
  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  /**
   * Montant maximum action.
   */
  @JsonbProperty(JSON_MAX_ACTION_AMOUNT)
  private Long maxActionAmount;

  /**
   * Représentation en chaine de caractères du montant maximum action.
   */
  @JsonbProperty(JSON_MAX_ACTION_AMOUNT_AS_STRING)
  private String maxActionAmountAsString;

  /**
   * Montant maximum opération.
   */
  @JsonbProperty(JSON_MAX_OPERATION_AMOUNT)
  private Long maxOperationAmount;

  /**
   * Représentation en chaine de caractères du montant maximum opération.
   */
  @JsonbProperty(JSON_MAX_OPERATION_AMOUNT_AS_STRING)
  private String maxOperationAmountAsString;

  /**
   * Transmittable.
   */
  @JsonbProperty(JSON_TRANSMITABLE)
  private Boolean transmitable;

  /**
   * Acceptable.
   */
  @JsonbProperty(JSON_ACCEPTABLE)
  private Boolean acceptable;

  /**
   * Retournable.
   */
  @JsonbProperty(JSON_RETURNABLE)
  private Boolean returnable;

  /**
   * Approuvable.
   */
  @JsonbProperty(JSON_APPROVABLE)
  private Boolean approvable;

  /**
   * Raison du statut.
   */
  @JsonbProperty(JSON_STATUS_REASON)
  private String statusReason;

  /**
   * Auteur de la création du programme triennal.
   */
  @JsonbProperty(JSON_CREATED_BY)
  private String createdBy;


  /**
   * Auteur de la modification du programme triennal.
   */
  @JsonbProperty(JSON_UPDATED_BY)
  private String updatedBy;

  /**
   * Date de transmission du programme triennal.
   */
  @JsonbProperty(JSON_TRANSMITTED_DATE_AS_STRING)
  private String transmittedDateAsString;


  /**
   * Auteur de la transmission du programme triennal.
   */
  @JsonbProperty(JSON_TRANSMITTED_BY)
  private String transmittedBy;


  /**
   * Date de retour du programme triennal.
   */
  @JsonbProperty(JSON_RETURNED_DATE_AS_STRING)
  private String returnedDateAsString;


  /**
   * Auteur du retour du programme triennal.
   */
  @JsonbProperty(JSON_RETURNED_BY)
  private String returnedBy;


  /**
   * Date d'acceptation du programme triennal.
   */
  @JsonbProperty(JSON_ACCEPTED_DATE_AS_STRING)
  private String acceptedDateAsString;


  /**
   * Auteur de l'acceptation du programme triennal.
   */
  @JsonbProperty(JSON_ACCEPTED_BY)
  private String acceptedBy;


  /**
   * Date d'approbation du programme triennal.
   */
  @JsonbProperty(JSON_APPROVED_DATE_AS_STRING)
  private String approvedDateAsString;


  /**
   * Auteur de l'acceptation du programme triennal.
   */
  @JsonbProperty(JSON_APPROVED_BY)
  private String approvedBy;


  /**
   * Cette méthode permet de copier à partir d'une réponse de changement de statut.
   *
   * @param statusUpdateResponse {@link TriennialProgramStatusUpdateResponseDto}
   */
  public void copy(TriennialProgramStatusUpdateResponseDto statusUpdateResponse) {
    status = statusUpdateResponse.getStatus();
    statusAsString = statusUpdateResponse.getStatusAsString();
    statusReason = statusUpdateResponse.getReason();
    transmitable = statusUpdateResponse.getTransmitable();
    acceptable = statusUpdateResponse.getAcceptable();
    approvable = statusUpdateResponse.getApprovable();
    returnable = statusUpdateResponse.getReturnable();
  }

  /**
   * Identifiant json de identifiant de {@link TriennialProgramDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idProgrammeTriennal";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link TriennialProgramDto}.
   */
  public static final String JSON_THIS_AS_STRING = "programmeTriennalChaine";

  /**
   * Identifiant json {@link #exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = ExerciseDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #exerciseYear}.
   */
  public static final String JSON_EXERCISE_YEAR = ExerciseDto.JSON_THIS_YEAR;

  /**
   * Identifiant json {@link #exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = ExerciseDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityCode}.
   */
  public static final String JSON_LOCAL_AUTHORITY_CODE = LocalAuthorityDto.JSON_THIS_CODE;

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";


  /**
   * Identifiant json champ {@link #approvalNumber}.
   */
  public static final String JSON_APPROVAL_NUMBER = "numeroApprobation";


  /**
   * Identitiant json {@link TriennialProgramDto#businessApprovalDate}.
   */
  public static final String JSON_BUSINESS_APPROVAL_DATE = "dateApprobationMetier";

  /**
   * Identifiant json champ {@link #filesGroupIdentifier}.
   */
  public static final String JSON_FILES_GROUP_IDENTIFIER = "identifiantGroupeFichier";

  /**
   * Identifiant json {@link #maxActionAmount}.
   */
  public static final String JSON_MAX_ACTION_AMOUNT = "montantMaxAction";

  /**
   * Identifiant json {@link #maxActionAmountAsString}.
   */
  public static final String JSON_MAX_ACTION_AMOUNT_AS_STRING = "montantMaxActionChaine";

  /**
   * Identifiant json {@link #maxOperationAmount}.
   */
  public static final String JSON_MAX_OPERATION_AMOUNT = "montantMaxOperation";

  /**
   * Identifiant json {@link #maxOperationAmountAsString}.
   */
  public static final String JSON_MAX_OPERATION_AMOUNT_AS_STRING = "montantMaxOperationChaine";

  /**
   * Identifiant json champ {@link #activityCountAsString}.
   */
  public static final String JSON_ACTIVITY_COUNT_AS_STRING = "nombreActiviteChaine";

  /**
   * Identifiant json champ {@link #actionCountAsString}.
   */
  public static final String JSON_ACTION_COUNT_AS_STRING = "nombreActionChaine";

  /**
   * Identifiant json champ {@link #totalFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT1_AS_STRING = "totalFinancementMontant1";

  /**
   * Identifiant json champ {@link #totalFundingAmount2AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT2_AS_STRING = "totalFinancementMontant2";

  /**
   * Identifiant json champ {@link #totalFundingAmount3AsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT3_AS_STRING = "totalFinancementMontant3";


  /**
   * Identifiant json champ {@link #totalFundingAmountAsString}.
   */
  public static final String JSON_TOTAL_FUNDING_AMOUNT_AS_STRING =
      "totalMontantFinancementChaine";

  /**
   * Identifiant json champ {@link #totalActionFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_ACTION_FUNDING_AMOUNT1_AS_STRING =
      "totalFinancementActionMontant1";

  /**
   * Identifiant json champ {@link #totalActionFundingAmount2AsString}.
   */
  public static final String JSON_TOTAL_ACTION_FUNDING_AMOUNT2_AS_STRING =
      "totalFinancementActionMontant2";

  /**
   * Identifiant json champ {@link #totalActionFundingAmount3AsString}.
   */
  public static final String JSON_TOTAL_ACTION_FUNDING_AMOUNT3_AS_STRING =
      "totalFinancementActionMontant3";


  /**
   * Identifiant json champ {@link #totalActionFundingAmountAsString}.
   */
  public static final String JSON_TOTAL_ACTION_FUNDING_AMOUNT_AS_STRING =
      "totalMontantFinancementActionChaine";



  /**
   * Identifiant json champ {@link #operationCountAsString}.
   */
  public static final String JSON_OPERATION_COUNT_AS_STRING = "nombreOperationChaine";

  /**
   * Identifiant json champ {@link #totalOperationFundingAmount1AsString}.
   */
  public static final String JSON_TOTAL_OPERATION_FUNDING_AMOUNT1_AS_STRING =
      "totalFinancementOperationMontant1";

  /**
   * Identifiant json champ {@link #totalOperationFundingAmount2AsString}.
   */
  public static final String JSON_TOTAL_OPERATION_FUNDING_AMOUNT2_AS_STRING =
      "totalFinancementOperationMontant2";

  /**
   * Identifiant json champ {@link #totalOperationFundingAmount3AsString}.
   */
  public static final String JSON_TOTAL_OPERATION_FUNDING_AMOUNT3_AS_STRING =
      "totalFinancementOperationMontant3";


  /**
   * Identifiant json champ {@link #totalOperationFundingAmountAsString}.
   */
  public static final String JSON_TOTAL_OPERATION_FUNDING_AMOUNT_AS_STRING =
      "totalMontantFinancementOperationChaine";

  /**
   * Identifiant json champ {@link #acceptable}.
   */
  public static final String JSON_ACCEPTABLE = "acceptable";

  /**
   * Identifiant json champ {@link #transmitable}.
   */
  public static final String JSON_TRANSMITABLE = "transmettable";

  /**
   * Identifiant json champ {@link #returnable}.
   */
  public static final String JSON_RETURNABLE = "retournable";

  /**
   * Identifiant json champ {@link #approvable}.
   */
  public static final String JSON_APPROVABLE = "approuvable";

  /**
   * Identifiant json champ {@link #statusReason}.
   */
  public static final String JSON_STATUS_REASON = "raisonStatut";

  /**
   * Identifiant json champ {@link #transmittedDateAsString}.
   */
  public static final String JSON_TRANSMITTED_DATE_AS_STRING = "dateTransmissionChaine";

  /**
   * Identifiant json champ {@link #transmittedBy}.
   */
  public static final String JSON_TRANSMITTED_BY = "acteurTransmissionChaine";

  /**
   * Identifiant json champ {@link #createdBy}.
   */
  public static final String JSON_CREATED_BY = "acteurCreationChaine";

  /**
   * Identifiant json champ {@link #updatedBy}.
   */
  public static final String JSON_UPDATED_BY = "acteurModificationChaine";


  /**
   * Identifiant json champ {@link #returnedDateAsString}.
   */
  public static final String JSON_RETURNED_DATE_AS_STRING = "dateRetourChaine";

  /**
   * Identifiant json champ {@link #returnedBy}.
   */
  public static final String JSON_RETURNED_BY = "acteurRetourChaine";


  /**
   * Identifiant json champ {@link #acceptedDateAsString}.
   */
  public static final String JSON_ACCEPTED_DATE_AS_STRING = "dateAcceptationChaine";

  /**
   * Identifiant json champ {@link #acceptedBy}.
   */
  public static final String JSON_ACCEPTED_BY = "acteurAcceptationChaine";


  /**
   * Identifiant json champ {@link #approvedDateAsString}.
   */
  public static final String JSON_APPROVED_DATE_AS_STRING = "dateApprobationChaine";

  /**
   * Identifiant json champ {@link #approvedBy}.
   */
  public static final String JSON_APPROVED_BY = "acteurApprobationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "programme triennal";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "programmes triennaux";
}
