package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.Executor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCalculateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCalculateResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCreatePayslipsRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCreatePayslipsResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollGetManyResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollStartCalculationRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollStartCalculationResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.PayrollUpdateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollService.ProcessResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link PayrollService}.
 *
 * @author A.K.M
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollClient extends AbstractClient<PayrollService>
    implements GetByIdentifier<PayrollDto>, GetMany<PayrollGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public PayrollClient service(PayrollService service) {
    return (PayrollClient) super.service(service);
  }

  /**
   * {@link PayrollService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(PayrollCreateRequestDto request) {
    return new CreateExecutor(PayrollService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link PayrollService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<PayrollGetManyResponseDto>(PayrollGetManyResponseDto.class,
        PayrollService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<PayrollDto>(PayrollDto.class, PayrollService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link PayrollService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link PayrollService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public PayrollDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollDto>(PayrollDto.class,
        PayrollService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link PayrollService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public PayrollDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link PayrollService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(PayrollUpdateRequestDto request) {
    return new IdentifiableExecutor(PayrollService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link PayrollService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(PayrollService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link PayrollService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link PayrollService#createPayslips}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollCreatePayslipsResponseDto createPayslips(PayrollCreatePayslipsRequestDto request) {
    return new GetOneExecutor<PayrollCreatePayslipsResponseDto>(
        PayrollCreatePayslipsResponseDto.class, PayrollService.CREATE_PAYSLIPS_IDENTIFIER)
            .execute(() -> service().createPayslips(request));
  }

  /**
   * {@link PayrollService#startCalculation}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollStartCalculationResponseDto startCalculation(
      PayrollStartCalculationRequestDto request) {
    return new GetOneExecutor<PayrollStartCalculationResponseDto>(
        PayrollStartCalculationResponseDto.class, PayrollService.START_CALCULATION_IDENTIFIER)
            .execute(() -> service().startCalculation(request));
  }

  /**
   * {@link PayrollService#calculate}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollCalculateResponseDto calculate(PayrollCalculateRequestDto request) {
    return new GetOneExecutor<PayrollCalculateResponseDto>(PayrollCalculateResponseDto.class,
        PayrollService.CREATE_PAYSLIPS_IDENTIFIER).execute(() -> service().calculate(request));
  }

  /**
   * {@link PayrollService#startInitialization}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto startInitialization(ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.START_INITIALIZATION_IDENTIFIER)
        .execute(() -> service().startInitialization(request));
  }

  /**
   * {@link PayrollService#initialize}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto initialize(ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.INITIALIZE_IDENTIFIER)
        .execute(() -> service().initialize(request));
  }

  /**
   * {@link PayrollService#resumeInitializationFromCheckpoint}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto resumeInitializationFromCheckpoint(
      ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.RESUME_INITIALIZATION_FROM_CHECKPOINT_IDENTIFIER)
        .execute(() -> service().resumeInitializationFromCheckpoint(request));
  }

  /**
   * {@link PayrollService#transmitForControl}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto transmitForControl(ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.TRANSMIT_FOR_CONTROL_IDENTIFIER)
        .execute(() -> service().transmitForControl(request));
  }

  /**
   * {@link PayrollService#control}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto control(ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.CONTROL_IDENTIFIER)
        .execute(() -> service().control(request));
  }

  /**
   * {@link PayrollService#transmitForArbitration}.
   *
   * @param request requête
   * @return réponse
   */
  public ProcessResponseDto transmitForArbitration(ByIdentifierRequestDto request) {
    return new ProcessExecutor(PayrollService.TRANSMIT_FOR_ARBITRATION_IDENTIFIER)
        .execute(() -> service().transmitForArbitration(request));
  }

  /**
   * Cette classe représente un exécuteur de {@link PayrollDto}.
   *
   * @author Christian
   *
   */
  public class ProcessExecutor extends Executor<ProcessResponseDto> {

    /**
     * Cette méthode permet d'instancier.
     *
     * @param identifier identifiant
     */
    public ProcessExecutor(String identifier) {
      super(ProcessResponseDto.class, identifier);
    }

  }
}
