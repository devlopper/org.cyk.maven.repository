package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.UserService.UserAssignRolesRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserAssignRolesResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateAccountRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateForFunctionaryRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateForNonFunctionaryRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserService.UserUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link UserService}.
 *
 * @author Christian
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class UserClient extends AbstractClient<UserService> implements GetByIdentifier<UserDto>,
    GetMany<UserGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public UserClient service(UserService service) {
    return (UserClient) super.service(service);
  }

  /**
   * {@link UserService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(UserCreateRequestDto request) {
    return new CreateExecutor(UserService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link UserService#createAccount}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto createAccount(UserCreateAccountRequestDto request) {
    return new IdentifiableExecutor(UserService.CREATE_ACCOUNT_IDENTIFIER)
        .setExpectedResponseStatusCode(Response.Status.CREATED.getStatusCode())
        .execute(() -> service().createAccount(request));
  }

  /**
   * {@link UserService#createForFunctionary}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createForFunctionary(UserCreateForFunctionaryRequestDto request) {
    return new CreateExecutor(UserService.CREATE_FOR_FUNCTIONARY_IDENTIFIER)
        .execute(() -> service().createForFunctionary(request));
  }

  /**
   * {@link UserService#createForNonFunctionary}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto createForNonFunctionary(UserCreateForNonFunctionaryRequestDto request) {
    return new CreateExecutor(UserService.CREATE_FOR_NON_FUNCTIONARY_IDENTIFIER)
        .execute(() -> service().createForNonFunctionary(request));
  }

  /**
   * {@link UserService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public UserGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<UserGetManyResponseDto>(UserGetManyResponseDto.class,
        UserService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link UserService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
                                        String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link UserService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public UserDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<UserDto>(UserDto.class, UserService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link UserService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public UserDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                        String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link UserService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public UserDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<UserDto>(UserDto.class, UserService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link UserService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
                                 String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link UserService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(UserUpdateRequestDto request) {
    return new IdentifiableExecutor(UserService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link UserService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(UserService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link UserService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link UserService#assignRoles}.
   *
   * @param request requête
   * @return réponse
   */
  public UserAssignRolesResponseDto assignRoles(UserAssignRolesRequestDto request) {
    return new GetOneExecutor<UserService.UserAssignRolesResponseDto>(UserService
        .UserAssignRolesResponseDto.class,
        UserService.ASSIGN_ROLES_IDENTIFIER).execute(() -> service().assignRoles(request));
  }

  /**
   * {@link UserService#revokeRoles}.
   *
   * @param request requête
   * @return réponse
   */
  public UserService.UserRevokeRolesResponseDto revokeRoles(
      UserService.UserRevokeRolesRequestDto request) {
    return new GetOneExecutor<UserService.UserRevokeRolesResponseDto>(
        UserService.UserRevokeRolesResponseDto.class,
        UserService.REVOKE_ROLES_IDENTIFIER).execute(() -> service().revokeRoles(request));
  }

}
