package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de documentation.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class DocumentationFilter extends AbstractIdentifiableFilter {

  /**
   * Cette méthode permet d'instancier.
   *
   * @param filter {@link FilterDto}
   */
  public DocumentationFilter(FilterDto filter) {
    super(filter);
  }

  /**
   * Cette méthode permet d'instancier.
   */
  public DocumentationFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
  }
}
