package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateNDto extends HasRemainingAmountToIntegrateN {

  /**
   * Identifiant json du montant restant à intégrer pour l'année N.
   */
  String JSON_REMAINING_AMOUNT_TO_INTEGRATE_N = "montantResteAIntegrerN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName