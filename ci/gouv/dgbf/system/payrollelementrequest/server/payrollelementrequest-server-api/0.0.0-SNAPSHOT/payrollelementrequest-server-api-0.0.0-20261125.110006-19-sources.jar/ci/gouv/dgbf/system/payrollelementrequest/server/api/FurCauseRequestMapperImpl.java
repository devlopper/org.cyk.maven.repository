package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FurCauseDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-25T11:00:24+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FurCauseRequestMapperImpl implements FurCauseRequestMapper {

    @Override
    public FurCauseService.FurCauseCreateRequestDto mapCreate(FurCauseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurCauseService.FurCauseCreateRequestDto furCauseCreateRequestDto = new FurCauseService.FurCauseCreateRequestDto();

        furCauseCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        furCauseCreateRequestDto.setCode( arg0.getCode() );
        furCauseCreateRequestDto.setName( arg0.getName() );
        furCauseCreateRequestDto.setReason( arg0.getReason() );
        furCauseCreateRequestDto.setSetAside( arg0.getSetAside() );
        furCauseCreateRequestDto.setAdvice( arg0.getAdvice() );
        furCauseCreateRequestDto.setForceable( arg0.getForceable() );

        return furCauseCreateRequestDto;
    }

    @Override
    public FurCauseService.FurCauseUpdateRequestDto mapUpdate(FurCauseDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FurCauseService.FurCauseUpdateRequestDto furCauseUpdateRequestDto = new FurCauseService.FurCauseUpdateRequestDto();

        furCauseUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        furCauseUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        furCauseUpdateRequestDto.setCode( arg0.getCode() );
        furCauseUpdateRequestDto.setName( arg0.getName() );
        furCauseUpdateRequestDto.setReason( arg0.getReason() );
        furCauseUpdateRequestDto.setSetAside( arg0.getSetAside() );
        furCauseUpdateRequestDto.setAdvice( arg0.getAdvice() );
        furCauseUpdateRequestDto.setForceable( arg0.getForceable() );

        return furCauseUpdateRequestDto;
    }
}
