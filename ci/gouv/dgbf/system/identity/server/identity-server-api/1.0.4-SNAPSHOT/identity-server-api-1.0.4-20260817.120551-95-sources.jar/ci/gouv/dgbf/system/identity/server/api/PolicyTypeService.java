package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link PolicyTypeDto}.
 *
 * @author Desysoft
 *
 */
@Path(value = PolicyTypeService.PATH)
@Tag(name = "Gestion des Types de Politique")
public interface PolicyTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "types-politique";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface PolicyTypeSaveRequestDto {

  }

  /**
   * Identifiant du service de création unitaire de {@link PolicyTypeDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_TYPE_POLITIQUE";

  /**
   * Chemin du service de création unitaire de {@link PolicyTypeDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER, summary = "Création d'un type de politique",
      description = "Ce service permet de créer un type de politique")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(PolicyTypeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link PolicyTypeDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyTypeCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements PolicyTypeSaveRequestDto {

  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link PolicyTypeDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TYPE_POLITIQUE";

  /**
   * Chemin du service d'obtention de plusieurs {@link PolicyTypeDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      description = "Ce service permet d'obtenir plusieurs types de politique")
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link PolicyTypeDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  public static class PolicyTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<PolicyTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<PolicyTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link PolicyTypeDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_TYPE_POLITIQUE";

  /**
   * Chemin du service d'obtention unitaire de {@link PolicyTypeDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER,
      description = "Ce service permet d'obtenir un type de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyTypeDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link PolicyTypeDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_TYPE_POLITIQUE";

  /**
   * Chemin du service d'obtention par identifiant de {@link PolicyTypeDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER,
      description = "Ce service permet d'obtenir par identifiant un type de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = PolicyTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link PolicyTypeDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_TYPE_POLITIQUE";

  /**
   * Chemin du service de mise à jour unitaire de {@link PolicyTypeDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER,
      description = "Ce service permet de mettre à jour un type de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(PolicyTypeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link PolicyTypeDto}.
   *
   * @author Desysoft
   *
   */
  @Getter
  @Setter
  class PolicyTypeUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements PolicyTypeSaveRequestDto {

  }

  /**
   * Identifiant du service de suppression unitaire de {@link PolicyTypeDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_TYPE_POLITIQUE";

  /**
   * Chemin du service de suppression unitaire de {@link PolicyTypeDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link PolicyTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      description = "Ce service permet de supprimer un type de politique")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
