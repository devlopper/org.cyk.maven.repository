package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link RepresentationFunctionTypeDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:47:46+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class RepresentationFunctionTypeRequestMapperImpl implements RepresentationFunctionTypeRequestMapper {

    @Override
    public RepresentationFunctionTypeService.RepresentationFunctionTypeCreateRequestDto mapCreate(RepresentationFunctionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationFunctionTypeService.RepresentationFunctionTypeCreateRequestDto representationFunctionTypeCreateRequestDto = new RepresentationFunctionTypeService.RepresentationFunctionTypeCreateRequestDto();

        representationFunctionTypeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationFunctionTypeCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        representationFunctionTypeCreateRequestDto.setFunctionTypeIdentifier( arg0.getFunctionTypeIdentifier() );
        representationFunctionTypeCreateRequestDto.setRepresentationIdentifier( arg0.getRepresentationIdentifier() );

        return representationFunctionTypeCreateRequestDto;
    }

    @Override
    public RepresentationFunctionTypeService.RepresentationFunctionTypeUpdateRequestDto mapUpdate(RepresentationFunctionTypeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        RepresentationFunctionTypeService.RepresentationFunctionTypeUpdateRequestDto representationFunctionTypeUpdateRequestDto = new RepresentationFunctionTypeService.RepresentationFunctionTypeUpdateRequestDto();

        representationFunctionTypeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        representationFunctionTypeUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        representationFunctionTypeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        representationFunctionTypeUpdateRequestDto.setFunctionTypeIdentifier( arg0.getFunctionTypeIdentifier() );
        representationFunctionTypeUpdateRequestDto.setRepresentationIdentifier( arg0.getRepresentationIdentifier() );

        return representationFunctionTypeUpdateRequestDto;
    }
}
