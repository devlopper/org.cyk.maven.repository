package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à intégrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToIntegrateN2AsStringDto
    extends HasRemainingAmountToIntegrateN2AsString {

  /**
   * Identifiant json du montant restant à intégrer pour l'année N+2,
   * sous forme de chaîne de caractères.
   */
  String JSON_REMAINING_AMOUNT_TO_INTEGRATE_N2_AS_STRING =
      "montantResteAIntegrerN2Chaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName