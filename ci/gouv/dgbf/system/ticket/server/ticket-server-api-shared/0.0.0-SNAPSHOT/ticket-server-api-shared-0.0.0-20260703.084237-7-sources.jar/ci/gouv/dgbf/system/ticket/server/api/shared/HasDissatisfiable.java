package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être insatisfait.
 *
 * @author Christian
 */
public interface HasDissatisfiable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être insatisfait.
   *
   * @return peut être insatisfait
   */
  Boolean getDissatisfiable();

  /**
   * Cette méthode permet d'assigner peut être insatisfait.
   *
   * @param dissatisfiable peut être insatisfait
   */
  void setDissatisfiable(Boolean dissatisfiable);

  /**
   * Identifiant java de peut être insatisfait.
   */
  String FIELD_DISSATISFIABLE = "dissatisfiable";
}