package ci.gouv.dgbf.extension.primefaces.component;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.StringCore;
import ci.gouv.dgbf.extension.core.enumeration.BusinessValueType;
import ci.gouv.dgbf.extension.core.segregation.HasCode;
import ci.gouv.dgbf.extension.core.segregation.HasName;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.Ajax;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.faces.component.UIInput;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente une colonne.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class Column extends AbstractWidget {

  String headerText;
  Function<Column, String> headerTextGeneratorFunction;
  String headerTextSuffix;

  String footerText;
  Supplier<String> footerTextSupplier;

  String width;
  boolean exportable;
  boolean visible;

  BusinessValueType businessValueType;

  DataTable dataTable;

  String fieldName;
  /* Identite : libelle (fieldName) en titre, code en sous-ligne, puis details. */
  String codeFieldName;
  Integer lines;
  ColumnType type;
  List<ColumnDetail> details;

  /* Filter */

  String filterBy;

  String filterMatchMode;

  String filterPlaceholder;

  /* Edit */

  Function<Object, Boolean> isCellEditableFunction;
  Ajax cellEditAjax;
  String editableFieldName;
  Function<Object, Object> updateRequestBuilderFunction;
  Function<Object, IdentifiableResponseDto> updateRequestConsumerFunction;
  Consumer<IdentifiableResponseDto> updateResponseConsumer;

  /**
   * Cette méthode permet de construire.
   */
  public Column() {
    lines = 2;
    exportable = true;
    visible = true;
    isCellEditableFunction = o -> false;

    headerTextGeneratorFunction =
        column -> StringCore.isBlank(column.headerText)
            ? column.businessValueType.getName()
                + StringCore.getOrDefaultToEmptyIfNull(headerTextSuffix)
            : column.headerText;
  }

  /**
   * Cette méthode permet de typer la colonne : son type et sa classe de style.
   *
   * @param type type
   * @return this
   */
  public Column typed(ColumnType type) {
    this.type = type;
    addStyleClass(type.getStyleClass());
    return this;
  }

  public Column writeHeaderText(String headerText) {
    this.headerText = headerText;
    return this;
  }

  public Column writeFooterText(String footerText) {
    this.footerText = footerText;
    return this;
  }

  public Column computeWithForButtonsWithIconOnly(int count) {
    width = (count * 50) + "px";
    return this;
  }

  /**
   * Cette méthode permet d'initialiser.
   *
   */
  public void initialize() {
    if (BusinessValueType.isNumber(businessValueType)) {
      initializeAsBusinessValueType();
    }
    supplyFooterText();
  }

  /**
   * Initialiser.
   *
   * @return this
   */
  public Column initializeAsAmount() {
    businessValueType = BusinessValueType.AMOUNT;
    initialize();
    return this;
  }

  /**
   * Cette méthode permet d'initialiser comme une colonne de code métier.
   *
   * @return this
   */
  public Column initializeAsCode() {
    Core.runIfStringBlank(headerText, () -> headerText = "Code");
    Core.runIfStringBlank(fieldName, () -> fieldName = HasCode.FIELD_CODE);
    Core.runIfStringBlank(width, () -> width = "70px");
    typed(ColumnType.CODE);
    return this;
  }

  /**
   * Cette méthode permet d'initialiser comme une colonne de libellé métier.
   *
   * @return this
   */
  public Column initializeAsName() {
    Core.runIfStringBlank(headerText, () -> headerText = "Libellé");
    Core.runIfStringBlank(fieldName, () -> fieldName = HasName.FIELD_NAME);
    typed(ColumnType.TEXT);
    return this;
  }

  /**
   * Cette méthode permet d'initialiser comme une colonne d'identité : le libellé en titre (sur
   * {@link #lines} lignes au plus), puis le code et les {@link #details} en sous-ligne.
   *
   * @return this
   */
  public Column initializeAsIdentity() {
    Core.runIfStringBlank(headerText, () -> headerText = "Code · Libellé");
    Core.runIfStringBlank(fieldName, () -> fieldName = HasName.FIELD_NAME);
    Core.runIfStringBlank(codeFieldName, () -> codeFieldName = HasCode.FIELD_CODE);
    typed(ColumnType.IDENTITY);
    return this;
  }

  /**
   * Cette méthode permet d'ajouter une information secondaire à l'identité.
   *
   * @param detail information
   * @return this
   */
  public Column addDetail(ColumnDetail detail) {
    Core.runIfNull(details, () -> details = new ArrayList<>());
    details.add(detail);
    return this;
  }

  /**
   * Cette méthode permet d'initialiser comme une colonne de date.
   *
   * @return this
   */
  public Column initializeAsDate() {
    Core.runIfStringBlank(headerText, () -> headerText = "Date");
    typed(ColumnType.DATE);
    return this;
  }

  /**
   * Cette méthode permet d'initialiser comme une colonne de valeur métier.
   *
   * @return this
   */
  public Column initializeAsBusinessValueType() {
    headerText = Core.applyFunction(headerTextGeneratorFunction, this);
    Core.runIfStringBlank(fieldName, () -> fieldName = businessValueType.getAsStringFieldName());
    Core.runIfStringBlank(width, () -> width = "150px");
    typed(ColumnType.NUMBER);
    addStyleClass("column-%s".formatted(businessValueType.getValueFieldName()));
    initializeCellEditAjax();
    return this;
  }

  void initializeCellEditAjax() {
    if (updateRequestBuilderFunction != null) {
      cellEditAjax = Ajax.newBuilder().event("valueChange").consumer(event -> {
        UIInput input = (UIInput) event.getComponent();
        Object dto = input.getAttributes().get("dto");

        Object request = updateRequestBuilderFunction.apply(dto);

        new ActionExecutor<>(this, "Saisie %s".formatted(businessValueType.getName()), () -> {
          IdentifiableResponseDto response = updateRequestConsumerFunction.apply(request);
          Core.acceptConsumer(updateResponseConsumer, response);
          supplyFooterText();
          return response;
        }).execute();

      }).updatePropertyValueBuilder(
          new CommandUpdatePropertyValueBuilder().widgets(List.of(dataTable))).build();
    }
  }

  /**
   * Cette méthode permet de fournir le texte de pied.
   */
  public void supplyFooterText() {
    if (footerTextSupplier != null) {
      footerText = footerTextSupplier.get();
    }
  }

  public Column addUpdateResponseConsumer(Consumer<IdentifiableResponseDto> consumer) {
    updateResponseConsumer = Core.combineConsumersTo(updateResponseConsumer, consumer);
    return this;
  }

  /**
   * Cette méthode permet de préparer l'édition de la valeur du champ.
   */
  public void prepareEdit() {
    Core.runIfStringBlank(editableFieldName,
        () -> editableFieldName = businessValueType.getValueFieldName());
    Core.runIfNull(isCellEditableFunction, () -> isCellEditableFunction = o -> true);
  }

  public static Builder newBuilder() {
    return new Builder();
  }

  /**
   * Cette classe représente un contructeur de {@link Column}.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder extends AbstractWidgetBuilder<Column> {

    String headerText;
    String footerText;
    String width;

    String fieldName;
    String editableFieldName;
    BusinessValueType businessValueType;

    @Override
    protected void processWidget(Column column) {
      super.processWidget(column);
      column.headerText = headerText;
      column.footerText = footerText;
      column.width = width;
      column.fieldName = fieldName;
      column.editableFieldName = editableFieldName;
      column.businessValueType = businessValueType;
    }

    @Override
    protected Column instantiateWidget() {
      return new Column();
    }
  }
}
