package ci.gouv.dgbf.system.documentation.client.extension.documentgroup;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentFilter;
import ci.gouv.dgbf.system.file.server.api.shared.HasFileIdentifierDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.List;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur des fichiers d'un enregistrement, tous groupes de
 * document confondus. Utilisée par l'onglet "Fichiers de l'enregistrement" de la page de lecture
 * de {@link ci.gouv.dgbf.system.documentation.server.api.DocumentGroupDto}.
 *
 * @author si.kimou
 *
 */
@Dependent
public class DocumentGroupRecordFilesController {

  @Inject
  DocumentClient client;

  @Getter
  List<DocumentDto> files;

  /**
   * Cette méthode permet de charger les fichiers de l'enregistrement.
   *
   * @param recordIdentifier identifiant de l'enregistrement
   * @param userIdentifier identifiant de l'utilisateur
   */
  public void initialize(String recordIdentifier, String userIdentifier) {
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        HasTypeAsStringDto.JSON_TYPE_AS_STRING, HasGroupAsStringDto.JSON_GROUP_AS_STRING,
        HasFileIdentifierDto.JSON_FILE_IDENTIFIER);

    FilterDto filter = new FilterDto();
    filter.addCriteria(DocumentFilter.JSON_GROUP_RECORD_IDENTIFIER, recordIdentifier);

    files = client.getMany(projection, filter, null, userIdentifier, null).getDatas();
  }
}
