package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un paramètre de script.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ScriptParameterDto extends AbstractIdentifiableCodableNamableAuditableDto {

  @JsonbProperty(JSON_SCRIPT_IDENTIFIER)
  private String scriptIdentifier;

  @JsonbProperty(JSON_SCRIPT_AS_STRING)
  private String scriptAsString;
    
  @JsonbProperty(JSON_TYPE)
  private ValueType type;

  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant json de identifiant de {@link ScriptParameterDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idParametreScript";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ScriptParameterDto}.
   */
  public static final String JSON_THIS_AS_STRING = "parametreScriptChaine";

  /**
   * Identifiant json {@link #scriptIdentifier}.
   */
  public static final String JSON_SCRIPT_IDENTIFIER = ScriptDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #scriptAsString}.
   */
  public static final String JSON_SCRIPT_AS_STRING = ScriptDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json {@link #type}.
   */
  public static final String JSON_TYPE = "type";

  /**
   * Identifiant json {@link #typeAsString}.
   */
  public static final String JSON_TYPE_AS_STRING = JSON_TYPE + "Chaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "paramètre de script";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "paramètres de script";
}
