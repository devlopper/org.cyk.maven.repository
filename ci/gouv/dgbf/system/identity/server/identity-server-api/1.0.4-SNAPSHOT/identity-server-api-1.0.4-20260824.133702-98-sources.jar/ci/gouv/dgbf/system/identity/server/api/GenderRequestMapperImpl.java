package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link GenderDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-24T13:37:24+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class GenderRequestMapperImpl implements GenderRequestMapper {

    @Override
    public GenderService.GenderCreateRequestDto mapCreate(GenderDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GenderService.GenderCreateRequestDto genderCreateRequestDto = new GenderService.GenderCreateRequestDto();

        genderCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        genderCreateRequestDto.setCode( arg0.getCode() );
        genderCreateRequestDto.setName( arg0.getName() );

        return genderCreateRequestDto;
    }

    @Override
    public GenderService.GenderUpdateRequestDto mapUpdate(GenderDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GenderService.GenderUpdateRequestDto genderUpdateRequestDto = new GenderService.GenderUpdateRequestDto();

        genderUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        genderUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        genderUpdateRequestDto.setCode( arg0.getCode() );
        genderUpdateRequestDto.setName( arg0.getName() );

        return genderUpdateRequestDto;
    }
}
