package ci.gouv.dgbf.system.documentation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Filtre de recherche sur les documents.
 *
 * @author si.kimou
 *
 */
@Getter
@Setter
public class DocumentFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant de l'enregistrement du {@link DocumentGroupDto} auquel le document est rattaché,
   * utilisé pour retrouver tous les fichiers d'un enregistrement, tous groupes de document
   * confondus.
   */
  String groupRecordIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public DocumentFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public DocumentFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    groupRecordIdentifier = getGroupRecordIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setGroupRecordIdentifier(filter, groupRecordIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'enregistrement du groupe de document.
   *
   * @param filter filtre
   * @param groupRecordIdentifier identifiant de l'enregistrement du groupe de document
   */
  public static void setGroupRecordIdentifier(FilterDto filter, String groupRecordIdentifier) {
    set(filter, JSON_GROUP_RECORD_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(groupRecordIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'enregistrement du groupe de document --
   * sans elle, le critère envoyé par le client pour lister les fichiers d'un enregistrement (tous
   * groupes de document confondus) serait silencieusement ignoré : {@code
   * DocumentClient.getMany(...)} retournerait tous les documents, et non les seuls fichiers de
   * l'enregistrement recherché.
   *
   * @param filter filtre
   * @return identifiant de l'enregistrement du groupe de document
   */
  public static String getGroupRecordIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_RECORD_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #groupRecordIdentifier}.
   */
  public static final String JSON_GROUP_RECORD_IDENTIFIER = "identifiantEnregistrementGroupe";
}
