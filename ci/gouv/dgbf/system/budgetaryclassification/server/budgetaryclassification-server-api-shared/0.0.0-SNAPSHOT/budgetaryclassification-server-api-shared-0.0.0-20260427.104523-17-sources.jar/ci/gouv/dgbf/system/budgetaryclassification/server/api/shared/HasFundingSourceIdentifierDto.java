package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de source de financement.
 *
 * @author Christian
 */
public interface HasFundingSourceIdentifierDto extends HasFundingSourceIdentifier {

  /**
   * Identifiant json de l'identifiant de la source de financement.
   */
  String JSON_FUNDING_SOURCE_IDENTIFIER = "idSourceFinancement";
}