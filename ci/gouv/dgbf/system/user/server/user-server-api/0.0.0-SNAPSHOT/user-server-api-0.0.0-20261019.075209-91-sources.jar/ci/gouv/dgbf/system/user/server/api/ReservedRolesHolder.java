package ci.gouv.dgbf.system.user.server.api;

/**
 * Cette interface représente les Rôles réservés détenus par un Utilisateur, quelle qu'en soit la
 * source : le jeton pour le frontal, la base pour le serveur (RG_UTI_ROL_16). Les Rôles d'un
 * Utilisateur appartiennent tous à des Applications de son Domaine (RG_UTI_ROL_15).
 *
 * @author Christian Yao Komenan
 */
public interface ReservedRolesHolder {

  /**
   * Cette méthode retourne le Code du Domaine de l'Utilisateur.
   *
   * @return Code du Domaine
   */
  String getDomainCode();

  /**
   * Cette méthode indique si l'Utilisateur est Administrateur de son Domaine
   * ({@link ReservedRole#DOMAIN_ADMINISTRATOR} de l'Application spéciale de son Domaine).
   *
   * @return vrai s'il l'est
   */
  boolean isDomainAdministrator();

  /**
   * Cette méthode indique si l'Utilisateur détient un Rôle d'une Application de son Domaine.
   *
   * @param roleCode        Code du Rôle
   * @param applicationCode Code de l'Application
   * @return vrai s'il le détient
   */
  boolean holds(String roleCode, String applicationCode);
}
