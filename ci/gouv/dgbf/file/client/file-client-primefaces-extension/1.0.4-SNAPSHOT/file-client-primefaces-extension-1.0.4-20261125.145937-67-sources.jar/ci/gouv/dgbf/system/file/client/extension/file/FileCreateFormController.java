package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDescriptionProposalDto;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.MediumNature;
import jakarta.faces.model.SelectItem;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Supplier;
import java.util.logging.Level;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.event.FileUploadEvent;

/**
 * Contrôleur réutilisable de saisie d'un {@link FileDto} à la création (partagé entre le
 * formulaire de création d'un Fichier et celui d'un Fichier de groupe). Gère les natures de
 * support autorisées (numérique seul par défaut), la proposition de description (RG_FILE_FIC_24)
 * et la construction de {@link FileCreateRequestDto}.
 *
 * @author Christian
 *
 */
public class FileCreateFormController implements Serializable {

  private static final long serialVersionUID = 1L;
  private static final Logger LOGGER = Logger.getLogger(FileCreateFormController.class.getName());

  private transient FileClient fileClient;
  private transient Supplier<String> userIdentifierSupplier = () -> null;
  private transient Supplier<FileDto> fileSupplier;

  /**
   * Entité locale de saisie du Fichier lorsque le contrôleur appelant n'en fournit pas déjà une
   * via {@link #fileSupplier} (ex. création d'un Fichier de groupe).
   */
  @Getter
  private FileDto file = new FileDto();

  /**
   * Natures de support autorisées à la création : par défaut uniquement numérique (cas nominal
   * dans la grande majorité des usages). Si une seule nature est autorisée, la section de choix
   * est masquée et cette nature est appliquée d'office ; sinon seules les natures autorisées sont
   * proposées.
   */
  @Getter
  private Set<MediumNature> allowedMediumNatures = EnumSet.of(MediumNature.DIGITAL);

  /**
   * Nature du support choisie en tête du formulaire de création (NUMERIQUE, PHYSIQUE ou HYBRIDE) :
   * elle décide des sections affichées et de ce qui est envoyé au serveur, qui la redéduit des
   * exemplaires reçus (RG_FILE_FIC_17).
   */
  @Getter
  @Setter
  private String mediumNatureCode = MediumNature.DIGITAL.getCode();

  @Getter
  @Setter
  private String physicalItemHolder;

  @Getter
  @Setter
  private String physicalItemContainer;

  @Getter
  @Setter
  private String physicalItemExtent;

  @Getter
  @Setter
  private String physicalItemCondition;

  /**
   * Support d'origine déclaré pour un Fichier hybride : pas de valeur par défaut, choix conscient
   * et définitif (RG_FILE_FIC_17).
   */
  @Getter
  @Setter
  private String originalMediumCode;

  /**
   * Nom du contenu binaire déposé, gardé à part du champ Nom : il sert de nom quand ce champ est
   * laissé vide (« Nom (facultatif) »), même si le champ a été réaffiché vide après un refus.
   */
  @Getter
  private String uploadedFileName;

  /**
   * Description proposée à partir du contenu déposé (RG_FILE_FIC_24) : le formulaire en remplit
   * les champs vides dans le navigateur. Jamais nulle, vide sans contenu déposé.
   */
  @Getter
  private FileDescriptionProposalDto descriptionProposal = new FileDescriptionProposalDto();

  /**
   * Câble les dépendances fournies par le contrôleur hôte.
   *
   * @param client client REST Fichier (pour la proposition de description)
   * @param userSupplier fournisseur de l'identifiant utilisateur
   * @param entitySupplier fournisseur optionnel du {@link FileDto} courant ({@code null} pour
   *        utiliser {@link #file})
   */
  public void configure(FileClient client, Supplier<String> userSupplier,
      Supplier<FileDto> entitySupplier) {
    fileClient = client;
    userIdentifierSupplier = userSupplier == null ? () -> null : userSupplier;
    fileSupplier = entitySupplier;
  }

  /**
   * Définit les natures de support autorisées dans le formulaire de création.
   *
   * @param natures ensemble non vide des natures autorisées
   */
  public void setAllowedMediumNatures(Set<MediumNature> natures) {
    if (natures == null || natures.isEmpty()) {
      throw new IllegalArgumentException(
          "Au moins une nature de support doit être autorisée.");
    }
    allowedMediumNatures = EnumSet.copyOf(natures);
    boolean currentAllowed = allowedMediumNatures.stream()
        .anyMatch(nature -> nature.getCode().equals(mediumNatureCode));
    if (!currentAllowed) {
      mediumNatureCode = defaultMediumNature().getCode();
    }
  }

  /**
   * Autorise toutes les natures de support (numérique, papier et hybride) dans le formulaire de
   * création.
   */
  public void allowAllMediumNatures() {
    setAllowedMediumNatures(EnumSet.allOf(MediumNature.class));
  }

  /**
   * Indique si la section de choix de la nature du support est affichée : seulement quand au
   * moins deux natures sont autorisées.
   *
   * @return {@code true} si l'utilisateur choisit la nature du support
   */
  public boolean isMediumNatureSelectionRendered() {
    return allowedMediumNatures.size() > 1;
  }

  /**
   * Options de nature du support affichées dans le formulaire de création, limitées aux natures
   * autorisées et dans l'ordre naturel (Numérique, Papier, Les deux).
   *
   * @return liste des options
   */
  public List<SelectItem> getMediumNatureSelectItems() {
    List<SelectItem> items = new ArrayList<>();
    for (MediumNature nature : allowedMediumNatures) {
      items.add(new SelectItem(nature.getCode(), mediumNatureOptionLabel(nature)));
    }
    return items;
  }

  private static String mediumNatureOptionLabel(MediumNature nature) {
    if (MediumNature.DIGITAL.equals(nature)) {
      return "Numérique : un contenu déposé (PDF, image, tableur…)";
    }
    if (MediumNature.PHYSICAL.equals(nature)) {
      return "Papier : un exemplaire physique seulement, rien à déposer";
    }
    return "Les deux : un contenu déposé et son exemplaire papier";
  }

  /**
   * Construit la phrase d'en-tête décrivant les natures autorisées, terminée par le complément de
   * contexte (ex. « et rattachez-le à son module. » ou « dans le groupe. »).
   *
   * @param contextSuffix complément final
   * @return texte descriptif
   */
  public String describeAllowedNatures(String contextSuffix) {
    if (allowedMediumNatures.size() == MediumNature.values().length) {
      return "Créez un fichier numérique, papier ou les deux, " + contextSuffix;
    }
    if (isMediumNatureSelectionRendered()) {
      return "Créez un fichier selon la nature du support choisie " + contextSuffix;
    }
    MediumNature only = defaultMediumNature();
    if (MediumNature.PHYSICAL.equals(only)) {
      return "Enregistrez un fichier papier " + contextSuffix;
    }
    if (MediumNature.HYBRID.equals(only)) {
      return "Créez un fichier hybride (contenu numérique et exemplaire papier) " + contextSuffix;
    }
    return "Déposez un fichier numérique " + contextSuffix;
  }

  /**
   * Message affiché lorsque le contenu numérique obligatoire n'a pas été déposé.
   *
   * @return message de validation
   */
  public String getBinaryContentRequiredMessage() {
    return allowedMediumNatures.contains(MediumNature.PHYSICAL)
        ? "Déposez le contenu numérique, ou choisissez « Papier » si vous n'avez que "
            + "l'exemplaire physique."
        : "Déposez le contenu numérique.";
  }

  /**
   * Réinitialise les champs de saisie du support physique, le fichier local et la proposition.
   */
  public void reset() {
    file = new FileDto();
    mediumNatureCode = defaultMediumNature().getCode();
    physicalItemHolder = null;
    physicalItemContainer = null;
    physicalItemExtent = null;
    physicalItemCondition = null;
    originalMediumCode = null;
    uploadedFileName = null;
    descriptionProposal = new FileDescriptionProposalDto();
  }

  /**
   * Réagit au téléchargement d'un fichier : le contenu est gardé pour la création et la
   * description proposée est demandée au serveur (RG_FILE_FIC_24).
   *
   * @param event évènement de téléversement
   */
  public void handleFileUpload(FileUploadEvent event) {
    FileDto target = currentFile();
    uploadedFileName = event.getFile().getFileName();
    target.setBytes(event.getFile().getContent());
    descriptionProposal = proposeDescription(target.getBytes(), uploadedFileName);
  }

  /**
   * Demande la description proposée ; un échec ne bloque jamais le dépôt (proposition vide).
   *
   * @param bytes octets déposés
   * @param fileName nom du fichier déposé
   * @return description proposée, jamais nulle
   */
  FileDescriptionProposalDto proposeDescription(byte[] bytes, String fileName) {
    if (fileClient == null) {
      return new FileDescriptionProposalDto();
    }
    try {
      FileDescriptionProposalDto proposal =
          fileClient.getProposedDescription(bytes, fileName, userIdentifierSupplier.get(), null);
      return proposal == null ? new FileDescriptionProposalDto() : proposal;
    } catch (RuntimeException exception) {
      LOGGER.log(Level.WARNING, "Description proposée indisponible pour " + fileName, exception);
      return new FileDescriptionProposalDto();
    }
  }

  /**
   * Nom retenu quand le champ Nom est laissé vide : le Nom proposé, à défaut le nom du fichier
   * déposé.
   *
   * @return nom par défaut
   */
  String defaultName() {
    return Core.isStringBlank(descriptionProposal.getName()) ? uploadedFileName
        : descriptionProposal.getName();
  }

  /**
   * Indique si un fichier a été téléversé pour la création en cours.
   *
   * @return {@code true} si le fichier peut être retiré avant l'enregistrement
   */
  public boolean hasUploadedFile() {
    FileDto target = currentFile();
    return target != null && target.getBytes() != null;
  }

  /**
   * Indique si la nature choisie attend un contenu binaire (Numérique ou Hybride).
   *
   * @return {@code true} si la section de dépôt est affichée
   */
  public boolean isBinaryContentExpected() {
    return !MediumNature.PHYSICAL.getCode().equals(mediumNatureCode);
  }

  /**
   * Indique si la nature choisie attend un Exemplaire physique (Physique ou Hybride).
   *
   * @return {@code true} si la section du papier est affichée
   */
  public boolean isPhysicalItemExpected() {
    return !MediumNature.DIGITAL.getCode().equals(mediumNatureCode);
  }

  /**
   * Indique si la nature choisie est Hybride (contenu binaire et papier).
   *
   * @return {@code true} si le choix de l'original est affiché
   */
  public boolean isHybrid() {
    return MediumNature.HYBRID.getCode().equals(mediumNatureCode);
  }

  /**
   * Réagit au changement de nature : un contenu binaire déjà déposé est retiré si la nature n'en
   * attend plus (Physique), pour que l'écran montre ce qui sera vraiment envoyé.
   */
  public void onMediumNatureChange() {
    if (!isBinaryContentExpected()) {
      removeUploadedFile();
    }
  }

  /**
   * Témoin du contenu binaire déposé, lu par un champ caché obligatoire du formulaire : la
   * validation JSF signale ainsi l'absence de contenu pour une nature qui en attend un.
   *
   * @return une valeur non vide si un contenu binaire est déposé, {@code null} sinon
   */
  public String getBinaryContentMarker() {
    return hasUploadedFile() ? "1" : null;
  }

  /**
   * Sans effet : le témoin se déduit du contenu déposé (requis par le champ caché).
   *
   * @param marker valeur soumise, ignorée
   */
  public void setBinaryContentMarker(String marker) {
    // Valeur dérivée de l'entité en cours de création : rien à mémoriser.
  }

  /**
   * Indique si le nom fourni a été saisi ou modifié manuellement par l'utilisateur (différent du
   * nom du fichier déposé et du nom proposé automatiquement).
   *
   * @param candidateName nom à tester
   * @return {@code true} si le nom est personnalisé
   */
  public boolean isCustomName(String candidateName) {
    return !Core.isStringBlank(candidateName)
        && !Objects.equals(candidateName, uploadedFileName)
        && !Objects.equals(candidateName, descriptionProposal.getName());
  }

  /**
   * Retire le fichier téléversé de la création en cours, avant toute persistance.
   */
  public void removeUploadedFile() {
    FileDto target = currentFile();
    if (target != null) {
      if (!isCustomName(target.getName())) {
        target.setName(null);
      }
      if (Objects.equals(descriptionProposal.getDescription(), target.getDescription())) {
        target.setDescription(null);
      }
      if (Objects.equals(descriptionProposal.getProductionDate(), target.getProductionDate())) {
        target.setProductionDate(null);
      }
      target.setBytes(null);
    }
    uploadedFileName = null;
    descriptionProposal = new FileDescriptionProposalDto();
  }

  /**
   * Construit la requête de création de {@link FileDto} conforme à la nature de support choisie.
   *
   * @param targetFile entité {@link FileDto} portant les champs généraux et octets
   * @param auditWho acteur d'audit
   * @return requête prête à soumettre à {@link FileClient#create(FileCreateRequestDto)}
   */
  public FileCreateRequestDto buildCreateRequest(FileDto targetFile, String auditWho) {
    FileCreateRequestDto request = new FileCreateRequestDto();
    request.setModuleIdentifier(targetFile.getModuleIdentifier());
    request.setName(isBinaryContentExpected() && Core.isStringBlank(targetFile.getName())
        && targetFile.getBytes() != null ? defaultName() : targetFile.getName());
    request.setBytes(isBinaryContentExpected() ? targetFile.getBytes() : null);
    request.setDescription(targetFile.getDescription());
    if (targetFile.getProductionDate() != null) {
      request.setProductionDate(targetFile.getProductionDate().toString());
    }
    if (isPhysicalItemExpected()) {
      request.setHolder(physicalItemHolder);
      request.setContainer(physicalItemContainer);
      request.setPhysicalExtent(physicalItemExtent);
      request.setPhysicalCondition(physicalItemCondition);
      request.setOriginalMedium(isHybrid() ? originalMediumCode : null);
    }
    request.setAuditWho(auditWho);
    return request;
  }

  private FileDto currentFile() {
    return fileSupplier == null ? file : fileSupplier.get();
  }

  private MediumNature defaultMediumNature() {
    return allowedMediumNatures.iterator().next();
  }
}
