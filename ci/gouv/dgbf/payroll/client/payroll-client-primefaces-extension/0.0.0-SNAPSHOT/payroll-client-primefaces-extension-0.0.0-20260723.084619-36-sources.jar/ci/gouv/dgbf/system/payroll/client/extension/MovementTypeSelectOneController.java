package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.MovementTypeClient;
import ci.gouv.dgbf.system.payroll.server.api.MovementTypeDto;
import ci.gouv.dgbf.system.payroll.server.api.MovementTypeService.MovementTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link MovementTypeDto}.
 *
 * @author akm
 *
 */
@Dependent
public class MovementTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    MovementTypeDto, MovementTypeGetManyResponseDto, MovementTypeClient> {

  @Getter
  @Inject
  MovementTypeClient client;

  protected MovementTypeSelectOneController() {
    super(MovementTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
