package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FieldDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des postes de paie.
 *
 * <p>Trois axes portes par le poste : la nature économique — l'imputation budgétaire —, la
 * catégorie de paie, et la nature du poste — normal, rappel ou régularisation. Ils ne
 * s'emboîtent pas, ils se croisent.</p>
 *
 * <p>Un quatrième, l'<strong>activité</strong>, ne vient pas du poste mais de sa catégorie. Il
 * n'écarte rien tant qu'il n'est pas renseigné, et couvrira d'autant plus de postes que la
 * table de liaison des activités se remplira — sans modification ici.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class PayrollComponentFilter extends AbstractIdentifiableFilter {

  /**
   * Nature économique du poste de paie.
   */
  String economicNatureIdentifier;

  /**
   * Catégorie du poste de paie.
   */
  String categoryIdentifier;

  /**
   * Nature de paie du poste.
   */
  String payrollNatureIdentifier;

  /**
   * Activité du poste de paie.
   */
  String activityIdentifier;

  public PayrollComponentFilter() {
    super();
  }

  public PayrollComponentFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setEconomicNatureIdentifier(
        read(filter, PayrollComponentDto.JSON_ECONOMIC_NATURE_IDENTIFIER));
    setCategoryIdentifier(read(filter, PayrollComponentDto.JSON_CATEGORY_IDENTIFIER));
    setPayrollNatureIdentifier(
        read(filter, PayrollComponentDto.JSON_PAYROLL_NATURE_IDENTIFIER));
    setActivityIdentifier(read(filter, PayrollComponentDto.JSON_ACTIVITY_IDENTIFIER));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, PayrollComponentDto.JSON_ECONOMIC_NATURE_IDENTIFIER,
        getEconomicNatureIdentifier());
    write(filter, PayrollComponentDto.JSON_CATEGORY_IDENTIFIER, getCategoryIdentifier());
    write(filter, PayrollComponentDto.JSON_PAYROLL_NATURE_IDENTIFIER,
        getPayrollNatureIdentifier());
    write(filter, PayrollComponentDto.JSON_ACTIVITY_IDENTIFIER, getActivityIdentifier());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  private static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, FieldDto::getValueAsString,
        field -> field.setValueAsString(value));
  }
}
