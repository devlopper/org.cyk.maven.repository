package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de bailleur.
 *
 * @author Christian
 */
public interface HasLessorIdentifierDto extends HasLessorIdentifier {

  /**
   * Identifiant json de l'identifiant de la bailleur.
   */
  String JSON_LESSOR_IDENTIFIER = "idBailleur";
}