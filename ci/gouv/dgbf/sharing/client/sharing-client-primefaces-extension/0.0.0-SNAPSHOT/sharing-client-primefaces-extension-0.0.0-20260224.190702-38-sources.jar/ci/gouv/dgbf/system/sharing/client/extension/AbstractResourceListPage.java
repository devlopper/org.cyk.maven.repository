package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages de liste de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
public abstract class AbstractResourceListPage extends AbstractPage {

  @Inject
  @Getter
  ResourceController controller;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Liste " + ResourceDto.NAME;
    initializeController();
  }
  
  void initializeController() {
    controller.initialize();
  }
}
