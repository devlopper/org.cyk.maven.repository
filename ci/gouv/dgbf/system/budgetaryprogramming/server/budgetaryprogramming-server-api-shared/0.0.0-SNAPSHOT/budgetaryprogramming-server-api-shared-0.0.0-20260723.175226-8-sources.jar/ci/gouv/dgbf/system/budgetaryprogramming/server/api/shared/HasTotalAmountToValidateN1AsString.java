package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN1AsString {

  /**
   * Obtient le montant total à valider pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant total à valider pour l'année N+1 sous forme de chaîne de caractères
   */
  String getTotalAmountToValidateN1AsString();

  /**
   * Définit le montant total à valider pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param totalAmountToValidateN1AsString le montant total à valider pour l'année N+1 sous forme
   *        de chaîne de caractères
   */
  void setTotalAmountToValidateN1AsString(String totalAmountToValidateN1AsString);

  /**
   * Identifiant java du montant total à valider pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_VALIDATE_N1_AS_STRING =
      "totalAmountToValidateN1AsString";
}
