package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une règle de type de réclamation par document du FUR : elle associe un
 * code pièce et le préfixe du code document au Type de Réclamation de la réclamation à générer
 * (RG-15 du dossier de spécifications du FUR). Les zéros de tête du code document sont ignorés,
 * {@code *} vaut pour tout code document de la pièce et le préfixe le plus long l'emporte.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimDocumentRuleDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto {

  /**
   * Code pièce du FUR (par exemple {@code 1192}).
   */
  @JsonbProperty(JSON_PIECE_CODE)
  private String pieceCode;

  /**
   * Préfixe du code document, ou {@code *} pour tout code document de la pièce.
   */
  @JsonbProperty(JSON_DOCUMENT_PREFIX)
  private String documentPrefix;

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Identifiant json {@link #pieceCode}.
   */
  public static final String JSON_PIECE_CODE = "codePiece";

  /**
   * Identifiant json {@link #documentPrefix}.
   */
  public static final String JSON_DOCUMENT_PREFIX = "prefixeDocument";

  /**
   * Préfixe qui vaut pour tout code document de la pièce.
   */
  public static final String ANY_DOCUMENT_PREFIX = "*";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "règle de type par document";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "règles de type par document";
}
