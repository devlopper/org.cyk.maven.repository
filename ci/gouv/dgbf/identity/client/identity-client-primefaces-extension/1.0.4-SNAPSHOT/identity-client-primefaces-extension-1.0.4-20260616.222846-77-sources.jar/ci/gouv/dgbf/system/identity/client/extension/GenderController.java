package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.GenderClient;
import ci.gouv.dgbf.system.identity.server.api.GenderDto;
import ci.gouv.dgbf.system.identity.server.api.GenderRequestMapper;
import ci.gouv.dgbf.system.identity.server.api.GenderService;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.GenderService.GenderUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link GenderDto}.
 *
 * @author arnaud
 *
 */
@Dependent
public class GenderController extends AbstractController {

  @Inject
  GenderClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  GenderRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = GenderDto.NAME;

    listController.setEntityClass(GenderDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(GenderService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      GenderCreateRequestDto request = requestMapper.mapCreate((GenderDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });

    listController.getUpdateController().setFunction(entity -> {
      GenderUpdateRequestDto request = requestMapper.mapUpdate((GenderDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
  }
}
