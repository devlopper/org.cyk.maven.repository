package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.mailer.server.api.ReceiverService.GetManyResponseDto;
import ci.gouv.dgbf.system.mailer.server.api.ReceiverService.ReceiverCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.ReceiverService.ReceiverUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client du service ReceiverService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ReceiverClient extends AbstractClient<ReceiverService>
    implements GetByIdentifier<ReceiverDto>, GetMany<GetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ReceiverClient service(ReceiverService service) {
    return (ReceiverClient) super.service(service);
  }

  /**
   * Cette méthode permet de créer un destinataire.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ReceiverCreateRequestDto request) {
    return new CreateExecutor(ReceiverService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * Cette méthode permet de créer un destinataire.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String mailIdentifier, String address, String auditWho,
      String auditSession) {
    ReceiverCreateRequestDto request = new ReceiverCreateRequestDto();
    request.setMailIdentifier(mailIdentifier);
    request.setAddress(address);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        ReceiverService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * Cette méthode permet d'obtenir des destinataires.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  public ReceiverDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ReceiverDto>(ReceiverDto.class, ReceiverService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * Cette méthode permet d'obtenir un destinataire.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReceiverDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * Cette méthode permet d'obtenir par identifiant un destinataire.
   *
   * @param request requête
   * @return destinataire
   */
  public ReceiverDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ReceiverDto>(ReceiverDto.class,
        ReceiverService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * Cette méthode permet d'obtenir par identifiant un destinataire.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReceiverDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  public IdentifiableResponseDto update(ReceiverUpdateRequestDto request) {
    return new IdentifiableExecutor(ReceiverService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * Cette méthode permet de mettre à jour un destinataire.
   *
   * @param identifier identifiant
   * @param mailIdentifier identifiant mail
   * @param address adresse
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String mailIdentifier, String address,
      String auditWho, String auditSession) {
    ReceiverUpdateRequestDto request = new ReceiverUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setMailIdentifier(mailIdentifier);
    request.setAddress(address);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ReceiverService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un destinataire.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
