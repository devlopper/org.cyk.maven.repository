package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIsCompletedDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasBudgetSpecializationUnitAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasSectionAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une synthèse d'activité de dépense de programmation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProgrammingExpenditureActivitySynthesisDto
    extends AbstractProgrammingAmountsContainerDto
    implements HasActivityIdentifierDto, HasActivityAsStringDto,
    HasBudgetSpecializationUnitAsStringDto, HasSectionAsStringDto, HasIsCompletedDto {

  // Activity

  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  private String activityIdentifier;

  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  private String activityAsString;

  // BudgetSpecializationUnit
  
  @JsonbProperty(JSON_BUDGET_SPECIALIZATION_UNIT_AS_STRING)
  private String budgetSpecializationUnitAsString;

  // Section
  
  @JsonbProperty(JSON_SECTION_AS_STRING)
  private String sectionAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idSyntheseActiviteDepenseProgrammation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "syntheseActiviteDepenseProgrammationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "synthèse d'activité de dépense de programmation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "synthèses des activités de dépenses de programmation";

}
