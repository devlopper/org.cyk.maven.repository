package ci.gouv.dgbf.system.token.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasModuleIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link TokenDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class TokenFilter extends AbstractIdentifiableFilter
    implements FilterHasModuleIdentifier, FilterHasStatusCode {

  String moduleIdentifier;

  String statusCode;

  @Override
  protected void doInitialize(FilterDto filter) {
    updateModuleIdentifier(filter);
    updateStatusCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterModuleIdentifier(filter);
    updateFilterStatusCode(filter);
  }
}
