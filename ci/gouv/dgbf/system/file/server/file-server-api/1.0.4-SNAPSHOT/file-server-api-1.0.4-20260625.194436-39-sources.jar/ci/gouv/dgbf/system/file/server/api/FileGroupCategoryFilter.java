package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FileGroupCategoryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class FileGroupCategoryFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link FileGroupDto}.
   */
  String fileGroupIdentifier;

  /**
   * Identifiant {@link FileCategoryDto}.
   */
  String categoryIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    fileGroupIdentifier = getFileGroupIdentifier(filter);
    categoryIdentifier = getCategoryIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setFileGroupIdentifier(filter, fileGroupIdentifier);
    setCategoryIdentifier(filter, categoryIdentifier);
  }

  /**
   * Cette méthode permet d'initialiser l'identifiant {@link FileGroupDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link FileGroupDto}
   */
  public static void setFileGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_FILE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link FileGroupDto}.
   *
   * @param filter filtre
   * @return identifiant {@link FileGroupDto}
   */
  public static String getFileGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_FILE_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'initialiser l'identifiant {@link FileCategoryDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link FileCategoryDto}
   */
  public static void setCategoryIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_CATEGORY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link FileCategoryDto}.
   *
   * @param filter filtre
   * @return identifiant {@link FileCategoryDto}
   */
  public static String getCategoryIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CATEGORY_IDENTIFIER));
  }

  /**
   * Champ JSON {@link #fileGroupIdentifier}.
   */
  public static final String JSON_FILE_GROUP_IDENTIFIER =
      FileGroupCategoryDto.JSON_FILE_GROUP_IDENTIFIER;

  /**
   * Champ JSON {@link #categoryIdentifier}.
   */
  public static final String JSON_CATEGORY_IDENTIFIER =
      FileGroupCategoryDto.JSON_CATEGORY_IDENTIFIER;
}
