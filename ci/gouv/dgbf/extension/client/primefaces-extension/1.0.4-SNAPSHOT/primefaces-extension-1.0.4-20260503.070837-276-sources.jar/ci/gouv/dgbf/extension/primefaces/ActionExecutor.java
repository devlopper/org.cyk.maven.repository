package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.executor.FunctionExecutor;
import jakarta.faces.application.FacesMessage;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.primefaces.PrimeFaces;

/**
 * Cette classe représente un exécuteur d'action.
 *
 * @author Christian
 */
public class ActionExecutor<T> extends FunctionExecutor<T> {

  @Setter
  @Accessors(chain = true)
  String exceptionMessageSummary;

  @Setter
  @Accessors(chain = true)
  boolean exceptionShowableInDialog;

  /**
   * Cette méthode permet d'instancier.
   *
   * @param container conteneur
   * @param name nom
   * @param function fonction
   */
  public ActionExecutor(Object container, String name, Callable<T> function) {
    super(container, name, function);
    exceptionShowableInDialog = CONFIGURATION.exceptionShowableInDialog;
    exceptionMessageSummary = name;
  }

  @Override
  protected T handleException(Exception exception) {
    if (exceptionShowableInDialog) {
      String message = exception.getMessage();
      getLogger().log(Level.SEVERE, message);
      FacesMessage facesMessage =
          new FacesMessage(FacesMessage.SEVERITY_ERROR, exceptionMessageSummary, message);
      PrimeFaces.current().dialog().showMessageDynamic(facesMessage);
    }
    return null;
  }

  public static final Configuration CONFIGURATION = new Configuration();

  /**
   * Cette classe représente la configuration.
   *
   * @author Christian
   *
   */
  @Getter
  @Setter
  public static class Configuration {
    boolean exceptionShowableInDialog = true;
  }
}
