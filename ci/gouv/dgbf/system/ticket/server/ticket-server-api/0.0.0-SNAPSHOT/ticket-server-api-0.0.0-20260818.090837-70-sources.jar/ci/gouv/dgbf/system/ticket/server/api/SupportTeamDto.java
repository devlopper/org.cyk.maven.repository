package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTicketCountAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTicketCountDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimedTicketCountDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasProcessedTicketCountAsStringDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasProcessedTicketCountDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un equipe support.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class SupportTeamDto extends AbstractIdentifiableAuditableDto
    implements HasUsersGroupIdentifierDto, HasUsersGroupAsStringDto, HasTicketCountDto,
    HasTicketCountAsStringDto, HasClaimedTicketCountDto,
    HasClaimedTicketCountAsStringDto, HasProcessedTicketCountDto,
    HasProcessedTicketCountAsStringDto {

  @JsonbProperty(JSON_USERS_GROUP_IDENTIFIER)
  private String usersGroupIdentifier;

  @JsonbProperty(JSON_USERS_GROUP_AS_STRING)
  private String usersGroupAsString;

  /**
   * Nombre maximal de prises en charge par support.
   */
  @JsonbProperty(JSON_MAX_CLAIMS_PER_SUPPORT)
  private Integer maxClaimsPerSupport;

  /**
   * Nombre total de tickets.
   */
  @JsonbProperty(JSON_TICKET_COUNT)
  private Integer ticketCount;

  /**
   * Nombre total de tickets sous forme de chaîne.
   */
  @JsonbProperty(JSON_TICKET_COUNT_AS_STRING)
  private String ticketCountAsString;

  /**
   * Nombre de tickets actuellement pris en charge.
   */
  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT)
  private Integer claimedTicketCount;

  /**
   * Nombre de tickets actuellement pris en charge sous forme de chaîne.
   */
  @JsonbProperty(JSON_CLAIMED_TICKET_COUNT_AS_STRING)
  private String claimedTicketCountAsString;

  /**
   * Nombre de tickets traités.
   */
  @JsonbProperty(JSON_PROCESSED_TICKET_COUNT)
  private Integer processedTicketCount;

  /**
   * Nombre de tickets traités sous forme de chaîne.
   */
  @JsonbProperty(JSON_PROCESSED_TICKET_COUNT_AS_STRING)
  private String processedTicketCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idServiceSupport";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "serviceSupportChaine";

  /**
   * Identifiant json champ {@link #maxClaimsPerSupport}.
   */
  public static final String JSON_MAX_CLAIMS_PER_SUPPORT = "nombreMaximalPrisesEnChargeParSupport";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "équipe support";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "équipes support";

}
