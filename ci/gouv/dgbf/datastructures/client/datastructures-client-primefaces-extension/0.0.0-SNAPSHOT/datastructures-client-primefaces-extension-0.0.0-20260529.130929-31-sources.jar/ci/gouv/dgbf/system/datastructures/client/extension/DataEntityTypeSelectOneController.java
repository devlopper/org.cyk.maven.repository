package ci.gouv.dgbf.system.datastructures.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneEnumerationController;
import ci.gouv.dgbf.system.datastructures.server.api.DataEntityType;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de sélection de {@link DataEntityType}.
 *
 * @author Christian
 *
 */
@Dependent
public class DataEntityTypeSelectOneController
    extends AbstractSelectOneEnumerationController<DataEntityType> {

  /**
   * Cette méthode permet de construire.
   */
  protected DataEntityTypeSelectOneController() {
    super(DataEntityType.values());
    outputLableValue = "Type d'entité de données";
  }

  @Override
  protected String computeSelectItemLabel(DataEntityType type) {
    return type.getName();
  }
}
