package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasFrontEndBaseUriDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ModulesGroupDto}.
 *
 * @author Christian
 */
@Path(value = ModulesGroupService.PATH)
@Tag(name = "Gestion des Groupes de Modules")
public interface ModulesGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-modules";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ModulesGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'ordre d'affichage de la section du Portail.
     *
     * @return ordre d'affichage de la section du Portail
     */
    Integer getOrder();

    /**
     * Cette méthode permet d'assigner l'ordre d'affichage de la section du Portail.
     *
     * @param order ordre d'affichage de la section du Portail
     */
    void setOrder(Integer order);

    /**
     * {@link ModulesGroupDto#JSON_ORDER}.
     */
    String JSON_ORDER = ModulesGroupDto.JSON_ORDER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ModulesGroupDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_MODULES";

  /**
   * Chemin du service de création unitaire de {@link ModulesGroupDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ModulesGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModulesGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ModulesGroupSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ModulesGroupDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention de plusieurs {@link ModulesGroupDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ModulesGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ModulesGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ModulesGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ModulesGroupDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention unitaire de {@link ModulesGroupDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ModulesGroupDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention par identifiant de {@link ModulesGroupDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir compte {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ModulesGroupDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_MODULES";

  /**
   * Chemin du service de mise à jour unitaire de {@link ModulesGroupDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ModulesGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModulesGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ModulesGroupSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ModulesGroupDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_MODULES";

  /**
   * Chemin du service de suppression unitaire de {@link ModulesGroupDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Identifiant du service d'obtention du catalogue filtré pour les agents (CU_SVC_005).
   */
  String GET_FILTERED_CATALOG_IDENTIFIER = "OBTENTION_CATALOGUE_FILTRE";

  /**
   * Chemin du service d'obtention du catalogue filtré pour les agents.
   */
  String GET_FILTERED_CATALOG_PATH = "obtention/catalogue-filtre";

  /**
   * Cette méthode permet d'obtenir le catalogue filtré (Portail privé agents, CU_SVC_005).
   *
   * @param request requête auditée
   * @return réponse contenant l'arborescence ordonnée et filtrée
   */
  @Path(GET_FILTERED_CATALOG_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_FILTERED_CATALOG_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = FilteredCatalogResponseDto.class))})
  Response getFilteredCatalog(GetFilteredCatalogRequestDto request);

  /**
   * Identifiant du service d'obtention du catalogue public (CU_SVC_008).
   */
  String GET_PUBLIC_CATALOG_IDENTIFIER = "OBTENTION_CATALOGUE_PUBLIC";

  /**
   * Chemin du service d'obtention du catalogue public.
   */
  String GET_PUBLIC_CATALOG_PATH = "obtention/catalogue-public";

  /**
   * Cette méthode permet d'obtenir le catalogue public minimal (Portail public, CU_SVC_008).
   *
   * @param request requête portant l'URI de base du front
   * @return réponse minimale contenant l'arborescence ordonnée des services publics
   */
  @Path(GET_PUBLIC_CATALOG_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_PUBLIC_CATALOG_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = PublicCatalogResponseDto.class))})
  Response getPublicCatalog(GetPublicCatalogRequestDto request);

  /**
   * Clé JSON portant la liste ordonnée des groupes dans les réponses de catalogue.
   */
  String JSON_MODULES_GROUPS = "groupesModules";

  /**
   * Clé JSON portant la liste ordonnée des modules d'un groupe dans les réponses de catalogue.
   */
  String JSON_MODULES = "modules";

  /**
   * Clé JSON portant la liste ordonnée des processus d'un module dans les réponses de catalogue.
   */
  String JSON_PROCESSES = "processus";

  /**
   * Cette classe représente la requête d'obtention du catalogue filtré (CU_SVC_005).
   */
  @Getter
  @Setter
  class GetFilteredCatalogRequestDto extends AbstractAuditedRequestJsonDto
      implements HasFrontEndBaseUriDto {

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;
  }

  /**
   * Cette classe représente la requête d'obtention du catalogue public (CU_SVC_008). Aucun
   * audit : l'accès est sans connexion. Le front transmet son URI de base, pour résoudre les URL
   * de base relatives à défaut d'adresse racine configurée (RG_SVC_NAV_06).
   */
  @Getter
  @Setter
  class GetPublicCatalogRequestDto implements HasFrontEndBaseUriDto {

    @JsonbProperty(JSON_FRONT_END_BASE_URI)
    private String frontEndBaseUri;
  }

  /**
   * Cette classe représente la réponse d'obtention du catalogue filtré (Portail agents).
   */
  @Getter
  @Setter
  class FilteredCatalogResponseDto {

    @JsonbProperty(JSON_MODULES_GROUPS)
    private List<CatalogModulesGroupDto> modulesGroups = new ArrayList<>();
  }

  /**
   * Cette classe représente un Groupe de modules dans le catalogue filtré (agents).
   */
  @Getter
  @Setter
  class CatalogModulesGroupDto {

    @JsonbProperty(AbstractIdentifiableCodableDto.JSON_CODE)
    private String code;

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(ModulesGroupDto.JSON_ORDER)
    private Integer order;

    @JsonbProperty(JSON_MODULES)
    private List<CatalogModuleDto> modules = new ArrayList<>();
  }

  /**
   * Cette classe représente un Module dans le catalogue filtré (agents).
   */
  @Getter
  @Setter
  class CatalogModuleDto {

    @JsonbProperty(AbstractIdentifiableCodableDto.JSON_CODE)
    private String code;

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(HasDescriptionDto.JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(ModuleDto.JSON_ICON)
    private String icon;

    @JsonbProperty(JSON_PROCESSES)
    private List<CatalogProcessDto> processes = new ArrayList<>();
  }

  /**
   * Cette classe représente un Processus dans le catalogue filtré (agents).
   */
  @Getter
  @Setter
  class CatalogProcessDto {

    @JsonbProperty(AbstractIdentifiableCodableDto.JSON_CODE)
    private String code;

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(HasDescriptionDto.JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(ProcessDto.JSON_NATURE)
    private ProcessNature nature;

    @JsonbProperty(ProcessDto.JSON_BASE_URL)
    private String baseUrl;

    @JsonbProperty(ProcessDto.JSON_PUBLIC_ACCESS)
    private Boolean publicAccess;
  }

  /**
   * Cette classe représente la réponse minimale d'obtention du catalogue public (CU_SVC_008).
   */
  @Getter
  @Setter
  class PublicCatalogResponseDto {

    @JsonbProperty(JSON_MODULES_GROUPS)
    private List<PublicCatalogModulesGroupDto> modulesGroups = new ArrayList<>();
  }

  /**
   * Cette classe représente un Groupe de modules dans le catalogue public (RG_SVC_VIS_04 :
   * aucun code ni identifiant ni ordre technique exposé).
   */
  @Getter
  @Setter
  class PublicCatalogModulesGroupDto {

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(JSON_MODULES)
    private List<PublicCatalogModuleDto> modules = new ArrayList<>();
  }

  /**
   * Cette classe représente un Module dans le catalogue public (RG_SVC_VIS_04 : sans code).
   */
  @Getter
  @Setter
  class PublicCatalogModuleDto {

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(HasDescriptionDto.JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(ModuleDto.JSON_ICON)
    private String icon;

    @JsonbProperty(JSON_PROCESSES)
    private List<PublicCatalogProcessDto> processes = new ArrayList<>();
  }

  /**
   * Cette classe représente un Processus dans le catalogue public (RG_SVC_VIS_04 : réponse
   * minimale sans code, ni identifiant, ni attribut interne).
   */
  @Getter
  @Setter
  class PublicCatalogProcessDto {

    @JsonbProperty(AbstractIdentifiableCodableNamableDto.JSON_NAME)
    private String name;

    @JsonbProperty(HasDescriptionDto.JSON_DESCRIPTION)
    private String description;

    @JsonbProperty(ProcessDto.JSON_NATURE)
    private ProcessNature nature;

    @JsonbProperty(ProcessDto.JSON_BASE_URL)
    private String baseUrl;
  }

}
