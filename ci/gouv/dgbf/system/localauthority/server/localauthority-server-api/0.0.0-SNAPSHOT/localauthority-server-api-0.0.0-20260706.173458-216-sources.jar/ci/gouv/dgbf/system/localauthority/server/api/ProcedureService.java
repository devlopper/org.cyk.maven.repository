package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCreateRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.time.LocalDate;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ProcedureDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = ProcedureService.PATH)
@Tag(name = "Gestion des  procedures")
public interface ProcedureService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "procedures";


  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_PROCEDURE";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";
  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_PROCEDURE";
  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";
  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_PROCEDURE";
  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";
  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_PROCEDURE";
  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";
  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_PROCEDURE";
  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";
  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_PROCEDURE";
  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Identifiant du service de création d'une procedure par modèle de procédure.
   */
  String CREATE_BY_MODEL_IDENTIFIER = "CREATION_PAR_MODELE_PROCEDURE";


  /**
   * Chemin du service de création d'une procedure par modèle de procédure.
   */
  String CREATE_BY_MODEL_PATH = "creation-par-modele";

  /**
   * Cette méthode permet de créer.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ProcedureCreateRequestDto request);


  /**
   * Cette méthode permet de créer par un modèle de procédure.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_BY_MODEL_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_BY_MODEL_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response createByModel(ProcedureCreateByModeleProcedureRequestDto request);

  /**
   * Cette méthode permet d'obtenir plusieurs.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {
          @Content(schema = @Schema(implementation = ProcedureGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette méthode permet d'obtenir {@link ProcedureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Cette méthode permet d'obtenir par identrifiant.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = ProcedureDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Cette méthode permet de mettre à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ProcedureUpdateRequestDto request);

  /**
   * Cette méthode permet de supprimer {@link ProcedureDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

  /**
   * Cette interface représente un enregistrement.
   *
   * @author Christian
   */
  interface ProcedureSaveRequestDto {

    /**
     * Identifiant JSON {@link TriennialProgramDto}.
     */
    String JSON_TRIENNIAL_PROGRAM_IDENTIFIER = ProcedureDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;


    /**
     * Identifiant json du champ d'ordre.
     */
    String JSON_ORDER = ProcedureDto.JSON_ORDER;

    /**
     * Identifiant json du champ de date detail.
     */
    String JSON_DATE = ProcedureDto.JSON_DATE;

    /**
     * Identifiant json du champ de date .
     */
    String JSON_OBSERVATION = ProcedureDto.JSON_OBSERVATION;


    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link TriennialProgramDto}.
     *
     * @return identifiant de {@link TriennialProgramDto}
     */
    String getTriennialProgramIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link TriennialProgramDto}.
     *
     * @param triennialProgramIdentifier identifiant de {@link TriennialProgramDto}
     */
    void setTriennialProgramIdentifier(String triennialProgramIdentifier);
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcedureCreateRequestDto extends AbstractNamableCreateRequestJsonDto
      implements ProcedureSaveRequestDto {

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_ORDER)
    private Integer order;

    @JsonbProperty(JSON_DATE)
    private LocalDate date;

    @JsonbProperty(JSON_OBSERVATION)
    private String observation;

  }

  /**
   * Cette classe représente la requête de création par modèle de procédure.
   *
   * @author Desysoft
   */
  @Getter
  @Setter
  class ProcedureCreateByModeleProcedureRequestDto
      extends AbstractCreateRequestDto {

    /**
     * Identifiant json de l'identifiant du modèle de procédure.
     */
    public static final String JSON_PROCEDURE_MODEL_IDENTIFIER =
        ProcedureDetailModelDto.JSON_PROCEDURE_MODEL_IDENTIFIER;

    /**
     * Identifiant json de l'identifiant du programme triennal.
     */
    public static final String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
        ProcedureDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

    @JsonbProperty(JSON_PROCEDURE_MODEL_IDENTIFIER)
    private String procedureModelIdentifier;
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

  }

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcedureGetManyResponseDto
      extends AbstractGetByPageResponseDto<ProcedureDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ProcedureDto> datas;
  }

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ProcedureUpdateRequestDto extends AbstractNamableUpdateRequestJsonDto
      implements ProcedureSaveRequestDto {

    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    @JsonbProperty(JSON_ORDER)
    private Integer order;

    @JsonbProperty(JSON_DATE)
    private LocalDate date;

    @JsonbProperty(JSON_OBSERVATION)
    private String observation;
  }
}
