package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService.UsersGroupCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UsersGroupService.UsersGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link UsersGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link UsersGroupDto}.

    @author Christian
               """)
public interface UsersGroupRequestMapper
    extends RequestMapper<UsersGroupDto, UsersGroupCreateRequestDto, UsersGroupUpdateRequestDto> {

}
