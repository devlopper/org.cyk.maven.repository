package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ValueReferenceService.ValueReferenceCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ValueReferenceService.ValueReferenceUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ValueReferenceDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ValueReferenceDto}.

    @author Christian
               """)
public interface ValueReferenceRequestMapper extends RequestMapper<ValueReferenceDto,
    ValueReferenceCreateRequestDto, ValueReferenceUpdateRequestDto> {

}
