package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasRoleIdentifier;
import ci.gouv.dgbf.system.user.server.api.shared.FilterHasUserIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link RoleSolicitationDto}.
 *
 * @author BoobaCool
 */
@Getter
@Setter
public class RoleSolicitationFilter extends AbstractIdentifiableFilter
    implements FilterHasUserIdentifier, FilterHasRoleIdentifier, FilterHasStatusCode {

  /**
   * Identifiant de l'utilisateur demandeur ("mes demandes").
   */
  private String userIdentifier;

  /**
   * Code du statut de la demande ({@link RoleSolicitationStatusCode}).
   */
  private String statusCode;

  /**
   * Identifiant du rôle demandé.
   */
  private String roleIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public RoleSolicitationFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public RoleSolicitationFilter() {
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateUserIdentifier(filter);
    updateStatusCode(filter);
    updateRoleIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterUserIdentifier(filter);
    updateFilterStatusCode(filter);
    updateFilterRoleIdentifier(filter);
  }
}
