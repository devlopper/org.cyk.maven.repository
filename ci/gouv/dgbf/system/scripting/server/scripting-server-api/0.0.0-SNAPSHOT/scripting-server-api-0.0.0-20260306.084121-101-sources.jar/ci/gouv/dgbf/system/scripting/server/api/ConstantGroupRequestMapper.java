package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConstantGroupService.ConstantGroupUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ConstantGroupDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ConstantGroupDto}.

    @author Christian
               """)
public interface ConstantGroupRequestMapper extends
    RequestMapper<ConstantGroupDto, ConstantGroupCreateRequestDto, ConstantGroupUpdateRequestDto> {

}
