package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupCreateRequestDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupGetManyResponseDto;
import ci.gouv.dgbf.system.identity.server.api.RegistrationNumberGroupService.RegistrationNumberGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente un client de {@link RegistrationNumberGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class RegistrationNumberGroupClient extends AbstractClient<RegistrationNumberGroupService>
    implements GetByIdentifier<RegistrationNumberGroupDto>, 
    GetMany<RegistrationNumberGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public RegistrationNumberGroupClient service(RegistrationNumberGroupService service) {
    return (RegistrationNumberGroupClient) super.service(service);
  }

  /**
   * {@link RegistrationNumberGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(RegistrationNumberGroupCreateRequestDto request) {
    return new CreateExecutor(RegistrationNumberGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link RegistrationNumberGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public RegistrationNumberGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<RegistrationNumberGroupGetManyResponseDto>(
    RegistrationNumberGroupGetManyResponseDto.class,
        RegistrationNumberGroupService.GET_MANY_IDENTIFIER).execute(() 
            -> service().getMany(request));
  }

  /**
   * {@link RegistrationNumberGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RegistrationNumberGroupGetManyResponseDto getMany(ProjectionDto projection, 
      FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link RegistrationNumberGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public RegistrationNumberGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<RegistrationNumberGroupDto>(RegistrationNumberGroupDto.class,
        RegistrationNumberGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link RegistrationNumberGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public RegistrationNumberGroupDto getOne(ProjectionDto projection, 
      FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link RegistrationNumberGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public RegistrationNumberGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<RegistrationNumberGroupDto>(RegistrationNumberGroupDto.class,
        RegistrationNumberGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link RegistrationNumberGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public RegistrationNumberGroupDto getByIdentifier(String identifier, 
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link RegistrationNumberGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(RegistrationNumberGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link RegistrationNumberGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(RegistrationNumberGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(RegistrationNumberGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link RegistrationNumberGroupService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
      String auditWho, String auditSession) {
    RegistrationNumberGroupUpdateRequestDto request = new RegistrationNumberGroupUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link RegistrationNumberGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

