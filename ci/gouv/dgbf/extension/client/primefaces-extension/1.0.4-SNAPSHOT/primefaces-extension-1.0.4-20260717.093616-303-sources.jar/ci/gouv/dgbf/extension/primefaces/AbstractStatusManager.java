package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base des gestionnaires de statut.
 *
 * @author Christian
 *
 * @param <T> Type du statut.
 */
public abstract class AbstractStatusManager<T extends Enum<T>> {

  protected Class<T> clazz;

  @Getter
  protected Map<String, String> badgeStyleClassMap;

  @Getter
  protected Map<T, String> severityMap;
  
  @Getter
  @Setter
  protected Function<T, String> nameBuilder;

  protected String badgeStyleClassFormat;

  /**
   * Cette méthode permet d'instanctier.
   */
  protected AbstractStatusManager(Class<T> clazz, Function<T, String> nameBuilder) {
    this.clazz = clazz;
    badgeStyleClassFormat = clazz.getSimpleName().toLowerCase() + "-status-badge-%s";
    this.nameBuilder = nameBuilder;
    buildBadgeStyleClassMap();
  }

  void buildBadgeStyleClassMap() {
    badgeStyleClassMap = new HashMap<>();
    Stream.of(clazz.getEnumConstants()).forEach(this::buildBadgeStyleClass);
  }

  String buildBadgeStyleClass(T enumeration) {
    return badgeStyleClassMap.put(enumeration.name(),
        badgeStyleClassFormat.formatted(enumeration.name().toLowerCase()));
  }

  /**
   * Cette méthode permet de construire le nom.
   *
   * @param status statut
   * @return nom construit
   */
  public String buildName(T status) {
    if (nameBuilder != null) {
      return nameBuilder.apply(status);
    }
    return status.toString();
  }

  /**
   * Cette méthode permet de savoir si l'énumeration est égale au nom.
   *
   * @param enumeration enumeration
   * @param name nom
   * @return vrai si l'énumeration est égale au nom
   */
  public boolean isEnumerationEqualsName(T enumeration, String name) {
    return Objects.equals(enumeration, Core.getEnumerationValueByName(clazz, name));
  }

  /**
   * Cette méthode permet d'obtenir le style class du badge.
   *
   * @param name nom
   * @return style class du badge
   */
  public String getBadgeStyleClassByName(String name) {
    return badgeStyleClassMap.get(name);
  }
  
  /**
   * Cette méthode permet d'obtenir la sévérité.
   *
   * @param status statut
   * @return sévérité
   */
  public String getSeverity(T status) {
    return Optional.ofNullable(severityMap).orElse(Collections.emptyMap()).get(status);
  }
}
