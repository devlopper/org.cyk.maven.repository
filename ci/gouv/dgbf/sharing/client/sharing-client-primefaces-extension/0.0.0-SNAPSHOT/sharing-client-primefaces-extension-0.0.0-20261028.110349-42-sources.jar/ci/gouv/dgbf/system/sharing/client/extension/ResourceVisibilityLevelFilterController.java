package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelFilter;
import jakarta.enterprise.context.Dependent;

/**
 * Cette classe représente le contrôleur de filtre de {@link ResourceVisibilityLevelDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceVisibilityLevelFilterController
    extends AbstractFilterController<ResourceVisibilityLevelFilter> {

  /**
   * Cette méthode permet de construire.
   */
  public ResourceVisibilityLevelFilterController() {
    super(ResourceVisibilityLevelFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
  }
}
