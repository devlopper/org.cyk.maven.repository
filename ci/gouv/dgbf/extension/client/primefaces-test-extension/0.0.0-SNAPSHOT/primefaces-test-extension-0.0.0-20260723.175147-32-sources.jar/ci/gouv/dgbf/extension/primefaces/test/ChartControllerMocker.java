package ci.gouv.dgbf.extension.primefaces.test;

import ci.gouv.dgbf.extension.primefaces.component.chart.BarChart;
import ci.gouv.dgbf.extension.primefaces.component.chart.ChartController;
import ci.gouv.dgbf.extension.primefaces.component.chart.LineChart;
import ci.gouv.dgbf.extension.primefaces.component.chart.PieChart;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;
import org.mockito.Mockito;

/**
 * Cette classe représente un mocker de {@link ChartController}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class ChartControllerMocker {

  /**
   * Cette méthode permet de mocker.
   *
   * @return {@link ChartController}
   */
  public ChartController mock() {
    ChartController controller = Mockito.mock(ChartController.class);
    
    PieChart.Builder pieChartBuilder = PieChart.newBuilder();
    Mockito.when(controller.pieChartBuilder()).thenReturn(pieChartBuilder);
    PieChart pieChart = Mockito.mock(PieChart.class);
    Mockito.when(controller.getPieChart()).thenReturn(pieChart);
    
    BarChart.Builder barChartBuilder = BarChart.newBuilder();
    Mockito.when(controller.barChartBuilder()).thenReturn(barChartBuilder);
    BarChart barChart = Mockito.mock(BarChart.class);
    Mockito.when(controller.getBarChart()).thenReturn(barChart);
    
    LineChart.Builder lineChartBuilder = LineChart.newBuilder();
    Mockito.when(controller.lineChartBuilder()).thenReturn(lineChartBuilder);
    LineChart lineChart = Mockito.mock(LineChart.class);
    Mockito.when(controller.getLineChart()).thenReturn(lineChart);
    
    return controller;
  }

}
