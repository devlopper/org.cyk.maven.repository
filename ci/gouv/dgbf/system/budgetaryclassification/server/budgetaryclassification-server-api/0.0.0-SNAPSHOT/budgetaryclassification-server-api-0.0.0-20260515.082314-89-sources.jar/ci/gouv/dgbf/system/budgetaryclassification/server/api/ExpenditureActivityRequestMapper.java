package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService.ExpenditureActivityCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.ExpenditureActivityService.ExpenditureActivityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ExpenditureActivityDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ExpenditureActivityDto}.

    @author Arnaud
               """)
public interface ExpenditureActivityRequestMapper extends RequestMapper<ExpenditureActivityDto,
    ExpenditureActivityCreateRequestDto, ExpenditureActivityUpdateRequestDto> {

}
