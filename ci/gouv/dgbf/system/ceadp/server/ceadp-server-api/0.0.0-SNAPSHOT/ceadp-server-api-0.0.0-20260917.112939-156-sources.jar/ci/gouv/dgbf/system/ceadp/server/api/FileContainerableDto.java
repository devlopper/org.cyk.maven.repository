package ci.gouv.dgbf.system.ceadp.server.api;

/**
 * Cette interface représente un conteneur de fichier.
 *
 * @author Christian
 *
 */
public interface FileContainerableDto extends FileContainerable {

  /**
   * Identifiant json {@link FileContainerableDto#getFileCountAsString()}.
   */
  String JSON_FILE_COUNT_AS_STRING = "nombreFichier";
}
