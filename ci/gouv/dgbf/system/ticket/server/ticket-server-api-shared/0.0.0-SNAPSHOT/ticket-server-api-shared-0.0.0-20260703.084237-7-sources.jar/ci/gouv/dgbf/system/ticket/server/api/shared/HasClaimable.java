package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de peut être pris en charge.
 *
 * @author Christian
 */
public interface HasClaimable extends HasField {

  /**
   * Cette méthode permet d'obtenir peut être pris en charge.
   *
   * @return peut être pris en charge
   */
  Boolean getClaimable();

  /**
   * Cette méthode permet d'assigner peut être pris en charge.
   *
   * @param claimable peut être pris en charge
   */
  void setClaimable(Boolean claimable);

  /**
   * Identifiant java de peut être pris en charge.
   */
  String FIELD_CLAIMABLE = "claimable";
}
