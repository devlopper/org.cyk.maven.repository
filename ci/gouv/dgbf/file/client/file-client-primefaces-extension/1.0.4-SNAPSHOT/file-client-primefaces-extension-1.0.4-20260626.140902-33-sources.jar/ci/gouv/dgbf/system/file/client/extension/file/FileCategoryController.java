package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryClient;
import ci.gouv.dgbf.system.file.server.api.FileCategoryDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryRequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link FileCategoryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FileCategoryController extends AbstractController {

  @Inject
  FileCategoryClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  FileCategoryRequestMapper requestMapper;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = FileCategoryDto.NAME;
  }
  
  /**
   * Cette méthode permet d'initialiser.
   */
  public void initialize() {
    listController.setEntityClass(FileCategoryDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(FileCategoryService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentifiableCodableDto.JSON_CODE,
            AbstractIdentifiableCodableNamableDto.JSON_NAME));

    listController.initialize();

    listController.getCreateController().setFunction(entity -> {
      FileCategoryCreateRequestDto request = requestMapper.mapCreate((FileCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    });
    
    listController.getUpdateController().setFunction(entity -> {
      FileCategoryUpdateRequestDto request = requestMapper.mapUpdate((FileCategoryDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    });
  }
}
