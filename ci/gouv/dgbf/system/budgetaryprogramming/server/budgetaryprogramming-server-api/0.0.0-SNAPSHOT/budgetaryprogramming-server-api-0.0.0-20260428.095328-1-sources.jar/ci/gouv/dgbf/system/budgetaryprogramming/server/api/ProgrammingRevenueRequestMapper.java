package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingRevenueService.ProgrammingRevenueCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.ProgrammingRevenueService.ProgrammingRevenueUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProgrammingRevenueDto}.
 *
 * @author Christian
 */
@Mapper
@Javadoc(
    """
    Cette interface représente le mapping de requête et {@link ProgrammingRevenueDto}.

    @author Christian
               """)
public interface ProgrammingRevenueRequestMapper
    extends RequestMapper<ProgrammingRevenueDto, ProgrammingRevenueCreateRequestDto,
        ProgrammingRevenueUpdateRequestDto> {

}
