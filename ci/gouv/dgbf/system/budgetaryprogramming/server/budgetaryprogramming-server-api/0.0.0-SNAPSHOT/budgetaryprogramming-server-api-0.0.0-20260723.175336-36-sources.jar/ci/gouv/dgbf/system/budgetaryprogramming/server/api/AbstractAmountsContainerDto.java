package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasArbitratedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN1AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN2AsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasInputtedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasIntegratedAmountNDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountN1Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountN2Dto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountNAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasValidatedAmountNDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public abstract class AbstractAmountsContainerDto extends AbstractIdentifiableAuditableDto
    implements
    // InputtedAmount
    HasInputtedAmountNDto, HasInputtedAmountNAsStringDto, HasInputtedAmountN1Dto,
    HasInputtedAmountN1AsStringDto, HasInputtedAmountN2Dto, HasInputtedAmountN2AsStringDto,
    // ArbitratedAmount
    HasArbitratedAmountNDto, HasArbitratedAmountNAsStringDto, HasArbitratedAmountN1Dto,
    HasArbitratedAmountN1AsStringDto, HasArbitratedAmountN2Dto, HasArbitratedAmountN2AsStringDto,
    // ValidatedAmount
    HasValidatedAmountNDto, HasValidatedAmountNAsStringDto, HasValidatedAmountN1Dto,
    HasValidatedAmountN2Dto,
    // IntegratedAmount
    HasIntegratedAmountNDto, HasIntegratedAmountNAsStringDto, HasIntegratedAmountN1Dto,
    HasIntegratedAmountN2Dto {

  // Inputted

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N)
  protected Long inputtedAmountN;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N_AS_STRING)
  protected String inputtedAmountNAsString;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N1)
  protected Long inputtedAmountN1;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N1_AS_STRING)
  protected String inputtedAmountN1AsString;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N2)
  protected Long inputtedAmountN2;

  @JsonbProperty(JSON_INPUTTED_AMOUNT_N2_AS_STRING)
  protected String inputtedAmountN2AsString;

  // Arbitrated

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N)
  protected Long arbitratedAmountN;

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N_AS_STRING)
  protected String arbitratedAmountNAsString;

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1)
  protected Long arbitratedAmountN1;

  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N1_AS_STRING)
  protected String arbitratedAmountN1AsString;
  
  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2)
  protected Long arbitratedAmountN2;
  
  @JsonbProperty(JSON_ARBITRATED_AMOUNT_N2_AS_STRING)
  protected String arbitratedAmountN2AsString;

  // Validated

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N)
  protected Long validatedAmountN;

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N_AS_STRING)
  protected String validatedAmountNAsString;

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N1)
  protected Long validatedAmountN1;

  @JsonbProperty(JSON_VALIDATED_AMOUNT_N2)
  protected Long validatedAmountN2;

  // Integrated

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N)
  protected Long integratedAmountN;

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N_AS_STRING)
  protected String integratedAmountNAsString;

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N1)
  protected Long integratedAmountN1;

  @JsonbProperty(JSON_INTEGRATED_AMOUNT_N2)
  protected Long integratedAmountN2;
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
