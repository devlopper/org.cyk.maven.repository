package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et
* {@link AdministrativeUnitPunctualMeasureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-17T13:47:55+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class AdministrativeUnitPunctualMeasureRequestMapperImpl implements AdministrativeUnitPunctualMeasureRequestMapper {

    @Override
    public AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureCreateRequestDto mapCreate(AdministrativeUnitPunctualMeasureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureCreateRequestDto administrativeUnitPunctualMeasureCreateRequestDto = new AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureCreateRequestDto();

        administrativeUnitPunctualMeasureCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitPunctualMeasureCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        administrativeUnitPunctualMeasureCreateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        administrativeUnitPunctualMeasureCreateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        administrativeUnitPunctualMeasureCreateRequestDto.setPunctualMeasureIdentifier( arg0.getPunctualMeasureIdentifier() );
        administrativeUnitPunctualMeasureCreateRequestDto.setAmount( arg0.getAmount() );

        return administrativeUnitPunctualMeasureCreateRequestDto;
    }

    @Override
    public AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureUpdateRequestDto mapUpdate(AdministrativeUnitPunctualMeasureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureUpdateRequestDto administrativeUnitPunctualMeasureUpdateRequestDto = new AdministrativeUnitPunctualMeasureService.AdministrativeUnitPunctualMeasureUpdateRequestDto();

        administrativeUnitPunctualMeasureUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setBudgetIdentifier( arg0.getBudgetIdentifier() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setAdministrativeUnitIdentifier( arg0.getAdministrativeUnitIdentifier() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setPunctualMeasureIdentifier( arg0.getPunctualMeasureIdentifier() );
        administrativeUnitPunctualMeasureUpdateRequestDto.setAmount( arg0.getAmount() );

        return administrativeUnitPunctualMeasureUpdateRequestDto;
    }
}
