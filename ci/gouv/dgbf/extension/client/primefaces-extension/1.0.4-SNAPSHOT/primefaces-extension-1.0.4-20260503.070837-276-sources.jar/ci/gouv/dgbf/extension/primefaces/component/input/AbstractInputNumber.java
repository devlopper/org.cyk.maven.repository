package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une saisie de nombre.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractInputNumber<T extends Number> extends AbstractInput<T> {

  String minValue;
  String maxValue;
  String thousandSeparator;
  
  String decimalPlaces;
  String decimalSeparator;
  
  protected AbstractInputNumber() {
    minValue = "-10000000000000";
    maxValue = "10000000000000";
    thousandSeparator = " ";
    
    decimalPlaces = "0";
    decimalSeparator = ".";
  }
}
