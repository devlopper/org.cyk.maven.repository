package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N.
 *
 * @author Christian
 */
public interface HasRemainingAmountToArbitrateN {

  /**
   * Obtient le montant restant à arbitrer pour l'année N.
   *
   * @return le montant restant à arbitrer pour l'année N
   */
  Long getRemainingAmountToArbitrateN();

  /**
   * Définit le montant restant à arbitrer pour l'année N.
   *
   * @param remainingAmountToArbitrateN le montant restant à arbitrer pour l'année N
   */
  void setRemainingAmountToArbitrateN(Long remainingAmountToArbitrateN);

  /**
   * Identifiant java du montant restant à arbitrer pour l'année N.
   */
  String FIELD_REMAINING_AMOUNT_TO_ARBITRATE_N = "remainingAmountToArbitrateN";
}