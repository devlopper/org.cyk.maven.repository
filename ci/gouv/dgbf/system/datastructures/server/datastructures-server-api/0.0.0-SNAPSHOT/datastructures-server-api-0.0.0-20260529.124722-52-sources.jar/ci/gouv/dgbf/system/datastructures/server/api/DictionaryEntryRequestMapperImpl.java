package ci.gouv.dgbf.system.datastructures.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link DictionaryEntryDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-29T12:47:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class DictionaryEntryRequestMapperImpl implements DictionaryEntryRequestMapper {

    @Override
    public DictionaryEntryService.DictionaryEntryCreateRequestDto mapCreate(DictionaryEntryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryEntryService.DictionaryEntryCreateRequestDto dictionaryEntryCreateRequestDto = new DictionaryEntryService.DictionaryEntryCreateRequestDto();

        dictionaryEntryCreateRequestDto.setCode( arg0.getCode() );
        dictionaryEntryCreateRequestDto.setName( arg0.getName() );
        dictionaryEntryCreateRequestDto.setDictionaryIdentifier( arg0.getDictionaryIdentifier() );
        dictionaryEntryCreateRequestDto.setValueType( arg0.getValueType() );
        dictionaryEntryCreateRequestDto.setDefaultValue( arg0.getDefaultValue() );

        return dictionaryEntryCreateRequestDto;
    }

    @Override
    public DictionaryEntryService.DictionaryEntryUpdateRequestDto mapUpdate(DictionaryEntryDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        DictionaryEntryService.DictionaryEntryUpdateRequestDto dictionaryEntryUpdateRequestDto = new DictionaryEntryService.DictionaryEntryUpdateRequestDto();

        dictionaryEntryUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        dictionaryEntryUpdateRequestDto.setCode( arg0.getCode() );
        dictionaryEntryUpdateRequestDto.setName( arg0.getName() );
        dictionaryEntryUpdateRequestDto.setDictionaryIdentifier( arg0.getDictionaryIdentifier() );
        dictionaryEntryUpdateRequestDto.setValueType( arg0.getValueType() );
        dictionaryEntryUpdateRequestDto.setDefaultValue( arg0.getDefaultValue() );

        return dictionaryEntryUpdateRequestDto;
    }
}
