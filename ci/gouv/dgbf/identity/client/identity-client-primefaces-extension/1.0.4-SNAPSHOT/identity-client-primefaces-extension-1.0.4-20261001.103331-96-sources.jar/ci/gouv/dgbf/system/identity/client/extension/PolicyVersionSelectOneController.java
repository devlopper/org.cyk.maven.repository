package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionClient;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionService.PolicyVersionGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PolicyVersionDto}, utilisé pour
 * filtrer les consentements par version de politique.
 *
 * @author Desysoft
 *
 */
@Dependent
public class PolicyVersionSelectOneController extends AbstractSelectOneIdentifiableController<
    PolicyVersionDto, PolicyVersionGetManyResponseDto, PolicyVersionClient> {

  @Getter
  @Inject
  PolicyVersionClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected PolicyVersionSelectOneController() {
    super(PolicyVersionDto.class);
    getProjection().addNames(PolicyVersionDto.JSON_POLICY_AS_STRING,
        PolicyVersionDto.JSON_VERSION);
  }

  @Override
  protected String buildSelectItemLabel(PolicyVersionDto dto) {
    return String.format("%s - v%d", dto.getPolicyAsString(), dto.getVersion());
  }
}
