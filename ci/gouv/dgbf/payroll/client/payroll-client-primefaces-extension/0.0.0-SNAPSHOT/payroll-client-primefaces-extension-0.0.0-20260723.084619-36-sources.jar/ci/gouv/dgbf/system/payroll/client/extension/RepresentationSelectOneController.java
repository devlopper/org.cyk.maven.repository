package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationClient;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationDto;
import ci.gouv.dgbf.system.payroll.server.api.RepresentationService.RepresentationGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link RepresentationDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RepresentationSelectOneController extends AbstractSelectOneIdentifiableController<
    RepresentationDto, RepresentationGetManyResponseDto, RepresentationClient> {

  @Inject
  @Getter
  RepresentationClient client;

  protected RepresentationSelectOneController() {
    super(RepresentationDto.class, SelectItemLabelStrategy.CODE_NAME);
  }
}
