package ci.gouv.dgbf.system.payrollbudget.server.api;

/**
 * {@link EmployeeContainer}.
 */
public interface EmployeeContainerDto extends EmployeeContainer {

  /**
   * Identifiant json du nombre d'employé.
   */
  String JSON_EMPLOYEE_COUNT = "nombreEmploye";
  
  /**
   * Identifiant json de la représentation en chaine de caractères du nombre de employé.
   */
  String JSON_EMPLOYEE_COUNT_AS_STRING = "nombreEmployeChaine";
  
  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   */
  String JSON_INCOMING_EMPLOYEE_COUNT_AS_STRING = "incomingEmployeeCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   */
  String JSON_OUTGOING_EMPLOYEE_COUNT_AS_STRING = "outgoingEmployeeCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de employé
   * ayant {@link MovementDto} ayant {@link MovementTypeDto} avec
   * {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  String JSON_ADMINISTRATIVE_UNIT_CHANGE_EMPLOYEE_COUNT_AS_STRING =
      "administrativeUnitChangeEmployeeCountAsString";
}
