package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une identité.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class IdentityDto extends AbstractIdentifiableDto {

  /**
   * Adresse email.
   */
  @JsonbProperty(value = JSON_EMAIL_ADDRESS)
  private String emailAddress;

  /**
   * Matricule.
   */
  @JsonbProperty(value = JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Nom.
   */
  @JsonbProperty(value = JSON_FIRST_NAME)
  private String firstName;

  /**
   * Prénoms.
   */
  @JsonbProperty(value = JSON_LAST_NAMES)
  private String lastNames;

  /**
   * Représentation en chaine de caractères du genre.
   */
  @JsonbProperty(value = JSON_GENDER_AS_STRING)
  private String genderAsString;

  /**
   * Représentation en chaine de caractères de l'unité administrative.
   */
  @JsonbProperty(value = JSON_ADMINISTRATIVE_UNIT_AS_STRING)
  private String administrativeUnitAsString;
  
  /**
   * Cette méthode permet de formatter la réprésentation en chaine de caractères.
   *
   * @param registrationNumber matricule
   * @param emailAddress adresse email
   * @param firstName nom
   * @param lastNames prénoms
   * @return réprésentation en chaine de caractères
   */
  public static String formatAsString(String registrationNumber, String emailAddress,
      String firstName, String lastNames) {
    registrationNumber = Core.getOrDefaultIfBlank(registrationNumber, null);
    emailAddress = Core.getOrDefaultIfBlank(emailAddress, null);
    firstName = Core.getOrDefaultIfBlank(firstName, null);
    lastNames = Core.getOrDefaultIfBlank(lastNames, null);
    String identifier = Core.getOrDefaultIfNull(registrationNumber, emailAddress);
    if (Core.isAllNull(identifier, firstName, lastNames)) {
      return Constant.EMPTY_STRING;
    }
    return String.format("%s - %s %s", identifier, firstName, lastNames);
  }

  /**
   * Identifiant json de {@link IdentityDto}.
   */
  public static final String JSON_THIS = "identite";
  
  /**
   * Identifiant json identifiant de {@link IdentityDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idIdentite";
  
  /**
   * Identifiant json représentation en chaine de caractères de {@link IdentityDto}.
   */
  public static final String JSON_THIS_AS_STRING = "identiteChaine";
  
  /**
   * Identifiant json champ {@link #emailAddress}.
   */
  public static final String JSON_EMAIL_ADDRESS = "adresseEmail";
  
  /**
   * Identifiant json champ {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";
  
  /**
   * Identifiant json champ {@link #firstName}.
   */
  public static final String JSON_FIRST_NAME = "nom";
  
  /**
   * Identifiant json champ {@link #lastNames}.
   */
  public static final String JSON_LAST_NAMES = "prenoms";

  /**
   * Identifiant json champ {@link #administrativeUnitAsString}.
   */
  public static final String JSON_ADMINISTRATIVE_UNIT_AS_STRING = "uniteAdministrativeChaine";

  /**
   * Identifiant json champ {@link #genderAsString}.
   */
  public static final String JSON_GENDER_AS_STRING = "genreChaine";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "identité";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
