package ci.gouv.dgbf.extension.primefaces.page;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.IdentifiableFilterGetter;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette interface représente la base de page d'identifiable.
 *
 * @param <I> type de l'identifiable
 * @param <F> type de filtre de l'identifiable
 * @author Christian
 */
public interface IdentifiablePage<I, F extends AbstractIdentifiableFilter> {

  /** Mode historique conservé pour les consommateurs existants. */
  default IdentifiablePageMode getIdentifiablePageMode() {
    return IdentifiablePageMode.LEGACY;
  }

  /** Modèle stable requis lorsque DISPLAY_STATE est activé. */
  default IdentifiablePageModel getIdentifiablePageModel() {
    return null;
  }

  /** Active explicitement le repli en mode DISPLAY_STATE. */
  default boolean isIdentifierFallbackEnabled() {
    return false;
  }

  /** À adapter pour effacer la ressource précédente et tous ses contrôleurs enfants. */
  default void clearIdentifiablePageContent() {}

  /** Classification des seules exceptions issues de l'appel au service. */
  default IdentifiablePageStatus classifyIdentifiableRetrievalFailure(RuntimeException failure) {
    return IdentifiablePageStatus.ERROR;
  }

  /** Permet de ne pas révéler l'existence d'une ressource interdite. */
  default boolean isIdentifiableAccessDeniedHidden() {
    return false;
  }

  /** Classe du DTO dont le champ statique NAME fournit le libellé public. */
  default Class<?> getIdentifiableDtoClass() {
    return null;
  }

  /** Libellé métier personnalisable, sans exposer le nom Java du DTO. */
  default String getIdentifiableResourceName() {
    Class<?> dtoClass = getIdentifiableDtoClass();
    if (dtoClass == null) {
      return "ressource";
    }
    Field field = Core.getField(dtoClass, "NAME");
    if (field == null || !Modifier.isStatic(field.getModifiers())) {
      return "ressource";
    }
    Object name = Core.getFieldValue(field.getDeclaringClass(), "NAME");
    return name instanceof String text && !text.isBlank() ? text.strip() : "ressource";
  }

  /** Texte public, personnalisable sans exposer l'exception technique. */
  default String getIdentifiablePageMessage(IdentifiablePageStatus status) {
    String message = switch (status) {
      case MISSING_IDENTIFIER -> "Aucune ressource n'a été demandée.";
      case NO_RESOURCE_AVAILABLE -> "Aucune ressource disponible.";
      case NOT_FOUND -> "La ressource demandée est introuvable.";
      case ACCESS_DENIED -> isIdentifiableAccessDeniedHidden()
          ? getIdentifiablePageMessage(IdentifiablePageStatus.NOT_FOUND)
          : "Vous n'êtes pas autorisé à accéder à cette ressource.";
      case ERROR -> "Impossible de charger la ressource demandée.";
      default -> null;
    };
    String name = getIdentifiableResourceName();
    if (message == null || "ressource".equals(name)) {
      return message;
    }
    return switch (status) {
      case MISSING_IDENTIFIER -> "Sélection " + name + " requise";
      case NO_RESOURCE_AVAILABLE -> name + " indisponible";
      case NOT_FOUND -> name + " introuvable";
      case ACCESS_DENIED -> isIdentifiableAccessDeniedHidden()
          ? message : "Accès à " + name + " non autorisé";
      default -> "Chargement " + name + " impossible";
    };
  }

  private IdentifiablePageModel requireIdentifiablePageModel() {
    return Objects.requireNonNull(getIdentifiablePageModel(),
        "Modèle IdentifiablePage requis en mode DISPLAY_STATE");
  }

  private void updateIdentifiablePageStatus(IdentifiablePageStatus status) {
    IdentifiablePageModel model = requireIdentifiablePageModel();
    String message = getIdentifiablePageMessage(status);
    model.update(status, message, isIdentifiableAccessDeniedHidden());
    model.setTitle("ressource".equals(getIdentifiableResourceName()) ? null : message);
  }

  /**
   * Cette méthode permet d'instantier le filtre.
   *
   * @return filtre
   */
  default IdentifiableFilterGetter<F> instantiateFilter() {
    IdentifiableFilterGetter<F> filterGetter =
        new IdentifiableFilterGetter<F>(getIdentifiableFilterClass())
            .onBlankIdentifier(this::processFilterWhenIdentifierBlank)
            .connectedUserSharedSelectionPageOutcome(getConnectedUserSharedSelectionPageOutcome());
    filterGetter.viewParameterValueGetter().authorized(isViewParameterValueAuthorized());
    filterGetter.onFilterPresent(onFilterPresent());
    return filterGetter;
  }

  Class<F> getIdentifiableFilterClass();

  void processFilterWhenIdentifierBlank(F filter);

  String getConnectedUserSharedSelectionPageOutcome();

  /**
   * Cette méthode permet de savoir si la valeur du parametre de la vue est autorisée.
   *
   * @return vrai si la valeur du parametre de la vue est autorisée
   */
  default Boolean isViewParameterValueAuthorized() {
    return true;
  }

  /**
   * Cette méthode permet d'instantier et d'obtenir le filtre.
   *
   * @return filtre
   */
  default F instantiateAndGetFilter() {
    if (getIdentifiablePageMode() == IdentifiablePageMode.DISPLAY_STATE) {
      IdentifiablePageModel model = requireIdentifiablePageModel();
      model.validate();
      updateIdentifiablePageStatus(IdentifiablePageStatus.LOADING);
      clearIdentifiablePageContent();
      IdentifiableFilterGetter<F> filterGetter = instantiateFilter();
      boolean[] fallbackAttempted = {false};
      if (isIdentifierFallbackEnabled()) {
        Consumer<F> fallback = Objects.requireNonNull(filterGetter.onBlankIdentifier(),
            "Stratégie de repli requise");
        filterGetter.onBlankIdentifier(filter -> {
          fallbackAttempted[0] = true;
          fallback.accept(filter);
        });
      } else {
        filterGetter.onBlankIdentifier(null);
      }
      filterGetter.onBlankFilter(filter ->
          updateIdentifiablePageStatus(fallbackAttempted[0]
              ? IdentifiablePageStatus.NO_RESOURCE_AVAILABLE
              : IdentifiablePageStatus.MISSING_IDENTIFIER));
      return filterGetter.get();
    }
    IdentifiableFilterGetter<F> filterGetter = instantiateFilter();
    return filterGetter.get();
  }

  OneRetrievable<I> getIdentifiableRetriever();

  /**
   * Cette méthode permet d'obtenir un consommateur du filtre.
   *
   * @return consommateur du filtre
   */
  default Consumer<F> onFilterPresent() {
    return filter -> {
      if (getIdentifiablePageMode() == IdentifiablePageMode.DISPLAY_STATE) {
        retrieveIdentifiableWithState(filter);
        return;
      }
      I identifiable = getIdentifiableRetriever().getOne(getIdentifiableProjection(),
          filter.toDto(), getUserIdentifier(), null);
      initializeWhenFilterPresent(identifiable);
    };
  }

  private void retrieveIdentifiableWithState(F filter) {
    // Préparer les arguments hors du bloc de classification des erreurs du service.
    OneRetrievable<I> retriever = Objects.requireNonNull(getIdentifiableRetriever());
    ProjectionDto projection = getIdentifiableProjection();
    FilterDto dto = filter.toDto();
    String userIdentifier = getUserIdentifier();
    I identifiable;
    try {
      identifiable = retriever.getOne(projection, dto, userIdentifier, null);
    } catch (RuntimeException failure) {
      IdentifiablePageStatus status = classifyIdentifiableRetrievalFailure(failure);
      if (status != IdentifiablePageStatus.NOT_FOUND
          && status != IdentifiablePageStatus.ACCESS_DENIED
          && status != IdentifiablePageStatus.ERROR) {
        throw new IllegalArgumentException("État de classification d'erreur invalide", failure);
      }
      Logger.getLogger(IdentifiablePage.class.getName()).log(Level.WARNING,
          "Échec de récupération de la ressource", failure);
      updateIdentifiablePageStatus(status);
      if (status == IdentifiablePageStatus.NOT_FOUND) {
        initializeWhenFilterPresent(null);
      }
      return;
    }
    if (identifiable == null) {
      updateIdentifiablePageStatus(IdentifiablePageStatus.NOT_FOUND);
      initializeWhenFilterPresent(null);
    } else {
      initializeWhenFilterPresent(identifiable);
      updateIdentifiablePageStatus(IdentifiablePageStatus.AVAILABLE);
    }
  }

  /**
   * Cette méthode permet d'obtenir la projection.
   *
   * @return projection
   */
  default ProjectionDto getIdentifiableProjection() {
    return new ProjectionDto().addNames(HasIdentifierDto.JSON_IDENTIFIER);
  }

  String getUserIdentifier();

  /**
   * Cette méthode permet d'initialiser lorsque le filtre est présent.
   *
   * @param identifiable identifiable
   */
  default void initializeWhenFilterPresent(I identifiable) {
    if (identifiable == null) {
      initializeWhenIdentifiableNull();
    } else {
      initializeWhenIdentifiableNotNull(identifiable);
    }
  }

  /**
   * Cette méthode d'initialiser lorsque l'identifiable est nul.
   */
  default void initializeWhenIdentifiableNull() {}

  /**
   * Cette méthode d'initialiser lorsque l'identifiable est non nul.
   */
  default void initializeWhenIdentifiableNotNull(I identifiable) {}

}
