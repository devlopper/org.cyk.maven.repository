package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasActivityIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasEconomicNatureIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasExerciseIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasFundingSourceIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasLessorIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ExpenditureDto}.
 *
 * @author Christian
 */
@Getter
@Setter
public class ExpenditureFilter extends AbstractIdentifiableFilter
    implements FilterHasExerciseIdentifier, FilterHasActivityIdentifier,
    FilterHasEconomicNatureIdentifier, FilterHasFundingSourceIdentifier, FilterHasLessorIdentifier {

  String exerciseIdentifier;

  String activityIdentifier;
  
  String economicNatureIdentifier;
  
  String fundingSourceIdentifier;
  
  String lessorIdentifier;
  
  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateExerciseIdentifier(filter);
    updateActivityIdentifier(filter);
    updateEconomicNatureIdentifier(filter);
    updateFundingSourceIdentifier(filter);
    updateLessorIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterExerciseIdentifier(filter);
    updateFilterActivityIdentifier(filter);
    updateFilterEconomicNatureIdentifier(filter);
    updateFilterFundingSourceIdentifier(filter);
    updateFilterLessorIdentifier(filter);
  }

}
