package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un identifiant de section.
 *
 * @author Christian
 */
public interface HasSectionIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de la section.
   *
   * @return identifiant de la section
   */
  String getSectionIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de la section.
   *
   * @param sectionIdentifier identifiant de la section
   */
  void setSectionIdentifier(String sectionIdentifier);

  /**
   * Identifiant java de l'identifiant de la section.
   */
  String FIELD_SECTION_IDENTIFIER = "sectionIdentifier";
}
