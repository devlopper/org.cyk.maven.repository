package ci.gouv.dgbf.system.datastructures.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeCreateRequestDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeGetManyResponseDto;
import ci.gouv.dgbf.system.datastructures.server.api.ValueSelectorFilterAttributeService.ValueSelectorFilterAttributeUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ValueSelectorFilterAttributeService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ValueSelectorFilterAttributeClient
    extends AbstractClient<ValueSelectorFilterAttributeService>
    implements GetByIdentifier<ValueSelectorFilterAttributeDto>,
    GetMany<ValueSelectorFilterAttributeGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ValueSelectorFilterAttributeClient service(ValueSelectorFilterAttributeService service) {
    return (ValueSelectorFilterAttributeClient) super.service(service);
  }

  /**
   * {@link ValueSelectorFilterAttributeService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ValueSelectorFilterAttributeCreateRequestDto request) {
    return new CreateExecutor(ValueSelectorFilterAttributeService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorFilterAttributeGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ValueSelectorFilterAttributeGetManyResponseDto>(
        ValueSelectorFilterAttributeGetManyResponseDto.class,
        ValueSelectorFilterAttributeService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSelectorFilterAttributeGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ValueSelectorFilterAttributeDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ValueSelectorFilterAttributeDto>(
        ValueSelectorFilterAttributeDto.class,
        ValueSelectorFilterAttributeService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ValueSelectorFilterAttributeDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ValueSelectorFilterAttributeDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ValueSelectorFilterAttributeDto>(
        ValueSelectorFilterAttributeDto.class,
        ValueSelectorFilterAttributeService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ValueSelectorFilterAttributeDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ValueSelectorFilterAttributeService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ValueSelectorFilterAttributeUpdateRequestDto request) {
    return new IdentifiableExecutor(ValueSelectorFilterAttributeService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ValueSelectorFilterAttributeService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ValueSelectorFilterAttributeService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
