package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link TicketDto}.
 *
 * @author Arnaud
 *
 */
@Getter
public enum TicketStatus {

  /**
   * Créé.
   */
  CREATED(TicketStatusCode.CREATED, "Créé", "Création", "Créer"),

  /**
   * Pris en charge.
   */
  IN_PROGRESS(TicketStatusCode.IN_PROGRESS, "Pris en charge", "Prise en charge",
      "Prendre en charge"),

  /**
   * Résolu.
   */
  RESOLVED(TicketStatusCode.RESOLVED, "Résolu", "Résolution", "Résoudre"),

  /**
   * Satisfait.
   */
  SATISFIED(TicketStatusCode.SATISFIED, "Satisfait", "Satisfaction", "Satisfaire"),

  /**
   * Non satisfait.
   */
  UNSATISFIED(TicketStatusCode.UNSATISFIED, "Non satisfait", "Insatisfaction", "Insatisfaire");


  private TicketStatus(String code, String name, String actionName, String actionVerb) {
    this.code = code;
    this.name = name;
    this.actionName = actionName;
    this.actionVerb = actionVerb;
  }

  private String code;
  private String name;
  private String actionName;
  private String actionVerb;
  private Set<TicketStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link TicketStatus} par code.
   *
   * @param code code
   * @return {@link TicketStatus}
   */
  public static TicketStatus getByCode(String code) {
    return Stream.of(TicketStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }

  static {
    CREATED.previous = Collections.emptySet();
    IN_PROGRESS.previous = Core.getSet(List.of(CREATED, UNSATISFIED));
    RESOLVED.previous = Core.getSet(List.of(IN_PROGRESS));
    SATISFIED.previous = Core.getSet(List.of(RESOLVED));
    UNSATISFIED.previous = Core.getSet(List.of(RESOLVED));
  }
}
