package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurLocalityService.FurLocalityCreateRequestDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.FurLocalityService.FurLocalityUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FurLocalityDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FurLocalityDto}.

    @author akm
               """)
public interface FurLocalityRequestMapper extends
    RequestMapper<FurLocalityDto, FurLocalityCreateRequestDto,
        FurLocalityUpdateRequestDto> {

}
