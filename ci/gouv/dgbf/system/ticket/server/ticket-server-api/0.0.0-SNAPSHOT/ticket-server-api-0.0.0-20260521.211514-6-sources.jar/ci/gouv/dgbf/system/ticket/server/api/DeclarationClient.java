package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.CreateIncidentRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationCreateRequestDto;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationGetManyResponseDto;
import ci.gouv.dgbf.system.ticket.server.api.DeclarationService.DeclarationUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link DeclarationService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class DeclarationClient extends AbstractClient<DeclarationService>
    implements GetByIdentifier<DeclarationDto>,
               GetMany<DeclarationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public DeclarationClient service(DeclarationService service) {
    return (DeclarationClient) super.service(service);
  }

  /**
   * {@link DeclarationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(DeclarationCreateRequestDto request) {
    return new CreateExecutor(DeclarationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link DeclarationService#create}.
   *
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String auditWho, String auditSession) {
    DeclarationCreateRequestDto request = new DeclarationCreateRequestDto();
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link DeclarationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public DeclarationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<DeclarationGetManyResponseDto>(
      DeclarationGetManyResponseDto.class,
        DeclarationService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link DeclarationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DeclarationGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link DeclarationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public DeclarationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<DeclarationDto>(DeclarationDto.class,
        DeclarationService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link DeclarationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public DeclarationDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link DeclarationService#getByIdentifier}.
   *
   * @param request requête
   * @return declaration
   */
  public DeclarationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<DeclarationDto>(DeclarationDto.class,
        DeclarationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link DeclarationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public DeclarationDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link DeclarationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(DeclarationUpdateRequestDto request) {
    return new IdentifiableExecutor(DeclarationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link DeclarationService#update}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier,
      String auditWho, String auditSession) {
    DeclarationUpdateRequestDto request = new DeclarationUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link DeclarationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(DeclarationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link DeclarationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }

  /**
   * {@link DeclarationService#createIncident}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto createIncident(CreateIncidentRequestDto request) {
    return new GetOneExecutor<IdentifiableResponseDto>(IdentifiableResponseDto.class,
        DeclarationService.CREATE_INCIDENT_IDENTIFIER
    ).execute(() -> service().createIncident(request));
  }
}
