package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.system.file.server.api.FileFilter;
import jakarta.enterprise.context.Dependent;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.primefaces.PrimeFaces;
import org.primefaces.model.DialogFrameworkOptions;

/**
 * Cette classe représente le contrôleur du bouton d'ouverture des fichiers.
 *
 * @author Christian
 *
 */
@Dependent
public class OpenFilesButtonController extends AbstractController {

  @Getter
  @Setter
  String type;

  @Getter
  @Setter
  String icon;

  @Getter
  @Setter
  String onClick;

  @Getter
  @Setter
  String styleClass;

  /**
   * Cette méthode permet de construire une instance.
   */
  public OpenFilesButtonController() {
    name = "Voir";
    icon = "pi pi-eye";
    type = "submit";
  }
  
  /**
   * Cette méthode permet d'ouvrir.
   *
   * @param identifier identifiant
   */
  public void open(String identifier) {
    DialogFrameworkOptions options =
        DialogFrameworkOptions.builder().modal(true).width("800").height("440")
            .contentHeight("100%").contentWidth("100%").build();

    PrimeFaces.current().dialog().openDynamic(FileListPage.OUTCOME_WITHOUT_TEMPLATE, options,
        Map.of(FileFilter.JSON_GROUP_IDENTIFIER, List.of(identifier)));
  }
}
