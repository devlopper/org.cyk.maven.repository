package ci.gouv.dgbf.system.payrollelementrequest.server.api;

/**
 * Cette classe représente les codes de {@link PayrollElementClaimStatus}.
 *
 * @author akm
 *
 */
public class PayrollElementClaimStatusCode {

  private PayrollElementClaimStatusCode() {

  }

  /**
   * Créée.
   */
  public static final String CREATED = "CREEE";

  /**
   * Soumise.
   */
  public static final String SUBMITTED = "SOUMISE";

  /**
   * Prise en charge.
   */
  public static final String IN_CHARGE = "PRISE_EN_CHARGE";

  /**
   * Rejetée.
   */
  public static final String REJECTED = "REJETEE";

  /**
   * Différée.
   */
  public static final String DEFERRED = "DIFFEREE";

  /**
   * Acceptée.
   */
  public static final String ACCEPTED = "ACCEPTEE";

  /**
   * Transmise pour Visa.
   */
  public static final String TRANSMITTED_TO_VISA = ClaimedValueReviewStatusCode.TRANSMITTED_TO_VISA;

  /**
   * Visée.
   */
  public static final String VISA_GRANTED = ClaimedValueReviewStatusCode.VISA_GRANTED;

  /**
   * Transmise pour Contrôle.
   */
  public static final String TRANSMITTED_TO_CONTROL =
      ClaimedValueReviewStatusCode.TRANSMITTED_TO_CONTROL;

  /**
   * Contrôlée.
   */
  public static final String CONTROLLED = ClaimedValueReviewStatusCode.CONTROLLED;

  /**
   * Transmise pour Validation.
   */
  public static final String TRANSMITTED_TO_VALIDATION =
      ClaimedValueReviewStatusCode.TRANSMITTED_TO_VALIDATION;

  /**
   * Validation Déléguée.
   */
  public static final String VALIDATION_DELEGATED =
      ClaimedValueReviewStatusCode.VALIDATION_DELEGATED;

  /**
   * Validée.
   */
  public static final String VALIDATED = ClaimedValueReviewStatusCode.VALIDATED;
}
