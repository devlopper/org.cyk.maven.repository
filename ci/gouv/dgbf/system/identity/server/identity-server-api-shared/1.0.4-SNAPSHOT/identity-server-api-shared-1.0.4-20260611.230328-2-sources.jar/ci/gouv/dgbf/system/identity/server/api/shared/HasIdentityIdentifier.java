package ci.gouv.dgbf.system.identity.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'identité.
 *
 * @author Christian
 */
public interface HasIdentityIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'identité.
   *
   * @return identifiant de l'identité
   */
  String getIdentityIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'identité.
   *
   * @param identityIdentifier identifiant de l'identité
   */
  void setIdentityIdentifier(String identityIdentifier);

  /**
   * Identifiant java de l'identifiant de l'identité.
   */
  String FIELD_IDENTITY_IDENTIFIER = "identityIdentifier";
}
