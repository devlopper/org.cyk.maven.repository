package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementPositionFieldService.MovementPositionFieldCreateRequestDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementPositionFieldService.MovementPositionFieldGetManyResponseDto;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementPositionFieldService.MovementPositionFieldUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link MovementPositionFieldService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class MovementPositionFieldClient extends AbstractClient<MovementPositionFieldService>
    implements GetByIdentifier<MovementPositionFieldDto>,
    GetMany<MovementPositionFieldGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public MovementPositionFieldClient service(MovementPositionFieldService service) {
    return (MovementPositionFieldClient) super.service(service);
  }

  /**
   * {@link MovementPositionFieldService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(MovementPositionFieldCreateRequestDto request) {
    return new CreateExecutor(MovementPositionFieldService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link MovementPositionFieldService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public MovementPositionFieldGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<MovementPositionFieldGetManyResponseDto>(
        MovementPositionFieldGetManyResponseDto.class,
        MovementPositionFieldService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link MovementPositionFieldService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public MovementPositionFieldGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link MovementPositionFieldService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public MovementPositionFieldDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<MovementPositionFieldDto>(MovementPositionFieldDto.class,
        MovementPositionFieldService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link MovementPositionFieldService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public MovementPositionFieldDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link MovementPositionFieldService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public MovementPositionFieldDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<MovementPositionFieldDto>(MovementPositionFieldDto.class,
        MovementPositionFieldService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link MovementPositionFieldService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public MovementPositionFieldDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link MovementPositionFieldService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(MovementPositionFieldUpdateRequestDto request) {
    return new IdentifiableExecutor(MovementPositionFieldService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link MovementPositionFieldService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(MovementPositionFieldService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link MovementPositionFieldService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
