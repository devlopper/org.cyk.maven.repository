package ci.gouv.dgbf.system.scripting.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ScriptContextGroupDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-03-06T08:42:26+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ScriptContextGroupRequestMapperImpl implements ScriptContextGroupRequestMapper {

    @Override
    public ScriptContextGroupService.ScriptContextGroupCreateRequestDto mapCreate(ScriptContextGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptContextGroupService.ScriptContextGroupCreateRequestDto scriptContextGroupCreateRequestDto = new ScriptContextGroupService.ScriptContextGroupCreateRequestDto();

        scriptContextGroupCreateRequestDto.setCode( arg0.getCode() );
        scriptContextGroupCreateRequestDto.setName( arg0.getName() );
        scriptContextGroupCreateRequestDto.setMultiplier( arg0.getMultiplier() );
        scriptContextGroupCreateRequestDto.setMinValue( arg0.getMinValue() );
        scriptContextGroupCreateRequestDto.setMaxValue( arg0.getMaxValue() );

        return scriptContextGroupCreateRequestDto;
    }

    @Override
    public ScriptContextGroupService.ScriptContextGroupUpdateRequestDto mapUpdate(ScriptContextGroupDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ScriptContextGroupService.ScriptContextGroupUpdateRequestDto scriptContextGroupUpdateRequestDto = new ScriptContextGroupService.ScriptContextGroupUpdateRequestDto();

        scriptContextGroupUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        scriptContextGroupUpdateRequestDto.setCode( arg0.getCode() );
        scriptContextGroupUpdateRequestDto.setName( arg0.getName() );
        scriptContextGroupUpdateRequestDto.setMultiplier( arg0.getMultiplier() );
        scriptContextGroupUpdateRequestDto.setMinValue( arg0.getMinValue() );
        scriptContextGroupUpdateRequestDto.setMaxValue( arg0.getMaxValue() );

        return scriptContextGroupUpdateRequestDto;
    }
}
