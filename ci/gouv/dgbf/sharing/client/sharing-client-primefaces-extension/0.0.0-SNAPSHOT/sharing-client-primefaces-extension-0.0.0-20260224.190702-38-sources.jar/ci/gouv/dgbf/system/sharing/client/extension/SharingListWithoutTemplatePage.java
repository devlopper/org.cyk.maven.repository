package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.system.sharing.server.api.SharingDto;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

/**
 * Cette classe représente la page de liste de {@link SharingDto}.
 *
 * @author AKM
 *
 */
@Named
@ViewScoped
public class SharingListWithoutTemplatePage extends AbstractSharingListPage  {

  /**
   * Cette constante est le cas de navigation.
   */
  public static final String OUTCOME = "sharingListWithoutTemplatePage";
}
