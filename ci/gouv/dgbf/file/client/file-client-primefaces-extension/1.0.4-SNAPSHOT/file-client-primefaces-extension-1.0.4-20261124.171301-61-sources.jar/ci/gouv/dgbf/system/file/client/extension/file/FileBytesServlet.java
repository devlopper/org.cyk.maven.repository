package ci.gouv.dgbf.system.file.client.extension.file;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.FileHelper;
import ci.gouv.dgbf.extension.core.throwable.ThrowableHelper;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.file.server.api.ContentForm;
import ci.gouv.dgbf.system.file.server.api.FileClient;
import ci.gouv.dgbf.system.file.server.api.FileDto;
import jakarta.inject.Inject;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Cette classe représente le serveur d'octets de fichier, piloté par la forme du contenu
 * (RG_FILE_FIC_18, spec-api § 9.6). Répond HTTP 409 explicite pour un fichier descriptif.
 *
 * @author Christian
 *
 */
@WebServlet(FileBytesServlet.URL_PATTERN)
public class FileBytesServlet extends org.omnifaces.servlet.FileServlet {
  private static final Logger LOGGER = Logger.getLogger(FileBytesServlet.class.getName());

  public static final String URL_PATTERN = FileViewerUriBuilder.PATH + "/*";

  @Inject
  transient FileClient client;

  @Inject
  transient FileHelper fileHelper;

  @Inject
  transient ThrowableHelper throwableHelper;

  @Override
  protected File getFile(HttpServletRequest request) {
    String identifier = request.getParameter(ByIdentifierRequestDto.JSON_IDENTIFIER);
    String ownerIdentifier = request.getParameter(FileDto.JSON_OWNER_IDENTIFIER);
    String auditWho = request.getParameter(AbstractRequestDto.JSON_AUDIT_WHO);
    String auditSession = request.getParameter(AbstractAuditedRequestJsonDto.JSON_AUDIT_SESSION);
    FileDto dto = client.getByIdentifier(identifier,
        new ProjectionDto().addNames(AbstractIdentifiableNamableDto.JSON_NAME,
            FileDto.JSON_CONTENT_FORM), auditWho, auditSession);
    if (dto == null) {
      return null;
    }
    if (ContentForm.DESCRIPTIVE.equals(dto.getContentForm())) {
      request.setAttribute(ATTRIBUTE_EXCEPTION_NAME, new NoBinaryContentException());
      return null;
    }
    File file;
    byte[] bytes = getBytes(request, identifier, ownerIdentifier, auditWho, auditSession);
    if (bytes == null) {
      file = null;
    } else {
      String fileName = buildFileName(dto.getName());
      file = fileHelper.writeToTemprorayFile(bytes, fileName);
    }
    LOGGER.log(Level.FINER, "Fichier obtenu. {0}", file);
    return file;
  }

  byte[] getBytes(HttpServletRequest request, String identifier, String ownerIdentifier,
      String auditWho, String auditSession) {
    byte[] bytes;
    try {
      bytes = client.getBytes(identifier, ownerIdentifier, auditWho, auditSession);
      LOGGER.log(Level.FINER, "Octets obtenus. #{0}", Core.getArrayLength(bytes));
    } catch (Exception exception) {
      request.setAttribute(ATTRIBUTE_EXCEPTION_NAME, exception);
      bytes = null;
      LOGGER.log(Level.SEVERE, "Erreur lors de l''obtention des octets. {0}",
          exception.getMessage());
    }
    return bytes;
  }

  String buildFileName(String name) {
    String timestamp = "_" + System.currentTimeMillis();
    int lastDotIndex = name.lastIndexOf(".");
    if (lastDotIndex > -1) {
      name = name.substring(0, lastDotIndex) + timestamp + "." + name.substring(lastDotIndex + 1);
    } else {
      name = name + timestamp;
    }
    return name;
  }

  @Override
  protected void handleFileNotFound(HttpServletRequest request, HttpServletResponse response)
      throws IOException {
    Exception exception = (Exception) request.getAttribute(ATTRIBUTE_EXCEPTION_NAME);
    if (exception == null) {
      super.handleFileNotFound(request, response);
    } else if (exception instanceof NoBinaryContentException) {
      response.sendError(409, throwableHelper.getMessage(exception));
    } else {
      response.sendError(500, throwableHelper.getMessage(exception));
    }
  }

  static final String FILE_NAME = "fichier";
  static final String ATTRIBUTE_EXCEPTION_NAME = "exception";

  /**
   * Cette classe représente l'absence de contenu binaire d'un Fichier physique : réponse 409, et
   * non 500 (RG_FILE_FIC_18). Un type dédié plutôt qu'un message comparé : le libellé peut
   * changer sans casser la détection.
   */
  static class NoBinaryContentException extends IllegalStateException {
    private static final long serialVersionUID = 1L;

    NoBinaryContentException() {
      super("Fichier physique : aucun contenu binaire à télécharger");
    }
  }
}
