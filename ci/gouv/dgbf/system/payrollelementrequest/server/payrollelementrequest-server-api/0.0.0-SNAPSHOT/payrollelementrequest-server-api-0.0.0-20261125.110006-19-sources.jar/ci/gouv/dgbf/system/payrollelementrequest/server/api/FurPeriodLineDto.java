package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDate;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une ligne consolidée d'une période du FUR, en codification CALO, en
 * lecture seule et sans donnée personnelle (nom, naissance, sexe, situation matrimoniale,
 * adresse).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FurPeriodLineDto extends AbstractIdentifiableAuditableDto {

  /**
   * Premier jour du mois de la période.
   */
  @JsonbProperty(JSON_PERIOD)
  private LocalDate period;

  /**
   * Type de FUR.
   */
  @JsonbProperty(JSON_FUR_TYPE)
  private String furType;

  /**
   * Code pièce.
   */
  @JsonbProperty(JSON_PIECE)
  private String piece;

  /**
   * Matricule de l'agent.
   */
  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  /**
   * Code document.
   */
  @JsonbProperty(JSON_DOCUMENT)
  private String document;

  /**
   * Code section CALO.
   */
  @JsonbProperty(JSON_SECTION_CODE)
  private String sectionCode;

  /**
   * Code organisme sous tutelle.
   */
  @JsonbProperty(JSON_TUTELAGE_ORGANISM_CODE)
  private String tutelageOrganismCode;

  /**
   * Code service CALO.
   */
  @JsonbProperty(JSON_SERVICE_CODE)
  private String serviceCode;

  /**
   * Code emploi CALO.
   */
  @JsonbProperty(JSON_JOB_CODE)
  private String jobCode;

  /**
   * Code catégorie CALO.
   */
  @JsonbProperty(JSON_CATEGORY_CODE)
  private String categoryCode;

  /**
   * Code grade CALO.
   */
  @JsonbProperty(JSON_GRADE_CODE)
  private String gradeCode;

  /**
   * Code classe CALO.
   */
  @JsonbProperty(JSON_CLASS_CODE)
  private String classCode;

  /**
   * Code échelon CALO.
   */
  @JsonbProperty(JSON_STEP_CODE)
  private String stepCode;

  /**
   * Code fonction CALO.
   */
  @JsonbProperty(JSON_FUNCTION_CODE)
  private String functionCode;

  /**
   * Code localité CALO.
   */
  @JsonbProperty(JSON_LOCALITY_CODE)
  private String localityCode;

  /**
   * Code mode de règlement.
   */
  @JsonbProperty(JSON_PAYMENT_MODE_CODE)
  private String paymentModeCode;

  /**
   * Code position solde.
   */
  @JsonbProperty(JSON_SALARY_POSITION_CODE)
  private String salaryPositionCode;

  /**
   * Code du type de réclamation résolu depuis la pièce et le document, {@code null} si aucune
   * règle ne correspond.
   */
  @JsonbProperty(JSON_RESOLVED_TYPE_CODE)
  private String resolvedTypeCode;

  /**
   * Libellé du type de réclamation résolu depuis la pièce et le document.
   */
  @JsonbProperty(JSON_RESOLVED_TYPE_LABEL)
  private String resolvedTypeLabel;

  /**
   * Référence de l'acte administratif.
   */
  @JsonbProperty(JSON_REFERENCE)
  private String reference;

  /**
   * Identifiant de la réclamation générée à partir de la ligne, {@code null} si aucune.
   */
  @JsonbProperty(JSON_CLAIM_IDENTIFIER)
  private String claimIdentifier;

  /**
   * Motif pour lequel la ligne n'a produit aucune réclamation.
   */
  @JsonbProperty(JSON_REASON)
  private String reason;

  /**
   * Date d'effet de la situation administrative.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_EFFECTIVE_DATE)
  private LocalDate administrativeEffectiveDate;

  /**
   * Date de début de la fonction CALO.
   */
  @JsonbProperty(JSON_FUNCTION_START_DATE)
  private LocalDate functionStartDate;

  /**
   * Date d'effet de la localité.
   */
  @JsonbProperty(JSON_LOCALITY_EFFECTIVE_DATE)
  private LocalDate localityEffectiveDate;

  /**
   * Date de début de la position solde.
   */
  @JsonbProperty(JSON_SALARY_POSITION_START_DATE)
  private LocalDate salaryPositionStartDate;

  /**
   * Date d'effet du service.
   */
  @JsonbProperty(JSON_SERVICE_EFFECTIVE_DATE)
  private LocalDate serviceEffectiveDate;

  /**
   * Date de recrutement.
   */
  @JsonbProperty(JSON_RECRUITMENT_DATE)
  private LocalDate recruitmentDate;

  /**
   * Identifiant json {@link #period}.
   */
  public static final String JSON_PERIOD = "periode";

  /**
   * Identifiant json {@link #furType}.
   */
  public static final String JSON_FUR_TYPE = "typeFur";

  /**
   * Identifiant json {@link #piece}.
   */
  public static final String JSON_PIECE = "codePiece";

  /**
   * Identifiant json {@link #registrationNumber}.
   */
  public static final String JSON_REGISTRATION_NUMBER = "matricule";

  /**
   * Identifiant json {@link #document}.
   */
  public static final String JSON_DOCUMENT = "codeDocument";

  /**
   * Identifiant json {@link #sectionCode}.
   */
  public static final String JSON_SECTION_CODE = "codeSection";

  /**
   * Identifiant json {@link #tutelageOrganismCode}.
   */
  public static final String JSON_TUTELAGE_ORGANISM_CODE = "codeOrganismeSousTutelle";

  /**
   * Identifiant json {@link #serviceCode}.
   */
  public static final String JSON_SERVICE_CODE = "codeService";

  /**
   * Identifiant json {@link #jobCode}.
   */
  public static final String JSON_JOB_CODE = "codeEmploi";

  /**
   * Identifiant json {@link #categoryCode}.
   */
  public static final String JSON_CATEGORY_CODE = "codeCategorie";

  /**
   * Identifiant json {@link #gradeCode}.
   */
  public static final String JSON_GRADE_CODE = "codeGrade";

  /**
   * Identifiant json {@link #classCode}.
   */
  public static final String JSON_CLASS_CODE = "codeClasse";

  /**
   * Identifiant json {@link #stepCode}.
   */
  public static final String JSON_STEP_CODE = "codeEchelon";

  /**
   * Identifiant json {@link #functionCode}.
   */
  public static final String JSON_FUNCTION_CODE = "codeFonction";

  /**
   * Identifiant json {@link #localityCode}.
   */
  public static final String JSON_LOCALITY_CODE = "codeLocalite";

  /**
   * Identifiant json {@link #paymentModeCode}.
   */
  public static final String JSON_PAYMENT_MODE_CODE = "codeModeReglement";

  /**
   * Identifiant json {@link #salaryPositionCode}.
   */
  public static final String JSON_SALARY_POSITION_CODE = "codePositionSolde";

  /**
   * Identifiant json {@link #resolvedTypeCode}.
   */
  public static final String JSON_RESOLVED_TYPE_CODE = "codeTypeResolu";

  /**
   * Identifiant json {@link #resolvedTypeLabel}.
   */
  public static final String JSON_RESOLVED_TYPE_LABEL = "libelleTypeResolu";

  /**
   * Identifiant json {@link #reference}.
   */
  public static final String JSON_REFERENCE = "reference";

  /**
   * Identifiant json {@link #claimIdentifier}.
   */
  public static final String JSON_CLAIM_IDENTIFIER = "idReclamation";

  /**
   * Identifiant json {@link #reason}.
   */
  public static final String JSON_REASON = "motif";

  /**
   * Identifiant json {@link #administrativeEffectiveDate}.
   */
  public static final String JSON_ADMINISTRATIVE_EFFECTIVE_DATE = "dateEffetSituationAdm";

  /**
   * Identifiant json {@link #functionStartDate}.
   */
  public static final String JSON_FUNCTION_START_DATE = "dateDebutFonction";

  /**
   * Identifiant json {@link #localityEffectiveDate}.
   */
  public static final String JSON_LOCALITY_EFFECTIVE_DATE = "dateEffetLocalite";

  /**
   * Identifiant json {@link #salaryPositionStartDate}.
   */
  public static final String JSON_SALARY_POSITION_START_DATE = "dateDebutPositionSolde";

  /**
   * Identifiant json {@link #serviceEffectiveDate}.
   */
  public static final String JSON_SERVICE_EFFECTIVE_DATE = "dateEffetService";

  /**
   * Identifiant json {@link #recruitmentDate}.
   */
  public static final String JSON_RECRUITMENT_DATE = "dateRecrutement";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ligne consolidée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "lignes consolidées";
}
