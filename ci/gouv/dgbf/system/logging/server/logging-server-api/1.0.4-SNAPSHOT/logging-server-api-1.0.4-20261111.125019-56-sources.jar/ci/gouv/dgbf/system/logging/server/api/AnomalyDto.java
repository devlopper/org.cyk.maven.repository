package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente l'objet de transfert de données d'une anomalie.
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class AnomalyDto extends AbstractIdentifiableAuditableDto
    implements Serializable, HasStatusDto<AnomalyStatus>, HasStatusAsStringDto, HasTreatableDto {

  @JsonbProperty("type")
  private AnomalyType type;

  @JsonbProperty("typeAsString")
  private String typeAsString;

  @JsonbProperty("module")
  private String module;

  @JsonbProperty("context")
  private String context;

  @JsonbProperty("containsMaskedData")
  private boolean containsMaskedData;

  @JsonbProperty(JSON_STATUS)
  private AnomalyStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_TREATABLE)
  private Boolean treatable;

  @JsonbProperty("treatmentDate")
  private LocalDateTime treatmentDate;

  @JsonbProperty("treatingAdministrator")
  private String treatingAdministrator;

  @JsonbProperty("treatmentComment")
  private String treatmentComment;

  @JsonbProperty("auditAsString")
  private String auditAsString;

  @JsonbProperty("auditSession")
  private String auditSession;
}

