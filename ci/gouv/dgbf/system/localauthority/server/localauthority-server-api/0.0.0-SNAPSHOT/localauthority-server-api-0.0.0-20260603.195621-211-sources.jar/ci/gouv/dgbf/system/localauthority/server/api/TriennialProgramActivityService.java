package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link TriennialProgramActivityDto}.
 *
 * @author Christian Yao Komenan
 */
@Path(value = TriennialProgramActivityService.PATH)
@Tag(name = "Gestion des activités de programme triennal")
public interface TriennialProgramActivityService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "activites-programmes-triennaux";

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(TriennialProgramActivityCreateRequestDto request);

  /**
   * Cette interface représente la requête d'enregistrement.
   *
   * @author Christian
   */
  interface TriennialProgramActivitySaveRequestDto {

    /**
     * Cette méthode permet d'obtenir identifiant {@link TriennialProgramDto}.
     *
     * @return identifiant {@link TriennialProgramDto}
     */
    String getTriennialProgramIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant {@link TriennialProgramDto}.
     *
     * @param triennialProgramIdentifier identifiant {@link TriennialProgramDto}
     */
    void setTriennialProgramIdentifier(String triennialProgramIdentifier);

    /**
     * Cette méthode permet d'obtenir identifiant {@link ActivityDto}.
     *
     * @return identifiant {@link ActivityDto}
     */
    String getActivityIdentifier();

    /**
     * Cette méthode permet d'assigner identifiant {@link ActivityDto}.
     *
     * @param activityIdentifier identifiant {@link ActivityDto}
     */
    void setActivityIdentifier(String activityIdentifier);

    /**
     * {@link TriennialProgramActivityDto#JSON_TRIENNIAL_PROGRAM_IDENTIFIER}.
     */
    String JSON_TRIENNIAL_PROGRAM_IDENTIFIER =
        TriennialProgramActivityDto.JSON_TRIENNIAL_PROGRAM_IDENTIFIER;

    /**
     * {@link TriennialProgramActivityDto#JSON_ACTIVITY_IDENTIFIER}.
     */
    String JSON_ACTIVITY_IDENTIFIER = TriennialProgramActivityDto.JSON_ACTIVITY_IDENTIFIER;

    /**
     * {@link TriennialProgramActivityDto#JSON_AMOUNT}.
     */
    String JSON_AMOUNT = TriennialProgramActivityDto.JSON_AMOUNT;

    /**
     * {@link TriennialProgramActivityDto#JSON_JUSTIFICATION}.
     */
    String JSON_JUSTIFICATION = TriennialProgramActivityDto.JSON_JUSTIFICATION;

    /**
     * {@link TriennialProgramActivityDto#JSON_PRIORITY}.
     */
    String JSON_PRIORITY = TriennialProgramActivityDto.JSON_PRIORITY;
  }

  /**
   * Cette classe représente la requête de création.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramActivityCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements TriennialProgramActivitySaveRequestDto {
    /**
     * {@link TriennialProgramActivityDto#getTriennialProgramIdentifier()}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    /**
     * {@link TriennialProgramActivityDto#getActivityIdentifier()}.
     */
    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    /**
     * {@link TriennialProgramActivityDto#getAmount()}.
     */
    @JsonbProperty(JSON_AMOUNT)
    private Long amount;

    /**
     * {@link TriennialProgramActivityDto#getJustification()}.
     */
    @JsonbProperty(JSON_JUSTIFICATION)
    private String justification;

    /**
     * {@link TriennialProgramActivityDto#getPriority()}.
     */
    @JsonbProperty(JSON_PRIORITY)
    private Long priority;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {@Content(
      schema = @Schema(implementation = TriennialProgramActivityGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class TriennialProgramActivityGetManyResponseDto
      extends AbstractGetByPageResponseDto<TriennialProgramActivityDto> {

    @JsonbProperty(JSON_DATAS)
    private List<TriennialProgramActivityDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TriennialProgramActivityDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = TriennialProgramActivityDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(TriennialProgramActivityUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class TriennialProgramActivityUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements TriennialProgramActivitySaveRequestDto {
    /**
     * {@link TriennialProgramActivityDto#getTriennialProgramIdentifier()}.
     */
    @JsonbProperty(JSON_TRIENNIAL_PROGRAM_IDENTIFIER)
    private String triennialProgramIdentifier;

    /**
     * {@link TriennialProgramActivityDto#getActivityIdentifier()}.
     */
    @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
    private String activityIdentifier;

    /**
     * {@link TriennialProgramActivityDto#getAmount()}.
     */
    @JsonbProperty(JSON_AMOUNT)
    private Long amount;

    /**
     * {@link TriennialProgramActivityDto#getJustification()}.
     */
    @JsonbProperty(JSON_JUSTIFICATION)
    private String justification;

    /**
     * {@link TriennialProgramActivityDto#getPriority()}.
     */
    @JsonbProperty(JSON_PRIORITY)
    private Long priority;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_ACTIVITE_PROGRAMME_TRIENNAL";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link TriennialProgramActivityDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
