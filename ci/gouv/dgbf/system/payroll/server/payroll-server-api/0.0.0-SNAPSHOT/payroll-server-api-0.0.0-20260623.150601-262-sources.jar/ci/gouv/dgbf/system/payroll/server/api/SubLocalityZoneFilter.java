package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link SubLocalityZoneDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class SubLocalityZoneFilter extends AbstractIdentifiableFilter {

  private String subLocalityIdentifier;

  private String zoneIdentifier;
  
  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public SubLocalityZoneFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public SubLocalityZoneFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    subLocalityIdentifier = getSubLocalityIdentifier(filter);
    zoneIdentifier = getZoneIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setSubLocalityIdentifier(filter, subLocalityIdentifier);
    setZoneIdentifier(filter, zoneIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la sous-localité.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setSubLocalityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_SUB_LOCALITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la sous-localité.
   *
   * @param filter filtre
   * @return identifiant de la sous-localité
   */
  public static String getSubLocalityIdentifier(FilterDto filter) {
    return get(filter, d ->
            d.getFieldValueAsStringByName(JSON_SUB_LOCALITY_IDENTIFIER));
  }
  
  /**
   * Cette méthode permet d'assigner l'identifiant de la zone.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setZoneIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_ZONE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la zone.
   *
   * @param filter filtre
   * @return identifiant de la zone
   */
  public static String getZoneIdentifier(FilterDto filter) {
    return get(filter,
              d -> d.getFieldValueAsStringByName(JSON_ZONE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #subLocalityIdentifier}.
   */
  public static final String JSON_SUB_LOCALITY_IDENTIFIER = 
      SubLocalityZoneDto.JSON_SUB_LOCALITY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #zoneIdentifier}.
   */
  public static final String JSON_ZONE_IDENTIFIER = 
      SubLocalityZoneDto.JSON_ZONE_IDENTIFIER;
}
