package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ceadp.server.api.FolderPriorityService.FolderPriorityCreateRequestDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderPriorityService.FolderPriorityGetManyResponseDto;
import ci.gouv.dgbf.system.ceadp.server.api.FolderPriorityService.FolderPriorityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link FolderPriorityService}.
 *
 * @author Dahoud
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FolderPriorityClient extends AbstractClient<FolderPriorityService>
    implements GetByIdentifier<FolderPriorityDto>,
        GetMany<FolderPriorityGetManyResponseDto>,
        DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public FolderPriorityClient service(FolderPriorityService service) {
    return (FolderPriorityClient) super.service(service);
  }

  /**
   * {@link FolderPriorityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FolderPriorityCreateRequestDto request) {
    return new CreateExecutor(FolderPriorityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link FolderPriorityService#create}.
   *
   * @param code code
   * @param name nom
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    FolderPriorityCreateRequestDto request = new FolderPriorityCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link FolderPriorityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public FolderPriorityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<FolderPriorityGetManyResponseDto>(
            FolderPriorityGetManyResponseDto.class, FolderPriorityService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link FolderPriorityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FolderPriorityGetManyResponseDto getMany(
      ProjectionDto projection,
      FilterDto filter,
      PageDto page,
      String auditWho,
      String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link FolderPriorityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public FolderPriorityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<FolderPriorityDto>(
            FolderPriorityDto.class, FolderPriorityService.GET_ONE_IDENTIFIER)
        .execute(() -> service().getOne(request));
  }

  /**
   * {@link FolderPriorityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public FolderPriorityDto getOne(
      ProjectionDto projection, FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link FolderPriorityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public FolderPriorityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FolderPriorityDto>(
            FolderPriorityDto.class, FolderPriorityService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link FolderPriorityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public FolderPriorityDto getByIdentifier(
      String identifier, ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link FolderPriorityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(FolderPriorityUpdateRequestDto request) {
    return new IdentifiableExecutor(FolderPriorityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link FolderPriorityService#update}.
   *
   * @param identifier identifiant
   * @param name nom
   * @param code code
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(
      String identifier, String code, String name, String auditWho, String auditSession) {
    FolderPriorityUpdateRequestDto request = new FolderPriorityUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link FolderPriorityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FolderPriorityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link FolderPriorityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(
      String identifier, String auditWho, String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
