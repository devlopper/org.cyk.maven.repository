package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConstantGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFullNameDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsCalculableAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsCalculableDto;
import ci.gouv.dgbf.extension.core.segregation.HasRegistrationNumberDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasRemunerableIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payroll.server.api.PayslipService.ProcessResponseDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasCalculationInputsFromPayrollConstantAsJsonDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasCalculationInputsFromPayrollConstantMapDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasCalculationInputsFromPayrollElementAsJsonDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasCalculationInputsFromPayrollElementMapDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollAsStringDto;
import ci.gouv.dgbf.system.payroll.server.api.shared.HasPayrollIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.LinkedHashMap;
import java.util.Map;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un bulletin de paie.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasPayrollIdentifierDto, HasPayrollAsStringDto, HasRemunerableIdentifierDto,
    HasRemunerableAsStringDto, HasRegistrationNumberDto, HasFullNameDto, PayslipContainerDto,
    HasConstantGroupIdentifierDto, HasConstantGroupAsStringDto, HasIsCalculableDto,
    HasIsCalculableAsStringDto, HasCalculationInputsFromPayrollElementAsJsonDto,
    HasCalculationInputsFromPayrollElementMapDto, HasCalculationInputsFromPayrollConstantAsJsonDto,
    HasCalculationInputsFromPayrollConstantMapDto {

  @JsonbProperty(JSON_PAYROLL_IDENTIFIER)
  private String payrollIdentifier;

  @JsonbProperty(JSON_PAYROLL_AS_STRING)
  private String payrollAsString;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_AS_JSON)
  private String calculationInputsFromPayrollElementAsJson;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_MAP)
  private Map<String, Object> calculationInputsFromPayrollElementMap;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_NAME_AS_JSON)
  private String calculationInputsFromPayrollElementNameAsJson;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_NAME_MAP)
  private LinkedHashMap<String, Object> calculationInputsFromPayrollElementNameMap;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_AS_JSON)
  private String calculationInputsFromPayrollConstantAsJson;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_MAP)
  private Map<String, Object> calculationInputsFromPayrollConstantMap;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_NAME_AS_JSON)
  private String calculationInputsFromPayrollConstantNameAsJson;

  @JsonbProperty(JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_NAME_MAP)
  private LinkedHashMap<String, Object> calculationInputsFromPayrollConstantNameMap;
  
  @JsonbProperty(JSON_REMUNERABLE_IDENTIFIER)
  private String remunerableIdentifier;

  @JsonbProperty(JSON_REMUNERABLE_AS_STRING)
  private String remunerableAsString;

  @JsonbProperty(JSON_REGISTRATION_NUMBER)
  private String registrationNumber;

  @JsonbProperty(JSON_FULL_NAME)
  private String fullName;

  /**
   * {@link PayslipStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private PayslipStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Est recalculable.
   */
  @JsonbProperty(JSON_IS_RECALCULABLE)
  private Boolean isRecalculable;

  @JsonbProperty(JSON_CONSTANT_GROUP_IDENTIFIER)
  private String constantGroupIdentifier;

  @JsonbProperty(JSON_CONSTANT_GROUP_AS_STRING)
  private String constantGroupAsString;

  /*-- Début définition des montants --*/

  /**
   * Représentation en chaine de caractères du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_AS_STRING)
  private String grossAmountAsString;

  /**
   * Variation du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_VARIATION)
  private Integer grossAmountVariation;

  /**
   * Représentation en chaine de caractères de la variation du montant brut.
   */
  @JsonbProperty(JSON_PREVIOUS_GROSS_AMOUNT_AS_STRING)
  private String previousGrossAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant brut.
   */
  @JsonbProperty(JSON_GROSS_AMOUNT_VARIATION_AS_STRING)
  private String grossAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant brut imposable.
   */
  @JsonbProperty(JSON_TAXABLE_GROSS_AMOUNT_AS_STRING)
  private String taxableGrossAmountAsString;

  /**
   * Représentation en chaine de caractères du montant brut imposable précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_TAXABLE_GROSS_AMOUNT_AS_STRING)
  private String previousTaxableGrossAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant brut imposable.
   */
  @JsonbProperty(JSON_TAXABLE_GROSS_AMOUNT_VARIATION_AS_STRING)
  private String taxableGrossAmountVariationAsString;

  /**
   * Représentation en chaine de caractères des éléments non soumis.
   */
  @JsonbProperty(JSON_NON_TAXABLE_AMOUNT_AS_STRING)
  private String nonTaxableAmountAsString;

  /**
   * Représentation en chaine de caractères des éléments non soumis précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_NON_TAXABLE_AMOUNT_AS_STRING)
  private String previousNonTaxableAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation des éléments non soumis.
   */
  @JsonbProperty(JSON_NON_TAXABLE_AMOUNT_VARIATION_AS_STRING)
  private String nonTaxableAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant des retenues.
   */
  @JsonbProperty(JSON_DEDUCTIONS_AMOUNT_AS_STRING)
  private String deductionsAmountAsString;

  /**
   * Représentation en chaine de caractères du montant des retenues précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_DEDUCTIONS_AMOUNT_AS_STRING)
  private String previousDeductionsAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant des retenues.
   */
  @JsonbProperty(JSON_DEDUCTIONS_AMOUNT_VARIATION_AS_STRING)
  private String deductionsAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant net.
   */
  @JsonbProperty(JSON_NET_AMOUNT_AS_STRING)
  private String netAmountAsString;

  /**
   * Représentation en chaine de caractères du montant net précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_NET_AMOUNT_AS_STRING)
  private String previousNetAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant net.
   */
  @JsonbProperty(JSON_NET_AMOUNT_VARIATION_AS_STRING)
  private String netAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_AMOUNT_AS_STRING)
  private String employerAmountAsString;

  /**
   * Représentation en chaine de caractères du montant employeur précédent.
   */
  @JsonbProperty(JSON_PREVIOUS_EMPLOYER_AMOUNT_AS_STRING)
  private String previousEmployerAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant employeur.
   */
  @JsonbProperty(JSON_EMPLOYER_AMOUNT_VARIATION_AS_STRING)
  private String employerAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant initialisé.
   */
  @JsonbProperty(JSON_INITIALIZED_AMOUNT_AS_STRING)
  private String initializedAmountAsString;

  /**
   * Représentation en chaine de caractères du montant controlé.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_AS_STRING)
  private String controledAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant controlé.
   */
  @JsonbProperty(JSON_CONTROLED_AMOUNT_VARIATION_AS_STRING)
  private String controledAmountVariationAsString;

  /**
   * Représentation en chaine de caractères du montant ajusté.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_AS_STRING)
  private String ajustedAmountAsString;

  /**
   * Représentation en chaine de caractères de la variation du montant ajusté.
   */
  @JsonbProperty(JSON_AJUSTED_AMOUNT_VARIATION_AS_STRING)
  private String ajustedAmountVariationAsString;

  /*-- Fin définition des montants --*/

  /**
   * Montant net inférieur au montant céssible.
   */
  private Boolean isNetAmountLessThanCessibleAmount;
  
  /**
   * Nombre de propositions.
   */
  @JsonbProperty(JSON_PROPOSITION_COUNT)
  private Integer propositionCount;

  /**
   * Représentation en chaine de caractère du nombre de propositions.
   */
  @JsonbProperty(JSON_PROPOSITION_COUNT_AS_STRING)
  private String propositionCountAsString;

  /**
   * Est à controler prioritairement.
   */
  @JsonbProperty(JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY)
  private Boolean isToBeControlledInPriority;

  /**
   * Code statut.
   */
  @JsonbProperty(JSON_STATUS_CODE)
  private String statusCode;

  /**
   * Est générable.
   */
  @JsonbProperty(JSON_IS_COMPUTE_AMOUNTS)
  private Boolean isComputeAmounts;

  /**
   * initializable.
   */
  @JsonbProperty(JSON_INITIALIZABLE)
  private Boolean initializable;

  /**
   * Transmettable pour contrôle.
   */
  @JsonbProperty(JSON_TRANSMITTABLE_FOR_CONTROL)
  private Boolean transmittableForControl;

  /**
   * Contrôlable.
   */
  @JsonbProperty(JSON_CONTROLLABLE)
  private Boolean controllable;

  /**
   * acceptable.
   */
  @JsonbProperty(JSON_ACCEPTABLE)
  private Boolean acceptable;

  /**
   * racalculable.
   */
  @JsonbProperty(JSON_RECALCULABLE)
  private Boolean recalculable;

  /**
   * validable.
   */
  @JsonbProperty(JSON_VALIDABLE)
  private Boolean validable;

  /**
   * arbitrable.
   */
  @JsonbProperty(JSON_ARBITRABLE)
  private Boolean arbitrable;

  /**
   * closable.
   */
  @JsonbProperty(JSON_CLOSABLE)
  private Boolean closable;

  @JsonbProperty(JSON_IS_CALCULABLE)
  private Boolean isCalculable;

  @JsonbProperty(JSON_IS_CALCULABLE_AS_STRING)
  private String isCalculableAsString;

  // Counts
  
  @JsonbProperty(JSON_MOVEMENT_COUNT_AS_STRING)
  private String movementCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_DEFERRED_PROPOSED_COUNT_AS_STRING)
  private String movementDeferredProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_DEFERRED_COUNT_AS_STRING)
  private String movementDeferredCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTION_PROPOSED_COUNT_AS_STRING)
  private String movementRejectionProposedCountAsString;
  
  @JsonbProperty(JSON_MOVEMENT_REJECTED_COUNT_AS_STRING)
  private String movementRejectedCountAsString;
  
  @JsonbProperty(JSON_CONSTANT_COUNT_AS_STRING)
  private String constantCountAsString;
  
  @JsonbProperty(JSON_COMPONENT_COUNT_AS_STRING)
  private String componentCountAsString;
  
  @JsonbProperty(JSON_EARNING_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String earningComponentHavingNonZeroAmountCountAsString;
  
  @JsonbProperty(JSON_DEDUCTION_COMPONENT_HAVING_NON_ZERO_AMOUNT_COUNT_AS_STRING)
  private String deductionComponentHavingNonZeroAmountCountAsString;
  
  @JsonbProperty(JSON_COMPONENT_HAVING_NON_BLANK_MESSAGE_COUNT_AS_STRING)
  private String componentHavingNonBlankMessageCountAsString;

  @JsonbProperty(JSON_IS_LITIGATABLE)
  private Boolean isLitigatable;

  @JsonbProperty(JSON_LITIGATION_REASON)
  private String litigationReason;
  
  /**
   * Cette méthode permet d'initialiser à partir d'une réponse.
   *
   * @param response résponse
   */
  public void initialize(ProcessResponseDto response) {
    status = response.getStatus();
    statusAsString = response.getStatus().getName();
    initializable = response.getInitializable();
    transmittableForControl = response.getTransmittableForControl();
    controllable = response.getControllable();
    acceptable = response.getAcceptable();
    recalculable = response.getRecalculable();
    validable = response.getValidable();
    arbitrable = response.getArbitrable();
    closable = response.getClosable();
  }

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBulletinPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "bulletinPaieChaine";

  /**
   * Identifiant json {@link #isRecalculable}.
   */
  public static final String JSON_IS_RECALCULABLE = "estRecalculable";

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json {@link #propositionCount}.
   */
  public static final String JSON_PROPOSITION_COUNT = "nombreProposition";

  /**
   * Identifiant json {@link #propositionCountAsString}.
   */
  public static final String JSON_PROPOSITION_COUNT_AS_STRING = "nombrePropositionChaine";

  /**
   * Identifiant json {@link #isToBeControlledInPriority}.
   */
  public static final String JSON_IS_TO_BE_CONTROLLED_IN_PRIORITY = "estAControlerPrioritairement";

  /**
   * Identifiant json {@link #statusCode}.
   */
  public static final String JSON_STATUS_CODE = "codeStatut";

  /**
   * Identifiant json de {@link #isComputeAmounts}.
   */
  public static final String JSON_IS_COMPUTE_AMOUNTS = "calculerMontant";

  /**
   * Identifiant json champ {@link #initializable}.
   */
  public static final String JSON_INITIALIZABLE = "initializable";

  /**
   * Identifiant json champ {@link #transmittableForControl}.
   */
  public static final String JSON_TRANSMITTABLE_FOR_CONTROL = "transmettablePourControle";

  /**
   * Identifiant json champ {@link #controllable}.
   */
  public static final String JSON_CONTROLLABLE = "controlable";

  /**
   * Identifiant json champ {@link #acceptable}.
   */
  public static final String JSON_ACCEPTABLE = "acceptable";

  /**
   * Identifiant json champ {@link #recalculable}.
   */
  public static final String JSON_RECALCULABLE = "recalculable";

  /**
   * Identifiant json champ {@link #validable}.
   */
  public static final String JSON_VALIDABLE = "validable";

  /**
   * Identifiant json champ {@link #arbitrable}.
   */
  public static final String JSON_ARBITRABLE = "arbitrable";

  /**
   * Identifiant json champ {@link #closable}.
   */
  public static final String JSON_CLOSABLE = "closable";

  /**
   * Identifiant json {@link #calculationInputsFromPayrollElementNameAsJson}.
   */
  public static final String JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_NAME_AS_JSON = 
                        "entreesDeduitLibelleElementPaieCalculJson";

  /**
   * Identifiant json {@link #calculationInputsFromPayrollElementNameMap}.
   */
  public static final String JSON_CALCULATION_INPUTS_FROM_PAYROLL_ELEMENT_NAME_MAP = 
                        "entreesDeduitLibelleElementPaieCalcul";

  /**
   * Identifiant json {@link #calculationInputsFromPayrollConstantNameAsJson}.
   */
  public static final String JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_NAME_AS_JSON = 
                        "entreesDeduitLibelleConstantePaieCalculJson";

  /**
   * Identifiant json {@link #calculationInputsFromPayrollConstantNameMap}.
   */
  public static final String JSON_CALCULATION_INPUTS_FROM_PAYROLL_CONSTANT_NAME_MAP = 
                        "entreesDeduitLibelleConstantePaieCalcul";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "bulletins de paie";
}
