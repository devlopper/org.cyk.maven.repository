package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat du paramétrage : quels postes de paie un type de mouvement impacte.
 *
 * <p><strong>Créer et supprimer, jamais modifier.</strong> Une association ne porte que ses deux
 * extrémités : la modifier reviendrait à la remplacer par une autre, sous le même identifiant —
 * l'audit ne saurait plus lire ce qui a été décidé. Rattacher un poste, le détacher : ces deux
 * gestes disent tout, et l'historique les conserve tels quels.</p>
 *
 * <p>Le paramétrage est <em>global</em> : il vaut pour tous les EPN et tous les exercices. Ce
 * n'est pas un oubli. Qu'un glissement catégoriel touche l'indemnité de résidence est une
 * propriété de la nomenclature de paie, pas une décision budgétaire annuelle. Ce qui varie d'un
 * EPN à l'autre, ce sont les montants — et ceux-là vivent déjà dans les projections de postes.</p>
 *
 * @author Christian
 *
 */
@Path(value = MovementTypePayrollComponentService.PATH)
@Tag(name = "Gestion des postes de paie des types de mouvement")
public interface MovementTypePayrollComponentService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "postes-paie-types-mouvement";

  /**
   * Ce que porte la requête, au-delà de ce que la classe parente apporte.
   *
   * <p>Le concept n'expose pas de mise à jour : l'interface ne factorise donc
   * rien, mais elle tient le contrat des champs et dispense la requête de
   * nommer le {@link MovementTypePayrollComponentDto} à chaque clé.</p>
   *
   * <p>Il n'y a pas de {@code MovementTypePayrollComponentRequestMapper} pour autant :
   * R50 ne le prévoit
   * que là où la création <em>et</em> la mise à jour existent toutes deux, un mapper
   * à un seul type de requête supposant une nouvelle classe générique dans
   * l'extension.</p>
   */
  interface MovementTypePayrollComponentSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir le type de mouvement.
     *
     * @return le type de mouvement
     */
    String getMovementTypeIdentifier();

    /**
     * Cette méthode permet d'assigner le type de mouvement.
     *
     * @param movementTypeIdentifier le type de mouvement
     */
    void setMovementTypeIdentifier(String movementTypeIdentifier);

    /**
     * Cette méthode permet d'obtenir le poste de paie.
     *
     * @return le poste de paie
     */
    String getPayrollComponentIdentifier();

    /**
     * Cette méthode permet d'assigner le poste de paie.
     *
     * @param payrollComponentIdentifier le poste de paie
     */
    void setPayrollComponentIdentifier(String payrollComponentIdentifier);

    /**
     * {@link MovementTypePayrollComponentDto#JSON_MOVEMENT_TYPE_IDENTIFIER}.
     */
    String JSON_MOVEMENT_TYPE_IDENTIFIER =
        MovementTypePayrollComponentDto.JSON_MOVEMENT_TYPE_IDENTIFIER;

    /**
     * {@link MovementTypePayrollComponentDto#JSON_PAYROLL_COMPONENT_IDENTIFIER}.
     */
    String JSON_PAYROLL_COMPONENT_IDENTIFIER =
        MovementTypePayrollComponentDto.JSON_PAYROLL_COMPONENT_IDENTIFIER;
  }

  /**
   * Identifiant du service de création unitaire de {@link MovementTypePayrollComponentDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_POSTE_PAIE_TYPE_MOUVEMENT";

  /**
   * Chemin du service de création unitaire de {@link MovementTypePayrollComponentDto}.
   */
  String CREATE_PATH = "";

  /**
   * Rattache un poste de paie à un type de mouvement.
   *
   * @param request le rattachement à créer
   * @return l'identifiant attribué
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER,
      summary = "Rattachement d'un poste de paie à un type de mouvement")
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(MovementTypePayrollComponentCreateRequestDto request);

  /**
   * Requête de rattachement d'un poste à un type de mouvement.
   */
  @Getter
  @Setter
  class MovementTypePayrollComponentCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements MovementTypePayrollComponentSaveRequestDto {

    @JsonbProperty(JSON_MOVEMENT_TYPE_IDENTIFIER)
    private String movementTypeIdentifier;

    @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
    private String payrollComponentIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link MovementTypePayrollComponentDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_POSTE_PAIE_TYPE_MOUVEMENT";

  /**
   * Chemin du service d'obtention de plusieurs {@link MovementTypePayrollComponentDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère du paramétrage.
   *
   * @param request critères, projection et pagination
   * @return les rattachements correspondants
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation des postes paramétrés")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = MovementTypePayrollComponentGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de rattachements.
   */
  @Getter
  @Setter
  public static class MovementTypePayrollComponentGetManyResponseDto
      extends AbstractGetByPageResponseDto<MovementTypePayrollComponentDto> {
    @JsonbProperty(JSON_DATAS)
    private List<MovementTypePayrollComponentDto> datas;
  }

  /**
   * Identifiant du service d'obtention par identifiant de {@link MovementTypePayrollComponentDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_POSTE_PAIE_TYPE_MOUVEMENT";

  /**
   * Chemin du service d'obtention par identifiant de {@link MovementTypePayrollComponentDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'un rattachement par son identifiant.
   *
   * @param request identifiant et projection
   * @return le rattachement correspondant
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = MovementTypePayrollComponentDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de suppression unitaire de {@link MovementTypePayrollComponentDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_POSTE_PAIE_TYPE_MOUVEMENT";

  /**
   * Chemin du service de suppression unitaire de {@link MovementTypePayrollComponentDto}.
   */
  String DELETE_PATH = "";

  /**
   * Détache un poste de paie d'un type de mouvement.
   *
   * @param request l'identifiant du rattachement à retirer
   * @return l'identifiant retiré
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER,
      summary = "Détachement d'un poste de paie d'un type de mouvement")
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
