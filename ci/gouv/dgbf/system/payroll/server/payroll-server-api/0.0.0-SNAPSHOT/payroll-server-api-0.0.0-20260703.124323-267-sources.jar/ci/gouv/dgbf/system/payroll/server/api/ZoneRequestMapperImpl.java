package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ZoneDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ZoneRequestMapperImpl implements ZoneRequestMapper {

    @Override
    public ZoneService.ZoneCreateRequestDto mapCreate(ZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ZoneService.ZoneCreateRequestDto zoneCreateRequestDto = new ZoneService.ZoneCreateRequestDto();

        zoneCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        zoneCreateRequestDto.setCode( arg0.getCode() );
        zoneCreateRequestDto.setName( arg0.getName() );

        return zoneCreateRequestDto;
    }

    @Override
    public ZoneService.ZoneUpdateRequestDto mapUpdate(ZoneDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ZoneService.ZoneUpdateRequestDto zoneUpdateRequestDto = new ZoneService.ZoneUpdateRequestDto();

        zoneUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        zoneUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        zoneUpdateRequestDto.setCode( arg0.getCode() );
        zoneUpdateRequestDto.setName( arg0.getName() );

        return zoneUpdateRequestDto;
    }
}
