package ci.gouv.dgbf.system.user.client.extension;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import lombok.Getter;

/**
 * Cette classe représente la page des applications du profile de l'utilisateur connecté.
 *
 * @author BoobaCool
 */
@Named
@ViewScoped
public class UserProfileReadApplicationsPage extends AbstractUserProfileReadDatasPage {


  @Inject
  @Getter
  ApplicationController applicationController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    applicationController.getFilterController().getFilter()
        .setUserName(user.getName());
    applicationController.initialize();
  }

  public static final String OUTCOME = "userProfileReadApplicationsPage";
}

