package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.UriQueryBuilder;
import jakarta.faces.application.ConfigurableNavigationHandler;
import jakarta.faces.application.NavigationCase;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.logging.Logger;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un redirigeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@Accessors(chain = true, fluent = true)
public class Redirector {

  public static final Logger LOGGER = Logger.getLogger(Redirector.class.getName());
  
  String url;
  
  String outcome;
  UriQueryBuilder uriQueryBuilder;
  
  /**
   * Cette méthode permet de rediriger.
   */
  public void redirect() {
    FacesContext facesContext = FacesContext.getCurrentInstance();
    ConfigurableNavigationHandler navigationHandler =
        (ConfigurableNavigationHandler) facesContext.getApplication().getNavigationHandler();
    NavigationCase navigationCase =
        navigationHandler.getNavigationCase(facesContext, null, outcome);

    HttpServletRequest request =
        (HttpServletRequest) facesContext.getExternalContext().getRequest();
    String path = navigationCase.getToViewId(facesContext);
    String query = buildQuery();
    redirect(request.getContextPath() + path + query);
  }
  
  void redirect(String url) {
    try {
      FacesContext facesContext = FacesContext.getCurrentInstance();
      facesContext.getExternalContext().redirect(url);
      facesContext.responseComplete(); // This is important!
      LOGGER.info(url);
    } catch (IOException exception) {
      throw new Exception(exception);
    }
  }
  
  String buildQuery() {
    if (uriQueryBuilder == null) {
      return Constant.EMPTY_STRING;
    }
    return uriQueryBuilder.build();
  }
  
  /**
   * Cette méthode permet d'obtenir {@link UriQueryBuilder} non nul.
   *
   * @return {@link UriQueryBuilder} non nul
   */
  public UriQueryBuilder uriQueryBuilder() {
    if (uriQueryBuilder == null) {
      uriQueryBuilder = new UriQueryBuilder();
      uriQueryBuilder.setAppendQuestionMarkIfNotBlank(true);
    }
    return uriQueryBuilder;
  }
  
  /**
   * Cette classe représente une exception de navigation.
   *
   * @author Christian
   *
   */
  public static class Exception extends RuntimeException {

    public Exception(Throwable cause) {
      super(cause);
    }

  }
}
