package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de nombre d'applications.
 *
 * @author Christian Yao Komenan
 */
public interface HasApplicationCountDto extends HasApplicationCount {

  /**
   * Identifiant json du nombre d'applications.
   */
  String JSON_APPLICATION_COUNT = "nombreApplications";
}
