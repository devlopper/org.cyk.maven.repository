package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateN1AsString {

  /**
   * Obtient le montant restant à valider pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @return le montant restant à valider pour l'année N+1 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToValidateN1AsString();

  /**
   * Définit le montant restant à valider pour l'année N+1, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToValidateN1AsString le montant restant à valider pour l'année N+1
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToValidateN1AsString(String remainingAmountToValidateN1AsString);

  /**
   * Identifiant java du montant restant à valider pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_VALIDATE_N1_AS_STRING =
      "remainingAmountToValidateN1AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName