package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N+2,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateN2AsString {

  /**
   * Obtient le montant restant à arbitrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @return le montant restant à arbitrer pour l'année N+2 sous forme de chaîne de caractères,
   *         {@code null} si aucun montant n'est défini
   */
  String getRemainingAmountToArbitrateN2AsString();

  /**
   * Définit le montant restant à arbitrer pour l'année N+2, sous forme de chaîne de caractères.
   *
   * @param remainingAmountToArbitrateN2AsString le montant restant à arbitrer pour l'année N+2
   *        sous forme de chaîne de caractères
   */
  void setRemainingAmountToArbitrateN2AsString(String remainingAmountToArbitrateN2AsString);

  /**
   * Identifiant java du montant restant à arbitrer pour l'année N+2, sous forme de chaîne de
   * caractères.
   */
  String FIELD_REMAINING_AMOUNT_TO_ARBITRATE_N2_AS_STRING =
      "remainingAmountToArbitrateN2AsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName