package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.StringCore;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'une page.
 *
 * @author Christian
 *
 */
@Getter
public abstract class AbstractPage extends AbstractController {

  protected String title;

  protected String contentTitle;

  @Setter
  protected boolean isRenderedAsDialog;

  protected ContentLoader contentLoader;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    setContentTitleFromRequestParameter();
    if (StringCore.isBlank(contentTitle)) {
      setContentTitleWhenBlank();
    }
  }

  /**
   * Cette méthode donne le titre de l'onglet du navigateur : {@link #title} s'il est renseigné,
   * sinon {@link #contentTitle}, le titre affiché dans la page (jamais un onglet vide).
   *
   * @return titre
   */
  public String getTitle() {
    return StringCore.isBlank(title) ? contentTitle : title;
  }

  void setContentTitleFromRequestParameter() {
    contentTitle = requestManager == null ? null
        : requestManager.getParameter(REQUEST_PARAMETER_CONTENT_TITLE);
  }

  protected void setContentTitleWhenBlank() {

  }

  /**
   * Cette méthode permet de préparer la page.
   */
  public void prepare() {
    prepareContent();
  }

  protected void prepareContent() {

  }
}
