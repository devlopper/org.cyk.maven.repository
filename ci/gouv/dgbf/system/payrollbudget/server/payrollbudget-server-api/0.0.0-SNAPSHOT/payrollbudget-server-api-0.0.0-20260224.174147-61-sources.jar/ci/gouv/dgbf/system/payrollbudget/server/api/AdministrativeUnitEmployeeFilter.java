package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.core.CollectionCore;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetIdentifier;
import ci.gouv.dgbf.system.employee.server.api.shared.FilterHasEmployeeIdentifier;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasCategoryIdentifier;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasGradeIdentifier;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitEmployeeDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitEmployeeFilter extends AbstractIdentifiableFilter
    implements FilterHasBudgetIdentifier, FilterHasAdministrativeUnitIdentifier,
    FilterHasBudgetAdministrativeUnitIdentifier, FilterHasEmployeeIdentifier,
    FilterHasCategoryIdentifier, FilterHasGradeIdentifier,
    FilterHasAdministrativeUnitEmployeeStatusCode, FilterHasAdministrativeUnitEmployeeStatusCodes,
    FilterHasAdministrativeUnitHasPresenceMovement {

  String budgetIdentifier;
  String administrativeUnitIdentifier;
  String employeeIdentifier;

  String budgetAdministrativeUnitIdentifier;
  String categoryIdentifier;
  String gradeIdentifier;
  String administrativeUnitEmployeeStatusCode;
  Set<String> administrativeUnitEmployeeStatusCodes;
  Boolean isAdministrativeUnitEmployeeHasPresenceMovement;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitEmployeeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public AdministrativeUnitEmployeeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetIdentifier(filter);
    updateAdministrativeUnitIdentifier(filter);
    updateEmployeeIdentifier(filter);

    updateBudgetAdministrativeUnitIdentifier(filter);
    updateCategoryIdentifier(filter);
    updateGradeIdentifier(filter);
    updateAdministrativeUnitEmployeeStatusCode(filter);
    updateAdministrativeUnitEmployeeStatusCodes(filter);
    updateAdministrativeUnitEmployeeHasPresenceMovement(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetIdentifier(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    updateFilterEmployeeIdentifier(filter);

    updateFilterBudgetAdministrativeUnitIdentifier(filter);
    updateFilterCategoryIdentifier(filter);
    updateFilterGradeIdentifier(filter);
    updateFilterAdministrativeUnitEmployeeStatusCode(filter);
    updateFilterAdministrativeUnitEmployeeStatusCodes(filter);
    updateFilterAdministrativeUnitEmployeeHasPresenceMovement(filter);
  }

  /**
   * Cette méthode permet de savoir si le filtre contient {@link AdministrativeUnitEmployeeStatus}
   * donné.
   *
   * @param administrativeUnitEmployeeStatus {@link AdministrativeUnitEmployeeStatus}
   * @return vrai si le filtre contient {@link AdministrativeUnitEmployeeStatus} donné
   */
  public boolean hasAdministrativeUnitEmployeeStatus(
      AdministrativeUnitEmployeeStatus administrativeUnitEmployeeStatus) {
    return administrativeUnitEmployeeStatus.getCode().equals(administrativeUnitEmployeeStatusCode)
        || CollectionCore.contains(administrativeUnitEmployeeStatusCodes,
            administrativeUnitEmployeeStatus.getCode());
  }
}
