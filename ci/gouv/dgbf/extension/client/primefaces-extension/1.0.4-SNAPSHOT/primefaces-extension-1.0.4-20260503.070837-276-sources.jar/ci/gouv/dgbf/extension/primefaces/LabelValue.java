package ci.gouv.dgbf.extension.primefaces;

import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente une libellé et une valeur.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class LabelValue {

  Text labelText;
  Text valueText;
  Style style;
  
  String labelTemplateFilePath;
  String valueTemplateFilePath;
  
  /**
   * {@link Style#getClassesAsString(Style)}.
   *
   * @return classes du style
   */
  public String getStyleClass() {
    return Style.getClassesAsString(style);
  }
  
  /**
   * Cette méthode permet d'assigner la classe du style.
   *
   * @param styleClass classe du style.
   */
  public void setStyleClass(String styleClass) {
    style().setClasses(styleClass);
  }
  
  Style style() {
    if (style == null) {
      style = new Style();
    }
    return style;
  }
  
  public static Builder newBuilder() {
    return new Builder();
  }
  
  /**
   * Cette classe représente un constructeur de {@link LabelValue}.
   *
   * @author Christian
   *
   */
  @Setter
  @Accessors(chain = true, fluent = true)
  public static class Builder {
    Text labelText;
    String label;
    String labelClass;
    
    Text valueText;
    String value;
    String valueClass;

    /**
     * Cette méthode permet de construire.
     *
     * @return {@link LabelValue}
     */
    public LabelValue build() {
      LabelValue labelValue = new LabelValue();
      if (labelText == null) {
        labelValue.labelText = Text.newBuilder().value(label).styleClass(labelClass).build();  
      } else {
        labelValue.labelText = labelText;
      }
      
      if (valueText == null) {
        labelValue.valueText = Text.newBuilder().value(value).styleClass(valueClass).build();  
      } else {
        labelValue.valueText = valueText;
      }
      
      return labelValue;
    }
  }
}
