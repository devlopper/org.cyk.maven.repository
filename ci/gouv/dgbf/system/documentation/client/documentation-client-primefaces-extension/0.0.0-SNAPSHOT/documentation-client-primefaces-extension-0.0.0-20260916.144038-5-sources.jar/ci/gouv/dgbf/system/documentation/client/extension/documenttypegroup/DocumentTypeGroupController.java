package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputsGroupController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.documentation.client.extension.documenttype.DocumentTypeSelectOneController;
import ci.gouv.dgbf.system.documentation.client.extension.documenttypesgroup.DocumentTypesGroupSelectOneController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupClient;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupRequestMapper;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupCreateRequestDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupService.DocumentTypeGroupUpdateRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.function.Consumer;
import java.util.function.Function;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentTypeGroupController extends AbstractController {

  @Inject
  DocumentTypeGroupClient client;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  DocumentTypeGroupRequestMapper requestMapper;

  @Inject
  @Getter
  DocumentTypeSelectOneController typeSelectOneController;

  @Inject
  @Getter
  DocumentTypesGroupSelectOneController groupSelectOneController;

  @Inject
  @Getter
  InputsGroupController inputsGroupController;

  @Inject
  @Getter
  DocumentTypeGroupFilterController filterController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = DocumentTypeGroupDto.NAME;

    listController.setEntityClass(DocumentTypeGroupDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(DocumentTypeGroupService.PATH);
    listController.setFilterController(filterController);
    listController.getDataTable().getFilterButton().setRendered(true);

    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        HasTypeIdentifierDto.JSON_TYPE_IDENTIFIER, HasTypeAsStringDto.JSON_TYPE_AS_STRING,
        HasGroupIdentifierDto.JSON_GROUP_IDENTIFIER,
        HasGroupAsStringDto.JSON_GROUP_AS_STRING);
    listController.getReadController().setProjection(projection);

    listController.getGotoReadPageButton().setRendered(true);
    listController.getGotoReadPageButton().setOutcome(DocumentTypeGroupReadIndexPage.OUTCOME);

    listController.initialize();

    listController.getCreateController().setFunction(createControllerFunction());

    listController.getUpdateController().addEntityConsumer(updateControllerEntityConsumer());
    listController.getUpdateController().setFunction(updateControllerFunction());

    typeSelectOneController.getSelectOneMenu().addValueConsumer(typeConsumer());
    groupSelectOneController.getSelectOneMenu().addValueConsumer(groupConsumer());

    inputsGroupController.add(typeSelectOneController.getSelectOneMenu(),
        groupSelectOneController.getSelectOneMenu());
  }

  Consumer<String> typeConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupDto.class)
        .setTypeIdentifier(identifier);
  }

  Consumer<String> groupConsumer() {
    return identifier -> listController
        .getCreateControllerOrUpdateControllerEntityAs(DocumentTypeGroupDto.class)
        .setGroupIdentifier(identifier);
  }

  // Create

  Function<Object, Object> createControllerFunction() {
    return entity -> {
      DocumentTypeGroupCreateRequestDto request =
          requestMapper.mapCreate((DocumentTypeGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.create(request);
    };
  }

  // Update

  Consumer<Object> updateControllerEntityConsumer() {
    return entity -> {
      typeSelectOneController.getSelectOneMenu()
          .writeValue(((DocumentTypeGroupDto) entity).getTypeIdentifier());
      groupSelectOneController.getSelectOneMenu()
          .writeValue(((DocumentTypeGroupDto) entity).getGroupIdentifier());
    };
  }

  Function<Object, Object> updateControllerFunction() {
    return entity -> {
      DocumentTypeGroupUpdateRequestDto request =
          requestMapper.mapUpdate((DocumentTypeGroupDto) entity);
      request.setAuditWho(userIdentifier);
      return client.update(request);
    };
  }
}
