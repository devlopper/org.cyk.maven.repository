package ci.gouv.dgbf.system.payrollreconciliation.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollComponentCorrespondenceDto}.
 *
 * @author desysoft
 *
 */
@Getter
@Setter
public class PayrollComponentCorrespondenceFilter extends AbstractIdentifiableFilter {

  /**
   * Code du poste Solde AN 2000.
   */
  private String legacyComponentCode;

  /**
   * Code de la catégorie Solde AN 2000.
   */
  private String legacyCategoryCode;

  /**
   * Code de l'échelle corps Solde AN 2000.
   */
  private String legacyScaleCode;

  /**
   * Code du poste de paie cible.
   */
  private String payrollComponentCode;

  /**
   * Recherche libre.
   */
  private String query;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollComponentCorrespondenceFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollComponentCorrespondenceFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    legacyComponentCode = getLegacyComponentCode(filter);
    legacyCategoryCode = getLegacyCategoryCode(filter);
    legacyScaleCode = getLegacyScaleCode(filter);
    payrollComponentCode = getPayrollComponentCode(filter);
    query = getQuery(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setLegacyComponentCode(filter, legacyComponentCode);
    setLegacyCategoryCode(filter, legacyCategoryCode);
    setLegacyScaleCode(filter, legacyScaleCode);
    setPayrollComponentCode(filter, payrollComponentCode);
    setQuery(filter, query);
  }

  /**
   * Cette méthode permet d'assigner le code du poste Solde AN 2000.
   *
   * @param filter filtre
   * @param legacyComponentCode code du poste Solde AN 2000
   */
  public static void setLegacyComponentCode(FilterDto filter, String legacyComponentCode) {
    set(filter, JSON_LEGACY_COMPONENT_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(legacyComponentCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du poste Solde AN 2000.
   *
   * @param filter filtre
   * @return code du poste Solde AN 2000
   */
  public static String getLegacyComponentCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LEGACY_COMPONENT_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code de la catégorie Solde AN 2000.
   *
   * @param filter filtre
   * @param legacyCategoryCode code de la catégorie Solde AN 2000
   */
  public static void setLegacyCategoryCode(FilterDto filter, String legacyCategoryCode) {
    set(filter, JSON_LEGACY_CATEGORY_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(legacyCategoryCode));
  }

  /**
   * Cette méthode permet d'obtenir le code de la catégorie Solde AN 2000.
   *
   * @param filter filtre
   * @return code de la catégorie Solde AN 2000
   */
  public static String getLegacyCategoryCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LEGACY_CATEGORY_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code de l'échelle corps Solde AN 2000.
   *
   * @param filter filtre
   * @param legacyScaleCode code de l'échelle corps Solde AN 2000
   */
  public static void setLegacyScaleCode(FilterDto filter, String legacyScaleCode) {
    set(filter, JSON_LEGACY_SCALE_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(legacyScaleCode));
  }

  /**
   * Cette méthode permet d'obtenir le code de l'échelle corps Solde AN 2000.
   *
   * @param filter filtre
   * @return code de l'échelle corps Solde AN 2000
   */
  public static String getLegacyScaleCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_LEGACY_SCALE_CODE));
  }

  /**
   * Cette méthode permet d'assigner le code du poste de paie cible.
   *
   * @param filter filtre
   * @param payrollComponentCode code du poste de paie cible
   */
  public static void setPayrollComponentCode(FilterDto filter, String payrollComponentCode) {
    set(filter, JSON_PAYROLL_COMPONENT_CODE, f -> f.getValueAsString(),
        f -> f.setValueAsString(payrollComponentCode));
  }

  /**
   * Cette méthode permet d'obtenir le code du poste de paie cible.
   *
   * @param filter filtre
   * @return code du poste de paie cible
   */
  public static String getPayrollComponentCode(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PAYROLL_COMPONENT_CODE));
  }

  /**
   * Cette méthode permet d'assigner la recherche libre.
   *
   * @param filter filtre
   * @param query recherche libre
   */
  public static void setQuery(FilterDto filter, String query) {
    set(filter, JSON_QUERY, f -> f.getValueAsString(), f -> f.setValueAsString(query));
  }

  /**
   * Cette méthode permet d'obtenir la recherche libre.
   *
   * @param filter filtre
   * @return recherche libre
   */
  public static String getQuery(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_QUERY));
  }

  /**
   * Identifiant json champ {@link PayrollComponentCorrespondenceFilter#legacyComponentCode}.
   */
  public static final String JSON_LEGACY_COMPONENT_CODE =
      PayrollComponentCorrespondenceDto.JSON_LEGACY_COMPONENT_CODE;

  /**
   * Identifiant json champ {@link PayrollComponentCorrespondenceFilter#legacyCategoryCode}.
   */
  public static final String JSON_LEGACY_CATEGORY_CODE =
      PayrollComponentCorrespondenceDto.JSON_LEGACY_CATEGORY_CODE;

  /**
   * Identifiant json champ {@link PayrollComponentCorrespondenceFilter#legacyScaleCode}.
   */
  public static final String JSON_LEGACY_SCALE_CODE =
      PayrollComponentCorrespondenceDto.JSON_LEGACY_SCALE_CODE;

  /**
   * Identifiant json champ {@link PayrollComponentCorrespondenceFilter#payrollComponentCode}.
   */
  public static final String JSON_PAYROLL_COMPONENT_CODE =
      PayrollComponentCorrespondenceDto.JSON_PAYROLL_COMPONENT_CODE;

  /**
   * Identifiant json champ {@link PayrollComponentCorrespondenceFilter#query}.
   */
  public static final String JSON_QUERY = "recherche";

}
