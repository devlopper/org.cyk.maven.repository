package ci.gouv.dgbf.system.sharing.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelCreateRequestDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelGetManyResponseDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceVisibilityLevelService.ResourceVisibilityLevelUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ResourceVisibilityLevelService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ResourceVisibilityLevelClient extends AbstractClient<ResourceVisibilityLevelService>
    implements GetByIdentifier<ResourceVisibilityLevelDto>,
    GetMany<ResourceVisibilityLevelGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ResourceVisibilityLevelClient service(ResourceVisibilityLevelService service) {
    return (ResourceVisibilityLevelClient) super.service(service);
  }

  /**
   * {@link ResourceVisibilityLevelService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ResourceVisibilityLevelCreateRequestDto request) {
    return new CreateExecutor(ResourceVisibilityLevelService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ResourceVisibilityLevelGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ResourceVisibilityLevelGetManyResponseDto>(
        ResourceVisibilityLevelGetManyResponseDto.class,
        ResourceVisibilityLevelService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ResourceVisibilityLevelGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ResourceVisibilityLevelService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ResourceVisibilityLevelDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ResourceVisibilityLevelDto>(ResourceVisibilityLevelDto.class,
        ResourceVisibilityLevelService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ResourceVisibilityLevelDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ResourceVisibilityLevelService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public ResourceVisibilityLevelDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ResourceVisibilityLevelDto>(ResourceVisibilityLevelDto.class,
        ResourceVisibilityLevelService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ResourceVisibilityLevelDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ResourceVisibilityLevelService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ResourceVisibilityLevelUpdateRequestDto request) {
    return new IdentifiableExecutor(ResourceVisibilityLevelService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ResourceVisibilityLevelService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ResourceVisibilityLevelService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
