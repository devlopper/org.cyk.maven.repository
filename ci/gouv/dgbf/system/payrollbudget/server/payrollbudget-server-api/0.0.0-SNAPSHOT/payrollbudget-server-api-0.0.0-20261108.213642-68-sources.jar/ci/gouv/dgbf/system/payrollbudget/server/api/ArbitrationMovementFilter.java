package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueGetter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterValueSetter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Critères de recherche des lignes d'arbitrage.
 *
 * <p>Les critères sont définis ici plutôt que dans des interfaces {@code FilterHasXxx} partagées :
 * ils ne servent qu'à ce filtre. Le triptyque partagé n'a d'intérêt que pour un critère utilisé par
 * plusieurs filtres.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ArbitrationMovementFilter extends AbstractIdentifiableFilter {

  /**
   * Dossier dont on veut les lignes.
   */
  String dossierIdentifier;

  /**
   * Budget de rattachement.
   */
  String budgetIdentifier;

  /**
   * Unité administrative où la ligne produit son effet.
   */
  String administrativeUnitIdentifier;

  /**
   * Agent concerné.
   */
  String employeeIdentifier;

  /**
   * Code de la nature du mouvement.
   */
  String movementTypeCode;

  /**
   * Nature de l'élément déversé.
   */
  String elementType;

  /**
   * Code {@link ArbitrationMovementStatus}.
   */
  String statusCode;

  public ArbitrationMovementFilter() {
    super();
  }

  public ArbitrationMovementFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    setDossierIdentifier(read(filter, ArbitrationMovementDto.JSON_DOSSIER_IDENTIFIER));
    setBudgetIdentifier(read(filter, ArbitrationMovementDto.JSON_BUDGET_IDENTIFIER));
    setAdministrativeUnitIdentifier(
        read(filter, ArbitrationMovementDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER));
    setEmployeeIdentifier(read(filter, ArbitrationMovementDto.JSON_EMPLOYEE_IDENTIFIER));
    setMovementTypeCode(read(filter, ArbitrationMovementDto.JSON_MOVEMENT_TYPE_CODE));
    setElementType(read(filter, ArbitrationMovementDto.JSON_ELEMENT_TYPE));
    setStatusCode(read(filter, ArbitrationMovementDto.JSON_STATUS_CODE));
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    write(filter, ArbitrationMovementDto.JSON_DOSSIER_IDENTIFIER, getDossierIdentifier());
    write(filter, ArbitrationMovementDto.JSON_BUDGET_IDENTIFIER, getBudgetIdentifier());
    write(filter, ArbitrationMovementDto.JSON_ADMINISTRATIVE_UNIT_IDENTIFIER,
        getAdministrativeUnitIdentifier());
    write(filter, ArbitrationMovementDto.JSON_EMPLOYEE_IDENTIFIER, getEmployeeIdentifier());
    write(filter, ArbitrationMovementDto.JSON_MOVEMENT_TYPE_CODE, getMovementTypeCode());
    write(filter, ArbitrationMovementDto.JSON_ELEMENT_TYPE, getElementType());
    write(filter, ArbitrationMovementDto.JSON_STATUS_CODE, getStatusCode());
  }

  /**
   * Lit un critère textuel du filtre.
   *
   * <p>Publique car la couche de persistance en a besoin pour ses prédicats, sous la forme
   * {@code dto -> ArbitrationMovementFilter.read(dto, clé)}.</p>
   *
   * @param filter filtre à lire
   * @param key clé du critère
   * @return la valeur, ou {@code null}
   */
  public static String read(FilterDto filter, String key) {
    return FilterValueGetter.get(filter, dto -> dto.getFieldValueAsStringByName(key));
  }

  /**
   * Écrit un critère textuel dans le filtre.
   *
   * <p>Publique pour la même raison que {@link #read(FilterDto, String)} : les filtres voisins du
   * module d'arbitrage s'en servent plutôt que de dupliquer la mécanique.</p>
   *
   * @param filter filtre à compléter
   * @param key clé du critère
   * @param value valeur à poser
   */
  public static void write(FilterDto filter, String key, String value) {
    FilterValueSetter.set(filter, key, field -> field.getValueAsString(),
        field -> field.setValueAsString(value));
  }
}
