package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.core.Core;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.IdentifiableActionController;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentFilter;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentAcceptRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentService.IdentityPolicyConsentRefuseRequestDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityPolicyConsentStatus;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionClient;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionDto;
import ci.gouv.dgbf.system.identity.server.api.PolicyVersionFilter;
import ci.gouv.dgbf.system.identity.server.api.UserRole;
import ci.gouv.dgbf.system.identity.server.api.shared.HasIdentityAsStringDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link IdentityPolicyConsentDto}. Le mode
 * back-office (consultation de tous les consentements, filtrable) ou self-service (mes
 * consentements, actionnable) est calculé selon le rôle de l'utilisateur courant
 * ({@link UserRole#ADMINISTRATOR}), et non porté par une classe distincte.
 *
 * @author desysoft
 *
 */
@Dependent
public class IdentityPolicyConsentController extends AbstractController {

  static final String EMPTY_CONTENT_FILE_PATH = "/extension/empty.xhtml";

  /**
   * Identifiant ne correspondant à aucune {@link IdentityDto} réelle, utilisé en repli à
   * l'initialisation de {@link #filterController} en self-service quand
   * {@link #identityIdentifier} n'a pas pu être résolu.
   */
  static final String UNRESOLVABLE_IDENTITY_IDENTIFIER = "00000000-0000-0000-0000-000000000000";

  @Inject
  IdentityPolicyConsentClient client;

  @Inject
  IdentityClient identityClient;

  @Inject
  PolicyVersionClient policyVersionClient;

  /**
   * Identifiant réel (PK) de l'{@link IdentityDto} de l'utilisateur connecté, distinct de
   * {@link #userIdentifier} qui porte le login Keycloak (ex. email), résolu par
   * {@link #resolveConnectedIdentityIdentifier()}.
   */
  String identityIdentifier;

  @Inject
  @Getter
  ListController listController;

  @Inject
  @Getter
  IdentityPolicyConsentFilterController filterController;

  @Inject
  @Getter
  IdentifiableActionController acceptActionController;

  @Inject
  @Getter
  IdentifiableActionController refuseActionController;

  @Getter
  boolean administrator;

  /**
   * Politiques actives pour lesquelles l'identité connectée n'a exprimé aucune décision
   * (RU_IDT_004) — calculée côté client par différence entre les versions de politique actives
   * et les versions déjà couvertes par un consentement de l'identité (TCH_IDT_534, décision de
   * conception du 2026-09-02 : pas de nouveau verbe API, composition de deux lectures
   * existantes). Toujours vide en back-office.
   */
  @Getter
  List<PolicyVersionDto> undecidedActivePolicyVersions = Collections.emptyList();

  /**
   * Cette méthode permet d'initialiser. Appelée explicitement par la page appelante (jamais
   * automatiquement depuis {@link #postConstruct()}), afin de lui laisser l'occasion de
   * pré-positionner {@link #filterController}'s filter (ex. {@code identityIdentifier}) avant
   * l'initialisation — même patron que {@code IdentitiesGroupReadPage}/{@code
   * IdentityGroupReadPage}.
   */
  public void initialize() {
    administrator = computeIsAdministrator();
    name = administrator ? "Consentements" : "Mes consentements";

    listController.setEntityClass(IdentityPolicyConsentDto.class);
    listController.setClient(client);

    ProjectionDto projection = new ProjectionDto();
    listController.setFilterController(filterController);
    filterController.initialize();
    if (administrator) {
      projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
          HasIdentityAsStringDto.JSON_IDENTITY_AS_STRING,
          IdentityPolicyConsentDto.JSON_POLICY_VERSION_AS_STRING, HasStatusDto.JSON_STATUS,
          HasStatusAsStringDto.JSON_STATUS_AS_STRING);
    } else {
      identityIdentifier = resolveConnectedIdentityIdentifier();
      projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
          IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER,
          IdentityPolicyConsentDto.JSON_POLICY_VERSION_AS_STRING, HasStatusDto.JSON_STATUS,
          HasStatusAsStringDto.JSON_STATUS_AS_STRING);
      /*
       * DynamicQueryParameters.Predicate.addable() ignore silencieusement un prédicat de valeur
       * nulle (au lieu de ne renvoyer aucun résultat) : si identityIdentifier n'a pas pu être
       * résolu, un identifiant improbable garantit une liste vide plutôt qu'une requête non
       * filtrée montrant les consentements de toutes les identités. Fixé directement sur le
       * filtre de filterController (partagé avec component/filterForm.xhtml) : seul le statut y
       * reste modifiable par l'utilisateur en self-service.
       */
      filterController.getFilter().setIdentityIdentifier(
          Core.getOrDefaultIfNull(identityIdentifier, UNRESOLVABLE_IDENTITY_IDENTIFIER));
      undecidedActivePolicyVersions = computeUndecidedActivePolicyVersions();
    }
    listController.getReadController().setProjection(projection);

    /*
     * useAsReadOnly() masque aussi le bouton de filtre : les deux vues ont besoin du filtre par
     * statut (back-office : aussi identité et version de politique), on le réaffiche
     * explicitement (VC9). Ceci doit précéder listController.initialize() :
     * ListController.initialize() résout le chemin du formulaire de filtre
     * (component/filterForm.xhtml vs /extension/empty.xhtml) selon l'état "rendered" du bouton de
     * filtre à cet instant précis.
     */
    listController.useAsReadOnly();
    listController.getDataTable().getFilterButton().setRendered(true);

    listController.initialize();

    /*
     * useAsReadOnly() masque les boutons Ajouter/Modifier mais ListController.initialize()
     * pointe quand même createDialog/updateDialog vers component/saveForm.xhtml (le ui:include
     * de la dialog est résolu même quand le bouton qui l'ouvre est caché). Cet écran n'a ni
     * création ni modification : on redirige ces dialogues vers le composant vide partagé.
     */
    listController.getCreateDialog().setContentFilePath(EMPTY_CONTENT_FILE_PATH);
    listController.getUpdateDialog().setContentFilePath(EMPTY_CONTENT_FILE_PATH);

    if (!administrator) {
      acceptActionController.setFunction(acceptFunction());
      listController.configureAction(acceptActionController);
      acceptActionController
          .addResponseConsumer(response -> refreshUndecidedActivePolicyVersions());

      refuseActionController.setFunction(refuseFunction());
      listController.configureAction(refuseActionController);
      refuseActionController
          .addResponseConsumer(response -> refreshUndecidedActivePolicyVersions());

      /*
       * ListController.initialize() dimensionne la colonne d'actions uniquement à partir des
       * boutons CRUD standards (consulter/modifier/supprimer), tous masqués ici (useAsReadOnly()).
       * Sans cet élargissement explicite, les boutons Accepter/Refuser ci-dessus restent dans une
       * colonne de largeur 0px et n'apparaissent pas à l'écran.
       */
      listController.getDataTable().getActionColumn().setWidth("260px");
    }
  }

  void refreshUndecidedActivePolicyVersions() {
    undecidedActivePolicyVersions = computeUndecidedActivePolicyVersions();
  }

  /**
   * Cette méthode permet de calculer les politiques actives pour lesquelles l'identité connectée
   * n'a exprimé aucune décision (RU_IDT_004) — versions actives moins celles déjà couvertes par
   * un consentement existant de cette identité, sans rien persister (RG_IDT_CST_02). Composition
   * côté client de deux lectures existantes plutôt qu'un nouveau verbe API dédié (TCH_IDT_534,
   * décision de conception du 2026-09-02).
   *
   * @return politiques actives sans décision, ou liste vide si l'identité n'a pas pu être résolue
   */
  @SuppressWarnings("unchecked")
  List<PolicyVersionDto> computeUndecidedActivePolicyVersions() {
    if (identityIdentifier == null) {
      return Collections.emptyList();
    }
    PolicyVersionFilter activeFilter = new PolicyVersionFilter();
    activeFilter.setIsActive(true);
    ProjectionDto activeProjection = new ProjectionDto();
    activeProjection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        PolicyVersionDto.JSON_POLICY_AS_STRING);
    List<PolicyVersionDto> activePolicyVersions =
        (List<PolicyVersionDto>) AbstractGetByPageResponseDto.getDatas(policyVersionClient
            .getMany(activeProjection, activeFilter.toDto(), null, userIdentifier, null));

    IdentityPolicyConsentFilter consentFilter = new IdentityPolicyConsentFilter();
    consentFilter.setIdentityIdentifier(identityIdentifier);
    ProjectionDto consentProjection = new ProjectionDto();
    consentProjection.addNames(IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER);
    List<IdentityPolicyConsentDto> consents =
        (List<IdentityPolicyConsentDto>) AbstractGetByPageResponseDto.getDatas(client
            .getMany(consentProjection, consentFilter.toDto(), null, userIdentifier, null));
    Set<String> decidedPolicyVersionIdentifiers = consents.stream()
        .map(IdentityPolicyConsentDto::getPolicyVersionIdentifier).collect(Collectors.toSet());

    return activePolicyVersions.stream()
        .filter(policyVersion -> !decidedPolicyVersionIdentifiers
            .contains(policyVersion.getIdentifier()))
        .toList();
  }

  /**
   * Cette méthode permet de calculer si l'utilisateur courant consulte cet écran en tant
   * qu'administrateur (back-office, tous les consentements) ou en self-service (ses propres
   * consentements).
   *
   * @return si l'utilisateur courant est administrateur
   */
  protected boolean computeIsAdministrator() {
    return isUserInRole(UserRole.ADMINISTRATOR);
  }

  /**
   * Cette méthode permet de résoudre le PK {@link IdentityDto} de l'utilisateur connecté à partir
   * de son login Keycloak ({@link #userIdentifier}, ex. email) : les deux espaces d'identifiants
   * sont distincts, {@link IdentityDto#getIdentifier()} n'est jamais généré à partir du login
   * (voir {@code AbstractIdentifiable.generateIdentifier()}, toujours un UUID aléatoire).
   *
   * @return identifiant {@link IdentityDto} correspondant à {@link #userIdentifier}, ou
   *         {@code null} si aucune identité ne correspond
   */
  String resolveConnectedIdentityIdentifier() {
    IdentityFilter filter = new IdentityFilter();
    filter.setEmailAddress(userIdentifier);
    ProjectionDto projection = new ProjectionDto();
    projection.addNames(AbstractIdentifiableDto.JSON_IDENTIFIER);
    IdentityDto identity = identityClient.getOne(projection, filter.toDto(), userIdentifier, null);
    return identity == null ? null : identity.getIdentifier();
  }

  // Visibilité des actions selon le statut courant (bascule libre Accepté <-> Refusé,
  // RG_IDT_CST_04, refonte des statuts 2026-08-21 : plus de statut "Créé" intermédiaire, plus de
  // retrait séparé). component/listForm.xhtml est partagé entre les deux modes : en back-office
  // (lecture seule), ces prédicats sont toujours faux.

  /**
   * Cette méthode permet de savoir si un consentement peut être accepté (déjà Refusé, bascule
   * vers Accepté).
   *
   * @param record consentement
   * @return si le consentement peut être accepté
   */
  public boolean isAcceptable(Object record) {
    return !administrator && isStatus(record, IdentityPolicyConsentStatus.REFUSED);
  }

  /**
   * Cette méthode permet de savoir si un consentement peut être refusé (déjà Accepté, bascule
   * vers Refusé — couvre aussi l'ancien "retrait volontaire", fusionné ici).
   *
   * @param record consentement
   * @return si le consentement peut être refusé
   */
  public boolean isRefusable(Object record) {
    return !administrator && isStatus(record, IdentityPolicyConsentStatus.ACCEPTED);
  }

  boolean isStatus(Object record, IdentityPolicyConsentStatus status) {
    return status.equals(((IdentityPolicyConsentDto) record).getStatus());
  }

  // Actions

  Function<String, IdentifiableResponseDto> acceptFunction() {
    return policyVersionIdentifier -> {
      IdentityPolicyConsentAcceptRequestDto request = new IdentityPolicyConsentAcceptRequestDto();
      request.setIdentityIdentifier(identityIdentifier);
      request.setPolicyVersionIdentifier(policyVersionIdentifier);
      request.setFrontEndBaseUri("");
      request.setAuditWho(userIdentifier);
      return client.accept(request);
    };
  }

  Function<String, IdentifiableResponseDto> refuseFunction() {
    return policyVersionIdentifier -> {
      IdentityPolicyConsentRefuseRequestDto request = new IdentityPolicyConsentRefuseRequestDto();
      request.setIdentityIdentifier(identityIdentifier);
      request.setPolicyVersionIdentifier(policyVersionIdentifier);
      request.setFrontEndBaseUri("");
      request.setAuditWho(userIdentifier);
      return client.refuse(request);
    };
  }
}
