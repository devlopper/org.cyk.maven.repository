package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de nombre d'opérations.
 *
 * @author Christian
 */
public interface HasOperationCount extends HasField {

  /**
   * Cette méthode permet d'obtenir le nombre d'opérations.
   *
   * @return le nombre d'opérations
   */
  Integer getOperationCount();

  /**
   * Cette méthode permet d'assigner le nombre d'opérations.
   *
   * @param operationCount le nombre d'opérations
   */
  void setOperationCount(Integer operationCount);

  /**
   * Identifiant java du nombre d'opérations.
   */
  String FIELD_OPERATION_COUNT = "operationCount";
}
