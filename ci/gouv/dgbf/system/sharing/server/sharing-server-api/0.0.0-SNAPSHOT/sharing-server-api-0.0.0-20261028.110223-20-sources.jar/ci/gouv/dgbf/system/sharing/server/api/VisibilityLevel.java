package ci.gouv.dgbf.system.sharing.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les niveaux de visibilité d'une {@link ResourceDto} pour un utilisateur.
 * <p>
 * L'ordre sert à la règle "le plus permissif l'emporte" : plus la valeur est grande, plus le
 * niveau est permissif.
 * </p>
 *
 * @author Christian
 *
 */
@Getter
public enum VisibilityLevel {

  /**
   * {@link VisibilityLevelCode#FULL} : visibilité complète.
   */
  FULL(VisibilityLevelCode.FULL, "Complet", 3),
  /**
   * {@link VisibilityLevelCode#SUMMARY} : existence et métadonnées visibles, détail masqué.
   */
  SUMMARY(VisibilityLevelCode.SUMMARY, "Résumé", 2),
  /**
   * {@link VisibilityLevelCode#NONE} : ressource invisible.
   */
  NONE(VisibilityLevelCode.NONE, "Aucun", 1)

  ;

  private VisibilityLevel(String code, String name, int order) {
    this.code = code;
    this.name = name;
    this.order = order;
  }

  private String code;
  private String name;
  private int order;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link VisibilityLevel} par code.
   *
   * @param code code
   * @return {@link VisibilityLevel}
   */
  public static VisibilityLevel getByCode(String code) {
    return Stream.of(VisibilityLevel.values()).filter(level -> level.getCode().equals(code))
        .findFirst()
        .orElseThrow(
            () -> new IllegalArgumentException("Code de niveau de visibilité inconnu : " + code));
  }
}
