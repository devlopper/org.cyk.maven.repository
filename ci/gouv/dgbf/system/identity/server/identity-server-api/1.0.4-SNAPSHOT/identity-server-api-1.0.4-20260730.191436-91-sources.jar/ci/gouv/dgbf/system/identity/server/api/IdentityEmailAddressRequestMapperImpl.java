package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityEmailAddressDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T19:14:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityEmailAddressRequestMapperImpl implements IdentityEmailAddressRequestMapper {

    @Override
    public IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto mapCreate(IdentityEmailAddressDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto identityEmailAddressCreateRequestDto = new IdentityEmailAddressService.IdentityEmailAddressCreateRequestDto();

        identityEmailAddressCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityEmailAddressCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityEmailAddressCreateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityEmailAddressCreateRequestDto.setEmailAddress( arg0.getEmailAddress() );

        return identityEmailAddressCreateRequestDto;
    }

    @Override
    public IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto mapUpdate(IdentityEmailAddressDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto identityEmailAddressUpdateRequestDto = new IdentityEmailAddressService.IdentityEmailAddressUpdateRequestDto();

        identityEmailAddressUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityEmailAddressUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityEmailAddressUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identityEmailAddressUpdateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityEmailAddressUpdateRequestDto.setEmailAddress( arg0.getEmailAddress() );

        return identityEmailAddressUpdateRequestDto;
    }
}
