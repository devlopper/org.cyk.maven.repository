package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentityPolicyConsentDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-10-27T14:44:05+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentityPolicyConsentRequestMapperImpl implements IdentityPolicyConsentRequestMapper {

    @Override
    public IdentityPolicyConsentService.IdentityPolicyConsentCreateRequestDto mapCreate(IdentityPolicyConsentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityPolicyConsentService.IdentityPolicyConsentCreateRequestDto identityPolicyConsentCreateRequestDto = new IdentityPolicyConsentService.IdentityPolicyConsentCreateRequestDto();

        identityPolicyConsentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityPolicyConsentCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityPolicyConsentCreateRequestDto.setIdentityIdentifier( arg0.getIdentityIdentifier() );
        identityPolicyConsentCreateRequestDto.setPolicyVersionIdentifier( arg0.getPolicyVersionIdentifier() );
        identityPolicyConsentCreateRequestDto.setStatus( arg0.getStatus() );

        return identityPolicyConsentCreateRequestDto;
    }

    @Override
    public IdentityPolicyConsentService.IdentityPolicyConsentUpdateRequestDto mapUpdate(IdentityPolicyConsentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentityPolicyConsentService.IdentityPolicyConsentUpdateRequestDto identityPolicyConsentUpdateRequestDto = new IdentityPolicyConsentService.IdentityPolicyConsentUpdateRequestDto();

        identityPolicyConsentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identityPolicyConsentUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identityPolicyConsentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identityPolicyConsentUpdateRequestDto.setStatus( arg0.getStatus() );

        return identityPolicyConsentUpdateRequestDto;
    }
}
