package ci.gouv.dgbf.system.localauthority.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ProcedureDetailDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-13T08:52:07+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ProcedureDetailRequestMapperImpl implements ProcedureDetailRequestMapper {

    @Override
    public ProcedureDetailService.ProcedureDetailCreateRequestDto mapCreate(ProcedureDetailDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureDetailService.ProcedureDetailCreateRequestDto procedureDetailCreateRequestDto = new ProcedureDetailService.ProcedureDetailCreateRequestDto();

        procedureDetailCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureDetailCreateRequestDto.setName( arg0.getName() );
        procedureDetailCreateRequestDto.setProcedureIdentifier( arg0.getProcedureIdentifier() );
        procedureDetailCreateRequestDto.setOrder( arg0.getOrder() );
        procedureDetailCreateRequestDto.setDate( arg0.getDate() );

        return procedureDetailCreateRequestDto;
    }

    @Override
    public ProcedureDetailService.ProcedureDetailUpdateRequestDto mapUpdate(ProcedureDetailDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ProcedureDetailService.ProcedureDetailUpdateRequestDto procedureDetailUpdateRequestDto = new ProcedureDetailService.ProcedureDetailUpdateRequestDto();

        procedureDetailUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        procedureDetailUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        procedureDetailUpdateRequestDto.setName( arg0.getName() );
        procedureDetailUpdateRequestDto.setProcedureIdentifier( arg0.getProcedureIdentifier() );
        procedureDetailUpdateRequestDto.setOrder( arg0.getOrder() );
        procedureDetailUpdateRequestDto.setDate( arg0.getDate() );

        return procedureDetailUpdateRequestDto;
    }
}
