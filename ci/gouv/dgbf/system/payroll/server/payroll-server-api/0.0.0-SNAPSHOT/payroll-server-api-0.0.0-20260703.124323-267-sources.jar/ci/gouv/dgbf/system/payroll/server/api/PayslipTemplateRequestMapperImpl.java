package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipTemplateDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipTemplateRequestMapperImpl implements PayslipTemplateRequestMapper {

    @Override
    public PayslipTemplateService.PayslipTemplateCreateRequestDto mapCreate(PayslipTemplateDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTemplateService.PayslipTemplateCreateRequestDto payslipTemplateCreateRequestDto = new PayslipTemplateService.PayslipTemplateCreateRequestDto();

        payslipTemplateCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTemplateCreateRequestDto.setCode( arg0.getCode() );
        payslipTemplateCreateRequestDto.setName( arg0.getName() );

        return payslipTemplateCreateRequestDto;
    }

    @Override
    public PayslipTemplateService.PayslipTemplateUpdateRequestDto mapUpdate(PayslipTemplateDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipTemplateService.PayslipTemplateUpdateRequestDto payslipTemplateUpdateRequestDto = new PayslipTemplateService.PayslipTemplateUpdateRequestDto();

        payslipTemplateUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipTemplateUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipTemplateUpdateRequestDto.setCode( arg0.getCode() );
        payslipTemplateUpdateRequestDto.setName( arg0.getName() );

        return payslipTemplateUpdateRequestDto;
    }
}
