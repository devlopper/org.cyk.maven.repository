package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionService.SectionCreateRequestDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.SectionService.SectionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link SectionDto}.
 *
 * @author stephane
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link SectionDto}.

    @author stephane
               """)
public interface SectionRequestMapper extends RequestMapper<SectionDto,
    SectionCreateRequestDto, SectionUpdateRequestDto> {

}
