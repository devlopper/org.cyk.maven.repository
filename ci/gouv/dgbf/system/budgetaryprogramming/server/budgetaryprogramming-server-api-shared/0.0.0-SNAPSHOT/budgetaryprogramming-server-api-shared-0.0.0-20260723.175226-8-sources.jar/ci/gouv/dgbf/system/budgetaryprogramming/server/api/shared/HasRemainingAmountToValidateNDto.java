package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à valider pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToValidateNDto extends HasRemainingAmountToValidateN {

  /**
   * Identifiant json du montant restant à valider pour l'année N.
   */
  String JSON_REMAINING_AMOUNT_TO_VALIDATE_N = "montantResteAValiderN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
