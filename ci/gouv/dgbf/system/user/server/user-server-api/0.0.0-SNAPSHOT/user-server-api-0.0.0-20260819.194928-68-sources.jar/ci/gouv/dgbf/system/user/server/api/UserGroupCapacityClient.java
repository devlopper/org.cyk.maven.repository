package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.user.server.api.UserGroupCapacityService.UserGroupCapacityCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupCapacityService.UserGroupCapacityGetManyResponseDto;
import ci.gouv.dgbf.system.user.server.api.UserGroupCapacityService.UserGroupCapacityUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link UserGroupCapacityDto}.
 *
 * @author BoobaCool
 */
@ApplicationScoped
public class UserGroupCapacityClient extends AbstractClient<UserGroupCapacityService>
    implements GetByIdentifier<UserGroupCapacityDto>,
    GetMany<UserGroupCapacityGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link UserGroupCapacityService}
   * @return client {@link UserGroupCapacityClient}
   */
  @Override
  public UserGroupCapacityClient service(UserGroupCapacityService service) {
    return (UserGroupCapacityClient) super.service(service);
  }

  /**
   * {@link UserGroupCapacityService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(UserGroupCapacityCreateRequestDto request) {
    return new CreateExecutor(UserGroupCapacityService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link UserGroupCapacityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public UserGroupCapacityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<UserGroupCapacityGetManyResponseDto>(
        UserGroupCapacityGetManyResponseDto.class,
        UserGroupCapacityService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link UserGroupCapacityService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserGroupCapacityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link UserGroupCapacityService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public UserGroupCapacityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    return new GetOneExecutor<UserGroupCapacityDto>(UserGroupCapacityDto.class,
        UserGroupCapacityService.GET_ONE_IDENTIFIER).execute(() -> {
          GetOneRequestDto request = new GetOneRequestDto();
          request.setProjection(projection);
          request.setFilter(filter);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getOne(request);
        });
  }

  /**
   * {@link UserGroupCapacityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public UserGroupCapacityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    return new GetOneExecutor<UserGroupCapacityDto>(UserGroupCapacityDto.class,
        UserGroupCapacityService.GET_BY_IDENTIFIER_IDENTIFIER).execute(() -> {
          GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
          request.setIdentifier(identifier);
          request.setProjection(projection);
          request.setAuditWho(auditWho);
          request.setAuditSession(auditSession);
          return service().getByIdentifier(request);
        });
  }

  /**
   * {@link UserGroupCapacityService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(UserGroupCapacityUpdateRequestDto request) {
    return new IdentifiableExecutor(UserGroupCapacityService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link UserGroupCapacityService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(UserGroupCapacityService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link UserGroupCapacityService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
