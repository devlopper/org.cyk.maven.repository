package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de groupe de fichiers.
 *
 * @author Christian
 */
public interface FilterHasMailIdentifier extends HasMailIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe de fichiers.
   *
   * @param filter {@link FilterDto}
   */
  default void updateMailIdentifier(FilterDto filter) {
    setMailIdentifier(MailIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant du groupe de fichiers de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterMailIdentifier(FilterDto filter) {
    MailIdentifierFilter.set(filter, getMailIdentifier());
  }

}
