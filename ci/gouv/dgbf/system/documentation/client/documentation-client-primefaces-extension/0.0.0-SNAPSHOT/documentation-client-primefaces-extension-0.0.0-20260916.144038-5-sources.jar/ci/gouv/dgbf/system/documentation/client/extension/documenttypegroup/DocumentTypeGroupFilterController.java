package ci.gouv.dgbf.system.documentation.client.extension.documenttypegroup;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.FilterSearchTextController;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupDto;
import ci.gouv.dgbf.system.documentation.server.api.DocumentTypeGroupFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link DocumentTypeGroupDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class DocumentTypeGroupFilterController
    extends AbstractFilterController<DocumentTypeGroupFilter> {

  @Inject
  @Getter
  FilterSearchTextController searchTextController;

  /**
   * Cette méthode permet de construire.
   */
  public DocumentTypeGroupFilterController() {
    super(DocumentTypeGroupFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    searchTextController.initialize(filter);
  }
}
