package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link ModulesGroupDto}.
 *
 * @author Christian
 */
@Path(value = ModulesGroupService.PATH)
@Tag(name = "Gestion des Groupes de Modules")
public interface ModulesGroupService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "groupes-modules";

  /**
   * Cette interface représente une requête de création ou de mise à jour unitaire.
   */
  interface ModulesGroupSaveRequestDto {

    /**
     * Cette méthode permet d'obtenir l'ordre d'affichage de la section du Portail.
     *
     * @return ordre d'affichage de la section du Portail
     */
    Integer getOrder();

    /**
     * Cette méthode permet d'assigner l'ordre d'affichage de la section du Portail.
     *
     * @param order ordre d'affichage de la section du Portail
     */
    void setOrder(Integer order);

    /**
     * {@link ModulesGroupDto#JSON_ORDER}.
     */
    String JSON_ORDER = ModulesGroupDto.JSON_ORDER;
  }

  /**
   * Identifiant du service de création unitaire de {@link ModulesGroupDto}.
   */
  String CREATE_IDENTIFIER = "CREATION_GROUPE_MODULES";

  /**
   * Chemin du service de création unitaire de {@link ModulesGroupDto}.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(ModulesGroupCreateRequestDto request);

  /**
   * Cette classe représente la requête de création unitaire de {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModulesGroupCreateRequestDto extends AbstractCodableNamableCreateRequestJsonDto
      implements ModulesGroupSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;
  }

  /**
   * Identifiant du service d'obtention de plusieurs {@link ModulesGroupDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention de plusieurs {@link ModulesGroupDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente la réponse d'obtention de plusieurs {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  public static class ModulesGroupGetManyResponseDto
      extends AbstractGetByPageResponseDto<ModulesGroupDto> {

    @JsonbProperty(JSON_DATAS)
    private List<ModulesGroupDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link ModulesGroupDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention unitaire de {@link ModulesGroupDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de {@link ModulesGroupDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention par identifiant de {@link ModulesGroupDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identifiant {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = ModulesGroupDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service d'obtention du compte.
   */
  String GET_COUNT_IDENTIFIER = "OBTENTION_COMPTE_GROUPE_MODULES";

  /**
   * Chemin du service d'obtention de compte.
   */
  String GET_COUNT_PATH = "obtention/compte";

  /**
   * Cette méthode permet d'obtenir compte {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_COUNT_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.TEXT_PLAIN})
  @Operation(operationId = GET_COUNT_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = Long.class))})
  Response getCount(GetCountRequestDto request);

  /**
   * Identifiant du service de mise à jour unitaire de {@link ModulesGroupDto}.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_GROUPE_MODULES";

  /**
   * Chemin du service de mise à jour unitaire de {@link ModulesGroupDto}.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(ModulesGroupUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour unitaire de {@link ModulesGroupDto}.
   *
   * @author Christian
   */
  @Getter
  @Setter
  class ModulesGroupUpdateRequestDto extends AbstractCodableNamableUpdateRequestJsonDto
      implements ModulesGroupSaveRequestDto {

    @JsonbProperty(JSON_ORDER)
    private Integer order;
  }

  /**
   * Identifiant du service de suppression unitaire de {@link ModulesGroupDto}.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_GROUPE_MODULES";

  /**
   * Chemin du service de suppression unitaire de {@link ModulesGroupDto}.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer unitairement {@link ModulesGroupDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);

}
