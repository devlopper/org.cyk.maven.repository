package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à saisir pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToInputNAsStringDto extends HasTotalAmountToInputNAsString {

  /**
   * Identifiant json du montant total à saisir pour l'année N, sous forme de chaîne de caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_INPUT_N_AS_STRING = "montantTotalASaisirNChaine";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
