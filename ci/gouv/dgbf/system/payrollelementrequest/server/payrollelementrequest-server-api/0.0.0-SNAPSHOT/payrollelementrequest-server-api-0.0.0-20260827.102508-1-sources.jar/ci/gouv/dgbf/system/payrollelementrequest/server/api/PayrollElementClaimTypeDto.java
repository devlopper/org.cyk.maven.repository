package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasClaimTypeGroupAsStringDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasClaimTypeGroupIdentifierDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasProcessingEntityAsStringDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasProcessingEntityIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de réclamation.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimTypeDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasClaimTypeGroupIdentifierDto, HasClaimTypeGroupAsStringDto,
    HasProcessingEntityIdentifierDto, HasProcessingEntityAsStringDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeGroupDto} (RG_REP_SOU_05).
   */
  @JsonbProperty(JSON_CLAIM_TYPE_GROUP_IDENTIFIER)
  private String claimTypeGroupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimTypeGroupIdentifier}.
   */
  @JsonbProperty(JSON_CLAIM_TYPE_GROUP_AS_STRING)
  private String claimTypeGroupAsString;

  /**
   * Identifiant {@link ProcessingEntityDto} (RG_REP_SOU_06).
   */
  @JsonbProperty(JSON_PROCESSING_ENTITY_IDENTIFIER)
  private String processingEntityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #processingEntityIdentifier}.
   */
  @JsonbProperty(JSON_PROCESSING_ENTITY_AS_STRING)
  private String processingEntityAsString;

  /**
   * Indique si ce Type est transmissible au Trésor (RG_REP_SOU_08).
   */
  @JsonbProperty(JSON_TREASURY_TRANSMITTABLE)
  private Boolean treasuryTransmittable;

  /**
   * Indique si le dépôt par le FAE est autorisé pour ce Type (RG_REP_SOU_09).
   */
  @JsonbProperty(JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED)
  private Boolean functionaryDepositAuthorized;

  /**
   * Identifiant du Groupe de Types de Document attendus, module {@code documentation} -- sans
   * FK (couplage faible, RG_REP_PCE_01).
   */
  @JsonbProperty(JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER)
  private String expectedDocumentTypesGroupIdentifier;

  /**
   * Identifiant json {@link #treasuryTransmittable}.
   */
  public static final String JSON_TREASURY_TRANSMITTABLE = "transmissibleAuTresor";

  /**
   * Identifiant json {@link #functionaryDepositAuthorized}.
   */
  public static final String JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED = "depotFaeAutorise";

  /**
   * Identifiant json {@link #expectedDocumentTypesGroupIdentifier}.
   */
  public static final String JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER =
      "idGroupeTypesDocumentAttendus";

  /**
   * Identifiant json de identifiant de {@link PayrollElementClaimTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idType";

  /**
   * Identifiant json de représentation en chaine de caractères
   * de {@link PayrollElementClaimTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de réclamation";
}
