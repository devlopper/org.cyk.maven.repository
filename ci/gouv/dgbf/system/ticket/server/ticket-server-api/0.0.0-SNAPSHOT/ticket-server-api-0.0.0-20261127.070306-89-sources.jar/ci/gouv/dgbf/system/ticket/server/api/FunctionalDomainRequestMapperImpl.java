package ci.gouv.dgbf.system.ticket.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FunctionalDomainDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-11-27T07:02:22+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.20.1 (Eclipse Adoptium)"
)
@ApplicationScoped
public class FunctionalDomainRequestMapperImpl implements FunctionalDomainRequestMapper {

    @Override
    public FunctionalDomainService.FunctionalDomainCreateRequestDto mapCreate(FunctionalDomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionalDomainService.FunctionalDomainCreateRequestDto functionalDomainCreateRequestDto = new FunctionalDomainService.FunctionalDomainCreateRequestDto();

        functionalDomainCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionalDomainCreateRequestDto.setCode( arg0.getCode() );
        functionalDomainCreateRequestDto.setName( arg0.getName() );

        return functionalDomainCreateRequestDto;
    }

    @Override
    public FunctionalDomainService.FunctionalDomainUpdateRequestDto mapUpdate(FunctionalDomainDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FunctionalDomainService.FunctionalDomainUpdateRequestDto functionalDomainUpdateRequestDto = new FunctionalDomainService.FunctionalDomainUpdateRequestDto();

        functionalDomainUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        functionalDomainUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        functionalDomainUpdateRequestDto.setCode( arg0.getCode() );
        functionalDomainUpdateRequestDto.setName( arg0.getName() );

        return functionalDomainUpdateRequestDto;
    }
}
