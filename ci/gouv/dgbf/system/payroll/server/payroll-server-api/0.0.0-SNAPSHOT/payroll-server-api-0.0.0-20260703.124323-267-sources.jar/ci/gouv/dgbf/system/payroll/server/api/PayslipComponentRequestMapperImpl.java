package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayslipComponentDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-03T12:44:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayslipComponentRequestMapperImpl implements PayslipComponentRequestMapper {

    @Override
    public PayslipComponentService.PayslipComponentCreateRequestDto mapCreate(PayslipComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipComponentService.PayslipComponentCreateRequestDto payslipComponentCreateRequestDto = new PayslipComponentService.PayslipComponentCreateRequestDto();

        payslipComponentCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipComponentCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipComponentCreateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipComponentCreateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payslipComponentCreateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipComponentCreateRequestDto;
    }

    @Override
    public PayslipComponentService.PayslipComponentUpdateRequestDto mapUpdate(PayslipComponentDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayslipComponentService.PayslipComponentUpdateRequestDto payslipComponentUpdateRequestDto = new PayslipComponentService.PayslipComponentUpdateRequestDto();

        payslipComponentUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payslipComponentUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payslipComponentUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payslipComponentUpdateRequestDto.setPayslipIdentifier( arg0.getPayslipIdentifier() );
        payslipComponentUpdateRequestDto.setPayrollComponentIdentifier( arg0.getPayrollComponentIdentifier() );
        payslipComponentUpdateRequestDto.setOrderNumber( arg0.getOrderNumber() );

        return payslipComponentUpdateRequestDto;
    }
}
