package ci.gouv.dgbf.system.file.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.Arrays;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link FileDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-25T19:44:55+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class FileRequestMapperImpl implements FileRequestMapper {

    @Override
    public FileService.FileCreateRequestDto mapCreate(FileDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileService.FileCreateRequestDto fileCreateRequestDto = new FileService.FileCreateRequestDto();

        fileCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileCreateRequestDto.setOwnerIdentifier( arg0.getOwnerIdentifier() );
        fileCreateRequestDto.setName( arg0.getName() );
        fileCreateRequestDto.setContentType( arg0.getContentType() );
        byte[] bytes = arg0.getBytes();
        if ( bytes != null ) {
            fileCreateRequestDto.setBytes( Arrays.copyOf( bytes, bytes.length ) );
        }

        return fileCreateRequestDto;
    }

    @Override
    public FileService.FileUpdateRequestDto mapUpdate(FileDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        FileService.FileUpdateRequestDto fileUpdateRequestDto = new FileService.FileUpdateRequestDto();

        fileUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        fileUpdateRequestDto.setIdentifier( arg0.getIdentifier() );

        return fileUpdateRequestDto;
    }
}
