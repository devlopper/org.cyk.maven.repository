package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollTypeService.PayrollTypeUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollTypeDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollTypeDto}.

    @author akm
               """)
public interface PayrollTypeRequestMapper extends RequestMapper<PayrollTypeDto,
    PayrollTypeCreateRequestDto, PayrollTypeUpdateRequestDto> {

}
