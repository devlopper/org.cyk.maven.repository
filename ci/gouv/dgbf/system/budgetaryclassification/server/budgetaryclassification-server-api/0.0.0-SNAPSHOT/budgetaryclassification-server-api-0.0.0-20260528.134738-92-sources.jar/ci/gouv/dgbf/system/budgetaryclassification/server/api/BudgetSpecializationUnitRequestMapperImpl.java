package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link BudgetSpecializationUnitDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-28T13:48:01+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class BudgetSpecializationUnitRequestMapperImpl implements BudgetSpecializationUnitRequestMapper {

    @Override
    public BudgetSpecializationUnitService.BudgetSpecializationUnitCreateRequestDto mapCreate(BudgetSpecializationUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetSpecializationUnitService.BudgetSpecializationUnitCreateRequestDto budgetSpecializationUnitCreateRequestDto = new BudgetSpecializationUnitService.BudgetSpecializationUnitCreateRequestDto();

        budgetSpecializationUnitCreateRequestDto.setCode( arg0.getCode() );
        budgetSpecializationUnitCreateRequestDto.setName( arg0.getName() );
        budgetSpecializationUnitCreateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );
        budgetSpecializationUnitCreateRequestDto.setBudgetCategoryIdentifier( arg0.getBudgetCategoryIdentifier() );
        budgetSpecializationUnitCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return budgetSpecializationUnitCreateRequestDto;
    }

    @Override
    public BudgetSpecializationUnitService.BudgetSpecializationUnitUpdateRequestDto mapUpdate(BudgetSpecializationUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        BudgetSpecializationUnitService.BudgetSpecializationUnitUpdateRequestDto budgetSpecializationUnitUpdateRequestDto = new BudgetSpecializationUnitService.BudgetSpecializationUnitUpdateRequestDto();

        budgetSpecializationUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        budgetSpecializationUnitUpdateRequestDto.setCode( arg0.getCode() );
        budgetSpecializationUnitUpdateRequestDto.setName( arg0.getName() );
        budgetSpecializationUnitUpdateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );
        budgetSpecializationUnitUpdateRequestDto.setBudgetCategoryIdentifier( arg0.getBudgetCategoryIdentifier() );
        budgetSpecializationUnitUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return budgetSpecializationUnitUpdateRequestDto;
    }
}
