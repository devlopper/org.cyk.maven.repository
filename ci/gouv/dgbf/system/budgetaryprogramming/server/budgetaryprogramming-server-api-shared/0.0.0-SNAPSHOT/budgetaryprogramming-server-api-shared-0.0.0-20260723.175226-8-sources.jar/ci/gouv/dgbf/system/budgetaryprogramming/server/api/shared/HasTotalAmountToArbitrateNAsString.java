package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N, sous
 * forme de chaîne de caractères.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasTotalAmountToArbitrateNAsString {

  /**
   * Obtient le montant total à arbitrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @return le montant total à arbitrer pour l'année N sous forme de chaîne de caractères,
   *         {@code null} si aucun plafond n'est défini
   */
  String getTotalAmountToArbitrateNAsString();

  /**
   * Définit le montant total à arbitrer pour l'année N, sous forme de chaîne de caractères.
   *
   * @param totalAmountToArbitrateNAsString le montant total à arbitrer pour l'année N sous forme de
   *        chaîne de caractères
   */
  void setTotalAmountToArbitrateNAsString(String totalAmountToArbitrateNAsString);

  /**
   * Identifiant java du montant total à arbitrer pour l'année N, sous forme de chaîne de
   * caractères.
   */
  String FIELD_TOTAL_AMOUNT_TO_ARBITRATE_N_AS_STRING = "totalAmountToArbitrateNAsString";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName
