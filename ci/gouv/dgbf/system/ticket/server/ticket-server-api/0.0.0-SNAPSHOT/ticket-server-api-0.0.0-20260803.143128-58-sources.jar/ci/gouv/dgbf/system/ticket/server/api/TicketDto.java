package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasCategoryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasChildCreatableDto;
import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLevelIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasParentAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasParentIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPriorityIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasServiceRatingDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusCommentDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.file.server.api.shared.HasFilesGroupIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasClaimableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasDiagnosticDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasDissatisfiableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasEscalatableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasRedirectableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasReporterIdentityIdentifierDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasResolvableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSatisfiableDto;
import ci.gouv.dgbf.system.ticket.server.api.shared.HasSolutionDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUsersGroupAsStringDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un ticket .
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TicketDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasReporterIdentityIdentifierDto,
    HasLevelIdentifierDto, HasLevelAsStringDto, HasDescriptionDto, HasFilesGroupIdentifierDto,
    HasStatusDto<TicketStatus>, HasStatusAsStringDto, HasStatusCommentDto, HasClaimableDto,
    HasResolvableDto, HasSatisfiableDto, HasDissatisfiableDto, HasRedirectableDto,
    HasEscalatableDto, HasCategoryIdentifierDto, HasCategoryAsStringDto, HasPriorityIdentifierDto,
    HasPriorityAsStringDto, HasDiagnosticDto, HasSolutionDto, HasUserIdentifierDto,
    HasUserAsStringDto, HasUsersGroupAsStringDto, HasParentIdentifierDto, HasParentAsStringDto,
    HasServiceRatingDto, HasChildCreatableDto {

  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  @JsonbProperty(JSON_FILES_GROUP_IDENTIFIER)
  private String filesGroupIdentifier;

  // Domain

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;

  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;

  // Status

  @JsonbProperty(JSON_STATUS)
  private TicketStatus status;

  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(JSON_STATUS_COMMENT)
  private String statusComment;

  @JsonbProperty(JSON_CLAIMABLE)
  private Boolean claimable;

  @JsonbProperty(JSON_RESOLVABLE)
  private Boolean resolvable;

  @JsonbProperty(JSON_SATISFIABLE)
  private Boolean satisfiable;

  @JsonbProperty(JSON_DISSATISFIABLE)
  private Boolean dissatisfiable;

  @JsonbProperty(JSON_REDIRECTABLE)
  private Boolean redirectable;

  @JsonbProperty(JSON_ESCALATABLE)
  private Boolean escalatable;

  @JsonbProperty(JSON_CHILD_CREATABLE)
  private Boolean childCreatable;

  @JsonbProperty(JSON_USER_ASSIGNABLE)
  private Boolean userAssignable;

  // Level

  @JsonbProperty(JSON_LEVEL_IDENTIFIER)
  private String levelIdentifier;

  @JsonbProperty(JSON_LEVEL_AS_STRING)
  private String levelAsString;

  // Category

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  // Priority

  @JsonbProperty(JSON_PRIORITY_IDENTIFIER)
  private String priorityIdentifier;

  @JsonbProperty(JSON_PRIORITY_AS_STRING)
  private String priorityAsString;

  // Claim result

  @JsonbProperty(JSON_DIAGNOSTIC)
  private String diagnostic;

  @JsonbProperty(JSON_SOLUTION)
  private String solution;

  // User

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;

  @JsonbProperty(JSON_USERS_GROUP_AS_STRING)
  private String usersGroupAsString;

  @JsonbProperty(JSON_REPORTER_IDENTITY_IDENTIFIER)
  private String reporterIdentityIdentifier;

  // note de prestation

  @JsonbProperty(JSON_SERVICE_RATING)
  private Integer serviceRating;



  // parent

  @JsonbProperty(JSON_PARENT_IDENTIFIER)
  private String parentIdentifier;

  @JsonbProperty(JSON_PARENT_AS_STRING)
  private String parentAsString;

  /**
   * Identifiant json de l'aptitude à être assigné à un utilisateur.
   */
  public static final String JSON_USER_ASSIGNABLE = "utilisateurPeutEtreAssigne";

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTicket";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "ticketChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "ticket";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
