package ci.gouv.dgbf.extension.primefaces.component.input;

import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une sélection d'une valeur chaine de caractères.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public abstract class AbstractSelectOneString extends AbstractSelectOne<String> {

  /**
   * Cette méthode permet d'instancier un objet.
   */
  protected AbstractSelectOneString() {
    nullChoiceLabel = "Néant";
  }
}
