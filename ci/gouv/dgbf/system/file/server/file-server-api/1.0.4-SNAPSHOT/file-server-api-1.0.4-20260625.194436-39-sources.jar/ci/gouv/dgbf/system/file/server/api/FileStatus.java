package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link FileDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum FileStatus {

  /**
   * {@link FileStatusCode#CREATED}.
   */
  CREATED(FileStatusCode.CREATED, "Créé", "Création", "Créer", "Nouveau"),

  /**
   * {@link FileStatusCode#CONFIRMED}.
   */
  CONFIRMED(FileStatusCode.CONFIRMED, "Confirmé", "Confirmation", "Confirmer");

  private FileStatus(String code, String name, String actionName, String actionVerb,
      String actionLabel) {
    this.code = code;
    this.name = name;
    this.actionName = actionName;
    this.actionVerb = actionVerb;
    this.actionLabel = actionLabel;
  }

  private FileStatus(String code, String name, String actionName, String actionVerb) {
    this(code, name, actionName, actionVerb, actionVerb);
  }

  private String code;
  private String name;
  private String actionName;
  private String actionVerb;
  private String actionLabel;
  private Set<FileStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link FileStatus} par code.
   *
   * @param code code
   * @return {@link FileStatus}
   */
  public static FileStatus getByCode(String code) {
    return Stream.of(FileStatus.values()).filter(status -> status.getCode().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    CONFIRMED.previous = Core.getSet(List.of(CREATED));
  }
}
