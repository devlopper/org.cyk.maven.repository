package ci.gouv.dgbf.system.file.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de fichier.
 *
 * @author Christian
 */
public interface HasFileIdentifierDto extends HasFileIdentifier {

  /**
   * Identifiant json de l'identifiant du fichier.
   */
  String JSON_FILE_IDENTIFIER = "idFichier";
}