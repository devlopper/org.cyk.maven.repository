package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Contrat de consultation de l'historique des états d'un dossier.
 *
 * <p>Le service est délibérément en lecture seule. Une transition ne se crée pas depuis
 * l'extérieur : elle est le sous-produit d'une opération métier, écrite dans la transaction même
 * qui change l'état. Exposer une création laisserait croire qu'on peut écrire l'histoire après
 * coup.</p>
 *
 * @author Christian
 *
 */
@Path(value = BudgetAdministrativeUnitHistoryService.PATH)
@Tag(name = "Gestion des transitions d'état de dossier")
public interface BudgetAdministrativeUnitHistoryService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "transitions-etat-dossier";

  /**
   * Identifiant du service d'obtention de plusieurs {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_TRANSITION_ETAT_DOSSIER";

  /**
   * Chemin du service d'obtention de plusieurs {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Recherche multicritère des transitions d'état.
   *
   * @param request critères, projection et pagination
   * @return les transitions correspondantes
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER,
      summary = "Consultation de l'historique des états d'un dossier")
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitHistoryGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Réponse paginée d'une recherche de transitions.
   */
  @Getter
  @Setter
  public static class BudgetAdministrativeUnitHistoryGetManyResponseDto
      extends AbstractGetByPageResponseDto<BudgetAdministrativeUnitHistoryDto> {
    @JsonbProperty(JSON_DATAS)
    private List<BudgetAdministrativeUnitHistoryDto> datas;
  }

  /**
   * Identifiant du service d'obtention unitaire de {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_TRANSITION_ETAT_DOSSIER";

  /**
   * Chemin du service d'obtention unitaire de {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Recherche d'une transition unique.
   *
   * @param request critères et projection
   * @return la transition correspondante
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitHistoryDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de
   * {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER =
      "OBTENTION_PAR_IDENTIFIANT_TRANSITION_ETAT_DOSSIER";

  /**
   * Chemin du service d'obtention par identifiant de {@link BudgetAdministrativeUnitHistoryDto}.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Lecture d'une transition par son identifiant.
   *
   * @param request identifiant et projection
   * @return la transition correspondante
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(
          implementation = BudgetAdministrativeUnitHistoryDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);
}
