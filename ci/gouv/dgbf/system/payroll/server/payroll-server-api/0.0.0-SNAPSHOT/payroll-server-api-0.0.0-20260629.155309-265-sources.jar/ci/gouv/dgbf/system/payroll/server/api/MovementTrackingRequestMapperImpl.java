package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link MovementTrackingDto}.
*
* @author A.K.M
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class MovementTrackingRequestMapperImpl implements MovementTrackingRequestMapper {

    @Override
    public MovementTrackingService.MovementTrackingCreateRequestDto mapCreate(MovementTrackingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementTrackingService.MovementTrackingCreateRequestDto movementTrackingCreateRequestDto = new MovementTrackingService.MovementTrackingCreateRequestDto();

        movementTrackingCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementTrackingCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementTrackingCreateRequestDto.setEffectDate( arg0.getEffectDate() );
        movementTrackingCreateRequestDto.setDateTakeInCounts( arg0.getDateTakeInCounts() );
        movementTrackingCreateRequestDto.setDateReminder( arg0.getDateReminder() );
        movementTrackingCreateRequestDto.setStatus( arg0.getStatus() );

        return movementTrackingCreateRequestDto;
    }

    @Override
    public MovementTrackingService.MovementTrackingUpdateRequestDto mapUpdate(MovementTrackingDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        MovementTrackingService.MovementTrackingUpdateRequestDto movementTrackingUpdateRequestDto = new MovementTrackingService.MovementTrackingUpdateRequestDto();

        movementTrackingUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        movementTrackingUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        movementTrackingUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        movementTrackingUpdateRequestDto.setEffectDate( arg0.getEffectDate() );
        movementTrackingUpdateRequestDto.setDateTakeInCounts( arg0.getDateTakeInCounts() );
        movementTrackingUpdateRequestDto.setDateReminder( arg0.getDateReminder() );
        movementTrackingUpdateRequestDto.setStatus( arg0.getStatus() );

        return movementTrackingUpdateRequestDto;
    }
}
