package ci.gouv.dgbf.system.budgetaryprogramming.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasLockAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasLockIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasActivityIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureAsStringDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasEconomicNatureIdentifierDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.HasExerciseAsYearDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasImputationIdentifierDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingAsStringDto;
import ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared.HasProgrammingIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base de conteneur de montants d'imputation.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractImputationAmountsContainerDto extends AbstractAmountsContainerDto
    implements HasProgrammingIdentifierDto, HasProgrammingAsStringDto, HasExerciseAsYearDto,
    HasImputationIdentifierDto, HasImputationAsStringDto, HasActivityIdentifierDto,
    HasActivityAsStringDto, HasEconomicNatureIdentifierDto, HasEconomicNatureAsStringDto,
    HasLockIdentifierDto, HasLockAsStringDto {

  // Programming

  @JsonbProperty(JSON_PROGRAMMING_IDENTIFIER)
  protected String programmingIdentifier;

  @JsonbProperty(JSON_PROGRAMMING_AS_STRING)
  protected String programmingAsString;

  // Exercise

  @JsonbProperty(JSON_EXERCISE_YEAR)
  protected Integer exerciseYear;

  // Imputation

  @JsonbProperty(JSON_IMPUTATION_IDENTIFIER)
  private String imputationIdentifier;

  @JsonbProperty(JSON_IMPUTATION_AS_STRING)
  private String imputationAsString;

  // Activity

  @JsonbProperty(JSON_ACTIVITY_IDENTIFIER)
  protected String activityIdentifier;

  @JsonbProperty(JSON_ACTIVITY_AS_STRING)
  protected String activityAsString;

  // Economic nature

  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  protected String economicNatureIdentifier;

  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  protected String economicNatureAsString;

  // Lock

  @JsonbProperty(JSON_LOCK_IDENTIFIER)
  protected String lockIdentifier;

  @JsonbProperty(JSON_LOCK_AS_STRING)
  protected String lockAsString;
}
