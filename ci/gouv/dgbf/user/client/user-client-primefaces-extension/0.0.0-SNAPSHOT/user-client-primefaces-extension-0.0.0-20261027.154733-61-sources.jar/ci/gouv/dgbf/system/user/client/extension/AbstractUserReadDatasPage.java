package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractPage;
import ci.gouv.dgbf.extension.primefaces.component.information.LabelValueGroupsInformationCard;
import ci.gouv.dgbf.extension.primefaces.component.layout.ListDetailLayoutController;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiablePage;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiablePageMode;
import ci.gouv.dgbf.extension.primefaces.page.IdentifiableResolution;
import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.OneRetrievable;
import ci.gouv.dgbf.system.user.server.api.UserClient;
import ci.gouv.dgbf.system.user.server.api.UserDto;
import ci.gouv.dgbf.system.user.server.api.UserFilter;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente la base des pages de consultation de {@link UserDto}.
 *
 * @author BoobaCool
 */
public abstract class AbstractUserReadDatasPage extends AbstractPage
    implements IdentifiablePage<UserDto, UserFilter> {

  @Inject
  protected UserClient client;

  @Getter
  protected UserDto user;

  protected IdentifiableResolution identifiableResolution = new IdentifiableResolution()
      .addNavigation("Retour à la liste", getListPageOutcome());
  private boolean identifiablePageInitialized;

  @Override
  public IdentifiableResolution getIdentifiableResolution() {
    if (!identifiablePageInitialized) {
      identifiablePageInitialized = true;
      initialize();
    }
    return identifiableResolution;
  }

  @Getter
  protected LabelValueGroupsInformationCard labelValueGroupsInformationCard;

  @Inject
  protected IconManager iconManager;

  @Inject
  @Getter
  protected UserTabMenuController tabMenuController;

  /**
   * Panneau des autres Utilisateurs, à droite de la fiche (maître-détail, RU_UTI_027) : simple
   * objet de présentation, sans dépendance à injecter.
   */
  @Getter
  protected ListDetailLayoutController listDetailLayoutController =
      new ListDetailLayoutController();

  @Override
  protected void postConstruct() {
    super.postConstruct();
    contentTitle = "Consultation " + UserDto.NAME;
  }

  /** Initialise la lecture pendant la phase metadata JSF, après la création de la vue. */
  public void initialize() {
    instantiateAndGetFilter();
  }

  @Override
  public IdentifiablePageMode getIdentifiablePageMode() {
    return IdentifiablePageMode.DISPLAY_STATE;
  }

  @Override
  public boolean isIdentifierFallbackEnabled() {
    return false;
  }

  @Override
  public void processFilterWhenIdentifierBlank(UserFilter filter) {
    clearIdentifiablePageContent();
  }

  @Override
  public OneRetrievable<UserDto> getIdentifiableRetriever() {
    return (projection, filter, actor, session) -> client.getByIdentifier(
        AbstractIdentifiableFilter.getIdentifier(filter), projection, actor, session);
  }

  @Override
  public void clearIdentifiablePageContent() {
    user = null;
    labelValueGroupsInformationCard = null;
  }

  @Override
  public Class<UserFilter> getIdentifiableFilterClass() {
    return UserFilter.class;
  }

  @Override
  public Class<UserDto> getIdentifiableDtoClass() {
    return UserDto.class;
  }

  @Override
  public String getConnectedUserSharedSelectionPageOutcome() {
    return getListPageOutcome();
  }

  protected abstract String getListPageOutcome();

  @Override
  public ProjectionDto getIdentifiableProjection() {
    return instantiateProjection();
  }

  @Override
  public void initializeWhenIdentifiableNull() {
    user = null;
  }

  @Override
  public void initializeWhenIdentifiableNotNull(UserDto instance) {
    user = instance;

    buildLabelValueGroupsInformationCard();

    tabMenuController.setInstance(user);
    tabMenuController.initialize();

    listDetailLayoutController.setLinkValueName("nom");
    listDetailLayoutController.instantiateDetailsAsLazyDataModel(UserDto.class, client,
        userIdentifier);
    listDetailLayoutController.initialize();
  }

  protected void buildLabelValueGroupsInformationCard() {
    UserLabelValueGroupsInformationCardBuilder builder =
        new UserLabelValueGroupsInformationCardBuilder(iconManager);
    builder.name(user.getName()).identity(user.getIdentityAsString())
        .domain(user.getDomainAsString()).roleCount(user.getRoleCountAsString())
        .pendingRoleSolicitationCount(user.getPendingRoleSolicitationCountAsString());
    labelValueGroupsInformationCard = builder.build();
  }

  protected ProjectionDto instantiateProjection() {
    return new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
        AbstractIdentifiableNamableDto.JSON_NAME, UserDto.JSON_IDENTITY_AS_STRING,
        UserDto.JSON_DOMAIN_AS_STRING,
        // Nombres de la fiche (RU_UTI_027)
        UserDto.JSON_ROLE_COUNT_AS_STRING, UserDto.JSON_PENDING_ROLE_SOLICITATION_COUNT_AS_STRING);
  }
}
