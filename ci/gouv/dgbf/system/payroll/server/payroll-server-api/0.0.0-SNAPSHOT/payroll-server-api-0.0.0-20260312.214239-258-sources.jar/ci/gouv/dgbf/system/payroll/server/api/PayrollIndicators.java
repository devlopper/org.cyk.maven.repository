package ci.gouv.dgbf.system.payroll.server.api;

/**
 * Cette interface représente des indicateurs de {@link PayrollDto}.
 *
 * @author Christian
 */
public interface PayrollIndicators {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} actifs.
   *
   * @return la représentation en chaine de caractères du nombre de {@link RemunerableDto} actifs
   */
  String getEnabledRemunerableCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} actifs.
   *
   * @param enabledRemunerableCountAsString la représentation en chaine de caractères du nombre de
   *        {@link RemunerableDto} actifs
   */
  void setEnabledRemunerableCountAsString(String enabledRemunerableCountAsString);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} non actifs.
   *
   * @return la représentation en chaine de caractères du nombre de {@link RemunerableDto} non
   *         actifs
   */
  String getDisabledRemunerableCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} non actifs.
   *
   * @param disabledRemunerableCountAsString la représentation en chaine de caractères du nombre de
   *        {@link RemunerableDto} non actifs
   */
  void setDisabledRemunerableCountAsString(String disabledRemunerableCountAsString);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} créés.
   *
   * @return la représentation en chaine de caractères du nombre de {@link PayslipDto} créés
   */
  String getCreatedPayslipCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} créés.
   *
   * @param createdPayslipCountAsString la représentation en chaine de caractères du nombre de
   *        {@link PayslipDto} créés
   */
  void setCreatedPayslipCountAsString(String createdPayslipCountAsString);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à créer.
   *
   * @return la représentation en chaine de caractères du nombre de {@link PayslipDto} à créer
   */
  String getCreatablePayslipCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} à créer.
   *
   * @param creatablePayslipCountAsString la représentation en chaine de caractères du nombre de
   *        {@link PayslipDto} à créer
   */
  void setCreatablePayslipCountAsString(String creatablePayslipCountAsString);

  /**
   * Cette méthode permet d'obtenir le nombre de {@link PayslipDto} calculable.
   *
   * @return nombre de {@link PayslipDto} calculable
   */
  Integer getCalculablePayslipCount();

  /**
   * Cette méthode permet d'assigner le nombre de {@link PayslipDto} calculable.
   *
   * @param calculablePayslipCount nombre de {@link PayslipDto} calculable
   */
  void setCalculablePayslipCount(Integer calculablePayslipCount);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculable.
   *
   * @return la représentation en chaine de caractères du nombre de {@link PayslipDto} calculable
   */
  String getCalculablePayslipCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculable.
   *
   * @param calculablePayslipCountAsString la représentation en chaine de caractères du nombre de
   *        {@link PayslipDto} calculable
   */
  void setCalculablePayslipCountAsString(String calculablePayslipCountAsString);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} non calculable.
   *
   * @return la représentation en chaine de caractères du nombre de {@link PayslipDto} non
   *         calculable
   */
  String getNonCalculablePayslipCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} non calculable.
   *
   * @param nonCalculablePayslipCountAsString la représentation en chaine de caractères du nombre de
   *        {@link PayslipDto} non calculable
   */
  void setNonCalculablePayslipCountAsString(String nonCalculablePayslipCountAsString);

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculé.
   *
   * @return la représentation en chaine de caractères du nombre de {@link PayslipDto} calculé
   */
  String getCalculatedPayslipCountAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères du nombre de
   * {@link PayslipDto} calculé.
   *
   * @param calculatedPayslipCountAsString la représentation en chaine de caractères du nombre de
   *        {@link PayslipDto} calculé
   */
  void setCalculatedPayslipCountAsString(String calculatedPayslipCountAsString);

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} actifs.
   */
  String FIELD_ENABLED_REMUNERABLE_COUNT_AS_STRING = "enabledRemunerableCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de
   * {@link RemunerableDto} non actifs.
   */
  String FIELD_DISABLED_REMUNERABLE_COUNT_AS_STRING = "disabledRemunerableCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link PayslipDto}
   * créés.
   */
  String FIELD_CREATED_PAYSLIP_COUNT_AS_STRING = "createdPayslipCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link PayslipDto} à
   * créer.
   */
  String FIELD_CREATABLE_PAYSLIP_COUNT_AS_STRING = "creatablePayslipCountAsString";

  /**
   * Identifiant java du nombre de {@link PayslipDto} calculable.
   */
  String FIELD_CALCULABLE_PAYSLIP_COUNT = "calculablePayslipCount";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link PayslipDto}
   * calculable.
   */
  String FIELD_CALCULABLE_PAYSLIP_COUNT_AS_STRING = "calculablePayslipCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link PayslipDto}
   * non calculable.
   */
  String FIELD_NON_CALCULABLE_PAYSLIP_COUNT_AS_STRING = "nonCalculablePayslipCountAsString";

  /**
   * Identifiant java de la représentation en chaine de caractères du nombre de {@link PayslipDto}
   * calculé.
   */
  String FIELD_CALCULATED_PAYSLIP_COUNT_AS_STRING = "calculatedPayslipCountAsString";
}
