package ci.gouv.dgbf.system.sharing.server.api;

import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les types de {@link ReceiverDto}.
 *
 * @author Christian
 *
 */
@Getter
public enum ReceiverType {

  /**
   * {@link ReceiverTypeCode#USER}.
   */
  USER(ReceiverTypeCode.USER, "Utilisateur"),
  /**
   * {@link ReceiverTypeCode#USER_GROUP}.
   */
  USER_GROUP(ReceiverTypeCode.USER_GROUP, "Groupe d'utilisateur")

  ;

  private ReceiverType(String code, String name) {
    this.code = code;
    this.name = name;
  }

  private String code;
  private String name;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir {@link ReceiverType} par code.
   *
   * @param code code
   * @return {@link ReceiverType}
   */
  public static ReceiverType getByCode(String code) {
    return Stream.of(ReceiverType.values()).filter(status -> status.getCode().equals(code))
        .findFirst().orElseThrow(IllegalArgumentException::new);
  }
}
