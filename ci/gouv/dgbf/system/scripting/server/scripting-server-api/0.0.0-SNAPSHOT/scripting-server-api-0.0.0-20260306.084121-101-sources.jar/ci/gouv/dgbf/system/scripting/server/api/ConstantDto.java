package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.enumeration.ValueType;
import ci.gouv.dgbf.extension.core.segregation.HasDomainAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasDomainIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasValueTypeDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une constante.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ConstantDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDomainIdentifierDto, HasDomainAsStringDto, HasStringValueDto, HasValueTypeDto,
    HasValueTypeAsStringDto {

  @JsonbProperty(JSON_DOMAIN_IDENTIFIER)
  private String domainIdentifier;
  
  @JsonbProperty(JSON_DOMAIN_AS_STRING)
  private String domainAsString;
  
  @JsonbProperty(JSON_VALUE)
  private String value;

  @JsonbProperty(JSON_VALUE_TYPE)
  private ValueType valueType;

  @JsonbProperty(JSON_VALUE_TYPE_AS_STRING)
  private String valueTypeAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idConstante";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "constanteChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "constante";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
