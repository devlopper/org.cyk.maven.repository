package ci.gouv.dgbf.system.servicecatalog.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasDescriptionDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasModuleIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasVisibleDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un module du système d'information DGBF, unité de
 * conception/architecture pouvant exposer plusieurs Processus.
 *
 * @author Christian
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ModuleDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasDescriptionDto, HasVisibleDto, HasProcessCountDto, HasProcessCountAsStringDto,
    HasOperationCountDto, HasOperationCountAsStringDto {

  /**
   * Description du module.
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Classification stratégique (Core Domain / Supporting Subdomain / Generic Subdomain), valeur du
   * référentiel {@code TR_CLASSIFICATION_STRATEGIQUE}.
   */
  @JsonbProperty(JSON_STRATEGIC_CLASSIFICATION)
  private StrategicClassification strategicClassification;

  /**
   * Identifiant du groupe de modules auquel appartient le module (RG_SVC_CAT_07),
   * AUTRES_SERVICES par défaut.
   */
  @JsonbProperty(JSON_GROUP)
  private String group;

  /**
   * Libellé du groupe de modules, calculé en lecture.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Indique si le module est présenté à tous les utilisateurs authentifiés dans le catalogue.
   * Faux par défaut.
   */
  @JsonbProperty(JSON_VISIBLE)
  private Boolean visible;

  /**
   * Pictogramme facultatif du module au Portail (RG_SVC_CAT_09) : nom d'icône PrimeIcons
   * ({@code pi-...}), pictogramme générique à défaut.
   */
  @JsonbProperty(JSON_ICON)
  private String icon;

  /**
   * Nombre de processus exposés par le module (calculé en lecture via {@code VA_MODULE_AGREGAT}).
   */
  @JsonbProperty(JSON_PROCESS_COUNT)
  private Integer processCount;

  /**
   * Nombre de processus exposés par le module sous forme de chaîne (calculé en lecture).
   */
  @JsonbProperty(JSON_PROCESS_COUNT_AS_STRING)
  private String processCountAsString;

  /**
   * Nombre d'opérations exposées par les processus du module (calculé en lecture via
   * {@code VA_MODULE_AGREGAT}).
   */
  @JsonbProperty(JSON_OPERATION_COUNT)
  private Integer operationCount;

  /**
   * Nombre d'opérations exposées par les processus du module sous forme de chaîne (calculé en
   * lecture).
   */
  @JsonbProperty(JSON_OPERATION_COUNT_AS_STRING)
  private String operationCountAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = HasModuleIdentifierDto.JSON_MODULE_IDENTIFIER;

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = HasModuleAsStringDto.JSON_MODULE_AS_STRING;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "module";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modules";

  /**
   * Identifiant json pour {@link #strategicClassification}.
   */
  public static final String JSON_STRATEGIC_CLASSIFICATION = "classificationStrategique";

  /**
   * Identifiant json pour {@link #group}.
   */
  public static final String JSON_GROUP = "groupe";

  /**
   * Identifiant json pour {@link #groupAsString}.
   */
  public static final String JSON_GROUP_AS_STRING = "groupeChaine";

  /**
   * Identifiant json pour {@link #icon}.
   */
  public static final String JSON_ICON = "icone";
}
