package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente la base d'un poste de dépense ou d'un poste de ressource.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public abstract class AbstractExpenditureOrResourceItemDto
    extends AbstractIdentifiableAuditableDto {

  /*
   * Identifiant {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_IDENTIFIER)
  private String exerciseIdentifier;

  /*
   * Code {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_CODE)
  private String exerciseCode;

  /*
   * Réprésentation en chaine de caractère {@link ExerciseDto}.
   */
  @JsonbProperty(JSON_EXERCISE_AS_STRING)
  private String exerciseAsString;

  /*
   * Identifiant {@link EconomicNatureDto}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /*
   * Code {@link EconomicNatureDto}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_CODE)
  private String economicNatureCode;

  /*
   * Réprésentation en chaine de caractère {@link EconomicNatureDto}.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_AS_STRING)
  private String economicNatureAsString;

  /*
   * Montants
   */

  /**
   * Représentation en chaine de caractères du budget initial plannifié.
   */
  @JsonbProperty(JSON_INITIAL_PLANNED_BUDGET_AS_STRING)
  private String initialPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget initial réalisé.
   */
  @JsonbProperty(JSON_INITIAL_REALIZED_BUDGET_AS_STRING)
  private String initialRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget actuel plannifié.
   */
  @JsonbProperty(JSON_ACTUAL_PLANNED_BUDGET_AS_STRING)
  private String actualPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget actuel réalisé.
   */
  @JsonbProperty(JSON_ACTUAL_REALIZED_BUDGET_AS_STRING)
  private String actualRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget préréservé plannifié en exécution.
   */
  @JsonbProperty(JSON_EXECUTION_PRERESERVED_PLANNED_BUDGET_AS_STRING)
  private String executionPrereservedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget préréservé réalisé en exécution.
   */
  @JsonbProperty(JSON_EXECUTION_PRERESERVED_REALIZED_BUDGET_AS_STRING)
  private String executionPrereservedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget préréservé plannifié.
   */
  @JsonbProperty(JSON_PRERESERVED_PLANNED_BUDGET_AS_STRING)
  private String prereservedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget préréservé réalisé.
   */
  @JsonbProperty(JSON_PRERESERVED_REALIZED_BUDGET_AS_STRING)
  private String prereservedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé plannifié en élaboration.
   */
  @JsonbProperty(JSON_ELABORATION_RESERVED_PLANNED_BUDGET_AS_STRING)
  private String elaborationReservedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé réalisé en élaboration.
   */
  @JsonbProperty(JSON_ELABORATION_RESERVED_REALIZED_BUDGET_AS_STRING)
  private String elaborationReservedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé plannifié en exécution.
   */
  @JsonbProperty(JSON_EXECUTION_RESERVED_PLANNED_BUDGET_AS_STRING)
  private String executionReservedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé réalisé en exécution.
   */
  @JsonbProperty(JSON_EXECUTION_RESERVED_REALIZED_BUDGET_AS_STRING)
  private String executionReservedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé plannifié.
   */
  @JsonbProperty(JSON_RESERVED_PLANNED_BUDGET_AS_STRING)
  private String reservedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget réservé réalisé.
   */
  @JsonbProperty(JSON_RESERVED_REALIZED_BUDGET_AS_STRING)
  private String reservedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget exécuté plannifié.
   */
  @JsonbProperty(JSON_EXECUTED_PLANNED_BUDGET_AS_STRING)
  private String executedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du budget exécuté réalisé.
   */
  @JsonbProperty(JSON_EXECUTED_REALIZED_BUDGET_AS_STRING)
  private String executedRealizedBudgetAsString;

  /**
   * Représentation en chaine de caractères du reste du budget plannifié.
   */
  @JsonbProperty(JSON_REMAINING_EXECUTED_PLANNED_BUDGET)
  private Long remainingExecutedPlannedBudget;

  /**
   * Représentation en chaine de caractères du reste du budget plannifié.
   */
  @JsonbProperty(JSON_REMAINING_EXECUTED_PLANNED_BUDGET_AS_STRING)
  private String remainingExecutedPlannedBudgetAsString;

  /**
   * Représentation en chaine de caractères du reste du budget réalisé.
   */
  @JsonbProperty(JSON_REMAINING_EXECUTED_REALIZED_BUDGET_AS_STRING)
  private String remainingExecutedRealizedBudgetAsString;

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#exerciseIdentifier}.
   */
  public static final String JSON_EXERCISE_IDENTIFIER = "idExercice";

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#exerciseCode}.
   */
  public static final String JSON_EXERCISE_CODE = "codeExercice";

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#exerciseAsString}.
   */
  public static final String JSON_EXERCISE_AS_STRING = "exerciceChaine";

  /**
   * Identifiant json champ identifiant activité.
   */
  public static final String JSON_ACTIVITY_IDENTIFIER = "idActivite";

  /**
   * Identifiant json champ code activité.
   */
  public static final String JSON_ACTIVITY_CODE = "codeActivite";

  /**
   * Identifiant json champ code activité et nature économique.
   */
  public static final String JSON_ACTIVITY_AND_ECONOMIC_NATURE_CODE =
      "codeActiviteEtNatureEconomique";

  /**
   * Identifiant json champ réprésentation en chaine de caractères d'activité.
   */
  public static final String JSON_ACTIVITY_AS_STRING = "chaineActivite";

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER = "idNatureEconomique";

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#economicNatureCode}.
   */
  public static final String JSON_ECONOMIC_NATURE_CODE = "codeNatureEconomique";

  /**
   * Identifiant json champ {@link AbstractExpenditureOrResourceItemDto#economicNatureAsString}.
   */
  public static final String JSON_ECONOMIC_NATURE_AS_STRING = "natureEconomiqueChaine";

  /* Montants */

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#initialPlannedBudgetAsString}.
   */
  public static final String JSON_INITIAL_PLANNED_BUDGET_AS_STRING = "budgetInitialPlannifieChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#initialRealizedBudgetAsString}.
   */
  public static final String JSON_INITIAL_REALIZED_BUDGET_AS_STRING = "budgetInitialRealiseChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#actualPlannedBudgetAsString}.
   */
  public static final String JSON_ACTUAL_PLANNED_BUDGET_AS_STRING = "budgetActuelPlannifieChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#actualPlannedBudgetAsString}.
   */
  public static final String JSON_ACTUAL_REALIZED_BUDGET_AS_STRING = "budgetActuelRealiseChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#executionPrereservedPlannedBudgetAsString}.
   */
  public static final String JSON_EXECUTION_PRERESERVED_PLANNED_BUDGET_AS_STRING =
      "executionBudgetPrereservePlannifieChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#executionPrereservedRealizedBudgetAsString}.
   */
  public static final String JSON_EXECUTION_PRERESERVED_REALIZED_BUDGET_AS_STRING =
      "executionBudgetPrereserveRealiseChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#prereservedPlannedBudgetAsString}.
   */
  public static final String JSON_PRERESERVED_PLANNED_BUDGET_AS_STRING =
      "budgetPrereservePlannifieChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#prereservedRealizedBudgetAsString}.
   */
  public static final String JSON_PRERESERVED_REALIZED_BUDGET_AS_STRING =
      "budgetPrereserveRealiseChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#elaborationReservedPlannedBudgetAsString}.
   */
  public static final String JSON_ELABORATION_RESERVED_PLANNED_BUDGET_AS_STRING =
      "elaborationBudgetReservePlannifieChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#elaborationReservedRealizedBudgetAsString}.
   */
  public static final String JSON_ELABORATION_RESERVED_REALIZED_BUDGET_AS_STRING =
      "elaborationBudgetReserveRealiseChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#executionReservedPlannedBudgetAsString}.
   */
  public static final String JSON_EXECUTION_RESERVED_PLANNED_BUDGET_AS_STRING =
      "executionBudgetReservePlannifieChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#executionReservedRealizedBudgetAsString}.
   */
  public static final String JSON_EXECUTION_RESERVED_REALIZED_BUDGET_AS_STRING =
      "executionBudgetReserveRealiseChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#reservedPlannedBudgetAsString}.
   */
  public static final String JSON_RESERVED_PLANNED_BUDGET_AS_STRING =
      "budgetReservePlannifieChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#reservedRealizedBudgetAsString}.
   */
  public static final String JSON_RESERVED_REALIZED_BUDGET_AS_STRING = "budgetReserveRealiseChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#executedPlannedBudgetAsString}.
   */
  public static final String JSON_EXECUTED_PLANNED_BUDGET_AS_STRING =
      "budgetExecutePlannifieChaine";

  /**
   * Identifiant json {@link AbstractExpenditureOrResourceItemDto#executedRealizedBudgetAsString}.
   */
  public static final String JSON_EXECUTED_REALIZED_BUDGET_AS_STRING = "budgetExecuteRealiseChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#remainingExecutedPlannedBudget}.
   */
  public static final String JSON_REMAINING_EXECUTED_PLANNED_BUDGET =
      "resteBudgetPlannifie";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#remainingExecutedPlannedBudgetAsString}.
   */
  public static final String JSON_REMAINING_EXECUTED_PLANNED_BUDGET_AS_STRING =
      "resteBudgetPlannifieChaine";

  /**
   * Identifiant json
   * {@link AbstractExpenditureOrResourceItemDto#remainingExecutedRealizedBudgetAsString}.
   */
  public static final String JSON_REMAINING_EXECUTED_REALIZED_BUDGET_AS_STRING =
      "resteBudgetRealiseChaine";
}
