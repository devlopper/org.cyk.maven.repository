package ci.gouv.dgbf.system.mailer.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link TemplateDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-10T15:17:58+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class TemplateRequestMapperImpl implements TemplateRequestMapper {

    @Override
    public TemplateService.TemplateCreateRequestDto mapCreate(TemplateDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TemplateService.TemplateCreateRequestDto templateCreateRequestDto = new TemplateService.TemplateCreateRequestDto();

        templateCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        templateCreateRequestDto.setCode( arg0.getCode() );
        templateCreateRequestDto.setName( arg0.getName() );

        return templateCreateRequestDto;
    }

    @Override
    public TemplateService.TemplateUpdateRequestDto mapUpdate(TemplateDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        TemplateService.TemplateUpdateRequestDto templateUpdateRequestDto = new TemplateService.TemplateUpdateRequestDto();

        templateUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        templateUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        templateUpdateRequestDto.setCode( arg0.getCode() );
        templateUpdateRequestDto.setName( arg0.getName() );

        return templateUpdateRequestDto;
    }
}
