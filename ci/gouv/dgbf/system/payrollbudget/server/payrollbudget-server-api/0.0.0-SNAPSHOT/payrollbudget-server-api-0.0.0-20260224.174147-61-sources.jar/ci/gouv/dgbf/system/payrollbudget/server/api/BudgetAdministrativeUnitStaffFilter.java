package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetAdministrativeUnitIdentifier;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetIdentifier;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasCategoryIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link BudgetAdministrativeUnitStaffDto}.
 *
 * @author parfait
 *
 */
@Getter
@Setter
public class BudgetAdministrativeUnitStaffFilter extends AbstractIdentifiableFilter
    implements FilterHasBudgetIdentifier, FilterHasAdministrativeUnitIdentifier,
               FilterHasBudgetAdministrativeUnitIdentifier, FilterHasCategoryIdentifier {

  String budgetIdentifier;
  String administrativeUnitIdentifier;
  String budgetAdministrativeUnitIdentifier;
  String categoryIdentifier;
  Boolean isFunctionary;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public BudgetAdministrativeUnitStaffFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public BudgetAdministrativeUnitStaffFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetIdentifier(filter);
    updateAdministrativeUnitIdentifier(filter);
    updateBudgetAdministrativeUnitIdentifier(filter);
    updateCategoryIdentifier(filter);
    isFunctionary = getIsFunctionary(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetIdentifier(filter);
    updateFilterAdministrativeUnitIdentifier(filter);
    updateFilterBudgetAdministrativeUnitIdentifier(filter);
    updateFilterCategoryIdentifier(filter);
    setIsFunctionary(filter, isFunctionary);
  }

  /**
   * Cette méthode permet d'assigner est fonctionnaire.
   *
   * @param filter filtre
   * @param isFunctionary est fonctionnaire
   */
  public static void setIsFunctionary(FilterDto filter, Boolean isFunctionary) {
    set(filter, JSON_IS_FUNCTIONARY, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(isFunctionary));
  }

  /**
   * Cette méthode permet d'obtenir est fonctionnaire.
   *
   * @param filter filtre
   * @return est fonctionnaire
   */
  public static Boolean getIsFunctionary(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_IS_FUNCTIONARY));
  }
  
  /**
   * Identifiant json champ {@link BudgetAdministrativeUnitStaffFilter#isFunctionary}.
   */
  public static final String JSON_IS_FUNCTIONARY = 
      BudgetAdministrativeUnitStaffDto.JSON_IS_FUNCTIONARY;
}
