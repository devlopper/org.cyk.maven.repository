package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de dépense.
 *
 * @author Christian
 */
public interface HasExpenditureIdentifierDto extends HasExpenditureIdentifier {

  /**
   * Identifiant json de l'identifiant de dépense.
   */
  String JSON_EXPENDITURE_IDENTIFIER = "idDepense";
}