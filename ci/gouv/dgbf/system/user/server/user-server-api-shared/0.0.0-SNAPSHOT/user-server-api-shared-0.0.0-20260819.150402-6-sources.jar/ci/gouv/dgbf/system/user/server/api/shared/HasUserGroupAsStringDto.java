package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'utilisateur groupe.
 *
 * @author Christian
 */
public interface HasUserGroupAsStringDto extends HasUserGroupAsString {

  /**
   * Identifiant json de représentation en chaine de caractères de l'utilisateur groupe.
   */
  String JSON_USER_GROUP_AS_STRING = "utilisateurGroupeChaine";
}
