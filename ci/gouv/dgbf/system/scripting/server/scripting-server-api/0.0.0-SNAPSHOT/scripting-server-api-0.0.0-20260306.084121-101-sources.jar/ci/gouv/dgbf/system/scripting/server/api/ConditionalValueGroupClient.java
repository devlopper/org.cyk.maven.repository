package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupGetApplicableValueResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ConditionalValueGroupService.ConditionalValueGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ConditionalValueGroupService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ConditionalValueGroupClient extends AbstractClient<ConditionalValueGroupService>
    implements GetByIdentifier<ConditionalValueGroupDto>,
    GetMany<ConditionalValueGroupGetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ConditionalValueGroupClient service(ConditionalValueGroupService service) {
    return (ConditionalValueGroupClient) super.service(service);
  }

  /**
   * {@link ConditionalValueGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ConditionalValueGroupCreateRequestDto request) {
    return new CreateExecutor(ConditionalValueGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ConditionalValueGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ConditionalValueGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ConditionalValueGroupGetManyResponseDto>(
        ConditionalValueGroupGetManyResponseDto.class,
        ConditionalValueGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ConditionalValueGroupService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConditionalValueGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ConditionalValueGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ConditionalValueGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ConditionalValueGroupDto>(ConditionalValueGroupDto.class,
        ConditionalValueGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ConditionalValueGroupService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ConditionalValueGroupDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ConditionalValueGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ConditionalValueGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ConditionalValueGroupDto>(ConditionalValueGroupDto.class,
        ConditionalValueGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ConditionalValueGroupService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ConditionalValueGroupDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ConditionalValueGroupService#getApplicableValue}.
   *
   * @param request requête
   * @return réponse
   */
  public ConditionalValueGroupGetApplicableValueResponseDto getApplicableValue(
      ConditionalValueGroupGetApplicableValueRequestDto request) {
    return new GetOneExecutor<ConditionalValueGroupGetApplicableValueResponseDto>(
        ConditionalValueGroupGetApplicableValueResponseDto.class,
        ConditionalValueGroupService.GET_APPLICABLE_VALUE_IDENTIFIER)
            .execute(() -> service().getApplicableValue(request));
  }

  /**
   * {@link ConditionalValueGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ConditionalValueGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ConditionalValueGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ConditionalValueGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ConditionalValueGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ConditionalValueGroupService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
