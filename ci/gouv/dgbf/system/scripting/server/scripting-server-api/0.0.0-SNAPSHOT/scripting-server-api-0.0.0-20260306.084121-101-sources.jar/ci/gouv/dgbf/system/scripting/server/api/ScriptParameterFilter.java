package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDerivableScriptIdentifier;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasDerivableScriptIdentifiers;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link ScriptParameterDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class ScriptParameterFilter extends AbstractScriptDataFilter
    implements FilterHasDerivableScriptIdentifier, FilterHasDerivableScriptIdentifiers {

  private String derivableScriptIdentifier;

  private Set<String> derivableScriptIdentifiers;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public ScriptParameterFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public ScriptParameterFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateDerivableScriptIdentifier(filter);
    updateDerivableScriptIdentifiers(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterDerivableScriptIdentifier(filter);
    updateFilterDerivableScriptIdentifiers(filter);
  }
}
