package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollbudget.server.api.MovementImpactService.MovementImpactGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Consommateur des impacts des mouvements de carrière.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class MovementImpactClient extends AbstractClient<MovementImpactService>
    implements GetMany<MovementImpactGetManyResponseDto>, GetByIdentifier<MovementImpactDto> {

  @Override
  public MovementImpactClient service(MovementImpactService service) {
    return (MovementImpactClient) super.service(service);
  }

  /**
   * Recherche multicritère des impacts.
   *
   * @param request critères, projection et pagination
   * @return les impacts correspondants
   */
  public MovementImpactGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<MovementImpactGetManyResponseDto>(
        MovementImpactGetManyResponseDto.class, MovementImpactService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  @Override
  public MovementImpactGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Lecture d'un impact par son identifiant.
   *
   * @param request identifiant et projection
   * @return l'impact correspondant
   */
  public MovementImpactDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<MovementImpactDto>(MovementImpactDto.class,
        MovementImpactService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  @Override
  public MovementImpactDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
