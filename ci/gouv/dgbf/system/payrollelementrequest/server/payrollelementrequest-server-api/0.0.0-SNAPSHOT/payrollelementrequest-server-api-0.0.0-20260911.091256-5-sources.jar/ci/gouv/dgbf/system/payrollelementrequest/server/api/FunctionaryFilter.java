package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasFunctionaryRegistrationNumber;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link FunctionaryDto}. Implémente
 * {@link FilterHasFunctionaryRegistrationNumber} pour une recherche dédiée par matricule --
 * distincte du {@code SearchTextFilter} plein-texte (nom/prénom/matricule confondus).
 *
 * @author akm
 *
 */
@Getter
@Setter
public class FunctionaryFilter extends AbstractIdentifiableFilter
    implements FilterHasFunctionaryRegistrationNumber {

  /**
   * Matricule.
   */
  String functionaryRegistrationNumber;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public FunctionaryFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public FunctionaryFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateFunctionaryRegistrationNumber(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterFunctionaryRegistrationNumber(filter);
  }
}
