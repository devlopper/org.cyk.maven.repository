package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasTypeAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasTypeIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un effet attendu d'un type de réclamation (RG_REP_EFF_01/02/03).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExpectedEffectDto extends AbstractIdentifiableAuditableDto
    implements HasTypeIdentifierDto, HasTypeAsStringDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeDto}.
   */
  @JsonbProperty(JSON_TYPE_IDENTIFIER)
  private String typeIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #typeIdentifier}.
   */
  @JsonbProperty(JSON_TYPE_AS_STRING)
  private String typeAsString;

  /**
   * Nature de l'objet visé : {@code ELEMENT_PAIE}, {@code CONSTANTE_PAIE} ou {@code POSTE}
   * (RG_REP_EFF_02).
   */
  @JsonbProperty(JSON_OBJECT_NATURE)
  private String objectNature;

  /**
   * Identifiant de l'Élément de Paie, de la Constante de Paie ou du Poste visé, module
   * {@code payroll} -- sans FK (couplage faible).
   */
  @JsonbProperty(JSON_OBJECT_IDENTIFIER)
  private String objectIdentifier;

  /**
   * Ordre d'affichage dans la liste des Effets Attendus du Type.
   */
  @JsonbProperty(JSON_RANK)
  private Integer rank;

  /**
   * Identifiant json {@link #objectNature}.
   */
  public static final String JSON_OBJECT_NATURE = "nature";

  /**
   * Identifiant json {@link #objectIdentifier}.
   */
  public static final String JSON_OBJECT_IDENTIFIER = "idCible";

  /**
   * Identifiant json {@link #rank}.
   */
  public static final String JSON_RANK = "ordre";

  /**
   * Identifiant json de identifiant de {@link ExpectedEffectDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idEffetAttendu";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExpectedEffectDto}.
   */
  public static final String JSON_THIS_AS_STRING = "effetAttenduChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "effet attendu";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "effets attendus";
}
