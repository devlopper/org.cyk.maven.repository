package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import java.util.Set;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityGroupDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class IdentityGroupFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant {@link IdentityDto}.
   */
  String identityIdentifier;

  /**
   * Identifiants {@link IdentityDto}.
   */
  Set<String> identitiesIdentifiers;

  /**
   * Identifiant {@link IdentityGroupDto}.
   */
  String groupIdentifier;

  /**
   * Identifiants {@link IdentityGroupDto}.
   */
  Set<String> groupsIdentifiers;

  @Override
  protected void doInitialize(FilterDto filter) {
    identityIdentifier = getIdentityIdentifier(filter);
    identitiesIdentifiers = getIdentitiesIdentifiers(filter);
    groupIdentifier = getGroupIdentifier(filter);
    groupsIdentifiers = getGroupsIdentifiers(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setIdentityIdentifier(filter, identityIdentifier);
    setIdentitiesIdentifiers(filter, identitiesIdentifiers);
    setGroupIdentifier(filter, groupIdentifier);
    setGroupsIdentifiers(filter, groupsIdentifiers);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link IdentityDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link IdentityDto}
   */
  public static void setIdentityIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_IDENTITY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link IdentityGroupDto}.
   *
   * @param filter filtre
   * @return {@link IdentityGroupDto}
   */
  public static String getIdentityIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_IDENTITY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants {@link IdentityDto}.
   *
   * @param filter filtre
   * @param identifiers identifiants {@link IdentityDto}
   */
  public static void setIdentitiesIdentifiers(FilterDto filter, Set<String> identifiers) {
    set(filter, JSON_IDENTITIES_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(identifiers));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants {@link IdentityDto}.
   *
   * @param filter filtre
   * @return identifiants {@link IdentityDto}
   */
  public static Set<String> getIdentitiesIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_IDENTITIES_IDENTIFIERS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @param identifier identifiant {@link IdentitiesGroupDto}
   */
  public static void setGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @return identifiants {@link IdentitiesGroupDto}
   */
  public static String getGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner les identifiants {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @param identifiers identifiants {@link IdentitiesGroupDto}
   */
  public static void setGroupsIdentifiers(FilterDto filter, Set<String> identifiers) {
    set(filter, JSON_GROUPS_IDENTIFIERS, f -> f.getValueAsStringsSet(),
        f -> f.setValueAsStringsSetIfNotNull(identifiers));
  }

  /**
   * Cette méthode permet d'obtenir les identifiants {@link IdentitiesGroupDto}.
   *
   * @param filter filtre
   * @return identifiants {@link IdentitiesGroupDto}
   */
  public static Set<String> getGroupsIdentifiers(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringsSetByName(JSON_GROUPS_IDENTIFIERS));
  }

  /**
   * Identifiant JSON {@link #identityIdentifier}.
   */
  public static final String JSON_IDENTITY_IDENTIFIER = "idIdentite";

  /**
   * Identifiant JSON {@link #identitiesIdentifiers}.
   */
  public static final String JSON_IDENTITIES_IDENTIFIERS = "idsIdentites";

  /**
   * Identifiant JSON {@link #groupIdentifier}.
   */
  public static final String JSON_GROUP_IDENTIFIER = "idGroupe";

  /**
   * Identifiant JSON {@link #groupsIdentifiers}.
   */
  public static final String JSON_GROUPS_IDENTIFIERS = "idsGroupes";
}
