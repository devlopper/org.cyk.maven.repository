package ci.gouv.dgbf.system.payroll.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SalaryElementDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-29T15:53:48+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SalaryElementRequestMapperImpl implements SalaryElementRequestMapper {

    @Override
    public SalaryElementService.SalaryElementCreateRequestDto mapCreate(SalaryElementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementService.SalaryElementCreateRequestDto salaryElementCreateRequestDto = new SalaryElementService.SalaryElementCreateRequestDto();

        salaryElementCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        salaryElementCreateRequestDto.setCode( arg0.getCode() );
        salaryElementCreateRequestDto.setName( arg0.getName() );
        salaryElementCreateRequestDto.setSalaryElementGroupIdentifier( arg0.getSalaryElementGroupIdentifier() );
        salaryElementCreateRequestDto.setIsEarning( arg0.getIsEarning() );

        return salaryElementCreateRequestDto;
    }

    @Override
    public SalaryElementService.SalaryElementUpdateRequestDto mapUpdate(SalaryElementDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SalaryElementService.SalaryElementUpdateRequestDto salaryElementUpdateRequestDto = new SalaryElementService.SalaryElementUpdateRequestDto();

        salaryElementUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        salaryElementUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        salaryElementUpdateRequestDto.setCode( arg0.getCode() );
        salaryElementUpdateRequestDto.setName( arg0.getName() );
        salaryElementUpdateRequestDto.setSalaryElementGroupIdentifier( arg0.getSalaryElementGroupIdentifier() );
        salaryElementUpdateRequestDto.setIsEarning( arg0.getIsEarning() );

        return salaryElementUpdateRequestDto;
    }
}
