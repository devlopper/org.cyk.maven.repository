package ci.gouv.dgbf.system.identity.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.primefaces.crud.ListController;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.system.identity.server.api.AbstractIdentityDto;
import ci.gouv.dgbf.system.identity.server.api.IdentityClient;
import ci.gouv.dgbf.system.identity.server.api.IdentityService.IdentityImportAllRequestDto;
import ci.gouv.dgbf.system.identity.server.api.ImportableIdentityClient;
import ci.gouv.dgbf.system.identity.server.api.ImportableIdentityDto;
import ci.gouv.dgbf.system.identity.server.api.ImportableIdentityService;
import ci.gouv.dgbf.system.identity.server.api.ImportableIdentityService.ImportableIdentityImportRequestDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de {@link ImportableIdentityDto} — lecture seule
 * (RG_IDT_IMP_01, source jamais modifiée depuis ce module), avec import unitaire (par ligne) et
 * en masse.
 *
 * @author Christian
 *
 */
@Dependent
public class ImportableIdentityController extends AbstractController {

  @Inject
  ImportableIdentityClient client;

  @Inject
  IdentityClient identityClient;

  @Inject
  @Getter
  ListController listController;

  @Override
  protected void postConstruct() {
    super.postConstruct();
    name = ImportableIdentityDto.NAME;

    listController.setEntityClass(ImportableIdentityDto.class);
    listController.setClient(client);
    listController.setNotificationChannel(ImportableIdentityService.PATH);

    listController.getReadController()
        .setProjection(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER,
            AbstractIdentityDto.JSON_REGISTRATION_NUMBER,
            AbstractIdentityDto.JSON_FIRST_NAME_AND_LAST_NAMES,
            AbstractIdentityDto.JSON_EMAIL_ADDRESS, AbstractIdentityDto.JSON_GENDER_AS_STRING,
            AbstractIdentityDto.JSON_ADMINISTRATIVE_UNIT_AS_STRING));

    listController.initialize();
  }

  /**
   * Cette méthode permet d'importer une identité importable.
   *
   * @param record {@link ImportableIdentityDto}
   */
  public void importOne(ImportableIdentityDto record) {
    ImportableIdentityImportRequestDto request = new ImportableIdentityImportRequestDto();
    request.setIdentifier(record.getIdentifier());
    request.setAuditWho(userIdentifier);
    request.setFrontEndBaseUri(requestManager.buildBaseUri().toString());
    new ActionExecutor<>(this, "Importation", () -> client.importIdentity(request)).execute();
  }

  /**
   * Cette méthode permet d'importer.
   */
  public void importAll() {
    IdentityImportAllRequestDto request = new IdentityImportAllRequestDto();
    request.setAuditWho(userIdentifier);
    request.setFrontEndBaseUri(requestManager.buildBaseUri().toString());
    new ActionExecutor<>(this, "Importation", () -> identityClient.importAll(request)).execute();
  }
}
