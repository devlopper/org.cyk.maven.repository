package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceClient;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollElementInstanceService.PayrollElementInstanceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link PayrollElementInstanceDto}.
 *
 * @author akm
 *
 */
@Dependent
public class PayrollElementInstanceSelectOneController 
    extends AbstractSelectOneIdentifiableController<
    PayrollElementInstanceDto, PayrollElementInstanceGetManyResponseDto, 
    PayrollElementInstanceClient> {

  @Getter
  @Inject
  PayrollElementInstanceClient client;

  protected PayrollElementInstanceSelectOneController() {
    super(PayrollElementInstanceDto.class, SelectItemLabelStrategy.NAME);
  }
}
