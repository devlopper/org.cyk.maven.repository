package ci.gouv.dgbf.system.payrollelementrequest.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneController;
import jakarta.enterprise.context.Dependent;
import jakarta.faces.model.SelectItem;
import java.util.List;
import java.util.Objects;

/**
 * Cette classe représente le contrôleur de sélection du Mode de Saisie d'un Rattachement
 * (référentiel {@code TR_MODE_SAISIE}).
 *
 * @author akm
 *
 */
@Dependent
public class ValueInputModeSelectOneController extends AbstractSelectOneController {

  protected ValueInputModeSelectOneController() {
    outputLableValue = "Mode de Saisie";
  }

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return List.of(new SelectItem(VALUE_FAE, "FAE"), new SelectItem(VALUE_AGENT, "Agent"));
  }

  /**
   * Cette méthode permet d'obtenir le libellé correspondant à une valeur.
   *
   * @param value valeur
   * @return libellé, ou la valeur elle-même si aucune correspondance
   */
  public String labelOf(String value) {
    return computeSelectItemsWhenChoicable().stream()
        .filter(item -> Objects.equals(item.getValue(), value)).map(SelectItem::getLabel)
        .findFirst().orElse(value);
  }

  /**
   * Valeur désignant le mode de saisie FAE.
   */
  public static final String VALUE_FAE = "FAE";

  /**
   * Valeur désignant le mode de saisie Agent.
   */
  public static final String VALUE_AGENT = "AGENT";
}
