package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une nature économique.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class EconomicNatureDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Indique si la nature économique est d'investissement (code commençant par 2).
   */
  @JsonbProperty(JSON_INVESTMENT)
  private Boolean investment;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "nature économique";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "natures économiques";

  /**
   * Identifiant json {@link #investment}.
   */
  public static final String JSON_INVESTMENT = "estInvestissement";
}
