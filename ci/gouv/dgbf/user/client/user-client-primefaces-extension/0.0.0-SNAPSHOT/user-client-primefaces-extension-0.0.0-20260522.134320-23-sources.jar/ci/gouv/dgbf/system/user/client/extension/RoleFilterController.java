package ci.gouv.dgbf.system.user.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.extension.primefaces.component.input.InputTextController;
import ci.gouv.dgbf.system.user.server.api.RoleDto;
import ci.gouv.dgbf.system.user.server.api.RoleFilter;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de filtre de {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class RoleFilterController extends AbstractFilterController<RoleFilter> {

  @Inject
  @Getter
  public InputTextController nameInputTextController;

  /**
   * Cette méthode permet de construire.
   */
  public RoleFilterController() {
    super(RoleFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
    filter.setName(getRequestParameter(RoleFilter.JSON_NAME));

    nameInputTextController.setOutputLableValue("Nom");
    nameInputTextController.getInputText().addValueConsumer(name -> filter.setName(name));

  }
}
