package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a une notion de montant arbitré à l'horizon N1.
 *
 * @author Christian
 */
public interface HasArbitratedAmountN1 extends HasField {

  /**
   * Cette méthode permet d'obtenir le montant arbitré à l'horizon N1.
   *
   * @return le montant arbitré à l'horizon N1
   */
  Long getArbitratedAmountN1();

  /**
   * Cette méthode permet d'assigner le montant arbitré à l'horizon N1.
   *
   * @param amount le montant arbitré à l'horizon N1
   */
  void setArbitratedAmountN1(Long amount);

  /**
   * Identifiant java du montant arbitré à l'horizon N1.
   */
  String FIELD_ARBITRATED_AMOUNT_N1 = "arbitratedAmountN1";
}
