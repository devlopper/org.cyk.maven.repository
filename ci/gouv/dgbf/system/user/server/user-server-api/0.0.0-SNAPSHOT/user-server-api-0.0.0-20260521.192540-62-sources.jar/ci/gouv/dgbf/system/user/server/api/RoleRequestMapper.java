package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleCreateRequestDto;
import ci.gouv.dgbf.system.user.server.api.RoleService.RoleUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link RoleDto}.
 *
 * @author Arnaud
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link RoleDto}.

    @author Arnaud
               """)
public interface RoleRequestMapper
    extends RequestMapper<RoleDto, RoleCreateRequestDto, RoleUpdateRequestDto> {

}
