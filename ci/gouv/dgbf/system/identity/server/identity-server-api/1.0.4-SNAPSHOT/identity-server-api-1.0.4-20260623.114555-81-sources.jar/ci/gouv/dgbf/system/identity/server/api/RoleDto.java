package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un rôle.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class RoleDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Enumération.
   */
  RoleDto enumeration;
  
  /**
   * Est responsable.
   */
  private Boolean isResponsible;
  
  /**
   * Identifiant JSON {@link #enumeration}.
   */
  public static final String JSON_ENUMERATION = "enumeration";
  
  /**
   * Identifiant JSON {@link #isResponsible}.
   */
  public static final String JSON_IS_RESPONSIBLE = "estResponsable";
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "rôle";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
