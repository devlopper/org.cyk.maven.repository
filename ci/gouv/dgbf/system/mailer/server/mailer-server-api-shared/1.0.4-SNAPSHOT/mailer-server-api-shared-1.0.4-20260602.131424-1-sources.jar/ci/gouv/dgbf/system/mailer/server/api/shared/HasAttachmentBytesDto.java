package ci.gouv.dgbf.system.mailer.server.api.shared;

/**
 * Cette interface représente une classe qui a un tableau d'octets de pièce jointe.
 *
 * @author Christian
 */
public interface HasAttachmentBytesDto extends HasAttachmentBytes {

  /**
   * Identifiant json du tableau d'octets de la pièce jointe.
   */
  String JSON_ATTACHMENT_BYTES = "octetsPieceJointe";
}
