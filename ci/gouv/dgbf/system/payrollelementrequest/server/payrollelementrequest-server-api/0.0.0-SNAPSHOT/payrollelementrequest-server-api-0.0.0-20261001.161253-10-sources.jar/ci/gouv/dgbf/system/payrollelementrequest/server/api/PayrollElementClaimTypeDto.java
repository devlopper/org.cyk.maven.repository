package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasClaimTypeGroupAsStringDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasClaimTypeGroupIdentifierDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.shared.HasIsActivatedDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de réclamation.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayrollElementClaimTypeDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasClaimTypeGroupIdentifierDto, HasClaimTypeGroupAsStringDto, HasIsActivatedDto {

  /**
   * Identifiant {@link PayrollElementClaimTypeGroupDto} (RG_REP_SOU_05).
   */
  @JsonbProperty(JSON_CLAIM_TYPE_GROUP_IDENTIFIER)
  private String claimTypeGroupIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimTypeGroupIdentifier}.
   */
  @JsonbProperty(JSON_CLAIM_TYPE_GROUP_AS_STRING)
  private String claimTypeGroupAsString;

  /**
   * Reference (sans FK) vers un role applicatif du module {@code user} determinant qui peut
   * traiter les reclamations de ce Type (RG_REP_SOU_06).
   */
  @JsonbProperty(JSON_ROLE_TRAITEMENT)
  private String roleTraitement;

  /**
   * Interrupteur d'activation (R48, RG_REP_SOU_15) -- désactivé, ce Type ne peut plus être
   * référencé par une nouvelle réclamation.
   */
  @JsonbProperty(JSON_IS_ACTIVATED)
  private Boolean isActivated;

  /**
   * Indique si ce Type est transmissible au Trésor (RG_REP_SOU_08).
   */
  @JsonbProperty(JSON_TREASURY_TRANSMITTABLE)
  private Boolean treasuryTransmittable;

  /**
   * Indique si le dépôt par le FAE est autorisé pour ce Type (RG_REP_SOU_09).
   */
  @JsonbProperty(JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED)
  private Boolean functionaryDepositAuthorized;

  /**
   * Identifiant du Groupe de Types de Document attendus, module {@code documentation} -- sans
   * FK (couplage faible, RG_REP_PCE_01).
   */
  @JsonbProperty(JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER)
  private String expectedDocumentTypesGroupIdentifier;

  /**
   * Description libre de ce Type, facultative (RG_REP_SOU_16).
   */
  @JsonbProperty(JSON_DESCRIPTION)
  private String description;

  /**
   * Référence réglementaire (ex. numéro de décret/arrêté) de ce Type, facultative
   * (RG_REP_SOU_16).
   */
  @JsonbProperty(JSON_REGULATORY_REFERENCE)
  private String regulatoryReference;

  /**
   * Identifiant du Document (module {@code documentation}, sans FK) portant la pièce jointe
   * unique et facultative de {@link #regulatoryReference} (RG_REP_SOU_16), même patron que
   * RG_REP_PCE_03.
   */
  @JsonbProperty(JSON_REGULATORY_REFERENCE_DOCUMENT_IDENTIFIER)
  private String regulatoryReferenceDocumentIdentifier;

  /**
   * Identifiant json {@link #roleTraitement}.
   */
  public static final String JSON_ROLE_TRAITEMENT = "roleTraitement";

  /**
   * Identifiant json {@link #treasuryTransmittable}.
   */
  public static final String JSON_TREASURY_TRANSMITTABLE = "transmissibleAuTresor";

  /**
   * Identifiant json {@link #functionaryDepositAuthorized}.
   */
  public static final String JSON_FUNCTIONARY_DEPOSIT_AUTHORIZED = "depotFaeAutorise";

  /**
   * Identifiant json {@link #expectedDocumentTypesGroupIdentifier}.
   */
  public static final String JSON_EXPECTED_DOCUMENT_TYPES_GROUP_IDENTIFIER =
      "idGroupeTypesDocumentAttendus";

  /**
   * Identifiant json {@link #description}.
   */
  public static final String JSON_DESCRIPTION = "description";

  /**
   * Identifiant json {@link #regulatoryReference}.
   */
  public static final String JSON_REGULATORY_REFERENCE = "referenceReglementaire";

  /**
   * Identifiant json {@link #regulatoryReferenceDocumentIdentifier}.
   */
  public static final String JSON_REGULATORY_REFERENCE_DOCUMENT_IDENTIFIER =
      "idDocumentReferenceReglementaire";

  /**
   * Identifiant json de identifiant de {@link PayrollElementClaimTypeDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idType";

  /**
   * Identifiant json de représentation en chaine de caractères
   * de {@link PayrollElementClaimTypeDto}.
   */
  public static final String JSON_THIS_AS_STRING = "typeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de réclamation";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de réclamation";
}
