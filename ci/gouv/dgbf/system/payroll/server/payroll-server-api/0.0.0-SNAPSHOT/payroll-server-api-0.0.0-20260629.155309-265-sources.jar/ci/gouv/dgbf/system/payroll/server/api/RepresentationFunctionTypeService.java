package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableCreateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractCodableNamableUpdateRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RepresentationFunctionTypeDto}.
 *
 * @author akm
 *
 */
@Path(value = RepresentationFunctionTypeService.PATH)
@Tag(name = "Gestion des representations de type de fonction")
public interface RepresentationFunctionTypeService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "representations-types-fonctions";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author akm
   *
   */
  interface RepresentationFunctionTypeSaveRequestDto {
    /**
     * Cette méthode permet d'obtenir l'identifiant du type de fonction.
     *
     * @return identifiant du type de fonction
     */
    String getFunctionTypeIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du type de fonction.
     *
     * @param identifier identifiant du type de fonction
     */
    void setFunctionTypeIdentifier(String identifier);

    /**
     * Cette méthode permet d'obtenir l'identifiant de {@link RepresentationDto}.
     *
     * @return identifiant {@link RepresentationDto}
     */
    String getRepresentationIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de {@link RepresentationDto}.
     *
     * @param identifier identifiant {@link RepresentationDto}
     */
    void setRepresentationIdentifier(String identifier);

    /**
     * {@link RepresentationFunctionTypeDto#JSON_FUNCTION_TYPE_IDENTIFIER}.
     */
    public static final String JSON_FUNCTION_TYPE_IDENTIFIER =
        RepresentationFunctionTypeDto.JSON_FUNCTION_TYPE_IDENTIFIER;

    /**
     * {@link RepresentationFunctionTypeDto#JSON_REPRESENTATION_IDENTIFIER}.
     */
    public static final String JSON_REPRESENTATION_IDENTIFIER =
        RepresentationFunctionTypeDto.JSON_REPRESENTATION_IDENTIFIER;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RepresentationFunctionTypeCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class RepresentationFunctionTypeCreateRequestDto extends 
      AbstractCodableNamableCreateRequestJsonDto
      implements RepresentationFunctionTypeSaveRequestDto {
    /**
     * Identifiant de {@link FunctionTypeDto}.
     */
    @JsonbProperty(JSON_FUNCTION_TYPE_IDENTIFIER)
    String functionTypeIdentifier;
    /**
     * Identifiant de {@link RepresentationDto}.
     */
    @JsonbProperty(JSON_REPRESENTATION_IDENTIFIER)
    String representationIdentifier;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(
        implementation = RepresentationFunctionTypeGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  public static class RepresentationFunctionTypeGetManyResponseDto
      extends AbstractGetByPageResponseDto<RepresentationFunctionTypeDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RepresentationFunctionTypeDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RepresentationFunctionTypeDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet d'obtenir par identrifiant {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RepresentationFunctionTypeDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RepresentationFunctionTypeUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author akm
   *
   */
  @Getter
  @Setter
  class RepresentationFunctionTypeUpdateRequestDto extends 
      AbstractCodableNamableUpdateRequestJsonDto
      implements RepresentationFunctionTypeSaveRequestDto {
    /**
     * Identifiant du type de fonction.
     */
    @JsonbProperty(JSON_FUNCTION_TYPE_IDENTIFIER)
    String functionTypeIdentifier;
    /**
     * Identifiant de {@link RepresentationDto}.
     */
    @JsonbProperty(JSON_REPRESENTATION_IDENTIFIER)
    String representationIdentifier;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_REPRESENTATION_TYPE_FONCTION";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link RepresentationFunctionTypeDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
