package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPositionService.PayrollPositionCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollPositionService.PayrollPositionUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollPositionDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollPositionDto}.

    @author akm
               """)
public interface PayrollPositionRequestMapper extends RequestMapper<PayrollPositionDto,
    PayrollPositionCreateRequestDto, PayrollPositionUpdateRequestDto> {

}
