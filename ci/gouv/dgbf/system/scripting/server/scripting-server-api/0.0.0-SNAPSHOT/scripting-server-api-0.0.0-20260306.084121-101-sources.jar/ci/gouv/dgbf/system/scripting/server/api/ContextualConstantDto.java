package ci.gouv.dgbf.system.scripting.server.api;


import ci.gouv.dgbf.extension.core.segregation.HasCategoryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasCategoryIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasConstantIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasFromDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasToDateDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une constante contextuelle.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ContextualConstantDto extends AbstractIdentifiableAuditableDto implements
    HasConstantIdentifierDto, HasConstantAsStringDto, HasGroupIdentifierDto, HasGroupAsStringDto,
    HasCategoryIdentifierDto, HasCategoryAsStringDto, HasFromDateDto<LocalDateTime>,
    HasFromDateAsStringDto, HasToDateDto<LocalDateTime>, HasToDateAsStringDto {

  @JsonbProperty(JSON_CONSTANT_IDENTIFIER)
  private String constantIdentifier;

  @JsonbProperty(JSON_CONSTANT_AS_STRING)
  private String constantAsString;
  
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  @JsonbProperty(JSON_CATEGORY_IDENTIFIER)
  private String categoryIdentifier;

  @JsonbProperty(JSON_CATEGORY_AS_STRING)
  private String categoryAsString;

  @JsonbProperty(JSON_FROM_DATE)
  private LocalDateTime fromDate;

  @JsonbProperty(JSON_FROM_DATE_AS_STRING)
  private String fromDateAsString;

  @JsonbProperty(JSON_TO_DATE)
  private LocalDateTime toDate;

  @JsonbProperty(JSON_TO_DATE_AS_STRING)
  private String toDateAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idConstanteContextuelle";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "constanteContextuelleChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "constante contextuelle";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "constantes contextuelles";
}
