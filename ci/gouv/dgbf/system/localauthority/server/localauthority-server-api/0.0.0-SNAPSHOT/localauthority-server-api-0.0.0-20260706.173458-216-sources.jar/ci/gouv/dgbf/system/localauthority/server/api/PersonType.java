package ci.gouv.dgbf.system.localauthority.server.api;

import java.util.Arrays;
import lombok.Getter;

/**
 * Cette énumeration représente les types de personnes (Personnalité juridique).
 *
 * @author Desysoft
 *
 */
@Getter
public enum PersonType {

  /**
   * Personne physique.
   */
  NATURAL_PERSON(PersonTypeCode.NATURAL_PERSON, "Personne physique"),

  /**
   * Personne morale.
   */
  LEGAL_PERSON(PersonTypeCode.LEGAL_PERSON, "Personne morale");

  private String code;
  private String label;

  PersonType(String code, String label) {
    this.code = code;
    this.label = label;
  }

  /**
   * Trouve l'enum par son code.
   *
   * @param code le code (ex: "PERSONNE_PHYSIQUE")
   * @return l'enum correspondant ou null
   */
  public static PersonType fromCode(String code) {
    if (code == null) {
      return null;
    }
    return Arrays.stream(values())
        .filter(type -> type.code.equals(code))
        .findFirst()
        .orElse(null);
  }

}
