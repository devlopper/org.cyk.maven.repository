/**
 * Ce package contient les contrats d'API, DTOs, filtres, énumérations et clients du module
 * Logging DGBF.
 *
 * <h2>Vue d'ensemble architecturale</h2>
 * Le module Logging centralise la traçabilité applicative et transverse du Système
 * d'Information DGBF :
 * <ul>
 *   <li><b>Log applicatif ({@link ci.gouv.dgbf.system.logging.server.api.LogService})</b> :
 *       messages d'événements techniques portant un niveau de sévérité
 *       ({@link ci.gouv.dgbf.extension.core.enumeration.LogLevel}).</li>
 *   <li><b>Opération d'enregistrement
 *       ({@link ci.gouv.dgbf.system.logging.server.api.RecordOperationService})</b> :
 *       traces structurées d'actions métier exécutées sur des enregistrements de données précis
 *       (qui a fait quoi sur quelle fiche, avec quels arguments et quel résultat).</li>
 *   <li><b>Journal transverse unifié
 *       ({@link ci.gouv.dgbf.system.logging.server.api.TraceabilityEventService})</b> :
 *       projection matérialisée commune fédérant les Logs et les Opérations d'enregistrement pour
 *       la consultation, les recherches par corrélation (session d'audit), les tableaux de bord et
 *       les timelines d'activité.</li>
 * </ul>
 *
 * <h2>Guide de nomenclature (Nouveaux développeurs)</h2>
 * Afin d'éviter les confusions fréquentes :
 * <ul>
 *   <li><b>{@code processIdentifier} (Processus)</b> : désigne le composant ou microservice
 *       émetteur (ex. {@code "mic-payroll-api"}), et non un workflow métier BPMN.</li>
 *   <li><b>{@code sourceIdentifier} (Source)</b> : désigne l'entité ou table métier ciblée
 *       (ex. {@code "TA_DEMANDE_CONGE"}), et non la provenance technique de l'appel.</li>
 *   <li><b>{@code recordIdentifier} (Enregistrement)</b> : désigne la clé primaire (identifiant)
 *       de la fiche manipulée dans la table source.</li>
 *   <li><b>{@code operationIdentifier} (Opération)</b> : désigne le code ou verbe de l'action
 *       exécutée (ex. {@code "VALIDATION"}).</li>
 *   <li><b>{@code RecordOperation}</b> : signifie « opération sur un enregistrement » (fiche de
 *       données), et non « action d'enregistrer une opération ».</li>
 *   <li><b>{@code category} vs {@code actionType}</b> : {@code category}
 *       ({@link ci.gouv.dgbf.system.logging.server.api.TraceabilityEventCategory}) distingue
 *       la macro-catégorie d'origine ({@code LOG} vs {@code OPERATION_ENREGISTREMENT}) ;
 *       {@code actionType}
 *       ({@link ci.gouv.dgbf.system.logging.server.api.TraceabilityActionType}) est la
 *       classification fonctionnelle normalisée en 7 verbes universels ({@code LECTURE},
 *       {@code CREATION}, {@code MODIFICATION}, {@code SUPPRESSION}, {@code EXECUTION},
 *       {@code ENVOI}, {@code AUTRE}).</li>
 * </ul>
 *
 * <h2>Invariants et règles d'or</h2>
 * <ul>
 *   <li><b>Append-Only strict</b> : aucun service de modification ({@code UPDATE}) ni de
 *       suppression ({@code DELETE}) n'est exposé. Toutes les données sont en ajout seul.</li>
 *   <li><b>Période bornée</b> : toute recherche d'activité est plafonnée à 90 jours maximum
 *       ({@link ci.gouv.dgbf.system.logging.server.api.TraceabilityEventFilter#MAX_PERIOD_DAYS}).
 *       </li>
 *   <li><b>Habilitation Administrateur</b> : la consultation de l'activité d'autrui exige le rôle
 *       {@link ci.gouv.dgbf.system.logging.server.api.UserRole#ADMINISTRATOR}
 *       ({@code "ADMINISTRATEUR_LOGGING"}).</li>
 * </ul>
 *
 * @author Christian
 *
 */
package ci.gouv.dgbf.system.logging.server.api;
