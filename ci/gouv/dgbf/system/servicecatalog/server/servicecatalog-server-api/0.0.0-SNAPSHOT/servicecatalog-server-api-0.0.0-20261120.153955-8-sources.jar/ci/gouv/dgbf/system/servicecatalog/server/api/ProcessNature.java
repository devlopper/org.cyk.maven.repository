package ci.gouv.dgbf.system.servicecatalog.server.api;

import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les natures d'un {@link ProcessDto}, valeurs du référentiel
 * {@code TR_NATURE_PROCESSUS}.
 *
 * @author Christian
 *
 */
@Getter
public enum ProcessNature {

  /**
   * {@link ProcessNatureCode#BACKEND}.
   */
  BACKEND(ProcessNatureCode.BACKEND, "Backend"),

  /**
   * {@link ProcessNatureCode#FRONTEND_WEB}.
   */
  FRONTEND_WEB(ProcessNatureCode.FRONTEND_WEB, "Frontend Web"),

  /**
   * {@link ProcessNatureCode#FRONTEND_MOBILE_FLUTTER}.
   */
  FRONTEND_MOBILE_FLUTTER(ProcessNatureCode.FRONTEND_MOBILE_FLUTTER,
      "Frontend Mobile (Flutter)"),

  /**
   * {@link ProcessNatureCode#FRONTEND_MOBILE_ANDROID}.
   */
  FRONTEND_MOBILE_ANDROID(ProcessNatureCode.FRONTEND_MOBILE_ANDROID,
      "Frontend Mobile (Android natif)"),

  /**
   * {@link ProcessNatureCode#FRONTEND_MOBILE_IOS}.
   */
  FRONTEND_MOBILE_IOS(ProcessNatureCode.FRONTEND_MOBILE_IOS, "Frontend Mobile (iOS natif)");

  private String code;
  private String name;

  private ProcessNature(String code, String name) {
    this.code = code;
    this.name = name;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Indique si cette nature correspond à un processus frontend lançable (RG_SVC_NAV_04).
   *
   * @return vrai si frontend
   */
  public boolean isFrontend() {
    return FRONTEND_NATURES.contains(this);
  }

  /**
   * Ensemble des natures frontend lançables au Portail (RG_SVC_NAV_04).
   */
  public static final Set<ProcessNature> FRONTEND_NATURES = Set.of(FRONTEND_WEB,
      FRONTEND_MOBILE_FLUTTER, FRONTEND_MOBILE_ANDROID, FRONTEND_MOBILE_IOS);

  /**
   * Cette méthode permet d'obtenir le {@link ProcessNature} par code.
   *
   * @param code code
   * @return {@link ProcessNature}
   */
  public static ProcessNature getByCode(String code) {
    return Stream.of(ProcessNature.values())
        .filter(nature -> nature.getCode().equals(code))
        .findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }
}
