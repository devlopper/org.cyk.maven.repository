package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.functionary.server.api.shared.FilterHasPayScaleIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link GradeClassDto}.
 *
 * @author stephane
 *
 */
@Getter
@Setter
public class GradeClassFilter extends AbstractIdentifiableFilter
    implements FilterHasPayScaleIdentifier {

  private String payScaleIdentifier;

  private String civilServiceStatusIdentifier;

  /**
   * Cette méthode permet d'instancier un objet.
   */
  public GradeClassFilter() {
    super();
  }

  /**
   * Cette méthode permet d'instancier un objet.
   *
   * @param dto filtre
   */
  public GradeClassFilter(FilterDto dto) {
    super(dto);
  }

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updatePayScaleIdentifier(filter);
    civilServiceStatusIdentifier = getCivilServiceStatusIdentifier(filter);

  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterPayScaleIdentifier(filter);
    setCivilServiceStatusIdentifier(filter, civilServiceStatusIdentifier);
  }

  /**
   * Cette méthode permet d'assigner {@link #civilServiceStatusIdentifier}.
   *
   * @param filter filtre
   * @param civilServiceStatusIdentifier {@link #civilServiceStatusIdentifier}
   */
  public static void setCivilServiceStatusIdentifier(FilterDto filter,
      String civilServiceStatusIdentifier) {
    set(filter, JSON_CIVIL_SERVICE_STATUS_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(civilServiceStatusIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir {@link #civilServiceStatusIdentifier}.
   *
   * @param filter filtre
   * @return {@link #civilServiceStatusIdentifier}
   */
  public static String getCivilServiceStatusIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CIVIL_SERVICE_STATUS_IDENTIFIER));
  }

  /**
   * Identifiant json du {@link #civilServiceStatusIdentifier}.
   */
  public static final String JSON_CIVIL_SERVICE_STATUS_IDENTIFIER =
      GradeClassDto.JSON_CIVIL_SERVICE_STATUS_IDENTIFIER;

}
