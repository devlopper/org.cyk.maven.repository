package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FileDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FileDto}.

    @author Christian
               """)
public interface FileRequestMapper
    extends RequestMapper<FileDto, FileCreateRequestDto, FileUpdateRequestDto> {

}
