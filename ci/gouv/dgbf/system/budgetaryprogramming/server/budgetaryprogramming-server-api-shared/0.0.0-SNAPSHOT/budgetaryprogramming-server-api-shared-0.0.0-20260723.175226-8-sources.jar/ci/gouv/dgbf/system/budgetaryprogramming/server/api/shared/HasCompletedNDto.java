package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à indiquer si l'année N est complétée.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasCompletedNDto extends HasCompletedN {

  /**
   * Identifiant json de l'indicateur indiquant si l'année N est complétée.
   */
  String JSON_COMPLETED_N = "completeN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName