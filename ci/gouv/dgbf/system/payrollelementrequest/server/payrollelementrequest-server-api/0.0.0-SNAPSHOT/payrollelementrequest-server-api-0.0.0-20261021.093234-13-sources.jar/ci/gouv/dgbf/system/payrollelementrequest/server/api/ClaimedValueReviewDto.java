package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une Revue de Valeur Réclamée (RVR, RG_REP_RVR_01) -- entité sans code
 * ni nom propres, jusqu'ici jamais exposée en lecture générique (RU_REP_007), désormais
 * nécessaire au portefeuille de l'Agent par statut et par rôle (RU_REP_015).
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimedValueReviewDto extends AbstractIdentifiableAuditableDto
    implements HasStatusDto<ClaimedValueReviewStatus>, HasStatusAsStringDto {

  /**
   * Identifiant {@link ClaimedValueDto} (FK unique, RG_REP_RVR_01).
   */
  @JsonbProperty(JSON_CLAIMED_VALUE_IDENTIFIER)
  private String claimedValueIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimedValueIdentifier}.
   */
  @JsonbProperty(JSON_CLAIMED_VALUE_AS_STRING)
  private String claimedValueAsString;

  /**
   * Identifiant {@code ClaimTypeClaimable} du Réclamable de {@link #claimedValueIdentifier} --
   * intermédiaire technique pour résoudre {@link #claimedValueAsString} (FK composite non
   * navigable en JPA, cf. {@code ClaimableAsStringResolver}).
   */
  @JsonbProperty(JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER)
  private String claimTypeClaimableIdentifier;

  /**
   * Statut courant du circuit (RG_REP_RVR_01).
   */
  @JsonbProperty(JSON_STATUS)
  private ClaimedValueReviewStatus status;

  /**
   * Représentation en chaine de caractères de {@link #status}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Référence (sans FK) vers le Mouvement/la Constante créé(e) une fois la Revue Validée ;
   * {@code null} tant qu'elle ne l'est pas (RG_REP_IMP_05).
   */
  @JsonbProperty(JSON_IMPACT_IDENTIFIER)
  private String impactIdentifier;

  /**
   * Identifiant du Mouvement clôturé par l'Impact (RG_REP_IMP_01/05), {@code null} si l'Impact
   * n'a rien clôturé (création sans Mouvement actif antérieur, Constante de Paie).
   */
  @JsonbProperty(JSON_CLOSED_IMPACT_IDENTIFIER)
  private String closedImpactIdentifier;

  /**
   * Valeur créée par l'Impact : l'instance de l'Élément de Paie du Mouvement créé, ou la
   * catégorie et la valeur de la Constante Contextuelle créée. {@code null} sans Impact créé.
   */
  @JsonbProperty(JSON_IMPACT_VALUE_AS_STRING)
  private String impactValueAsString;

  /**
   * Statut actuel, dans le module {@code payroll}, du Mouvement créé par l'Impact -- {@code null}
   * pour une Constante Contextuelle.
   */
  @JsonbProperty(JSON_IMPACT_STATUS_AS_STRING)
  private String impactStatusAsString;

  /**
   * Indique si le Mouvement créé par l'Impact est actuellement activé, c'est-à-dire en vigueur.
   */
  @JsonbProperty(JSON_IMPACT_ACTIVE)
  private boolean impactActive;

  /**
   * Date d'effet du Mouvement créé par l'Impact (jj/mm/aaaa) -- {@code null} pour une Constante
   * Contextuelle.
   */
  @JsonbProperty(JSON_IMPACT_EFFECTIVE_DATE_AS_STRING)
  private String impactEffectiveDateAsString;

  /**
   * Valeur clôturée par l'Impact, dans le même format que {@link #impactValueAsString}.
   */
  @JsonbProperty(JSON_CLOSED_IMPACT_VALUE_AS_STRING)
  private String closedImpactValueAsString;

  /**
   * Motif du Rejet (RG_REP_RVR_03) -- renseigné pour {@link ClaimedValueReviewStatus#REJECTED}
   * uniquement, {@code null} sinon.
   */
  @JsonbProperty(JSON_MOTIF)
  private String motif;

  /**
   * Identifiant json champ {@link #claimedValueIdentifier}.
   */
  public static final String JSON_CLAIMED_VALUE_IDENTIFIER = ClaimedValueDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json champ {@link #claimedValueAsString}.
   */
  public static final String JSON_CLAIMED_VALUE_AS_STRING = ClaimedValueDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #claimTypeClaimableIdentifier}.
   */
  public static final String JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER =
      ClaimedValueDto.JSON_CLAIM_TYPE_CLAIMABLE_IDENTIFIER;

  /**
   * Identifiant json champ {@link #impactIdentifier}.
   */
  public static final String JSON_IMPACT_IDENTIFIER = "idImpact";

  /**
   * Identifiant json champ {@link #closedImpactIdentifier}.
   */
  public static final String JSON_CLOSED_IMPACT_IDENTIFIER = "idImpactCloture";

  /**
   * Identifiant json champ {@link #impactValueAsString}.
   */
  public static final String JSON_IMPACT_VALUE_AS_STRING = "impactValeurChaine";

  /**
   * Identifiant json champ {@link #impactStatusAsString}.
   */
  public static final String JSON_IMPACT_STATUS_AS_STRING = "impactStatutChaine";

  /**
   * Identifiant json champ {@link #impactActive}.
   */
  public static final String JSON_IMPACT_ACTIVE = "impactActif";

  /**
   * Identifiant json champ {@link #impactEffectiveDateAsString}.
   */
  public static final String JSON_IMPACT_EFFECTIVE_DATE_AS_STRING = "impactDateEffetChaine";

  /**
   * Identifiant json champ {@link #closedImpactValueAsString}.
   */
  public static final String JSON_CLOSED_IMPACT_VALUE_AS_STRING = "impactClotureValeurChaine";

  /**
   * Identifiant json champ {@link #motif}.
   */
  public static final String JSON_MOTIF = "motif";

  /**
   * Identifiant json de identifiant de {@link ClaimedValueReviewDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idRevueValeurReclamee";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ClaimedValueReviewDto}.
   */
  public static final String JSON_THIS_AS_STRING = "revueValeurReclameeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "revue de valeur réclamée";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "revues de valeur réclamée";
}
