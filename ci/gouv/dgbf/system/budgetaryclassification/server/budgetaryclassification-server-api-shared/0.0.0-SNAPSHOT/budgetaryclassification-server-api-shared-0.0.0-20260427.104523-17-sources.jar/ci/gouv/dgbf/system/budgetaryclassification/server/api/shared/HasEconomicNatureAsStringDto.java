package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a une représentation en chaine de caractères
 * de la nature economique.
 *
 * @author arnaud
 */
public interface HasEconomicNatureAsStringDto
       extends HasEconomicNatureAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de la nature economique.
   */
  String JSON_ECONOMIC_NATURE_AS_STRING = "natureEconomiqueChaine";
}
