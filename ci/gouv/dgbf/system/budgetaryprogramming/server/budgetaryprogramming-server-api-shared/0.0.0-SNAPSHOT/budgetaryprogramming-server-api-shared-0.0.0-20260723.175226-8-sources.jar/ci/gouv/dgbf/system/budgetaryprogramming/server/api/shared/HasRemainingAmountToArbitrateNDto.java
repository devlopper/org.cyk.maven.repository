package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant restant à arbitrer pour l'année N.
 *
 * @author Christian
 */
// CHECKSTYLE:OFF: AbbreviationAsWordInName
public interface HasRemainingAmountToArbitrateNDto extends HasRemainingAmountToArbitrateN {

  /**
   * Identifiant json du montant restant à arbitrer pour l'année N.
   */
  String JSON_REMAINING_AMOUNT_TO_ARBITRATE_N = "montantResteAArbitrerN";
}
// CHECKSTYLE:ON: AbbreviationAsWordInName