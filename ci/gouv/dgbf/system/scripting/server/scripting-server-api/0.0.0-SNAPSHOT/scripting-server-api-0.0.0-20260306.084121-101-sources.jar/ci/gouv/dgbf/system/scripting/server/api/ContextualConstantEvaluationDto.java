package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringValueDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une évaluation de constante contextuelle.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ContextualConstantEvaluationDto extends AbstractIdentifiableAuditableDto
    implements HasStringValueDto, HasGroupIdentifierDto, HasGroupAsStringDto {


  /**
   * Réprésentation en chaine de caractères de {@link ContextualConstantEvaluationGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;


  /**
   * Réprésentation en chaine de caractères de {@link ContextualConstantEvaluationGroupDto}.
   */
  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;

  /**
   * Réprésentation en chaine de caractères de {@link ContextualConstantDto}.
   */
  @JsonbProperty(JSON_CONTEXTUAL_CONSTANT_IDENTIFIER)
  private String contextualConstantIdentifier;


  /**
   * Réprésentation en chaine de caractères de {@link ContextualConstantDto}.
   */
  @JsonbProperty(JSON_CONTEXTUAL_CONSTANT_AS_STRING)
  private String contextualConstantAsString;

  /**
   * Valeur.
   */
  @JsonbProperty(value = JSON_VALUE)
  private String value;

  /**
   * Identifiant champ java {@link #contextualConstantIdentifier}.
   */
  public static final String JSON_CONTEXTUAL_CONSTANT_IDENTIFIER =
      ContextualConstantDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #contextualConstantAsString}.
   */
  public static final String JSON_CONTEXTUAL_CONSTANT_AS_STRING =
      ContextualConstantDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idContextualConstantEvaluation";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "contextualConstantEvaluationChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "évaluation de constante contextuelle";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "évaluations de constantes contextuelles";
}
