package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.persistence.Transient;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un exercice.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ExerciseDto extends AbstractIdentifiableCodableNamableDto
    implements PayrollComponentProjectionContainerDto, EmployeeContainerDto {

  /**
   * Année.
   */
  @JsonbProperty(JSON_YEAR)
  Integer year;

  /**
   * Nombre d'employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT)
  Integer employeeCount;
  
  /**
   * Représentation en chaine de caractères du nombre de employé.
   */
  @JsonbProperty(JSON_EMPLOYEE_COUNT_AS_STRING)
  String employeeCountAsString;

  /**
   * Représentation en chaine de caractères du montant de référence.
   */
  @Transient
  @JsonbProperty(JSON_REFERENCE_AMOUNT_AS_STRING)
  String referenceAmountAsString;
  
  /**
   * Représentation en chaine de caractères du montant.
   */
  @JsonbProperty(JSON_AMOUNT_AS_STRING)
  String amountAsString;

  /**
   * Représentation en chaine de caractères de la variance du montant.
   */
  @JsonbProperty(JSON_AMOUNT_VARIANCE_AS_STRING)
  String amountVarianceAsString;
  
  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#INCOMING}.
   */
  @JsonbProperty(JSON_INCOMING_EMPLOYEE_COUNT_AS_STRING)
  String incomingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé
   * {@link AdministrativeUnitEmployeeStatus#OUTGOING}.
   */
  @JsonbProperty(JSON_OUTGOING_EMPLOYEE_COUNT_AS_STRING)
  String outgoingEmployeeCountAsString;

  /**
   * Représentation en chaine de caractères du nombre de employé ayant
   * {@link MovementDto} ayant {@link MovementTypeDto} avec
   * {@link AdministrativeUnitEmployeeStatus#PRESENT}.
   */
  @JsonbProperty(JSON_ADMINISTRATIVE_UNIT_CHANGE_EMPLOYEE_COUNT_AS_STRING)
  String administrativeUnitChangeEmployeeCountAsString;

  /**
   * Identifiant json de identifiant de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idExercice";

  /**
   * Identifiant json de année de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_YEAR = "anneeExercice";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link ExerciseDto}.
   */
  public static final String JSON_THIS_AS_STRING = "exerciceChaine";

  /**
   * Identifiant json {@link #year}.
   */
  public static final String JSON_YEAR = "annee";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "exercice";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
