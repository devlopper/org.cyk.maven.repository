package ci.gouv.dgbf.system.payroll.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeClient;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeDto;
import ci.gouv.dgbf.system.payroll.server.api.FundGroupTypeService.FundGroupTypeGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FundGroupTypeDto}.
 *
 * @author akm
 *
 */
@Dependent
public class FundGroupTypeSelectOneController extends AbstractSelectOneIdentifiableController<
    FundGroupTypeDto, FundGroupTypeGetManyResponseDto, FundGroupTypeClient> {

  @Getter
  @Inject
  FundGroupTypeClient client;

  protected FundGroupTypeSelectOneController() {
    super(FundGroupTypeDto.class, SelectItemLabelStrategy.NAME);
  }
}
