package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.enumeration.StringFormat;
import ci.gouv.dgbf.extension.core.segregation.HasArgumentsDto;
import ci.gouv.dgbf.extension.core.segregation.HasMessageDto;
import ci.gouv.dgbf.extension.core.segregation.HasOperationIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasProcessIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasRecordIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasResultDto;
import ci.gouv.dgbf.extension.core.segregation.HasSourceIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringArgumentsDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatArgumentsFormatDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringFormatResultFormatDto;
import ci.gouv.dgbf.extension.core.segregation.HasStringResultDto;
import ci.gouv.dgbf.extension.server.service.api.SpecificService;
import ci.gouv.dgbf.extension.server.service.api.request.AbstractAuditedRequestJsonDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.response.AbstractGetByPageResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import jakarta.json.bind.annotation.JsonbProperty;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import java.util.List;
import lombok.Getter;
import lombok.Setter;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.media.Content;
import org.eclipse.microprofile.openapi.annotations.media.Schema;
import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;

/**
 * Cette interface représente les services de {@link RecordOperationDto}.
 *
 * @author Arnaud
 *
 */
@Path(value = RecordOperationService.PATH)
@Tag(name = "Gestion des operations d'enregistrement")
public interface RecordOperationService extends SpecificService {

  /**
   * Chemin de base des services.
   */
  String PATH = "operations-enregistrements";

  /**
   * Cette interface représente une requête d'enregistrement.
   *
   * @author Arnaud
   *
   */
  interface RecordOperationSaveRequestDto {


    /**
     * Cette méthode permet d'obtenir l'identifiant du processus.
     *
     * @return l'identifiant du processus
     */
    String getProcessIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant du processus.
     *
     * @param processIdentifeir l'identifiant du processus
     */
    void setProcessIdentifier(String processIdentifeir);


    /**
     * Cette méthode permet d'obtenir l'identifiant de la source.
     *
     * @return l'identifiant de la source
     */
    String getSourceIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de la source.
     *
     * @param sourceIdentifier l'identifiant de la source
     */
    void setSourceIdentifier(String sourceIdentifier);


    /**
     * Cette méthode permet d'obtenir l'identifiant de l'enregistrement.
     *
     * @return l'identifiant de l'enregistrement
     */
    String getRecordIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'enregistrement.
     *
     * @param recordIdentifier l'identifiant de l'enregistrement
     */
    void setRecordIdentifier(String recordIdentifier);


    /**
     * Cette méthode permet d'obtenir l'identifiant de l'operation.
     *
     * @return l'identifiant de l'operation
     */
    String getOperationIdentifier();

    /**
     * Cette méthode permet d'assigner l'identifiant de l'operation.
     *
     * @param operationIdentifier l'identifiant de l'operation
     */
    void setOperationIdentifier(String operationIdentifier);


    /**
     * Cette méthode permet d'obtenir les arguments.
     *
     * @return les arguments
     */
    String getArguments();

    /**
     * Cette méthode permet d'assigner les arguments.
     *
     * @param arguments les arguments
     */
    void setArguments(String arguments);

    /**
     * Cette méthode permet d'obtenir le format des arguments.
     *
     * @return le format des arguments
     */
    StringFormat getArgumentsFormat();

    /**
     * Cette méthode permet d'assigner le format des arguments.
     *
     * @param argumentsFormat le format des arguments
     */
    void setArgumentsFormat(StringFormat argumentsFormat);

    /**
     * Cette méthode permet d'obtenir le resultat.
     *
     * @return le resultat
     */
    String getResult();

    /**
     * Cette méthode permet d'assigner le resultat.
     *
     * @param result le resultat
     */
    void setResult(String result);

    /**
     * Cette méthode permet d'obtenir le format du resultat.
     *
     * @return le format du resultat
     */
    StringFormat getResultFormat();

    /**
     * Cette méthode permet d'assigner le format du resultat.
     *
     * @param resultFormat le format du resultat
     */
    void setResultFormat(StringFormat resultFormat);

    /**
     * Cette méthode permet d'obtenir le message.
     *
     * @return le message
     */
    String getMessage();

    /**
     * Cette méthode permet d'assigner le message.
     *
     * @param message le message
     */
    void setMessage(String message);
    
    /**
     * {@link HasProcessIdentifierDto#JSON_PROCESS_IDENTIFIER}.
     */
    String JSON_PROCESS_IDENTIFIER = HasProcessIdentifierDto.JSON_PROCESS_IDENTIFIER;

    /**
     * {@link HasSourceIdentifierDto#JSON_SOURCE_IDENTIFIER}.
     */
    String JSON_SOURCE_IDENTIFIER = HasSourceIdentifierDto.JSON_SOURCE_IDENTIFIER;

    /**
     * {@link HasOperationIdentifierDto#JSON_OPERATION_IDENTIFIER}.
     */
    String JSON_OPERATION_IDENTIFIER = HasOperationIdentifierDto.JSON_OPERATION_IDENTIFIER;

    /**
     * {@link HasRecordIdentifierDto#JSON_RECORD_IDENTIFIER}.
     */
    String JSON_RECORD_IDENTIFIER = HasRecordIdentifierDto.JSON_RECORD_IDENTIFIER;

    /**
     * {@link HasStringArgumentsDto#JSON_ARGUMENTS}.
     */
    String JSON_ARGUMENTS = HasArgumentsDto.JSON_ARGUMENTS;

    /**
     * {@link HasStringFormatArgumentsFormatDto#JSON_ARGUMENTS_FORMAT}.
     */
    String JSON_ARGUMENTS_FORMAT = HasStringFormatArgumentsFormatDto.JSON_ARGUMENTS_FORMAT;

    /**
     * {@link HasStringResultDto#JSON_RESULT}.
     */
    String JSON_RESULT = HasResultDto.JSON_RESULT;

    /**
     * {@link HasStringFormatResultFormatDto#JSON_RESULT_FORMAT}.
     */
    String JSON_RESULT_FORMAT = HasStringFormatResultFormatDto.JSON_RESULT_FORMAT;
    
    /**
     * {@link HasMessageDto#JSON_MESSAGE}.
     */
    String JSON_MESSAGE = HasMessageDto.JSON_MESSAGE;
  }

  /**
   * Identifiant du service de création.
   */
  String CREATE_IDENTIFIER = "CREATION_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service de création.
   */
  String CREATE_PATH = "";

  /**
   * Cette méthode permet de créer {@link RecordOperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(CREATE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(MediaType.APPLICATION_JSON)
  @Operation(operationId = CREATE_IDENTIFIER)
  @APIResponse(responseCode = "201",
      content = {@Content(schema = @Schema(implementation = CreateResponseDto.class))})
  Response create(RecordOperationCreateRequestDto request);

  /**
   * Cette classe représente la requête de création.
   *
   * @author Arnaud
   *
   */
  @Getter
  @Setter
  class RecordOperationCreateRequestDto extends AbstractAuditedRequestJsonDto
      implements RecordOperationSaveRequestDto {

    @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(value = JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(value = JSON_OPERATION_IDENTIFIER)
    private String operationIdentifier;

    @JsonbProperty(value = JSON_RECORD_IDENTIFIER)
    private String recordIdentifier;

    @JsonbProperty(value = JSON_ARGUMENTS)
    private String arguments;

    @JsonbProperty(value = JSON_ARGUMENTS_FORMAT)
    private StringFormat argumentsFormat;
    
    @JsonbProperty(value = JSON_RESULT)
    private String result;

    @JsonbProperty(value = JSON_RESULT_FORMAT)
    private StringFormat resultFormat;
    
    @JsonbProperty(value = JSON_MESSAGE)
    private String message;
  }

  /**
   * Identifiant du service d'obtention de plusieurs.
   */
  String GET_MANY_IDENTIFIER = "OBTENTION_PLUSIEURS_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service d'obtention de plusieurs.
   */
  String GET_MANY_PATH = "obtention/plusieurs";

  /**
   * Cette méthode permet d'obtenir plusieurs {@link RecordOperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_MANY_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_MANY_IDENTIFIER)
  @APIResponse(responseCode = "200", content = {
      @Content(schema = @Schema(implementation = RecordOperationGetManyResponseDto.class))})
  Response getMany(GetManyRequestDto request);

  /**
   * Cette classe représente l'objet de transfert de donnée de la réponse d'obtention de plusieurs.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  public static class RecordOperationGetManyResponseDto
      extends AbstractGetByPageResponseDto<RecordOperationDto> {

    @JsonbProperty(JSON_DATAS)
    private List<RecordOperationDto> datas;
  }

  /**
   * Identifiant du service d'obtention de un.
   */
  String GET_ONE_IDENTIFIER = "OBTENTION_UN_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service d'obtention de un.
   */
  String GET_ONE_PATH = "obtention/un";

  /**
   * Cette méthode permet d'obtenir {@link RecordOperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_ONE_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_ONE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RecordOperationDto.class))})
  Response getOne(GetOneRequestDto request);

  /**
   * Identifiant du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_IDENTIFIER = "OBTENTION_PAR_IDENTIFIANT_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service d'obtention par identifiant de un.
   */
  String GET_BY_IDENTIFIER_PATH = "obtention/par-identifiant";

  /**
   * Cette méthode permet la mise à jour.
   *
   * @param request requête
   * @return réponse
   */
  @Path(GET_BY_IDENTIFIER_PATH)
  @POST
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON})
  @Operation(operationId = GET_BY_IDENTIFIER_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = RecordOperationDto.class))})
  Response getByIdentifier(GetByIdentifierRequestDto request);

  /**
   * Identifiant du service de mise à jour.
   */
  String UPDATE_IDENTIFIER = "MISE_A_JOUR_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service de mise à jour.
   */
  String UPDATE_PATH = "";

  /**
   * Cette méthode permet de mettre à jour {@link RecordOperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(UPDATE_PATH)
  @PUT
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = UPDATE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response update(RecordOperationUpdateRequestDto request);

  /**
   * Cette classe représente la requête de mise à jour.
   *
   * @author Arnaud
   */
  @Getter
  @Setter
  class RecordOperationUpdateRequestDto extends ByIdentifierRequestDto
      implements RecordOperationSaveRequestDto {

    @JsonbProperty(value = JSON_PROCESS_IDENTIFIER)
    private String processIdentifier;

    @JsonbProperty(value = JSON_SOURCE_IDENTIFIER)
    private String sourceIdentifier;

    @JsonbProperty(value = JSON_OPERATION_IDENTIFIER)
    private String operationIdentifier;

    @JsonbProperty(value = JSON_RECORD_IDENTIFIER)
    private String recordIdentifier;

    @JsonbProperty(value = JSON_ARGUMENTS)
    private String arguments;

    @JsonbProperty(value = JSON_ARGUMENTS_FORMAT)
    private StringFormat argumentsFormat;
    
    @JsonbProperty(value = JSON_RESULT)
    private String result;
    
    @JsonbProperty(value = JSON_RESULT_FORMAT)
    private StringFormat resultFormat;
    
    @JsonbProperty(value = JSON_MESSAGE)
    private String message;
  }

  /**
   * Identifiant du service de suppression.
   */
  String DELETE_IDENTIFIER = "SUPPRESSION_UN_OPERATION_ENREGISTREMENT";

  /**
   * Chemin du service de suppression.
   */
  String DELETE_PATH = "";

  /**
   * Cette méthode permet de supprimer {@link RecordOperationDto}.
   *
   * @param request requête
   * @return réponse
   */
  @Path(DELETE_PATH)
  @DELETE
  @Consumes(MediaType.APPLICATION_JSON)
  @Produces(value = {MediaType.APPLICATION_JSON, MediaType.TEXT_PLAIN})
  @Operation(operationId = DELETE_IDENTIFIER)
  @APIResponse(responseCode = "200",
      content = {@Content(schema = @Schema(implementation = IdentifiableResponseDto.class))})
  Response delete(DeleteOneRequestDto request);
}
