package ci.gouv.dgbf.system.ticket.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'équipe support.
 *
 * @author Arnaud
 */
public interface HasSupportTeamAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'équipe support.
   *
   * @return représentation en chaine de caractères de l'équipe support
   */
  String getSupportTeamAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'équipe
   * support.
   *
   * @param supportTeamAsString représentation en chaine de caractères de l'équipe support
   */
  void setSupportTeamAsString(String supportTeamAsString);

  /**
   * Identifiant java de la représentation en chaine de caractères de l'équipe support.
   */
  String FIELD_SUPPORT_TEAM_AS_STRING = "supportTeamAsString";
}
