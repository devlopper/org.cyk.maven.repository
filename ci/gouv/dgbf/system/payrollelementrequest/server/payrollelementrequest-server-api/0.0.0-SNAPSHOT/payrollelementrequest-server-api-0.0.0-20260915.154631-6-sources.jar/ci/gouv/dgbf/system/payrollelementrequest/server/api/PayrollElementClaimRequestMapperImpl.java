package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PayrollElementClaimDto}.
*
* @author akm
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-09-15T15:46:51+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PayrollElementClaimRequestMapperImpl implements PayrollElementClaimRequestMapper {

    @Override
    public PayrollElementClaimService.PayrollElementClaimCreateRequestDto mapCreate(PayrollElementClaimDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimService.PayrollElementClaimCreateRequestDto payrollElementClaimCreateRequestDto = new PayrollElementClaimService.PayrollElementClaimCreateRequestDto();

        payrollElementClaimCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollElementClaimCreateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollElementClaimCreateRequestDto.setNature( arg0.getNature() );
        payrollElementClaimCreateRequestDto.setComment( arg0.getComment() );
        payrollElementClaimCreateRequestDto.setEmailAddress( arg0.getEmailAddress() );
        payrollElementClaimCreateRequestDto.setDocumentsGroupIdentifier( arg0.getDocumentsGroupIdentifier() );
        payrollElementClaimCreateRequestDto.setConcernedFunctionaryIdentifier( arg0.getConcernedFunctionaryIdentifier() );
        Map<String, String> map = arg0.getConcernedStructure();
        if ( map != null ) {
            payrollElementClaimCreateRequestDto.setConcernedStructure( new LinkedHashMap<String, String>( map ) );
        }

        return payrollElementClaimCreateRequestDto;
    }

    @Override
    public PayrollElementClaimService.PayrollElementClaimUpdateRequestDto mapUpdate(PayrollElementClaimDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PayrollElementClaimService.PayrollElementClaimUpdateRequestDto payrollElementClaimUpdateRequestDto = new PayrollElementClaimService.PayrollElementClaimUpdateRequestDto();

        payrollElementClaimUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        payrollElementClaimUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        payrollElementClaimUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        payrollElementClaimUpdateRequestDto.setTypeIdentifier( arg0.getTypeIdentifier() );
        payrollElementClaimUpdateRequestDto.setNature( arg0.getNature() );
        payrollElementClaimUpdateRequestDto.setComment( arg0.getComment() );

        return payrollElementClaimUpdateRequestDto;
    }
}
