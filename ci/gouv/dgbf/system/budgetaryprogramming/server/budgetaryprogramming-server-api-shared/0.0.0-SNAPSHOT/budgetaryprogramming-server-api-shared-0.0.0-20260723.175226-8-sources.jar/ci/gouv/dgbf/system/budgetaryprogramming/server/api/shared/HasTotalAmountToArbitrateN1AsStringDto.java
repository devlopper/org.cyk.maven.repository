package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à arbitrer pour l'année N+1,
 * sous forme de chaîne de caractères.
 *
 * @author Christian
 */
public interface HasTotalAmountToArbitrateN1AsStringDto
    extends HasTotalAmountToArbitrateN1AsString {

  /**
   * Identifiant json du montant total à arbitrer pour l'année N+1, sous forme de chaîne de
   * caractères.
   */
  String JSON_TOTAL_AMOUNT_TO_ARBITRATE_N1_AS_STRING = "montantTotalAArbitrerN1Chaine";
}
