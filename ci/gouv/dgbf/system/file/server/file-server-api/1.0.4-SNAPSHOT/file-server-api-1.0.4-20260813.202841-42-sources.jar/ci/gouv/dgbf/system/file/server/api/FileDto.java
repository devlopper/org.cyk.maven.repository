package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasConfirmableDto;
import ci.gouv.dgbf.extension.core.segregation.HasContentTypeDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasHashDto;
import ci.gouv.dgbf.extension.core.segregation.HasNumberOfBytesAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasNumberOfBytesDto;
import ci.gouv.dgbf.extension.core.segregation.HasOwnerAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasOwnerIdentifierDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasPlannedPurgeDateDto;
import ci.gouv.dgbf.extension.core.segregation.HasPrimitiveBytesArrayDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasStatusDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un fichier.
 *
 * @author Christian Yao Komenan
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class FileDto extends AbstractIdentifiableNamableAuditableDto
    implements HasContentTypeDto, HasPrimitiveBytesArrayDto, HasNumberOfBytesDto<Integer>,
    HasNumberOfBytesAsStringDto, HasOwnerIdentifierDto, HasOwnerAsStringDto, HasHashDto,
    HasGroupIdentifierDto, HasStatusDto<FileStatus>, HasStatusAsStringDto, HasConfirmableDto,
    HasPlannedPurgeDateDto<LocalDateTime>, HasPlannedPurgeDateAsStringDto {

  @JsonbProperty(value = JSON_CONTENT_TYPE)
  private String contentType;

  @JsonbProperty(value = JSON_BYTES)
  private byte[] bytes;

  @JsonbProperty(value = JSON_NUMBER_OF_BYTES)
  private Integer numberOfBytes;

  @JsonbProperty(value = JSON_NUMBER_OF_BYTES_AS_STRING)
  private String numberOfBytesAsString;

  @JsonbProperty(value = JSON_OWNER_IDENTIFIER)
  private String ownerIdentifier;

  @JsonbProperty(value = JSON_OWNER_AS_STRING)
  private String ownerAsString;

  @JsonbProperty(value = JSON_HASH)
  private String hash;

  @JsonbProperty(value = JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(value = JSON_STATUS)
  private FileStatus status;

  @JsonbProperty(value = JSON_STATUS_AS_STRING)
  private String statusAsString;

  @JsonbProperty(value = JSON_CONFIRMABLE)
  private Boolean confirmable;

  @JsonbProperty(value = JSON_PLANNED_PURGE_DATE)
  private LocalDateTime plannedPurgeDate;

  @JsonbProperty(value = JSON_PLANNED_PURGE_DATE_AS_STRING)
  private String plannedPurgeDateAsString;

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "fichier";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
