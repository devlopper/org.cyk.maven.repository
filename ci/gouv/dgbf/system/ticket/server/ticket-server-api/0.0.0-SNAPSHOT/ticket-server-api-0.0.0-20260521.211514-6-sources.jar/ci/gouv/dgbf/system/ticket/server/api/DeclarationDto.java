package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une déclaration.
 *
 * @author Arnaud
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class DeclarationDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link TicketDto}.
   */
  @JsonbProperty(JSON_TICKET_IDENTIFIER)
  private String ticketIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link TicketDto}.
   */
  @JsonbProperty(JSON_TICKET_AS_STRING)
  private String ticketAsString;

  /**
   * Identifiant identifiant identité du déclarant .
   */
  @JsonbProperty(JSON_REPORTER_IDENTITY_IDENTIFIER)
  private String reporterIdentityIdentifier;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idDeclaration";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "reporterChaine";


  /**
   * Identifiant champ java {@link #ticketIdentifier}.
   */
  public static final String JSON_TICKET_IDENTIFIER =
      TicketDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #ticketAsString}.
   */
  public static final String JSON_TICKET_AS_STRING = TicketDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #reporterIdentityIdentifier}.
   */
  public static final String JSON_REPORTER_IDENTITY_IDENTIFIER = "identifiantIdentiteDeclarant";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "déclaration";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";

}

