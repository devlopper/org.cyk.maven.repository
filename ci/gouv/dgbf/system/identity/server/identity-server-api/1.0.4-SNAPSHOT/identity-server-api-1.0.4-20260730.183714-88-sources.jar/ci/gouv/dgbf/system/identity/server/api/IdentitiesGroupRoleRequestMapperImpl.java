package ci.gouv.dgbf.system.identity.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link IdentitiesGroupRoleDto}.
*
* @author Arnaud
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-07-30T18:37:41+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class IdentitiesGroupRoleRequestMapperImpl implements IdentitiesGroupRoleRequestMapper {

    @Override
    public IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto mapCreate(IdentitiesGroupRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto identitiesGroupRoleCreateRequestDto = new IdentitiesGroupRoleService.IdentitiesGroupRoleCreateRequestDto();

        identitiesGroupRoleCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        identitiesGroupRoleCreateRequestDto.setAuditSession( arg0.getAuditSession() );
        identitiesGroupRoleCreateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        identitiesGroupRoleCreateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return identitiesGroupRoleCreateRequestDto;
    }

    @Override
    public IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto mapUpdate(IdentitiesGroupRoleDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto identitiesGroupRoleUpdateRequestDto = new IdentitiesGroupRoleService.IdentitiesGroupRoleUpdateRequestDto();

        identitiesGroupRoleUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        identitiesGroupRoleUpdateRequestDto.setAuditSession( arg0.getAuditSession() );
        identitiesGroupRoleUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        identitiesGroupRoleUpdateRequestDto.setGroupIdentifier( arg0.getGroupIdentifier() );
        identitiesGroupRoleUpdateRequestDto.setRoleIdentifier( arg0.getRoleIdentifier() );

        return identitiesGroupRoleUpdateRequestDto;
    }
}
