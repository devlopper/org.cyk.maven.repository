package ci.gouv.dgbf.extension.primefaces.page;

import java.io.Serializable;
import java.util.Map;

/** Lien GET interne rendu par JSF, sans action métier associée. */
public final class IdentifiablePageNavigation implements Serializable {
  private static final long serialVersionUID = 1L;
  private final String label;
  private final String outcome;
  private final Map<String, String> parameters;

  public IdentifiablePageNavigation(String label, String outcome) {
    this(label, outcome, Map.of());
  }

  /** Construit un lien interne avec des paramètres encodés lors du rendu JSF. */
  public IdentifiablePageNavigation(String label, String outcome, Map<String, String> parameters) {
    if (label == null || label.isBlank() || outcome == null || outcome.isBlank()) {
      throw new IllegalArgumentException("Libellé et outcome de navigation requis");
    }
    this.label = label;
    this.outcome = outcome;
    this.parameters = Map.copyOf(parameters);
  }

  public String getLabel() {
    return label;
  }

  public String getOutcome() {
    return outcome;
  }

  public Map<String, String> getParameters() {
    return parameters;
  }
}
