package ci.gouv.dgbf.system.file.server.api;

import java.util.stream.Stream;
import lombok.AccessLevel;
import lombok.Getter;

/**
 * Cette classe représente la nature du support d'un {@link FileDto}, déduite des exemplaires
 * présents et jamais saisie (RG_FILE_FIC_17, DEC_FILE_01 D03). Elle type aussi le support
 * d'origine, fixé à la création, qui n'est jamais hybride ({@link #canBeOriginal()},
 * DEC_FILE_02 D15).
 *
 * @author Christian
 *
 */
@Getter
public enum MediumNature {

  /**
   * Contenu binaire seul.
   */
  DIGITAL("NUMERIQUE", "Numérique", true),

  /**
   * Exemplaire physique seul.
   */
  PHYSICAL("PHYSIQUE", "Physique", true),

  /**
   * Contenu binaire et Exemplaire physique.
   */
  HYBRID("HYBRIDE", "Hybride", false);

  private final String code;
  private final String name;
  @Getter(AccessLevel.NONE)
  private final boolean originalPossible;

  private MediumNature(String code, String name, boolean originalPossible) {
    this.code = code;
    this.name = name;
    this.originalPossible = originalPossible;
  }

  /**
   * Cette méthode permet de savoir si cette nature peut être un support d'origine : un original
   * est numérique ou physique, jamais hybride (DEC_FILE_02 D15).
   *
   * @return vrai si la nature peut être un support d'origine
   */
  public boolean canBeOriginal() {
    return originalPossible;
  }

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le {@link MediumNature} par code.
   *
   * @param code code
   * @return {@link MediumNature}
   */
  public static MediumNature getByCode(String code) {
    return Stream.of(values()).filter(nature -> nature.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  /**
   * Cette méthode permet de déduire la nature du support des exemplaires présents.
   *
   * @param hasBinaryContent le Fichier a un contenu binaire
   * @param hasPhysicalItem le Fichier a un Exemplaire physique
   * @return {@link MediumNature}, {@code null} si aucun exemplaire n'est présent
   */
  public static MediumNature of(boolean hasBinaryContent, boolean hasPhysicalItem) {
    if (hasBinaryContent) {
      return hasPhysicalItem ? HYBRID : DIGITAL;
    }
    return hasPhysicalItem ? PHYSICAL : null;
  }
}
