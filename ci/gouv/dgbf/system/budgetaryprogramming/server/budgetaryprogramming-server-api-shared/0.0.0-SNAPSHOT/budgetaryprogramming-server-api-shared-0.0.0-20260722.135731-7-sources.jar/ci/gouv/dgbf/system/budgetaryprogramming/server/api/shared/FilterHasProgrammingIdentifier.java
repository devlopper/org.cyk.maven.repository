package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * Cette interface représente une classe qui a un filtre par identifiant de programmation.
 *
 * @author Christian
 */
public interface FilterHasProgrammingIdentifier extends HasProgrammingIdentifier {

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la programmation.
   *
   * @param filter {@link FilterDto}
   */
  default void updateProgrammingIdentifier(FilterDto filter) {
    setProgrammingIdentifier(ProgrammingIdentifierFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour l'identifiant de la programmation de {@link FilterDto}.
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterProgrammingIdentifier(FilterDto filter) {
    ProgrammingIdentifierFilter.set(filter, getProgrammingIdentifier());
  }

}
