package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupClient;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionGroupService.FunctionGroupGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FunctionGroupDto}.
 *
 * @author Arnaud
 *
 */
@Dependent
public class FunctionGroupSelectOneController extends AbstractSelectOneIdentifiableController<
    FunctionGroupDto, FunctionGroupGetManyResponseDto, FunctionGroupClient> {

  @Getter
  @Inject
  FunctionGroupClient client;

  /**
   * Cette méthode permet de construire.
   */
  protected FunctionGroupSelectOneController() {
    super(FunctionGroupDto.class, SelectItemLabelStrategy.NAME);
  }
}
