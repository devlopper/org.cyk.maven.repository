package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportCreateRequestDto;
import ci.gouv.dgbf.system.report.server.api.ReportService.ReportUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ReportDto}.
 *
 * @author Desysoft
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link ReportDto}.
    
    @author Desysoft
    """)
public interface ReportRequestMapper extends RequestMapper<ReportDto,
    ReportCreateRequestDto, ReportUpdateRequestDto> {

}
