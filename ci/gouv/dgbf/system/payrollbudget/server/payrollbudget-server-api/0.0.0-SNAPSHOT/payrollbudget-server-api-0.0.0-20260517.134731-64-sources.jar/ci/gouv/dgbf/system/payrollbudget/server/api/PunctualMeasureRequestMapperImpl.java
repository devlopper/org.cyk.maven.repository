package ci.gouv.dgbf.system.payrollbudget.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link PunctualMeasureDto}.
*
* @author Christian
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-05-17T13:47:55+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class PunctualMeasureRequestMapperImpl implements PunctualMeasureRequestMapper {

    @Override
    public PunctualMeasureService.PunctualMeasureCreateRequestDto mapCreate(PunctualMeasureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PunctualMeasureService.PunctualMeasureCreateRequestDto punctualMeasureCreateRequestDto = new PunctualMeasureService.PunctualMeasureCreateRequestDto();

        punctualMeasureCreateRequestDto.setCode( arg0.getCode() );
        punctualMeasureCreateRequestDto.setName( arg0.getName() );
        punctualMeasureCreateRequestDto.setIsActive( arg0.getIsActive() );

        return punctualMeasureCreateRequestDto;
    }

    @Override
    public PunctualMeasureService.PunctualMeasureUpdateRequestDto mapUpdate(PunctualMeasureDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        PunctualMeasureService.PunctualMeasureUpdateRequestDto punctualMeasureUpdateRequestDto = new PunctualMeasureService.PunctualMeasureUpdateRequestDto();

        punctualMeasureUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        punctualMeasureUpdateRequestDto.setCode( arg0.getCode() );
        punctualMeasureUpdateRequestDto.setName( arg0.getName() );
        punctualMeasureUpdateRequestDto.setIsActive( arg0.getIsActive() );

        return punctualMeasureUpdateRequestDto;
    }
}
