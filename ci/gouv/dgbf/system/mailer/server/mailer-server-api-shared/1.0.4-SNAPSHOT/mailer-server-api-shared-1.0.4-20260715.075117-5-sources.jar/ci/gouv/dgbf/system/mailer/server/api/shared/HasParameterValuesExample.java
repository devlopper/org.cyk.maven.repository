package ci.gouv.dgbf.system.mailer.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe qui a un exemple de valeurs de paramètres.
 *
 * @author Christian
 */
public interface HasParameterValuesExample extends HasField {

  /**
   * Cette méthode permet d'obtenir l'exemple de valeurs de paramètres.
   *
   * @return l'exemple de valeurs de paramètres
   */
  String getParameterValuesExample();

  /**
   * Cette méthode permet d'assigner l'exemple de valeurs de paramètres.
   *
   * @param parameterValuesExample l'exemple de valeurs de paramètres
   */
  void setParameterValuesExample(String parameterValuesExample);

  /**
   * Identifiant java de l'exemple de valeurs de paramètres.
   */
  String FIELD_PARAMETER_VALUES_EXAMPLE = "parameterValuesExample";
}
