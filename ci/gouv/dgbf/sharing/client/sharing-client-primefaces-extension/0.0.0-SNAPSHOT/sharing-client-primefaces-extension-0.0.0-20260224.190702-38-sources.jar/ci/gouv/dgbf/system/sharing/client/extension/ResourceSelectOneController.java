package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceClient;
import ci.gouv.dgbf.system.sharing.server.api.ResourceDto;
import ci.gouv.dgbf.system.sharing.server.api.ResourceService.ResourceGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link ResourceDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class ResourceSelectOneController extends AbstractSelectOneIdentifiableController<
    ResourceDto, ResourceGetManyResponseDto, ResourceClient> {

  @Inject
  @Getter
  ResourceClient client;

  /**
   * Cette methode permet de construire.
   */
  protected ResourceSelectOneController() {
    super(ResourceDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
