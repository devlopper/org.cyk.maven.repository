package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.time.LocalDateTime;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un historique de ticket.
 *
 * @author kimou
 *
 */

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class TicketHistoryDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant de {@link TicketDto}.
   */
  @JsonbProperty(JSON_TICKET_IDENTIFIER)
  private String ticketIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link TicketDto}.
   */
  @JsonbProperty(JSON_TICKET_AS_STRING)
  private String ticketAsString;


  /**
   * Identifiant de {@link SupportLevelDto}.
   */
  @JsonbProperty(JSON_SUPPORT_LEVEL_IDENTIFIER)
  private String supportLevelIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportLevelDto}.
   */
  @JsonbProperty(JSON_SUPPORT_LEVEL_AS_STRING)
  private String supportLevelAsString;

  /**
   * Identifiant de {@link FunctionalDomainDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_DOMAIN_IDENTIFIER)
  private String functionalDomainIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link FunctionalDomainDto}.
   */
  @JsonbProperty(JSON_FUNCTIONAL_DOMAIN_AS_STRING)
  private String functionalDomainAsString;

  /**
   * Identifiant de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_IDENTIFIER)
  private String supportTeamIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_AS_STRING)
  private String supportTeamAsString;

  /**
   * Identifiant de {@link SupportTeamMemberDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER)
  private String supportTeamMemberIdentifier;

  /**
   * Réprésentation en chaine de caractères de {@link SupportTeamDto}.
   */
  @JsonbProperty(JSON_SUPPORT_TEAM_MEMBER_AS_STRING)
  private String supportTeamMemberAsString;


  /**
   * commentaire.
   */
  @JsonbProperty(JSON_COMMENT)
  private String comment;

  /**
   * Date et heure de la transition métier tracée par cet historique.
   */
  @JsonbProperty(JSON_DATE)
  private LocalDateTime date;

  /**
   * {@link TicketStatus}.
   */
  @JsonbProperty(JSON_STATUS)
  private TicketStatus status;

  /**
   * Représentation en chaine de caractères de {@link TicketStatus}.
   */
  @JsonbProperty(JSON_STATUS_AS_STRING)
  private String statusAsString;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idHistoriqueTicket";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "historiqueTicketChaine";

  /**
   * Identifiant champ java {@link #supportLevelIdentifier}.
   */
  public static final String JSON_SUPPORT_LEVEL_IDENTIFIER =
      SupportLevelDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportLevelAsString}.
   */
  public static final String JSON_SUPPORT_LEVEL_AS_STRING =
      SupportLevelDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #functionalDomainIdentifier}.
   */
  public static final String JSON_FUNCTIONAL_DOMAIN_IDENTIFIER =
      FunctionalDomainDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #functionalDomainAsString}.
   */
  public static final String JSON_FUNCTIONAL_DOMAIN_AS_STRING =
      FunctionalDomainDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #supportTeamIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_IDENTIFIER =
      SupportTeamDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_AS_STRING =
      SupportTeamDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #supportTeamMemberIdentifier}.
   */
  public static final String JSON_SUPPORT_TEAM_MEMBER_IDENTIFIER =
      SupportTeamMemberDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #supportTeamMemberAsString}.
   */
  public static final String JSON_SUPPORT_TEAM_MEMBER_AS_STRING =
      SupportTeamMemberDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant champ java {@link #ticketIdentifier}.
   */
  public static final String JSON_TICKET_IDENTIFIER =
      TicketDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant champ java {@link #ticketAsString}.
   */
  public static final String JSON_TICKET_AS_STRING =
      TicketDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = "statut";

  /**
   * Identifiant json champ {@link #statusAsString}.
   */
  public static final String JSON_STATUS_AS_STRING = "statutChaine";

  /**
   * Identifiant champ java {@link #comment}.
   */
  public static final String JSON_COMMENT = "commentaire";

  /**
   * Identifiant champ java {@link #date}.
   */
  public static final String JSON_DATE = "date";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "historique ticket";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "historiques ticket";

}

