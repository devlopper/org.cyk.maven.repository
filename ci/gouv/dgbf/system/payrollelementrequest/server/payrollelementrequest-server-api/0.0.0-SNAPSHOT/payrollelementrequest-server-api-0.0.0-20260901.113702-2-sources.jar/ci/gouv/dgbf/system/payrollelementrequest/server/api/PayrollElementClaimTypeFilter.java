package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimTypeDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimTypeFilter extends AbstractIdentifiableFilter {

  /**
   * Identifiant du groupe de type de réclamation.
   */
  String claimTypeGroupIdentifier;

  /**
   * Rôle applicatif du module {@code user} déterminant qui peut traiter les réclamations.
   */
  String roleTraitement;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementClaimTypeFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementClaimTypeFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    claimTypeGroupIdentifier = getClaimTypeGroupIdentifier(filter);
    roleTraitement = getRoleTraitement(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setClaimTypeGroupIdentifier(filter, claimTypeGroupIdentifier);
    setRoleTraitement(filter, roleTraitement);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du groupe de type de réclamation.
   *
   * @param filter filtre
   * @param identifier identifiant
   */
  public static void setClaimTypeGroupIdentifier(FilterDto filter, String identifier) {
    set(filter, JSON_CLAIM_TYPE_GROUP_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(identifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du groupe de type de réclamation.
   *
   * @param filter filtre
   * @return identifiant du groupe de type de réclamation
   */
  public static String getClaimTypeGroupIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CLAIM_TYPE_GROUP_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le rôle de traitement.
   *
   * @param filter filtre
   * @param roleTraitement rôle de traitement
   */
  public static void setRoleTraitement(FilterDto filter, String roleTraitement) {
    set(filter, JSON_ROLE_TRAITEMENT, f -> f.getValueAsString(),
        f -> f.setValueAsString(roleTraitement));
  }

  /**
   * Cette méthode permet d'obtenir le rôle de traitement.
   *
   * @param filter filtre
   * @return rôle de traitement
   */
  public static String getRoleTraitement(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ROLE_TRAITEMENT));
  }

  /**
   * Identifiant json champ {@link #claimTypeGroupIdentifier}.
   */
  public static final String JSON_CLAIM_TYPE_GROUP_IDENTIFIER =
      PayrollElementClaimTypeDto.JSON_CLAIM_TYPE_GROUP_IDENTIFIER;

  /**
   * Identifiant json champ {@link #roleTraitement}.
   */
  public static final String JSON_ROLE_TRAITEMENT =
      PayrollElementClaimTypeDto.JSON_ROLE_TRAITEMENT;
}
