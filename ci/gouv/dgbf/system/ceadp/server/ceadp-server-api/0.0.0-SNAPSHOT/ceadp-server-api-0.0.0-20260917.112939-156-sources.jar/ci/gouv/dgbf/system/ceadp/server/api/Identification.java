package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.core.Constant;
import ci.gouv.dgbf.extension.core.Core;

/**
 * Cette interface représente une identification.
 *
 * @author Christian
 *
 */
public interface Identification {

  /**
   * Cette méthode permet d'obtenir le matricule.
   *
   * @return matricule
   */
  String getRegistrationNumber();
  
  /**
   * Cette méthode permet d'obtenir l'adresse email.
   *
   * @return adresse email
   */
  String getEmailAddress();
  
  /**
   * Cette méthode permet d'obtenir le nom et prénoms.
   *
   * @return nom et prénoms
   */
  String getFirstNameAndLastNames();
  
  /**
   * Cette méthode permet de formatter la réprésentation en chaine de caractères.
   *
   * @param registrationNumber matricule
   * @param emailAddress adresse email
   * @param firstName nom
   * @param lastNames prénoms
   * @return réprésentation en chaine de caractères
   */
  static String formatAsString(String registrationNumber, String emailAddress,
      String firstName, String lastNames) {
    registrationNumber = Core.getOrDefaultIfBlank(registrationNumber, null);
    emailAddress = Core.getOrDefaultIfBlank(emailAddress, null);
    firstName = Core.getOrDefaultIfBlank(firstName, null);
    lastNames = Core.getOrDefaultIfBlank(lastNames, null);
    String identifier = Core.getOrDefaultIfNull(registrationNumber, emailAddress);
    if (Core.isAllNull(identifier, firstName, lastNames)) {
      return Constant.EMPTY_STRING;
    }
    return String.format("%s - %s %s", identifier, firstName, lastNames);
  }
  
  /**
   * Identifiant java {@link #getRegistrationNumber()}.
   */
  String FIELD_REGISTRATION_NUMBER = "registrationNumber";
  
  /**
   * Identifiant java {@link #getEmailAddress()}.
   */
  String FIELD_EMAIL_ADDRESS = "emailAddress";
  
  /**
   * Identifiant java {@link #getFirstNameAndLastNames()}.
   */
  String FIELD_FIRST_NAME_AND_LAST_NAMES = "firstNameAndLastNames";
}
