package ci.gouv.dgbf.system.sharing.client.extension;

import ci.gouv.dgbf.extension.primefaces.AbstractFilterController;
import ci.gouv.dgbf.system.sharing.server.api.ResourceTypeConfidentialityFilter;
import jakarta.enterprise.context.Dependent;

/** Controleur de filtre de la confidentialite par type. */
@Dependent
public class ResourceTypeConfidentialityFilterController
    extends AbstractFilterController<ResourceTypeConfidentialityFilter> {
  /** Construit le controleur. */
  public ResourceTypeConfidentialityFilterController() {
    super(ResourceTypeConfidentialityFilter.class);
  }

  @Override
  protected void postConstruct() {
    super.postConstruct();
  }
}
