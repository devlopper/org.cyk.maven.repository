package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à valider pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToValidateN2Dto extends HasTotalAmountToValidateN2 {

  /**
   * Identifiant json du montant total à valider pour l'année N+2.
   */
  String JSON_TOTAL_AMOUNT_TO_VALIDATE_N2 = "montantTotalAValiderN2";
}
