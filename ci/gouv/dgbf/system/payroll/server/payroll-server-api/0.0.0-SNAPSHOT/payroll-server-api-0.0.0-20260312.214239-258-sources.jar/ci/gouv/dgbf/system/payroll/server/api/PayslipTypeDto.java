package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasIsSecondaryAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasIsSecondaryDto;
import ci.gouv.dgbf.extension.core.segregation.HasOrderNumberDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un type de {@link PayslipDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayslipTypeDto extends AbstractIdentifiableCodableNamableAuditableDto
    implements HasIsSecondaryDto, HasIsSecondaryAsStringDto, HasOrderNumberDto {

  @JsonbProperty(JSON_IS_SECONDARY)
  private Boolean isSecondary;

  @JsonbProperty(JSON_IS_SECONDARY_AS_STRING)
  private String isSecondaryAsString;

  @JsonbProperty(JSON_ORDER_NUMBER)
  private Integer orderNumber;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idTypeBulletinPaie";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "typeBulletinPaieChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "type de bulletin de paie";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "types de bulletin de paie";
}
