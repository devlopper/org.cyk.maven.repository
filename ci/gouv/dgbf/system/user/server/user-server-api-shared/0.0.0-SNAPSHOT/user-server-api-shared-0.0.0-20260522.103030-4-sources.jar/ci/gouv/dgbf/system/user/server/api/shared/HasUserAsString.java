package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * d'utilisateur.
 *
 * @author Christian
 */
public interface HasUserAsString extends HasField {

  /**
   * Cette méthode permet d'obtenir la représentation en chaine de caractères de l'utilisateur.
   *
   * @return identifiant de l'utilisateur
   */
  String getUserAsString();

  /**
   * Cette méthode permet d'assigner la représentation en chaine de caractères de l'utilisateur.
   *
   * @param userAsString identifiant de l'utilisateur
   */
  void setUserAsString(String userAsString);

  /**
   * Identifiant java de représentation en chaine de caractères de l'utilisateur.
   */
  String FIELD_USER_AS_STRING = "userAsString";
}
