package ci.gouv.dgbf.system.mailer.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetStringExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutCreateRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutGetBodyPreviewRequestDto;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutGetManyResponseDto;
import ci.gouv.dgbf.system.mailer.server.api.MailLayoutService.MailLayoutUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link MailLayoutDto}.
 *
 * @author Christian
 */
@ApplicationScoped
public class MailLayoutClient extends AbstractClient<MailLayoutService>
    implements GetByIdentifier<MailLayoutDto>, GetMany<MailLayoutGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  /**
   * Cette méthode permet d'obtenir le service.
   *
   * @param service {@link MailLayoutService}
   * @return client {@link MailLayoutClient}
   */
  @Override
  public MailLayoutClient service(MailLayoutService service) {
    return (MailLayoutClient) super.service(service);
  }

  /**
   * {@link MailLayoutService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(MailLayoutCreateRequestDto request) {
    return new CreateExecutor(MailLayoutService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link MailLayoutService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public MailLayoutGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<MailLayoutGetManyResponseDto>(MailLayoutGetManyResponseDto.class,
        MailLayoutService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link MailLayoutService#getMany}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param page {@link PageDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public MailLayoutGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link MailLayoutService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public MailLayoutDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<MailLayoutDto>(MailLayoutDto.class,
        MailLayoutService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link MailLayoutService#getOne}.
   *
   * @param projection {@link ProjectionDto}
   * @param filter {@link FilterDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public MailLayoutDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link MailLayoutService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public MailLayoutDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<MailLayoutDto>(MailLayoutDto.class,
        MailLayoutService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link MailLayoutService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection {@link ProjectionDto}
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public MailLayoutDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return new GetOneExecutor<MailLayoutDto>(MailLayoutDto.class,
        MailLayoutService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link MailLayoutService#getBodyPreview}.
   *
   * @param request requête
   * @return réponse
   */
  public String getBodyPreview(MailLayoutGetBodyPreviewRequestDto request) {
    return new GetStringExecutor(MailLayoutService.GET_BODY_PREVIEW_IDENTIFIER)
        .execute(() -> service().getBodyPreview(request));
  }

  /**
   * {@link MailLayoutService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(MailLayoutUpdateRequestDto request) {
    return new IdentifiableExecutor(MailLayoutService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link MailLayoutService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(MailLayoutService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
