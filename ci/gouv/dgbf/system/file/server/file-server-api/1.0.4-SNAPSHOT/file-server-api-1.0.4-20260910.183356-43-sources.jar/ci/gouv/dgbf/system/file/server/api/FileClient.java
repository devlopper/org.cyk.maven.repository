package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetStringExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.file.server.api.FileService.AbstractOwnerRequestJsonDto;
import ci.gouv.dgbf.system.file.server.api.FileService.AbstractOwnerRequestMultipartDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileConfirmRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileConfirmResponseDto;
import ci.gouv.dgbf.system.file.server.api.FileService.FileCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.GetBytesRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.GetIdentifierByBytesRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileService.GetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import java.util.Collections;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client du service FileService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class FileClient extends AbstractClient<FileService>
    implements GetMany<GetManyResponseDto>, DeleteByIdentifier<IdentifiableResponseDto> {

  @Inject
  OwnerClient ownerClient;

  String moduleIdentifier;

  String moduleIdentifierConfigurationPropertyName() {
    return buildConfigurationPropertyName("caller.module.identifier");
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du module déclaré côté appelant (transitoire,
   * coexiste avec {@link OwnerClient#ownerIdentifier()} ; cf. file-conception-spec-kit
   * TCH_FILE_550).
   *
   * @return identifiant du module
   */
  String moduleIdentifier() {
    if (moduleIdentifier == null) {
      moduleIdentifier = configurationHelper().getValue(String.class,
          moduleIdentifierConfigurationPropertyName(), null);
    }
    return moduleIdentifier;
  }

  @Override
  public FileClient service(FileService service) {
    return (FileClient) super.service(service);
  }

  /**
   * {@link FileService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(FileCreateRequestDto request) {
    setOwnerIdentifier(request);
    setModuleIdentifier(request);
    return new CreateExecutor(FileService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  void setModuleIdentifier(FileCreateRequestDto request) {
    if (request == null) {
      return;
    }
    if (Boolean.TRUE.equals(stringHelper().isBlank(request.getModuleIdentifier()))) {
      request.setModuleIdentifier(moduleIdentifier());
    }
  }

  void setOwnerIdentifier(AbstractOwnerRequestMultipartDto request) {
    if (request == null) {
      return;
    }
    if (Boolean.TRUE.equals(stringHelper().isBlank(request.getOwnerIdentifier()))) {
      request.setOwnerIdentifier(ownerClient.ownerIdentifier());
    }
  }

  void setOwnerIdentifier(AbstractOwnerRequestJsonDto request) {
    if (request == null) {
      return;
    }
    if (Boolean.TRUE.equals(stringHelper().isBlank(request.getOwnerIdentifier()))) {
      request.setOwnerIdentifier(ownerClient.ownerIdentifier());
    }
  }

  /**
   * {@link FileService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        FileService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link FileService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant à partir des octets d'un fichier.
   *
   * @param request requête
   * @return l'identifiant
   */
  public String getIdentifierByBytes(GetIdentifierByBytesRequestDto request) {
    setOwnerIdentifier(request);
    return new GetStringExecutor(FileService.GET_IDENTIFIER_BY_BYTES_IDENTIFIER)
        .execute(() -> service().getIdentifierByBytes(request));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant à partir des octets d'un fichier.
   *
   * @param bytes octets
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return identifiant
   */
  public String getIdentifierByBytes(byte[] bytes, String auditWho, String auditSession) {
    GetIdentifierByBytesRequestDto request = new GetIdentifierByBytesRequestDto();
    request.setBytes(bytes);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getIdentifierByBytes(request);
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant par octets ou après création.
   *
   * @param name nom
   * @param bytes octets
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return identifiant
   */
  public String getIdentifierByBytesOrByCreate(String name, byte[] bytes, String auditWho,
      String auditSession) {
    String identifier = getIdentifierByBytes(bytes, auditWho, auditSession);
    if (stringHelper().isBlank(identifier)) {
      FileCreateRequestDto request = new FileCreateRequestDto();
      request.setName(name);
      request.setBytes(bytes);
      request.setAuditWho(auditWho);
      request.setAuditSession(auditSession);
      CreateResponseDto response = create(request);
      return response.getIdentifier();
    }
    return identifier;
  }

  /**
   * Cette méthode permet d'obtenir les octets à partir d'un identifiant.
   *
   * @param request requête
   * @return tableau d'octets
   */
  public byte[] getBytes(GetBytesRequestDto request) {
    setOwnerIdentifier(request);
    return new GetOneExecutor<byte[]>(byte[].class, FileService.GET_BYTES_IDENTIFIER)
        .execute(() -> service().getBytes(request));
  }

  /**
   * Cette méthode permet d'obtenir les octets à partir d'un identifiant.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return tableau d'octets
   */
  public byte[] getBytes(String identifier, String auditWho, String auditSession) {
    return getBytes(identifier, null, auditWho, auditSession);
  }

  /**
   * Cette méthode permet d'obtenir les octets à partir d'un identifiant.
   *
   * @param identifier identifiant
   * @param ownerIdentifier identifiant propriétaire
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return tableau d'octets
   */
  public byte[] getBytes(String identifier, String ownerIdentifier, String auditWho,
      String auditSession) {
    GetBytesRequestDto request = new GetBytesRequestDto();
    request.setIdentifier(identifier);
    request.setOwnerIdentifier(ownerIdentifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getBytes(request);
  }

  /**
   * Cette méthode permet d'obtenir les octets à partir d'un identifiant.
   *
   * @param request requête
   * @return tableau d'octets
   */
  public byte[] getBytesByIdentifier(ByIdentifierRequestDto request) {
    return new GetOneExecutor<byte[]>(byte[].class, FileService.GET_BYTES_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getBytesByIdentifier(request));
  }
  
  /**
   * {@link FileService#getByIdentifier}.
   *
   * @param request requête
   * @return réponse
   */
  public FileDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<FileDto>(FileDto.class, FileService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * Cette méthode permet d'obtenir un fichier.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return {@link FileDto}
   */
  public FileDto getByIdentifier(String identifier, ProjectionDto projection, String auditWho,
      String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * Cette méthode permet d'obtenir les identifiants de fichiers par identifiant de groupe.
   *
   * @param identifier identifiant de groupe
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return identifiants de fichiers
   */
  public Set<String> getIdentifiersByGroupIdentifier(String identifier, String auditWho,
      String auditSession) {
    GetManyResponseDto response =
        getMany(new ProjectionDto().addNames(AbstractIdentifiableDto.JSON_IDENTIFIER),
            new FilterDto().addCriteria(FileFilter.JSON_GROUP_IDENTIFIER, identifier), null,
            auditWho, auditSession);

    return Optional.ofNullable(response)
        .map(r -> Optional.ofNullable(r.getDatas()).orElse(Collections.emptyList()).stream()
            .map(d -> d.getIdentifier()).collect(Collectors.toSet()))
        .orElse(Collections.emptySet());
  }

  /**
   * {@link FileService#confirm}.
   *
   * @param request requête
   * @return réponse
   */
  public FileConfirmResponseDto confirm(FileConfirmRequestDto request) {
    return new GetOneExecutor<>(FileConfirmResponseDto.class, FileService.CONFIRM_IDENTIFIER)
        .execute(() -> service().confirm(request));
  }

  /**
   * {@link FileService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(FileService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * Cette méthode permet de supprimer un fichier.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
