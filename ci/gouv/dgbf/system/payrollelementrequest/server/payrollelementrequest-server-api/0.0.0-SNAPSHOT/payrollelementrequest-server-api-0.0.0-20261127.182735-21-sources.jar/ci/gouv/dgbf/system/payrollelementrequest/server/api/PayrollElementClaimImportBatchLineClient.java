package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchLineService.PayrollElementClaimImportBatchLineGetManyResponseDto;
import ci.gouv.dgbf.system.payrollelementrequest.server.api.PayrollElementClaimImportBatchLineService.PayrollElementClaimImportBatchLineSummaryResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente le client de {@link PayrollElementClaimImportBatchLineService}.
 *
 * @author akm
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class PayrollElementClaimImportBatchLineClient
    extends AbstractClient<PayrollElementClaimImportBatchLineService>
    implements GetMany<PayrollElementClaimImportBatchLineGetManyResponseDto> {

  @Override
  public PayrollElementClaimImportBatchLineClient service(
      PayrollElementClaimImportBatchLineService service) {
    return (PayrollElementClaimImportBatchLineClient) super.service(service);
  }

  /**
   * {@link PayrollElementClaimImportBatchLineService#getCount}.
   *
   * @param request requête
   * @return nombre
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(PayrollElementClaimImportBatchLineService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchLineService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public PayrollElementClaimImportBatchLineGetManyResponseDto getMany(
      GetManyRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchLineGetManyResponseDto>(
        PayrollElementClaimImportBatchLineGetManyResponseDto.class,
        PayrollElementClaimImportBatchLineService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link PayrollElementClaimImportBatchLineService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public PayrollElementClaimImportBatchLineGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link PayrollElementClaimImportBatchLineService#summary}.
   *
   * @param request requête portant l'identifiant du Lot
   * @return réponse
   */
  public PayrollElementClaimImportBatchLineSummaryResponseDto summary(
      GetByIdentifierRequestDto request) {
    return new GetOneExecutor<PayrollElementClaimImportBatchLineSummaryResponseDto>(
        PayrollElementClaimImportBatchLineSummaryResponseDto.class,
        PayrollElementClaimImportBatchLineService.SUMMARY_IDENTIFIER)
            .execute(() -> service().summary(request));
  }
}
