package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de est par défaut.
 *
 * @author Christian
 */
public interface HasIsNationalPublicInstitutionDto extends HasIsNationalPublicInstitution {

  /**
   * Identifiant json de est EPN.
   */
  String JSON_IS_NATIONAL_PUBLIC_INSTITUTION = "estEpn";
}
