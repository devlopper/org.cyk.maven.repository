package ci.gouv.dgbf.system.ticket.server.api.shared;

/**
 * Cette interface représente un classe avec une notion de représentation en chaine de caractères
 * d'équipe support.
 *
 * @author Arnaud
 */
public interface HasSupportTeamAsStringDto extends HasSupportTeamAsString {

  /**
   * Identifiant json de la représentation en chaine de caractères de l'équipe support.
   */
  String JSON_SUPPORT_TEAM_AS_STRING = "equipeSupportChaine";
}
