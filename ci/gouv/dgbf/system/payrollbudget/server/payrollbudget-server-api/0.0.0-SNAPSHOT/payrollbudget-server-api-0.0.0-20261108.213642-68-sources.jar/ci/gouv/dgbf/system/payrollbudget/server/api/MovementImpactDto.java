package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Ce qu'un mouvement de carrière coûte, poste de paie par poste de paie.
 *
 * <p>C'est le grain que les classeurs de l'EPN tiennent pour chaque agent : un montant avant, un
 * montant après, et l'écart qui les sépare. Puis cet écart se partage en deux, et ce partage est
 * tout le sujet : le <strong>rappel</strong>, dû au titre des exercices déjà clos, et
 * l'<strong>encours</strong>, que l'exercice à venir portera.</p>
 *
 * <p>Les confondre fausse l'arbitrage dans les deux sens. Sur l'INP-HB, le rappel du glissement
 * catégoriel pèse deux fois son encours : qui ne retient que le total budgète le double de ce que
 * l'année coûtera vraiment, et qui ne retient que l'encours oublie une dette.</p>
 *
 * <p><strong>L'écart est la somme des deux, et la base l'impose.</strong> La table porte une
 * contrainte, {@code CK_IMPACT_IDENTITE}, qui refuse toute ligne où {@code ECART} ne vaudrait pas
 * {@code MONTANT_RAPPEL + MONTANT_ENCOURS}. L'écart n'est donc pas une différence de niveau entre
 * deux exercices : c'est l'effet total de la mesure, arriérés compris.</p>
 *
 * @author Christian
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class MovementImpactDto extends AbstractIdentifiableDto {

  /**
   * Mouvement de carrière dont cet impact découle.
   */
  @JsonbProperty(JSON_MOVEMENT_IDENTIFIER)
  private String movementIdentifier;

  /**
   * Poste de paie touché.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_IDENTIFIER)
  private String payrollComponentIdentifier;

  /**
   * Libellé du poste de paie touché.
   */
  @JsonbProperty(JSON_PAYROLL_COMPONENT_AS_STRING)
  private String payrollComponentAsString;

  /**
   * Nature économique sur laquelle la dépense s'impute.
   */
  @JsonbProperty(JSON_ECONOMIC_NATURE_IDENTIFIER)
  private String economicNatureIdentifier;

  /**
   * Mode de calcul retenu : indiciaire, forfaitaire, prorata de sortie, transfert.
   */
  @JsonbProperty(JSON_CALCULATION_MODE)
  private String calculationMode;

  /**
   * Ce que le poste coûtait avant la mesure.
   */
  @JsonbProperty(JSON_AMOUNT_BEFORE)
  private Long amountBefore;

  /**
   * Ce qu'il coûtera après.
   */
  @JsonbProperty(JSON_AMOUNT_AFTER)
  private Long amountAfter;

  /**
   * L'effet total de la mesure, arriérés compris.
   */
  @JsonbProperty(JSON_VARIANCE)
  private Long variance;

  /**
   * Ce qui reste dû au titre des exercices antérieurs.
   */
  @JsonbProperty(JSON_ARREARS_AMOUNT)
  private Long arrearsAmount;

  /**
   * Ce que l'exercice à venir porte.
   */
  @JsonbProperty(JSON_CURRENT_AMOUNT)
  private Long currentAmount;

  /**
   * Nombre de mois de l'exercice que l'encours couvre.
   */
  @JsonbProperty(JSON_PRORATED_MONTH_COUNT)
  private Integer proratedMonthCount;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idImpactMouvement";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "impactMouvementChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "impact d'un mouvement";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "impacts des mouvements";

  /**
   * Identifiant json pour {@link #movementIdentifier}.
   */
  public static final String JSON_MOVEMENT_IDENTIFIER = MovementDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #payrollComponentIdentifier}.
   */
  public static final String JSON_PAYROLL_COMPONENT_IDENTIFIER =
      PayrollComponentDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json pour {@link #payrollComponentAsString}.
   */
  public static final String JSON_PAYROLL_COMPONENT_AS_STRING =
      PayrollComponentDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json pour {@link #economicNatureIdentifier}.
   */
  public static final String JSON_ECONOMIC_NATURE_IDENTIFIER =
      PayrollComponentDto.JSON_ECONOMIC_NATURE_IDENTIFIER;

  /**
   * Identifiant json pour {@link #calculationMode}.
   */
  public static final String JSON_CALCULATION_MODE = "modeCalcul";

  /**
   * Identifiant json pour {@link #amountBefore}.
   */
  public static final String JSON_AMOUNT_BEFORE = "montantAvant";

  /**
   * Identifiant json pour {@link #amountAfter}.
   */
  public static final String JSON_AMOUNT_AFTER = "montantApres";

  /**
   * Identifiant json pour {@link #variance}.
   */
  public static final String JSON_VARIANCE = "ecart";

  /**
   * Identifiant json pour {@link #arrearsAmount}.
   */
  public static final String JSON_ARREARS_AMOUNT = "montantRappel";

  /**
   * Identifiant json pour {@link #currentAmount}.
   */
  public static final String JSON_CURRENT_AMOUNT = "montantEncours";

  /**
   * Identifiant json pour {@link #proratedMonthCount}.
   */
  public static final String JSON_PRORATED_MONTH_COUNT = "nombreMoisProrata";
}
