package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion de représentation en chaine de caractères
 * de groupe d'utilisateur.
 *
 * @author Christian
 */
public interface HasUsersGroupAsStringDto extends HasUsersGroupAsString {

  /**
   * Identifiant json de représentation en chaine de caractères du groupe d'utilisateurs.
   */
  String JSON_USERS_GROUP_AS_STRING = "groupeUtilisateursChaine";
}
