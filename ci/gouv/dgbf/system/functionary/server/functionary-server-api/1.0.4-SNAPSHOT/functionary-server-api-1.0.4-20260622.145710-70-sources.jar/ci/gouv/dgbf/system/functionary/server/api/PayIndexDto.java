package ci.gouv.dgbf.system.functionary.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un indice.
 *
 * @author A.K.M
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class PayIndexDto extends AbstractIdentifiableAuditableDto {
  
  @JsonbProperty(JSON_PAY_SCALE_IDENTIFIER)
  private String payScaleIdentifier;

  @JsonbProperty(JSON_PAY_SCALE_AS_STRING)
  private String payScaleAsString;

  @JsonbProperty(JSON_GRADE_IDENTIFIER)
  private String gradeIdentifier;

  @JsonbProperty(JSON_GRADE_AS_STRING)
  private String gradeAsString;

  @JsonbProperty(JSON_GRADE_CLASS_IDENTIFIER)
  private String gradeClassIdentifier;

  @JsonbProperty(JSON_GRADE_CLASS_AS_STRING)
  private String gradeClassAsString;


  @JsonbProperty(JSON_ECHELON_IDENTIFIER)
  private String echelonIdentifier;

  @JsonbProperty(JSON_ECHELON_AS_STRING)
  private String echelonAsString;

  /**
   * Valeur.
   */
  @JsonbProperty(value = JSON_VALUE)
  private Integer value;

  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idIndice";
  
  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "indiceChaine";

  /**
   * Identifiant json {@link #value}.
   */
  public static final String JSON_VALUE = "valeur";

  /**
   * Identifiant json de {@link #payScaleIdentifier}.
   */
  public static final String JSON_PAY_SCALE_IDENTIFIER =
      PayScaleDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #payScaleAsString}.
   */
  public static final String JSON_PAY_SCALE_AS_STRING =
      PayScaleDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #gradeIdentifier}.
   */
  public static final String JSON_GRADE_IDENTIFIER =
      GradeDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #gradeAsString}.
   */
  public static final String JSON_GRADE_AS_STRING =
      GradeDto.JSON_THIS_AS_STRING;

  /**
   * Identifiant json de {@link #gradeClassIdentifier}.
   */
  public static final String JSON_GRADE_CLASS_IDENTIFIER =
      GradeClassDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #gradeClassAsString}.
   */
  public static final String JSON_GRADE_CLASS_AS_STRING =
      GradeClassDto.JSON_THIS_AS_STRING;
  
  /**
   * Identifiant json de {@link #echelonIdentifier}.
   */
  public static final String JSON_ECHELON_IDENTIFIER =
      EchelonDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json de {@link #echelonAsString}.
   */
  public static final String JSON_ECHELON_AS_STRING =
      EchelonDto.JSON_THIS_AS_STRING;
  
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "indice";
  
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";
}
