package ci.gouv.dgbf.system.functionary.client.extension;

import ci.gouv.dgbf.extension.primefaces.component.input.AbstractSelectOneIdentifiableController;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryClient;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryDto;
import ci.gouv.dgbf.system.functionary.server.api.FunctionaryService.FunctionaryGetManyResponseDto;
import jakarta.enterprise.context.Dependent;
import jakarta.inject.Inject;
import lombok.Getter;

/**
 * Cette classe représente le contrôleur de sélection de {@link FunctionaryDto}.
 *
 * @author Christian
 *
 */
@Dependent
public class FunctionarySelectOneController extends AbstractSelectOneIdentifiableController<
    FunctionaryDto, FunctionaryGetManyResponseDto, FunctionaryClient> {

  @Inject
  @Getter
  FunctionaryClient client;

  /**
   * Cette methode permet de construire.
   */
  protected FunctionarySelectOneController() {
    super(FunctionaryDto.class, SelectItemLabelStrategy.AS_STRING);
  }
}
