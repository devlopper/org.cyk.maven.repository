package ci.gouv.dgbf.system.user.server.api.shared;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'application.
 *
 * @author BoobaCool
 */
public interface HasApplicationIdentifierDto extends HasApplicationIdentifier {

  /**
   * Identifiant json de l'identifiant de l'application.
   */
  String JSON_APPLICATION_IDENTIFIER = "idApplication";
}
