package ci.gouv.dgbf.system.user.server.api.shared;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'identifiant d'utilisateur groupe.
 *
 * @author Christian
 */
public interface HasUserGroupIdentifier extends HasField {

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'utilisateur groupe.
   *
   * @return identifiant de l'utilisateur groupe
   */
  String getUserGroupIdentifier();

  /**
   * Cette méthode permet d'assigner l'identifiant de l'utilisateur groupe.
   *
   * @param userGroupIdentifier identifiant de l'utilisateur groupe
   */
  void setUserGroupIdentifier(String userGroupIdentifier);

  /**
   * Identifiant java de l'identifiant de l'utilisateur groupe.
   */
  String FIELD_USER_GROUP_IDENTIFIER = "userGroupIdentifier";
}
