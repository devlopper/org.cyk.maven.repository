package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PolicyDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class PolicyFilter extends AbstractIdentifiableFilter implements FilterHasCode {

  /**
   * Code.
   */
  String code;

  /**
   * Identifiant du type de politique.
   */
  String typeIdentifier;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateCode(filter);
    typeIdentifier = getTypeIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterCode(filter);
    setTypeIdentifier(filter, typeIdentifier);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du type de politique.
   *
   * @param filter filtre
   * @param typeIdentifier identifiant du type de politique
   */
  public static void setTypeIdentifier(FilterDto filter,
      String typeIdentifier) {
    set(filter, JSON_TYPE_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(typeIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du type de politique.
   *
   * @param filter filtre
   * @return identifiant du type de politique
   */
  public static String getTypeIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_TYPE_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #typeIdentifier}.
   */
  public static final String JSON_TYPE_IDENTIFIER =
      PolicyDto.JSON_TYPE_IDENTIFIER;
}
