package ci.gouv.dgbf.extension.primefaces.component.input;

import jakarta.faces.model.SelectItem;
import java.util.List;

/**
 * Cette classe représente un contrôleur d'un sélecteur d'une énumération.
 *
 * @author Christian
 *
 */
public abstract class AbstractSelectOneEnumerationController<T extends Enum<T>>
    extends AbstractSelectOneController {

  List<T> values;

  protected AbstractSelectOneEnumerationController(T[] values) {
    this.values = List.of(values);
  }

  /*  */

  @Override
  protected List<SelectItem> computeSelectItemsWhenChoicable() {
    return values.stream().map(value -> new SelectItem(value.name(), computeSelectItemLabel(value)))
        .toList();
  }

  protected String computeSelectItemLabel(T value) {
    return value.toString();
  }
}
