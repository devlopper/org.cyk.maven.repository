package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.core.Core;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;
import lombok.Getter;

/**
 * Cette classe représente les statuts de {@link PayrollDto}.
 *
 * @author A.K.M
 *
 */
@Getter
public enum PayrollStatus {

  /**
   * Créée.
   */
  CREATED(PayrollStatusCode.CREATED, "Créée", "Création"),
  
  /**
   * Initialisée.
   */
  INITIALIZED(PayrollStatusCode.INITIALIZED, "Initialisée", "Initialisation"),
  
  /**
   * Transmis pour contrôle.
   */
  TRANSMITTED_FOR_CONTROL(PayrollStatusCode.TRANSMITTED_FOR_CONTROL, 
  "Transmis pour contrôle", "Transmission pour contrôle"),
  
  /**
   * Controlée.
   */
  CONTROLLED(PayrollStatusCode.CONTROLLED, "Controlée", "Contrôle"),
  
  /**
   * Transmis pour arbitrage.
   */
  TRANSMITTED_FOR_ARBITRATION(PayrollStatusCode.TRANSMITTED_FOR_ARBITRATION, 
  "Transmis pour arbitrage", "Transmission pour arbitrage"),
  
  /**
   * Arbitrée.
   */
  ARBITRATED(PayrollStatusCode.ARBITRATED, "Arbitrée", "Arbitrage"),
  
  /**
   * Clôturée.
   */
  CLOSED(PayrollStatusCode.CLOSED, "Clôturée", "Clôture")

  ;

  private PayrollStatus(String code, String name, String action) {
    this.code = code;
    this.name = name;
    this.action = action;
  }

  private String code;
  private String name;
  private String action;
  private Set<PayrollStatus> previous;

  @Override
  public String toString() {
    return name;
  }

  /**
   * Cette méthode permet d'obtenir le statut par code.
   *
   * @param code code
   * @return statut
   */
  public static PayrollStatus getByCode(String code) {
    return Stream.of(PayrollStatus.values())
        .filter(status -> status.getCode().equals(code)).findFirst()
        .orElseThrow(() -> new IllegalArgumentException("Code <<%s>> inconnu".formatted(code)));
  }

  static {
    CREATED.previous = Collections.emptySet();
    INITIALIZED.previous = Core.getSet(List.of(CREATED));
    TRANSMITTED_FOR_CONTROL.previous = Core.getSet(List.of(INITIALIZED));
    CONTROLLED.previous = Core.getSet(List.of(TRANSMITTED_FOR_CONTROL));
    TRANSMITTED_FOR_ARBITRATION.previous = Core.getSet(List.of(CONTROLLED));
    ARBITRATED.previous = Core.getSet(List.of(TRANSMITTED_FOR_ARBITRATION));
    CLOSED.previous = Core.getSet(List.of(ARBITRATED));
  }
}
