package ci.gouv.dgbf.system.logging.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasField;

/**
 * Cette interface représente une classe avec une notion d'éligibilité au traitement.
 */
public interface HasTreatable extends HasField {

  /**
   * Cette méthode permet d'obtenir si l'entité peut être traitée.
   *
   * @return vrai si traitable
   */
  Boolean getTreatable();

  /**
   * Cette méthode permet d'assigner si l'entité peut être traitée.
   *
   * @param treatable vrai si traitable
   */
  void setTreatable(Boolean treatable);

  /**
   * Identifiant java du champ.
   */
  String FIELD_TREATABLE = "treatable";
}

