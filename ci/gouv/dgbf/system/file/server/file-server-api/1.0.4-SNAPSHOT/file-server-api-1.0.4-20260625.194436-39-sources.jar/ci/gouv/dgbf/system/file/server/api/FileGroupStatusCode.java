package ci.gouv.dgbf.system.file.server.api;

/**
 * Cette classe représente les codes de {@link FileGroupStatus}.
 *
 * @author Christian
 *
 */
public class FileGroupStatusCode {

  private FileGroupStatusCode() {

  }

  /**
   * Créé.
   */
  public static final String CREATED = "CREE";

  /**
   * Confirmé.
   */
  public static final String CONFIRMED = "CONFIRME";
}
