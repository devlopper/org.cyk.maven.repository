package ci.gouv.dgbf.system.functionary.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link GradeDto}.
*
* @author Stéphane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-06-22T14:57:34+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class GradeRequestMapperImpl implements GradeRequestMapper {

    @Override
    public GradeService.GradeCreateRequestDto mapCreate(GradeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GradeService.GradeCreateRequestDto gradeCreateRequestDto = new GradeService.GradeCreateRequestDto();

        gradeCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        gradeCreateRequestDto.setCode( arg0.getCode() );
        gradeCreateRequestDto.setName( arg0.getName() );
        gradeCreateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return gradeCreateRequestDto;
    }

    @Override
    public GradeService.GradeUpdateRequestDto mapUpdate(GradeDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        GradeService.GradeUpdateRequestDto gradeUpdateRequestDto = new GradeService.GradeUpdateRequestDto();

        gradeUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        gradeUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        gradeUpdateRequestDto.setCode( arg0.getCode() );
        gradeUpdateRequestDto.setName( arg0.getName() );
        gradeUpdateRequestDto.setCategoryIdentifier( arg0.getCategoryIdentifier() );

        return gradeUpdateRequestDto;
    }
}
