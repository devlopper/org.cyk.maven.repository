package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un bénéficiaire.
 *
 * @author Desysoft
 */
@Getter
@Setter
public class BeneficiaryDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Type de personne.
   */
  @JsonbProperty(JSON_PERSON_TYPE)
  private PersonType personType;


  /**
   * Type de personne chaine.
   */
  @JsonbProperty(JSON_PERSON_TYPE_AS_STRING)
  private String personTypeAsString;

  /**
   * Relevé d’identité bancaire (RIB).
   */
  @JsonbProperty(JSON_BANK_ACCOUNT_DETAILS)
  private String bankAccountDetails;

  /**
   * Documents justificatifs.
   */
  @JsonbProperty(JSON_SUPPORTING_DOCUMENT)
  private String supportingDocument;


  /**
   * Identifiant de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_IDENTIFIER)
  private String localAuthorityIdentifier;

  /**
   * Représentation en chaine de caractères de {@link LocalAuthorityDto}.
   */
  @JsonbProperty(JSON_LOCAL_AUTHORITY_AS_STRING)
  private String localAuthorityAsString;


  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "bénéficiaire";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = NAME + "s";


  /**
   * Identifiant json {@link #bankAccountDetails}.
   */
  public static final String JSON_BANK_ACCOUNT_DETAILS = "relevéIdentitéBancaire";


  /**
   * Identifiant json {@link #supportingDocument}.
   */
  public static final String JSON_SUPPORTING_DOCUMENT = "documentJustificatif";

  /**
   * Identifiant json {@link #personType}.
   */
  public static final String JSON_PERSON_TYPE = "typeDePersonne";

  /**
   * Identifiant json {@link #personTypeAsString}.
   */
  public static final String JSON_PERSON_TYPE_AS_STRING = "typeDePersonneChaine";


  /**
   * Identifiant json de identifiant de {@link BeneficiaryDto}.
   */
  public static final String JSON_THIS_IDENTIFIER = "idBeneficiaire";

  /**
   * Identifiant json de représentation en chaine de caractères de {@link BeneficiaryDto}.
   */
  public static final String JSON_THIS_AS_STRING = "beneficiaireChaine";

  /**
   * Identifiant json {@link #localAuthorityIdentifier}.
   */
  public static final String JSON_LOCAL_AUTHORITY_IDENTIFIER =
      LocalAuthorityDto.JSON_THIS_IDENTIFIER;

  /**
   * Identifiant json {@link #localAuthorityAsString}.
   */
  public static final String JSON_LOCAL_AUTHORITY_AS_STRING = LocalAuthorityDto.JSON_THIS_AS_STRING;
}
