package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.core.UriBuilder;
import jakarta.faces.context.FacesContext;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Cette classe représente les fonctiosn statiques de traitement de face.
 *
 * @author Christian
 *
 */
public class JsfCore {

  private JsfCore() {}
  
  /**
   * Cette méthode permet de construire une url relative à partir de la requête courante.
   *
   * @return url relative à partir de la requête courante
   */
  public static String buildRelativeUrlFromCurrentRequest() {
    return new UriBuilder().relativeFromRequest(
        (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest())
        .build().toString();
  }
 
}