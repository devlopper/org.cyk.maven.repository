package ci.gouv.dgbf.system.file.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryCreateRequestDto;
import ci.gouv.dgbf.system.file.server.api.FileCategoryService.FileCategoryUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link FileCategoryDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link FileCategoryDto}.

    @author Christian
               """)
public interface FileCategoryRequestMapper extends
    RequestMapper<FileCategoryDto, FileCategoryCreateRequestDto, FileCategoryUpdateRequestDto> {

}
