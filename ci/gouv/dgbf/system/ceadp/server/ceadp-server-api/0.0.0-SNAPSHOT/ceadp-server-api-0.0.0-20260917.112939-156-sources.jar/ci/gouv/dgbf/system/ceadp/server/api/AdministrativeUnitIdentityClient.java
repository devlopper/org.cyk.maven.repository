package ci.gouv.dgbf.system.ceadp.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetLongExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetCountRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.ceadp.server.api.AdministrativeUnitIdentityService.AdministrativeUnitIdentityGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de {@link AdministrativeUnitIdentityService}.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class AdministrativeUnitIdentityClient
    extends AbstractClient<AdministrativeUnitIdentityService>
    implements GetByIdentifier<AdministrativeUnitIdentityDto>,
    GetMany<AdministrativeUnitIdentityGetManyResponseDto> {

  @Override
  public AdministrativeUnitIdentityClient service(AdministrativeUnitIdentityService service) {
    return (AdministrativeUnitIdentityClient) super.service(service);
  }

  /**
   * {@link AdministrativeUnitIdentityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitIdentityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitIdentityGetManyResponseDto>(
        AdministrativeUnitIdentityGetManyResponseDto.class,
        AdministrativeUnitIdentityService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link AdministrativeUnitIdentityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitIdentityGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link AdministrativeUnitIdentityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public AdministrativeUnitIdentityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitIdentityDto>(AdministrativeUnitIdentityDto.class,
        AdministrativeUnitIdentityService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link AdministrativeUnitIdentityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public AdministrativeUnitIdentityDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link AdministrativeUnitIdentityService#getCount}.
   *
   * @param request requête
   * @return réponse
   */
  public Long getCount(GetCountRequestDto request) {
    return new GetLongExecutor(AdministrativeUnitIdentityService.GET_COUNT_IDENTIFIER)
        .execute(() -> service().getCount(request));
  }

  /**
   * {@link AdministrativeUnitIdentityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public AdministrativeUnitIdentityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<AdministrativeUnitIdentityDto>(AdministrativeUnitIdentityDto.class,
        AdministrativeUnitIdentityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link AdministrativeUnitIdentityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public AdministrativeUnitIdentityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
