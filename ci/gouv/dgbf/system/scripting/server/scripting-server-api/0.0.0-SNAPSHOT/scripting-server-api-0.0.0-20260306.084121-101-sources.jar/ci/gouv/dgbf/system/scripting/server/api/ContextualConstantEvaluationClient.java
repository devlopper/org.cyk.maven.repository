package ci.gouv.dgbf.system.scripting.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationCreateContextuallyRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationCreateContextuallyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationCreateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationGetManyResponseDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateRequestDto;
import ci.gouv.dgbf.system.scripting.server.api.ContextualConstantEvaluationService.ContextualConstantEvaluationUpdateValueRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ContextualConstantEvaluationService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ContextualConstantEvaluationClient
    extends AbstractClient<ContextualConstantEvaluationService>
    implements GetByIdentifier<ContextualConstantEvaluationDto>,
    GetMany<ContextualConstantEvaluationGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ContextualConstantEvaluationClient service(ContextualConstantEvaluationService service) {
    return (ContextualConstantEvaluationClient) super.service(service);
  }

  /**
   * {@link ContextualConstantEvaluationService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ContextualConstantEvaluationCreateRequestDto request) {
    return new CreateExecutor(ContextualConstantEvaluationService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#createContextually}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationCreateContextuallyResponseDto createContextually(
      ContextualConstantEvaluationCreateContextuallyRequestDto request) {
    return new GetOneExecutor<>(ContextualConstantEvaluationCreateContextuallyResponseDto.class,
        ContextualConstantEvaluationService.CREATE_CONTEXTUALLY_IDENTIFIER)
            .setExpectedResponseStatusCode(201)
            .execute(() -> service().createContextually(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationGetManyResponseDto>(
        ContextualConstantEvaluationGetManyResponseDto.class,
        ContextualConstantEvaluationService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantEvaluationGetManyResponseDto getMany(ProjectionDto projection,
      FilterDto filter, PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ContextualConstantEvaluationService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ContextualConstantEvaluationDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationDto>(
        ContextualConstantEvaluationDto.class,
        ContextualConstantEvaluationService.GET_ONE_IDENTIFIER)
            .execute(() -> service().getOne(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ContextualConstantEvaluationDto getOne(ProjectionDto projection, FilterDto filter,
      String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ContextualConstantEvaluationService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ContextualConstantEvaluationDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ContextualConstantEvaluationDto>(
        ContextualConstantEvaluationDto.class,
        ContextualConstantEvaluationService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ContextualConstantEvaluationDto getByIdentifier(String identifier,
      ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ContextualConstantEvaluationService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ContextualConstantEvaluationUpdateRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantEvaluationService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#updateValue}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto updateValue(
      ContextualConstantEvaluationUpdateValueRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantEvaluationService.UPDATE_VALUE_IDENTIFIER)
        .execute(() -> service().updateValue(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ContextualConstantEvaluationService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ContextualConstantEvaluationService#delete}.
   *
   * @param identifier identifiant
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
      String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}
