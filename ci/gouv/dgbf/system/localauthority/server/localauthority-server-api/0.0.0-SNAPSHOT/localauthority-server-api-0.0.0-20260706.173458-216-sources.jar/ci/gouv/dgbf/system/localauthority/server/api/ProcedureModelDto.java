package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableCodableNamableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import java.util.Date;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un modèle de  procedure.
 *
 * @author Desysoft
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ProcedureModelDto extends AbstractIdentifiableCodableNamableAuditableDto {

  /**
   * Identifiant json {@link ProcedureModelDto#order}.
   */
  public static final String JSON_ORDER = "order";
  /**
   * Identifiant json {@link ProcedureModelDto#orderAsString}.
   */
  public static final String JSON_ORDER_AS_STRING = "orderChaine";
  /**
   * Identifiant json {@link ProcedureModelDto#date}.
   */
  public static final String JSON_DATE = "date";
  /**
   * Identifiant json {@link ProcedureModelDto#dateAsString}.
   */
  public static final String JSON_DATE_AS_STRING = "dateChaine";
  /**
   * Identifiant json {@link ProcedureModelDto#observation}.
   */
  public static final String JSON_OBSERVATION = "observation";
  /**
   * Identifiant json {@link ProcedureModelDto#observationAsString}.
   */
  public static final String JSON_OBSERVATION_AS_STRING = "observationChaine";
  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "modele de procedure";
  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "modeles de procedure";
  /**
   * Ordre.
   */
  @JsonbProperty(JSON_ORDER)
  private Integer order;
  /**
   * Représentation en chaine de caractères d'ordre.
   */
  @JsonbProperty(JSON_ORDER_AS_STRING)
  private String orderAsString;
  /**
   * Date.
   */
  @JsonbProperty(JSON_DATE)
  private Date date;
  /**
   * Représentation en chaine de caractères de date.
   */
  @JsonbProperty(JSON_DATE_AS_STRING)
  private String dateAsString;
  /**
   * Observation.
   */
  @JsonbProperty(JSON_OBSERVATION)
  private String observation;
  /**
   * Représentation en chaine de caractères d'observation.
   */
  @JsonbProperty(JSON_OBSERVATION_AS_STRING)
  private String observationAsString;
}
