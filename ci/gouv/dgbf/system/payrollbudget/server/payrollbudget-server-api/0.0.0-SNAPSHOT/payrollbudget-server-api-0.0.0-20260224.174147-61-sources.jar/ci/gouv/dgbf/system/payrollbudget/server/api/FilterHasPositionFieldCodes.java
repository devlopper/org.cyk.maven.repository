package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;

/**
 * {@inheritDoc}.
 *
 * @author Christian
 */
public interface FilterHasPositionFieldCodes extends HasPositionFieldCodes {

  /**
   * Cette méthode permet de mettre à jour les codes de {@link PositionField}.
   *
   * @param filter {@link FilterDto}
   */
  default void updatePositionFieldCodes(FilterDto filter) {
    setPositionFieldCodes(PositionFieldCodesFilter.get(filter));
  }

  /**
   * Cette méthode permet de mettre à jour les codes de {@link PositionField} de {@link FilterDto} .
   *
   * @param filter {@link FilterDto}
   */
  default void updateFilterPositionFieldCodes(FilterDto filter) {
    PositionFieldCodesFilter.set(filter, getPositionFieldCodes());
  }

}
