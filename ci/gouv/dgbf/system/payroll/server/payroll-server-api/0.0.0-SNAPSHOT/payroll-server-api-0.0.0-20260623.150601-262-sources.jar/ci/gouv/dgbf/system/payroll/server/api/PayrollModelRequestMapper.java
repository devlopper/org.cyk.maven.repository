package ci.gouv.dgbf.system.payroll.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.payroll.server.api.PayrollModelService.PayrollModelCreateRequestDto;
import ci.gouv.dgbf.system.payroll.server.api.PayrollModelService.PayrollModelUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link PayrollModelDto}.
 *
 * @author akm
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PayrollModelDto}.

    @author akm
               """)
public interface PayrollModelRequestMapper extends RequestMapper<PayrollModelDto,
    PayrollModelCreateRequestDto, PayrollModelUpdateRequestDto> {

}
