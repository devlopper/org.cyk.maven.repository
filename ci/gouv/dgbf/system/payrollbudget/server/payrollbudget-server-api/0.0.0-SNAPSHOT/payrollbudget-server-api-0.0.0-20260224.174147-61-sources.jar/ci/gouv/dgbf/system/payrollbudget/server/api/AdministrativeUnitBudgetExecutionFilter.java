package ci.gouv.dgbf.system.payrollbudget.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.shared.FilterHasBudgetAdministrativeUnitIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link AdministrativeUnitEmployeeCategoryDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class AdministrativeUnitBudgetExecutionFilter extends 
    AbstractIdentifiableFilter implements
    FilterHasBudgetAdministrativeUnitIdentifier {

  private String budgetAdministrativeUnitIdentifier;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public AdministrativeUnitBudgetExecutionFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public AdministrativeUnitBudgetExecutionFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateBudgetAdministrativeUnitIdentifier(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterBudgetAdministrativeUnitIdentifier(filter);
  }
}

