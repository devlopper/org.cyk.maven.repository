package ci.gouv.dgbf.system.report.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link ReportDto}.
*
* @author Desysoft
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-04-28T11:33:54+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class ReportRequestMapperImpl implements ReportRequestMapper {

    @Override
    public ReportService.ReportCreateRequestDto mapCreate(ReportDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportService.ReportCreateRequestDto reportCreateRequestDto = new ReportService.ReportCreateRequestDto();

        reportCreateRequestDto.setCode( arg0.getCode() );
        reportCreateRequestDto.setName( arg0.getName() );
        reportCreateRequestDto.setDescription( arg0.getDescription() );
        reportCreateRequestDto.setTemplateIdentifier( arg0.getTemplateIdentifier() );
        reportCreateRequestDto.setParametersDictionaryIdentifier( arg0.getParametersDictionaryIdentifier() );

        return reportCreateRequestDto;
    }

    @Override
    public ReportService.ReportUpdateRequestDto mapUpdate(ReportDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        ReportService.ReportUpdateRequestDto reportUpdateRequestDto = new ReportService.ReportUpdateRequestDto();

        reportUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        reportUpdateRequestDto.setCode( arg0.getCode() );
        reportUpdateRequestDto.setName( arg0.getName() );
        reportUpdateRequestDto.setDescription( arg0.getDescription() );
        reportUpdateRequestDto.setTemplateIdentifier( arg0.getTemplateIdentifier() );
        reportUpdateRequestDto.setParametersDictionaryIdentifier( arg0.getParametersDictionaryIdentifier() );

        return reportUpdateRequestDto;
    }
}
