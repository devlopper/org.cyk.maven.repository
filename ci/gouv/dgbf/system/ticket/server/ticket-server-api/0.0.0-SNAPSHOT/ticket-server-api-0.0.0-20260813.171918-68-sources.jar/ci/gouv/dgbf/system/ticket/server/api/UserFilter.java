package ci.gouv.dgbf.system.ticket.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableNamableDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link UserDto}.
 *
 * @author Christian
 *
 */
@Getter
@Setter
public class UserFilter extends AbstractIdentifiableFilter {

  /**
   * Nom.
   */
  String name;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public UserFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public UserFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    name = getName(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    setName(filter, name);
  }

  /**
   * Cette méthode permet d'obtenir le nom.
   *
   * @param filter filtre
   * @return nom
   */
  public static String getName(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_NAME));
  }

  /**
   * Cette méthode permet d'assigner le nom.
   *
   * @param filter filtre
   * @param userName nom
   */
  public static void setName(FilterDto filter, String userName) {
    set(filter, JSON_NAME, f -> f.getValueAsString(), f -> f.setValueAsString(userName));
  }

  /**
   * Identifiant json champ {@link #name}.
   */
  public static final String JSON_NAME = AbstractIdentifiableNamableDto.JSON_NAME;
}

