package ci.gouv.dgbf.system.report.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.IdentifiableExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.DeleteOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.report.server.api.ReportsGroupService.ReportsGroupGetManyResponseDto;
import ci.gouv.dgbf.system.report.server.api.ReportsGroupService.ReportsGroupUpdateRequestDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link ReportsGroupService}.
 *
 * @author Desysoft
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class ReportsGroupClient extends AbstractClient<ReportsGroupService>
    implements GetByIdentifier<ReportsGroupDto>, GetMany<ReportsGroupGetManyResponseDto>,
    DeleteByIdentifier<IdentifiableResponseDto> {

  @Override
  public ReportsGroupClient service(ReportsGroupService service) {
    return (ReportsGroupClient) super.service(service);
  }

  /**
   * {@link ReportsGroupService#create}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto create(ReportsGroupService.ReportsGroupCreateRequestDto request) {
    return new CreateExecutor(ReportsGroupService.CREATE_IDENTIFIER)
        .execute(() -> service().create(request));
  }

  /**
   * {@link ReportsGroupService#create}.
   *
   * @param code         code
   * @param name         nom
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public CreateResponseDto create(String code, String name, String auditWho, String auditSession) {
    ReportsGroupService.ReportsGroupCreateRequestDto
        request = new ReportsGroupService.ReportsGroupCreateRequestDto();
    request.setCode(code);
    request.setName(name);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return create(request);
  }

  /**
   * {@link ReportsGroupService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportsGroupGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ReportsGroupGetManyResponseDto>(ReportsGroupGetManyResponseDto.class,
        ReportsGroupService.GET_MANY_IDENTIFIER).execute(() -> service().getMany(request));
  }

  /**
   * {@link ReportsGroupService#getMany}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param page         page
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReportsGroupGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
                                                PageDto page,
                                                String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ReportsGroupService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ReportsGroupDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ReportsGroupDto>(ReportsGroupDto.class,
        ReportsGroupService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ReportsGroupService#getOne}.
   *
   * @param projection   projection
   * @param filter       filtre
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ReportsGroupDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
                                String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ReportsGroupService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ReportsGroupDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ReportsGroupDto>(ReportsGroupDto.class,
        ReportsGroupService.GET_BY_IDENTIFIER_IDENTIFIER)
        .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ReportsGroupService#getByIdentifier}.
   *
   * @param identifier   identifiant
   * @param projection   projection
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ReportsGroupDto getByIdentifier(String identifier, ProjectionDto projection,
                                         String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ReportsGroupService#update}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto update(ReportsGroupService.ReportsGroupUpdateRequestDto request) {
    return new IdentifiableExecutor(ReportsGroupService.UPDATE_IDENTIFIER)
        .execute(() -> service().update(request));
  }

  /**
   * {@link ReportsGroupService#update}.
   *
   * @param identifier   identifiant
   * @param name         nom
   * @param code         code
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public IdentifiableResponseDto update(String identifier, String code, String name,
                                        String auditWho, String auditSession) {
    ReportsGroupService.ReportsGroupUpdateRequestDto request = new ReportsGroupUpdateRequestDto();
    request.setIdentifier(identifier);
    request.setName(name);
    request.setCode(code);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return update(request);
  }

  /**
   * {@link ReportsGroupService#delete}.
   *
   * @param request requête
   * @return réponse
   */
  public IdentifiableResponseDto delete(DeleteOneRequestDto request) {
    return new IdentifiableExecutor(ReportsGroupService.DELETE_IDENTIFIER)
        .execute(() -> service().delete(request));
  }

  /**
   * {@link ReportsGroupService#delete}.
   *
   * @param identifier   identifiant
   * @param auditWho     audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public IdentifiableResponseDto deleteByIdentifier(String identifier, String auditWho,
                                                    String auditSession) {
    DeleteOneRequestDto request = new DeleteOneRequestDto();
    request.setIdentifier(identifier);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return delete(request);
  }
}

