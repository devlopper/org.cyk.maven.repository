package ci.gouv.dgbf.system.budgetaryprogramming.server.api.shared;

/**
 * Cette interface représente la capacité à porter le montant total à intégrer pour l'année N+2.
 *
 * @author Christian
 */
public interface HasTotalAmountToIntegrateN2 {

  /**
   * Obtient le montant total à intégrer pour l'année N+2.
   *
   * @return le montant total à intégrer pour l'année N+2
   */
  Long getTotalAmountToIntegrateN2();

  /**
   * Définit le montant total à intégrer pour l'année N+2.
   *
   * @param totalAmountToIntegrateN2 le montant total à intégrer pour l'année N+2
   */
  void setTotalAmountToIntegrateN2(Long totalAmountToIntegrateN2);

  /**
   * Identifiant java du montant total à intégrer pour l'année N+2.
   */
  String FIELD_TOTAL_AMOUNT_TO_INTEGRATE_N2 = "totalAmountToIntegrateN2";
}