package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasStatusCode;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.system.identity.server.api.shared.FilterHasIdentityIdentifier;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link IdentityPolicyConsentDto}.
 *
 * @author Desysoft
 *
 */
@Getter
@Setter
public class IdentityPolicyConsentFilter extends AbstractIdentifiableFilter
    implements FilterHasIdentityIdentifier, FilterHasStatusCode {

  String identityIdentifier;

  /**
   * Identifiant de la version de politique.
   */
  String policyVersionIdentifier;

  String statusCode;

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateIdentityIdentifier(filter);
    policyVersionIdentifier = getPolicyVersionIdentifier(filter);
    updateStatusCode(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterIdentityIdentifier(filter);
    setPolicyVersionIdentifier(filter, policyVersionIdentifier);
    updateFilterStatusCode(filter);
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de la version de politique.
   *
   * @param filter filtre
   * @param policyVersionIdentifier identifiant de la version de politique
   */
  public static void setPolicyVersionIdentifier(FilterDto filter,
      String policyVersionIdentifier) {
    set(filter, JSON_POLICY_VERSION_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(policyVersionIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de la version de politique.
   *
   * @param filter filtre
   * @return identifiant de la version de politique
   */
  public static String getPolicyVersionIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_POLICY_VERSION_IDENTIFIER));
  }

  /**
   * Identifiant json champ {@link #policyVersionIdentifier}.
   */
  public static final String JSON_POLICY_VERSION_IDENTIFIER =
      IdentityPolicyConsentDto.JSON_POLICY_VERSION_IDENTIFIER;
}
