package ci.gouv.dgbf.system.user.server.api;

import ci.gouv.dgbf.extension.core.segregation.HasGroupAsStringDto;
import ci.gouv.dgbf.extension.core.segregation.HasGroupIdentifierDto;
import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserAsStringDto;
import ci.gouv.dgbf.system.user.server.api.shared.HasUserIdentifierDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente un domaine.
 *
 * @author Arnaud
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class UserGroupDto extends AbstractIdentifiableAuditableDto implements HasUserIdentifierDto,
    HasUserAsStringDto, HasGroupIdentifierDto, HasGroupAsStringDto {

  @JsonbProperty(JSON_USER_IDENTIFIER)
  private String userIdentifier;

  @JsonbProperty(JSON_USER_AS_STRING)
  private String userAsString;
  
  @JsonbProperty(JSON_GROUP_IDENTIFIER)
  private String groupIdentifier;

  @JsonbProperty(JSON_GROUP_AS_STRING)
  private String groupAsString;


  /**
   * Identifiant json de l'identifiant.
   */
  public static final String JSON_THIS_IDENTIFIER = "idUtilisateurGroupe";

  /**
   * Identifiant json de la représentation en chaine de caractères.
   */
  public static final String JSON_THIS_AS_STRING = "utilisateurGroupeChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "utilisateur de groupe";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "utilisateurs de groupes";
}
