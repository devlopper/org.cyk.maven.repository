package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import jakarta.enterprise.context.ApplicationScoped;
import javax.annotation.processing.Generated;

/**
* Cette interface représente le mapping de requête et {@link SectionUnitDto}.
*
* @author stephane
*
*/
@Generated(
    value = "org.mapstruct.ap.MappingProcessor",
    date = "2026-08-12T18:07:43+0000",
    comments = "version: 1.6.0, compiler: javac, environment: Java 17.0.2 (Oracle Corporation)"
)
@ApplicationScoped
public class SectionUnitRequestMapperImpl implements SectionUnitRequestMapper {

    @Override
    public SectionUnitService.SectionUnitCreateRequestDto mapCreate(SectionUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SectionUnitService.SectionUnitCreateRequestDto sectionUnitCreateRequestDto = new SectionUnitService.SectionUnitCreateRequestDto();

        sectionUnitCreateRequestDto.setAuditWho( arg0.getAuditWho() );
        sectionUnitCreateRequestDto.setCode( arg0.getCode() );
        sectionUnitCreateRequestDto.setName( arg0.getName() );
        sectionUnitCreateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );

        return sectionUnitCreateRequestDto;
    }

    @Override
    public SectionUnitService.SectionUnitUpdateRequestDto mapUpdate(SectionUnitDto arg0) {
        if ( arg0 == null ) {
            return null;
        }

        SectionUnitService.SectionUnitUpdateRequestDto sectionUnitUpdateRequestDto = new SectionUnitService.SectionUnitUpdateRequestDto();

        sectionUnitUpdateRequestDto.setAuditWho( arg0.getAuditWho() );
        sectionUnitUpdateRequestDto.setIdentifier( arg0.getIdentifier() );
        sectionUnitUpdateRequestDto.setCode( arg0.getCode() );
        sectionUnitUpdateRequestDto.setName( arg0.getName() );
        sectionUnitUpdateRequestDto.setSectionIdentifier( arg0.getSectionIdentifier() );

        return sectionUnitUpdateRequestDto;
    }
}
