package ci.gouv.dgbf.extension.primefaces.crud;

import ci.gouv.dgbf.extension.primefaces.AbstractActionController;
import ci.gouv.dgbf.extension.primefaces.ActionExecutor;
import ci.gouv.dgbf.extension.server.service.api.response.IdentifiableResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.DeleteByIdentifier;
import jakarta.enterprise.context.Dependent;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le contrôleur de suppression.
 *
 * @author Christian
 *
 */
@Dependent
public class DeleteController extends AbstractActionController<IdentifiableResponseDto> {

  @Getter
  @Setter
  Object client;
  
  public DeleteController() {
    name = "Suppression";
  }
  
  /**
   * Cette méthode permet de supprimer.
   *
   * @return navigation
   */
  public String deleteByIdentifier(String identifier) {
    return new ActionExecutor<String>(this, name, () -> {
      IdentifiableResponseDto response = doDeleteByIdentifier(identifier);
      processResponse(response);
      updateComponents();
      publishNotification(response);
      return navigate(response);
    }).execute(); 
  }
  
  IdentifiableResponseDto doDeleteByIdentifier(String identifier) {
    if (client instanceof DeleteByIdentifier<?> c) {
      return (IdentifiableResponseDto) c.deleteByIdentifier(identifier, userIdentifier, null);
    }
    throw new IllegalStateException("La suppression de données n'a pas été implémentée.");
  }
}
