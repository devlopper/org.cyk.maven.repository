package ci.gouv.dgbf.system.budgetaryclassification.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.budgetaryclassification.server.api.BudgetSpecializationUnitCategoryService.GetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * Cette classe représente un client de {@link BudgetSpecializationUnitCategoryService}.
 *
 * @author Arnaud
 *
 */
@ApplicationScoped
@Setter
@Accessors(chain = true, fluent = true)
public class BudgetSpecializationUnitCategoryClient extends
    AbstractClient<BudgetSpecializationUnitCategoryService>
    implements GetByIdentifier<BudgetSpecializationUnitCategoryDto>, GetMany<GetManyResponseDto> {

  @Override
  public BudgetSpecializationUnitCategoryClient
      service(BudgetSpecializationUnitCategoryService service) {
    return (BudgetSpecializationUnitCategoryClient) super.service(service);
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public GetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<GetManyResponseDto>(GetManyResponseDto.class,
        BudgetSpecializationUnitCategoryService.GET_MANY_IDENTIFIER)
        .execute(() -> service().getMany(request));
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public GetManyResponseDto getMany(ProjectionDto projection, FilterDto filter, PageDto page,
      String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public BudgetSpecializationUnitCategoryDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<BudgetSpecializationUnitCategoryDto>(
      BudgetSpecializationUnitCategoryDto.class,
      BudgetSpecializationUnitCategoryService.GET_ONE_IDENTIFIER)
      .execute(() -> service().getOne(request));
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public BudgetSpecializationUnitCategoryDto getOne(ProjectionDto projection,
      FilterDto filter, String auditWho, String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public BudgetSpecializationUnitCategoryDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<BudgetSpecializationUnitCategoryDto>(
      BudgetSpecializationUnitCategoryDto.class,
        BudgetSpecializationUnitCategoryService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link BudgetSpecializationUnitCategoryService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public BudgetSpecializationUnitCategoryDto getByIdentifier(String identifier,
        ProjectionDto projection, String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }
}
