package ci.gouv.dgbf.extension.primefaces;

import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import jakarta.enterprise.context.ApplicationScoped;
import java.util.function.Supplier;

/**
 * Cette classe représente l'accesseur de projection.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ProjectionDtoGetter {

  /**
   * Cette méthode permet d'obtenir une projection.
   *
   * @param value valeur
   * @param supplier fournisseur
   * @return projection
   */
  public ProjectionDto get(Object value, Supplier<Object> supplier) {
    ProjectionDto dto = get(value);
    if (dto != null) {
      return dto;
    }
    if (supplier != null) {
      dto = get(supplier.get());
    }
    return dto;
  }

  ProjectionDto get(Object object) {
    if (object instanceof ProjectionDto dto) {
      return dto;
    }
    return null;
  }
}
