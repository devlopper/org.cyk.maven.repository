package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.AbstractIdentifiableFilter;
import ci.gouv.dgbf.extension.server.service.api.filter.FilterHasTypeIdentifier;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente le filtre de {@link PayrollElementClaimDto}.
 *
 * @author akm
 *
 */
@Getter
@Setter
public class PayrollElementClaimFilter extends AbstractIdentifiableFilter
    implements FilterHasTypeIdentifier {

  /**
   * Identifiant du type de réclamation.
   */
  String typeIdentifier;

  /**
   * Statut de la réclamation.
   */
  String status;

  /**
   * Identifiant de l'émetteur de la réclamation.
   */
  String issuerIdentifier;

  /**
   * Identifiant du FAE concerné par la réclamation
   * ({@link PayrollElementClaimDto#getConcernedFunctionaryIdentifier()}) -- distinct de
   * {@link #issuerIdentifier} : couvre aussi bien le dépôt pour son propre compte (les deux
   * identifiants sont alors égaux) que celui fait par un agent de traitement/Tiers habilité pour
   * un autre FAE (RU_REP_003), utilisé par le suivi des réclamations d'un fonctionnaire
   * (annuaire).
   */
  String concernedFunctionaryIdentifier;

  /**
   * Statut à exclure -- distinct de {@link #status} (qui ne cible qu'un statut précis) : sert au
   * suivi des réclamations d'un fonctionnaire (annuaire) pour exclure les brouillons
   * ({@code CREEE}), jamais soumis, sans avoir à énumérer les statuts à inclure un par un.
   */
  String excludedStatus;

  /**
   * Identifiant de l'Agent de Traitement ayant pris en charge la réclamation
   * ({@link PayrollElementClaimDto#getProcessingAgentIdentifier()}) -- utilisé par le
   * portefeuille de l'Agent (RU_REP_015) pour ses files "Prises en charge"/"Différées" (files b/c,
   * CU_REP_015).
   */
  String processingAgentIdentifier;

  /**
   * Vrai pour ne retenir que les réclamations Acceptées portant au moins une {@code
   * ClaimedValueReview} encore à l'état Générée -- utilisé par le portefeuille de l'Agent de
   * Traitement (RU_REP_015) pour sa file "Revues à transmettre" (transmission manuelle et
   * groupée pour Visa, RG_REP_RVR_01).
   */
  Boolean hasReviewsPendingTransmission;

  /**
   * Statut de {@code ClaimedValueReview} porté par l'onglet actif -- distinct de {@link #status}
   * (statut de la réclamation elle-même) : utilisé par l'écran de traitement des revues
   * (RU_REP_010) pour ne retenir que les réclamations portant au moins une Revue à ce statut, et
   * pour la colonne "Nombre de revues" (compte des Revues de la réclamation à ce statut).
   */
  String reviewStatus;

  /**
   * Cette méthode permet d'instantier un objet.
   *
   * @param dto filtre
   */
  public PayrollElementClaimFilter(FilterDto dto) {
    super(dto);
  }

  /**
   * Cette méthode permet d'instantier un objet.
   */
  public PayrollElementClaimFilter() {}

  @Override
  protected void doInitialize(FilterDto filter) {
    super.doInitialize(filter);
    updateTypeIdentifier(filter);
    status = getStatus(filter);
    issuerIdentifier = getIssuerIdentifier(filter);
    concernedFunctionaryIdentifier = getConcernedFunctionaryIdentifier(filter);
    excludedStatus = getExcludedStatus(filter);
    processingAgentIdentifier = getProcessingAgentIdentifier(filter);
    hasReviewsPendingTransmission = getHasReviewsPendingTransmission(filter);
    reviewStatus = getReviewStatus(filter);
  }

  @Override
  protected void toDto(FilterDto filter) {
    super.toDto(filter);
    updateFilterTypeIdentifier(filter);
    setStatus(filter, status);
    setIssuerIdentifier(filter, issuerIdentifier);
    setConcernedFunctionaryIdentifier(filter, concernedFunctionaryIdentifier);
    setExcludedStatus(filter, excludedStatus);
    setProcessingAgentIdentifier(filter, processingAgentIdentifier);
    setHasReviewsPendingTransmission(filter, hasReviewsPendingTransmission);
    setReviewStatus(filter, reviewStatus);
  }

  /**
   * Cette méthode permet d'assigner le statut.
   *
   * @param filter filtre
   * @param status statut
   */
  public static void setStatus(FilterDto filter, String status) {
    set(filter, JSON_STATUS, f -> f.getValueAsString(), f -> f.setValueAsString(status));
  }

  /**
   * Cette méthode permet d'obtenir le statut.
   *
   * @param filter filtre
   * @return statut
   */
  public static String getStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_STATUS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'émetteur.
   *
   * @param filter filtre
   * @param issuerIdentifier identifiant de l'émetteur
   */
  public static void setIssuerIdentifier(FilterDto filter, String issuerIdentifier) {
    set(filter, JSON_ISSUER_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(issuerIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'émetteur.
   *
   * @param filter filtre
   * @return identifiant de l'émetteur
   */
  public static String getIssuerIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_ISSUER_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant du FAE concerné.
   *
   * @param filter filtre
   * @param concernedFunctionaryIdentifier identifiant du FAE concerné
   */
  public static void setConcernedFunctionaryIdentifier(FilterDto filter,
      String concernedFunctionaryIdentifier) {
    set(filter, JSON_CONCERNED_FUNCTIONARY_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(concernedFunctionaryIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant du FAE concerné.
   *
   * @param filter filtre
   * @return identifiant du FAE concerné
   */
  public static String getConcernedFunctionaryIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_CONCERNED_FUNCTIONARY_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner le statut à exclure.
   *
   * @param filter filtre
   * @param excludedStatus statut à exclure
   */
  public static void setExcludedStatus(FilterDto filter, String excludedStatus) {
    set(filter, JSON_EXCLUDED_STATUS, f -> f.getValueAsString(),
        f -> f.setValueAsString(excludedStatus));
  }

  /**
   * Cette méthode permet d'obtenir le statut à exclure.
   *
   * @param filter filtre
   * @return statut à exclure
   */
  public static String getExcludedStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_EXCLUDED_STATUS));
  }

  /**
   * Cette méthode permet d'assigner l'identifiant de l'Agent de Traitement ayant pris en charge.
   *
   * @param filter filtre
   * @param processingAgentIdentifier identifiant de l'Agent de Traitement
   */
  public static void setProcessingAgentIdentifier(FilterDto filter,
      String processingAgentIdentifier) {
    set(filter, JSON_PROCESSING_AGENT_IDENTIFIER, f -> f.getValueAsString(),
        f -> f.setValueAsString(processingAgentIdentifier));
  }

  /**
   * Cette méthode permet d'obtenir l'identifiant de l'Agent de Traitement ayant pris en charge.
   *
   * @param filter filtre
   * @return identifiant de l'Agent de Traitement
   */
  public static String getProcessingAgentIdentifier(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_PROCESSING_AGENT_IDENTIFIER));
  }

  /**
   * Cette méthode permet d'assigner l'indicateur de revues en attente de transmission.
   *
   * @param filter filtre
   * @param hasReviewsPendingTransmission indicateur de revues en attente de transmission
   */
  public static void setHasReviewsPendingTransmission(FilterDto filter,
      Boolean hasReviewsPendingTransmission) {
    set(filter, JSON_HAS_REVIEWS_PENDING_TRANSMISSION, f -> f.getValueAsBoolean(),
        f -> f.setValueAsBoolean(hasReviewsPendingTransmission));
  }

  /**
   * Cette méthode permet d'obtenir l'indicateur de revues en attente de transmission.
   *
   * @param filter filtre
   * @return indicateur de revues en attente de transmission
   */
  public static Boolean getHasReviewsPendingTransmission(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsBooleanByName(JSON_HAS_REVIEWS_PENDING_TRANSMISSION));
  }

  /**
   * Cette méthode permet d'assigner le statut de {@code ClaimedValueReview} porté par l'onglet
   * actif.
   *
   * @param filter filtre
   * @param reviewStatus statut de {@code ClaimedValueReview}
   */
  public static void setReviewStatus(FilterDto filter, String reviewStatus) {
    set(filter, JSON_REVIEW_STATUS, f -> f.getValueAsString(),
        f -> f.setValueAsString(reviewStatus));
  }

  /**
   * Cette méthode permet d'obtenir le statut de {@code ClaimedValueReview} porté par l'onglet
   * actif.
   *
   * @param filter filtre
   * @return statut de {@code ClaimedValueReview}
   */
  public static String getReviewStatus(FilterDto filter) {
    return get(filter, d -> d.getFieldValueAsStringByName(JSON_REVIEW_STATUS));
  }

  /**
   * Identifiant json champ {@link #status}.
   */
  public static final String JSON_STATUS = PayrollElementClaimDto.JSON_STATUS;

  /**
   * Identifiant json champ {@link #issuerIdentifier}.
   */
  public static final String JSON_ISSUER_IDENTIFIER = PayrollElementClaimDto.JSON_ISSUER_IDENTIFIER;

  /**
   * Identifiant json champ {@link #concernedFunctionaryIdentifier}.
   */
  public static final String JSON_CONCERNED_FUNCTIONARY_IDENTIFIER =
      PayrollElementClaimDto.JSON_CONCERNED_FUNCTIONARY_IDENTIFIER;

  /**
   * Identifiant json champ {@link #excludedStatus}.
   */
  public static final String JSON_EXCLUDED_STATUS = "statutExclu";

  /**
   * Identifiant json champ {@link #processingAgentIdentifier}.
   */
  public static final String JSON_PROCESSING_AGENT_IDENTIFIER =
      PayrollElementClaimDto.JSON_PROCESSING_AGENT_IDENTIFIER;

  /**
   * Identifiant json champ {@link #hasReviewsPendingTransmission}.
   */
  public static final String JSON_HAS_REVIEWS_PENDING_TRANSMISSION = "revuesEnAttenteTransmission";

  /**
   * Identifiant json champ {@link #reviewStatus}.
   */
  public static final String JSON_REVIEW_STATUS = "statutRevue";
}
