package ci.gouv.dgbf.system.identity.server.api;

import ci.gouv.dgbf.extension.server.service.api.client.AbstractClient;
import ci.gouv.dgbf.extension.server.service.api.client.executor.CreateExecutor;
import ci.gouv.dgbf.extension.server.service.api.client.executor.GetOneExecutor;
import ci.gouv.dgbf.extension.server.service.api.request.ByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.FilterDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetByIdentifierRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetManyRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.GetOneRequestDto;
import ci.gouv.dgbf.extension.server.service.api.request.PageDto;
import ci.gouv.dgbf.extension.server.service.api.request.ProjectionDto;
import ci.gouv.dgbf.extension.server.service.api.response.CreateResponseDto;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetByIdentifier;
import ci.gouv.dgbf.extension.server.service.api.segregation.GetMany;
import ci.gouv.dgbf.system.identity.server.api.ImportableIdentityService.ImportableIdentityGetManyResponseDto;
import jakarta.enterprise.context.ApplicationScoped;

/**
 * Cette classe représente le client de ImportableIdentityService.
 *
 * @author Christian
 *
 */
@ApplicationScoped
public class ImportableIdentityClient extends AbstractClient<ImportableIdentityService> implements
    GetByIdentifier<ImportableIdentityDto>, GetMany<ImportableIdentityGetManyResponseDto> {

  @Override
  public ImportableIdentityClient service(ImportableIdentityService service) {
    return (ImportableIdentityClient) super.service(service);
  }

  /**
   * {@link ImportableIdentityService#getMany}.
   *
   * @param request requête
   * @return réponse
   */
  public ImportableIdentityGetManyResponseDto getMany(GetManyRequestDto request) {
    return new GetOneExecutor<ImportableIdentityGetManyResponseDto>(
        ImportableIdentityGetManyResponseDto.class, ImportableIdentityService.GET_MANY_IDENTIFIER)
            .execute(() -> service().getMany(request));
  }

  /**
   * {@link ImportableIdentityService#getMany}.
   *
   * @param projection projection
   * @param filter filtre
   * @param page page
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ImportableIdentityGetManyResponseDto getMany(ProjectionDto projection, FilterDto filter,
      PageDto page, String auditWho, String auditSession) {
    GetManyRequestDto request = new GetManyRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setPage(page);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getMany(request);
  }

  /**
   * {@link ImportableIdentityService#getOne}.
   *
   * @param request requête
   * @return réponse
   */
  public ImportableIdentityDto getOne(GetOneRequestDto request) {
    return new GetOneExecutor<ImportableIdentityDto>(ImportableIdentityDto.class,
        ImportableIdentityService.GET_ONE_IDENTIFIER).execute(() -> service().getOne(request));
  }

  /**
   * {@link ImportableIdentityService#getOne}.
   *
   * @param projection projection
   * @param filter filtre
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  public ImportableIdentityDto getOne(ProjectionDto projection, FilterDto filter, String auditWho,
      String auditSession) {
    GetOneRequestDto request = new GetOneRequestDto();
    request.setProjection(projection);
    request.setFilter(filter);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getOne(request);
  }

  /**
   * {@link ImportableIdentityService#getByIdentifier}.
   *
   * @param request requête
   * @return groupe d'échéance
   */
  public ImportableIdentityDto getByIdentifier(GetByIdentifierRequestDto request) {
    return new GetOneExecutor<ImportableIdentityDto>(ImportableIdentityDto.class,
        ImportableIdentityService.GET_BY_IDENTIFIER_IDENTIFIER)
            .execute(() -> service().getByIdentifier(request));
  }

  /**
   * {@link ImportableIdentityService#getByIdentifier}.
   *
   * @param identifier identifiant
   * @param projection projection
   * @param auditWho audit acteur
   * @param auditSession audit session
   * @return réponse
   */
  @Override
  public ImportableIdentityDto getByIdentifier(String identifier, ProjectionDto projection,
      String auditWho, String auditSession) {
    GetByIdentifierRequestDto request = new GetByIdentifierRequestDto();
    request.setIdentifier(identifier);
    request.setProjection(projection);
    request.setAuditWho(auditWho);
    request.setAuditSession(auditSession);
    return getByIdentifier(request);
  }

  /**
   * {@link ImportableIdentityService#importIdentity}.
   *
   * @param request requête
   * @return réponse
   */
  public CreateResponseDto importIdentity(ByIdentifierRequestDto request) {
    return new CreateExecutor(ImportableIdentityService.IMPORT_IDENTITY_PATH)
        .execute(() -> service().importIdentity(request));
  }
}
