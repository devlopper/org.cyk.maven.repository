package ci.gouv.dgbf.system.localauthority.server.api;

import ci.gouv.dgbf.extension.server.service.api.request.RequestMapper;
import ci.gouv.dgbf.system.localauthority.server.api.PhaseService.PhaseCreateRequestDto;
import ci.gouv.dgbf.system.localauthority.server.api.PhaseService.PhaseUpdateRequestDto;
import org.mapstruct.Javadoc;
import org.mapstruct.Mapper;

/**
 * Cette interface représente le mapping de requête et {@link ProcedureDto}.
 *
 * @author Christian
 *
 */
@Mapper
@Javadoc("""
    Cette interface représente le mapping de requête et {@link PhaseDto}.

    @author Stephane
               """)
public interface PhaseRequestMapper extends RequestMapper<PhaseDto,
    PhaseCreateRequestDto, PhaseUpdateRequestDto> {

}
