package ci.gouv.dgbf.system.budgetaryclassification.server.api.shared;

/**
 * Cette interface représente une classe qui a un identifiant de l'activité.
 *
 * @author Arnaud
 */
public interface HasActivityIdentifierDto
       extends HasActivityIdentifier {

  /**
   * Identifiant json de l'identifiant de l'activité.
   */
  String JSON_ACTIVITY_IDENTIFIER = "idActivite";
}