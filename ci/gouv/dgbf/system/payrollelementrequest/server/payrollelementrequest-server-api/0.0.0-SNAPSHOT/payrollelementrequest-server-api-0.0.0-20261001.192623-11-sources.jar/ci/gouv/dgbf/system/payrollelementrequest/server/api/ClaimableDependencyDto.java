package ci.gouv.dgbf.system.payrollelementrequest.server.api;

import ci.gouv.dgbf.extension.server.service.api.entity.AbstractIdentifiableAuditableDto;
import jakarta.json.bind.annotation.JsonbProperty;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 * Cette classe représente une dépendance entre deux Réclamables Élément de Paie (RG_REP_CIB_11) --
 * paire dirigée, mais symétrique par construction métier : {@link #claimableIdentifier} et
 * {@link #requiredClaimableIdentifier} n'ont aucune signification directionnelle propre l'un par
 * rapport à l'autre.
 *
 * @author akm
 *
 */
@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class ClaimableDependencyDto extends AbstractIdentifiableAuditableDto {

  /**
   * Identifiant d'un des deux Réclamables de la paire -- vraie FK vers le référentiel
   * {@code Claimable} ({@code TA_RECLAMABLE}, RG_REP_CIB_07).
   */
  @JsonbProperty(JSON_CLAIMABLE_IDENTIFIER)
  private String claimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #claimableIdentifier} -- résolue côté
   * serveur (lecture directe de {@code Claimable}, même module).
   */
  @JsonbProperty(JSON_CLAIMABLE_AS_STRING)
  private String claimableAsString;

  /**
   * Identifiant de l'autre Réclamable de la paire -- vraie FK vers le référentiel
   * {@code Claimable} ({@code TA_RECLAMABLE}, RG_REP_CIB_07).
   */
  @JsonbProperty(JSON_REQUIRED_CLAIMABLE_IDENTIFIER)
  private String requiredClaimableIdentifier;

  /**
   * Représentation en chaine de caractères de {@link #requiredClaimableIdentifier} -- résolue
   * côté serveur, sur le même principe que {@link #claimableAsString}.
   */
  @JsonbProperty(JSON_REQUIRED_CLAIMABLE_AS_STRING)
  private String requiredClaimableAsString;

  /**
   * Identifiant json {@link #claimableIdentifier}.
   */
  public static final String JSON_CLAIMABLE_IDENTIFIER = "idReclamable";

  /**
   * Identifiant json {@link #claimableAsString}.
   */
  public static final String JSON_CLAIMABLE_AS_STRING = "reclamableChaine";

  /**
   * Identifiant json {@link #requiredClaimableIdentifier}.
   */
  public static final String JSON_REQUIRED_CLAIMABLE_IDENTIFIER = "idReclamableRequis";

  /**
   * Identifiant json {@link #requiredClaimableAsString}.
   */
  public static final String JSON_REQUIRED_CLAIMABLE_AS_STRING = "reclamableRequisChaine";

  /**
   * Nom pour lecture humaine de la classe.
   */
  public static final String NAME = "cible indissociable";

  /**
   * Nom au pluriel pour lecture humaine de la classe.
   */
  public static final String PLURAL_NAME = "cibles indissociables";
}
